sap.ui.define([
	"sap/ui/core/format/DateFormat"
	], function(DateFormat) {
	"use strict";

	return {

		/**
		 * Rounds the number unit value to 2 digits
		 * @public
		 * @param {string} sValue the number string to be rounded
		 * @returns {string} sValue with 2 digits rounded
		 */
		numberUnit: function(sValue) {
			if (!sValue) {
				return "";
			}
			return parseFloat(sValue).toFixed(2);
		},
		dateFormat: function(aDate) {
			
			if (aDate) {
				var oDateFormat = DateFormat.getDateTimeInstance({
						pattern: "MMM d, YYYY"
							// pattern: "MM/dd/YYYY"
					}),
					tzOffsetMs = aDate.getTimezoneOffset() * 60 * 1000;
				return oDateFormat.format(new Date(new Date(aDate).getTime() + tzOffsetMs));
			}

			return "";
		
		
		},
		btnVis: function(invDocNo, MatDocNo, PrintStatus) {
			if(invDocNo === null || MatDocNo=== null || PrintStatus === null){
				return false;
			}
			if (invDocNo.length === 0 || MatDocNo.length === 0) {
				return false;
			} else if (invDocNo.length > 0 && MatDocNo.length > 0 && PrintStatus === "X") {
				return false;
			} else if ((invDocNo.length === 0 || MatDocNo.length === 0) && PrintStatus === "X") {
				return false;
			} else if (invDocNo.length > 0 && MatDocNo.length > 0 && PrintStatus === "") {
				return true;
			}
		},
		txtVis: function(invDocNo, MatDocNo, PrintStatus) {
			if(invDocNo === null || MatDocNo=== null || PrintStatus === null){
				return false;
			}
			if (invDocNo.length === 0 || MatDocNo.length === 0) {
				return false;
			} else if (invDocNo.length > 0 && MatDocNo.length > 0 && PrintStatus === "X") {
				return true;
			} else if ((invDocNo.length === 0 || MatDocNo.length === 0) && PrintStatus === "X") {
				return false;
			} else if (invDocNo.length > 0 && MatDocNo.length > 0 && PrintStatus === "") {
				return false;
			}
		}

	};

});