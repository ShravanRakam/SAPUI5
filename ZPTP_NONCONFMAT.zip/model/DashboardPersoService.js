sap.ui.define(['jquery.sap.global'],
	function (jQuery) {
		"use strict";

		var poPersoService = {
			oData: {
				_persoSchemaVersion: "1.0",
				aColumns: [{
					id: "idCreateOn",
					order: 1,
					text: "Created On",
					visible: true
				}, {
					id: "idPlant",
					order: 2,
					text: "Plant",
					visible: true
				}, {
					id: "idMaterial",
					order: 3,
					text: "Material",
					visible: true
				}, {
					id: "idVers",
					order: 4,
					text: "Version",
					visible: true
				}, {
					id: "idMatDesc",
					order: 5,
					text: "Material Description",
					visible: true
				}, {
					id: "idMoveType",
					order: 6,
					text: "Move Type",
					visible: true
				}, {
					id: "idMovTypName",
					order: 7,
					text: "Move Type Date",
					visible: true
				}, {
					id: "idQuant",
					order: 8,
					text: "Quantity",
					visible: true
				}, {
					id: "idSign",
					order: 9,
					text: "Sign",
					visible: true
				}, {
					id: "idUOM",
					order: 10,
					text: "UOM",
					visible: true
				},{
					id: "idMovDate",
					order: 9,
					text: "Move Date",
					visible: true
				}, {
					id: "idRefNo",
					order: 10,
					text: "Reference No",
					visible: true
				},{
					id: "idSeqNo",
					order: 6,
					text: "Sequence No",
					visible: true
				}, {
					id: "idPreSeqNo",
					order: 7,
					text: "Pre Sequence Number",
					visible: true
				}, {
					id: "idMatDocNo",
					order: 8,
					text: "Material Document No",
					visible: true
				}, {
					id: "idMatDocDate",
					order: 9,
					text: "Material Document Date",
					visible: true
				}, {
					id: "idStorLoc",
					order: 10,
					text: "Storage Location",
					visible: true
				},{
					id: "idInvDocNo",
					order: 9,
					text: "Invoice Document No",
					visible: true
				}, {
					id: "idInvDocDate",
					order: 10,
					text: "Invoice Document Date",
					visible: true
				},{
					id: "idPrintStat",
					order: 10,
					text: "Print Status",
					visible: true
				}]
			},
			getPersData: function () {
				var oDeferred = new jQuery.Deferred();
				if (!this._oBundle) {
					this._oBundle = this.oData;
				}
				var oBundle = this._oBundle;
				oDeferred.resolve(oBundle);
				return oDeferred.promise();
			},

			setPersData: function (oBundle) {
				var oDeferred = new jQuery.Deferred();
				this._oBundle = oBundle;
				oDeferred.resolve();
				return oDeferred.promise();
			},

			delPersData: function () {
				var oDeferred = new jQuery.Deferred();
				oDeferred.resolve();
				return oDeferred.promise();
			}
		};

		return poPersoService;

	}, true);