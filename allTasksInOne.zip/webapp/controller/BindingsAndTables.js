sap.ui.define([
	"sap/ui/core/mvc/Controller",
	"sap/ui/core/ValueState",
	"sap/ui/model/Sorter",
	"sap/ui/model/Filter",
	"sap/ui/model/FilterOperator",
	"sap/ui/table/library",
	"sap/ui/model/json/JSONModel"

], function(Controller, ValueState, Sorter, Filter, FilterOperator, library, JSONModel) {
	"use strict";
	// var SortOrder = library.SortOrder;
	
	return Controller.extend("com.allTasksInOneallTasksInOne.controller.BindingsAndTables", {
	

	
		// for navigating the screen
		
		onPress: function(){
			var oRouter = sap.ui.core.UIComponent.getRouterFor(this);
			oRouter.navTo("similarProducts");
		}


	});
});