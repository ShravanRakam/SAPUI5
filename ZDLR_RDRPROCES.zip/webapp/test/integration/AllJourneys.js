/*global QUnit*/

jQuery.sap.require("sap.ui.qunit.qunit-css");
jQuery.sap.require("sap.ui.thirdparty.qunit");
jQuery.sap.require("sap.ui.qunit.qunit-junit");
QUnit.config.autostart = false;

sap.ui.require([
	"sap/ui/test/Opa5",
	"com/fiskerincdlr_rdr_process/ZDLR_RDRPROCES/test/integration/pages/Common",
	"sap/ui/test/opaQunit",
	"com/fiskerincdlr_rdr_process/ZDLR_RDRPROCES/test/integration/pages/Worklist",
	"com/fiskerincdlr_rdr_process/ZDLR_RDRPROCES/test/integration/pages/Object",
	"com/fiskerincdlr_rdr_process/ZDLR_RDRPROCES/test/integration/pages/NotFound",
	"com/fiskerincdlr_rdr_process/ZDLR_RDRPROCES/test/integration/pages/Browser",
	"com/fiskerincdlr_rdr_process/ZDLR_RDRPROCES/test/integration/pages/App"
], function (Opa5, Common) {
	"use strict";
	Opa5.extendConfig({
		arrangements: new Common(),
		viewNamespace: "com.fiskerincdlr_rdr_process.ZDLR_RDRPROCES.view."
	});

	sap.ui.require([
		"com/fiskerincdlr_rdr_process/ZDLR_RDRPROCES/test/integration/WorklistJourney",
		"com/fiskerincdlr_rdr_process/ZDLR_RDRPROCES/test/integration/ObjectJourney",
		"com/fiskerincdlr_rdr_process/ZDLR_RDRPROCES/test/integration/NavigationJourney",
		"com/fiskerincdlr_rdr_process/ZDLR_RDRPROCES/test/integration/NotFoundJourney"
	], function () {
		QUnit.start();
	});
});