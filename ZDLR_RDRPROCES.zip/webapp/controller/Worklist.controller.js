/*global location history */
sap.ui.define([
	"com/fiskerincdlr_rdr_process/ZDLR_RDRPROCES/controller/BaseController",
	"sap/ui/model/json/JSONModel",
	"com/fiskerincdlr_rdr_process/ZDLR_RDRPROCES/model/formatter",
	"sap/ui/model/Filter",
	"sap/ui/model/FilterOperator",
	"sap/m/MessageToast",
	'sap/m/SearchField',
	'sap/ui/model/type/String',
	'sap/ui/table/Column',
	'sap/m/Column',
	"sap/ui/core/fragment",
	'sap/m/Token',
	'sap/ui/comp/library',
	'sap/m/Text',
	"sap/m/Dialog",
	'sap/ui/core/IconPool',
	'sap/ui/core/library',
	'sap/m/MessageItem',
	'sap/m/MessageView',
	'sap/m/Button',
	'sap/m/Bar',
	'sap/m/Title',
	"sap/m/library"
], function(BaseController, JSONModel, formatter, Filter, FilterOperator, MessageToast, SearchField, TypeString, Column, MColumn,
	fragment, Token, library, Text, Dialog, IconPool, coreLibrary, MessageItem, MessageView, Button, Bar, Title, mobileLibrary) {
	"use strict";

	return BaseController.extend("com.fiskerincdlr_rdr_process.ZDLR_RDRPROCES.controller.Worklist", {

		formatter: formatter,

		/* =========================================================== */
		/* lifecycle methods                                           */
		/* =========================================================== */

		/**
		 * Called when the worklist controller is instantiated.
		 * @public
		 */
		onInit: function() {
			var that = this;

			var oDate1 = new Date();
			var cdate = oDate1.toLocaleDateString();
			var cdat = cdate.split("/");
			if (cdat[0].length === 1) {
				var mnth = "0" + cdat[0];
			}
			var fdate = cdat[2] + "-" + mnth + "-" + cdat[1];

			var oViewModel = new JSONModel({
				"VehiNum": "",
				"Customer": "",
				"CustoemrD": fdate,
				"FirstName": "",
				"LastName": "",
				"Street": "",
				"City": "",
				"PostalCode": "",
				"Country": "",
				"ValuestateFN": "None",
				"ValuestateLN": "None",
				"ValuestateST": "None",
				"ValuestateCT": "None",
				"ValuestatePC": "None",
				"ValuestateCN": "None",
			});

			that.setModel(oViewModel, "objectView");
			this._oMultiInput = this.getView().byId("InternalVehNum");
			this._oMultiInputVin = this.getView().byId("VIN");
			var sServiceURL = this.getOwnerComponent().getModel().sServiceUrl;
			var sModel = new sap.ui.model.odata.ODataModel(sServiceURL);
			sModel.read("/HeaderSet", {
				// filters: filters,
				success: function(oData, res) {
					that.oModelMat = new sap.ui.model.json.JSONModel(oData);
					// oModel.setSizeLimit(oData.results.length);
					// var r = that.byId("MatID");
					// r.setModel(oModelMat, "MatModel");
					that.getView().setModel(that.oModelMat, "MatModel");
				}.bind(that),
				error: function(oResponse) {
					that.errMsgReadFun(oResponse);
				}
			});
			sModel.read("/CountrySet", {
				success: function(oData, res) {
					var oModel = new JSONModel();
					oModel.setData({
						modelData: oData.results
					});
					oModel.setSizeLimit(oData.results.length);
					that.setModel(oModel, "baModelData");
				}.bind(that)
			});
			sModel.read("/ECustomerSet", {
				success: function(oData, res) {
					var oModel = new JSONModel();
					oModel.setData({
						modelData: oData.results
					});
					oModel.setSizeLimit(oData.results.length);
					that.setModel(oModel, "CustModel");
				}.bind(that)
			});
		},

		onVINVHRequested: function() {
			var that = this;
			var oTextTemplate = new Text({
				text: {
					path: 'MatModel>VHVIN'
				},
				renderWhitespace: true
			});
			this._oBasicSearchField = new SearchField({
				search: function() {
					this.oWhitespaceDialog.getFilterBar().search();
				}.bind(this)
			});
			if (!this.VinspaceDialog) {
				// this.pWhitespaceDialog = this.loadFragment({
				// 	// 	this.pWhitespaceDialog = Fragment.load({
				// 	name: "com.fiskerinczvmspioreport.zvms_pio_report.fragment.internalVehicle"
				// });
				this.VinspaceDialog = sap.ui.xmlfragment("com.fiskerincdlr_rdr_process.ZDLR_RDRPROCES.fragment.Vin", this);
				this.getView().addDependent(this._VinspaceDialog);
			}
			var oFilterBar = this.VinspaceDialog.getFilterBar();
			this.oVinspaceDialog = this.VinspaceDialog;
			this.getView().addDependent(this.oVinspaceDialog);
			// Set key fields for filtering in the Define Conditions Tab
			this.oVinspaceDialog.setRangeKeyFields([{
				label: "Vin",
				key: "VHVIN",
				type: "string",
				typeInstance: new TypeString({}, {
					maxLength: 35
				})
			}]);
			// Set Basic Search for FilterBar
			oFilterBar.setFilterBarExpanded(false);
			oFilterBar.setBasicSearch(this._oBasicSearchField);

			// Re-map whitespaces
			oFilterBar.determineFilterItemByName("VHVIN").getControl().setTextFormatter(this._inputTextFormatter);

			this.VinspaceDialog.getTableAsync().then(function(oTable) {
				// this.oWhitespaceDialog.getTableAsync().then(function(oTable) {
				oTable.setModel(that.oModelMat, "MatModel");

				// For Desktop and tabled the default table is sap.ui.table.Table
				if (oTable.bindRows) {
					oTable.addColumn(new Column({
						label: "Vin",
						template: oTextTemplate
					}));
					// oTable.addColumn(new Column({
					// 	label: "Product Name",
					// 	template: "ProductName"
					// }));
					oTable.bindAggregation("rows", {
						path: "MatModel>/results"
							// events: {
							// 	// dataReceived: function() {
							// 	// }
							// }
					});
				}

				// For Mobile the default table is sap.m.Table
				if (oTable.bindItems) {
					oTable.addColumn(new MColumn({
						header: new sap.m.Label({
							text: "Vin"
						})
					}));
					// oTable.addColumn(new MColumn({
					// 	header: new sap.m.Label({
					// 		text: "Product Name"
					// 	})
					// }));
					oTable.bindItems({
						path: "MatModel>/results",
						template: new sap.m.ColumnListItem({
							cells: [new sap.m.Label({
								text: "{MatModel>VHVIN}"
							}), new sap.m.Label({
								text: "Vin"
							})]
						}),
						events: {
							dataReceived: function() {
								this.VinspaceDialog.update();
							}
						}
					});
				}

				// this.pWhitespaceDialog.update();
			}.bind(this));

			// this.pWhitespaceDialog.setTokens(this._oWhiteSpacesInput.getTokens());
			// this._bWhitespaceDialogInitialized = true;
			this.VinspaceDialog.open();
		},
		onWhitespaceVHRequested: function() {
			var that = this;
			var oTextTemplate = new sap.m.Text({
				text: {
					path: 'MatModel>VHCLE'
				},
				renderWhitespace: true
			});

			this._oBasicSearchField = new SearchField({
				search: function() {
					this.oWhitespaceDialog.getFilterBar().search();
				}.bind(this)
			});
			if (!this.pWhitespaceDialog) {
				// this.pWhitespaceDialog = this.loadFragment({
				// 	// 	this.pWhitespaceDialog = Fragment.load({
				// 	name: "com.fiskerinczvmspioreport.zvms_pio_report.fragment.internalVehicle"
				// });
				this.pWhitespaceDialog = sap.ui.xmlfragment("com.fiskerincdlr_rdr_process.ZDLR_RDRPROCES.fragment.internalVehicle", this);
				this.getView().addDependent(this._pWhitespaceDialog);
			}
			// this.pWhitespaceDialog.then(function(oWhitespaceDialog) {
			var oFilterBar = this.pWhitespaceDialog.getFilterBar();
			this.oWhitespaceDialog = this.pWhitespaceDialog;
			// if (this._bWhitespaceDialogInitialized) {
			// 	// Re-set the tokens from the input and update the table
			// 	oWhitespaceDialog.setTokens([]);
			// 	oWhitespaceDialog.setTokens(this._oWhiteSpacesInput.getTokens());
			// 	oWhitespaceDialog.update();

			// 	oWhitespaceDialog.open();
			// 	return;
			// }
			// this.getView().addDependent(this.pWhitespaceDialog);
			this.getView().addDependent(this.oWhitespaceDialog);
			// Set key fields for filtering in the Define Conditions Tab
			this.oWhitespaceDialog.setRangeKeyFields([{
				label: "Internal Vehicle Number",
				key: "VHCLE",
				type: "string",
				typeInstance: new TypeString({}, {
					maxLength: 10
				})
			}]);

			// Set Basic Search for FilterBar
			oFilterBar.setFilterBarExpanded(false);
			oFilterBar.setBasicSearch(this._oBasicSearchField);

			// Re-map whitespaces
			oFilterBar.determineFilterItemByName("VHCLE").getControl().setTextFormatter(this._inputTextFormatter);
			//	that.loadTable();
			this.pWhitespaceDialog.getTableAsync().then(function(oTable) {
				// this.oWhitespaceDialog.getTableAsync().then(function(oTable) {
				oTable.setModel(that.oModelMat, "MatModel");

				// For Desktop and tabled the default table is sap.ui.table.Table
				if (oTable.bindRows) {
					oTable.addColumn(new Column({
						label: "Internal Vehicle Number",
						template: oTextTemplate
					}));
					// oTable.addColumn(new Column({
					// 	label: "Product Name",
					// 	template: "ProductName"
					// }));
					oTable.bindAggregation("rows", {
						path: "MatModel>/results"
							// events: {
							// 	// dataReceived: function() {
							// 	// }
							// }
					});
				}

				// For Mobile the default table is sap.m.Table
				if (oTable.bindItems) {
					oTable.addColumn(new MColumn({
						header: new sap.m.Label({
							text: "Internal Vehicle Number"
						})
					}));
					// oTable.addColumn(new MColumn({
					// 	header: new sap.m.Label({
					// 		text: "Product Name"
					// 	})
					// }));
					oTable.bindItems({
						path: "MatModel/results",
						template: new sap.m.ColumnListItem({
							cells: [new sap.m.Label({
								text: "{MatModel>VHCLE}"
							}), new sap.m.Label({
								text: "Internal Vehicle Number"
							})]
						}),
						events: {
							dataReceived: function() {
								this.pWhitespaceDialog.update();
							}
						}
					});
				}

				// this.pWhitespaceDialog.update();
			}.bind(this));

			// this.pWhitespaceDialog.setTokens(this._oWhiteSpacesInput.getTokens());
			// this._bWhitespaceDialogInitialized = true;
			this.pWhitespaceDialog.open();

			// }.bind(this));
		},
		// onCustomer: function() {
		// 	var that = this;
		// 	var oTextTemplate = new sap.m.Text({
		// 		text: {
		// 			path: 'CustModel>KUNNR'
		// 		},
		// 		renderWhitespace: true
		// 	});

		// 	this._oBasicSearchField = new SearchField({
		// 		search: function() {
		// 			this.oWhitespaceDialog.getFilterBar().search();
		// 		}.bind(this)
		// 	});
		// 	if (!this.pWhitespaceDialog) {
		// 		// this.pWhitespaceDialog = this.loadFragment({
		// 		// 	// 	this.pWhitespaceDialog = Fragment.load({
		// 		// 	name: "com.fiskerinczvmspioreport.zvms_pio_report.fragment.internalVehicle"
		// 		// });
		// 		this.pWhitespaceDialog = sap.ui.xmlfragment("com.fiskerincdlr_rdr_process.ZDLR_RDRPROCES.fragment.Customer", this);
		// 		this.getView().addDependent(this._pWhitespaceDialog);
		// 	}
		// 	// this.pWhitespaceDialog.then(function(oWhitespaceDialog) {
		// 	var oFilterBar = this.pWhitespaceDialog.getFilterBar();
		// 	this.oWhitespaceDialog = this.pWhitespaceDialog;
		// 	// if (this._bWhitespaceDialogInitialized) {
		// 	// 	// Re-set the tokens from the input and update the table
		// 	// 	oWhitespaceDialog.setTokens([]);
		// 	// 	oWhitespaceDialog.setTokens(this._oWhiteSpacesInput.getTokens());
		// 	// 	oWhitespaceDialog.update();

		// 	// 	oWhitespaceDialog.open();
		// 	// 	return;
		// 	// }
		// 	// this.getView().addDependent(this.pWhitespaceDialog);
		// 	this.getView().addDependent(this.oWhitespaceDialog);
		// 	// Set key fields for filtering in the Define Conditions Tab
		// 	this.oWhitespaceDialog.setRangeKeyFields([{
		// 		label: "Customer",
		// 		key: "KUNNR",
		// 		type: "string",
		// 		typeInstance: new TypeString({}, {
		// 			maxLength: 10
		// 		})
		// 	}]);

		// 	// Set Basic Search for FilterBar
		// 	oFilterBar.setFilterBarExpanded(false);
		// 	oFilterBar.setBasicSearch(this._oBasicSearchField);

		// 	// Re-map whitespaces
		// 	oFilterBar.determineFilterItemByName("KUNNR").getControl().setTextFormatter(this._inputTextFormatter);
		// 	//	that.loadTable();
		// 	this.pWhitespaceDialog.getTableAsync().then(function(oTable) {
		// 		// this.oWhitespaceDialog.getTableAsync().then(function(oTable) {
		// 		oTable.setModel(that.oModelMat, "CustModel");

		// 		// For Desktop and tabled the default table is sap.ui.table.Table
		// 		if (oTable.bindRows) {
		// 			oTable.addColumn(new Column({
		// 				label: "Customer",
		// 				template: oTextTemplate
		// 			}));
		// 			// oTable.addColumn(new Column({
		// 			// 	label: "Product Name",
		// 			// 	template: "ProductName"
		// 			// }));
		// 			oTable.bindAggregation("rows", {
		// 				path: "CustModel>/results"
		// 					// events: {
		// 					// 	// dataReceived: function() {
		// 					// 	// }
		// 					// }
		// 			});
		// 		}

		// 		// For Mobile the default table is sap.m.Table
		// 		if (oTable.bindItems) {
		// 			oTable.addColumn(new MColumn({
		// 				header: new sap.m.Label({
		// 					text: "Customer"
		// 				})
		// 			}));
		// 			// oTable.addColumn(new MColumn({
		// 			// 	header: new sap.m.Label({
		// 			// 		text: "Product Name"
		// 			// 	})
		// 			// }));
		// 			oTable.bindItems({
		// 				path: "CustModel/results",
		// 				template: new sap.m.ColumnListItem({
		// 					cells: [new sap.m.Label({
		// 						text: "{CustModel>VHCLE}"
		// 					}), new sap.m.Label({
		// 						text: "Customer"
		// 					})]
		// 				}),
		// 				events: {
		// 					dataReceived: function() {
		// 						this.pWhitespaceDialog.update();
		// 					}
		// 				}
		// 			});
		// 		}

		// 		// this.pWhitespaceDialog.update();
		// 	}.bind(this));

		// 	// this.pWhitespaceDialog.setTokens(this._oWhiteSpacesInput.getTokens());
		// 	// this._bWhitespaceDialogInitialized = true;
		// 	this.pWhitespaceDialog.open();

		// 	// }.bind(this));
		// },
		OnSelectionChange: function(oEvent) {
			var that = this;
			var filters = [];
			var country = oEvent.getSource().getSelectedKey();
			var sServiceURL = this.getOwnerComponent().getModel().sServiceUrl;
			var sModel = new sap.ui.model.odata.ODataModel(sServiceURL);
			filters.push(new sap.ui.model.Filter("LAND1", sap.ui.model.FilterOperator.EQ, country));
			if (country !== "") {
				sModel.read("/RegionSet", {
					filters: filters,
					success: function(oData, res) {
						var oModel = new JSONModel();
						oModel.setData({
							modelData: oData.results
						});
						oModel.setSizeLimit(oData.results.length);
						that.setModel(oModel, "RegModelData");
					}.bind(that)
				});
			} else {
				var oModel = new JSONModel();
				oModel.setData({
					modelData: ""
				});
				that.setModel(oModel, "RegModelData");
			}

		},
		onUpdate: function(oEvent) {
			var that = this;
			var oControl = oEvent.getSource();
			var gettingInternalTable = this.byId("Vehicle").getTable(),
				// length = gettingInternalTable.getSelectedContextPaths().length;
				gettingAllRows = gettingInternalTable.getRows();
			var oSelIndices = gettingInternalTable.getSelectedIndices();
			var length = oSelIndices.length;
			if (length === 1) {
				var Vbeln = gettingInternalTable.getContextByIndex(oSelIndices[0]).getObject("VHCLE");
				// // var Vbeln = this.byId("Vehicle").getTable().getSelectedItems()[0].getCells()[6].getText();
				that.getModel("objectView").setProperty("/VehiNum", Vbeln);
				that._oEditSubDetailDialog = sap.ui.xmlfragment("com.fiskerincdlr_rdr_process.ZDLR_RDRPROCES.fragment.UpdateCustomer", this);

				if (!that.UpdateCust) {
					that.UpdateCust = sap.ui.xmlfragment("com.fiskerincdlr_rdr_process.ZDLR_RDRPROCES.fragment.UpdateCustomer", that);
					that.getView().addDependent(that.UpdateCust);
				}
				that.UpdateCust.open();
			} else if (length > 1) {
				var msg = "Please select only one record";
				MessageToast.show(msg);
			} else if (length === 0) {
				var msg1 = "Please select atleast one record";
				MessageToast.show(msg1);
			}
		},
		OnDatechange: function(oEvent) {
			var that = this;
			var sValue = oEvent.getParameter("value");
			var SValue = sValue.split("/");
			var oDate = new Date();
			var year = oDate.getFullYear();
			// if (sValue[2].slice().length === 1) {
			// 	var mon = "0" + SValue[0];
			// }
			var CustomerDate = SValue[2] + SValue[0]  + SValue[1];
			that.getModel("objectView").setProperty("/CustoemrD", CustomerDate);
		},
		onClose: function(oEvent) {
			this.UpdateCust.close();
			this.UpdateCust.destroy();
			this.UpdateCust = null;
		},
		onCloseC: function(oEvent) {
			this.CreateCustomer.close();
			this.CreateCustomer.destroy();
			this.CreateCustomer = null;
		},
		onUpdateC: function(oEvent) {
			var that = this;
			var sServiceURL = "/sap/opu/odata/sap/ZDLR_OTC_RDR_SRV/";
			// var sServiceURL = "/sap/opu/odata/sap/ZVMS_VEHICLE_F4_CDS/";
			var sModel = new sap.ui.model.odata.ODataModel(sServiceURL);
			var oEntry = {};
			oEntry.VHCLE = that.getModel("objectView").getData().VehiNum;
			oEntry.RTLDATE = that.getModel("objectView").getData().CustoemrD;
			
			var cust = that.getModel("objectView").getData().Customer;
			var customer = cust.split("-");
			oEntry.ENDCU = customer[0];
			sModel.create("/VehicleSet", oEntry, {
				method: "POST",
				success: function(data, res) {
					var ButtonType = mobileLibrary.ButtonType;
					// shortcut for sap.m.DialogType
					var DialogType = mobileLibrary.DialogType;
					// shortcut for sap.ui.core.ValueState
					var ValueState = coreLibrary.ValueState;
					if (!that.oDefaultMessageDialog) {
						that.oDefaultMessageDialog = new Dialog({
							type: DialogType.Message,
							title: "Success",
							state: ValueState.Success,
							content: new Text({
								text: data.MESSAGE
							}),
							beginButton: new Button({
								type: ButtonType.Emphasized,
								text: "OK",
								press: function() {
									that.oDefaultMessageDialog.close();
								}.bind(that)
							})
						});
					}

					that.oDefaultMessageDialog.open();

				},

				error: function(oResponce) {
					var ButtonType = mobileLibrary.ButtonType;

					// shortcut for sap.m.DialogType
					var DialogType = mobileLibrary.DialogType;

					// shortcut for sap.ui.core.ValueState
					var ValueState = coreLibrary.ValueState;
					var msg = oResponce.response.requestUri + " " + oResponce.message + " " + oResponce.response.statusCode + " " + oResponce.response
						.statusText;
					if (!that.oDefaultMessageDialog) {
						that.oDefaultMessageDialog = new Dialog({
							type: DialogType.Message,
							title: "Error",
							state: ValueState.Error,
							content: new Text({
								text: msg
							}),
							beginButton: new Button({
								type: ButtonType.Emphasized,
								text: "OK",
								press: function() {
									that.oDefaultMessageDialog.close();
								}.bind(that)
							})
						});
					}

					that.oDefaultMessageDialog.open();
				}
			});
			// shortcut for sap.m.ButtonType

		},
		CreateCust: function(oEvent) {
			var that = this;
			var sServiceURL = "/sap/opu/odata/sap/ZDLR_OTC_RDR_SRV/";
			// var sServiceURL = "/sap/opu/odata/sap/ZVMS_VEHICLE_F4_CDS/";
			var sModel = new sap.ui.model.odata.ODataModel(sServiceURL);
			var oEntry = {};
			var proceed = "";
			oEntry.NAME1 = that.getModel("objectView").getData().FirstName;
			if (oEntry.NAME1 === "") {
				that.getModel("objectView").setProperty("/ValuestateFN", "Error");
				var proceed = "X";
			} else {
				that.getModel("objectView").setProperty("/ValuestateFN", "None");
				proceed = "";
			}
			oEntry.NAME2 = that.getModel("objectView").getData().LastName;
			if (oEntry.NAME2 === "") {
				that.getModel("objectView").setProperty("/ValuestateLN", "Error");
				proceed = "X";
			} else {
				that.getModel("objectView").setProperty("/ValuestateLN", "None");
				proceed = "";
			}
			oEntry.STREET = that.getModel("objectView").getData().Street;
			if (oEntry.STREET === "") {
				that.getModel("objectView").setProperty("/ValuestateST", "Error");
				proceed = "X";
			} else {
				that.getModel("objectView").setProperty("/ValuestateST", "None");
				proceed = "";
			}
			oEntry.CITY = that.getModel("objectView").getData().City;
			if (oEntry.CITY === "") {
				that.getModel("objectView").setProperty("/ValuestateCT", "Error");
				proceed = "X";
			} else {
				that.getModel("objectView").setProperty("/ValuestateCT", "None");
				proceed = "";
			}
			oEntry.PSTCD = that.getModel("objectView").getData().PostalCode;
			if (oEntry.PSTCD === "") {
				that.getModel("objectView").setProperty("/ValuestatePT", "Error");
				proceed = "X";
			} else {
				that.getModel("objectView").setProperty("/ValuestatePT", "None");
				proceed = "";
			}
			var cnt = that.getModel("objectView").getData().Country;
			var country = cnt.split("-");
			oEntry.COUNTRY = country[0];
			if (oEntry.COUNTRY === "") {
				that.getModel("objectView").setProperty("/ValuestateCN", "Error");
				proceed = "X";
			} else {
				that.getModel("objectView").setProperty("/ValuestateCN", "None");
				proceed = "";
			}
			if (proceed === "") {
				sModel.create("/ECustomerSet", oEntry, {
					method: "POST",
					success: function(data, res) {
						that.getModel("objectView").setProperty("/Customer", data.BPARTNER);
						var ButtonType = mobileLibrary.ButtonType;
						// shortcut for sap.m.DialogType
						var DialogType = mobileLibrary.DialogType;
						// shortcut for sap.ui.core.ValueState
						var ValueState = coreLibrary.ValueState;
						if (!that.oDefaultMessageDialog1) {
							that.oDefaultMessageDialog1 = new Dialog({
								type: DialogType.Message,
								title: "Success",
								state: ValueState.Success,
								content: new Text({
									text: data.MESSAGE
								}),
								beginButton: new Button({
									type: ButtonType.Emphasized,
									text: "OK",
									press: function() {
										that.oDefaultMessageDialog1.close();
										that.onCloseC();
									}.bind(that)
								})
							});
						}

						that.oDefaultMessageDialog1.open();

					},

					error: function(oResponce) {
						var ButtonType = mobileLibrary.ButtonType;
						// shortcut for sap.m.DialogType
						var DialogType = mobileLibrary.DialogType;

						// shortcut for sap.ui.core.ValueState
						var ValueState = coreLibrary.ValueState;
						var msg = oResponce.response.requestUri + " " + oResponce.message + " " + oResponce.response.statusCode + " " + oResponce.response
							.statusText;
						if (!that.oDefaultMessageDialog) {
							that.oDefaultMessageDialog = new Dialog({
								type: DialogType.Message,
								title: "Error",
								state: ValueState.Error,
								content: new Text({
									text: msg
								}),
								beginButton: new Button({
									type: ButtonType.Emphasized,
									text: "OK",
									press: function() {
										that.oDefaultMessageDialog.close();
									}.bind(that)
								})
							});
						}

						that.oDefaultMessageDialog.open();

					}
				});
			}
		},
		onCreate: function(oEvent) {
			var that = this;
			if (!that.CreateCustomer) {
				that.CreateCustomer = sap.ui.xmlfragment("com.fiskerincdlr_rdr_process.ZDLR_RDRPROCES.fragment.CreateCustomer", that);
				that.getView().addDependent(that.CreateCustomer);
			}
			that.CreateCustomer.open();
		},
		onWhitespaceOkPress: function(oEvent) {
			var aTokens = oEvent.getParameter("tokens");
			this._oMultiInput.setTokens(aTokens);
			this.pWhitespaceDialog.close();
			this.pWhitespaceDialog.destroy();
			this.pWhitespaceDialog = null;
		},
		onVinOkPress: function(oEvent) {
			var aTokens = oEvent.getParameter("tokens");
			this._oMultiInputVin.setTokens(aTokens);
			this.VinspaceDialog.close();
			this.VinspaceDialog.destroy();
			this.VinspaceDialog = null;
		},
		onVinCancelPress: function() {
			this.VinspaceDialog.close();
			this.VinspaceDialog.destroy();
			this.VinspaceDialog = null;
		},
		onWhitespaceCancelPress: function() {
			this.pWhitespaceDialog.close();
			this.pWhitespaceDialog.destroy();
			this.pWhitespaceDialog = null;
		},
		onBeforeRebindTable: function(oEvent) {
			var mBindingParams = oEvent.getParameter("bindingParams"),
				aSelectedItems = this._oMultiInput.getTokens();
			var aSelectedItemsVin = this._oMultiInputVin.getTokens();
			aSelectedItems.forEach(function(oSelectedItem) {
				mBindingParams.filters.push(
					// aSelectedItems.filters.push(
					new Filter(
						"VHCLE",
						FilterOperator.EQ,
						oSelectedItem.getText()
					)
				);
			});
			aSelectedItemsVin.forEach(function(oSelectedItem) {
				mBindingParams.filters.push(
					new Filter(
						"VHVIN",
						FilterOperator.EQ,
						oSelectedItem.getText()
					)
				);
			});

		},
		onFilterVinSearch: function(oEvent) {
			var sSearchQuery = this._oBasicSearchField.getValue();
			if (sSearchQuery === '') {
				sSearchQuery = sap.ui.getCore().byId("Mat").getValue();;
			}
			var aSelectionSet = oEvent.getParameter("selectionSet");
			var aFilters = aSelectionSet.reduce(function(aResult, oControl) {
				if (oControl.getValue()) {
					aResult.push(new Filter({
						path: oControl.getName(),
						operator: FilterOperator.Contains,
						value1: oControl.getValue()
					}));
				}

				return aResult;
			}, []);
			aFilters.push(new Filter({
				filters: [
					new Filter({
						path: "VHVIN",
						operator: FilterOperator.Contains,
						value1: sSearchQuery
					}),
					// new Filter({ path: "Name", operator: FilterOperator.Contains, value1: sSearchQuery }),
					// new Filter({ path: "Category", operator: FilterOperator.Contains, value1: sSearchQuery })
				],
				and: false
			}));
			this._filterTable(new Filter({
				filters: aFilters,
				and: true
			}));
		},
		onFilterBarWhitespacesSearch: function(oEvent) {
			var sSearchQuery = this._oBasicSearchField.getValue();
			if (sSearchQuery === '') {
				sSearchQuery = sap.ui.getCore().byId("Mat").getValue();;
			}
			var aSelectionSet = oEvent.getParameter("selectionSet");
			var aFilters = aSelectionSet.reduce(function(aResult, oControl) {
				if (oControl.getValue()) {
					aResult.push(new Filter({
						path: oControl.getName(),
						operator: FilterOperator.Contains,
						value1: oControl.getValue()
					}));
				}

				return aResult;
			}, []);
			aFilters.push(new Filter({
				filters: [
					new Filter({
						path: "VHCLE",
						operator: FilterOperator.Contains,
						value1: sSearchQuery
					}),
					// new Filter({ path: "Name", operator: FilterOperator.Contains, value1: sSearchQuery }),
					// new Filter({ path: "Category", operator: FilterOperator.Contains, value1: sSearchQuery })
				],
				and: false
			}));
			this._filterTable(new Filter({
				filters: aFilters,
				and: true
			}));
		},
		_filterTable: function(oFilter) {
			if (oFilter.aFilters[0].aFilters[0].sPath === "VHVIN") {
				var oValueHelpDialog = this.VinspaceDialog;
			} else {
				oValueHelpDialog = this.pWhitespaceDialog;
			}

			oValueHelpDialog.getTableAsync().then(function(oTable) {
				if (oTable.bindRows) {
					oTable.getBinding("rows").filter(oFilter);
				}

				if (oTable.bindItems) {
					oTable.getBinding("items").filter(oFilter);
				}

				oValueHelpDialog.update();
			});
		},

		/**
		 * Event handler for refresh event. Keeps filter, sort
		 * and group settings and refreshes the list binding.
		 * @public
		 */
		// onRefresh : function () {
		// 	var oTable = this.byId("table");
		// 	oTable.getBinding("items").refresh();
		// },

		/* =========================================================== */
		/* internal methods                                            */
		/* =========================================================== */

		/**
		 * Shows the selected item on the object page
		 * On phones a additional history entry is created
		 * @param {sap.m.ObjectListItem} oItem selected Item
		 * @private
		 */
		// _showObject : function (oItem) {
		// 	this.getRouter().navTo("object", {
		// 		objectId: oItem.getBindingContext().getProperty("Vhcle")
		// 	});
		// },

		/**
		 * Internal helper method to apply both filter and search state together on the list binding
		 * @param {sap.ui.model.Filter[]} aTableSearchState An array of filters for the search
		 * @private
		 */
		// _applySearch: function(aTableSearchState) {
		// 	var oTable = this.byId("table"),
		// 		oViewModel = this.getModel("worklistView");
		// 	oTable.getBinding("items").filter(aTableSearchState, "Application");
		// 	// changes the noDataText of the list in case there are no filter results
		// 	if (aTableSearchState.length !== 0) {
		// 		oViewModel.setProperty("/tableNoDataText", this.getResourceBundle().getText("worklistNoDataWithSearchText"));
		// 	}
		// }

	});
});