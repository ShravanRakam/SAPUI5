sap.ui.define(['jquery.sap.global'],
	function(jQuery) {
		"use strict";

		var DemoPersoService = {
			oData: {
				_persoSchemaVersion: "1.0",
				aColumns: [{
					id: "_IDGenColumn1",
					order: 0,
					text: "Employee Id",
					visible: true
				}, {
					id: "_IDGenColumn2",
					order: 1,
					text: "Existing Employee Name",
					visible: true
				}, {
					id: "_IDGenColumn3",
					order: 2,
					text: "Skill Set",
					visible: true
				}, {
					id: "_IDGenColumn4",
					order: 3,
					text: "Client",
					visible: true
				}, {
					id: "_IDGenColumn5",
					order: 4,
					text: "Project",
					visible: true
				}, {
					id: "_IDGenColumn6",
					order: 5,
					text: "Proposal",
					visible: true
				}, {
					id: "_IDGenColumn7",
					order: 6,
					text: "New Resource",
					visible: true
				}, {
					id: "_IDGenColumn8",
					order: 7,
					text: "Start Date",
					visible: true
				}, {
					id: "_IDGenColumn9",
					order: 8,
					text: "End Date",
					visible: true
				}, {
					id: "_IDGenColumn10",
					order: 9,
					text: "Status",
					visible: true
				}, {
					id: "_IDGenColumn11",
					order: 10,
					text: "Person Responsible",
					visible: true
				}, {
					id: "_IDGenColumn12",
					order: 11,
					text: "Comments",
					visible: true
				}]
			},
			getPersData: function () {
				var oDeferred = new jQuery.Deferred();
				if (!this._oBundle) {
					this._oBundle = this.oData;
				}
				var oBundle = this._oBundle;
				oDeferred.resolve(oBundle);
				return oDeferred.promise();
			},
			setPersData: function (oBundle) {
				var oDeferred = new jQuery.Deferred();
				this._oBundle = oBundle;
				oDeferred.resolve();
				return oDeferred.promise();
			},
			delPersData: function () {
				var oDeferred = new jQuery.Deferred();
				oDeferred.resolve();
				return oDeferred.promise();
			}

		};

		return DemoPersoService;

	}, true);