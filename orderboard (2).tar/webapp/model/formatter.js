sap.ui.define([], function() {
	"use strict";

	return {
		formatDate: function(sValue) {
			if (sValue !== null) {
				var oDateFormat = sap.ui.core.format.DateFormat.getDateInstance({
					pattern: "MM/dd/yyyy"
				});
				return oDateFormat.format(new Date(sValue));

			} else {
				return "";
			}

		}
	};

});