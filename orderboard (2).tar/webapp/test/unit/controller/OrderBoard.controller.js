/*global QUnit*/

sap.ui.define([
	"comerporderboard/orderboard/controller/OrderBoard.controller"
], function (Controller) {
	"use strict";

	QUnit.module("OrderBoard Controller");

	QUnit.test("I should test the OrderBoard controller", function (assert) {
		var oAppController = new Controller();
		oAppController.onInit();
		assert.ok(oAppController);
	});

});
