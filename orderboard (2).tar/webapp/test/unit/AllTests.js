sap.ui.define([
	"comerporderboard/orderboard/test/unit/controller/OrderBoard.controller"
], function () {
	"use strict";
});
