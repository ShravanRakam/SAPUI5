/* global QUnit */

sap.ui.require(["com/erp/orderboard/orderboard/test/integration/AllJourneys"
], function () {
	QUnit.config.autostart = false;
	QUnit.start();
});
