sap.ui.define([
    "sap/ui/core/mvc/Controller",
    "sap/ui/model/json/JSONModel",
    "../model/formatter",
    "sap/ui/model/Filter",
    "sap/ui/model/FilterOperator",
    "sap/m/MessageBox",
    "sap/ui/table/TablePersoController",
    "../model/persoService"
],
    /**
     * @param {typeof sap.ui.core.mvc.Controller} Controller
     */
    function (Controller, JSONModel, formatter, Filter, FilterOperator, MessageBox, TablePersoController, persoService) {
        "use strict";

        return Controller.extend("com.erp.orderboard.orderboard.controller.OrderBoard", {
            formatter: formatter,
            onInit: function () {
                var that = this,
                    visible = new JSONModel({
                        busyTableDialog: false,
                        createButton: false,
                        updateButton: false,
                        clientBusy: false,
                        empBusyDialog: false,
                        dialogTitle: "",
                        empDialogVisible: false,
                        ProjectDialogVisible: false,
                        selectDialogTitle: "",
                        enableCreate: true,
                        enableUpdate: false,
                        skillColorState: "None"
                    });
                that.getView().setModel(visible, "visibleModel");
                var formModel = new JSONModel({
                    Empid: "",
                    Name: "",
                    Client: "",
                    Project: "",
                    Personresponsible: "",
                    Status: "",
                    Startdate: "2023-12-19T00:00:00",
                    Enddate: "2023-12-19T00:00:00",
                    Comments: "",
                    Skillset: ""
                });
                that.getView().setModel(formModel, "formModel");
                that.statusOverview = new TablePersoController({
                    table: that.getView().byId("_IDGenTable1"),
                    persoService: persoService
                });
                that.getOrderBoardData();
            },
            onPersoButtonPressed: function () {
                var that = this;
                that.statusOverview.openDialog();
            },
            getOrderBoardData: function () {
                var that = this,
                    data,
                    oModel = that.getOwnerComponent().getModel("serviceModel"),
                    visible = that.getView().getModel("visibleModel");
                visible.setProperty("/busyTableDialog", true);
                oModel.read("/OrderboardSet", {
                    success: function (OData) {
                        data = new JSONModel(OData.results);
                        that.getView().setModel(data, "orderBoardData");
                        visible.setProperty("/busyTableDialog", false);
                    },
                    error: function (error) {
                        visible.setProperty("/busyTableDialog", false);
                        MessageBox.error(JSON.parse(error.responseText).error.message.value);
                    }
                });
            },
            onSelectedItem: function (oEvent) {
                var that = this;
                var selectedIndex = oEvent.getSource().getSelectedIndex();
                var visible = that.getView().getModel("visibleModel");
                if (selectedIndex !== -1) {
                    visible.setProperty("/enableCreate", false);
                    visible.setProperty("/enableUpdate", true);
                } else {
                    visible.setProperty("/enableCreate", true);
                    visible.setProperty("/enableUpdate", false);
                }
            },
            onPressCreateBtn: function () {
                var that = this;
                if (!that.createDialog) {
                    that.createDialog = new sap.ui.xmlfragment("com.erp.orderboard.orderboard.fragments.create", that);
                    that.getView().addDependent(that.createDialog);
                }
                that.getView().getModel("visibleModel").setProperty("/createButton", true);
                that.getView().getModel("visibleModel").setProperty("/updateButton", false);
                that.getView().getModel("visibleModel").setProperty("/dialogTitle", "Create Order Board");
                that.createDialog.open();
            },
            onCloseDialog: function () {
                var that = this,
                    dialogTitle = that.getView().getModel("visibleModel");
                var title = dialogTitle.getProperty("/dialogTitle");
                var selectDialog = dialogTitle.getProperty("/selectDialogTitle");
                if (title === "Create Order Board") {
                    that.createDialog.close();
                    that.createDialog.destroy();
                    that.createDialog = null;
                    that.getView().getModel("formModel").setData([]);
                } else if (title === "Update Order Board") {
                    that.updateDialog.close();
                    that.updateDialog.destroy();
                    that.updateDialog = null;
                }
                else if (selectDialog === "Project Details") {
                    that.updateDialog.close();
                    that.updateDialog.destroy();
                    that.updateDialog = null;
                }
            },
            onPressCreateData: function (oEvent) {
                var that = this,
                    mFilters = [],
                    event = oEvent.getSource(),
                    formData = that.getView().getModel("formModel").getData(),
                    oModel = that.getOwnerComponent().getModel("serviceModel");
                oModel.create("/OrderboardSet", formData, {
                    success: function () {
                        that.getOrderBoardData();
                        that.onCloseCreateDialog();
                        MessageBox.success("Record Created Successfuly");
                    },
                    error: function (err) {
                        MessageBox.error(JSON.parse(err.responseText).error.message.value);
                    }
                });
            },
            onPressUpdateBtn: function (oEvent) {
                var that = this,
                    getSelectedIndex = oEvent.getSource().getParent().getParent().getSelectedIndex(),
                    rowData = that.getView().getModel("orderBoardData").getProperty("/" + getSelectedIndex),
                    data = {},
                    formData;
                if (getSelectedIndex !== -1) {
                    if (!that.updateDialog) {
                        that.updateDialog = new sap.ui.xmlfragment("com.erp.orderboard.orderboard.fragments.create", that);
                        that.getView().addDependent(that.updateDialog);
                    }
                    that.getView().getModel("visibleModel").setProperty("/updateButton", true);
                    that.getView().getModel("visibleModel").setProperty("/createButton", false);
                    that.getView().getModel("visibleModel").setProperty("/dialogTitle", "Update Order Board");
                    data.Empid = rowData.Empid;
                    data.Name = rowData.Name;
                    data.Client = rowData.Client;
                    data.Project = rowData.Project;
                    data.Personresponsible = rowData.Personresponsible;
                    data.Startdate = rowData.Startdate;
                    data.Enddate = rowData.Enddate;
                    data.Comments = rowData.Comments;
                    that.getView().getModel("formModel").setData(data);
                    that.updateDialog.open();
                }
                else {
                    MessageBox.warning("Please Select an Line Item..!")
                }
            },
            onPressUpdateData: function (oEvent) {
                var that = this,
                    oModel = that.getOwnerComponent().getModel("serviceModel"),
                    updateData = that.getView().getModel("formModel").getData(),
                    dialog = new sap.m.BusyDialog({
                        text: "Updating record please wait..."
                    });
                var entitySet = "/OrderboardSet";
                dialog.open();
                oModel.update(entitySet + "(Empid='" + updateData.Empid + "',Client=''," + "Project='')",
                    updateData, {
                    success: function () {
                        dialog.close();
                        MessageBox.confirm("Are you sure, want to update data?", {
                            actions: [MessageBox.Action.OK, MessageBox.Action.CANCEL],
                            emphasizedAction: MessageBox.Action.OK,
                            onClose: function (sAction) {
                                if (sAction === "OK") {
                                    that.onCloseCreateDialog();
                                    MessageBox.success("Record Updated Successfully");
                                    that.getOrderBoardData();
                                }
                            }
                        });
                    },
                    error: function (error) {
                        dialog.close();
                        that.onCloseCreateDialog();
                        MessageBox.error(JSON.parse(error.responseText).error.message.value);
                    }
                });
            },
            onPressF4Help: function (oEvent) {
                var that = this,
                    getButtonName = oEvent.getSource().getName();
                if (getButtonName === "empName") {
                    if (!that.f4Dialog) {
                        that.f4Dialog = new sap.ui.xmlfragment("com.erp.orderboard.orderboard.fragments.emp", that);
                        that.getView().addDependent(that.f4Dialog);
                    }
                    that.getView().getModel("visibleModel").setProperty("/selectDialogTitle", "Employee Details");
                    that.getView().getModel("visibleModel").setProperty("/empDialogVisible", true);
                    that.getView().getModel("visibleModel").setProperty("/ProjectDialogVisible", false);
                    that.getEmpMasterData();
                    that.f4Dialog.open();
                } else {
                    if (!that.f4Dialog) {
                        that.f4Dialog = new sap.ui.xmlfragment("com.erp.orderboard.orderboard.fragments.valueHelpDialog", that);
                        that.getView().addDependent(that.f4Dialog);
                    }
                    that.getView().getModel("visibleModel").setProperty("/selectDialogTitle", "Project Details");
                    that.getView().getModel("visibleModel").setProperty("/empDialogVisible", false);
                    that.getView().getModel("visibleModel").setProperty("/ProjectDialogVisible", true);
                    that.getProjectDetails();
                    that.f4Dialog.open();
                }

            },
            getProjectDetails: function () {
                var that = this,
                    projectDetails,
                    oModel = that.getOwnerComponent().getModel("serviceModel"),
                    visible = that.getView().getModel("visibleModel");
                visible.setProperty("/clientBusy", true);
                oModel.read("/projectDetailsSet", {
                    success: function (OData) {
                        projectDetails = new JSONModel(OData.results);
                        projectDetails.setSizeLimit(OData.results.length);
                        that.getView().setModel(projectDetails, "projectData");
                        visible.setProperty("/clientBusy", false);
                    },
                    error: function (error) {
                        visible.setProperty("/clientBusy", false);
                        MessageBox.error(JSON.parse(error.responseText).error.message.value);
                    }
                });
            },
            onSelectProject: function (oEvent) {
                var that = this,
                empDetails,
                projectDetails,
                title = oEvent.getSource().getTitle(),
                formData = that.getView().getModel("formModel");
                if (title === "Employee Details") {
                    empDetails = oEvent.getParameters("listItems").selectedItem.getBindingContext("empDetails").getObject(),
                        formData.setProperty("/Empid", empDetails.Empid);
                    formData.setProperty("/Empname", empDetails.Empname);
                } else {
                    projectDetails = oEvent.getParameters("listItems").selectedItem.getBindingContext("projectData").getObject();
                    formData.setProperty("/Client", projectDetails.Client);
                formData.setProperty("/Project", projectDetails.Projectdesc);
                }               
            },
            onLoadStatus: function () {
                var that = this;
                var status = new JSONModel(jQuery.sap.getModulePath("com.erp.orderboard.orderboard.", "/model/status.json"));
                that.getView().setModel(status, "statusModel")
            },
            onSearchList: function (oEvent) {
                var that = this;
                var sQuery = oEvent.getParameter("query");
                if (!sQuery) {
                    sQuery = oEvent.getParameter("newValue");
                }
                var filter1 = new Filter("Client", FilterOperator.Contains, sQuery);
                var filter2 = new Filter("Projectdesc", FilterOperator.Contains, sQuery);
                var filterData = [filter1, filter2];
                var oNewFilter = new Filter({
                    filters: filterData,
                    and: false
                });
                var oTab = that.getView().byId("idStndrdListItem");
                var oBinding = oTab.getBinding("items");
                oBinding.filter(oNewFilter);
            },
            onGoPress: function (oEvent) {
                var that = this;

                var ofilter = [];

                var selectedEmpId = oEvent.getSource().getModel("formModel").getProperty("/Empid");
                if (selectedEmpId) {
                    ofilter.push(new Filter("Empid", FilterOperator.Contains, selectedEmpId));
                }
                var selectedClient = oEvent.getSource().getModel("formModel").getProperty("/Client");
                if (selectedClient) {
                    ofilter.push(new Filter("Cleint", FilterOperator.Contains, selectedClient));
                }
                var selectedProject = oEvent.getSource().getModel("formModel").getProperty("/Project");
                if (selectedProject) {
                    ofilter.push(new Filter("Projectdesc", FilterOperator.Contains, selectedProject));
                }
                var selectedStatus = oEvent.getSource().getModel("formModel").getProperty("/Status");
                if (selectedStatus) {
                    ofilter.push(new Filter("Status", FilterOperator.Contains, selectedStatus));
                }
                var oNewFilter = new Filter({
                    filters: ofilter,
                    and: false
                });
                var oTab = that.getView().byId("_IDGenTable1");
                var oBinding = oTab.getBinding("rows");
                oBinding.filter(oNewFilter);
            },
            onResetFB: function () {
                var that = this,
                    formModel = that.getView().getModel("formModel");
                formModel.setProperty("/Client", "");
                formModel.setProperty("/Project", "");
                formModel.setProperty("/Empname", "");
                formModel.setProperty("/Status  ", "");
                that.getOrderBoardData();
            },
            getEmpMasterData: function () {
                var that = this,
                    empDetails,
                    oModel = that.getOwnerComponent().getModel("serviceModel"),
                    visible = that.getView().getModel("visibleModel");
                visible.setProperty("/empBusyDialog", true);
                oModel.read("/EmpMasterDataSet", {
                    success: function (OData) {
                        empDetails = new JSONModel(OData.results);
                        empDetails.setSizeLimit(OData.results.length);
                        that.getView().setModel(empDetails, "empDetails");
                        visible.setProperty("/empBusyDialog", false);
                    },
                    error: function (error) {
                        visible.setProperty("/empBusyDialog", false);
                        MessageBox.error(JSON.parse(error.responseText).error.message.value);
                    }
                });
            },
            onCheckMaxLength: function(oEvent){
                var that = this,
                event = oEvent.getSource(),
                getLenth = event.getValue().length,
                getMaxLength = 250;
                if(getLenth < getMaxLength){
                    that.getView().getModel("visibleModel").setProperty("/skillColorState", "None");
                }
                else{
                    that.getView().getModel("visibleModel").setProperty("/skillColorState", "Warning");
                }
            }
        });
    });
