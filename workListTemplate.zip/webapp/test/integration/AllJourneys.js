/*global QUnit*/

jQuery.sap.require("sap.ui.qunit.qunit-css");
jQuery.sap.require("sap.ui.thirdparty.qunit");
jQuery.sap.require("sap.ui.qunit.qunit-junit");
QUnit.config.autostart = false;

sap.ui.require([
	"sap/ui/test/Opa5",
	"com/workListTemplate/workListTemplate/test/integration/pages/Common",
	"sap/ui/test/opaQunit",
	"com/workListTemplate/workListTemplate/test/integration/pages/Worklist",
	"com/workListTemplate/workListTemplate/test/integration/pages/Object",
	"com/workListTemplate/workListTemplate/test/integration/pages/NotFound",
	"com/workListTemplate/workListTemplate/test/integration/pages/Browser",
	"com/workListTemplate/workListTemplate/test/integration/pages/App"
], function (Opa5, Common) {
	"use strict";
	Opa5.extendConfig({
		arrangements: new Common(),
		viewNamespace: "com.workListTemplate.workListTemplate.view."
	});

	sap.ui.require([
		"com/workListTemplate/workListTemplate/test/integration/WorklistJourney",
		"com/workListTemplate/workListTemplate/test/integration/ObjectJourney",
		"com/workListTemplate/workListTemplate/test/integration/NavigationJourney",
		"com/workListTemplate/workListTemplate/test/integration/NotFoundJourney",
		"com/workListTemplate/workListTemplate/test/integration/FLPIntegrationJourney"
	], function () {
		QUnit.start();
	});
});