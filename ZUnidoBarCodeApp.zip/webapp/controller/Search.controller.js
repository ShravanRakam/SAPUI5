sap.ui.define([
	"sap/ui/core/mvc/Controller",
	"sap/m/MessageBox",
	"sap/ndc/BarcodeScanner",
	"sap/ui/model/json/JSONModel",
	"sap/ui/model/Filter",
	"sap/ui/model/FilterOperator"
], function(Controller, MessageBox, BarcodeScanner, JSONModel, Filter, FilterOperator) {
	"use strict";

	return Controller.extend("Navigation1.controller.Search", {
		onInit: function() {
			var data = {
				results: [{
					ItemNo: "10",
					EmpName: "1000",
					PosDesc: "Signal Maintainer",
					Qyt: "2.00",
					Unit: "PC",
					DeliveredQty: "2.00",
					UnitPrice: "300.00",
				}, {
					ItemNo: "20",
					EmpName: "1001",
					PosId: "30001028",
					PosDesc: "B&B Mechanic",
					Qyt: "3.00",
					Unit: "PC",
					DeliveredQty: "2.00",
					UnitPrice: "300.00"
				}, {
					ItemNo: "30",
					EmpName: "1002",
					PosId: "30000747",
					PosDesc: "B&B Apprentice",
					Qyt: "2.00",
					Unit: "PC",
					DeliveredQty: "2.00",
					UnitPrice: "800.00"

				}, {
					ItemNo: "40",
					EmpName: "1003",
					PosId: "30016895",
					PosDesc: "CARAMAN",
					Qyt: "1.00",
					Unit: "PC",
					DeliveredQty: "1.00",
					UnitPrice: "500.00"
				}, {
					ItemNo: "50",
					EmpName: "1004",
					PosId: "30000125",
					PosDesc: "Signal Maintainer",
					Qyt: "4.00",
					Unit: "PC",
					DeliveredQty: "2.00",
					UnitPrice: "400.00"
				}, {
					ItemNo: "60",
					EmpName: "1005",
					PosId: "30001028",
					PosDesc: "B&B Mechanic",
					Qyt: "1.00",
					Unit: "PC",
					DeliveredQty: "1.00",
					UnitPrice: "400.00"
				}]
			};
			var model = new JSONModel(data);
			this.getView().setModel(model, "barcodes");

			var viewModel = new JSONModel({
				PoNumber: ""
			});
			this.getView().setModel(viewModel, "viewModel");
		},

		onNavBack: function() {
			// history.go(-1);
			var route = sap.ui.core.UIComponent.getRouterFor(this);
			route.navTo("Navigation1");
		},
		onPress: function() {
			var that = this;
			var route = sap.ui.core.UIComponent.getRouterFor(this);
			// var pono = that.getView().getModel("viewModel").getData().PoNumber;

			route.navTo("page2");
			// that.getRouter().navTo("page2", {
			// objectId: pono
			// });
		},

		onItempress: function(oEvent) {
			var that = this;
			var route = sap.ui.core.UIComponent.getRouterFor(this);
			// var pono = that.getView().getModel("viewModel").getData().PoNumber;
			var obj = oEvent.getSource().getBindingContext("barcodes").getObject();
			route.navTo("page2");
			// that.getRouter().navTo("page2", {
			// objectId: pono
			// });

		}

	});
});