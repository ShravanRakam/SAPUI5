sap.ui.define([
	"sap/ui/core/mvc/Controller",
	"sap/m/MessageBox",
	"sap/ndc/BarcodeScanner",
	"sap/ui/model/json/JSONModel",
	"sap/ui/model/Filter",
	"sap/ui/model/FilterOperator"
], function(Controller, MessageBox, BarcodeScanner, JSONModel, Filter, FilterOperator) {
	"use strict";

	return Controller.extend("Navigation1.controller.page2", {
		onInit: function() {
			var that = this;
			var oViewModel = new JSONModel({
				qtyValue: false,
				postButton: false
			});

			that.getView().setModel(oViewModel, "viewModel");

			var data = {
				results: [{
					ItemNo: "10",
					EmpName: "1000",
					PosDesc: "Signal Maintainer",
					Qyt: "2.00",
					Unit: "PC",
					DeliveredQty: "2.00",
					UnitPrice: "300.00",
					oFlag: false
				}, {
					ItemNo: "20",
					EmpName: "1001",
					PosId: "30001028",
					PosDesc: "B&B Mechanic",
					Qyt: "3.00",
					Unit: "PC",
					DeliveredQty: "2.00",
					UnitPrice: "300.00",
					oFlag: false
				}, {
					ItemNo: "30",
					EmpName: "1002",
					PosId: "30000747",
					PosDesc: "B&B Apprentice",
					Qyt: "2.00",
					Unit: "PC",
					DeliveredQty: "2.00",
					UnitPrice: "800.00",
					oFlag: false

				}, {
					ItemNo: "40",
					EmpName: "1003",
					PosId: "30016895",
					PosDesc: "CARAMAN",
					Qyt: "1.00",
					Unit: "PC",
					DeliveredQty: "1.00",
					UnitPrice: "500.00",
					oFlag: false
				}, {
					ItemNo: "50",
					EmpName: "1004",
					PosId: "30000125",
					PosDesc: "Signal Maintainer",
					Qyt: "4.00",
					Unit: "PC",
					DeliveredQty: "2.00",
					UnitPrice: "400.00",
					oFlag: false
				}, {
					ItemNo: "60",
					EmpName: "1005",
					PosId: "30001028",
					PosDesc: "B&B Mechanic",
					Qyt: "1.00",
					Unit: "PC",
					DeliveredQty: "1.00",
					UnitPrice: "400.00",
					oFlag: false
				},{
					ItemNo: "70",
					EmpName: "1006",
					PosId: "30001029",
					PosDesc: "BB Mechanic",
					Qyt: "4.00",
					Unit: "PC",
					DeliveredQty: "1.00",
					UnitPrice: "400.00",
					oFlag: false
				},{
					ItemNo: "80",
					EmpName: "1007",
					PosId: "30001030",
					PosDesc: "BB8 Mechanic",
					Qyt: "3.00",
					Unit: "PC",
					DeliveredQty: "1.00",
					UnitPrice: "400.00",
					oFlag: false
				},{
					ItemNo: "90",
					EmpName: "1008",
					PosId: "30001031",
					PosDesc: "BB9 Mechanic",
					Qyt: "6.00",
					Unit: "PC",
					DeliveredQty: "1.00",
					UnitPrice: "400.00",
					oFlag: false
				},{
					ItemNo: "100",
					EmpName: "1009",
					PosId: "30001032",
					PosDesc: "BB9 Mechanic",
					Qyt: "8.00",
					Unit: "PC",
					DeliveredQty: "1.00",
					UnitPrice: "400.00",
					oFlag: false
				},{
					ItemNo: "110",
					EmpName: "10010",
					PosId: "30001033",
					PosDesc: "BB10 Mechanic",
					Qyt: "4.00",
					Unit: "PC",
					DeliveredQty: "1.00",
					UnitPrice: "400.00",
					oFlag: false
				}]
			};
			var model = new JSONModel(data);
			this.getView().setModel(model, "barcodes");
		},
		onNavBack: function() {
			// history.go(-1);
			var route = sap.ui.core.UIComponent.getRouterFor(this);
			route.navTo("Navigation1");
		},
		onBackPress: function() {
			var route = sap.ui.core.UIComponent.getRouterFor(this);
			route.navTo("search");
		},

		_filter: function() {
			var oFilter = null;

			if (this._oGlobalFilter && this._oPriceFilter) {
				oFilter = new sap.ui.model.Filter([this._oGlobalFilter, this._oPriceFilter], true);
			} else if (this._oGlobalFilter) {
				oFilter = this._oGlobalFilter;
			} else if (this._oPriceFilter) {
				oFilter = this._oPriceFilter;
			}

			this.getView().byId("table").getBinding("rows").filter(oFilter, "Application");
		},

		filterGlobally: function(oEvent) {
			var sQuery = oEvent.getSource().getValue();
			this._oGlobalFilter = null;

			if (sQuery) {
				this._oGlobalFilter = new Filter([
					new Filter("ItemNo", FilterOperator.Contains, sQuery),
					new Filter("PosDesc", FilterOperator.Contains, sQuery)
				], false);
			}
			var items = this.getView().byId("itemsId").getBinding("items");
			items.filter(this._oGlobalFilter);
			// this._filter();
		},

		clearAllFilters: function(oEvent) {
			var oTable = this.getView().byId("itemsId");

			var oUiModel = this.getView().getModel("ui");
			oUiModel.setProperty("/globalFilter", "");
			oUiModel.setProperty(
				"/availabilityFilterOn", false);

			this._oGlobalFilter = null;
			this._oPriceFilter = null;
			this._filter();

			var aColumns = oTable.getColumns();
			for (var i = 0; i < aColumns.length; i++) {
				oTable.filter(aColumns[i], null);
			}
		},
		QuantityChng: function(oEvent) {
			var that = this;

			if (oEvent.getParameters().selected === true) {
				oEvent.getParameters().listItems.forEach(function(item) {
					var oContext = item.getBindingContext("barcodes");
					var path = oContext.getPath();
					var obj = oContext.getObject();
					obj.oFlag = true;
					that.getView().getModel("barcodes").setProperty(path, obj, oContext, true);
					// that.getView().getModel("viewModel").setProperty("/postButton", true);
				});
			} else {
				oEvent.getParameters().listItems.forEach(function(item) {
					var oContext = item.getBindingContext("barcodes");
					var path = oContext.getPath();
					var obj = oContext.getObject();
					obj.oFlag = false;
					that.getView().getModel("barcodes").setProperty(path, obj, oContext, true);
					that.getView().getModel("viewModel").setProperty("/postButton", false);
				});
			}
			if (oEvent.getSource().getSelectedItems().length === this.getView().byId("itemsId").getItems().length) {
				that.getView().getModel("viewModel").setProperty("/postButton", true);
			} else {
				that.getView().getModel("viewModel").setProperty("/postButton", false);
			}

		},
		
		onPostPress:function()
		{
			var crfmsg = "Do you want to post the Purchase order details?";
				
				sap.m.MessageBox.information(crfmsg, {
                                icon: sap.m.MessageBox.Icon.INFORMATION,
                                title: "Information",
                                actions: ["OK","Cancel"],
                                onClose: function (oAction) {
                                    if (oAction === "OK") {
                                    		MessageBox.success("Purchase order details are posted successfully");
                                    }
                                }
                            });
		}

	});
});