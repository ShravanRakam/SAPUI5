sap.ui.define([
	"sap/ui/core/mvc/Controller",
	"sap/ui/model/json/JSONModel"
], function(Controller, JSONModel) {
	"use strict";
	return Controller.extend("RoutingparameterRoutingparameter.controller.customers", {
		onInit: function() {
			var that = this;
			var dataModel = this.getOwnerComponent().getModel("northwindModel");
			that.getView().setModel(dataModel, "northwind");
			// var sUrl = "/Northwind/V2/Northwind/Northwind.svc/";
			// var oModel = new sap.ui.model.odata.ODataModel(sUrl, true);
			// that.getView().setModel(oModel, "nortWindModel"); // local to the View
			// var eData = that.getView().getModel("nortWindModel");
			dataModel.read("/Customers", {
				success: function(oData, res) {
					if (res.statusCode === "200" || res.statusCode === 200) {
						var customModel = new JSONModel(oData.results);
						that.getView().setModel(customModel, "dataModel");
						var data = that.getView().getModel("dataModel").getData().results;
						console.log(data);
					}
				},
				error: function(err) {
					// console.log(err);
				}
			});
		},
		onpress: function(oEvent) {
			var oItem = oEvent.getSource();
			var oRouter = this.getOwnerComponent().getRouter();
			oRouter.navTo("Orderdetails", {
			Customers: oItem.getBindingContext("dataModel").getObject().CustomerID
					// Orders: oItem.getBindingContext("NewModel").getObject().CustomerID
			});
		}

	});
});