/*global QUnit*/

jQuery.sap.require("sap.ui.qunit.qunit-css");
jQuery.sap.require("sap.ui.thirdparty.qunit");
jQuery.sap.require("sap.ui.qunit.qunit-junit");
QUnit.config.autostart = false;

sap.ui.require([
	"sap/ui/test/Opa5",
	"com/shipment/ZPTP_SHIPMENTS/test/integration/pages/Common",
	"sap/ui/test/opaQunit",
	"com/shipment/ZPTP_SHIPMENTS/test/integration/pages/Worklist",
	"com/shipment/ZPTP_SHIPMENTS/test/integration/pages/Object",
	"com/shipment/ZPTP_SHIPMENTS/test/integration/pages/NotFound",
	"com/shipment/ZPTP_SHIPMENTS/test/integration/pages/Browser",
	"com/shipment/ZPTP_SHIPMENTS/test/integration/pages/App"
], function (Opa5, Common) {
	"use strict";
	Opa5.extendConfig({
		arrangements: new Common(),
		viewNamespace: "com.shipment.ZPTP_SHIPMENTS.view."
	});

	sap.ui.require([
		"com/shipment/ZPTP_SHIPMENTS/test/integration/WorklistJourney",
		"com/shipment/ZPTP_SHIPMENTS/test/integration/ObjectJourney",
		"com/shipment/ZPTP_SHIPMENTS/test/integration/NavigationJourney",
		"com/shipment/ZPTP_SHIPMENTS/test/integration/NotFoundJourney",
		"com/shipment/ZPTP_SHIPMENTS/test/integration/FLPIntegrationJourney"
	], function () {
		QUnit.start();
	});
});