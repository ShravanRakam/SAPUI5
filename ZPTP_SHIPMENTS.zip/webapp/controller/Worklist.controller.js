/*global location history */
sap.ui.define([
	"com/shipment/ZPTP_SHIPMENTS/controller/BaseController",
	"sap/ui/model/json/JSONModel",
	"sap/ui/core/routing/History",
	"com/shipment/ZPTP_SHIPMENTS/model/formatter",
	"sap/ui/model/Filter",
	"sap/ui/model/FilterOperator",
	"sap/m/MessageBox",
	"sap/ui/export/library",
	"sap/ui/export/Spreadsheet",
	"sap/m/TablePersoController",
	"../model/PersoService"
], function(BaseController, JSONModel, History, formatter, Filter, FilterOperator, MessageBox, exportLibrary, Spreadsheet,
	TablePersoController, PersoService) {
	"use strict";
	var EdmType = exportLibrary.EdmType;
	return BaseController.extend("com.shipment.ZPTP_SHIPMENTS.controller.Worklist", {
			formatter: formatter,
			/* =========================================================== */
			/* lifecycle methods                                           */
			/* =========================================================== */

			/**
			 * Called when the worklist controller is instantiated.
			 * @public
			 */
			onInit: function() {
				var that = this;
				var sObj = {
					"shipPointValue": "",
					"shipToValue": "",
					"routeVal": "",
					"delveryNumberValue": "",
					"createdOnValue": ""
				};
				var oModel = new JSONModel(sObj);
				that.getView().setModel(oModel, "intialModel");
				that._oTPC = new TablePersoController({
					table: that.getView().byId("idTable"),
					componentName: "Demo",
					persoService: PersoService
				}).activate();
			},
			onPersoButtonPressed: function(oEvent) {
				var that = this;
				that._oTPC.openDialog();
			},
			onUpdateTable: function(oEvent) {
				var that = this;
				var oTable = that.getView().byId("idTable"),
					getItems = oTable.getItems();
				for (var i = 0; i < getItems.length; i++) {
					if (getItems[i].getBindingContext("orderDetails").getObject().TKNUM === "") {
						getItems[i].getMultiSelectControl(true).setEnabled(false);
					}
				}
			},
			onSelectCheckBox: function() {
				var that = this;
				var oTable = that.getView().byId("idTable"),
					getItems = oTable.getItems();
				for (var i = 0; i < getItems.length; i++) {
					var enableItems = getItems[i].getMultiSelectControl(true).getEnabled(true);
					if (enableItems === false) {
						getItems[i].setSelected(false);
					}
				}
			},
			onPressFilterData: function(oEvent) {
				var that = this,
					sModel;
				var sfilters = [];
				that.busyDialog = new sap.m.BusyDialog({
					text: "Data loading please wait..."
				});
				// oVal = oEvent.getSource().getValue();
				var shipPointValue = that.getView().getModel("intialModel").getData().shipPointValue;
				var shipToValue = that.getView().getModel("intialModel").getData().shipToValue;
				var routeVal = that.getView().getModel("intialModel").getData().routeVal;
				var delveryNumberValue = that.getView().getModel("intialModel").getData().delveryNumberValue;
				var createdOnValue = that.getView().getModel("intialModel").getData().createdOnValue;
				if (shipPointValue === "") {
					MessageBox.error("Please enter Ship point");
					return;
				} else if (shipToValue === "") {
					MessageBox.error("Please enter Ship To");
					return;
				} else if (routeVal === "") {
					MessageBox.error("Please enter Route Value");
					return;
				}
				sfilters.push(new sap.ui.model.Filter("Vstel", sap.ui.model.FilterOperator.EQ, shipPointValue));
				sfilters.push(new sap.ui.model.Filter("Kunnr", sap.ui.model.FilterOperator.EQ, shipToValue));
				sfilters.push(new sap.ui.model.Filter("Route", sap.ui.model.FilterOperator.EQ, routeVal));
				// sfilters.push(new sap.ui.model.Filter("Vbeln", sap.ui.model.FilterOperator.EQ, delveryNumberValue));
				// sfilters.push(new sap.ui.model.Filter("Erdat", sap.ui.model.FilterOperator.EQ, createdOnValue));
				sModel = that.getOwnerComponent().getModel();
				sModel.setUseBatch(false);
				that.busyDialog.open();
				sModel.read("/DeliveriesSet", {
					filters: sfilters,
					success: function(oData) {
						that.busyDialog.close();
						var oModel = new JSONModel();
						if (oData.results.length > 0) {
							oModel.setData(oData);
							oModel.setSizeLimit(100000);
						} else {
							oModel.setData({
								results: []
							});
						}
						that.getView().setModel(oModel, "oTableModelData");
					},
					error: function(err) {
						that.busyDialog.close();
						// var oMessage = JSON.parse(err.response.body).find('message').first().text();
						var oMessage = "Issue With the bad data";
						MessageBox.error(oMessage, {
							icon: sap.m.MessageBox.Icon.ERROR,
							title: "Error"
						});
					}
				});
			},
			/*Create Shipemnt---START*/
			onCreateShipment: function(oEvent) {
				var that = this,
					sModel;
				var oArray = [];
				that.oDialog = new sap.m.BusyDialog({
					text: "please wait Shipment creating inprogress..."
				});
				// var oModelData = that.getView().getModel("oTableModelData").getData();
				var selectedItems = oEvent.getSource().getParent().getParent().getSelectedItems();
				if (selectedItems.length > 0) {
					selectedItems.forEach(function(item) {
						var oModelData = item.getBindingContext("oTableModelData").getObject();
						oArray.push(oModelData);
					});
					var oEntry = {};
					oEntry.Tknum = oArray[0].Tknum;
					oEntry.ShipmentSet = oArray;
					sModel = that.getOwnerComponent().getModel();
					sModel.create("/DeliveriesSet", oEntry, {
						success: function() {
							that.oDialog.close();
						},
						error: function(err) {
							MessageBox.error(err);
							that.oDialog.close();
						}
					});
				} else {
					MessageBox.error("Please select atleast one line item");
				}
			},
			/*Create Shipemnt---END*/
			/*Export Table data---START*/
			createColumnConfig: function() {
				var aCols = [];
				aCols.push({
					label: 'Shipping Point',
					property: "Vstel",
					type: EdmType.String
				});
				aCols.push({
					label: 'Ship to Party',
					property: "Kunnr",
					type: EdmType.String
				});
				aCols.push({
					label: 'Route',
					property: 'Route',
					type: EdmType.String
				});
				aCols.push({
					label: 'Receiving Plant',
					property: 'Werks',
					type: EdmType.String
				});
				aCols.push({
					label: 'Delivery No.',
					property: 'Vbeln',
					type: EdmType.Date
				});
				aCols.push({
					label: 'Shipment No.',
					property: 'Tknum',
					type: EdmType.String
				});
				aCols.push({
					label: 'Created on',
					property: 'Erdat',
					type: EdmType.String
				});
				aCols.push({
					label: 'PGI Date',
					property: 'WadatIst',
					type: EdmType.String
				});
				aCols.push({
					label: 'External Delivery No.',
					property: 'Lifex',
					type: EdmType.string
				});
				aCols.push({
					label: 'Net Weight',
					property: 'Ntgew',
					type: EdmType.strin
				});
				aCols.push({
					label: 'Gross Weight',
					property: 'Btgew',
					type: EdmType.string
				});
				aCols.push({
					label: 'Material',
					property: 'Matnr',
					type: EdmType.string
				});
				aCols.push({
					label: 'Material Desc',
					property: 'Arktx',
					type: EdmType.string
				});
				aCols.push({
					label: 'Delivery Quantity',
					property: 'Lfimg',
					type: EdmType.string
				});
				aCols.push({
					label: 'Unit of Measure',
					property: 'Vrkme',
					type: EdmType.string
				});
				aCols.push({
					label: 'Ref Doc',
					property: 'Vgbel',
					type: EdmType.string
				});
				return aCols;
			},
			onPressExport: function() {
				var that = this;
				var aCols, oRowBinding, oSettings, oSheet;
				if (that.getView().getModel("oTableModelData") !== undefined) {
					oRowBinding = that.getView().getModel("oTableModelData").getData();
					aCols = that.createColumnConfig();
					oSettings = {
						workbook: {
							columns: aCols,
							hierarchyLevel: 'Level'
						},
						dataSource: oRowBinding,
						fileName: 'Shipment data.xlsx',
						worker: false // We need to disable worker because we are using a MockServer as OData Service
					};
					oSheet = new Spreadsheet(oSettings);
					oSheet.build().finally(function() {
						oSheet.destroy();
					});
				} else {
					MessageBox.error("No Table data...");
				}
			},
			/*Export Table data---END*/
			onCrossAppShipment: function(oEvent) {
				var buttonText = oEvent.getSource().getText();
				var selectedItem = oEvent.getSource().getParent().getParent().getSelectedItems();
				if (buttonText === "Display Shipment") {
					if (selectedItem.length === 1) {
						var oCrossAppNavigatorDisplay = sap.ushell.Container.getService("CrossApplicationNavigation");
						var hashDisplay = oCrossAppNavigatorDisplay.hrefForExternal({
							target: {
								semanticObject: "Shipment",
								action: "display"
							}, //App that you're navigating to
							params: {
								"ShipmentNo": selectedItem[0].TKNUM
							}
						});
						var urlDisplay = window.location.href.split('#')[0] + hashDisplay;
						sap.m.URLHelper.redirect(urlDisplay, true);
				} else if (selectedItem.length > 1) {
					MessageBox.error("Please only one lineItem to Display Shipment");
				} else {
					MessageBox.error("Please select an lineItem to Display Shipment");
				}
			}
			else if (buttonText === "Change Shipment") {
				if (selectedItem.length === 1) {
					var oCrossAppNavigatorChange = sap.ushell.Container.getService("CrossApplicationNavigation");
					var hashChange = oCrossAppNavigatorChange.hrefForExternal({

						target: {
							semanticObject: "Shipment",
							action: "change"
						},
						params: {
							"ShipmentNo": selectedItem[0].TKNUM
						}
					});
						var urlChange = window.location.href.split('#')[0] + hashChange;
						sap.m.URLHelper.redirect(urlChange, true);
				
				} else if (selectedItem.length > 1) {
					MessageBox.error("Please only one lineItem to Display Shipment");
				} else {
					MessageBox.error("Please select an lineItem to Display Shipment");
				}
			}
		}

	});
});