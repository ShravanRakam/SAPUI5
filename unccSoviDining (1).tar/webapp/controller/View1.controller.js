sap.ui.define([
	"sap/ui/core/mvc/Controller",
	"sap/ui/model/json/JSONModel"
], function(Controller, JSONModel) {
	"use strict";

	return Controller.extend("com.unccSoviDiningunccSoviDining.controller.View1", {
		onInit: function() {
			var that = this;
			var oModel = new JSONModel("model/sample.json");
			that.getView().setModel(oModel, "dataModel");
			var graph = new sap.ui.model.json.JSONModel("model/graphModel.json");
			
			var oVizFrame = that.getView().byId("idVizFrame1");
			oVizFrame.setModel(graph);
			
				
			var oVizFrame1 = that.getView().byId("idVizFrameRev2");
			oVizFrame1.setModel(graph);
			
			var oVizFrame2 = that.getView().byId("idVizFrame2");
			oVizFrame2.setModel(graph);
			
			var oVizframe3 = that.getView().byId("idVizFrameProd");
			oVizframe3.setModel(graph);
			
			var oVizFrame4 = that.getView().byId("idVizFrame3");
			oVizFrame4.setModel(graph);
			
			var oVizFrame5 = that.getView().byId("idVizFrame");
			oVizFrame5.setModel(graph);
		},
		onClick: function(oEvent) {
			var that = this;
			var sObject = oEvent.getSource().getBindingContext("dataModel").getPath();
			var sIndex = sObject.split("/")[2];
			var oRouter = sap.ui.core.UIComponent.getRouterFor(this);

			oRouter.navTo("View2", {
				"object": sIndex
			});
		}
	});
});