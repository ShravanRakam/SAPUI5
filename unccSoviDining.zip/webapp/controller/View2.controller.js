sap.ui.define([
	"sap/ui/core/mvc/Controller",
	"sap/ui/model/json/JSONModel",
	"sap/ui/core/routing/History"
], function(Controller, JSONModel, History) {
	"use strict";

	return Controller.extend("com.unccSoviDiningunccSoviDining.controller.View2", {
		onInit: function() {
			var that = this;
			// var oModel = new JSONModel("model/sample.json");
			// that.getView().setModel(oModel, "typeModel");
			var oRouter = that.getOwnerComponent().getRouter();
			oRouter.getRoute("View2").attachPatternMatched(that.onObjectMatched, that);
		},
		onObjectMatched: function(oEvent) {
			var that = this;
			var selectedArguments = oEvent.getParameter("arguments").object;
			var navData = that.getView().getModel("dataModel").getData().results[selectedArguments];
			var items = {
				"results": [navData]
			};
			var oModel = new JSONModel(items);
			var oVizFrame = that.getView().byId("idVizFrame1");
			oVizFrame.setModel(oModel);

		},
		onBack: function() {
			var that = this;
			var oHistory, sPreviousHash;

			oHistory = History.getInstance();
			sPreviousHash = oHistory.getPreviousHash();

			if (sPreviousHash !== undefined) {
				window.history.go(-1);
			} else {
				this.getRouter().navTo("view1", {}, true /*no history*/ );
			}
		},
	});
});