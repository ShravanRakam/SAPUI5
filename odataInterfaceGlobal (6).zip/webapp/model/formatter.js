sap.ui.define(function() {
	"use strict";
	var formatter = {
		State: function(sStatus) {
			if (sStatus === "Processed Succesfully") {
				return "Success";
			} else if (sStatus === "Processed With Errors") {
				return "Error";
			}
		},
		ButtonType: function(ButtonTy) {
			if (ButtonTy === "Processed Succesfully" || ButtonTy === "Ready to send" || ButtonTy === "Sent to Mulesoft") {
				return sap.m.ButtonType.Accept;
			} else if (ButtonTy === "Processed With Errors" || ButtonTy === "Ready to send" || ButtonTy === "Sent to Mulesoft") {
				return sap.m.ButtonType.Reject;
			}
		},
		linkVisible: function(sValue) {
			if (sValue !== null && sValue !== undefined) {
				if (sValue.length !== 0) {
					return true;
				} else {
					return false;
				}
			} else {
				return false;
			}
		}

	};
	return formatter;
});