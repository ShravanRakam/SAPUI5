sap.ui.define(["jquery.sap.global"],
	function(jQuery) {
		"use strict";
		var PersoService = {
			oData: {
				_persoSchemaVersion: "1.0",
				aColumns: [{
					id: "demoApp-table1-C1",
					order: 0,
					text: "{i18n>InterfaceID}",
					property: "interfaceId",
					type: "String",
					visible: true
				}, {
					id: "demoApp-table1-C2",
					order: 1,
					text: "{i18n>ShipmentID}",
					property: "id",
					type: "String",
					visible: true

				}, {
					id: "demoApp-table1-C3",
					order: 2,
					text: "{i18n>DeliveryFreightBill}",
					property: "customId",
					type: "String",
					visible: true
				}, {
					id: "demoApp-table1-C4",
					order: 3,
					text: "{i18n>Region}",
					property: "regionCode",
					type: "String",
					visible: true
				}, {
					id: "demoApp-table1-C5",
					order: 4,
					text: "{i18n>OriginCountry}",
					property: "originCountry",
					type: "String",
					visible: true
				}, {
					id: "demoApp-table1-C6",
					order: 5,
					text: "{i18n>DestinationCountry}",
					property: "destinationCountry",
					type: "String",
					visible: true
				}, {
					id: "demoApp-table1-C7",
					order: 6,
					text: "{i18n>CreatedTimestamp}",
					property: "createdTimestamp",
					type: "String",
					visible: true
				}, {
					id: "demoApp-table1-C8",
					order: 7,
					text: "{i18n>UpdatedTimestamp}",
					property: "updatedTimestamp",
					type: "String",
					visible: true
				}, {
					id: "demoApp-table1-C9",
					order: 8,
					text: "{i18n>QuarantineUserName}",
					property: "ErrorSystemName",
					type: "String",
					visible: true
				}, {
					id: "demoApp-table1-C10",
					order: 9,
					text: "{i18n>ErrorMessage}",
					property: "errorMessageJson",
					type: "String",
					visible: true
				}, {
					id: "demoApp-table1-C11",
					order: 10,
					text: "{i18n>TransactionType}",
					property: "transactionType",
					type: "String",
					visible: false
				}, {
					id: "demoApp-table1-C12",
					order: 11,
					text: "{i18n>OriginalPayload}",
					property: "originalPayloadJson",
					type: "String",
					visible: true
				}, {
					id: "demoApp-table1-C13",
					order: 12,
					text: "{i18n>FailurePayload}",
					property: "failurePayloadJson",
					type: "String",
					visible: true
				}, {
					id: "demoApp-table1-C14",
					order: 13,
					text: "{i18n>RecordStatus}",
					property: "recordStatus",
					type: "String",
					visible: true
				}, {
					id: "demoApp-table1-C15",
					order: 14,
					text: "{i18n>TypeofErrpr}",
					property: "typeofError",
					type: "String",
					visible: true
				}, {
					id: "demoApp-table1-C16",
					order: 15,
					text: "{i18n>RetryStatus}",
					property: "retryStatus",
					type: "String",
					visible: true
				}, {
					id: "demoApp-table1-C17",
					order: 16,
					text: "{i18n>SnowTicket}",
					property: "snowticket",
					type: "String",
					visible: true
				},
				 {
					id: "demoApp-table1-C18",
					order: 17,
					text: "{i18n>SnowTicket}",
					property: "snowticket",
					type: "String",
					visible: true
				},
				 {
					id: "demoApp-table1-C19",
					order: 18,
					text: "{i18n>MailNotification}",
					property: "mailNotification",
					type: "String",
					visible: true
				}]
			},
			getPersData: function() {
				var oDeferred = new jQuery.Deferred();
				if (!this._oBundle) {
					// oBundle
				}
				var oBundle = this._oBundle;
				oDeferred.resolve(oBundle);
				return oDeferred.promise();
			},
			setPersData: function(oBundle) {
				var oDeferred = new jQuery.Deferred();
				this._oBundle = oBundle;
				oDeferred.resolve();
				return oDeferred.promise();
			}
		};
		return PersoService;
	}, true
);