// jQuery.sap.require("demo.globalodataInterfaceGlobal.Libs.xmlToJson");
sap.ui.define([
	"sap/ui/core/mvc/Controller",
	// "demo/globalodataInterfaceGlobal/controller/BaseController",
	"sap/ui/model/json/JSONModel",
	"sap/m/TablePersoController",
	"../model/Inboundperso",
	"sap/ui/model/Filter",
	"sap/ui/model/FilterOperator",
	"../model/formatter",
	"sap/ui/model/Sorter",
	"sap/m/MessageBox",
	'sap/ui/core/util/Export',
	'sap/ui/core/util/ExportTypeCSV'
], function(Controller, JSONModel, TablePersoController, Inboundperso, Filter, FilterOperator, formatter, Sorter, MessageBox, Export,
	ExportTypeCSV) {
	"use strict";

	return Controller.extend("demo.globalodataInterfaceGlobal.controller.Inbound", {
		formatter: formatter,
		onInit: function() {
			var that = this;
			var oTable = this.getView().byId("table1");
			oTable.addEventDelegate({
				onAfterRendering: function() {
					var oHeader = this.$().find('.sapMListTblHeaderCell');
					for (var i = 0; i < oHeader.length; i++) {
						var oID = oHeader[i].id;
						that.onClick(oID, oTable);
					}
				}
			}, oTable);
			that._oTPC = new TablePersoController({
				table: that.getView().byId("table1"),
				componentName: "oTableComp",
				persoService: Inboundperso
			}).activate();
			var oRouter = sap.ui.core.UIComponent.getRouterFor(this);
			oRouter.getRoute("Inbound").attachPatternMatched(this._onObjectMatched, this);
		},
		_onObjectMatched: function(oEvent) {

			var that = this;
			var getObj = oEvent.getParameter("arguments");
			that.Data = JSON.parse(getObj.obj);
			that.getOdataService(that.Data);
			var ButtonHide = new JSONModel({
				Accept: true,
				Reject: true
			});
			that.getView().setModel(ButtonHide, "HideButton");

			var sData = sap.ui.getCore().getModel("oMuelTabModel").getData();

			var oModel = new JSONModel(sData);
			that.getView().setModel(oModel, "oMuelTabModel2");
			sap.ui.getCore().setModel(oModel, "oMuelTabModel2");

		},
		getOdataService: function(object) {
			var that = this;

			var oData = that.getOwnerComponent().getModel("mainModel");
			oData.read("/modelData", {
				// filters: Filters,
				success: function(oData, res) {
					if (res.statusCode === "200" || res.statusCode === 200) {
						var TabModel = new sap.ui.model.json.JSONModel({
							"modelData": oData.results,
							success: "",
							failure: ""
						});
						that.getView().setModel(TabModel, "oMuelTabModel2");
					}
				}
			});
		},
		onClick: function(oID, oTable) {
			var that = this;
			$('#' + oID).click(function(oEvent) {
				var Items = oTable.getItems(),
					oView = that.getView();
				that.selectedTable = oTable;
				if (Items.length > 0) {
					if (!that._oResponsivePopover) {
						that._oResponsivePopover = sap.ui.xmlfragment("demo.globalodataInterfaceGlobal.fragments.ColumnFragment", that);
						that._oResponsivePopover.setModel(oView.getModel());
					}
					var oTarget = oEvent.currentTarget; //Get hold of Header Element
					// get column path based on target id.
					oTable.getColumns().findIndex(function(item, index) {

						if (oTarget.innerText === item.getHeader().getText()) {
							that.columnIndex = index;
							that.columnPath = Items[0].getCells()[index].getBindingInfo("text").parts;
							return;
						}
					});
					// open popover by target.
					that._oResponsivePopover.openBy(oTarget);
				} else {
					// showing notification if use have no items in the table.
					sap.m.MessageToast.show("You have No Data For Sort and Filter");
				}
			});

		},
		onPerso1: function() {
			var that = this;
			that._oTPC.openDialog();
		},
		onLiveSearch: function(oEvent) {
			var source = oEvent.getSource();
			var items = source.getValue();
			var oTable = this.getView().byId("table1");
			var tableItems = oTable.getBinding("items");
			var nameFilter5 = new sap.ui.model.Filter("interfaceId", sap.ui.model.FilterOperator.Contains, items);
			var nameFilter6 = new sap.ui.model.Filter("id", sap.ui.model.FilterOperator.Contains, items);
			var nameFilter7 = new sap.ui.model.Filter("customId", sap.ui.model.FilterOperator.Contains, items);
			var nameFilter8 = new sap.ui.model.Filter("regionCode", sap.ui.model.FilterOperator.Contains, items);
			var nameFilter9 = new sap.ui.model.Filter("originCountry", sap.ui.model.FilterOperator.Contains, items);
			var nameFilter10 = new sap.ui.model.Filter("destinationCountry", sap.ui.model.FilterOperator.Contains, items);
			var nameFilter11 = new sap.ui.model.Filter("createdTimestamp", sap.ui.model.FilterOperator.Contains, items);
			var nameFilter12 = new sap.ui.model.Filter("updatedTimestamp", sap.ui.model.FilterOperator.Contains, items);
			var nameFilter13 = new sap.ui.model.Filter("transactionType", sap.ui.model.FilterOperator.Contains, items);
			var nameFilter14 = new sap.ui.model.Filter("recordStatus", sap.ui.model.FilterOperator.Contains, items);
			var nameFilter15 = new sap.ui.model.Filter("typeofError", sap.ui.model.FilterOperator.Contains, items);
			var nameFilter16 = new sap.ui.model.Filter("retryStatus", sap.ui.model.FilterOperator.Contains, items);
			var nameFilter17 = new sap.ui.model.Filter("snowticket", sap.ui.model.FilterOperator.Contains, items);
			var nameFilter18 = new sap.ui.model.Filter("mailNotification", sap.ui.model.FilterOperator.Contains, items);
			var filter = [nameFilter5, nameFilter6, nameFilter7, nameFilter8, nameFilter9, nameFilter10, nameFilter11, nameFilter12,
				nameFilter13, nameFilter14, nameFilter15, nameFilter16, nameFilter17, nameFilter18
			];
			var filters = new sap.ui.model.Filter(filter, false);
			tableItems.filter(filters);
		},
		onChange: function(oEvent) {
			var source = oEvent.getSource();
			var items = source.getValue();
			var oTable = this.getView().byId("table1");
			var tableItems = oTable.getBinding("items");
			var nameFilter5 = new sap.ui.model.Filter("interfaceId", sap.ui.model.FilterOperator.Contains, items);
			var nameFilter6 = new sap.ui.model.Filter("id", sap.ui.model.FilterOperator.Contains, items);
			var nameFilter7 = new sap.ui.model.Filter("customId", sap.ui.model.FilterOperator.Contains, items);
			var nameFilter8 = new sap.ui.model.Filter("regionCode", sap.ui.model.FilterOperator.Contains, items);
			var nameFilter9 = new sap.ui.model.Filter("originCountry", sap.ui.model.FilterOperator.Contains, items);
			var nameFilter10 = new sap.ui.model.Filter("destinationCountry", sap.ui.model.FilterOperator.Contains, items);
			var nameFilter11 = new sap.ui.model.Filter("createdTimestamp", sap.ui.model.FilterOperator.Contains, items);
			var nameFilter12 = new sap.ui.model.Filter("updatedTimestamp", sap.ui.model.FilterOperator.Contains, items);
			var nameFilter13 = new sap.ui.model.Filter("transactionType", sap.ui.model.FilterOperator.Contains, items);
			var nameFilter14 = new sap.ui.model.Filter("recordStatus", sap.ui.model.FilterOperator.Contains, items);
			var nameFilter15 = new sap.ui.model.Filter("typeofError", sap.ui.model.FilterOperator.Contains, items);
			var nameFilter16 = new sap.ui.model.Filter("retryStatus", sap.ui.model.FilterOperator.Contains, items);
			var nameFilter17 = new sap.ui.model.Filter("snowticket", sap.ui.model.FilterOperator.Contains, items);
			var nameFilter18 = new sap.ui.model.Filter("mailNotification", sap.ui.model.FilterOperator.Contains, items);
			var filter = [nameFilter5, nameFilter6, nameFilter7, nameFilter8, nameFilter9, nameFilter10, nameFilter11, nameFilter12,
				nameFilter13, nameFilter14, nameFilter15, nameFilter16, nameFilter17, nameFilter18
			];
			var filters = new sap.ui.model.Filter(filter, false);
			tableItems.filter(filters);
			this._oResponsivePopover.close();
		},
		onAscending: function(oEvent) {
			var that = this,
				oTable = that.selectedTable,
				text = oEvent.getSource().getContent()[0].getItems()[0].getText(),
				oBinding,
				sPath = that.columnPath[0].path,
				bDescending,
				aSorters = [];
			// checking selcted sort by
			if (text === "Ascending") {
				bDescending = true;
			} else {
				bDescending = false;
			}
			aSorters.push(new Sorter(sPath, bDescending));
			oBinding = oTable.getBinding("items");
			// apply the selected sort and group settings
			oBinding.sort(new Sorter(sPath, bDescending));
			oTable.getModel().refresh();
			this._oResponsivePopover.close();
		},
		onDescending: function(oEvent) {
			var that = this,
				oTable = that.selectedTable,
				text = oEvent.getSource().getContent()[0].getItems()[0].getText(),
				oBinding,
				sPath = that.columnPath[0].path,
				bDescending,
				aSorters = [];
			// checking selcted sort by
			if (text === "Ascending") {
				bDescending = false;
			} else {
				bDescending = true;
			}
			aSorters.push(new Sorter(sPath, bDescending));
			oBinding = oTable.getBinding("items");
			// apply the selected sort and group settings
			oBinding.sort(new Sorter(sPath, bDescending));
			oTable.getModel().refresh();
			this._oResponsivePopover.close();
		},
		onIconPress: function(oEvent) {
			var that = this;
			var oBinding = this.byId("table1").getBinding("items");
			// sKey = oEvent.getParameter("key"),
			that.sKey = oEvent.getSource().getSelectedKey();
			var aFilters = [];
			if (that.sKey === "All") {
				this.getView().getModel("HideButton").setProperty("/Accept", true);
				this.getView().getModel("HideButton").setProperty("/Reject", true);
				oBinding.filter(null);
			}
			if (that.sKey === "Success") {
				aFilters.push(new Filter("recordStatus", FilterOperator.EQ, "success"));
				oBinding.filter(aFilters);
				// var TabItems = this.getView().byId("table").getItems().length;
				var TabItems = oBinding.getLength();
				this.getView().getModel("oMuelTabModel2").setProperty("/success", TabItems);
				this.getView().getModel("HideButton").setProperty("/Accept", true);
				this.getView().getModel("HideButton").setProperty("/Reject", false);

			}
			oBinding.filter(aFilters);
			if (that.sKey === "Failure") {
				aFilters.push(new Filter("recordStatus", FilterOperator.EQ, "failed"));
				oBinding.filter(aFilters);
				// var TabItems1 = this.getView().byId("table").getItems().length;
				var TabItems1 = oBinding.getLength();
				this.getView().getModel("oMuelTabModel2").setProperty("/failure", TabItems1);
				this.getView().getModel("HideButton").setProperty("/Accept", false);
				this.getView().getModel("HideButton").setProperty("/Reject", true);
			}
			oBinding.filter(aFilters);

		},
		onLinkPress: function(oEvent) {
			var that = this,
				errData = oEvent.getSource().getBindingContext("oMuelTabModel2").getObject();

			if (!that._oPopover) {
				that._oPopover = sap.ui.xmlfragment("demo.globalodataInterfaceGlobal.fragments.errorMsgPopover", this);
				that.getView().addDependent(that._oPopover);
			}
			var oModel = new JSONModel({
				errMsg: errData.errorMessageJson,
				title: "Error Message"
			});
			that.getView().setModel(oModel, "errMsgModel");

			var oButton = oEvent.getSource();
			jQuery.sap.delayedCall(0, this, function() {
				that._oPopover.openBy(oButton);
			});
		},
		onPopCancel: function() {
			var that = this;
			that._oPopover.destroy();
			that._oPopover = null;
		},
		onRefresh: function() {

			var that = this;
			var oTable = this.selectedTable,
				sFilters = [];

			if (that.sKey === "All") {
				sFilters.push(new sap.ui.model.Filter("recordStatus", sap.ui.model.FilterOperator.Contains, ""));
			} else if (that.sKey === "Success") {
				sFilters.push(new sap.ui.model.Filter("recordStatus", sap.ui.model.FilterOperator.Contains, "success"));
			} else if (that.sKey === "failed") {
				sFilters.push(new sap.ui.model.Filter("recordStatus", sap.ui.model.FilterOperator.Contains, "failed"));
			}
			var sInpFilter = new sap.ui.model.Filter({
				filters: sFilters,
				and: true
			});
			var oBinding = oTable.getBinding("items");
			// apply the selected sort and group settings
			oBinding.sort(null);
			oBinding.filter(sInpFilter);
		},
		onOrginalPayloadPress: function(oEvent) {
			var that = this;

			if (!that.oPersoPopover) {
				that.oPersoPopover = sap.ui.xmlfragment("demo.globalodataInterfaceGlobal.fragments.viewPayload", that);
				that.getView().addDependent(that.oPersoPopover);
				// that.getView().setModel(payloadModel, "PayloadModelBind");
			}
			that.oPersoPopover.open();

		},
		onClose: function() {
			var that = this;
			that.oPersoPopover.close();
		},
		onExport: function(oEvent) {
			var that = this;
			var Key = oEvent.getSource().oParent.oParent.oParent.mAggregations.content[1].mAggregations._header.oSelectedItem.mProperties.key;
			if (Key === "All") {
				var oExport = new Export({
					exportType: new ExportTypeCSV({
						separatorColumn: "Column",
						mimeType: "application/vnd.ms-excel",
						fileExtension: "xls"
					}),
					models: this.getView().getModel("oMuelTabModel2"),
					rows: {
						path: "/modelData"

					},
					// columns: Arr
					columns: [{
						name: "InterfaceID",
						template: {
							content: "{interfaceId}"
						}
					}, {
						name: "ShipmentID",
						template: {
							content: "{id}"
						}
					}, {
						name: "DeliveryFreightBill",
						template: {
							content: "{customId}"
						}

					}, {
						name: "Region",
						template: {
							content: "{regionCode}"
						}
					}, {
						name: "OriginCountry",
						template: {
							content: "{originCountry}"
						}
					}, {
						name: "DestinationCountry",
						template: {
							content: "{destinationCountry}"
						}
					}, {
						name: "CreatedTimestamp",
						template: {
							content: "{createdTimestamp}"
						}
					}, {
						name: "UpdatedTimestamp",
						template: {
							context: "{updatedTimestamp}"
						}
					}, {
						name: "QuarantineUserName",
						template: {
							context: "{ErrorSystemName}"
						}

					}, {
						name: "ErrorMessage",
						template: {
							context: "{errorMessageJson}"
						}

					}, {
						name: "TransactionType",
						template: {
							context: "{transactionType}"
						}

					}, {
						name: "OriginalPayload",
						template: {
							context: "{originalPayloadJson}"
						}

					}, {
						name: "FailurePayload",
						template: {
							context: "{failurePayloadJson}"
						}

					}, {
						name: "RecordStatus",
						template: {
							context: "{recordStatus}"
						}

					}, {
						name: "TypeofErrpr",
						template: {
							context: "{typeofError}"
						}

					}, {
						name: "RetryStatus",
						template: {
							context: "{retryStatus}"
						}

					}, {
						name: "SnowTicket",
						template: {
							context: "{snowticket}"
						}

					}, {
						name: "MailNotification",
						template: {
							context: "{mailNotification}"
						}

					}]
				});

				oExport.saveFile("Inbound_Data").catch(function(oError) {
					sap.m.MessageBox.error("Error when downloading data. Browser might not be supported!\n\n" + oError);
				}).then(function() {
					oExport.destroy();
				});
			} else if (Key === "Success") {
				var DataModel = this.getView().getModel("oMuelTabModel2").getData().modelData;
				for(var i = 0; i < DataModel.length; i++){
					
				}
				
				var oExport = new Export({
					exportType: new ExportTypeCSV({
						separatorColumn: "Column",
						mimeType: "application/vnd.ms-excel",
						fileExtension: "xls"
					}),
					models: this.getView().getModel("oMuelTabModel2"),
					rows: {
						path: "/modelData"

					},
					// columns: Arr
					columns: [{
						name: "InterfaceID",
						template: {
							content: "{interfaceId}"
						}
					}, {
						name: "ShipmentID",
						template: {
							content: "{id}"
						}
					}, {
						name: "DeliveryFreightBill",
						template: {
							content: "{customId}"
						}

					}, {
						name: "Region",
						template: {
							content: "{regionCode}"
						}
					}, {
						name: "OriginCountry",
						template: {
							content: "{originCountry}"
						}
					}, {
						name: "DestinationCountry",
						template: {
							content: "{destinationCountry}"
						}
					}, {
						name: "CreatedTimestamp",
						template: {
							content: "{createdTimestamp}"
						}
					}, {
						name: "UpdatedTimestamp",
						template: {
							context: "{updatedTimestamp}"
						}
					}, {
						name: "QuarantineUserName",
						template: {
							context: "{ErrorSystemName}"
						}

					}, {
						name: "ErrorMessage",
						template: {
							context: "{errorMessageJson}"
						}

					}, {
						name: "TransactionType",
						template: {
							context: "{transactionType}"
						}

					}, {
						name: "OriginalPayload",
						template: {
							context: "{originalPayloadJson}"
						}

					}, {
						name: "FailurePayload",
						template: {
							context: "{failurePayloadJson}"
						}

					}, {
						name: "RecordStatus",
						template: {
							context: "{recordStatus}"
						}

					}, {
						name: "TypeofErrpr",
						template: {
							context: "{typeofError}"
						}

					}, {
						name: "RetryStatus",
						template: {
							context: "{retryStatus}"
						}

					}, {
						name: "SnowTicket",
						template: {
							context: "{snowticket}"
						}

					}, {
						name: "MailNotification",
						template: {
							context: "{mailNotification}"
						}

					}]
				});

				oExport.saveFile("Inbound_Data").catch(function(oError) {
					sap.m.MessageBox.error("Error when downloading data. Browser might not be supported!\n\n" + oError);
				}).then(function() {
					oExport.destroy();
				});
			} else if (Key === "Failure") {

				var oExport = new Export({
					exportType: new ExportTypeCSV({
						separatorColumn: "Column",
						mimeType: "application/vnd.ms-excel",
						fileExtension: "xls"
					}),
					models: this.getView().getModel("oMuelTabModel2"),
					rows: {
						path: "/modelData"

					},
					// columns: Arr
					columns: [{
						name: "InterfaceID",
						template: {
							content: "{interfaceId}"
						}
					}, {
						name: "ShipmentID",
						template: {
							content: "{id}"
						}
					}, {
						name: "DeliveryFreightBill",
						template: {
							content: "{customId}"
						}

					}, {
						name: "Region",
						template: {
							content: "{regionCode}"
						}
					}, {
						name: "OriginCountry",
						template: {
							content: "{originCountry}"
						}
					}, {
						name: "DestinationCountry",
						template: {
							content: "{destinationCountry}"
						}
					}, {
						name: "CreatedTimestamp",
						template: {
							content: "{createdTimestamp}"
						}
					}, {
						name: "UpdatedTimestamp",
						template: {
							context: "{updatedTimestamp}"
						}
					}, {
						name: "QuarantineUserName",
						template: {
							context: "{ErrorSystemName}"
						}

					}, {
						name: "ErrorMessage",
						template: {
							context: "{errorMessageJson}"
						}

					}, {
						name: "TransactionType",
						template: {
							context: "{transactionType}"
						}

					}, {
						name: "OriginalPayload",
						template: {
							context: "{originalPayloadJson}"
						}

					}, {
						name: "FailurePayload",
						template: {
							context: "{failurePayloadJson}"
						}

					}, {
						name: "RecordStatus",
						template: {
							context: "{recordStatus}"
						}

					}, {
						name: "TypeofErrpr",
						template: {
							context: "{typeofError}"
						}

					}, {
						name: "RetryStatus",
						template: {
							context: "{retryStatus}"
						}

					}, {
						name: "SnowTicket",
						template: {
							context: "{snowticket}"
						}

					}, {
						name: "MailNotification",
						template: {
							context: "{mailNotification}"
						}

					}]
				});

				oExport.saveFile("Inbound_Data").catch(function(oError) {
					sap.m.MessageBox.error("Error when downloading data. Browser might not be supported!\n\n" + oError);
				}).then(function() {
					oExport.destroy();
				});
			}
		}
	});
});