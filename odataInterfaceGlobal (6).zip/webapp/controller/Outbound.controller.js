// jQuery.sap.require("demo.globalodataInterfaceGlobal.Libs.xmlToJson");
sap.ui.define([
	"sap/ui/core/mvc/Controller",
	"sap/ui/model/json/JSONModel",
	"sap/m/TablePersoController",
	"../model/perso",
	"sap/ui/model/Filter",
	"sap/ui/model/FilterOperator",
	"../model/formatter",
	"sap/ui/model/Sorter",
	'sap/ui/core/util/Export',
	'sap/ui/core/util/ExportTypeCSV'
	// "sap/ui/export/library",
	// "sap/ui/export/Spreadsheet"

], function(Controller, JSONModel, TablePersoController, perso, Filter, FilterOperator, formatter, Sorter, Export, ExportTypeCSV) {
	"use strict";
	// var EdmType = exportLibrary.EdmType;
	return Controller.extend("demo.globalodataInterfaceGlobal.controller.Outbound", {
		formatter: formatter,

		onInit: function() {
			var that = this;
			that._oTPC = new TablePersoController({
				table: that.getView().byId("table"),
				componentName: "demoApp",
				persoService: perso
			}).activate();
			var oTable = this.getView().byId("table");
			oTable.addEventDelegate({
				onAfterRendering: function() {
					var oHeader = this.$().find('.sapMListTblHeaderCell'); //Get hold of table header elements
					for (var i = 0; i < oHeader.length; i++) {
						var oID = oHeader[i].id;
						that.onClick(oID, oTable);
					}
				}
			}, oTable);
			//
			this.getAjaxHeadConfig();
			//
			var oRouter = sap.ui.core.UIComponent.getRouterFor(this);
			oRouter.getRoute("Outbound").attachPatternMatched(this._onObjectMatched, this);
		},
		onClick: function(oID, oTable) {
			var that = this;
			$('#' + oID).click(function(oEvent) {
				var Items = oTable.getItems(),
					oView = that.getView();
				that.selectedTable = oTable;
				if (Items.length > 0) {
					if (!that._oResponsivePopover) {
						that._oResponsivePopover = sap.ui.xmlfragment("demo.globalodataInterfaceGlobal.fragments.ColumnFragment", that);
						that._oResponsivePopover.setModel(oView.getModel());
					}
					var oTarget = oEvent.currentTarget; //Get hold of Header Element
					// get column path based on target id.
					oTable.getColumns().findIndex(function(item, index) {

						if (oTarget.innerText === item.getHeader().getText()) {
							that.columnIndex = index;
							that.columnPath = Items[0].getCells()[index].getBindingInfo("text").parts;
							return;
						}
					});
					// open popover by target.
					that._oResponsivePopover.openBy(oTarget);
				} else {
					// showing notification if use have no items in the table.
					sap.m.MessageToast.show("You have No Data For Sort and Filter");
				}
			});

		},
		getAjaxHeadConfig: function() {
			var that = this;
			var sModel = that.getOwnerComponent().getModel("mainModel");
			// that.fnCreateBusyDialog("pallet.svg");
			sModel.read("/ConfigSet('A')", {
				success: function(oData) {
					var settings = {
						"async": true,
						"crossDomain": true,
						"url": oData.ServerUrl,
						"headers": {
							"Access-Control-Allow-Origin": "*",
							"Access-Control-Allow-Methods": "GET, POST, PUT, DELETE, OPTIONS",
							"client_id": oData.ClientId,
							"client_secret": oData.ClientSecret,
							"cache-control": "no-cache"
						}
					};
					var jsonModel = new JSONModel(settings);
					jsonModel.setDefaultBindingMode("OneWay");
					that.getView().setModel(jsonModel, "ajaxHeaderModel");
					// calling interface list service.
					// that.UserSet();
					// that.oInsCreateDailog.close();
				},
				error: function(oResponse) {
					that.oInsCreateDailog.close();
					that.errMsgReturn(oResponse);
				}
			});
		},

		_onObjectMatched: function(oEvent) {
			var that = this;
			var getObj = oEvent.getParameter("arguments");
			that.oData = JSON.parse(getObj.obj);
			that.getOdataService(that.oData);
			var ButtonHide = new JSONModel({
				Accept: true,
				Reject: true
			});
			that.getView().setModel(ButtonHide, "HideButton");

		},
		onPerso: function() {
			var that = this;
			that._oTPC.openDialog();
		},
		getOdataService: function(object) {
			var that = this;
			var Filters = [];

			// var Filters = [

			// 	new Filter("trtyp", FilterOperator.EQ, object.transType),
			// 	new Filter("destination", FilterOperator.EQ, object.sysDesn),
			// 	new Filter("status", FilterOperator.EQ, object.status)

			// ];
			if (object.transType.length > 0) {
				Filters.push(new Filter("trtyp", FilterOperator.EQ, object.transType));
			}
			if (object.sysDesn.length > 0) {
				Filters.push(new Filter("destination", FilterOperator.EQ, object.sysDesn));
			}
			if (object.status.length > 0) {
				Filters.push(new Filter("status", FilterOperator.EQ, object.status));
			}

			if (object.delNo !== undefined) {
				object.delNo.forEach(function(item) {
					Filters.push(new Filter("vbeln", sap.ui.model.FilterOperator.EQ, object.delNo));
				});
				// Filters.push(new Filter("vbeln", sap.ui.model.FilterOperator.EQ, object.delNo));

			}
			if (object.salesOrg !== undefined) {
				object.salesOrg.forEach(function(item) {
					Filters.push(new Filter("salesorg", sap.ui.model.FilterOperator.EQ, object.salesOrg));
				});

			}
			var oData = that.getOwnerComponent().getModel("mainModel");
			oData.read("/InboundSet", {
				filters: Filters,
				success: function(oData, res) {
					if (res.statusCode === "200" || res.statusCode === 200) {
						var TabModel = new sap.ui.model.json.JSONModel({
							"InboundSet": oData.results,
							success: "",
							failure: ""
						});
						that.getView().setModel(TabModel, "OutBoundModel");
						sap.ui.getCore().setModel(TabModel, "OutBoundModel");
					}
				}
			});
		},
		onOrginalPay: function(oEvent) {
			var that = this;
			// that.sValue = oEvent.getSource().getBindingContext("OutBoundModel").getObject();
			// var modelData = JSON.stringify(that.getView().getModel("ajaxHeaderModel").getData());
			// var settings = JSON.parse(modelData);
			// settings.url = settings.url + "retrievePayload?customId=" + that.sValue.guid + "&interfacePayload=originalPayload";
			// settings.method = "GET";

			// $.ajax(settings).success(function(response) {

			// 	if (response.length > 0) {
			// 		var failLoad = response[0].originalPayloadXml;
			// 		var payloadModel;
			// 		var arr = [];
			// 		if (failLoad !== null) {
			// 			var json = xmlToJson.parse(failLoad);
			// 			// try {
			// 			// 	JSON.stringify(json, undefined, 4)
			// 			// } catch (err) {
			// 			// 	MessageBox.error(err);
			// 			// }
			// 			$.each(json, function(k, v) {
			// 				if (typeof(json[k]) === "object") {
			// 					$.each(json[k], function(k1, v1) {
			// 						var obj = {};
			// 						obj.label = k1;
			// 						obj.value = v1;
			// 						arr.push(obj);
			// 					});
			// 				} else {
			// 					json[k].forEach(function(item) {
			// 						$.each(item, function(k1, v1) {
			// 							var obj = {};
			// 							obj.label = k1;
			// 							obj.value = v1;
			// 							arr.push(obj);
			// 						});
			// 					});
			// 				}
			// 			});
			// 		} else {
			// 			failLoad = "";

			// 			try {
			// 				json = JSON.parse(response[0].originalPayloadJson);
			// 			} catch (err) {
			// 				// var msg = that.i18nModel("payloadErr");
			// 				// sap.m.MessageBox.error(msg);
			// 			}
			// 		}
			// 		if (arr.length > 0) {
			// 			payloadModel = new JSONModel({
			// 				// title: that.i18nModel("orgiPayload"),
			// 				typeofRecord: "original",
			// 				json: JSON.stringify(json, undefined, 4),
			// 				xml: failLoad,
			// 				retryStatus: that.sValue.retryStatus,
			// 				typeofError: that.sValue.typeofError,
			// 				results: arr
			// 			});
			// 		} else {
			// 			payloadModel = new JSONModel({
			// 				// title: that.i18nModel("orgiPayload"),
			// 				typeofRecord: "original",
			// 				json: JSON.stringify(json, undefined, 4),
			// 				xml: failLoad,
			// 				retryStatus: that.sValue.retryStatus,
			// 				typeofError: that.sValue.typeofError,
			// 				results: []
			// 			});
			// 		}
			if (!that.oPersoPopover) {
				that.oPersoPopover = sap.ui.xmlfragment("demo.globalodataInterfaceGlobal.fragments.viewPayload", that);
				that.getView().addDependent(that.oPersoPopover);
				// that.getView().setModel(payloadModel, "PayloadModelBind");
			}
			that.oPersoPopover.open();
			// 	} else {
			// 		// var msg1 = that.i18nModel("payloadErr");
			// 		// sap.m.MessageBox.error(msg1);
			// 	}
			// 	// MessageBox.success(response.status);
			// });

		},
		onClose: function() {
			var that = this;
			that.oPersoPopover.close();
		},
		onNavBack: function() {
			history.go(-1);
		},
		createColumnConfig: function() {
			var that = this;
			// var cols;
			var basicCols;
			var visibleColumns = [];
			this.visibleColumns = [];
			var getHeaderText = this.getOwnerComponent().getModel("i18n");
			// cols = that._oTPC.aColumns;
			basicCols = that._oTPC.getAggregation("persoService").oData.aColumns;
			basicCols.forEach(function(item) {
				var colHeader = item.text;
				if (item.visible === true) {
					if (item.text.includes("{i18n>")) {
						var label = item.text.split("{i18n>")[1].split("}")[0];
						item.label = getHeaderText.getProperty(label);
					} else {
						item.label = item.text;
					}
					basicCols.forEach(function(sItem) {
						if (item.visible === true && item.id === sItem.id) {
							item.property = sItem.property;
							item.type = sItem.type;
							item.scale = sItem.scale;
							item.unitProperty = sItem.unitProperty;
							item.displayUnit = sItem.displayUnit;
							item.template = sItem.template;
							item.width = sItem.width;
						}
					});
					if ((colHeader !== "{i18n>orgPayload}" && colHeader !== "Original Payload") && (colHeader !== "{i18n>errPayload}" &&
							colHeader !== "Error Payload")) {
						visibleColumns.push(item);
						that.visibleColumns.push(item.text);
					}
				}
			});
			return visibleColumns;
		},
		// createColumnConfig: function() {
		// 	var aColumns = [];
		// 	aColumns.push({
		// 		label: "Delivery",
		// 		property: "vbeln"

		// 	}, {
		// 		label: "Reference Number",
		// 		property: "zreference"

		// 	}, {
		// 		label: "Shipping Conditions",
		// 		property: "ship_cond"

		// 	}, {
		// 		label: "Sales Org",
		// 		property: "salesorg"

		// 	}, {
		// 		label: "Plant",
		// 		property: "plant"

		// 	}, {
		// 		label: "Customer",
		// 		property: "customer"

		// 	}, {
		// 		label: "System",
		// 		property: "destination"

		// 	}, {
		// 		label: "System Name",
		// 		property: "system_descr"

		// 	}, {
		// 		label: "Created Time",
		// 		property: "timestamp"

		// 	}, {
		// 		label: "Last Updated Time",
		// 		property: "user_time"

		// 	}, {
		// 		label: "Status Description",
		// 		property: "status_descr"

		// 	}, {
		// 		label: "Error Description",
		// 		property: "err_des"

		// 	}, {
		// 		label: "Transaction Type",
		// 		property: "trtyp"

		// 	}, {
		// 		label: "TType Description",
		// 		property: "trtyp_des"

		// 	}, {
		// 		label: "status",
		// 		property: "status"

		// 	});
		// 	return aColumns;
		// },
		// onExport: function() {
		// 	// var that = this;
		// 	// var oTable, tableItems;
		// 	// oTable = that.getView().byId("table");
		// 	// tableItems = oTable.getItems();
		// 	// if (tableItems.length > 0) {
		// 	// 	var aColumns, oSettings, oSheet;
		// 	// 	aColumns = that.createColumnConfig();
		// 	// 	var collectionRecord = that.getView().getModel("OutBoundModel").getData();

		// 	// 	oSettings = {
		// 	// 		workbook: {
		// 	// 			columns: aColumns,
		// 	// 			context: {
		// 	// 				sheetName: "Outbound Deatils"
		// 	// 			}
		// 	// 		},
		// 	// 		dataSource: collectionRecord,
		// 	// 		fileName: "Outbound Data"
		// 	// 	};
		// 	// 	oSheet = new Spreadsheet(oSettings);
		// 	// 	oSheet.build()
		// 	// 		.then(function() {  

		// 	// 		})
		// 	// 		.finally(function() {
		// 	// 			oSheet.destory();
		// 	// 		});
		// 	// }
		// },
		onExport: sap.m.Table.prototype.exportData || function(oEvent) {

			// var aCols = this.createColumnConfig();
		
			// var tableItems, aCols, Arr = [],
			// 	filterData = [],
			// 	oTableData = this.getView().getModel("OutBoundModel").getData().results;
			// var getHeaderText = this.getOwnerComponent().getModel("i18n");
			// tableItems = oEvent.getSource().getParent().getParent().getContent()[1].getContent()[0].getItems();
			// oEvent.getSource().getParent().getParent().getContent()[1].getContent()[0].getBindingInfo("items").binding.aIndices.forEach(
			// 	function(item) {
			// 		filterData.push(oTableData[item]);
			// 	});
			// filterData.forEach(function(item) {
			// 	item.Eventcreated_timestamp = formatter.timestamp(item.Eventcreated_timestamp);
			// 	item.timestamp = formatter.timestamp(item.timestamp);
			// });
			// var expModel = new JSONModel({
			// 	results: filterData
			// });
			// this.getView().setModel(expModel, "expModel");
			// if (tableItems.length > 0) {
			// 	aCols = this.createColumnConfig();
			// 	for (var a = 0; a < aCols.length; a++) {
			// 		var columnname = getHeaderText.getProperty(aCols[a].label);
			// 		var actColumn = aCols[a].property;
			// 		var oPath = "{" + actColumn + "}";
			// 		var oColumn = {
			// 			name: columnname,
			// 			template: {
			// 				content: oPath
			// 			}
			// 		};
			// 		Arr.push(oColumn);
			// 	}
				var TabModel = sap.ui.getCore().getModel("OutBoundModel");
			var oExport = new Export({
				exportType: new ExportTypeCSV({
					separatorColumn: "Column",
					mimeType: "application/vnd.ms-excel",
					fileExtension: "xls"
				}),

				// models: this.getView().getModel("OutBoundModel"),
				// models: this.getView().getModel("expModel"),
				models: TabModel,
				rows: {
					path: "/InboundSet"

				},
				// columns: Arr
				columns: [{
					name: "Delivery",
					template: {
						content: "{vbeln}"
					}
				}, {
					name: "Reference Number",
					template: {
						content: "{zreference}"
					}
				}, {
					name: "Shipping Conditions",
					template: {
						content: "{ship_cond}"
					}

				}, {
					name: "Sales Org",
					template: {
						content: "{salesorg}"
					}
				}, {
					name: "Plant",
					template: {
						content: "{Plant}"
					}
				}, {
					name: "Customer",
					template: {
						content: "{Customer}"
					}
				}, {
					name: "System",
					template: {
						content: "{destination}"
					}
				}, {
					name: "System Name",
					template: {
						context: "{system_descr}"
					}
				}, {
					name: "Created Time",
					template: {
						context: "{timestamp}"
					}

				}, {
					name: "Last Updated Time",
					template: {
						context: "{user_time}"
					}

				}, {
					name: "Status Description",
					template: {
						context: "{status_descr}"
					}

				}, {
					name: "Created Time",
					template: {
						context: "{timestamp}"
					}

				}, {
					name: "Error Description",
					template: {
						context: "{err_des}"
					}

				}, {
					name: "Transaction Type",
					template: {
						context: "{trtyp}"
					}

				}, {
					name: "TType Description",
					template: {
						context: "{trtyp_des}"
					}

				}, {
					name: "Original Payload",
					template: {
						context: "{}"
					}

				}, {
					name: "Error Payload",
					template: {
						context: "{}"
					}

				}, {
					name: "status",
					template: {
						context: "{status}"
					}

				}]
			});

			oExport.saveFile("OutBound_Data").catch(function(oError) {
				sap.m.MessageBox.error("Error when downloading data. Browser might not be supported!\n\n" + oError);
			}).then(function() {
				oExport.destroy();
			});
			// }
		},
		onFilterSelect: function(oEvent) {
			// var that=this;
			// var Tabledata = that.getView().byId("table");
			// var oTab = Tabledata.getBinding("items");
			var oBinding = this.byId("table").getBinding("items"),
				// sKey = oEvent.getParameter("key"),
				sKey = oEvent.getSource().getSelectedKey(),
				aFilters = [];
			if (sKey === "All") {
				this.getView().getModel("HideButton").setProperty("/Accept", true);
				this.getView().getModel("HideButton").setProperty("/Reject", true);
				oBinding.filter(null);
			}
			if (sKey === "Success") {
				aFilters.push(new Filter("status", FilterOperator.EQ, "03"));
				oBinding.filter(aFilters);
				// var TabItems = this.getView().byId("table").getItems().length;
				var TabItems = oBinding.getLength();
				this.getView().getModel("OutBoundModel").setProperty("/success", TabItems);
				this.getView().getModel("HideButton").setProperty("/Accept", true);
				this.getView().getModel("HideButton").setProperty("/Reject", false);

			}
			oBinding.filter(aFilters);
			if (sKey === "Failure") {
				aFilters.push(new Filter("status", FilterOperator.EQ, "04"));
				oBinding.filter(aFilters);
				// var TabItems1 = this.getView().byId("table").getItems().length;
				var TabItems1 = oBinding.getLength();
				this.getView().getModel("OutBoundModel").setProperty("/failure", TabItems1);
				this.getView().getModel("HideButton").setProperty("/Accept", false);
				this.getView().getModel("HideButton").setProperty("/Reject", true);
			}
			oBinding.filter(aFilters);

		},
		onSearch: function(oEvent) {
			var source = oEvent.getSource();
			var items = source.getValue();
			var oTable = this.getView().byId("table");
			var tableItems = oTable.getBinding("items");
			var nameFilter5 = new sap.ui.model.Filter("vbeln", sap.ui.model.FilterOperator.Contains, items);
			var nameFilter6 = new sap.ui.model.Filter("zreference", sap.ui.model.FilterOperator.Contains, items);
			var nameFilter7 = new sap.ui.model.Filter("ship_cond", sap.ui.model.FilterOperator.Contains, items);
			var nameFilter8 = new sap.ui.model.Filter("salesorg", sap.ui.model.FilterOperator.Contains, items);
			var nameFilter9 = new sap.ui.model.Filter("Plant", sap.ui.model.FilterOperator.Contains, items);
			var nameFilter10 = new sap.ui.model.Filter("Reportto", sap.ui.model.FilterOperator.Contains, items);
			var nameFilter11 = new sap.ui.model.Filter("Customer", sap.ui.model.FilterOperator.Contains, items);
			var nameFilter12 = new sap.ui.model.Filter("status", sap.ui.model.FilterOperator.Contains, items);
			var filter = [nameFilter5, nameFilter6, nameFilter7, nameFilter8, nameFilter9, nameFilter10, nameFilter11, nameFilter12];
			var filters = new sap.ui.model.Filter(filter, false);
			tableItems.filter(filters);
		},
		onLinkPress: function(oEvent) {
			var that = this,
				errData = oEvent.getSource().getBindingContext("OutBoundModel").getObject();

			if (!that._oPopover) {
				that._oPopover = sap.ui.xmlfragment("demo.globalodataInterfaceGlobal.fragments.errorMsgPopover", this);
				that.getView().addDependent(that._oPopover);
			}
			var oModel = new JSONModel({
				errMsg: errData.err_des,
				title: "Error Message"
			});
			that.getView().setModel(oModel, "errMsgModel");

			var oButton = oEvent.getSource();
			jQuery.sap.delayedCall(0, this, function() {
				that._oPopover.openBy(oButton);
			});
		},
		onPopCancel: function() {
			var that = this;
			that._oPopover.destroy();
			that._oPopover = null;
		},
		onChange: function(oEvent) {
			var source = oEvent.getSource();
			var items = source.getValue();
			var oTable = this.getView().byId("table");
			var tableItems = oTable.getBinding("items");
			var nameFilter5 = new sap.ui.model.Filter("vbeln", sap.ui.model.FilterOperator.Contains, items);
			var nameFilter6 = new sap.ui.model.Filter("zreference", sap.ui.model.FilterOperator.Contains, items);
			var nameFilter7 = new sap.ui.model.Filter("ship_cond", sap.ui.model.FilterOperator.Contains, items);
			var nameFilter8 = new sap.ui.model.Filter("salesorg", sap.ui.model.FilterOperator.Contains, items);
			var nameFilter9 = new sap.ui.model.Filter("Plant", sap.ui.model.FilterOperator.Contains, items);
			var nameFilter10 = new sap.ui.model.Filter("Reportto", sap.ui.model.FilterOperator.Contains, items);
			var nameFilter11 = new sap.ui.model.Filter("Customer", sap.ui.model.FilterOperator.Contains, items);
			var nameFilter12 = new sap.ui.model.Filter("status", sap.ui.model.FilterOperator.Contains, items);
			var filter = [nameFilter5, nameFilter6, nameFilter7, nameFilter8, nameFilter9, nameFilter10, nameFilter11, nameFilter12];
			var filters = new sap.ui.model.Filter(filter, false);
			tableItems.filter(filters);
			this._oResponsivePopover.close();
		},
		onAscending: function(oEvent) {
			var that = this,
				oTable = that.selectedTable,
				text = oEvent.getSource().getContent()[0].getItems()[0].getText(),
				oBinding,
				sPath = that.columnPath[0].path,
				bDescending,
				aSorters = [];
			// checking selcted sort by
			if (text === "Ascending") {
				bDescending = true;
			} else {
				bDescending = false;
			}
			aSorters.push(new Sorter(sPath, bDescending));
			oBinding = oTable.getBinding("items");
			// apply the selected sort and group settings
			oBinding.sort(new Sorter(sPath, bDescending));
			oTable.getModel().refresh();
			this._oResponsivePopover.close();
		},
		onDescending: function(oEvent) {
			var that = this,
				oTable = that.selectedTable,
				text = oEvent.getSource().getContent()[0].getItems()[0].getText(),
				oBinding,
				sPath = that.columnPath[0].path,
				bDescending,
				aSorters = [];
			// checking selcted sort by
			if (text === "Ascending") {
				bDescending = false;
			} else {
				bDescending = true;
			}
			aSorters.push(new Sorter(sPath, bDescending));
			oBinding = oTable.getBinding("items");
			// apply the selected sort and group settings
			oBinding.sort(new Sorter(sPath, bDescending));
			oTable.getModel().refresh();
			this._oResponsivePopover.close();
		},
		onRefresh: function() {

			var that = this;
			var oTable = this.selectedTable,
				sFilters = [];

			if (that.sKey === "All") {
				sFilters.push(new sap.ui.model.Filter("status", sap.ui.model.FilterOperator.Contains, ""));
			} else if (that.sKey === "Success") {
				sFilters.push(new sap.ui.model.Filter("status", sap.ui.model.FilterOperator.Contains, "03"));
			} else if (that.sKey === "failed") {
				sFilters.push(new sap.ui.model.Filter("status", sap.ui.model.FilterOperator.Contains, "04"));
			}
			var sInpFilter = new sap.ui.model.Filter({
				filters: sFilters,
				and: true
			});
			var oBinding = oTable.getBinding("items");
			// apply the selected sort and group settings
			oBinding.sort(null);
			oBinding.filter(sInpFilter);
		}
	});
});