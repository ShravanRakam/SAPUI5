sap.ui.define([
	"sap/ui/core/mvc/Controller",
	"sap/ui/model/json/JSONModel",
	"sap/ui/model/Filter",
	"sap/ui/model/FilterOperator",
	"sap/m/MessageBox"
], function(Controller, JSONModel, Filter, FilterOperator, MessageBox) {
	"use strict";

	return Controller.extend("demo.globalodataInterfaceGlobal.controller.View1", {

		onInit: function() {
			var that = this;
			that.getView().setModel(new sap.ui.model.json.JSONModel({
				currentTime: this.LocalTime()
			}));
			setInterval(function() {
				this.getView().getModel().setProperty("/currentTime", this.LocalTime());
			}.bind(this), 1000);

			//Date and Time Format in particular selected combo items//

			var DateModel = new JSONModel({
				"eDate": "",
				"eTime": "",
				"sDate": "",
				"sTime": "",
				"DefaultValue": "",
				"transTypVal": "",
				"statusVal": ""
			});
			that.getView().setModel(DateModel, "DateModel");
			//Ajax
			this.getAjaxHeadConfig();
			//Internal Combo datas for Particular item//

			var sPath = $.sap.getModulePath("demo.globalodataInterfaceGlobal", "/model/status.json");
			var sPath2 = $.sap.getModulePath("demo.globalodataInterfaceGlobal", "/model/tType.json");
			var sPath3 = $.sap.getModulePath("demo.globalodataInterfaceGlobal", "/model/outbound.json");

			var Outbound = new JSONModel(sPath3);
			that.getView().setModel(Outbound, "outBoundModel");

			var statusModel = new sap.ui.model.json.JSONModel(sPath);
			this.getView().setModel(statusModel, "statusModel");

			var ttypeModel = new sap.ui.model.json.JSONModel(sPath2);
			this.getView().setModel(ttypeModel, "ttypeModel");

			var interfaceModel = new JSONModel();
			that.getView().setModel(interfaceModel, "interfaceModel");
			sap.ui.getCore().setModel(interfaceModel, "interfaceModel");

			// var DynModel = new JSONModel();
			// that.getView().setModel(DynModel, "DynamicModel");

			// var odataModel = that.getOwnerComponent().getModel("mainModel");

			// //Calling Filters for Extuser and filtered "NALAJAP" for access//	
			// var Filters = [];
			// Filters.push(new sap.ui.model.Filter("Extuser", sap.ui.model.FilterOperator.EQ, "NALAJAP"));

			// odataModel.read("/UserSet", {
			// 	filters: Filters,
			// 	success: function(data, res) {
			// 		if (res.statusCode === "200" || res.statusCode === 200) {

			// 			var oData = {
			// 				results: []
			// 			};
			// 			var intKey = {};
			// 			var arr = [];
			// 			data.results.forEach(function(item) {
			// 				var index = oData.results.findIndex(function(sItem) {
			// 					return sItem.Interface === item.Interface;
			// 				});
			// 				if (item.INTERFACE_DES.includes("Outbound Delivery Interface")) {
			// 					if (item.DEFAULTINF === 'X') {
			// 						that.getView().getModel("DateModel").setProperty("/DefaultValue", item.INTKEY);
			// 						that.DefaultValue = item.INTKEY;
			// 					}
			// 					intKey = item;
			// 					arr.push(intKey);
			// 				}
			// 				if (index === -1) {
			// 					oData.results.push(item);
			// 				}
			// 			});

			// 			that.getView().getModel("interfaceModel").setData({
			// 				"UserSet": oData.results

			// 			});
			// 		}
			// 	},
			// 	error: function(error) {
			// 		var errorMsg = JSON.parse(error.responseText).error.message;
			// 		sap.m.MessageToast.show(errorMsg);
			// 	}

			// });
		},
		getAjaxHeadConfig: function() {
			var that = this;
			var sModel = that.getOwnerComponent().getModel("mainModel");
			// that.fnCreateBusyDialog("pallet.svg");
			sModel.read("/ConfigSet('A')", {
				success: function(oData) {
					var settings = {
						"async": true,
						"crossDomain": true,
						"url": oData.ServerUrl,
						"headers": {
							"Access-Control-Allow-Origin": "*",
							"Access-Control-Allow-Methods": "GET, POST, PUT, DELETE, OPTIONS",
							"client_id": oData.ClientId,
							"client_secret": oData.ClientSecret,
							"cache-control": "no-cache"
						}
					};
					var jsonModel = new JSONModel(settings);
					jsonModel.setDefaultBindingMode("OneWay");
					that.getView().setModel(jsonModel, "ajaxHeaderModel");
					// calling interface list service.
					that.UserSet();
					// that.oInsCreateDailog.close();
				},
				error: function(oResponse) {
					that.oInsCreateDailog.close();
					that.errMsgReturn(oResponse);
				}
			});
		},
		UserSet: function() {
			var that = this;
			var odataModel = that.getOwnerComponent().getModel("mainModel");

			//Calling Filters for Extuser and filtered "NALAJAP" for access//	
			var Filters = [];
			Filters.push(new sap.ui.model.Filter("Extuser", sap.ui.model.FilterOperator.EQ, "NALAJAP"));

			odataModel.read("/UserSet", {
				filters: Filters,
				success: function(data, res) {
					if (res.statusCode === "200" || res.statusCode === 200) {

						var oData = {
							results: []
						};
						var intKey = {};
						var arr = [];
						data.results.forEach(function(item) {
							var index = oData.results.findIndex(function(sItem) {
								return sItem.Interface === item.Interface;
							});

							if (index === -1) {
								oData.results.push(item);
							}
							if (item.INTERFACE_DES.includes("Outbound Delivery Interface")) {
								if (item.DEFAULTINF === 'X') {
									that.getView().getModel("DateModel").setProperty("/DefaultValue", item.INTKEY);
									that.DefaultValue = item.INTKEY;
								}
								intKey = item;
								arr.push(intKey);
							}
						});

						that.getView().getModel("interfaceModel").setData({
							"UserSet": oData.results

						});
					}
				},
				error: function(error) {
					var errorMsg = JSON.parse(error.responseText).error.message;
					sap.m.MessageToast.show(errorMsg);
				}

			});
		},
		//ComboBox Selectionchange event//

		onInterfaceChange: function(oEvent) {
			var that = this;
			//DateView function Calling in Combobox Selectionchange event//
			that.DateView();

			//Combodata Userset key//
			that.sKey = oEvent.getSource().getSelectedKey();

			// var outData = this.getView().getModel("outBoundModel").getData();

			var form = that.getView().byId("simpleForm");
			for (var i = form.getContent().length - 1; i >= 0; i--) {
				if (i !== 0 && i !== 1 && i !== 2) {
					form.removeContent(form.getContent()[i].getId());
				}
			}

			if (that.sKey !== "") {
				that.getDynamicFormSet(that.sKey);
			}
			form.addContent(new sap.ui.core.Title());
			// form.addContent(new sap.ui.core.Title());
		},
		DateView: function() {
			var sDate = new Date();
			var dateFormat = sap.ui.core.format.DateFormat.getDateInstance({
				style: "full",
				pattern: "MM-dd-YYYY"
			});
			var timeFormat = sap.ui.core.format.DateFormat.getTimeInstance({
				style: "full",
				pattern: "hh:mm:ss"
			});
			this.currDate = dateFormat.format(sDate);
			this.currTime = timeFormat.format(sDate);

			this.getView().getModel("DateModel").setProperty("/eDate", this.currDate);
			this.getView().getModel("DateModel").setProperty("/sDate", this.currDate);
			this.getView().getModel("DateModel").setProperty("/eTime", this.currTime);
			this.getView().getModel("DateModel").setProperty("/sTime", "00:00:01");
		},
		getDynamicFormSet: function(intrfc) {
			var that = this;
			var odataModel = that.getOwnerComponent().getModel("mainModel");

			var Filters = [
				new Filter("Interface", FilterOperator.EQ, intrfc),
				new Filter("Spras", FilterOperator.EQ, "EN")
			];

			odataModel.read("/DynamicFormSet", {
				filters: Filters,
				success: function(oData, res) {
					if (res.statusCode === "200" || res.statusCode === 200) {

						that.obj = {
							"interfaceId": "",
							"elements": []
						};
						//mule ajax call
						if (that.obj.interfaceId === "") {
							that.obj.interfaceId = oData.results[0].Interface;
						}
						//mule Global object//
						that.modelObj = {};
						oData.results.forEach(function(item) {
							var index = that.obj.elements.findIndex(function(sItem) {
								return sItem.Controlid === item.Controlid;
							});

							if (intrfc === item.Interface && index === -1) {
								that.obj.elements.push(item);
								// dObj.muleID.push(item);

							}
							that.modelObj[item.MuleID] = "";

							var oModel = new JSONModel(that.modelObj);
							that.getView().setModel(oModel, "dynamicModel");
						});

						var form = that.getView().byId("simpleForm");
						for (var i = form.getContent().length - 1; i >= 0; i--) {
							if (i !== 0 && i !== 1 && i !== 2) {
								form.removeContent(form.getContent()[i].getId());
							}
						}

						that.obj.elements.forEach(function(element) {

							var label, control;

							label = new sap.m.Label({
								text: element.Lablekey,
								design: "Bold"

							});

							form.addContent(label);

							if (element.Controlname === "sap.m.ComboBox") {

								control = new sap.m.ComboBox({
									// selectedKey:"{outBoundModel>/SysDest/0/addText}",
									name: element.Controlid,
									showSecondaryValues: true

								});
								form.addContent(control);

								if (element.Controlid === "sysDesn") {

									var oTemplate = new sap.ui.core.ListItem({

										key: "{outBoundModel>addText}",
										text: "{outBoundModel>text}",
										additionalText: "{outBoundModel>addText}"

									});

									control.bindItems("outBoundModel>/SysDest", oTemplate);
									control.applySettings({
										selectedKey: "{DateModel>/DefaultValue}"
									});

								} else if (element.Controlid === "status") {
									if (element.Interface === "aperture-jda-sap-order" || element.Interface === "aperture-sf-sap-audit" || element.Interface ===
										"aperture-sf-bw-contacts-us") {
										var oTemplate = new sap.ui.core.ListItem({
											key: "{statusModel>additionaltext}",
											text: "{statusModel>text}",
											additionalText: "{statusModel>additionaltext}"

										});

										control.bindItems("statusModel>/SAPJDAInterfaceStatus", oTemplate);
										control.applySettings({
											selectedKey: "{DateModel>/statusVal}"
										});

									} else if (element.Interface === "sam-brix-sap-confirmations-global" || element.Interface ===
										"sam-brix-sap-scActivities-global" || element.Interface === "tms-by-sap-shipment-global") {
										var oTemplate = new sap.ui.core.ListItem({
											key: "{statusModel>additionaltext}",
											text: "{statusModel>text}",
											additionalText: "{statusModel>additionaltext}"

										});

										control.bindItems("statusModel>/BRIXInboundStatus", oTemplate);

										control.applySettings({
											selectedKey: "{DateModel>/statusVal}"
										});
									} else if (element.Interface === "tms-sap-by-delivery-global") {
										var oTemplate = new sap.ui.core.ListItem({
											key: "{statusModel>additionaltext}",
											text: "{statusModel>text}",
											additionalText: "{statusModel>additionaltext}"

										});

										control.bindItems("statusModel>/OutboundDeliveryStatus", oTemplate);

										control.applySettings({
											selectedKey: "{DateModel>/statusVal}"
										});
									}

								} else if (element.Controlid === "transType") {
									if (element.Interface === "aperture-jda-sap-order") {
										var oTemplate = new sap.ui.core.ListItem({
											key: "{ttypeModel>additionaltext}",
											text: "{ttypeModel>text}",
											additionalText: "{ttypeModel>additionaltext}"

										});
										control.applySettings({
											selectedKey: "{DateModel>/transTypVal}"
										});
										control.bindItems("ttypeModel>/SAPJDAInterfaceTransaction", oTemplate);

									} else if (element.Interface === "aperture-sf-sap-audit") {
										var oTemplate = new sap.ui.core.ListItem({
											key: "{ttypeModel>additionaltext}",
											text: "{ttypeModel>text}",
											additionalText: "{ttypeModel>additionaltext}"

										});
										control.applySettings({
											selectedKey: "{DateModel>/transTypVal}"
										});
										control.bindItems("ttypeModel>/ApertureAuditTransaction", oTemplate);
									} else if (element.Interface === "aperture-sf-sap-customer") {
										var oTemplate = new sap.ui.core.ListItem({
											key: "{ttypeModel>additionaltext}",
											text: "{ttypeModel>text}",
											additionalText: "{ttypeModel>additionaltext}"

										});
										control.applySettings({
											selectedKey: "{DateModel>/transTypVal}"
										});
										control.bindItems("ttypeModel>/ApertureCustomerTransaction", oTemplate);
									} else if (element.Interface === "sam-brix-sap-confirmations-global") {
										var oTemplate = new sap.ui.core.ListItem({
											key: "{ttypeModel>additionaltext}",
											text: "{ttypeModel>text}",
											additionalText: "{ttypeModel>additionaltext}"

										});
										control.applySettings({
											selectedKey: "{DateModel>/transTypVal}"
										});
										control.bindItems("ttypeModel>/BRIXInboundConfirmationsTransaction", oTemplate);
									} else if (element.Interface === "sam-brix-sap-scActivities-global") {
										var oTemplate = new sap.ui.core.ListItem({
											key: "{ttypeModel>additionaltext}",
											text: "{ttypeModel>text}",
											additionalText: "{ttypeModel>additionaltext}"

										});
										control.applySettings({
											selectedKey: "{DateModel>/transTypVal}"
										});
										control.bindItems("ttypeModel>/BRIXInboundPIMSTransaction", oTemplate);
									} else if (element.Interface === "tms-by-sap-shipment-global") {
										var oTemplate = new sap.ui.core.ListItem({
											key: "{ttypeModel>additionaltext}",
											text: "{ttypeModel>text}",
											additionalText: "{ttypeModel>additionaltext}"

										});
										control.applySettings({
											selectedKey: "{DateModel>/transTypVal}"
										});
										control.bindItems("ttypeModel>/InboundShipmentTransaction", oTemplate);
									} else if (element.Interface === "tms-sap-by-delivery-global") {
										var oTemplate = new sap.ui.core.ListItem({
											key: "{ttypeModel>additionaltext}",
											text: "{ttypeModel>text}",
											additionalText: "{ttypeModel>additionaltext}"

										});
										control.applySettings({
											selectedKey: "{DateModel>/transTypVal}"
										});
										control.bindItems("ttypeModel>/OutboundDeliveryTransaction", oTemplate);
									}
								}
							} else if (element.Controlname === "sap.m.Input") {
								control = new sap.m.Input({
									name: element.Controlid,
									change: function(oEvent) {
										that.onDelNoChange(oEvent);
									},
									enableMultiLineMode: true,
									placeholder: "",
									showValueHelp: false

								});

								form.addContent(control);
							} else if (element.Controlname === "sap.m.DatePicker") {
								if (element.Controlid === "startDate") {
									control = new sap.m.DatePicker({
										name: element.Controlid,
										value: "{DateModel>/sDate}",
										valueFormat: "MM-dd-yyyy",
										displayFormat: "MM-dd-yyyy"

										// value:new Date()

									});
									form.addContent(control);
								} else if (element.Controlid === "endDate") {
									control = new sap.m.DatePicker({
										name: element.Controlid,
										value: "{DateModel>/eDate}",
										valueFormat: "MM-dd-yyyy",
										displayFormat: "MM-dd-yyyy"

										// value:new Date()

									});
									form.addContent(control);

								}
							} else if (element.Controlname === "sap.m.TimePicker") {
								if (element.Controlid === "startTime") {
									control = new sap.m.TimePicker({

										name: element.Controlid,
										value: "{DateModel>/sTime}",
										displayFormat: "hh:mm:ss",
										valueFormat: "MM-dd-yyyy",

									});
									form.addContent(control);
								} else if (element.Controlid === "endTime") {
									control = new sap.m.TimePicker({

										name: element.Controlid,
										displayFormat: "hh:mm:ss",
										valueFormat: "MM-dd-yyyy",
										value: "{DateModel>/eTime}"

									});
									form.addContent(control);
								}
							} else if (element.Controlname === "sap.m.MultiInput") {

								control = new sap.m.MultiInput({
									name: element.Controlid

								});

								control.addValidator(function(args) {
									var oToken = new sap.m.Token({
										key: args.text,
										text: args.text
									});
									args.asyncCallback(oToken);
									return sap.m.MultiInput.WaitForAsyncValidation;

								});
								form.addContent(control);

							}

						});

						form.addContent(new sap.m.Label({
							text: ""

						}));
						form.addContent(new sap.m.Button({
							press: function(oEvent) {
								that.onSearch(oEvent);
							},
							text: "Search",
							tooltip: "Search",
							type: "Emphasized",
							class: "sapUiMediumMarginBegin",
							layoutData: new sap.ui.layout.GridData({
								span: "XL8 L12 M8 S8"
							})

						}));

						form.addContent(new sap.m.Button({
							press: function(oEvent) {
								that.onClear(oEvent);
							},
							text: "Clear",
							tooltip: "Clear",
							type: "Reject",
							layoutData: new sap.ui.layout.GridData({
								span: "XL8 L12 M8 S8"
							})

						}));

						form.addContent(new sap.m.Button({
							press: function(oEvent) {
								that.onBack(oEvent);
							},
							text: "Back",
							tooltip: "Back",
							type: "Reject",
							class: "sapUiMediumMarginBegin",
							layoutData: new sap.ui.layout.GridData({
								span: "XL8 L12 M8 S8"
							})

						}));
						form.addContent(new sap.ui.core.Title());
					}
				}

			});
		},
		LocalTime: function() {
			var date = new Date();
			var dateformat = sap.ui.core.format.DateFormat.getDateInstance({
				style: 'full',
				pattern: "EEEE, MMMM dd, YYYY hh:mm:ss a"
			});
			var DFormat = dateformat.format(date);
			return DFormat;
		},
		onSearch: function(oEvent) {
			var that = this;
			var obj = {};
			obj.interfaceId = that.obj.interfaceId;
			var array = [];
			var dynamicData = that.getView().getModel("dynamicModel").getData();
			var fContent = that.getView().byId("simpleForm").getContent();
			for (var i = 4; i < fContent.length; i++) {

				if (fContent[i].getId().includes("box") === true) {

					if (fContent[i].getName() === "sysDesn") {

						var value = fContent[i].getSelectedKey();
						obj.sysDesn = value;
					} else if (fContent[i].getName() === "transType") {
						var value3 = fContent[i].getSelectedKey();
						obj.transType = value3;
					} else if (fContent[i].getName() === "status") {
						var value4 = fContent[i].getSelectedKey();
						obj.status = value4;
					}

				}
				if (fContent[i].getId().includes("input") === true) {
					if (fContent[i].getName() === "delNo") {

						if (fContent[i].getTokens().length > 0) {

							fContent[i].getTokens().forEach(function(item) {
								var delno1 = item.getText();
								// obj.delNo = delno1;

								array.push(delno1);

							});
							obj.delNo = array;
						}
					} else if (fContent[i].getName() === "salOrg") {
						var sales = [];
						if (fContent[i].getTokens().length > 0) {
							fContent[i].getTokens().forEach(function(item) {
								var salesOrg = item.getText();
								// obj.delNo = delno1;

								sales.push(salesOrg);

							});
							obj.salesOrg = sales;
						}
					} else if (fContent[i].getName() === "shipmentNo") {
						var shipment = [];
						if (fContent[i].getTokens().length > 0) {
							fContent[i].getTokens().forEach(function(item) {
								var shipmentNo = item.getText();
								// obj.delNo = delno1;

								shipment.push(shipmentNo);

							});
							obj.shipmentNo = shipment;
						}
					} else if (fContent[i].getName() === "regionCode") {
						var region = [];
						if (fContent[i].getTokens().length > 0) {
							fContent[i].getTokens().forEach(function(item) {
								var regionCode = item.getText();
								// obj.delNo = delno1;

								region.push(regionCode);

							});
							obj.regionCode = region;
						}
					}
				
				}

				if (fContent[i].getId().includes("picker") === true) {

					if (fContent[i].getName() === "startDate") {
						var picker = fContent[i].getValue();
						obj.startDate = picker;
					} else if (fContent[i].getName() === "endDate") {
						var picker1 = fContent[i].getValue();
						obj.endDate = picker1;
					} else if (fContent[i].getName() === "startTime") {
						var picker2 = fContent[i].getValue();
						obj.startTime = picker2;
					} else if (fContent[i].getName() === "endTime") {
						var picker3 = fContent[i].getValue();
						obj.endTime = picker3;
					}

				}
			}
			console.log(obj);
			// that.getSapservice(obj);

			// if (that.sKey === "tms-by-sap-shipment-global") {
			// 	var oRouter = sap.ui.core.UIComponent.getRouterFor(this);
			// 	oRouter.navTo("Inbound", {
			// 		obj: JSON.stringify(obj)
			// 	});
			// } 
			if (that.sKey === "tms-sap-by-delivery-global") {
				var oRouter1 = sap.ui.core.UIComponent.getRouterFor(this);
				oRouter1.navTo("Outbound", {
					obj: JSON.stringify(obj)
				});
			}
			if (that.sKey.includes("sap-by")) {
				that.getSapService(obj);
			} else {
				if (obj.startTime !== "00:00:00" && obj.endTime !== "00:00:00") {
					var stDate = obj.startDate.split("-");
					var stTime = obj.startTime.split(":");
					var enDate = obj.endDate.split("-");
					var enTime = obj.endTime.split(":");
					var convStDate = that.convertLocalDateToUTCDate(new Date(stDate[2], stDate[0] - 1, stDate[1], stTime[0], stTime[1], stTime[2]),
						true);
					var convEnDate = that.convertLocalDateToUTCDate(new Date(enDate[2], enDate[0] - 1, enDate[1], enTime[0], enTime[1], enTime[2]),
						true);
					var dateFormat = sap.ui.core.format.DateFormat.getDateInstance({
						style: 'full',
						pattern: "MM-dd-YYYY"
					});
					var timeFormat = sap.ui.core.format.DateFormat.getTimeInstance({
						style: 'full',
						pattern: "HH:mm:ss"
					});
					var sDate = dateFormat.format(convStDate);
					var eDate = dateFormat.format(convEnDate);
					var sTime = timeFormat.format(convStDate);
					var eTime = timeFormat.format(convEnDate);
				}
				var startDate = sDate + " " + sTime;
				var endDate = eDate + " " + eTime;
				var viewName = "Inbound";
				obj.startDate = startDate;
				obj.endDate = endDate;
				// removing start time and end time fields. 
				delete obj.startTime;
				delete obj.endTime;
				that.getAllSapService(obj);

			}

		},
		getAllSapService: function(obj) {
			var that = this,
				sPath, str = "",
				modelData = JSON.stringify(that.getView().getModel("ajaxHeaderModel").getData()),
				settings = JSON.parse(modelData);
			that.inferfaceType = that.obj.interfaceId;
			if (obj.transactionType !== "" && (that.inferfaceType === "aperture-sf-sap-customer" || that.inferfaceType ===
					"aperture-sf-sap-audit")) {
				obj.interfaceId = obj.transactionType;
				obj.transactionType = "";
			} else if (obj.transactionType === "" && (that.inferfaceType === "aperture-sf-sap-customer" || that.inferfaceType ===
					"aperture-sf-sap-audit")) {
				obj.interfaceId = "";
			}
			if (obj.interfaceId !== "" && (obj.startDate !== "" && obj.endDate !== "")) {
				// Timestamp and interface id based Ajax call trigger here.
				sPath = "getByTimestamp?";
			} else {
				// get Data by Delivery Number Ajax service call will start here.
				sPath = "getById?";
			}
			Object.entries(obj).forEach(function([key, value], index) {
				if (value !== "") {
					str += key + "=" + value;
					if (Object.entries(obj).length !== index) {
						str += "&"
					}
				}
			});
			settings.url = settings.url + sPath + str;
			settings.method = "GET";
			that.getMuleService(settings, obj);
		},
		getMuleService: function(settings, obj) {
			var that = this;
			var oModel = new JSONModel();
			$.ajax(settings).success(function(response) {
				var oData = {
					"modelData": response
				}
				var oModel = new JSONModel(oData);
				oModel.setSizeLimit(oData.modelData.length);
				sap.ui.getCore().setModel(oModel, "oMuelTabModel");

				console.log(oData);
				if (response.length === 0) {
					var msg = "Error Message";
					MessageBox.show(msg);
				} else {
					var oRouter = sap.ui.core.UIComponent.getRouterFor(that);
					oRouter.navTo("Inbound", {
						obj: JSON.stringify(obj)
					});
				}
			}).error(function(error) {
				oModel.setData({
					"modelData": []
				});
				that.getView().setModel(oModel, "oMuelTabModel");
			});
		},
		convertLocalDateToUTCDate: function(date, toUTC) {
			date = new Date(date);
			//Local time converted to UTC
			var localOffset = date.getTimezoneOffset() * 60000;
			var localTime = date.getTime();
			if (toUTC) {
				date = localTime + localOffset;
			} else {
				date = localTime - localOffset;
			}
			date = new Date(date);
			return date;
		},
		dateFormatChange: function(date) {
			var yyyy = date.split("-")[2];
			var mm = date.split("-")[0];
			var dd = date.split("-")[1];
			if (mm.length === 1) {
				mm = '0' + mm;
			} else if (dd.length === 1) {
				dd = '0' + dd;
			}

			var newDate = yyyy + mm + dd;
			return newDate;
		},

		getSapservice: function(object) {
			var that = this;
			var TableModel = new JSONModel();
			that.getView().setModel(TableModel, "TableMod");
			sap.ui.getCore().setModel(TableModel, "TableMod");
			var Filters = [
				new Filter("destination", FilterOperator.EQ, object.sysDesn),
				new Filter("trtyp", FilterOperator.EQ, object.transType),
				new Filter("status", FilterOperator.EQ, object.status)
			];
			var oData = that.getOwnerComponent().getModel("mainModel");
			oData.read("/InboundSet", {
				filters: Filters,
				success: function(oData, res) {
					if (res.statusCode === "200" || res.statusCode === 200) {
						that.getView().getModel("TableMod").setData(oData.results);
					}
				}
			});
		},
		onClear: function() {
			this.getView().getModel("DateModel").setProperty("/transTypVal", "");
			this.getView().getModel("DateModel").setProperty("/DefaultValue", "");
			this.getView().getModel("DateModel").setProperty("/statusVal", "");
			this.getView().getModel("DateModel").setProperty("/sDate", "");
			this.getView().getModel("DateModel").setProperty("/eDate", "");
			this.getView().getModel("DateModel").setProperty("/sTime", "");
			this.getView().getModel("DateModel").setProperty("/eTime", "");
			var form = this.getView().byId("simpleForm");
			var contents = form.getContent();
			contents.forEach(function(item) {
				if (item.getMetadata().getElementName() === "sap.m.MultiInput") {
					if (item.getTokens().length !== 0) {
						item.removeAllTokens();
					}
				}
			});

		},
		onBack: function(oEvent) {
			var that = this;
			var form = that.getView().byId("simpleForm");
			for (var i = form.getContent().length - 1; i >= 0; i--) {
				if (i !== 0 && i !== 1 && i !== 2) {
					form.removeContent(form.getContent()[i].getId());
				}
			}
			form.addContent(new sap.ui.core.Title());
			var sData = that.getView().getModel("DateModel");
			sData.setProperty("/interfaceId", "");

		}

	});
});