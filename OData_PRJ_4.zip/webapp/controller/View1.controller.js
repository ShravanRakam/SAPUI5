sap.ui.define([
	"sap/ui/core/mvc/Controller",
	"sap/ui/model/json/JSONModel",
	"sap/m/TablePersoController",
	"../model/Persocode",
	"sap/m/MessageToast",
	"sap/m/MessageBox"
], function(Controller, JSONModel, TablePersoController, Persocode, MessageToast, MessageBox) {
	"use strict";

	return Controller.extend("oDataOperation1oDataOperation1.controller.View1", {
		onInit: function() {
			var that = this;
			that.odatamodel();
			// that.Table = new TablePersoController({
			// 	//table is association name
			// 	table: that.getView().byId("id1"),
			// 	ComponentName: "",
			// 	//persoservice is a aggregation
			// 	persoService: Persocode
			// }).activate();

		},
		odatamodel: function() {
			var that = this;
			var url = "/sap/opu/odata/sap/ZEMPLOYEE_SRV/";
			var oModel1 = new sap.ui.model.odata.ODataModel(url, true);
			oModel1.read("/zempSet", {
				success: function(oData) {
					var oModel = new JSONModel(oData);
					that.getView().setModel(oModel, "table");
					MessageToast.show("Data Loaded successfully");
				}
			});
		},
		onCreate: function() {
			var oCreateModel = new JSONModel({
				Empno: "",
				Empname: "",
				Street: "",
				City: "",
				Postalcode: "",
				Country: ""
			});
			this.getView().setModel(oCreateModel, "formModel");
			var visibleModel = new JSONModel(oCreateModel);
			this.getView().setModel(visibleModel, "buttonModel");
			this.getView().getModel("buttonModel").setProperty("/onAddDataVisible", true);
			this.getView().getModel("buttonModel").setProperty("/onUpdateVisible", false);

			if (!this.oDialog) {
				this.oDialog = sap.ui.xmlfragment("oDataOperation1oDataOperation1.view.Fragment", this);
				this.getView().addDependent(this.oDialog);
			}

			this.oDialog.open();

		},
		onCancel: function() {
			this.oDialog.close();
			this.oDialog.destroy();
			this.oDialog = null;
		},
		onAddData: function() {
			var that = this;
			var sUrl = "/sap/opu/odata/sap/ZEMPLOYEE_SRV/";
			var oModel = new sap.ui.model.odata.ODataModel(sUrl, true);
			var formData = that.getView().getModel("formModel").getData();
			oModel.create("/zempSet", formData, {
				success: function(Data) {
					MessageToast.show("record Created Successfuly");
				}
			});
			this.onCancel();
			this.odatamodel().refresh();

		},
		onDeleteItem: function(oEvent) {
			// var that = this;
			var source = oEvent.getSource();
			var selecteditem = source.getBindingContext("table").getObject().Empno;
			var url = "/sap/opu/odata/sap/ZEMPLOYEE_SRV/";
			var oDatamodel = new sap.ui.model.odata.ODataModel(url, true);
			oDatamodel.remove("/zempSet('" + selecteditem + "')", {
				success: function(oData) {
					MessageBox.show("Deleted Successfully");
				}
			});
			this.odatamodel().refresh();
		},
		onUpdateOpen: function(event) {
			this.onCreate();
			var source = event.getSource();
			var selecteditem = source.getBindingContext("table").getObject();
			var newModel = new JSONModel(selecteditem);
			this.getView().setModel(newModel, "formModel");
			this.getView().getModel("buttonModel").setProperty("/onAddDataVisible", false);
			this.getView().getModel("buttonModel").setProperty("/onUpdateVisible", true);

		},
		onUpdate: function() {
			var url = "/sap/opu/odata/sap/ZEMPLOYEE_SRV/";
			var oDatamodel = new sap.ui.model.odata.ODataModel(url, true);
			var formdata = this.getView().getModel("formModel").getData();
			oDatamodel.update("/zempSet('" + formdata.Empno + "')", formdata, {
				success: function(oData) {
					MessageToast.show("Updated successfully Successfully");
				}
			});
			this.onCancel();
			this.odatamodel().refresh();
		},
		onSearch: function(oevent) {
			var source = oevent.getSource();
			var searchitem = source.getValue();
			var tabledata = this.getView().byId("tableid");
			var tableitem = tabledata.getBinding("items");
			var filtername = new sap.ui.model.Filter("Empname", sap.ui.model.FilterOperator.Contains, searchitem);
			tableitem.filter(filtername);
		},
		// persoPress: function() {
		// 	this.Table.openDialog();
		// }

	});
});