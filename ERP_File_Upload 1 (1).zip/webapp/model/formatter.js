jQuery.sap.require("sap.ui.core.format.DateFormat");
sap.ui.define(["sap/ui/core/format/NumberFormat"],
function(NumberFormat) {
		return {
			/*fragment for custome date*/
		Date1: function(date1) {
			var dateFormat = sap.ui.core.format.DateFormat.getDateInstance({
				pattern: "YYYY/MM/dd"
			});
			var dateFormatted = dateFormat.format(date1);

			return dateFormatted;
		},
			DateFormat: function (sValue) {
				var FormatedDate;
				if (sValue === null || sValue === undefined || sValue === "" || sValue === "00000000") {
					FormatedDate = "";
				} else {
					if (new Date(sValue).toString() === "Invalid Date") {
						var year = sValue.slice("0", "4");
						var month = sValue.slice("4").slice("0", "2");
						var day = sValue.slice("6");
						FormatedDate = day + "/" + month + "/" + year;
							// FormatedDate = year + "/" + month + "/" + day;
					} else {
						var delvDate = sValue;
						var oDay = delvDate.getDate();
						var oMonth = delvDate.getMonth() + 1;
						if (oMonth.toString().length > 1) {
							oMonth = oMonth;
						} else {
							oMonth = "0" + oMonth;
						}
						var oYear = delvDate.getFullYear();
						FormatedDate = oDay + "/" + oMonth + "/" + oYear;
						// FormatedDate = oYear + "/" + oMonth + "/" + oDay;
					}
				}
				return FormatedDate;

			},
			onFormatColor:function(oText){
				var colorFormat;
				if(oText === "No error found" || oText === "Successfully updated"){
					colorFormat = "Success";
				}else 	if(oText === "More than 4 activities/WBS not allowed"){
					colorFormat = "None";
				}else{
						colorFormat = "Error";
				}
				return colorFormat;
			}

		};
	});