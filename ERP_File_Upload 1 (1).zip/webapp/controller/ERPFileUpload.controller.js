/*Calling external Files From Libs folder*/
jQuery.sap.require("com.fileUpload.ERP_File_Upload.Libs.jszip");
jQuery.sap.require("com.fileUpload.ERP_File_Upload.Libs.xlsx");
var XLSX;
var verify;
var save;
var err;
var selChange;
var oFile;
var FileName;

sap.ui.define([
	"sap/ui/core/mvc/Controller",
	"sap/ui/model/json/JSONModel",
	"sap/m/MessageBox",
	"../model/formatter",
	"sap/m/MessageToast",
	"sap/ui/export/Spreadsheet",
	"sap/ui/export/library",
	"sap/ui/model/Filter",
	"sap/ui/model/FilterOperator"
], function (Controller, JSONModel, MessageBox, formatter, MessageToast, Spreadsheet, exportLibrary, Filter, FilterOperator) {
	"use strict";
	var EdmType = exportLibrary.EdmType;

	return Controller.extend("com.fileUpload.ERP_File_Upload.controller.ERPFileUpload", {
		formatter: formatter,

		onInit: function () {
			var that = this;
			
			var sComponentName = that.getOwnerComponent().getMetadata().getComponentName();
			var staticData = $.sap.getModulePath(sComponentName, "/model/Link.json");

			var stModel = new JSONModel(staticData);
			that.getView().setModel(stModel, "stModel");

			var sampleModel = new JSONModel();
			that.getView().setModel(sampleModel, "sampleModel");

			var mainModel = new JSONModel();
			that.getView().setModel(mainModel, "mainModel");

			var deleteModel = new JSONModel();
			that.getView().setModel(deleteModel, "deleteModel");

			var dummyModel = new JSONModel();
			that.getView().setModel(dummyModel, "dummyModel");

			// var sYear = [{
			// 	year: "2024"
			// }, {
			// 	year: "2023"
			// }, {
			// 	year: "2022"
			// }, {
			// 	year: "2021"
			// }, {
			// 	year: "2020"
			// }, {
			// 	year: "2019"
			// }, {
			// 	year: "2018"
			// }, {
			// 	year: "2017"
			// }];

			var combo1 = new JSONModel();
			that.getView().setModel(combo1, "combo1");

			// that.getView().getModel("combo1").setData(sYear);

			var yearArray = [];

			var currentYear = new Date().getFullYear();

			yearArray.push(currentYear);
			var AddYear;
			for (var i = 0; i < 1; i++) {
				// if (i === 0) {
				AddYear = currentYear + 1;

				// } else {
				// 	AddYear = AddYear + 1;
				// }
				yearArray.push(AddYear);

			}

			var subYear;
			for (var j = 0; j < 3; j++) {

				if (j === 0) {
					subYear = currentYear - 1;

				} else {
					subYear = subYear - 1;
				}

				yearArray.push(subYear);

			}

			var oSorted = yearArray.sort(function (a, b) {
				return b - a;
			});
			that.getView().getModel("combo1").setData(oSorted);

			that.byId("Fyear").setSelectedKey(currentYear);
		},

		// onBrowse: function () {
		// 	var that = this;
		// 	// that.byId("delbtn").setVisible(true);
		// 	// that.byId("saveBtn").setEnabled(true);
		// 	// that.byId("verifyBtn").setEnabled(true);

		// 	// that.byId("previewBtn").setEnabled(true);

		// 	// verify = undefined;
		// 	var oFileUploader = that.getView().byId("fileUploader");

		// 	// var file = oFileUploader.getFocusDomRef().files;
		// 	var fileSet = oFileUploader.getFocusDomRef().files[0];
		// 	if (fileSet === undefined) {
		// 		that.getView().getModel("sampleModel").setData("");

		// 		that.getView().getModel("mainModel").setData("");
		// 		// that.byId("previewBtn").setEnabled(false);

		// 	} else {
		// 		// that.byId("previewBtn").setEnabled(true);
		// 	}

		// },
		/*Function For Open Button After Uploading excel files*/
		handleValueChange: function (e) {
			var that = this;

			// that.byId("verifyBtn").setEnabled(true);

			verify = undefined;
			var oFileUploader = that.getView().byId("fileUploader");

			var file = oFileUploader.getFocusDomRef().files;
			var fileSet = oFileUploader.getFocusDomRef().files[0];

			if (fileSet === undefined) {

				oFileUploader.setValue(FileName);

				// that._import(oFile && oFile[0]);

			} else {
				oFile = oFileUploader.getFocusDomRef().files;
				FileName = fileSet.name;
				that._import(file && fileSet);
				// that.byId("delbtn").setVisible(true);
				// that.byId("saveBtn").setEnabled(true);

			}

		},

		handleValueRefresh: function (e) {
			var that = this;

			// that.byId("verifyBtn").setEnabled(true);

			verify = undefined;
			var oFileUploader = that.getView().byId("fileUploader");

			var file = oFileUploader.getFocusDomRef().files;
			var fileSet = oFileUploader.getFocusDomRef().files[0];

			if (fileSet === undefined) {
				// var name = FileName[0].name;

				oFileUploader.setValue(FileName);

				that._import(oFile && oFile[0]);
			} else {
				oFile = oFileUploader.getFocusDomRef().files;
				FileName = fileSet.name;
				that._import(file && fileSet);

			}

			// if (fileSet === undefined) {
			// 	that.getView().getModel("sampleModel").setData("");

			// 	that.getView().getModel("mainModel").setData("");

			// } else {
			// that.byId("previewBtn").setEnabled(true);

			// }

		},

		_import: function (file) {
			var that = this;
			var excelData = {};
			if (file && window.FileReader) {
				var reader = new FileReader();
				reader.onload = function (e) {
					var data = e.target.result;
					var workbook = XLSX.read(data, {
						type: 'binary'
					});
					workbook.SheetNames.forEach(function (sheetName) {
						// Here is your object for every sheet in workbook
						// that.onGetExcelData(workbook,sheetName);
						excelData = that.onGetExcelData(workbook, sheetName);
						// excelData = XLSX.utils.sheet_to_row_object_array(workbook.Sheets[sheetName]);

					});
					// Setting the data to the local model 
					var sArray = [];
					var btnIndicator = [];
					for (var i = 0; i < excelData.length; i++) {
						if (i === 0) {
							continue;
						} else {

							var startDate = that.DateFormat(excelData[i][1]);
							var endDate = that.DateFormat(excelData[i][2]);

							if (startDate === "Error" && endDate !== "Error") {
								var sObj = {};
								sObj.Position = excelData[i][0];

								// var sDate = excelData[i][1];
								// if (sDate.length < 8) {
								// 	sObj.Start_date = sDate;
								// } else {
								// 	sObj.Start_date = "";
								// }
								sObj.Start_date = excelData[i][1];
								sObj.End_date = endDate;
								sObj.Posid = excelData[i][3];
								sObj.Prozt = excelData[i][4];
								sObj.Grant_nbr = excelData[i][5];
								sObj.Fincode = excelData[i][6];
								sObj.Fund_id = excelData[i][7];
								sObj.Award_type = excelData[i][8];

								sObj.Error = "Begin Date Format Error in file";
								sArray.push(sObj);

								btnIndicator.push(false);

								// that.byId("saveBtn").setEnabled(false);

								// MessageBox.error("Date Format in Uploded File is wrong.");
								// MessageBox.error(
								// 	"Date Format in Uploded File is wrong, Plesae Edit and Reupload the file : " + " ' " + FileName + " ' ", {

								// 		actions: [MessageBox.Action.OK],
								// 		emphasizedAction: MessageBox.Action.YES,
								// 		onClose: function (oAction) {
								// 			if (oAction === "OK") {
								// 				var oFileUploader = that.getView().byId("fileUploader");

								// 				oFileUploader.setValue("");
								// 				FileName = "";
								// 				oFile = "";

								// 				that.getView().getModel("sampleModel").setData("");

								// 				that.getView().getModel("mainModel").setData("");
								// 				that.byId("refereshBtn").setEnabled(false);

								// 			}
								// 		}
								// 	}
								// );
								// break;

							} else if (startDate !== "Error" && endDate === "Error") {
								var sObj = {};
								sObj.Position = excelData[i][0];
								sObj.Start_date = startDate;
								// var eDate = excelData[i][2];
								// if (eDate.length < 8) {
								// 	sObj.End_date = eDate;
								// } else {
								// 	sObj.End_date = "";
								// }
								sObj.End_date = excelData[i][2];
								sObj.Posid = excelData[i][3];
								sObj.Prozt = excelData[i][4];
								sObj.Grant_nbr = excelData[i][5];
								sObj.Fincode = excelData[i][6];
								sObj.Fund_id = excelData[i][7];
								sObj.Award_type = excelData[i][8];

								sObj.Error = "End Date Format Error in file";
								sArray.push(sObj);

								btnIndicator.push(false);

								// that.byId("saveBtn").setEnabled(false);

							} else if (startDate === "Error" && endDate === "Error") {
								var sObj = {};
								sObj.Position = excelData[i][0];
								// var sDate = excelData[i][1];
								// if (sDate.length < 8) {
								// 	sObj.Start_date = sDate;
								// } else {
								// 	sObj.Start_date = "";
								// }
								// var eDate = excelData[i][2];
								// if (eDate.length < 8) {
								// 	sObj.End_date = eDate;
								// } else {
								// 	sObj.End_date = "";
								// }
								sObj.Start_date = excelData[i][1];
								sObj.End_date = excelData[i][2];
								sObj.Posid = excelData[i][3];
								sObj.Prozt = excelData[i][4];
								sObj.Grant_nbr = excelData[i][5];
								sObj.Fincode = excelData[i][6];
								sObj.Fund_id = excelData[i][7];
								sObj.Award_type = excelData[i][8];

								sObj.Error = "Both Begin and End Date Format Error in file";
								sArray.push(sObj);

								btnIndicator.push(false);

								// that.byId("saveBtn").setEnabled(false);

							} else {

								var sObj = {};
								sObj.Position = excelData[i][0];
								sObj.Start_date = startDate;
								sObj.End_date = endDate;
								sObj.Posid = excelData[i][3];
								sObj.Prozt = excelData[i][4];
								sObj.Grant_nbr = excelData[i][5];
								sObj.Fincode = excelData[i][6];
								sObj.Fund_id = excelData[i][7];
								sObj.Award_type = excelData[i][8];

								sObj.Error = excelData[i][9];
								sArray.push(sObj);

								btnIndicator.push(true);

							}
						}

					}

					for (var j = 0; j < btnIndicator.length; j++) {
						if (btnIndicator[j] === true) {
							that.byId("saveBtn").setEnabled(true);

						} else if (btnIndicator[j] === false) {
							that.byId("saveBtn").setEnabled(false);
							break;

						}
					}

					that.getView().getModel("sampleModel").setData(sArray);

					that.getView().getModel("mainModel").setData(sArray);

					that.byId("refereshBtn").setEnabled(true);
					that.byId("delbtn").setVisible(true);

					// that.byId("previewBtn").setEnabled(false);

					// that.sampleModel.setData({
					// 	items: excelData
					// });
					// that.localModel.refresh(true);
				};
				reader.onerror = function (ex) {

					MessageBox.error(
						"Uploaded file was edited, Plesae Reupload the file : " + " ' " + FileName + " ' ", {

							actions: [MessageBox.Action.OK],
							emphasizedAction: MessageBox.Action.YES,
							onClose: function (oAction) {
								if (oAction === "OK") {
									var oFileUploader = that.getView().byId("fileUploader");

									oFileUploader.setValue("");
									FileName = "";
									oFile = "";

									that.getView().getModel("sampleModel").setData("");

									that.getView().getModel("mainModel").setData("");
									that.byId("refereshBtn").setEnabled(false);

								}
							}
						}
					);

					// MessageBox.error("Uploaded file was edited, Plesae Reupload the file"+FileName);

					// MessageBox.error(ex.target.error.message);

					// console.log(ex);
				};
				reader.readAsBinaryString(file);
			}
		},

		DateFormat: function (sValue) {
			var FormatedDate, day, month, year, oError;

			var sDate = parseInt(sValue);
			sDate = sDate.toString();

			// if (sValue.includes("/") === true) {
			// 	var oSplit = sValue.split("/");
			// 	day = oSplit[0];
			// 	month = oSplit[1];
			// 	year = oSplit[2];

			// 	if (day.toString().length > 1) {
			// 		day = day;
			// 	} else {
			// 		day = "0" + day;
			// 	}
			// 	if (month.toString().length > 1) {
			// 		month = month;
			// 	} else {
			// 		month = "0" + month;
			// 	}
			// 	if (year.toString().length === 4) {
			// 		year = year;
			// 	} else {
			// 		year = "20" + year;
			// 	}

			// 	FormatedDate = day + "/" + month + "/" + year;

			// 	// return FormatedDate;
			// } else 

			// if (sValue.length === 7) {
			// 	sValue = 0 + sValue;

			// }
			if (sValue.length === 8) {
				// var oSplit = sValue.split("/");

				// var len = sValue.length;
				// if (len === 8) {
				day = sValue.slice(0, 2);
				month = sValue.slice(2, 4);
				year = sValue.slice(4);
				// } 

				if (day.toString().length > 1 && day <= 31) {
					day = day;
				} else if (day.toString().length === 1 && day <= 31) {
					day = "0" + day;
				} else {
					day = "Error";
				}
				if (month.toString().length > 1 && month <= 12) {
					month = month;
				} else if (month <= 12 && month.toString().length === 1) {
					month = "0" + month;
				} else {
					month = "Error";
				}
				if (year.toString().length === 4) {
					year = year;
				} else if (year.toString().length === 2) {
					year = "20" + year;
				} else {
					year = "Error";
				}

				if (day !== "Error" && month !== "Error" && year !== "Error") {
					FormatedDate = day + "/" + month + "/" + year;

				} else {
					FormatedDate = "Error";
				}

			} else if (sDate === "NaN" || sValue.length !== 8) {

				FormatedDate = "Error";

				// MessageBox.error("Date Format in Excel sheet is wrong");
			}
			return FormatedDate;
			// var day = sValue.slice("0", "2");
			// 	// '31'
			// 	var month = sValue.slice("4").slice("0", "1");
			// 	// '2'
			// 	var year = sValue.slice("6");
			// 	// '2021'

		},

		onGetExcelData: function (workbook, sheetName) {
			// var sData =	XLSX.utils.make_formulae(workbook.Sheets[sheetName]);

			var oArray = [];

			var oData = XLSX.utils.make_csv(workbook.Sheets[sheetName]).split("\n");

			for (var i = 0; i < oData.length; i++) {
				var sAry = {};

				// sData[i];

				var val = oData[i].split(",");
				if (val[0] !== "") {
					sAry = val;
					oArray.push(sAry);
				}

			}
			return oArray;

		},
		onSearch: function (oEvent) {

			var that = this;
			var aFilter = [];
			var sQuery = oEvent.getParameter("newValue");
			if (sQuery) {
				aFilter = new Filter({

					filters: [

						new Filter("Position", FilterOperator.Contains, sQuery),
						new Filter("Start_date", FilterOperator.Contains, sQuery),
						new Filter("End_date", FilterOperator.Contains, sQuery),
						new Filter("Posid", FilterOperator.Contains, sQuery),
						new Filter("Prozt", FilterOperator.Contains, sQuery),
						new Filter("Grant_nbr", FilterOperator.Contains, sQuery),
						new Filter("Fincode", FilterOperator.Contains, sQuery),
						new Filter("Fund_id", FilterOperator.Contains, sQuery),
						new Filter("Award_type", FilterOperator.Contains, sQuery),
						new Filter("Error", FilterOperator.Contains, sQuery)

					]

				});

			}

			var oTable = that.byId("TablePlanned");
			var oBinding = oTable.getBinding("items");
			oBinding.filter(aFilter);
		},
		onSelectChange: function (oEvent) {

			var that = this;
			selChange = "change";
			that.byId("delbtn").setVisible(true);
			that.byId("saveBtn").setEnabled(true);

		},
		onVerify: function () {
			var that = this;

			verify = "v";

			// var finalData = [];
			var oArray = [];

			var sYear = that.byId("Fyear").getValue();

			var fileUploader = that.byId("fileUploader").getValue();

			var sData = that.getView().getModel("sampleModel").getProperty("/");

			// var oPlant = that.getOwnerComponent().getModel("oUserPlantModel").getProperty("/Plant");

			if (sYear === "" || fileUploader === "") {
				MessageBox.error("No Data Found,Please Choose File.");
			} else if (sData.length === 0) {
				MessageBox.error("No Data Found.");

			} else {

				for (var i = 0; i < sData.length; i++) {

					// var oContext = that.getView().getModel("sampleModel").getProperty(oBinding[i]);
					var updateObj = sData[i];

					var keyData = {
						"Position": updateObj.Position,
						"Start_date": updateObj.Start_date,
						"End_date": updateObj.End_date,
						"Posid": updateObj.Posid,
						"Prozt": updateObj.Prozt,
						"Fincode": updateObj.Fincode,
						"Grant_nbr": updateObj.Grant_nbr,

						"Fund_id": "",
						"Award_type": "",

						"Error": "",
						"Month_end": "",
						"Flag": ""
					};
					oArray.push(keyData);
					// finalData.push(updateObj.Position);
					var oEntryData = {};
					// oEntryData.Position = finalData;
					// oEntryData.FileUploadSet = oArray;
					oEntryData.Position = sYear;
					oEntryData.FileUploadSet = oArray;

					// finalData.push(oEntryData);

				}
				// that.onCreateData(oEntryData);
				that.onCreateDataVerify(oEntryData);
			}

		},
		onCreateDataVerify: function (oEntryData) {
			var that = this;

			var oEntry = oEntryData;

			var oGlobalBusyDialog = new sap.m.BusyDialog();
			oGlobalBusyDialog.open();
			that.getOwnerComponent().getModel("MainModel").create("/FileUpdHdrSet", oEntry, {

				success: function (oData, oResponse) {
					if (oResponse.statusCode === 201 || oResponse.statusCode === "201") {
						oGlobalBusyDialog.close();
						// that.onDataBindVerify(oData);
						that.onDataBindAfterSave(oData);

					}
				},
				error: function (oError) {
					// console.log(oError);
					oGlobalBusyDialog.close();
					MessageBox.error(oError.statusText + "," + oError.statusCode);

				}
			});
		},
		// ------------- Read Data After Creation --------------- //
		onDataBindVerify: function (oData) {
			var that = this;
			var msg;
			var sData = oData.FileUploadSet.results;

			for (var i = 0; i < sData.length; i++) {
				if (sData[i].Error === "No error found" || sData[i].Error === "More than 4 activities/WBS not allowed" || sData[i].Error ===
					"More than 4 activities/WBS not allowed;") {
					msg = "No Error Found";

				} else if (sData[i].Error !== "Successfully updated") {
					MessageBox.error("Errors found! Fix errors before Upload.");
					msg = "";
					break;
				}
			}

			// if (msg === "No Error Found") {
			// 	MessageBox.success("No Error Found While Verification");
			// }

			that.storeMainData(sData);

			that.getView().getModel("sampleModel").setData(sData);

			// that.getView().getModel("sampleModel").setData(sData);

		},

		storeMainData: function (sData) {
			var that = this;
			// var oData = that.getView().getModel("mainModel").getData();
			var oDel = that.getView().getModel("deleteModel").getData();

			var sArray = [];

			for (var i = 0; i < sData.length; i++) {
				sArray.push(sData[i]);
			}
			if (oDel.length !== 0) {
				for (var j = 0; j < oDel.length; j++) {
					sArray.push(oDel[j]);
				}
			}

			that.getView().getModel("mainModel").setData(sArray);

		},

		onSave: function () {
			var that = this;
			var oArray = [];

			var sData = that.getView().getModel("sampleModel").getProperty("/");

			var sYear = that.byId("Fyear").getValue();
			var fileUploader = that.byId("fileUploader").getValue();

			// var oPlant = that.getOwnerComponent().getModel("oUserPlantModel").getProperty("/Plant");

			if (sYear === "" || fileUploader === "") {
				MessageBox.error("No Data Found,Please Choose File.");
			} else if (sData.length === 0) {
				MessageBox.error("No Data Found.");

			} else {

				// verify ="v";

				if (verify === "v") {

					save = "";
					for (var i = 0; i < sData.length; i++) {

						// var oContext = that.getView().getModel("sampleModel").getProperty(oBinding[i]);
						var updateObj = sData[i];
						if (updateObj.Error === "No error found" || updateObj.Error === "Successfully updated") {
							var keyData = {
								"Position": updateObj.Position,
								"Start_date": updateObj.Start_date,
								"End_date": updateObj.End_date,
								"Posid": updateObj.Posid,
								"Prozt": updateObj.Prozt,
								"Fincode": updateObj.Fincode,
								"Grant_nbr": updateObj.Grant_nbr,
								"Fund_id": updateObj.Fund_id,
								"Award_type": updateObj.Award_type,

								"Error": updateObj.Error,
								"Month_end": "",
								"Flag": "X"
							};
							oArray.push(keyData);
							var oEntryData = {};

							oEntryData.Position = sYear;
							oEntryData.FileUploadSet = oArray;

						}
						// else if(updateObj.Error === "Successfully updated"){
						// 	var success = "S";

						// }
						else if (updateObj.Error !== "No error found" && updateObj.Error !== "Successfully updated") {
							var error = "E";
							//that.getView().getModel("sampleModel").setProperty("/saveError",error);
							break;

						}

					}
					if (error === "E") {
						MessageBox.error("Errors found! Fix errors before Upload.");
					}
					// else if(success === "S"){
					// 		MessageBox.success("Data Saved and Uploaded Successfully");
					// }
					else {

						that.onCreateDataSave(oEntryData);
					}

				} else if (verify === undefined) {

					for (var i = 0; i < sData.length; i++) {

						// var oContext = that.getView().getModel("sampleModel").getProperty(oBinding[i]);
						var updateObj = sData[i];

						var keyData = {
							"Position": updateObj.Position,
							"Start_date": updateObj.Start_date,
							"End_date": updateObj.End_date,
							"Posid": updateObj.Posid,
							"Prozt": updateObj.Prozt,
							"Fincode": updateObj.Fincode,
							"Grant_nbr": updateObj.Grant_nbr,
							"Fund_id": updateObj.Fund_id,
							"Award_type": updateObj.Award_type,

							"Error": updateObj.Error,
							"Month_end": "",
							"Flag": ""
						};
						oArray.push(keyData);
						// finalData.push(updateObj.Position);
						var oEntryData = {};
						// oEntryData.Position = finalData;
						// oEntryData.FileUploadSet = oArray;
						oEntryData.Position = sYear;
						oEntryData.FileUploadSet = oArray;

						// finalData.push(oEntryData);

					}
					// that.onCreateData(oEntryData);
					verify = "v";
					save = "s";
					that.onCreateDataSave(oEntryData);

				}
			}

		},

		onSaveVerifyUpload: function () {
			var that = this;
			var oArray = [];

			var sData = that.getView().getModel("sampleModel").getProperty("/");

			var sYear = that.byId("Fyear").getValue();
			var fileUploader = that.byId("fileUploader").getValue();

			// var oPlant = that.getOwnerComponent().getModel("oUserPlantModel").getProperty("/Plant");

			if (sYear === "" || fileUploader === "") {
				MessageBox.error("No Data Found,Please Choose File.");
			} else if (sData.length === 0) {
				MessageBox.error("No Data Found.");

			} else {

				for (var i = 0; i < sData.length; i++) {

					// var oContext = that.getView().getModel("sampleModel").getProperty(oBinding[i]);
					var updateObj = sData[i];
					if (updateObj.Error === "No error found" || updateObj.Error === "More than 4 activities/WBS not allowed" || updateObj.Error ===
						"More than 4 activities/WBS not allowed;") {
						var keyData = {
							"Position": updateObj.Position,
							"Start_date": updateObj.Start_date,
							"End_date": updateObj.End_date,
							"Posid": updateObj.Posid,
							"Prozt": updateObj.Prozt,
							"Fincode": updateObj.Fincode,
							"Grant_nbr": updateObj.Grant_nbr,
							"Fund_id": updateObj.Fund_id,
							"Award_type": updateObj.Award_type,

							"Error": updateObj.Error,
							"Month_end": "",
							"Flag": "X"
						};
						oArray.push(keyData);
						var oEntryData = {};

						oEntryData.Position = sYear;
						oEntryData.FileUploadSet = oArray;

					}
					// else if(updateObj.Error === "Successfully updated"){
					// 	var success = "S";

					// }
					else if (updateObj.Error !== "No error found" || updateObj.Error !== "More than 4 activities/WBS not allowed" || updateObj.Error !==
						"More than 4 activities/WBS not allowed;") {
						var error = "E";
						//that.getView().getModel("sampleModel").setProperty("/saveError",error);
						break;

					}

				}
				if ((error === "E" && selChange !== "change") || (error === "E" && selChange === "change")) {
					that.onVerify();
				}
				// else if(success === "S"){
				// 		MessageBox.success("Data Saved and Uploaded Successfully");
				// }
				else {

					that.onCreateDataSave(oEntryData);
				}

			}

			//	}

		},

		onCreateDataSave: function (oEntryData) {
			var that = this;

			var oEntry = oEntryData;

			var oGlobalBusyDialog = new sap.m.BusyDialog();
			oGlobalBusyDialog.open();
			that.getOwnerComponent().getModel("MainModel").create("/FileUpdHdrSet", oEntry, {

				success: function (oData, oResponse) {
					if (oResponse.statusCode === 201 || oResponse.statusCode === "201") {
						oGlobalBusyDialog.close();

						if (save === "s") {
							that.onDataBindAfterSave(oData);
						} else {

							that.onDataBindSuccess(oData);
						}

					}
				},
				error: function (oError) {
					// console.log(oError);
					oGlobalBusyDialog.close();
					MessageBox.error(oError.statusText + "," + oError.statusCode);

				}
			});
		},

		onDataBindSuccess: function (oData) {
			var that = this;

			// var oGlobalBusyDialog = new sap.m.BusyDialog();
			// oGlobalBusyDialog.open();
			// that.getOwnerComponent().getModel("MainModel").read("/FileUpdHdrSet", {

			// 	success: function (oData1, oResponse) {
			// 		if (oResponse.statusCode === 200 || oResponse.statusCode === "200") {
			// 			// that.onDataBind(oData);
			// 			oGlobalBusyDialog.close();
			var sData = oData.FileUploadSet.results;

			MessageBox.success("Data Saved and Uploaded Successfully");

			that.storeMainData(sData);
			//	that.getView().getModel("mainModel").setData(sData);

			that.getView().getModel("sampleModel").setData(sData);

			that.byId("delbtn").setVisible(false);
			that.byId("saveBtn").setEnabled(false);
			that.byId("refereshBtn").setEnabled(false);
			// that.byId("verifyBtn").setEnabled(false);

			// 		}
			// 	},
			// 	error: function (oError) {
			// 		// console.log(oError);
			// 		oGlobalBusyDialog.close();
			// 		MessageBox.error(oError.statusText + "," + oError.statusCode);

			// 	}
			// });
		},

		onDataBindAfterSave: function (oData) {
			var that = this;
			var msg;

			var sData = oData.FileUploadSet.results;

			var sYear = that.byId("Fyear").getValue();

			for (var i = 0; i < sData.length; i++) {
				if (sData[i].Error === "No error found" || sData[i].Error === "More than 4 activities/WBS not allowed" || sData[i].Error ===
					"More than 4 activities/WBS not allowed;") {
					msg = "No Error Found";
					//	break;
					// MessageBox.success("No Error Found While Verification");
				} else if (sData[i].Error !== "Successfully updated") {
					MessageBox.error("Errors found! Fix errors before Upload.");
					//	that.getView().getModel("mainModel").setData(sData);
					that.storeMainData(sData);
					that.getView().getModel("sampleModel").setData(sData);

					err = "e";
					msg = "";
					break;
				}
			}

			// 
			var oArray = [];
			if (msg === "No Error Found") {
				save = "";
				err = "";
				for (var j = 0; j < sData.length; j++) {

					// var oContext = that.getView().getModel("sampleModel").getProperty(oBinding[i]);
					var updateObj = sData[j];

					var keyData = {
						"Position": updateObj.Position,
						"Start_date": updateObj.Start_date,
						"End_date": updateObj.End_date,
						"Posid": updateObj.Posid,
						"Prozt": updateObj.Prozt,
						"Fincode": updateObj.Fincode,
						"Grant_nbr": updateObj.Grant_nbr,
						"Fund_id": updateObj.Fund_id,
						"Award_type": updateObj.Award_type,
						"Error": updateObj.Error,
						"Month_end": "",
						"Flag": "X"
					};
					oArray.push(keyData);

				}

				var oEntryData = {};

				oEntryData.Position = sYear;
				oEntryData.FileUploadSet = oArray;
				that.onCreateDataSave(oEntryData);
			}
			// else if (verify === "v" && err !== "e") {
			// 	MessageBox.success("No Error Found While Verification");
			// 	err = "";
			// }

		},
		/*Delete Functionalty*/
		onDelete: function (oEvent) {

			var that = this;
			var oSelectedItem = oEvent.getSource();
			var oContext = oSelectedItem.getBindingContext("sampleModel");
			var sPath = oContext.getPath();
			// console.log(sPath);
			// var sData = that.getView().getModel("sampleModel").getProperty("/");
			// var newObj = Object.assign([], sData);

			// that.getView().getModel("mainModel").setProperty("/", newObj);
			var sPosData = that.getView().getModel("sampleModel").getProperty(sPath);
			// var position = sPath.split("/")[1];
			// var check = sData[position];
			// if (check.Default === "X") {
			// 	var msgDelete = that.getView().getModel("i18n").getProperty('msgDelete');
			// 	MessageBox.warning(msgDelete);
			// } else {
			var sPosId = sPosData.Position;

			var conformDelete = that.getView().getModel("i18n").getProperty('conformDelete');
			var oMessage = conformDelete.replace("{posId}", sPosId);

			MessageBox.warning(oMessage, {
				actions: [MessageBox.Action.YES, MessageBox.Action.CANCEL],
				emphasizedAction: MessageBox.Action.Yes,
				onClose: function (sAction) {
					if (sAction === "YES") {
						var finalData = [];
						var pfinal = [];
						var sData1 = [];
						var deleted = [];

						var sPos = sPosData.Position;
						var sampleData = that.getView().getModel("sampleModel").getProperty("/");

						var mainData = that.getView().getModel("mainModel").getProperty("/");

						var delData = that.getView().getModel("deleteModel").getData();
						// if (delData.length === 0) {
						for (var a = 0; a < mainData.length; a++) {
							if (mainData[a].Error !== undefined) {
								var oMatch = mainData[a].Error.match("Deleted");

								if (oMatch !== null) {

									deleted.push(mainData[a]);
								}
							}

						}
						// }

						for (var d = 0; d < mainData.length; d++) {
							if (mainData[d].Position === sPos) {
								// var pos = sampleData[k];
								if (mainData[d].Error === undefined) {
									mainData[d].Error = "Deleted";
								} else if (mainData[d].Error !== "") {
									mainData[d].Error = "Deleted : " + mainData[d].Error;
								}
								// mainData[d].Error = "Deleted";
								// var pos = d;
								// pfinal.push(pos);
								sData1.push(mainData[d]);
								deleted.push(mainData[d]);
							} else {
								sData1.push(mainData[d]);
								// finalData.push(sampleData[d]);
							}

						}
						that.getView().getModel("deleteModel").setData(deleted);

						that.getView().getModel("mainModel").setData(sData1);

						for (var k = 0; k < sampleData.length; k++) {
							if (sampleData[k].Position === sPos) {
								// var pos = sampleData[k];
								// sampleData[k].Error ="Deleted" ;
								var pos = k;
								pfinal.push(pos);
								// sData1.push(sampleData[k]);
							} else {
								// sData1.push(sampleData[k]);
								finalData.push(sampleData[k]);
							}

						}

						that.getView().getModel("sampleModel").setProperty("/", finalData);

						// for (var j = 0; j < sampleData.length; j++) {

						// 	if(pfinal[j])

						// 	sData.splice(pfinal[j], 1);
						// 	that.getView().getModel("sampleModel").setProperty("/", sData);

						// }

						// sData.splice(position, 1);

					} else if (sAction === "CANCEL") {

						var action = that.getView().getModel("i18n").getProperty('action');
						MessageToast.show(action + sAction);
					}
				}
			});

			// }

		},
		/*Delete Functionalty*/
		onDownload: function (oEvent) {
			var that = this;

			// var sComponentName = that.getOwnerComponent().getMetadata().getComponentName();
			// var staticData = $.sap.getModulePath(sComponentName, "/model/Link.json");

			// var sampleModel = new JSONModel(staticData);
			// that.getView().setModel(sampleModel, "stModel");

			// sampleModel.attachRequestCompleted(function () {

			// 	var oData = that.getView().getModel("stModel").getData();
			// 	var sampleModel = new JSONModel(oData);
			// 	that.getView().setModel(sampleModel, "stModel");
			// });

			var aLink = that.getView().getModel("stModel").getProperty("/aLink");

			// var link = document.createElement("a");
			// if (link.download !== undefined) {
			// 	var url = URL.createObjectURL(aLink);
			// 	link.setAttribute("href", url);
			// 	link.setAttribute("download", "CostDistributionUploadTemplate");
			// 	link.style.visibility = 'hidden';
			// 	document.body.appendChild(link);
			// 	link.click();
			// 	document.body.removeChild(link);
			// }

			var link = document.createElement("a");

			document.body.appendChild(link);

			link.setAttribute("type", "hidden");

			link.href = "data:@file/vnd.openxmlformats-officedocument.spreadsheetml.sheet;base64," + aLink;

			link.download = "CostDistributionUploadTemplate.xlsx";

			link.click();

			document.body.removeChild(link);

			// var aCols, oRowBinding, oSettings, oSheet, oTable;
			
			// oTable = that.byId("TablePlanned");
			// oRowBinding = oTable.getBinding("items");
			// aCols = that.createColumnConfig();
			// var sArray = [{
			// 	"Position": "",
			// 	"Start_date": "01122022",
			// 	"End_date": "",
			// 	"Posid": "",
			// 	"Prozt": "",
			// 	"Grant_nbr": "",
			// 	"Fincode": "",
			// 	"Fund_id": "",
			// 	"Award_type": "",
			// 	"Error": ""

			// }];
			// this.getView().getModel("dummyModel").setData(sArray);
			// var aProducts = this.getView().getModel("dummyModel").getData();
			// oSettings = {
			// 	workbook: {
			// 		columns: aCols,
			// 		context: {
			// 			sheetName: "CostDistributionUploadTemplate"
			// 		}
			// 	},
			// 	dataSource: aProducts,
			// 	fileName: "CostDistributionUploadTemplate"
			// };
		
			// this.getView().getModel("dummyModel").setData("");
			// oSheet = new Spreadsheet(oSettings);
			// oSheet.build().finally(function () {

			// 	oSheet.destroy();
			// });

		},
		createColumnConfig: function () {
			var aCols = [];
			aCols.push({
				label: 'Position',
				property: 'Position',
				//type: 'string',
				width: '5%'
			});
			aCols.push({
				label: 'Begin Date (ddmmyyyy)',
				property: 'Start_date',
				//type: 'EdmType.Enumeration',
				type: EdmType.String,
				format: '@',
				width: '8%'

			});
			aCols.push({
				label: 'End Date (ddmmyyyy)',
				property: 'End_date',
				type: 'EdmType.Date',
				inputFormat: 'ddmmyyyy',
				// type: 'string',
				width: '8%'
			});
			aCols.push({
				label: 'WBS Element',
				property: 'Posid',
				// type: 'string',
				width: '20%'
			});
			aCols.push({
				label: 'Percentage',
				property: 'Prozt',
				// type: 'string',
				width: '6%'
			});
			aCols.push({
				label: 'Grant',
				property: 'Grant_nbr',
				// type: 'string',
				width: '12%'
			});
			aCols.push({
				label: 'Fund',
				property: 'Fincode',
				// type: 'string',
				width: '7%'
			});
			// 	aCols.push({
			// 	label: 'Fund ID',
			// 	property: 'Fund_id',
			// 	// type: 'string',
			// 	width: '10%'
			// });
			// 	aCols.push({
			// 	label: 'Award Type',
			// 	property: 'Award_type',
			// 	// type: 'string',
			// 	width: '10%'
			// });

			return aCols;
		},
		onDownloadPreview: function () {
			var that = this;
			var aCols, oRowBinding, oSettings, oSheet, oTable;
			// if (!this._oTable) {
			//     this._oTable = sap.ui.getCore().byId("TablePlanned");
			// }
			// oTable = this._oTable;
			oTable = that.byId("TablePlanned");
			oRowBinding = oTable.getBinding("items");
			aCols = that.createColumnConfigPeivew();
			var aProd = this.getView().getModel("mainModel").getData();

			// var aProducts = this.getView().getModel("sampleModel").getData();
			oSettings = {
				workbook: {
					columns: aCols,
					context: {
						sheetName: "CostDistributionPreview"
					}
				},
				dataSource: aProd,
				fileName: "CostDistributionPreview"
			};
			// oSheet = new Spreadsheet(oSettings);
			// oSheet.build()
			//     .then(function () {
			//         // MessageToast.show('Spreadsheet export has finished');
			//     })
			//     .finally(function () {
			//         oSheet.destroy();
			//     });
			oSheet = new Spreadsheet(oSettings);
			oSheet.build().finally(function () {
				oSheet.destroy();
			});

		},
		createColumnConfigPeivew: function () {
			var aCols = [];
			aCols.push({
				label: 'Position',
				property: 'Position',
				// type: 'string',
				width: '5%'
			});
			aCols.push({
				label: 'Begin Date (dd/mm/yyyy)',
				property: 'Start_date',
				type: 'EdmType.Date',
				inputFormat: 'ddmmyyyy',
				width: '8%'

			});
			aCols.push({
				label: 'End Date (dd/mm/yyyy)',
				property: 'End_date',
				type: 'EdmType.Date',
				inputFormat: 'ddmmyyyy',
				// type: 'string',
				width: '8%'
			});
			aCols.push({
				label: 'WBS Element',
				property: 'Posid',
				// type: 'string',
				width: '20%'
			});
			aCols.push({
				label: 'Percentage',
				property: 'Prozt',
				// type: 'string',
				width: '6%'
			});
			aCols.push({
				label: 'Grant',
				property: 'Grant_nbr',
				// type: 'string',
				width: '12%'
			});
			aCols.push({
				label: 'Fund',
				property: 'Fincode',
				// type: 'string',
				width: '7%'
			});
			aCols.push({
				label: 'Fund ID',
				property: 'Fund_id',
				// type: 'string',
				width: '10%'
			});
			aCols.push({
				label: 'Award Type',
				property: 'Award_type',
				// type: 'string',
				width: '10%'
			});

			aCols.push({
				label: 'Status',
				property: 'Error',
				// type: 'string',
				width: '35%'
			});
			return aCols;
		},
		onFilterUITable: function (oEvent) {
			// var oSource = oEvent;
			oEvent.getParameters().column.setFiltered(true);

		},
		clearAllFilters: function (oEvent) {
			// var oSource = oEvent;
			var that = this;
			that.byId("TableActive1").getColumns()[0].setFiltered(false);
			// oEvent.getSource().getColumns()[0].setFiltered(false);

		}
	});
});