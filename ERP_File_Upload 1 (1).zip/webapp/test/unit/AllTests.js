sap.ui.define([
	"com/fileUpload/ERP_File_Upload/test/unit/controller/ERPFileUpload.controller"
], function () {
	"use strict";
});