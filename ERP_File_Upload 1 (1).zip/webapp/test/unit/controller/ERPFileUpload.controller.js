/*global QUnit*/

sap.ui.define([
	"com/fileUpload/ERP_File_Upload/controller/ERPFileUpload.controller"
], function (Controller) {
	"use strict";

	QUnit.module("ERPFileUpload Controller");

	QUnit.test("I should test the ERPFileUpload controller", function (assert) {
		var oAppController = new Controller();
		oAppController.onInit();
		assert.ok(oAppController);
	});

});