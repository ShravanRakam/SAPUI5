sap.ui.define([
	"sap/ui/core/mvc/Controller",
	"sap/ui/model/json/JSONModel",
	"sap/ui/table/TablePersoController",
	"../model/statusOverviewPerso",
	"sap/ui/core/routing/History",
	"sap/m/MessageBox",
	"../model/formatter"
], function(Controller, JSONModel, TablePersoController, statusOverviewPerso, History, MessageBox, formatter) {
	"use strict";

	return Controller.extend("org.wfpRomaMaintenance.controller.RomaMaintenance", {
		formatter: formatter,
		onInit: function() {
			var that = this;
			var visibleModel = new sap.ui.model.json.JSONModel({
				OrgMaint: false,
				PositionMaint: false,
				posMaint: false,
				persMaint: false,
				busyDialog: false,
				statusOVBusyDialog: false,
				posTableBusy: false,
				pcrTableBusy: false,
				reporteesTableBusy: false
			});
			that.getView().setModel(visibleModel, "visibleModel");
			that.statusOverview = new TablePersoController({
				table: that.getView().byId("statusOverviewTable"),
				persoService: statusOverviewPerso
			});
			that.getDirectOrgData();
			that.getDirectPositions();
			that.getDirectReportees();
		},
		getOverviewData: function() {
			var that = this,
				oModel = that.getOwnerComponent().getModel("overViewModel"),
				pcrData,
				visible = that.getView().getModel("visibleModel");
			visible.setProperty("/statusOVBusyDialog", true);
			oModel.read("/ZPCR_STATUS_OVERVIEWSet", {
				success: function(OData) {
					pcrData = new JSONModel(OData);
					that.getView().setModel(pcrData, "overViewData");
					visible.setProperty("/statusOVBusyDialog", false);
				},
				error: function() {
					visible.setProperty("/statusOVBusyDialog", false);
				}
			});

		},
		onPersoButtonPressed: function() {
			var that = this;
			that.statusOverview.openDialog();
		},
		onPressSelectForm: function(oEvent) {
			var that = this;
			var event = oEvent.getSource();
			// 	iconTabbar = event.getParent().getParent().getContent()[1]._getIconTabHeader(),
			// 	selectedTab = iconTabbar.getSelectedKey(),
			// 	selectedIndex;
			var selectedTab = this.getView().byId("idIconTabBar").getSelectedKey();
			var selectedIndex;
			if (selectedTab === "orgMngmnt") {
				var orgTab = this.getView().byId("idIconTabBarOrg").getSelectedKey();
				if (orgTab === "orgAdmin") {
					selectedIndex = that.getView().byId("orgAdminTable").getSelectedIndex();
					that.openPopUp(event, selectedIndex);

					that.getView().getModel("visibleModel").setProperty("/OrgMaint", true);
					that.getView().getModel("visibleModel").setProperty("/PositionMaint", false);
					that.getView().getModel("visibleModel").setProperty("/posMaint", false);
				} else if (orgTab === "posAdmin") {
					selectedIndex = that.getView().byId("posAdminTable").getSelectedIndex();
					that.openPopUp(event, selectedIndex);

					that.getView().getModel("visibleModel").setProperty("/OrgMaint", false);
					that.getView().getModel("visibleModel").setProperty("/PositionMaint", true);
					that.getView().getModel("visibleModel").setProperty("/posMaint", false);
				}
				// selectedIndex = that.getView().byId("posTable").getSelectedIndex();
			} else if (selectedTab === "pcrTab") {
				selectedIndex = that.getView().byId("posTable").getSelectedIndex();
				that.openPopUp(event, selectedIndex);

				that.getView().getModel("visibleModel").setProperty("/OrgMaint", false);
				that.getView().getModel("visibleModel").setProperty("/PositionMaint", false);
				that.getView().getModel("visibleModel").setProperty("/posMaint", true);
			}
		},
		openPopUp: function(oEvent, selectedItem) {
			if (selectedItem !== -1) {
				if (!this._actionSheet) {
					this._actionSheet = sap.ui.xmlfragment(
						"org.wfpRomaMaintenance.fragments.ActionSheet",
						this
					);
					this.getView().addDependent(this._actionSheet);
				}
				this._actionSheet.openBy(oEvent);
			} else {
				MessageBox.warning("Please Select an Line Item");
			}
		},
		onRefreshStatusOVTable: function() {
			var that = this;
			that.getOverviewData();
		},

		onUpdateFinished: function(oEvent) {
			var that = this;
			oEvent.getSource().setSelectedItem(oEvent.getSource().getItems()[0]);
			that.getView().getModel("visibleModel").setProperty("/busyDialog", false);
		},
		onIconSelect: function(oEvent) {
			this.getView().byId("orgAdminTable").clearSelection();
			this.getView().byId("posAdminTable").clearSelection();
			this.getView().byId("posTable").clearSelection();

			// var that = this;
			// var key = oEvent.getSource().getSelectedKey();
			// if (key === "orgMngmnt") {
			// 	that.getDirectOrgData();

			// } else if (key === "pcrTab") {
			// 	that.getDirectPositions();

			// } else {
			// 	that.getView().getModel("visibleModel").setProperty("/OrgMaint", false);
			// 	that.getView().getModel("visibleModel").setProperty("/posMaint", false);
			// 	that.getView().getModel("visibleModel").setProperty("/persMaint", true);
			// }
		},
		onPressActionButton: function(oEvent) {
			var sPath = oEvent.getSource().getText();
			var oRouter = sap.ui.core.UIComponent.getRouterFor(this);
			oRouter.navTo("SelectForm", {
				path: sPath
			});
		},
		onExpand: function(oEvent) {
			var that = this,
				expanded = oEvent.getSource().getExpanded();
			if (expanded === true) {
				oEvent.getSource().setHeaderText("Hide Status Overview");
				that.getOverviewData();
			} else if (expanded === false) {
				 oEvent.getSource().setHeaderText("Show Status Overview");
				that.getView().getModel("overViewData").setData([]);
			}
		},
		getDirectPositions: function() {
			var that = this,
				oModel = that.getOwnerComponent().getModel("overViewModel"),
				positionData,
				visible = that.getView().getModel("visibleModel");
			visible.setProperty("/posTableBusy", true);
			oModel.read("/ZHR_POSITIONSSet", {
				success: function(OData) {
					positionData = new JSONModel(OData);
					positionData.setSizeLimit(OData.results.length);
					that.getView().setModel(positionData, "positionData");
					visible.setProperty("/posTableBusy", false);
				},
				error: function(error) {
					visible.setProperty("/posTableBusy", false);
				}
			});

		},
		getDirectOrgData: function() {
			var that = this,
				oModel = that.getOwnerComponent().getModel("overViewModel"),
				directOrgData,
				visible = that.getView().getModel("visibleModel");
			visible.setProperty("/posTableBusy", true);
			oModel.read("/ZHR_DIRECT_ORGSet", {
				success: function(OData) {
					directOrgData = new JSONModel(OData);
					directOrgData.setSizeLimit(OData.results.length);
					that.getView().setModel(directOrgData, "directOrgData");
					visible.setProperty("/pcrTableBusy", false);
				},
				error: function(error) {
					visible.setProperty("/pcrTableBusy", false);
				}
			});
		},
		getDirectReportees: function() {
			var that = this,
				oModel = that.getOwnerComponent().getModel("overViewModel"),
				visible = that.getView().getModel("visibleModel");
			visible.setProperty("/reporteesTableBusy", true);
			oModel.read("/ZHR_REPORTEESSet", {
				success: function(OData) {
					var directreportees = new JSONModel(OData);
					directreportees.setSizeLimit(OData.results.length);
					that.getView().setModel(directreportees, "directreportees");
					visible.setProperty("/reporteesTableBusy", false);
				},
				error: function(error) {
					visible.setProperty("/reporteesTableBusy", false);
				}
			});
		},
		onItemPress: function(oEvent) {
			var that = this;
			var rowData = oEvent.getSource().getBindingContext("overViewData").getObject();
			var data = new sap.ui.model.json.JSONModel(rowData);
			that.getView().setModel(data, "rowData");
			if (!that.rowDialog) {
				that.rowDialog = sap.ui.xmlfragment("org.wfpRomaMaintenance.fragments.rowData", that);
				that.getView().addDependent(that.rowDialog);
			}
			that.rowDialog.open();
		},
		onClose: function() {
			var that = this;
			that.rowDialog.close();
			that.rowDialog.destroy();
			that.rowDialog = null;
		}

	});
});