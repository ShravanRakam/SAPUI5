sap.ui.define([
	"sap/ui/core/mvc/Controller",
	"sap/ui/model/json/JSONModel"
], function(Controller, JSONModel) {
	"use strict";
		
	return Controller.extend("com.AppTwoTables.controller.App", {
		onInit: function(){
			var that = this,
			
			oModel = new JSONModel(jQuery.sap.getModulePath("com.AppTwoTables", "/model/Products2.json"));
			that.getView().setModel(oModel, "Products2Model");
		
		}
	});
});