sap.ui.define([
	"sap/ui/core/mvc/Controller",
		"sap/ui/model/json/JSONModel"
], function(Controller,JSONModel) {
	"use strict";

	return Controller.extend("com.addadd_edit_save.controller.View1", {
		onInit: function() {
			var that = this;
			var sTableModel = new JSONModel(jQuery.sap.getModulePath("com.addadd_edit_save", "/model/Table.json"));
		
			
			that.getView().setModel(sTableModel, "STableModel");
		},
			onEditTable: function(oEvent) {

			var that = this;
			var oModel = that.getView().getModel("STableModel");
			var itemPath = oEvent.getSource().getParent().getParent().getBindingContextPath();
			var Objectdata = that.getView().getModel("STableModel").getProperty(itemPath);
			Objectdata.inputVisible = true;
			Objectdata.textVisible = false;
			Objectdata.tabEditVis = false;
			Objectdata.tabSaveVis = true;
			Objectdata.tabCancelVis = true;
			Objectdata.tabDelVis = false;
			that.getView().getModel("STableModel").setProperty(itemPath, Objectdata);

			oModel.refresh(true);

		},
			onpressCancel: function(oEvent) {
			var that = this;
			var itemPath = oEvent.getSource().getParent().getParent().getBindingContextPath();
			var Objectdata = that.getView().getModel("STableModel").getProperty(itemPath);
				// var oModel = JSON.parse(JSON.stringify(sap.ui.getCore().getModel().getData()));
			Objectdata.inputVisible = false;
			Objectdata.textVisible = true;
			Objectdata.tabEditVis = true;
			Objectdata.tabSaveVis = false;
			Objectdata.tabCancelVis = false;
			Objectdata.tabDelVis = true;
			that.getView().getModel("STableModel").setProperty(itemPath, Objectdata);
			that.getView().updateBindings(true);
		},
			onpressSave: function(oEvent) {
			var that = this;
			var itemPath = oEvent.getSource().getParent().getParent().getBindingContextPath();
			var Objectdata = that.getView().getModel("STableModel").getProperty(itemPath);
			Objectdata.textVisible = true;
			Objectdata.inputVisible = false;
			Objectdata.tabEditVis = true;
			Objectdata.tabSaveVis = false;
			Objectdata.tabCancelVis = false;
			Objectdata.tabDelVis = true;
			that.getView().getModel("STableModel").setProperty(itemPath, Objectdata);
		},
			onAdd: function() {
			if (!this.form) {
				this.form = sap.ui.xmlfragment("com.addadd_edit_save.view.form", this);
				this.getView().addDependent(this.form);
			}
			this.form.open();
			var fModel = new JSONModel({
			
			});
			this.getView().setModel(fModel, "formModel");
		},
			onCancel: function() {
			this.form.close();
			this.form.destroy();
			this.form = null;
		},
			onSave: function(oEvent) {
				var that = this;
			var TableData = that.getView().getModel("STableModel");
			var data = TableData.getData();

			var FormData = that.getView().getModel("formModel").getData();
			FormData.textVisible = true;
			FormData.inputVisible = false;
			FormData.tabEditVis = true;
			FormData.tabSaveVis = false;
			FormData.tabCancelVis = false;
			data.tabDelVis = true;
		
			data.Objects.push(FormData);
			TableData.setData(data);
			
			that.form.close();
			

			
			}

	});
});