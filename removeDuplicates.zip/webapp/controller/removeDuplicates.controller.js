sap.ui.define([
	"sap/ui/core/mvc/Controller",
	"sap/ui/model/json/JSONModel"
], function(Controller, JSONModel) {
	"use strict";

	return Controller.extend("com.removeDuplicatesremoveDuplicates.controller.removeDuplicates", {
		onInit: function() {
			var that = this;
			var Prod = new JSONModel(jQuery.sap.getModulePath("com.removeDuplicatesremoveDuplicates", "/model/Products.json"));
			that.getView().setModel(Prod, "ProductModel");
		},
		onPress: function() {
			var that = this;
			var getData = that.getView().getModel("ProductModel").getData().Products;
			var oModel = new JSONModel(getData);
			that.getView().setModel(oModel, "bindModel");

			var a = [];
			var b = [];
			var Products = that.getView().getModel("bindModel").getData();
			for (var i = 0; i < Products.length; i++) {
				if (a.indexOf(Products[i].Prod_Id) === -1) {
					a.push(Products[i].Prod_Id);
				}
			}
			for (var j = 0; j < a.length; j++) {
				var object = {};
				object.Prod_Id = a[j];
				b.push(object);
			}
			// that.getView().getModel("bindModel").setProperty("/Prod_Id", b);
			var oModel = new JSONModel(b);
			that.getView().setModel(oModel, "comboBoxModel");
			

		}
	});
});