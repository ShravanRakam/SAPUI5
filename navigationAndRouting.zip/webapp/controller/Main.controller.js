sap.ui.define([
	"sap/ui/core/mvc/Controller",
	"sap/ui/model/json/JSONModel"
], function(Controller, JSONModel) {
	"use strict";

	return Controller.extend("Com.AppnavigationAndRouting.controller.Main", {
		onInit: function() {
			var that = this;
			// for M table
		
			var Products1Model = new JSONModel(jQuery.sap.getModulePath("Com.AppnavigationAndRouting", "/model/Products.json"));
			that.getView().setModel(Products1Model, "Products1Model");
		}
	});
});