/*global location history */
sap.ui.define([
	"bumpmaint/zbump_maintenance/controller/BaseController",
	"sap/ui/model/json/JSONModel",
	"bumpmaint/zbump_maintenance/model/formatter",
	"sap/ui/model/Filter",
	"sap/ui/model/FilterOperator",
	"sap/ui/export/Spreadsheet",
	"sap/m/Dialog",
	"sap/m/Button",
	"sap/m/StandardListItem",
	"sap/m/List"
], function (BaseController, JSONModel, formatter, Filter, FilterOperator, Spreadsheet, Dialog, Button, StandardListItem, List) {
	"use strict";

	return BaseController.extend("bumpmaint.zbump_maintenance.controller.Worklist", {
		formatter: formatter,
		/* =========================================================== */
		/* lifecycle methods                                           */
		/* =========================================================== */
		/**
		 * Called when the worklist controller is instantiated.
		 * @public
		 */
		onInit: function () {
			var that = this;
			// this.getView().addStyleClass(sap.ui.Device.support.touch ? "sapUiSizeCozy" : "sapUiSizeCompact");
			// this.getView().addStyleClass(sap.ui.Device.support.touch ? "sapUiSizeCompact" : "sapUiSizeCozy");
			var mModel = that.getOwnerComponent().getModel("oDataSrv");
			that.oLoggedinUser = "";
			that.craftUnion = "";
			var y = "/sap/bc/ui2/start_up";
			var xmlHttp = null;
			xmlHttp = new XMLHttpRequest();
			xmlHttp.onreadystatechange = function () {
				if (xmlHttp.readyState === 4 && xmlHttp.status === 200) {
					var oUserData = JSON.parse(xmlHttp.responseText);
					that.oLoggedinUser = oUserData.id;
					var firstName = oUserData.firstName;
					var lastName = oUserData.lastName;
					that.name = firstName + " " + lastName;
					//------ Calling the oData service for Craft ------
					mModel.read("/UserDetailsSet?$filter=Uname eq '" + that.oLoggedinUser + "'", null, null, false,
						function (oData) {
							that.userDetailsSetData = oData; //settting the odata to global variable access the User details 
							that.craftUnion = oData.results[0].Unions;
							//setting the view model for visibility control
							var oViewModel = new sap.ui.model.json.JSONModel({
								Unions: oData.results[0].Unions
							});
							oViewModel.setSizeLimit(10000);
							that.getView().setModel(oViewModel, "viewModel");
							var resul = oData.results;
							var rolesArray = resul.slice();
							var roleVals = [];
							for (var i = 0; i < rolesArray.length; i++) {
								var oVal1 = rolesArray[i].Role;
								roleVals.push(oVal1);
							}
							var finalArray = that.uniqueValuesFunc(roleVals, "Role");
							var oDataRole = {
								results: finalArray
							};
							var selectedKey1 = oDataRole.results[0].Role;
							var oJModelRole = new sap.ui.model.json.JSONModel(oDataRole);
							that.byId("roleIdSelect").setModel(oJModelRole);
							that.byId("roleIdSelect").setSelectedKey(selectedKey1);
							//fire the change event of the roles dropdown to get the departments values
							that.byId("roleIdSelect").fireChange(that.byId("roleIdSelect").getSelectedItem());
							if (rolesArray[0].Department !== "Engineering") {
								that.byId("effDateId").setMinDate(new Date());
							}
							// var resul2 = oData.results;
							// var DepArray2 = resul2.slice();
							// var depVals = [];
							// for (var i = 0; i < DepArray2.length; i++) {
							// 	var oVal = DepArray2[i].Department;
							// 	depVals.push(oVal);
							// }
							// var finalArray2 = that.uniqueValuesFunc(depVals, "Department");
							// var oDataRole2 = {
							// 	results: finalArray2
							// };
							// var oJModel = new sap.ui.model.json.JSONModel(oDataRole2);
							// // oJModel.setDefaultBindingMode("OneWay");
							// var selectedKey2 = oDataRole2.results[0].Department;

							// var oJModelRole = new sap.ui.model.json.JSONModel(oDataRole);
							// // oJModelRole.setDefaultBindingMode("OneWay");
							// var selectedKey1 = oDataRole.results[0].Role;
							// that.byId("roleIdSelect").setModel(oJModelRole);
							// that.byId("depIdSelect").setModel(oJModel);
							// that.byId("roleIdSelect").setSelectedKey(selectedKey1);
							// that.byId("depIdSelect").setSelectedKey(selectedKey2);
							// that.byId("oBumpMaintPageId").setShowFooter(true);
							// var roleSelection = that.byId("roleIdSelect").getSelectedKey();
							// that.onRoleSelectionChange();
							// that.byId("roleIdSelect").clearSelection(true);
							// that.byId("depIdSelect").clearSelection(true);

							// var filterObj = new sap.ui.model.Filter(oFilters, true);
							// 	that.byId("reasonCodeId").getBinding("items").filter(filterObj);

							//             	 var oComboBoxControl = this.getView().byId("cb");

							// var oBindingComboBox = oComboBoxControl.getBinding("items");

							// var aFiltersComboBox = [];
							// var oFilterComboBox = new sap.ui.model.Filter("text", "Contains", filter);
							// aFiltersComboBox.push(oFilterComboBox);
							// oBindingComboBox.filter(aFiltersComboBox);

							// *************************** Device detection **********************

							if (sap.ui.Device.system.phone === true) {
								that.byId("dBlock").setHeight("6rem");
								var mBlock = that.byId("mBlock");
								mBlock.setVisible(true);
								var mRHbox = that.byId("mRoleBlock");
								var mGHbox = that.byId("mGroupBlock");
								var mRefreshHbox = that.byId("mRefreshBlock");

								// that.byId("roleLabel").setWidth("3.1rem");
								var mRoleLabel = that.byId("roleLabel").addStyleClass("sapUiTinyMarginTop");
								mRHbox.addItem(mRoleLabel);
								that.byId("roleIdSelect").setWidth("10rem");
								var mRoleSelect = that.byId("roleIdSelect").addStyleClass("mAlignCls");
								mRHbox.addItem(mRoleSelect);
								mBlock.addItem(mRHbox);

								var mGroupLabel = that.byId("deptLabel").addStyleClass("sapUiTinyMarginTop");
								mGHbox.addItem(mGroupLabel);
								that.byId("depIdSelect").setWidth("10rem");
								var mGroupSelect = that.byId("depIdSelect").addStyleClass("sapUiMediumMarginBeginEnd");
								mGHbox.addItem(mGroupSelect);
								mBlock.addItem(mGHbox);

								var mRefreshBtn = that.byId("refreshBtn");
								mRefreshHbox.addItem(mRefreshBtn);
								mBlock.addItem(mRefreshHbox);

							} else if (sap.ui.Device.system.tablet === true) {
								that.byId("dBlock").setHeight("2rem");
								var mBlock2 = that.byId("mBlock");
								mBlock2.setVisible(false);

							} else {
								that.byId("dBlock").setHeight("2rem");
								var mBlock1 = that.byId("mBlock");
								mBlock1.setVisible(false);
							}

						});

				}
			};
			xmlHttp.open("GET", y, false);
			xmlHttp.send(null);

			if (!that._oResponsivePopover) {
				that._oResponsivePopover = sap.ui.xmlfragment("bumpmaint.zbump_maintenance.fragments.FilterPopover",
					that);
				that.getView().addDependent(that._oResponsivePopover, that);
				// that._oResponsivePopover.setModel(sap.ui.getCore().getModel("tabhdr"));
			}

			// var oTable = that.byId("bumpHeadTabId");
			var oTable = that.byId("bumpTableId");
			oTable.addEventDelegate({
				onAfterRendering: function () {
					var oHeader = oTable.$().find('.sapMListTblHeaderCell'); //Get hold of table header elements
					for (var i = 0; i < oHeader.length; i++) {
						var oID = oHeader[i].id;
						that.onClick(oID);
					}
				}
			}, oTable);

			//table2
			var oTable1 = that.byId("bumpList");
			oTable1.addEventDelegate({
				onAfterRendering: function () {
					var oHeader = oTable1.$().find('.sapMListTblHeaderCell'); //Get hold of table header elements
					for (var i = 0; i < oHeader.length; i++) {
						var oID = oHeader[i].id;
						that.onClick(oID);
					}
				}
			}, oTable1);

			that.aFilters = [];
			that.activeEligTableBindFunc(this.craftUnion);

		},
		activeEligTableBindFunc2: function (craft) {
			var that = this;
			var oTable = that.byId("bumpTableId");
			var oFilter = new sap.ui.model.Filter("Craft", "EQ", craft);
			oTable.setBusy(true);
			oTable.setBusyIndicatorDelay(0);
			var oEligModel = new sap.ui.model.json.JSONModel();
			oEligModel.setSizeLimit(10000);
			oEligModel.setDefaultBindingMode("OneWay");
			var oModel = that.getOwnerComponent().getModel("oDataSrv");
			oModel.setUseBatch(false);
			that.aFilters = [];
			oModel.read("/BumpDataSet", {
				async: true,
				filters: [oFilter],
				success: function (oData) {
					oEligModel.setData(oData);
					oTable.setBusy(false);
					oTable.setModel(oEligModel);
					// var sItems = oTable.getBinding("items");
					// var sSorter = new sap.ui.model.Sorter("BumpId", true);
					// sItems.sort(sSorter);
					oTable.getModel().refresh();
				},
				error: function (error) {
					oTable.setBusy(false);
				}
			});

		},
		activeEligTableBindFunc: function (craft) {
			var that = this;
			var oTable = that.byId("bumpTableId");
			var oFilter = new sap.ui.model.Filter("Craft", "EQ", craft);
			oTable.setBusy(true);
			oTable.setBusyIndicatorDelay(0);
			var oEligModel = new sap.ui.model.json.JSONModel();
			oEligModel.setSizeLimit(10000);
			oEligModel.setDefaultBindingMode("OneWay");
			var oModel = that.getOwnerComponent().getModel("oDataSrv");
			oModel.setUseBatch(false);
			that.aFilters = [];
			oModel.read("/BumpDataSet", {
				async: true,
				filters: [oFilter],
				success: function (oData) {
					oEligModel.setData(oData);
					oTable.setBusy(false);
					oTable.setModel(oEligModel);
					// var sItems = oTable.getBinding("items");
					// var sSorter = new sap.ui.model.Sorter("BumpId", true);
					// sItems.sort(sSorter);
					oTable.getModel().refresh();
				},
				error: function (error) {
					oEligModel.setData({
						results: []
					});
					oTable.setBusy(false);
					oTable.setModel(oEligModel);
				}
			});

		},

		onEffDateChange: function (oEvent) {
			var bValid = oEvent.getParameter("valid");
			this.allempdate();
			if (bValid) {
				oEvent.getSource().setValueState("None");
			} else {
				oEvent.getSource().setValueState("Error");
				oEvent.getSource().setValue();
			}
		},

		onEndDateChange: function (oEvent) {
			var oEffDate = this.getView().byId("effDateId").getValue();
			var bValid = oEvent.getParameter("valid");
			if (bValid) {
				oEvent.getSource().setValueState("None");
				if (oEffDate > oEvent.getSource().getValue()) {
					oEvent.getSource().setValue();
					oEvent.getSource().setValueState("Error");
					sap.m.MessageToast.show("Bump End date should be greater than Bump Start Date");
				} else {
					oEvent.getSource().setValueState("None");
				}
			} else {
				oEvent.getSource().setValueState("Error");
				oEvent.getSource().setValue();
			}

		},

		onEndTimeChange: function (oEvent) {
			var oEffDate = this.byId("effDateId").getValue();
			var oEndDate = this.byId("endDateId").getValue();
			var oStartTime = this.byId("effTimeId").getValue();
			if (oEffDate === oEndDate) {
				if (oStartTime > oEvent.getSource().getValue()) {
					oEvent.getSource().setValue("000000");
					oEvent.getSource().setValueState("Error");
					sap.m.MessageToast.show("Bump End Time should be greater than Bump Start Time");
				} else {
					oEvent.getSource().setValueState("None");
				}
			}
		},

		onRoleSelectionChange: function (oEvent) {
			var that = this;
			var oSelectedRole = oEvent.getSource().getSelectedKey();
			var selectedRows = [];
			//get the same roles data based on the role selection
			for (var i = 0; i < that.userDetailsSetData.results.length; i++) {
				if (that.userDetailsSetData.results[i].Role === oSelectedRole) {
					selectedRows.push(that.userDetailsSetData.results[i]);
				}
			}
			//create the array of object of unique departments to bind it to the group dropdown
			var newObj = {};
			var newDepAndUnionsArray = selectedRows.filter(function (obj) {
				if (newObj[obj.Department]) {
					return false;
				}
				newObj[obj.Department] = true;
				return true;
			});

			var oDataRole2 = {
				results: newDepAndUnionsArray
			};
			var oJModel = new sap.ui.model.json.JSONModel(oDataRole2);
			oJModel.setSizeLimit(10000);
			oJModel.setDefaultBindingMode("OneWay");
			that.byId("depIdSelect").setModel(oJModel, "DepModel");

			that.byId("depIdSelect").setSelectedKey(newDepAndUnionsArray[0].Unions);
			//fire the change event of the roles dropdown to get the departments values
			that.byId("depIdSelect").fireChange(that.byId("depIdSelect").getSelectedItem());
			//to set the enable of the group dropdown based on the data
			if (newDepAndUnionsArray.length === 1 || newDepAndUnionsArray.length === 0) {
				that.byId("depIdSelect").setEnabled(false);
			} else {
				that.byId("depIdSelect").setEnabled(true);
			}

			// var oSelectedRole = this.byId("roleIdSelect").getSelectedKey();
			// this.byId("depIdSelect").setSelectedKey(oSelectedRole);
			// var oSelctedIndex;
			/*if (oSelectedRole === "LR Admin") {
				// this.byId("depIdSelect").setEnabled(true);
				this.byId("createBumpEligTabId").setVisible(false);
				this.byId("oBumpMaintPageId").setShowFooter(false);
			} else {
				// this.byId("depIdSelect").setEnabled(false);
				this.byId("createBumpEligTabId").setVisible(true);
				this.byId("oBumpMaintPageId").setShowFooter(true);
			}*/

			// if (oSelectedRole === "ATDA") {

			// } else if (oSelectedRole === "Mechanical") {

			// } else if (oSelectedRole === "TCU") {

			// } else if (
			// 	oSelectedRole !== "LR Admin") {

			// }
			// this.craftUnion = oSelectedRole;
		},

		onDepSelectionChange: function (oEvent) {

			// var oSelectedKey = this.byId("depIdSelect").getSelectedKey();
			var sPath = oEvent.getSource().getSelectedItem().getBindingContext("DepModel").getPath();
			var data = oEvent.getSource().getModel("DepModel").getProperty(sPath);
			// var Department = data.Department;
			var union = data.Unions;
			this.getView().getModel("viewModel").setProperty("/Unions", union);
			// this.byId("depIdSelect").setSelectedKey(oSelectedKey);
			var mCraft;
			var that = this;
			//set the craft union based on the model path
			this.craftUnion = data.Unions;
			this.onRefresh();
			// this.craftUnion = mCraft;
			// var oSelectedKey = "E";
			var oTable = this.byId("bumpList");
			oTable.setVisible(true);
			var empId = ""; //initiallily emp id will be empty
			if (union === "SM" || union === "M") {
				mCraft = "M";
				this.onGetCallFunc(mCraft, oTable, empId);
			} else if (union === "SE" || union === "E") {
				// var oListEng = this.byId("bumpListEngList");
				// oListEng.setVisible(true);
				// oTable.setVisible(false);
				mCraft = "E";
				this.onGetCallFunc(mCraft, oTable, empId);
			} else if (union === "ST" || union === "T") {
				mCraft = "T";
				this.onGetCallFunc(mCraft, oTable, empId);
			} else if (union === "SA" || union === "A" || union === "D" || union === "SD") {
				mCraft = "D";
				this.onGetCallFunc(mCraft, oTable, empId);
			} else {
				var oJModel = new sap.ui.model.json.JSONModel([{
					"results": ""
				}]);
				oTable.setVisible(false);
				oTable.setModel(oJModel, "bumpListModel");

			}
			var formContent = that.byId("createBumpEligFormId").getContent();
			for (var f = 0; f < formContent.length; f++) {
				var oElement = formContent[f].getMetadata().getElementName();
				if ((oElement === "sap.m.Input") || (oElement === "sap.m.ComboBox") || (oElement === "sap.m.DatePicker") || (oElement ===
						"sap.m.TimePicker")) {
					formContent[f].setValue();
					formContent[f].setValueState("None");

				}
			}
			that.byId("empId").setTokens([]);
			that.byId("empTextId").setText();
			that.byId("posTextId").setText();
			that.byId("splScnId").setValue();
			that.byId("adminCommId").setValue();
			that.byId("splScnId").setEnabled(false);
			that.byId("splScnId").setRequired(false);
			that.byId("reasonCodeId").setValue();
			that.byId("reasonCodeId").clearSelection();
			this.onIconTabBarSelect();
			// if (Department === "Mechanical") {
			// 	mCraft = "M";

			// 	oTable = this.byId("mechTableId");
			// 	oTable.setVisible(true);
			// 	this.byId("EngTableId").setVisible(false);
			// 	this.byId("tcuTableId").setVisible(false);
			// 	this.byId("atdaTableId").setVisible(false);
			// 	this.onGetCallFunc(mCraft, oTable);
			// } else if (Department === "Engineering") {
			// 	mCraft = "E";

			// 	// this.byId("endDateId").setValue("11:59");
			// 	this.byId("mechTableId").setVisible(false);
			// 	oTable = this.byId("EngTableId");
			// 	oTable.setVisible(true);
			// 	this.byId("tcuTableId").setVisible(false);
			// 	this.byId("atdaTableId").setVisible(false);
			// 	this.onGetCallFunc(mCraft, oTable);
			// } else if (Department === "TCU") {
			// 	mCraft = "T";

			// 	this.byId("mechTableId").setVisible(false);
			// 	this.byId("EngTableId").setVisible(false);
			// 	oTable = this.byId("tcuTableId");
			// 	oTable.setVisible(true);
			// 	this.byId("atdaTableId").setVisible(false);
			// 	this.onGetCallFunc(mCraft, oTable);
			// } else if (Department === "ATDA" || Department === "Dispatchers") {
			// 	mCraft = "A";

			// 	this.byId("mechTableId").setVisible(false);
			// 	this.byId("EngTableId").setVisible(false);
			// 	this.byId("tcuTableId").setVisible(false);
			// 	oTable = this.byId("atdaTableId");
			// 	oTable.setVisible(true);
			// 	this.onGetCallFunc(mCraft, oTable);
			// } else {
			// 	// var results=[];

			// 	var oJModel = new sap.ui.model.json.JSONModel([{
			// 		"results": ""
			// 	}]);
			// 	this.byId("mechTableId").setModel(oJModel);
			// 	this.byId("EngTableId").setModel(oJModel);
			// 	this.byId("tcuTableId").setModel(oJModel);
			// 	this.byId("atdaTableId").setModel(oJModel);

			// }

		},

		onGetCallFunc: function (craft, oTable, empNo) {
			var oModel = this.getOwnerComponent().getModel();
			var sFilter = [];
			var that = this;
			var oCraft = new sap.ui.model.Filter("Craft", "EQ", craft);
			sFilter.push(oCraft);
			if (empNo.trim() !== "") {
				var oEmpId = new sap.ui.model.Filter("EmpId", "EQ", empNo);
				sFilter.push(oEmpId);
			}
			var oJModel = new sap.ui.model.json.JSONModel();
			oJModel.setSizeLimit(10000);
			if (empNo) {
				oModel.setUseBatch(false);
				var oPage = this.byId("oBumpMaintPageId");
				oPage.setBusy(true);
				oPage.setBusyIndicatorDelay(0);
				oModel.read("/BumpListSet", {
					filters: sFilter,
					success: function (oData, warring) {
						that.WMessage = "";
						oPage.setBusy(false);
						oJModel.setData(oData);
						oTable.setModel(oJModel, "bumpListModel");
						oTable.getModel("bumpListModel").refresh();
						if (warring.headers["sap-message"]) {
							var WMessage = JSON.parse(warring.headers["sap-message"]).message;
							if (WMessage) {
								that.WMessage = WMessage;
							}
						}
					},
					error: function (err) {
						oPage.setBusy(false);
						var messageLen = JSON.parse(err.responseText).error.message.value;
						// var msg = "";
						// for (var i = 0; i < messageLen.length; i++) {
						// 	if (!messageLen[i].message.includes("without specific error")) {
						// 		msg = messageLen[i].message;
						// 	}
						// }
						// if (messageLen.length === 0) {
						// 	msg = JSON.parse(err.response.body).error.message.value;
						// }
						sap.m.MessageBox.error(messageLen);
						oJModel.setData({});
						oTable.setModel(oJModel, "bumpListModel");
						oTable.getModel("bumpListModel").refresh();
					}
				});
			} else {
				oJModel.setData({});
				oTable.setModel(oJModel, "bumpListModel");
				oTable.getModel("bumpListModel").refresh();
			}
		},

		uniqueValuesFunc: function (array, field) {
			// var names = ["Mike", "Matt", "Nancy", "Adam", "Jenny", "Nancy", "Carl"];
			var uniqueValues = [];
			var finalArray = [];
			$.each(array, function (i, el) {
				if ($.inArray(el, uniqueValues) === -1) {
					uniqueValues.push(el);
				}
			});

			$.each(uniqueValues, function (j, val) {
				var sObj = {};
				sObj["" + field + ""] = val;
				finalArray.push(sObj);
			});

			return finalArray;
		},

		onIconTabBarSelect: function () {
			var that = this;
			var oSelectedKey = that.byId("bumpMaintIconTabId").getSelectedKey();
			if (oSelectedKey === "activeBumpEmployeeList") {
				// this.byId("saveBtn").setVisible(true);
				that.byId("submitBtn").setVisible(true);
				that.byId("cancelBtn").setVisible(true);

				this.onRefresh();
			} else if (oSelectedKey === "createBump") {
				// this.byId("saveBtn").setVisible(false);
				if (this.craftUnion === "E" || this.craftUnion === "SE") {
					this.getView().byId("endTimeId").setValue("11:59");
				}
				var oFilters = [];
				oFilters.push(new sap.ui.model.Filter("Craft", sap.ui.model.FilterOperator.EQ, that.craftUnion));
				that.byId("reasonCodeId").getBinding("items").filter(oFilters, sap.ui.model.FilterType.Application);
				that.byId("submitBtn").setVisible(true);
				that.byId("cancelBtn").setVisible(true);
			} else if (oSelectedKey === "bumpList") {
				// that.byId("depIdSelect").fireChange(that.byId("depIdSelect").getSelectedItem()); //--D5OW5 - Dt 01/31/2022
				// begin - new code - D5OW5 - Dt 01/31/2022
				that.byId("EmpNameId").setText();
				that.byId("rrCodeId").setText();
				that.byId("cdlId").setText();
				that.byId("bumpListEmpId").removeAllTokens([]);
				that.byId("bumpList").destroyItems();
				// end - new  code - D5OW5 - Dt 01/31/2022
				that.byId("submitBtn").setVisible(false);
				that.byId("cancelBtn").setVisible(false);

			}

		},

		onSubmit: function () {
			var that = this;
			var oSelectedKey = that.byId("bumpMaintIconTabId").getSelectedKey();
			if (oSelectedKey === "createBump") {
				var formErrorFlag = false;
				var formContent = that.byId("createBumpEligFormId").getContent();
				for (var f = 0; f < formContent.length; f++) {
					var oElement = formContent[f].getMetadata().getElementName();
					if ((oElement === "sap.m.Input") || (oElement === "sap.m.ComboBox") || (oElement === "sap.m.DatePicker") || (oElement ===
							"sap.m.TimePicker")) {

						if ((formContent[f].getRequired() === true) && (formContent[f]
								.getValue().trim().length < 1)) {
							formErrorFlag = true;
							formContent[f].setValueState("Error");
						}
					} else if (oElement === "sap.m.MultiInput") {
						if ((formContent[f].getRequired() === true) && (formContent[f].getTokens().length === 0)) {
							formErrorFlag = true;
							formContent[f].setValueState("Error");
						}
					}
				}

				if (formErrorFlag) {
					sap.m.MessageToast.show("Please fill all the mandatory fields");
				} else {
					var oEntry = {};
					oEntry.EmpId = that.byId("empId").getTokens()[0].getKey();
					oEntry.EmpName = that.byId("empTextId").getText();
					oEntry.BumpSdate = that.byId("effDateId").getValue();
					oEntry.BumpEdate = that.byId("endDateId").getValue();
					oEntry.BumpStime = that.byId("effTimeId").getValue().split(":").join("");
					oEntry.BumpEtime = that.byId("endTimeId").getValue().split(":").join("");
					oEntry.ReasonCode = that.byId("reasonCodeId").getValue();
					oEntry.ReasonDesc = that.byId("splScnId").getValue();
					oEntry.Comments = that.byId("adminCommId").getValue();
					oEntry.PositionId = that.byId("posId").getValue();
					oEntry.Craft = this.craftUnion;
					var oModel = that.getOwnerComponent().getModel();
					var oPage = this.byId("oBumpMaintPageId");
					oPage.setBusy(true);
					oPage.setBusyIndicatorDelay(0);
					oModel.create("/BumpDataSet", oEntry, {
						success: function (oData, oResponse) {
							oPage.setBusy(false);
							var message = oResponse.headers;
							if (message !== undefined) {
								var xml = message["sap-message"];
								$($.parseXML(xml)).find("message").each(function (a, b) {
									if (b.innerHTML !== "") {
										var text = $(b).text();

										sap.m.MessageBox.show(text, {
											icon: sap.m.MessageBox.Icon.INFORMATION,
											title: "Information",
											actions: [sap.m.MessageBox.Action.OK],
											onClose: function (sAction) {}
										});
										that.onClearCreateForm();

									}
								});
							}
						},
						error: function (error) {
							oPage.setBusy(false);
							var rrorDetails = JSON.parse(error.responseText).error.innererror.errordetails;
							var oMessage = false;
							var errmsg;
							for (var x = 0; x < rrorDetails.length; x++) {
								var msg = rrorDetails[x].message;
								if (!(msg.includes("without specific error"))) {
									oMessage = true;
									errmsg = msg;
								}

							}

							if (oMessage) {
								sap.m.MessageBox.show(errmsg, {
									icon: sap.m.MessageBox.Icon.SUCCESS,
									title: "Information",
									actions: [sap.m.MessageBox.Action.OK],
									onClose: function (sAction) {}
								});
								that.onClearCreateForm();
							}

						}
					});
				}
			} else if (oSelectedKey === "activeBumpEmployeeList") {

				sap.m.MessageBox.confirm("Are you sure you want to proceed with the update?", {
					title: "Confirm",
					actions: [sap.m.MessageBox.Action.YES, sap.m.MessageBox.Action.NO],
					onClose: function (oAction) {
						if (oAction === "YES") {
							that.stopBumpEligibleFunc();
						} else {
							that.onRefresh();
						}
					}
				});

			}

		},

		stopBumpEligibleFunc: function (oEvent) {
			var that = this;
			var oTable = that.byId("bumpTableId");
			var oItems = oTable.getItems();
			// var bumpFlagSelect = false;
			that.stopBumpArray = [];
			for (var i = 0; i < oItems.length; i++) {
				var oPath = oItems[i].getBindingContextPath();
				var oContext = oTable.getModel().getProperty(oPath);
				// if (oItems[i].getCells()[0].getSelected() === true) {
				// 	that.stopBumpArray.push(oContext);
				// }
				if (oItems[i].getCells()[0].getItems()[0].getSelected() === true) {
					that.stopBumpArray.push(oContext);
				}
			}

			if (that.stopBumpArray.length < 1) {
				sap.m.MessageToast.show("Please select atleast one record from the table");
			} else {
				sap.m.MessageToast.show("You have selected " + that.stopBumpArray.length + " records");
				that.submitManualStopFunc(that.stopBumpArray);
			}
		},

		submitManualStopFunc: function (bumpStopArray) {
			var that = this;
			var oEntry = {
				BumpId: "1"
			};

			// for (var i = 0; i < bumpStopArray.length; i++) {
			// 	var oContext = bumpStopArray[i];
			// 	oContext.BumpTrigger = "";
			// 	oContext.BumpStop = "X";
			// }
			oEntry.BumpDataNav = bumpStopArray;

			var oModel = that.getOwnerComponent().getModel("oDataSrv");
			var oPage = that.byId("oBumpMaintPageId");
			oPage.setBusy(true);
			oPage.setBusyIndicatorDelay(0);

			oModel.create("/BumpHeaderSet()", oEntry, {
				async: true,
				success: function (res) {
					sap.m.MessageToast.show("success");
					oPage.setBusy(false);
					that.onRefresh();
				},
				error: function (err, response) {
					oPage.setBusy(false);
					that.onRefresh();
					var rrorDetails = JSON.parse(err.response.body).error.innererror.errordetails;
					// var oMessage = false;
					var errmsg;
					for (var x = 0; x < rrorDetails.length; x++) {
						var msg = rrorDetails[x].message;
						if (!(msg.includes("without specific error"))) {
							// oMessage = true;
							errmsg = msg;
						}

					}
					sap.m.MessageBox.information(errmsg);

				}
			});

		},

		onEmpF4Help: function (oEvent) {
			var that = this;
			that.id = oEvent.getSource().getId();
			if (!that._empNoValueDialog) {
				that._empNoValueDialog = sap.ui.xmlfragment("bumpmaint.zbump_maintenance.fragments.EmpId", that.getView()
					.getController());
				that.getView().addDependent(that._empNoValueDialog);
			}
			that._empNoValueDialog.open();

			that._empNoValueDialog.setEscapeHandler(function (o) {
				o.reject();
			});

			sap.ui.getCore().byId("empIdSearch").setValue(oEvent.getSource().getValue());
			sap.ui.getCore().byId("empIdSearch").fireSearch();

		},

		onEmpNoSearch: function (oEvent) {
			var oVal = oEvent.getSource().getValue().trim();
			if (oVal.length > 0) {
				this.onEmpData();
			} else {
				var jsonModel = new sap.ui.model.json.JSONModel({});
				var empNoTable = sap.ui.getCore().byId("empIdTable");
				empNoTable.setModel(jsonModel, "empNoModel");
			}
		},

		onEmpData: function () {
			var that = this;
			var oModel = that.getOwnerComponent().getModel();
			var dialog = new sap.m.BusyDialog({});
			dialog.open();
			// var craftVal = that.byId("craftId").getValue();
			var craftVal = that.byId("depIdSelect").getSelectedKey();
			var union;
			if (craftVal === "SM" || craftVal === "M") {
				union = "M";
			} else if (craftVal === "SE" || craftVal === "E") {
				union = "E";
			} else if (craftVal === "ST" || craftVal === "T") {
				union = "T";
			} else if (craftVal === "SA" || craftVal === "A" || craftVal === "D" || craftVal === "SD") {
				union = "D";
			} else {
				union = "A";
			}
			var empVal = sap.ui.getCore().byId("empIdSearch").getValue();
			var craftQueryFil = [];
			var empNo = new sap.ui.model.Filter("EmpId", "EQ", empVal);
			// var craft = new sap.ui.model.Filter("Craft", "EQ", "T");
			var craft = new sap.ui.model.Filter("Craft", "EQ", union);
			craftQueryFil.push(empNo);
			craftQueryFil.push(craft);
			oModel.read("/EmpSearchHelpSet", {
				filters: craftQueryFil,
				success: function (oData, oResponse) {
					dialog.close();
					that.empDataFlag = true;
					var jsonModel = new sap.ui.model.json.JSONModel(oData);
					jsonModel.setSizeLimit(10000);
					var empNoTable = sap.ui.getCore().byId("empIdTable");
					empNoTable.setModel(jsonModel, "empNoModel");
				},
				error: function (oErr) {
					dialog.close();
					that.empDataFlag = false;
					var msg = JSON.parse(oErr.response.body).error.message.value;
					sap.m.MessageBox.show(
						msg, {
							icon: sap.m.MessageBox.Icon.INFORMATION,
							title: "Log",
							actions: [sap.m.MessageBox.Action.OK],
							onClose: function (oAction) {
								if (oAction === sap.m.MessageBox.Action.OK) {

								}
							}
						});

				}
			});
		},

		onEmpNoSubmit: function (oEvent) {
			var that = this;
			var pPath = oEvent.getSource().getBindingContextPath();
			var empNoContexts = sap.ui.getCore().byId("empIdTable").getModel("empNoModel").getProperty(pPath);
			var empNo = empNoContexts.EmpId;
			var empDesc = empNoContexts.EmpName;
			this.EmpName = empDesc;
			this.posId = empNoContexts.PosId;
			this.PosDesc = empNoContexts.PosDesc;
			that.byId("EmpNameId").setText(empNoContexts.EmpName);
			that.byId("rrCodeId").setText(empNoContexts.RRCode);
			that.byId("cdlId").setText(empNoContexts.CDL);
			var oSelectedKey = that.byId("bumpMaintIconTabId").getSelectedKey();
			var craftVal = that.byId("depIdSelect").getSelectedKey();
			var union;
			if (craftVal === "SM" || craftVal === "M") {
				union = "M";
			} else if (craftVal === "SE" || craftVal === "E") {
				union = "E";
			} else if (craftVal === "ST" || craftVal === "T") {
				union = "T";
			} else if (craftVal === "SA" || craftVal === "A" || craftVal === "D" || craftVal === "SD") {
				union = "D";
			} else {
				union = "E";
			}
			if (oSelectedKey === "createBump") {
				that.byId(that.id).setTokens([new sap.m.Token({
					text: empNo,
					key: empNo
				})]);
				that.byId("posId").setValue(this.posId);
				that.byId("empTextId").setText(empDesc);
				that.byId("posTextId").setText(this.PosDesc);
				that._empNoValueDialog.close();
			} else if (oSelectedKey === "bumpList") {
				that.byId(that.id).setTokens([new sap.m.Token({
					text: empNo,
					key: empNo
				})]);
				that._empNoValueDialog.close();
				var oTable = this.byId("bumpList");
				oTable.setVisible(true);
				this.onGetCallFunc(union, oTable, empNo);
			} else {
				that.byId(that.id).setTokens([new sap.m.Token({
					text: empNo,
					key: empNo
				})]);
				that._empNoValueDialog.close();
			}
			that.allempdate();
			if (that.craftUnion === "E" || that.craftUnion === "SE") {
				that.byId("reasonCodeId").setValue();
				that.byId("reasonCodeId").clearSelection();
				var oFilters = [];
				oFilters.push(new sap.ui.model.Filter("Craft", sap.ui.model.FilterOperator.EQ, that.craftUnion));
				oFilters.push(new sap.ui.model.Filter("PsubArea", sap.ui.model.FilterOperator.EQ, empNoContexts.PsubArea));
				that.byId("reasonCodeId").getBinding("items").filter(oFilters, sap.ui.model.FilterType.Application);
			}

		},
		allempdate: function () {
			var that = this;
			var emp = that.byId("empId").getTokens()[0].getKey();
			var resCode = that.byId("reasonCodeId").getSelectedKey();
			var effDate = that.byId("effDateId").getValue();

			if (emp === "" || resCode === "" || effDate === "") {
				return;
			} else {

				var oModel = that.getOwnerComponent().getModel();
				oModel.read("/EmpSearchHelpSet(EmpId='" + emp + "',ReasonCode='" + encodeURIComponent(resCode) + "',BumpSdate='" + effDate +
					"',Craft='" + that.craftUnion + "')", {
						success: function (oData, oResponse) {
							that.byId("endDateId").setValue(oData.BumpEdate);
							that.byId("effTimeId").setValue(oData.BumpStime);
							that.byId("endTimeId").setValue(oData.BumpEtime);
							//	that.byId("effDateId").setValue(oData.BumpEdate);
							//	dialog.close();
							// that.empDataFlag = true;
							// var jsonModel = new sap.ui.model.json.JSONModel(oData);
							// var empNoTable = sap.ui.getCore().byId("empIdTable");
							// empNoTable.setModel(jsonModel, "empNoModel");
						},
						error: function (oErr) {
							//	dialog.close();
							//that.empDataFlag = false;
							var msg = JSON.parse(oErr.response.body).error.message.value;
							sap.m.MessageBox.show(
								msg, {
									icon: sap.m.MessageBox.Icon.INFORMATION,
									title: "Log",
									actions: [sap.m.MessageBox.Action.OK],
									onClose: function (oAction) {
										if (oAction === sap.m.MessageBox.Action.OK) {

										}
									}
								});

						}
					});
			}
		},
		onEmpNoCancel: function () {
			var that = this;
			var oSelectedKey = that.byId("bumpMaintIconTabId").getSelectedKey();
			if (oSelectedKey === "createBump") {
				that.byId(that.id).removeAllTokens();
				that.byId("posId").setValue();
				that.byId("empTextId").setText();
				that.byId("posTextId").setText();
				that._empNoValueDialog.close();
			} else {
				that.byId(that.id).removeAllTokens();
				that._empNoValueDialog.close();
			}
		},

		onCancel: function () {
			var that = this;
			var oSelectedKey = that.byId("bumpMaintIconTabId").getSelectedKey();

			if (oSelectedKey === "createBump") {
				sap.m.MessageBox.confirm("Do you want to cancel the data?", {
					title: "Confirm",
					actions: [sap.m.MessageBox.Action.YES, sap.m.MessageBox.Action.NO],
					onClose: function (oAction) {
						if (oAction === sap.m.MessageBox.Action.YES) {
							var formContent = that.byId("createBumpEligFormId").getContent();
							for (var f = 0; f < formContent.length; f++) {
								var oElement = formContent[f].getMetadata().getElementName();
								if ((oElement === "sap.m.Input") || (oElement === "sap.m.ComboBox") || (oElement === "sap.m.DatePicker") || (oElement ===
										"sap.m.TimePicker")) {
									formContent[f].setValue();
									formContent[f].setValueState("None");

								}
							}
							that.byId("empId").setTokens([]);
							that.byId("empTextId").setText();
							that.byId("posTextId").setText();
							that.byId("splScnId").setValue();
							that.byId("adminCommId").setValue();
							that.byId("splScnId").setEnabled(false);
							that.byId("splScnId").setRequired(false);
							that.byId("reasonCodeId").setValue();
							that.byId("reasonCodeId").clearSelection();

						}
					}
				});
			} else {
				// if (that.stopBumpArray.length > 0) {
				sap.m.MessageBox.warning("Selection will be lost! \n Are you sure you want to cancel?", {
					title: "Warning",
					actions: [sap.m.MessageBox.Action.YES, sap.m.MessageBox.Action.NO],
					onClose: function (oAction) {
						if (oAction === sap.m.MessageBox.Action.YES) {
							that.onRefresh();
						}
					}
				});
			}
			// }

		},

		onClearCreateForm: function () {
			var that = this;
			var formContent = that.byId("createBumpEligFormId").getContent();
			for (var f = 0; f < formContent.length; f++) {
				var oElement = formContent[f].getMetadata().getElementName();
				if ((oElement === "sap.m.Input") || (oElement === "sap.m.ComboBox") || (oElement === "sap.m.DatePicker") || (oElement ===
						"sap.m.TimePicker")) {
					formContent[f].setValue();
					formContent[f].setValueState("None");

				}
			}
			that.byId("empTextId").setText();
			that.byId("posTextId").setText();
			that.byId("splScnId").setValue();
			that.byId("adminCommId").setValue();
			that.byId("splScnId").setEnabled(false);
			that.byId("splScnId").setRequired(false);
			that.byId("reasonCodeId").setValue();
			that.byId("reasonCodeId").clearSelection();
		},

		onReasonChange: function (oEvent) {
			var oReason = oEvent.getSource().getValue();
			this.allempdate();
			if (oReason === "Special Scenarios") {
				this.byId("splScnId").setRequired(true);
				this.byId("splScnId").setEnabled(true);
			} else {
				this.byId("splScnId").setRequired(false);
				this.byId("splScnId").setEnabled(false);
				this.byId("splScnId").setValueState("None");
				this.byId("splScnId").setValue();
			}
		},

		splScnChange: function (oEvent) {
			var oSplVal = oEvent.getSource().getValue().trim();
			if (oSplVal.length > 0) {
				oEvent.getSource().setValueState("None");
			}
		},
		onLoadItemsFinishedBump: function (oEvent) {
			var that = this;
			var oTable = that.byId("bumpList");
			var oItems = oTable.getItems();
			for (var i = 0; i < oItems.length; i++) {
				var oPath = oItems[i].getBindingContextPath();
				var oContext = oTable.getModel("bumpListModel").getProperty(oPath);
				var bumpStop = oContext.BumpStop;
				var bumpTrigger = oContext.BumpTrigger;
				if ((bumpStop === "Yes") || (bumpTrigger === "Yes")) {
					oItems[i].getCells()[0].getItems()[0].setEditable(false);
					oItems[i].getCells()[0].getItems()[0].setSelected(false);
					oItems[i].getCells()[0].getItems()[0].addStyleClass("cbCustom");
					// oItems[i].getCells()[0].setEditable(false);
					// oItems[i].getCells()[0].setSelected(false);
					// oItems[i].getCells()[0].addStyleClass("cbCustom");
				} else {
					oItems[i].getCells()[0].getItems()[0].setEditable(true);
					oItems[i].getCells()[0].getItems()[0].setSelected(false);
					oItems[i].getCells()[0].getItems()[0].removeStyleClass("cbCustom");
					// oItems[i].getCells()[0].setEditable(true);
					// oItems[i].getCells()[0].setSelected(false);
					// oItems[i].getCells()[0].removeStyleClass("cbCustom");
				}
			}
		},
		onLoadItemsFinished: function (oEvent) {
			var that = this;
			var oTable = that.byId("bumpTableId");
			var oItems = oTable.getItems();
			for (var i = 0; i < oItems.length; i++) {
				var oPath = oItems[i].getBindingContextPath();
				var oContext = oTable.getModel().getProperty(oPath);
				var bumpStop = oContext.BumpStop;
				var bumpTrigger = oContext.BumpTrigger;
				if ((bumpStop === "Yes") || (bumpTrigger === "Yes")) {
					oItems[i].getCells()[0].getItems()[0].setEditable(false);
					oItems[i].getCells()[0].getItems()[0].setSelected(false);
					oItems[i].getCells()[0].getItems()[0].addStyleClass("cbCustom");
					// oItems[i].getCells()[0].setEditable(false);
					// oItems[i].getCells()[0].setSelected(false);
					// oItems[i].getCells()[0].addStyleClass("cbCustom");
				} else {
					oItems[i].getCells()[0].getItems()[0].setEditable(true);
					oItems[i].getCells()[0].getItems()[0].setSelected(false);
					oItems[i].getCells()[0].getItems()[0].removeStyleClass("cbCustom");
					// oItems[i].getCells()[0].setEditable(true);
					// oItems[i].getCells()[0].setSelected(false);
					// oItems[i].getCells()[0].removeStyleClass("cbCustom");
				}
			}
		},

		onClick: function (oID) {
			var that = this;
			$('#' + oID).click(function (oEvent) {
				var oSelectedKey = that.byId("bumpMaintIconTabId").getSelectedKey();
				var oItems;
				if (oSelectedKey === "bumpList") {
					oItems = that.getView().byId("bumpList").getBinding("items");
				} else {
					oItems = that.getView().byId("bumpTableId").getBinding("items");
				}
				// var columnName = sap.ui.getCore().byId(oID).mAggregations.header.mProperties.text;
				var columnName = sap.ui.getCore().byId(oID).getAggregation("header").getProperty("text");
				sap.ui.getCore().byId("oFilterInputId").setType("Text");
				switch (columnName) {
				case "Bump ID":
					that.filColumn = "BumpId";
					sap.ui.getCore().byId("oFilterInputId").setValue("");
					if (oItems.aFilters.length > 0) {
						for (var i = 0; i < oItems.aFilters[0].aFilters.length; i++) {
							if (oItems.aFilters[0].aFilters[i].sPath === that.filColumn) {
								sap.ui.getCore().byId("oFilterInputId").setValue(oItems.aFilters[0].aFilters[i].oValue1);
							}
						}
					}
					sap.ui.getCore().byId("oFilterInputId");
					sap.ui.getCore().byId("oFilterInputId").setPlaceholder("Enter Bump ID");
					var oTarget = oEvent.currentTarget; //Get hold of Header Element
					var oLabelText = oTarget.childNodes[0].textContent; //Get Column Header text
					var oIndex = oTarget.id.slice(-1); //Get the column Index
					var oView = that.getView();
					var oTable = oView.byId("bumpTableId");
					that._oResponsivePopover.srcColumn = columnName;
					that._oResponsivePopover.openBy(oTarget);
					break;
				case "Employee ID":
					that.filColumn = "EmpId";
					sap.ui.getCore().byId("oFilterInputId").setValue("");
					if (oItems.aFilters.length > 0) {
						for (var i = 0; i < oItems.aFilters[0].aFilters.length; i++) {
							if (oItems.aFilters[0].aFilters[i].sPath === that.filColumn) {
								sap.ui.getCore().byId("oFilterInputId").setValue(oItems.aFilters[0].aFilters[i].oValue1);
							}
						}
					}
					sap.ui.getCore().byId("oFilterInputId");
					sap.ui.getCore().byId("oFilterInputId").setPlaceholder("Enter Employee ID");
					var oTarget1 = oEvent.currentTarget; //Get hold of Header Element
					var oLabelText1 = oTarget1.childNodes[0].textContent; //Get Column Header text
					oTarget1.id.slice(-1); //Get the column Index
					that._oResponsivePopover.srcColumn = columnName;
					that._oResponsivePopover.openBy(oTarget1);
					break;
				case "Employee Name":
					that.filColumn = "EmpName";
					sap.ui.getCore().byId("oFilterInputId").setValue("");
					if (oItems.aFilters.length > 0) {
						for (var i = 0; i < oItems.aFilters[0].aFilters.length; i++) {
							if (oItems.aFilters[0].aFilters[i].sPath === that.filColumn) {
								sap.ui.getCore().byId("oFilterInputId").setValue(oItems.aFilters[0].aFilters[i].oValue1);
							}
						}
					}
					sap.ui.getCore().byId("oFilterInputId");
					sap.ui.getCore().byId("oFilterInputId").setPlaceholder("Enter Employee Name");
					var oTarget2 = oEvent.currentTarget; //Get hold of Header Element
					var oLabelText2 = oTarget2.childNodes[0].textContent; //Get Column Header text
					oTarget2.id.slice(-1); //Get the column Index
					that._oResponsivePopover.srcColumn = columnName;
					that._oResponsivePopover.openBy(oTarget2);
					break;
					//		bump list 	Roster column
				case "Roster":
					that.filColumn = "RosterNo";
					sap.ui.getCore().byId("oFilterInputId").setValue("");
					if (oItems.aFilters.length > 0) {
						for (var i = 0; i < oItems.aFilters[0].aFilters.length; i++) {
							if (oItems.aFilters[0].aFilters[i].sPath === that.filColumn) {
								sap.ui.getCore().byId("oFilterInputId").setValue(oItems.aFilters[0].aFilters[i].oValue1);
							}
						}
					}
					sap.ui.getCore().byId("oFilterInputId");
					sap.ui.getCore().byId("oFilterInputId").setPlaceholder("Enter Roster");
					var oTargetRoster = oEvent.currentTarget; //Get hold of Header Element
					//var oLabelTextRoster = oTarget2.childNodes[0].textContent; //Get Column Header text
					oTargetRoster.id.slice(-1); //Get the column Index
					that._oResponsivePopover.srcColumn = columnName;
					that._oResponsivePopover.openBy(oTargetRoster);
					break;
					//      Union
				case "Union":
					if (oSelectedKey === "activeBumpEmployeeList") {
						that.filColumn = "Union";
						sap.ui.getCore().byId("oFilterInputId").setValue("");
						if (oItems.aFilters.length > 0) {
							for (var i = 0; i < oItems.aFilters[0].aFilters.length; i++) {
								if (oItems.aFilters[0].aFilters[i].sPath === that.filColumn) {
									sap.ui.getCore().byId("oFilterInputId").setValue(oItems.aFilters[0].aFilters[i].oValue1);
								}
							}
						}
						sap.ui.getCore().byId("oFilterInputId");
						sap.ui.getCore().byId("oFilterInputId").setPlaceholder("Enter Union");
						var oTargetU = oEvent.currentTarget; //Get hold of Header Element
						//var oLabelTextRoster = oTarget2.childNodes[0].textContent; //Get Column Header text
						oTargetU.id.slice(-1); //Get the column Index
						that._oResponsivePopover.srcColumn = columnName;
						that._oResponsivePopover.openBy(oTargetU);

					}
					break;
				case "Reason Code":
					that.filColumn = "ReasonCode";
					sap.ui.getCore().byId("oFilterInputId").setValue("");
					if (oItems.aFilters.length > 0) {
						for (var i = 0; i < oItems.aFilters[0].aFilters.length; i++) {
							if (oItems.aFilters[0].aFilters[i].sPath === that.filColumn) {
								sap.ui.getCore().byId("oFilterInputId").setValue(oItems.aFilters[0].aFilters[i].oValue1);
							}
						}
					}
					sap.ui.getCore().byId("oFilterInputId");
					sap.ui.getCore().byId("oFilterInputId").setPlaceholder("Enter Reason Code");
					var oTarget3 = oEvent.currentTarget; //Get hold of Header Element
					var oLabelText3 = oTarget3.childNodes[0].textContent; //Get Column Header text
					oTarget3.id.slice(-1); //Get the column Index
					that._oResponsivePopover.srcColumn = columnName;
					that._oResponsivePopover.openBy(oTarget3);
					break;
				case "RR Hired":
					that.filColumn = "RRHired";
					sap.ui.getCore().byId("oFilterInputId").setValue("");
					if (oItems.aFilters.length > 0) {
						for (var i = 0; i < oItems.aFilters[0].aFilters.length; i++) {
							if (oItems.aFilters[0].aFilters[i].sPath === that.filColumn) {
								sap.ui.getCore().byId("oFilterInputId").setValue(oItems.aFilters[0].aFilters[i].oValue1);
							}
						}
					}
					sap.ui.getCore().byId("oFilterInputId");
					sap.ui.getCore().byId("oFilterInputId").setPlaceholder("Enter RR Hired ");
					var oTarget4 = oEvent.currentTarget; //Get hold of Header Element
					oTarget4.id.slice(-1); //Get the column Index
					that._oResponsivePopover.srcColumn = columnName;
					that._oResponsivePopover.openBy(oTarget4);
					break;
				case "Rest Days":
					that.filColumn = "RestDays";
					sap.ui.getCore().byId("oFilterInputId").setValue("");
					if (oItems.aFilters.length > 0) {
						for (var i = 0; i < oItems.aFilters[0].aFilters.length; i++) {
							if (oItems.aFilters[0].aFilters[i].sPath === that.filColumn) {
								sap.ui.getCore().byId("oFilterInputId").setValue(oItems.aFilters[0].aFilters[i].oValue1);
							}
						}
					}
					sap.ui.getCore().byId("oFilterInputId");
					sap.ui.getCore().byId("oFilterInputId").setPlaceholder("Enter Rest Days");
					var oTarget5 = oEvent.currentTarget; //Get hold of Header Element
					oTarget5.id.slice(-1); //Get the column Index
					that._oResponsivePopover.srcColumn = columnName;
					that._oResponsivePopover.openBy(oTarget5);
					break;
				case "Department":
					that.filColumn = "Department";
					sap.ui.getCore().byId("oFilterInputId").setValue("");
					if (oItems.aFilters.length > 0) {
						for (var i = 0; i < oItems.aFilters[0].aFilters.length; i++) {
							if (oItems.aFilters[0].aFilters[i].sPath === that.filColumn) {
								sap.ui.getCore().byId("oFilterInputId").setValue(oItems.aFilters[0].aFilters[i].oValue1);
							}
						}
					}
					sap.ui.getCore().byId("oFilterInputId");
					sap.ui.getCore().byId("oFilterInputId").setPlaceholder("Enter Department ");
					var oTarget6 = oEvent.currentTarget; //Get hold of Header Element
					oTarget6.id.slice(-1); //Get the column Index
					that._oResponsivePopover.srcColumn = columnName;
					that._oResponsivePopover.openBy(oTarget6);
					break;
				case "Rank":
					that.filColumn = "Rank";
					sap.ui.getCore().byId("oFilterInputId").setValue("");
					if (oItems.aFilters.length > 0) {
						for (var i = 0; i < oItems.aFilters[0].aFilters.length; i++) {
							if (oItems.aFilters[0].aFilters[i].sPath === that.filColumn) {
								sap.ui.getCore().byId("oFilterInputId").setValue(oItems.aFilters[0].aFilters[i].oValue1);
							}
						}
					}
					sap.ui.getCore().byId("oFilterInputId");
					sap.ui.getCore().byId("oFilterInputId").setPlaceholder("Enter Rank ");
					var oTarget6 = oEvent.currentTarget; //Get hold of Header Element
					oTarget6.id.slice(-1); //Get the column Index
					that._oResponsivePopover.srcColumn = columnName;
					that._oResponsivePopover.openBy(oTarget6);
					break;
				case "Desk":
					that.filColumn = "Desk";
					sap.ui.getCore().byId("oFilterInputId").setValue("");
					if (oItems.aFilters.length > 0) {
						for (var i = 0; i < oItems.aFilters[0].aFilters.length; i++) {
							if (oItems.aFilters[0].aFilters[i].sPath === that.filColumn) {
								sap.ui.getCore().byId("oFilterInputId").setValue(oItems.aFilters[0].aFilters[i].oValue1);
							}
						}
					}
					sap.ui.getCore().byId("oFilterInputId");
					sap.ui.getCore().byId("oFilterInputId").setPlaceholder("Enter Department ");
					var oTarget7 = oEvent.currentTarget; //Get hold of Header Element
					oTarget7.id.slice(-1); //Get the column Index
					that._oResponsivePopover.srcColumn = columnName;
					that._oResponsivePopover.openBy(oTarget7);
					break;
					//new code started
				case "Territory":
					that.filColumn = "Territory";
					sap.ui.getCore().byId("oFilterInputId").setValue("");
					if (oItems.aFilters.length > 0) {
						for (var i = 0; i < oItems.aFilters[0].aFilters.length; i++) {
							if (oItems.aFilters[0].aFilters[i].sPath === that.filColumn) {
								sap.ui.getCore().byId("oFilterInputId").setValue(oItems.aFilters[0].aFilters[i].oValue1);
							}
						}
					}
					sap.ui.getCore().byId("oFilterInputId");
					sap.ui.getCore().byId("oFilterInputId").setPlaceholder("Enter Territory");
					var oTarget3 = oEvent.currentTarget; //Get hold of Header Element
					var oLabelText3 = oTarget3.childNodes[0].textContent; //Get Column Header text
					oTarget3.id.slice(-1); //Get the column Index
					that._oResponsivePopover.srcColumn = columnName;
					that._oResponsivePopover.openBy(oTarget3);
					break;
					//new code end
				default:
					sap.ui.getCore().byId("oFilterInputId").setPlaceholder("Enter Text");
				}
			});
		},

		onChange: function (oEvent) {
			var that = this;
			var oValue = oEvent.getParameter("value");
			// if (oValue.length < 1) {
			// 	that._oResponsivePopover.close();
			// 	oEvent.getSource().setValueState("None");
			// 	return;
			// }
			var oSelectedKey = that.byId("bumpMaintIconTabId").getSelectedKey();
			var oItems;
			if (oSelectedKey === "bumpList") {
				oItems = that.getView().byId("bumpList").getBinding("items");
			} else {
				oItems = that.getView().byId("bumpTableId").getBinding("items");
			}
			var oMultipleValues = oValue.split(",");
			var columnName = that.filColumn;
			switch (columnName) {
			case "BumpId":
				var aFil = [];
				if (oValue.length > 0) {
					for (var i = 0; i < oMultipleValues.length; i++) {
						var oVal = Number(oMultipleValues[i]);
						var oFilter = new sap.ui.model.Filter("BumpId", "EQ", oVal);
						aFil.push(oFilter);
						var Fin = new sap.ui.model.Filter({
							filters: aFil,
							and: false
						});
						that.aFilters.push(Fin);
					}
					//	oEvent.getSource().setValueState("None");
				} else {
					if (oItems.aFilters.length > 0) {
						for (var i = 0; i < oItems.aFilters[0].aFilters.length; i++) {
							if (oItems.aFilters[0].aFilters[i].sPath === that.filColumn) {
								oItems.aFilters[0].aFilters.pop(0, i);
							}
						}
					}
					//	oEvent.getSource().setValueState("Error");
				}
				break;
			case "EmpId":

				if (oValue.length > 0) {
					for (var j = 0; j < oMultipleValues.length; j++) {
						var oVal1 = oMultipleValues[j];

						var oFilter1 = new sap.ui.model.Filter("EmpId", "Contains", oVal1);
						that.aFilters.push(oFilter1);
					}
					//	oEvent.getSource().setValueState("None");
				} else {
					if (oItems.aFilters.length > 0) {
						for (var i = 0; i < oItems.aFilters[0].aFilters.length; i++) {
							if (oItems.aFilters[0].aFilters[i].sPath === that.filColumn) {
								oItems.aFilters[0].aFilters.pop(0, i);
							}
						}
					}
					//	oEvent.getSource().setValueState("Error");
				}
				break;
			case "Rank":

				if (oValue.length > 0) {
					for (var j = 0; j < oMultipleValues.length; j++) {
						var oVal1 = oMultipleValues[j];

						var oFilter1 = new sap.ui.model.Filter("Rank", "Contains", oVal1);
						that.aFilters.push(oFilter1);
					}
					//	oEvent.getSource().setValueState("None");
				} else {
					if (oItems.aFilters.length > 0) {
						for (var i = 0; i < oItems.aFilters[0].aFilters.length; i++) {
							if (oItems.aFilters[0].aFilters[i].sPath === that.filColumn) {
								oItems.aFilters[0].aFilters.pop(0, i);
							}
						}
					}
					//	oEvent.getSource().setValueState("Error");
				}
				break;
			case "EmpName":

				if (oValue.length > 0) {
					for (var k = 0; k < oMultipleValues.length; k++) {
						var oVal2 = oMultipleValues[k];

						var oFilter2 = new sap.ui.model.Filter("EmpName", "Contains", oVal2);
						that.aFilters.push(oFilter2);
					}
					//	oEvent.getSource().setValueState("None");
				} else {
					if (oItems.aFilters.length > 0) {
						for (var i = 0; i < oItems.aFilters[0].aFilters.length; i++) {
							if (oItems.aFilters[0].aFilters[i].sPath === that.filColumn) {
								oItems.aFilters[0].aFilters.pop(0, i);
							}
						}
					}
					//	oEvent.getSource().setValueState("Error");
				}
				break;
				// Roster # 
			case "RosterNo":

				if (oValue.length > 0) {
					for (var k = 0; k < oMultipleValues.length; k++) {
						var oVal2 = oMultipleValues[k];

						var oFilter2 = new sap.ui.model.Filter("RosterNo", "Contains", oVal2);
						that.aFilters.push(oFilter2);
					}
					//	oEvent.getSource().setValueState("None");
				} else {
					if (oItems.aFilters.length > 0) {
						for (var i = 0; i < oItems.aFilters[0].aFilters.length; i++) {
							if (oItems.aFilters[0].aFilters[i].sPath === that.filColumn) {
								oItems.aFilters[0].aFilters.pop(0, i);
							}
						}
					}
					//	oEvent.getSource().setValueState("Error");
				}
				break;

				// Union
			case "Union":

				if (oValue.length > 0) {
					for (var k = 0; k < oMultipleValues.length; k++) {
						var oValU = oMultipleValues[k];

						var oFilterU = new sap.ui.model.Filter("Union", "Contains", oValU);
						that.aFilters.push(oFilterU);
					}
					//	oEvent.getSource().setValueState("None");
				} else {
					if (oItems.aFilters.length > 0) {
						for (var i = 0; i < oItems.aFilters[0].aFilters.length; i++) {
							if (oItems.aFilters[0].aFilters[i].sPath === that.filColumn) {
								oItems.aFilters[0].aFilters.pop(0, i);
							}
						}
					}
					//	oEvent.getSource().setValueState("Error");
				}
				break;
			case "ReasonCode":

				if (oValue.length > 0) {
					for (var l = 0; l < oMultipleValues.length; l++) {
						var oVal3 = oMultipleValues[l];

						var oFilter3 = new sap.ui.model.Filter("ReasonCode", "Contains", oVal3);
						that.aFilters.push(oFilter3);
					}
					// oEvent.getSource().setValueState("None");
				} else {
					// oEvent.getSource().setValueState("Error");
					if (oItems.aFilters.length > 0) {
						for (var i = 0; i < oItems.aFilters[0].aFilters.length; i++) {
							if (oItems.aFilters[0].aFilters[i].sPath === that.filColumn) {
								oItems.aFilters[0].aFilters.pop(0, i);
							}
						}
					}
				}
				break;
			case "RRHired":
				if (oValue.length > 0) {
					for (var m = 0; m < oMultipleValues.length; m++) {
						var oVal4 = oMultipleValues[m];
						var oFilter4 = new sap.ui.model.Filter("RRHired", "Contains", oVal4);
						that.aFilters.push(oFilter4);
					}
					//	oEvent.getSource().setValueState("None");
				} else {
					//	oEvent.getSource().setValueState("Error
					if (oItems.aFilters.length > 0) {
						for (var i = 0; i < oItems.aFilters[0].aFilters.length; i++) {
							if (oItems.aFilters[0].aFilters[i].sPath === that.filColumn) {
								oItems.aFilters[0].aFilters.pop(0, i);
							}
						}
					}
				}
				break;
			case "RestDays":
				if (oValue.length > 0) {
					for (var n = 0; n < oMultipleValues.length; n++) {
						var oVal5 = oMultipleValues[n];
						var oFilter5 = new sap.ui.model.Filter("Restdays", "Contains", oVal5);
						that.aFilters.push(oFilter5);
					}
					//	oEvent.getSource().setValueState("None");
				} else {
					//	oEvent.getSource().setValueState("Error");
					if (oItems.aFilters.length > 0) {
						for (var i = 0; i < oItems.aFilters[0].aFilters.length; i++) {
							if (oItems.aFilters[0].aFilters[i].sPath === that.filColumn) {
								oItems.aFilters[0].aFilters.pop(0, i);
							}
						}
					}
				}
				break;
			case "Department":
				if (oValue.length > 0) {
					for (var o = 0; o < oMultipleValues.length; o++) {
						var oVal6 = oMultipleValues[o];
						var oFilter6 = new sap.ui.model.Filter("Department", "Contains", oVal6);
						that.aFilters.push(oFilter6);
					}
					//oEvent.getSource().setValueState("None");
				} else {
					//oEvent.getSource().setValueState("Error");
					if (oItems.aFilters.length > 0) {
						for (var i = 0; i < oItems.aFilters[0].aFilters.length; i++) {
							if (oItems.aFilters[0].aFilters[i].sPath === that.filColumn) {
								oItems.aFilters[0].aFilters.pop(0, i);
							}
						}
					}
				}
				break;
			case "Desk":
				if (oValue.length > 0) {
					for (var p = 0; p < oMultipleValues.length; p++) {
						var oVal7 = oMultipleValues[p];
						var oFilter7 = new sap.ui.model.Filter("DeskNumber", "Contains", oVal7);
						that.aFilters.push(oFilter7);
					}
					//	oEvent.getSource().setValueState("None");
				} else {
					//	oEvent.getSource().setValueState("Error");
					if (oItems.aFilters.length > 0) {
						for (var i = 0; i < oItems.aFilters[0].aFilters.length; i++) {
							if (oItems.aFilters[0].aFilters[i].sPath === that.filColumn) {
								oItems.aFilters[0].aFilters.pop(0, i);
							}
						}
					}
				}
				break;
			case "Territory":
				if (oValue.length > 0) {
					for (var q = 0; q < oMultipleValues.length; q++) {
						var oVal8 = oMultipleValues[q];
						var oFilter8 = new sap.ui.model.Filter("Territory", "Contains", oVal8);
						that.aFilters.push(oFilter8);
					}
					//	oEvent.getSource().setValueState("None");
				} else {
					//	oEvent.getSource().setValueState("Error");
					if (oItems.aFilters.length > 0) {
						for (var i = 0; i < oItems.aFilters[0].aFilters.length; i++) {
							if (oItems.aFilters[0].aFilters[i].sPath === that.filColumn) {
								oItems.aFilters[0].aFilters.pop(0, i);
							}
						}
					}
				}
				break;
			default:
			}
			// if (oEvent.getSource().getValueState() !== "Error") {
			var oFilters = new sap.ui.model.Filter({
				filters: that.aFilters,
				and: true
			});
			// var oSelectedKey = that.byId("bumpMaintIconTabId").getSelectedKey();
			// var oItems;
			// if (oSelectedKey === "bumpList") {
			// 	oItems = that.getView().byId("bumpList").getBinding("items");
			// } else {
			// 	oItems = that.getView().byId("bumpTableId").getBinding("items");
			// }
			oItems.filter(oFilters);
			sap.ui.getCore().byId("oFilterInputId").setValue();
			this._oResponsivePopover.close();
			// }
			// 
		},

		onAscending: function () {
			var that = this;
			var oTable;
			var oSelectedKey = that.byId("bumpMaintIconTabId").getSelectedKey();
			if (oSelectedKey === "bumpList") {
				oTable = that.byId("bumpList");
			} else {
				oTable = that.byId("bumpTableId");
			}
			var sItems = oTable.getBinding("items");
			var sSorter = new sap.ui.model.Sorter("" + that.filColumn + "", false);
			sItems.sort(sSorter);
			oTable.getModel().refresh();
			that._oResponsivePopover.close();
			// that.onLoadItemsFinished();

		},

		onDescending: function () {
			var that = this;
			//var oTable = that.byId("bumpTableId");
			var oTable;
			var oSelectedKey = that.byId("bumpMaintIconTabId").getSelectedKey();
			if (oSelectedKey === "bumpList") {
				oTable = that.byId("bumpList");
			} else {
				oTable = that.byId("bumpTableId");
			}
			var sItems = oTable.getBinding("items");
			var sSorter = new sap.ui.model.Sorter("" + that.filColumn + "", true);
			sItems.sort(sSorter);
			oTable.getModel().refresh();
			that._oResponsivePopover.close();
			// that.onLoadItemsFinished();
		},

		onRefresh: function (oEvent) {
			var that = this;
			// that.byId("bumpTableId").unbindItems();
			that.activeEligTableBindFunc(this.craftUnion);
			that.byId("bumpTableId").getModel().refresh();
			that.onLoadItemsFinished();
			var oSelectedKey = that.byId("bumpMaintIconTabId").getSelectedKey();
			if (oSelectedKey === "bumpList") {
				//that.onLoadItemsFinishedBump();
				/*var oTable = this.byId("atdaTableId");
				that.onGetCallFunc("A", oTable);*/

			}
		},

		dateTimeFormatFunc: function (date, time) {
			if (date !== null) {
				var oDate = date.slice("0", "8");
				var oTime;
				if (date.slice("8").includes(":")) {
					oTime = date.slice("8").split(":").join("").trim();
				} else {
					oTime = date.slice("8");
				}
				var mTime;
				if (oTime.length === 6) {
					mTime = oTime.slice("0", "2") + ":" + oTime.slice("2", "4");
				} else if (oTime.length === 4) {
					mTime = oTime.slice("0", "2") + ":" + oTime.slice("2", "4");
				} else if (oTime.length === 2) {
					mTime = oTime.slice("2", "0") + ":" + "00";
				} else if (oTime.length === 0) {
					mTime = "00" + ":" + "00";
				}

				var mDate = oDate.slice("4", "6") + "/" + oDate.slice("6") + "/" + oDate.slice("0", "4");
				// var mTime = oTime.slice("0", "2") + ":" + oTime.slice("2", "2") + ":" + oTime.slice("4");
				var mDateTime = mDate + ", " + mTime;

				return mDateTime;
			}
		},
		dTimeFormatFunc: function (oVal1, oVal2) {
			var stime = "";
			var etime = "";
			if (oVal1) {
				stime = oVal1.slice("0", "2") + ":" + oVal1.slice("2", "4");
			}
			if (oVal2) {
				etime = oVal2.slice("0", "2") + ":" + oVal2.slice("2", "4");
			}
			return stime + " - " + etime;
		},
		onDateFormat: function (oVal) {
			if (oVal) {
				var year = oVal.slice("0", "4");
				var month = oVal.slice("4").slice("0", "2");
				var day = oVal.slice("6");
				var date = month + "/" + day + "/" + year;
				return date;
			}
		},

		onTCU_ATDA_BumpPress: function () {
			this.getRouter().navTo("TCUATDAForm");
		},
		/*onMechBumpPress: function () {
			this.getRouter().navTo("MechForm");
		}*/
		onMechBumpPress: function (oEvent) {
			this.cSource = oEvent.getSource();
			var craftVal = this.byId("depIdSelect").getSelectedKey();
			var union;
			if (craftVal === "SM" || craftVal === "M") {
				union = "M";
			} else if (craftVal === "SE" || craftVal === "E") {
				union = "E";
			} else if (craftVal === "ST" || craftVal === "T") {
				union = "T";
			} else if (craftVal === "SA" || craftVal === "A" || craftVal === "D" || craftVal === "SD") {
				union = "D";
			} else {
				union = "A";
			}
			if (!oEvent.getSource().getParent().getParent().getAggregation("cells")[oEvent.getSource().getParent().getParent().getAggregation(
					"cells").length - 2].getSelected() && union === "M") {
				sap.m.MessageBox.error("You do not hold the qualification to bump this position. Contact PM Admin for verification");
				return;
			}
			var that = this;
			if (!that._AdminCommentsDialog) {
				that._AdminCommentsDialog = sap.ui.xmlfragment("bumpmaint.zbump_maintenance.fragments.AdminComments", that.getView()
					.getController());
				that.getView().addDependent(that._AdminCommentsDialog);
			}
			that._AdminCommentsDialog.open();
			that._AdminCommentsDialog.setEscapeHandler(function (o) {
				o.reject();
			});
		},
		onACommConfirm: function () {
			if (sap.ui.getCore().byId("adminCommentsFID").getValue() !== "") {
				this.AdminComent = sap.ui.getCore().byId("adminCommentsFID").getValue();
				sap.ui.getCore().byId("adminCommentsFID").setValue("");
				this.onMechBumpPress1(this.cSource);
				this._AdminCommentsDialog.close();
			} else {
				sap.m.MessageToast.show("Please enter comments");
			}
		},
		onACommCancel: function () {
			sap.ui.getCore().byId("adminCommentsFID").setValue("");
			this._AdminCommentsDialog.close();
		},
		onMechBumpPress1: function (oEvent) {
			/*this.getRouter().navTo("MechForm");*/
			var that = this;
			var oPath = oEvent.getParent().getParent().getBindingContextPath();
			// var oContext = oEvent.getSource().getParent().getParent().getModel().getProperty(oPath);
			var oContext = oEvent.getModel("bumpListModel").getProperty(oPath);
			var userEmpId = oContext.UserEmpId;
			var empId = oContext.EmpId;
			var empName = oContext.EmpName;
			var posId = oContext.PosId;
			var senDate = oContext.SenDate;
			var posDesc = oContext.PosDesc;
			var Gang = oContext.Gang;
			// if (this.WMessage !== "") {
			// 	sap.m.MessageBox.warning(this.WMessage);
			// }
			// var ebtFlag = oContext.EbtFlag;
			// var ebtDate = oContext.EbtDate;
			var shiftTimings = oContext.ShiftTiming;
			var splitTimings = shiftTimings.split("-");
			var stTimings = splitTimings[0].slice("0", "2") + ":" + splitTimings[0].slice("2").slice("0", "2");
			var endTimings = splitTimings[1].slice("0", "2") + ":" + splitTimings[1].slice("2").slice("0", "2");
			var sTimings = stTimings + " " + "-" + " " + endTimings;
			var rDays = oContext.RestDays;
			var dept = oContext.DeptName;
			var union = oContext.Union;
			var roster = oContext.RosterNo;

			var oSelectedKey = this.byId("depIdSelect").getSelectedKey();
			var mModel = this.getOwnerComponent().getModel("oDataSrv");
			var aMes = "Please find \n Hello";
			var oPos;
			var oStartDate;
			var bData = "";
			var bumbername = "";
			var bumberRoster = "";
			mModel.read("/BumpTransDataSet(EmployeeID='" + empId + "',Bumpee_Roster='" + roster + "',Craft='" + oSelectedKey +
				"',Bumper_EinNo='" + userEmpId +
				"',PositionID='" + posId.toString() + "')", {
					// mModel.read("/BumpTransDataSet(EmployeeID='" + empId + "',Craft='" + oSelectedKey + "',Bumper_EinNo='" + userEmpId +
					// 	"',PositionID='" + posId.toString() + "')", {
					async: false,
					success: function (oData, warring) {
						oPos = oData.PositionID;
						oStartDate = oData.StartDate;
						bData = oData;
						bumbername = oData.Bumper_n;
						bumberRoster = oData.Bumper_roster;
						that.WMessage = "";

						// sap.m.MessageBox.confirm(that.WMessage);

						// that.stopBumpEligibleFunc();
						// } else {
						// 	// that.onRefresh();

						bData.PositionID = oContext.PosId;
						if (oSelectedKey === "T" || oSelectedKey === "ST" || oSelectedKey === "D" || oSelectedKey === "A" || oSelectedKey === "SA" ||
							oSelectedKey === "SD") {
							bData.Department = oContext.DeptName;
							//bData.Shift = oContext.ShiftTiming;
							bData.Rdays = oContext.RestDays;
							//bData.Comments = oContext.AdminComm;
						}
						if (oSelectedKey === "A" || oSelectedKey === "SA") {
							//bData.PositionID = oContext.fix_HQ;
						}
						// bData.SenDate = oContext.SenDate;
						// bData.StartDate = bData.EndDate;
						bData.BumperPosID = that.posId;
						bData.BumperPosDesc = that.PosDesc;
						bData.Admincomnts = that.AdminComent;
						that.sData = bData;
						var sDate = "";
						if (oStartDate) {
							sDate = oStartDate.slice("4").slice("0", "2") + "/" + oStartDate.slice("6") + "/" + oStartDate.slice("0", "4");
						} else {
							sDate = "";
						}
						if (bData.SenDate) {
							senDate = bData.SenDate.slice("4").slice("0", "2") + "/" + bData.SenDate.slice("6") + "/" + bData.SenDate.slice("0", "4");
						} else {
							senDate = "";
						}

						// var a = new Date();
						var efftime = "";
						// var thDate = new Date((a.getTime() + 129600000));
						if (bData.EndDate.length > 8) {
							efftime = bData.EndDate.slice("8", "10") + ":" + bData.EndDate.slice("10", "12");
						}

						var effDate = bData.EndDate.slice("4", "6") + "/" + bData.EndDate.slice("6", "8") + "/" + bData.EndDate.slice("0", "4");

						var effpdatetime = "";
						if (bData.EffTime > 0) {
							effpdatetime = bData.EffTime.slice("0", "2") + ":" + bData.EffTime.slice("2", "4");
						}
						bData.StartDate = bData.EndDate;

						if (!that._oPopover1) {
							that._oPopover1 = sap.ui.xmlfragment("bumpmaint.zbump_maintenance.fragments.TCUATDA", that);
							that.getView().addDependent(that._oPopover1);
						}
						sap.ui.getCore().byId("effDateTime").setVisible(false);
						// if (effDate.split("/")[0].length < 2) {
						// 	effDate = "0" + effDate;
						// }
						// if (effDate.split("/")[1].length < 2) {
						// 	effDate = "0" + effDate;
						// }
						//var efftime = thDate.toLocaleTimeString();
						if (oSelectedKey === "M" || oSelectedKey === "SM") {
							// if (!that._oPopover1) {
							// that._oPopover1 = sap.ui.xmlfragment("bumpmaint.zbump_maintenance.fragments.MechBump", that);
							// that.getView().addDependent(that._oPopover1);

							// this._oPopover.bindElement("/ProductCollection/0");
							// }
							// this.sData.EmpName = empName;
							that.sData.PositionID = posId;
							that.sData.EmployeeID = empId;
							that.sData.Department = dept;
							that.sData.StartDate = bData.EndDate;
							//this.sData.Shift = shiftTimings;
							that.sData.Rdays = rDays;
							that.sData.Union = union;

							that.sData.Bumper_roster = oContext.Rank;
							that.sData.Bumpee_Roster = roster;
							// this.sData.RosterNo = roster;
							// var oMechFormData = {
							// 	results: [this.sData]
							// };
							// var oMechFormModel = new sap.ui.model.json.JSONModel(oMechFormData);
							// this._oPopover.setModel(oMechFormModel);
							// this._oPopover.bindElement("/results/0");
							// this._oPopover.getModel().refresh();
							// var yesDate = new Date(bData.EndDate.slice("0", "4") + "-" + bData.EndDate.slice("4", "6") + "-" + bData.EndDate.slice("6", "8"));
							// effDate = new Date(yesDate.setDate(yesDate.getDate() - 1));
							// effDate = effDate.getMonth() + 1 + "/" + effDate.getDate() + "/" + effDate.getFullYear();
							sap.ui.getCore().byId("mesgId").setText("Union Affiliation: " + union +
								// " Seniority District: " + this.sData.SenDist + 
								"\n\n Employee Name:  " + empName + " \n  EIN#: " + empId + "\n" + "  Roster# " + oContext.Rank +
								"\n\n is hereby notified that effective " + effDate + " that your position  " +
								posId + " - " + posDesc + "  in department  " + dept + " Overhauls " + bData.Shift +
								"  " + rDays + " has been claimed by senior employee  \n\n Employee Name:" + that.EmpName + " \n  EIN#:  " + userEmpId +
								"\n Roster#: " + bumberRoster);

							// that._oPopover1.open();

							// that._oPopover1.setEscapeHandler(function (o) {
							// 	o.reject();
							// });

						} else if (oSelectedKey === "T" || oSelectedKey === "ST" || oSelectedKey === "D" || oSelectedKey === "SD") {
							// if (!that._oPopover1) {
							// that._oPopover1 = sap.ui.xmlfragment("bumpmaint.zbump_maintenance.fragments.TCUATDA", that);
							// that.getView().addDependent(that._oPopover1);
							// }
							if (bData.Flag === "X") {
								sap.ui.getCore().byId("mesgId").setText(
									"I,  " + that.EmpName +
									", have been displaced by " + bData.Bumpee_n +
									"from position " + that.posId + " - " + that.PosDesc + ". \n\n Effective date of my displacement is " +
									sDate + ", at Effective Time " + effpdatetime +
									// "Due to the change to my current Position ID: " +
									// //this.byId("posId").getValue() + " - " + this.byId("posTextId").getText() +
									// this.posId + " - " + this.PosDesc + " " +
									// "effective " + sDate + ".\n" +
									". \n\n Due to the above reason I am displacing " + empName +
									" from positon ID: " + posId + " - " + posDesc + " effective " + effDate + " at " + efftime + "." +
									"           " + "     \n\n My Seniority Date is " + senDate + ".");
							} else {
								sap.ui.getCore().byId("mesgId").setText("Due to the change to my current Position: " +
									//this.byId("posId").getValue() + " - " + this.byId("posTextId").getText() +
									that.posId + " - " + that.PosDesc + " " +
									"effective " + sDate + ".\n" +
									"\nDue to the above reason I am displacing " + empName +
									" from positon ID: " + posId + " - " + posDesc + " effective " + effDate + " at " + efftime + "." +
									"           " + "     \n\n My Seniority Date is " + senDate + ".");
							}
							// that._oPopover1.open();

							// that._oPopover1.setEscapeHandler(function (o) {
							// 	o.reject();
							// });

						} else if (oSelectedKey === "E" || oSelectedKey === "SE") {
							var Gangdesc = "";
							if (Gang !== "") {
								Gangdesc = " on " + Gang;
							}
							sap.ui.getCore().byId("mesgId").setText(that.EmpName + "  (" + userEmpId + ") is displacing " + empName + " (" + empId +
								") from Position ID: " +
								//this.byId("posId").getValue() + " - " + this.byId("posTextId").getText() +
								posId + " - " + posDesc + Gangdesc + ".");
							sap.ui.getCore().byId("effDateTime").setVisible(true);
							sap.ui.getCore().byId("dateTimeForAllId").setValue("" + effDate + efftime);

						}
						if (warring.headers["sap-message"]) {
							var WMessage = JSON.parse(warring.headers["sap-message"]).message;
							if (WMessage) {
								that.WMessage = WMessage;
								sap.m.MessageBox.confirm(that.WMessage, {
									title: "Confirm",
									actions: [sap.m.MessageBox.Action.YES, sap.m.MessageBox.Action.NO],
									onClose: function (oAction) {
										if (oAction === "YES") {
											that._oPopover1.open();
											that._oPopover1.setEscapeHandler(function (o) {
												o.reject();
											});
										}
									}
								});
							} else {
								that._oPopover1.open();
								that._oPopover1.setEscapeHandler(function (o) {
									o.reject();
								});
							}
						} else {
							that._oPopover1.open();
							that._oPopover1.setEscapeHandler(function (o) {
								o.reject();
							});
						}
						// populating same shift timings shown on UI
						if (oSelectedKey === "M" || oSelectedKey === "SM") {
							return;
						}
						if (sTimings !== "") {
							that.sData.Shift = sTimings;
						}
					},
					error: function () {}
				});
			if (oSelectedKey === "M" || oSelectedKey === "SM") {
				this.sData.Shift = bData.Shift;
			}
		},
		oncCancel: function () {
			var oSelectedKey = this.byId("depIdSelect").getSelectedKey();
			if (oSelectedKey === "M" || oSelectedKey === "SM") {
				this._oPopover1.close();
				// this._oPopover1.destroy(true);
				// this._oPopover1 = undefined;
			} else if (oSelectedKey === "T" || oSelectedKey === "E" || oSelectedKey === "SE" || oSelectedKey === "ST" || oSelectedKey === "D" ||
				oSelectedKey === "SD") {
				this._oPopover1.close();
				// this._oPopover1.destroy(true);
				// this._oPopover1 = undefined;
			}
		},
		/*onBumpListLive: function (oEvent) {
			var oVal = oEvent.getSource().getValue();
			var oTable = this.byId("atdaTableId");
			if (oVal.trim().length > 0) {
				var oFilter = new sap.ui.model.Filter("EmpId", "Contains",
					oVal);
				var oTableBindings = oTable.getBinding("items");
				oTableBindings.filter([oFilter]);
			} else {
				this.onGetCallFunc("A", oTable);
			}
		},*/
		//begin new code - D5OW5 - 01/31/2022
		onBumpListLive: function (oEvent) {
			var that = this;
			var oVal = oEvent.getSource().getValue();
			var oTable = this.byId("bumpList");
			oTable.setVisible(true);
			this.onGetCallFunc(that.craftUnion, oTable, oVal);
			that.byId("EmpNameId").setText();
			that.byId("rrCodeId").setText();
			that.byId("cdlId").setText();
		},
		//end new code - D5OW5 - 01/31/2022
		onConfirm: function () {
			var that = this;
			var oSelectedKey = that.byId("depIdSelect").getSelectedKey();
			var oData = that.sData;
			oData.Bumptriggger = "X";
			oData.Craft = oSelectedKey;
			oData.Bumper_EinNo = that.byId("bumpListEmpId").getTokens()[0].getKey();

			// sap.m.MessageToast.show("Success");
			if (oSelectedKey === "E" || oSelectedKey === "SE") {
				if (sap.ui.getCore().byId("dateTimeForAllId").getValue() === "") {
					sap.m.MessageBox.information("Please enter effective date");
					return;
				} else {
					oData.StartDate = sap.ui.getCore().byId("dateTimeForAllId").getValue();
				}
			}
			var oData = that.sData;
			oData.Bumptriggger = "X";
			oData.Craft = oSelectedKey;
			oData.Bumper_EinNo = that.byId("bumpListEmpId").getTokens()[0].getKey();
			var mModel = that.getOwnerComponent().getModel("oDataSrv");
			mModel.create("/BumpTransDataSet", oData, {
				async: false,
				success: function (succ) {
					if (oSelectedKey === "M" || oSelectedKey === "SM") {
						that._oPopover1.close();
						// 		this._oPopover1.destroy(true);
						// this._oPopover1 = undefined;
					} else if (oSelectedKey === "T" || oSelectedKey === "ST" || oSelectedKey === "D" || oSelectedKey === "SD" || oSelectedKey ===
						"E" || oSelectedKey === "SE") {
						that._oPopover1.close();
						// that._oPopover1.destroy(true);
						// that._oPopover1 = undefined;
					}
					that.byId("depIdSelect").fireChange(that.byId("depIdSelect").getSelectedItem());
				},
				error: function (err) {
					var messageLen = JSON.parse(err.response.body).error.innererror.errordetails;
					var msg = "";
					for (var i = 0; i < messageLen.length; i++) {
						if (!messageLen[i].message.includes("without specific error")) {
							msg = messageLen[i].message;
						}
					}
					if (messageLen.length === 0) {
						msg = JSON.parse(err.response.body).error.message.value;
					}
					sap.m.MessageBox.error(msg);
					if (oSelectedKey === "M" || oSelectedKey === "SM") {
						that._oPopover1.close();
						// 		this._oPopover1.destroy(true);
						// this._oPopover1 = undefined;
					} else if (oSelectedKey === "T" || oSelectedKey === "ST" || oSelectedKey === "D" || oSelectedKey === "SD" || oSelectedKey ===
						"E" || oSelectedKey === "SE") {
						that._oPopover1.close();
						// that._oPopover1.destroy(true);
						// that._oPopover1 = undefined;
					}
					//refresh - bumpList after success message
					that.byId("bumpList").destroyItems();
					that.byId("bumpListEmpId").setValue();
				}
			});
		},

		onShiftFormat: function (oVal) {
			if ((oVal !== "000000") && (oVal !== null)) {
				var oValSplit = oVal.split("-");

				var hh = oValSplit[0].slice("0", "2");
				var mm = oValSplit[0].slice("2", "4");
				var date = hh + ":" + mm;

				var hh1 = oValSplit[1].slice("0", "2");
				var mm1 = oValSplit[1].slice("2", "4");
				var date1 = hh1 + ":" + mm1;

				var sTimings = date + " " + "-" + " " + date1;

				return sTimings;
			} else {
				return "00:00:00 - 00:00";
			}
		},
		onBumpedStoppedConfirm: function () {
			var oModel = this.getView().byId("bumpTableId").getModel();
			var comments = sap.ui.getCore().byId("bumpStoppedComments").getValue();
			if (comments.trim() === "") {
				sap.ui.getCore().byId("bumpStoppedComments").setValueState("Error");
				sap.m.MessageToast.show("Please add some comments");
			} else {
				sap.ui.getCore().byId("bumpStoppedComments").setValueState("None");
				oModel.setProperty(this.path + "/BumpStop", "X");
				oModel.setProperty(this.path + "/Comments", comments);
				sap.m.MessageToast.show("Comments Saved Successfully");
				this.bumpStoppedDialog.close();
				// oModel.refresh();
			}

		},

		onDataExport: function () {
			var aCols, oRowBinding, oSettings, oSheet, oTable;

			if (!this._oTable) {
				this._oTable = this.byId("bumpList");
			}

			oTable = this._oTable;
			oRowBinding = oTable.getBinding("items");

			aCols = this.createColumnConfig();
			var aProducts = this.getView().byId("bumpList").getModel("bumpListModel").getData().results;
			//dateTimeFormatFunc
			for (var i = 0; i < aProducts.length; i++) {
				aProducts[i].ShiftTiming = this.onShiftFormat(aProducts[i].ShiftTiming);
				var senDate = aProducts[i].SenDate;
				aProducts[i].SenDate = senDate.slice("4").slice("0", "2") + "/" + senDate.slice("6") + "/" + senDate.slice("0", "4");
			}
			aProducts[0].CDL1 = this.getView().byId("cdlId").getText();
			aProducts[0].EmpID1 = this.getView().byId("bumpListEmpId").getTokens()[0].getKey();
			aProducts[0].EmpName1 = this.getView().byId("EmpNameId").getText();
			aProducts[0].RRCode1 = this.getView().byId("rrCodeId").getText();
			oSettings = {
				workbook: {
					columns: aCols
				},
				dataSource: aProducts

			};

			oSheet = new Spreadsheet(oSettings);
			oSheet.build().build()
				.then(function () {})
				.finally(function () {
					oSheet.destroy();
				});
		},
		onClosePO: function () {
			this._pPopover.close();
		},
		onMechAction: function (oEvt) {
			var QualDesc = oEvt.getSource().getParent().getParent().getModel("bumpListModel").getProperty(oEvt.getSource().getParent().getParent()
				.getBindingContextPath()).QualDesc.split(";");
			if (!this._pPopover) {
				this._pPopover = sap.ui.xmlfragment("bumpmaint.zbump_maintenance.fragments.QualPO",
					this);
			}
			var QualText = [];
			for (var i = 0; i < QualDesc.length; i++) {

				QualText.push({
					"id": QualDesc[i].split("-")[0],
					"text": QualDesc[i].split("-")[1]
				});
			}
			var oViewModel = new sap.ui.model.json.JSONModel(QualText);
			oViewModel.setSizeLimit(10000);
			if (QualText.length > 0 && QualText[0].id !== "") {
				this._pPopover.open();
			}
			sap.ui.getCore().byId("QualTextsID").setModel(oViewModel, "QualData");
		},
		createColumnConfig: function () {
			var aCols = [];
			if (this.craftUnion !== "SE" && this.craftUnion !== "E") {

				aCols.push({
					label: 'Rank',
					property: 'Rank',
					type: 'string'
				});
			}
			if (this.craftUnion === "SE" || this.craftUnion === "E") {
				aCols.push({
					label: 'Employee ID',
					property: 'EmpID1',
					type: 'string'
				});
				aCols.push({
					label: 'Employee Name',
					property: 'EmpName1',
					type: 'string'
				});
				aCols.push({
					label: 'RR Code',
					property: 'RRCode1',
					type: 'string'
				});
				aCols.push({
					label: 'CDL',
					property: 'CDL1',
					type: 'string'
				});
				aCols.push({
					label: 'Roster',
					property: 'RosterNo',
					type: 'string'
				});
			}
			aCols.push({
				label: 'Seniority Date',
				type: 'string',
				property: 'SenDate'
			});
			if (this.craftUnion === "SE" || this.craftUnion === "E") {
				aCols.push({
					label: 'Roster Rank (Live Rank)',
					property: 'Rank',
					type: 'string'
				});
				aCols.push({
					label: 'RR Hired',
					property: 'RRHired',
					type: 'string'
				});
				aCols.push({
					label: 'Employee ID',
					property: 'EmpId',
					type: 'string'
				});
			}
			aCols.push({
				label: 'Employee Name',
				property: 'EmpName',
				type: 'string'
			});
			if (this.craftUnion === "SM" || this.craftUnion === "M") {
				aCols.push({
					label: 'Position ID',
					property: 'PosId',
					type: 'string'
				});
			}
			if (this.craftUnion === "SE" || this.craftUnion === "E") {
				aCols.push({
					label: 'Position ID',
					property: 'PosId',
					type: 'string'
				});
			}
			if (this.craftUnion !== "SM" || this.craftUnion !== "M") {
				aCols.push({
					label: 'Position Title',
					property: 'PosDesc',
					type: 'string'
				});
			}
			if (this.craftUnion === "SE" || this.craftUnion === "E") {
				aCols.push({
					label: 'CDL',
					property: 'QualDesc',
					type: 'string'
				});

				aCols.push({
					label: 'Assignment Type',
					property: 'AssgnType',
					type: 'string'
				});
			}
			if (this.craftUnion === "SM" || this.craftUnion === "M" || this.craftUnion === "ST" || this.craftUnion === "T") {
				aCols.push({
					label: 'Department',
					property: 'DeptName',
					type: 'string'
				});
			}
			if (this.craftUnion === "SD" || this.craftUnion === "D") {
				aCols.push({
					label: 'Desk Number',
					property: 'DeskNumber',
					type: 'string'
				});
			}
			// begin insert -D5OW5 - Dt 03/06/2022
			if (this.craftUnion === "SM" || this.craftUnion === "M") {
				aCols.push({
					label: 'Union', // added union
					property: 'Union',
					type: 'string'
				});

			}
			// end insert -D5OW5 - Dt 03/06/2022
			if (this.craftUnion === "SM" || this.craftUnion === "M") {
				aCols.push({
					label: 'Job Description',
					property: 'JobDesc',
					type: 'string'
				});
			}
			if (this.craftUnion === "SE" || this.craftUnion === "E") {
				aCols.push({
					label: 'Gang',
					property: 'Gang',
					type: 'string'
				});

				aCols.push({
					label: 'Location',
					property: 'Location',
					type: 'string'
				});

				aCols.push({
					label: 'Fixed Head Quarter',
					property: 'FixHeadquart',
					type: 'string'
				});
				aCols.push({
					label: 'Division',
					property: 'Division',
					type: 'string'
				});

				aCols.push({
					label: 'District',
					property: 'District',
					type: 'string'
				});
			} else {
				aCols.push({
					label: 'Shift Timings',
					property: 'ShiftTiming',
					type: 'string'
				});

				aCols.push({
					label: 'Rest Days',
					property: 'RestDays',
					type: 'string'
				});
			}
			if (this.craftUnion === "SM" || this.craftUnion === "M") {
				aCols.push({
					label: 'Differential Code - Pay Rate', // added pay rate
					property: 'DifftimeCode',
					type: 'string'
				});
				// begin comment --D5OW5 - Dt 03/06/2022
				// aCols.push({
				// 	label: 'Union', // added union
				// 	property: 'Union',
				// 	type: 'string'
				// });
				// end comment --D5OW5 - Dt 03/06/2022
			} else {
				aCols.push({
					label: 'Differential Code', // added pay rate
					property: 'DifftimeCode',
					type: 'string'
				});

				aCols.push({
					label: 'Pay Rate',
					property: 'PayRate',
					type: 'string'
				});
			}
			// aCols.push({
			// 	label: 'Start Date & Time',
			// 	type: 'string',
			// 	property: ['BumpSdate','BumpStime']
			// //	format: 'MM/dd/yyyy'
			// });

			// aCols.push({
			// 	label: 'End Date & Time',
			// 	property: ['BumpEdate','BumpEtime'],
			// 	type: 'string'
			// //	format: 'MM/dd/yyyy'
			// });
			if (this.craftUnion === "SM" || this.craftUnion === "M" || this.craftUnion === "ST" || this.craftUnion === "T" || this.craftUnion ===
				"SD" || this.craftUnion === "D") {
				aCols.push({
					label: 'Active or Inactive Roster',
					property: 'ActInact',
					type: 'string'
				});
			}
			aCols.push({
				label: 'Admin Comments',
				property: 'AdminComm',
				type: 'string'
			});

			// aCols.push({
			// 	label: 'Reason Code',
			// 	property: 'ReasonCode',
			// 	type: 'string'
			// });
			// aCols.push({
			// 	label: 'Bump Stopped',
			// 	property: 'BumpStop',
			// 	type: 'string'
			// });
			// aCols.push({
			// 	label: 'Bump Triggered',
			// 	property: 'BumpTrigger',
			// 	type: 'string'
			// });

			return aCols;
		},

		onBumpStoppedCancel: function () {
			this.bumpStoppedDialog.close();
			sap.ui.getCore().byId("bumpStoppedComments").setValueState("None");
			sap.ui.getCore().byId("bumpStoppedComments").setValue("");
		},
		onCheckSelect: function (oEvent) {
			if (oEvent.getSource().getSelected()) {
				this.openBumpCommentsDialog(oEvent);
			} else {
				var oModel = this.getView().byId("bumpTableId").getModel();
				oModel.setProperty(this.path + "/BumpStop", "");
				oModel.setProperty(this.path + "/Comments", "");
			}
		},
		onBumpCommentsPress: function (oEvent) {
			this.openBumpCommentsDialog(oEvent);
		},
		openBumpCommentsDialog: function (oEvent) {
			var that = this;
			var sPath = oEvent.getSource().getBindingContext().getPath();
			this.path = sPath;
			var oModel = oEvent.getSource().getModel();
			var comments = oModel.getProperty(sPath).Comments;
			if (!that.bumpStoppedDialog) {
				that.bumpStoppedDialog = sap.ui.xmlfragment("bumpmaint.zbump_maintenance.fragments.BumpStoppedComments", that.getView()
					.getController());
				that.getView().addDependent(that.bumpStoppedDialog);
			}
			that.bumpStoppedDialog.open();

			that.bumpStoppedDialog.setEscapeHandler(function (o) {
				o.reject();
			});

			sap.ui.getCore().byId("bumpStoppedComments").setValue(comments);
		},
		onJobPress: function (oEvent) {
			var that = this;
			var oSelectedItem = oEvent.getSource();
			var oContext = oSelectedItem.getBindingContext("bumpListModel");
			var sPath = oContext.getObject();
			var oViewModel = new sap.ui.model.json.JSONModel(sPath);
			that.getView().setModel(oViewModel, "jobDescMod");
			if (!that.postPaymentDialog) {
				that.postPaymentDialog = sap.ui.xmlfragment("bumpmaint.zbump_maintenance.fragments.jobDescription", that);
				that.getView().addDependent(that.postPaymentDialog);
			}
			that.postPaymentDialog.open();
		},
		onCLose: function () {
			var that = this;
			that.postPaymentDialog.close();
			that.postPaymentDialog.destroy();
			that.postPaymentDialog = null;
		}
	});
});