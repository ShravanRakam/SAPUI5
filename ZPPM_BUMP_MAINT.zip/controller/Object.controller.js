sap.ui.define(["bumpmaint/zbump_maintenance/controller/BaseController", "sap/ui/model/json/JSONModel", "sap/ui/core/routing/History",
	"bumpmaint/zbump_maintenance/model/formatter"
], function (e, t, n, i) {
	"use strict";
	return e.extend("bumpmaint.zbump_maintenance.controller.Object", {
		formatter: i,
		onInit: function () {
			var e, n = new t({
				busy: true,
				delay: 0
			});
			this.getRouter().getRoute("object").attachPatternMatched(this._onObjectMatched, this);
			e = this.getView().getBusyIndicatorDelay();
			this.setModel(n, "objectView");
			this.getOwnerComponent().getModel().metadataLoaded().then(function () {
				n.setProperty("/delay", e);
			});
		},
		onNavBack: function () {
			var e = n.getInstance().getPreviousHash();
			if (e !== undefined) {
				history.go(-1);
			} else {
				this.getRouter().navTo("worklist", {}, true);
			}
		},
		_onObjectMatched: function (e) {
			var t = e.getParameter("arguments").objectId;
			this.getModel().metadataLoaded().then(function () {
				var e = this.getModel().createKey("GangDetailsSet", {
					GangId: t
				});
				this._bindView("/" + e);
			}.bind(this));
		},
		_bindView: function (e) {
			var t = this.getModel("objectView"),
				n = this.getModel();
			this.getView().bindElement({
				path: e,
				events: {
					change: this._onBindingChange.bind(this),
					dataRequested: function () {
						n.metadataLoaded().then(function () {
							t.setProperty("/busy", true);
						});
					},
					dataReceived: function () {
						t.setProperty("/busy", false);
					}
				}
			});
		},
		_onBindingChange: function () {
			var e = this.getView(),
				t = this.getModel("objectView"),
				n = e.getElementBinding();
			if (!n.getBoundContext()) {
				this.getRouter().getTargets().display("objectNotFound");
				return;
			}
			var i = this.getResourceBundle(),
				a = e.getBindingContext().getObject(),
				o = a.GangId,
				s = a.City;
			t.setProperty("/busy", false);
			t.setProperty("/shareSendEmailSubject", i.getText("shareSendEmailObjectSubject", [o]));
			t.setProperty("/shareSendEmailMessage", i.getText("shareSendEmailObjectMessage", [s, o, location.href]));
		}
	});
});