sap.ui.define([], function () {
	"use strict";

	return {

		/**
		 * Rounds the number unit value to 2 digits
		 * @public
		 * @param {string} sValue the number string to be rounded
		 * @returns {string} sValue with 2 digits rounded
		 */
		numberUnit: function (sValue) {
			if (!sValue) {
				return "";
			}
			return parseFloat(sValue).toFixed(2);
		},

		DateFormat: function (sValue) {
			var FormatedDate;
			if (sValue === null || sValue === undefined) {
				FormatedDate = "";
			} else {
				var year = sValue.slice("0", "4");
				var month = sValue.slice("4").slice("0", "2");
				var day = sValue.slice("6");
				FormatedDate = month + "/" + day + "/" + year;

				/*var dateFormat = sap.ui.core.format.DateFormat.getDateInstance({
					pattern: "YYYY/MM/DD"
				});
				FormatedDate = dateFormat.format(sValue);*/

			}
			return FormatedDate;

		}

	};

});