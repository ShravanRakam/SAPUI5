var close;
var error;
sap.ui.define([
	"./BaseController",
	"sap/ui/model/json/JSONModel",
	"../model/formatter",
	"sap/ui/model/Filter",
	"sap/ui/model/FilterOperator"
], function (BaseController, JSONModel, formatter, Filter, FilterOperator) {
	"use strict";
	return BaseController.extend("com.tempforceassignment.Temp_ForceAssignment.controller.Worklist", {
		formatter: formatter,
		/* =========================================================== */
		/* lifecycle methods                                           */
		/* =========================================================== */
		/**
		 * Called when the worklist controller is instantiated.
		 * @public
		 */
		onInit: function () {
			var that = this;

			var browser = sap.ui.Device.browser;
			var oViewModel = new JSONModel({
				Craft: ""
			});
			this.getView().setModel(oViewModel, "worklistView");
			//-------- Get user information by calling the below service. --------
			that.craftUnion = "";
			var oLoggedinUser;
			var y = "/sap/bc/ui2/start_up";
			var xmlHttp = null;
			xmlHttp = new XMLHttpRequest();
			xmlHttp.onreadystatechange = function () {
				if (xmlHttp.readyState === 4 && xmlHttp.status === 200) {
					var oUserData = JSON.parse(xmlHttp.responseText);
					oLoggedinUser = oUserData.id;
					jQuery.sap.require("jquery.sap.storage");
					jQuery.sap.storage(jQuery.sap.storage.Type.local).put("UserName", oLoggedinUser);
					var listFil = [];
					var loginUser = new sap.ui.model.Filter("Uname", "EQ", oLoggedinUser);
					listFil.push(loginUser);
					var oModel = that.getOwnerComponent().getModel();
					oModel.read("/UserDetailsSet", {
						filters: listFil,
						success: function (oData) {
							var roleResults = oData.results;
							that.wholeData = roleResults;
							var roleArray = roleResults.slice();
							var roleFinalArray = that.uniqueRoleDropDownValFun(roleArray, "Role");
							var roleSelectedKey = roleFinalArray[0].Unions;

							var oRoleArray = {
								results: roleFinalArray
							};
							var oRoleModel = new sap.ui.model.json.JSONModel(oRoleArray);
							var oRoleDropDown = that.byId("roleId");
							oRoleDropDown.setModel(oRoleModel, "roleData");
							that.byId("roleId").setSelectedKey(roleSelectedKey);
							var oSelRole = that.byId("roleId").getSelectedItem().getProperty("text");
							var deptArray = [];
							for (var i = 0; i < that.wholeData.length; i++) {
								var deptObj = {};
								if (oSelRole === that.wholeData[i].Role) {
									deptObj.Department = that.wholeData[i].Department;
									deptObj.Unions = that.wholeData[i].Unions;
									deptArray.push(deptObj);
								}
							}
							var oViewModel = new sap.ui.model.json.JSONModel({
								Department: oData.results[0].Department
							});
							that.getView().setModel(oViewModel, "viewModel");
							var deptFinalArray = that.uniqueDeptDropDownValFun(deptArray, "Department");
							var deptSelectedKey = deptFinalArray[0].Unions;
							var oDeptArray = {
								results: deptFinalArray
							};
							var oDeptModel = new sap.ui.model.json.JSONModel(oDeptArray);
							var oDeptDropDown = that.byId("deptId");
							oDeptDropDown.setModel(oDeptModel, "deptData");
							that.byId("deptId").setSelectedKey(deptSelectedKey);
							var roleGetSelectedKey = that.byId("roleId").getSelectedKey();
							var deptGetSelectedKey = that.byId("deptId").getSelectedKey();
							if (oSelRole === "LR Admin") {
								that.byId("deptId").setEnabled(true);
								that.byId("deptId").setValue();
								that.byId("saveBtn").setVisible(false);
								that.byId("cancelBtn").setVisible(false);
							} else {
								that.byId("deptId").setEnabled(true);
								that.byId("deptId").setSelectedKey(roleGetSelectedKey);
								that.byId("saveBtn").setVisible(true);
								that.byId("cancelBtn").setVisible(true);
							}
							if (deptGetSelectedKey === "E" || deptGetSelectedKey === "SE") {
								that.craftUnion = "Engineering";
							}
							if (deptGetSelectedKey === "M" || deptGetSelectedKey === "SM") {
								that.craftUnion = "Mechanical";
							}
							if (deptGetSelectedKey === "T" || deptGetSelectedKey === "ST") {
								that.craftUnion = "TCU";
							}
							if (deptGetSelectedKey === "D" || deptGetSelectedKey === "SD") {
								that.craftUnion = "ATDA";
							}
							if (deptGetSelectedKey === "L" || deptGetSelectedKey === "SL") {
								that.craftUnion = "ILA";
							}
							if (deptGetSelectedKey === "C" || deptGetSelectedKey === "SC") {
								that.craftUnion = "Conrail";
							}
							if (deptGetSelectedKey === "I" || deptGetSelectedKey === "SI") {
								that.craftUnion = "IHB";
							}
							if (deptGetSelectedKey === "N" || deptGetSelectedKey === "SN") {
								that.craftUnion = "NAHR";
							}
							that.getView().getModel("worklistView").setProperty("/Craft", that.craftUnion);
						},
						error: function (oResponse) {
							that.initialErrorMsgFun(oResponse);
						}
					});
				}
			};
			xmlHttp.open("GET", y, false);
			xmlHttp.send(null);
			//------ Defaulting current date to the effective date field ------
			that.defaultDate();
			//------ Reason Code drop down binding ------
			that.reasonComboBox();
			that.histDetailsArr = [];
			that.byId("tempEndDate").setEnabled(true);
		},
		//-----------------------------------------------------------------------	
		// Method for gettting uniq drop down values.
		//-----------------------------------------------------------------------
		uniqueRoleDropDownValFun: function (roleArray, Role) {
			var oArray = [];
			var checkArray = [];
			for (var i = 0; i < roleArray.length; i++) {
				if (oArray.indexOf(roleArray[i]["" + Role + ""]) === -1 && roleArray[i]["" + Role + ""].trim() !== "") {
					oArray.push(roleArray[i]["" + Role + ""]);
					var uObj = Object.assign({}, roleArray[i]);
					checkArray.push(uObj);
				}
			}
			return checkArray;
		},
		uniqueDeptDropDownValFun: function (deptArray, Department) {
			var oArray = [];
			var checkArray = [];
			for (var i = 0; i < deptArray.length; i++) {
				if (oArray.indexOf(deptArray[i]["" + Department + ""]) === -1 && deptArray[i]["" + Department + ""].trim() !== "") {
					oArray.push(deptArray[i]["" + Department + ""]);
					var uObj = Object.assign({}, deptArray[i]);
					checkArray.push(uObj);
				}
			}
			return checkArray;
		},
		onRoleChange: function (oEvent) {
			var that = this;
			var oRole = oEvent.getParameter("selectedItem").getProperty("key");
			that.byId("positonIdInp").setTokens([]);
			that.onPosLiveChange();
			var oSelRole = oEvent.getParameter("selectedItem").getProperty("text");
			var deptArr = [];
			for (var i = 0; i < that.wholeData.length; i++) {
				var departmentObj = {};
				if (oSelRole === that.wholeData[i].Role) {
					departmentObj.Department = that.wholeData[i].Department;
					departmentObj.Unions = that.wholeData[i].Unions;
					deptArr.push(departmentObj);
				}
			}
			var deptFinalArr = that.uniqueDeptDropDownValFun(deptArr, "Department");
			var deptSelectedKey = deptFinalArr[0].Unions;
			var oDeptArray = {
				results: deptFinalArr
			};
			var oDeptModel = new sap.ui.model.json.JSONModel(oDeptArray);
			var oDeptDropDown = that.byId("deptId");
			oDeptDropDown.setModel(oDeptModel, "deptData");
			that.byId("deptId").setSelectedKey(deptSelectedKey);
			var oSelDept = that.byId("deptId").getSelectedItem().getProperty("key");
			if (oSelDept === "E" || oSelDept === "SE") {
				that.craftUnion = "Engineering";
			}
			if (oSelDept === "M" || oSelDept === "SM") {
				that.craftUnion = "Mechanical";
			}
			if (oSelDept === "T" || oSelDept === "ST") {
				that.craftUnion = "TCU";
			}
			if (oSelDept === "D" || oSelDept === "SD") {
				that.craftUnion = "ATDA";
			}
			if (oSelDept === "L" || oSelDept === "SL") {
				that.craftUnion = "ILA";
			}
			if (oSelDept === "C" || oSelDept === "SC") {
				that.craftUnion = "Conrail";
			}
			if (oSelDept === "I" || oSelDept === "SI") {
				that.craftUnion = "IHB";
			}
			if (oSelDept === "N" || oSelDept === "SN") {
				that.craftUnion = "NAHR";
			}
			if (oSelRole === "LR Admin") {
				that.byId("deptId").setEnabled(true);
				that.byId("deptId").setValue();
				that.byId("saveBtn").setVisible(false);
				that.byId("cancelBtn").setVisible(false);
			} else {
				that.byId("deptId").setEnabled(true);
				that.byId("deptId").setSelectedKey(oRole);
				that.byId("saveBtn").setVisible(true);
				that.byId("cancelBtn").setVisible(true);
			}
			that.getView().getModel("worklistView").setProperty("/Craft", that.craftUnion);
		},
		onDeptChange: function (oEvent) {
			var that = this;
			var oDept = oEvent.getParameter("selectedItem").getProperty("key");
			that.byId("positonIdInp").removeAllTokens();
			that.onPosLiveChange();
			that.changeValFlag = undefined;
			that.tempPosDataFormClrFun();
			//			that.onPosLiveChange();
			if (oDept === "E" || oDept === "SE") {
				that.craftUnion = "Engineering";
			}
			if (oDept === "M" || oDept === "SM") {
				that.craftUnion = "Mechanical";
			}
			if (oDept === "T" || oDept === "ST") {
				that.craftUnion = "TCU";
			}
			if (oDept === "D" || oDept === "SD") {
				that.craftUnion = "ATDA";
			}
			if (oDept === "L" || oDept === "SL") {
				that.craftUnion = "ILA";
			}
			if (oDept === "C" || oDept === "SC") {
				that.craftUnion = "Conrail";
			}
			if (oDept === "I" || oDept === "SI") {
				that.craftUnion = "IHB";
			}
			if (oDept === "N" || oDept === "SN") {
				that.craftUnion = "NAHR";
			}
			that.getView().getModel("worklistView").setProperty("/Craft", that.craftUnion);

		},
		onAfterRendering: function () {
			var that = this;
			close = that.getView().getModel("i18n").getProperty("close");
			error = that.getView().getModel("i18n").getProperty("titleError");
		},
		//-----------------------------------------------------------------------	
		// Reason drop down binding.
		//-----------------------------------------------------------------------
		reasonComboBox: function () {
			var that = this;
			var reasonComboBox = that.getView().byId("reasonHeaderCombo");
			that.selReasonVal = reasonComboBox.getValue();
			var oModel = that.getOwnerComponent().getModel();
			var rbValue = "T";
			if (that.selRBIndex === 1) {
				rbValue = "F";
			} else if (that.selRBIndex === 2) {
				rbValue = "H";
			}
			var queryFil = [];
			var rbv = new sap.ui.model.Filter("rflag", "EQ", rbValue);
			queryFil.push(rbv);
			oModel.read("/ReasonSet", {
				filters: queryFil,
				success: function (oData) {
					var oReasonModel = new sap.ui.model.json.JSONModel({
						"results": oData.results
					});
					reasonComboBox.setModel(oReasonModel, "reasonHeaderMod");
					that.byId("reasonHeaderCombo").setValue(that.selReasonVal);
				},
				error: function (oResponse) {
					that.initialErrorMsgFun(oResponse);
				}
			});
		},
		initialErrorMsgFun: function (oResponse) {
			var that = this;
			//-----------------------------------------------------------------------	
			// Displaying response body message.
			//-----------------------------------------------------------------------
			var errMsg = JSON.parse(oResponse.responseText).error.message.value;
			var oSplitMsg = errMsg.split(":");
			var oMsgFlag = oSplitMsg[0];
			sap.m.MessageBox.show(errMsg, {
				icon: sap.m.MessageBox.Icon.ERROR,
				title: error,
				actions: [sap.m.MessageBox.Action.OK],
				onClose: function (oAction) {
					if (oAction === sap.m.MessageBox.Action.OK) {
						if (oMsgFlag === "User") {
							that.byId("positonIdInp").setEnabled(false);
							that.byId("tempEmpNoInp").setEnabled(false);
							that.byId("reasonHeaderCombo").setEnabled(false);
							that.byId("tempStDate").setEnabled(false);
							that.byId("tempEndDate").setEnabled(false);
						} else {
							that.byId("positonIdInp").setEnabled(true);
							that.byId("tempEmpNoInp").setEnabled(true);
							that.byId("reasonHeaderCombo").setEnabled(true);
							that.byId("tempStDate").setEnabled(true);
							that.byId("tempEndDate").setEnabled(false);
						}
					}
				}
			});
		},
		//-----------------------------------------------------------------------	
		// Selecting Temporary radio button.
		//-----------------------------------------------------------------------
		onTempRbSelect: function (oEvent) {
			var that = this;
			var plsSaveCancelUnsavedData = that.getView().getModel("i18n").getProperty("plsSaveCancelUnsavedData");
			if (that.changeValFlag === "X") {
				var selectedRb = that.byId("assignmentRb").getSelectedIndex();
				if (selectedRb === 0) {
					that.byId("assignmentRb").setSelectedIndex(1);
				} else if (selectedRb === 1) {
					that.byId("assignmentRb").setSelectedIndex(0);
				}
				sap.m.MessageToast.show(plsSaveCancelUnsavedData);
			}
		},
		//-----------------------------------------------------------------------	
		// Selecting Permanent radio button.
		//-----------------------------------------------------------------------
		onForceRbSelect: function (oEvent) {
			var that = this;
			var plsSaveCancelUnsavedData = that.getView().getModel("i18n").getProperty("plsSaveCancelUnsavedData");
			if (that.changeValFlag === "X") {
				var selectedRb = that.byId("assignmentRb").getSelectedIndex();
				if (selectedRb === 0) {
					that.byId("assignmentRb").setSelectedIndex(1);
				} else if (selectedRb === 1) {
					that.byId("assignmentRb").setSelectedIndex(0);
				}
				sap.m.MessageToast.show(plsSaveCancelUnsavedData);
			}
		},
		//-----------------------------------------------------------------------	
		// Cancel button method.
		//-----------------------------------------------------------------------
		onCancel: function () {
			var that = this;
			var areYouSureWantToClrFields = that.getView().getModel("i18n").getProperty("areYouSureWantToClrFields");
			var titleConfirm = that.getView().getModel("i18n").getProperty("titleConfirm");
			var yes = that.getView().getModel("i18n").getProperty("yes");
			var no = that.getView().getModel("i18n").getProperty("no");
			if (that.byId("assignmentRb").getSelectedButton().getProperty("text") === "Temporary Assignment") {
				sap.m.MessageBox.information(areYouSureWantToClrFields, {
					icon: sap.m.MessageBox.Icon.INFORMATION,
					title: "Information",
					actions: ["YES", "NO"],
					onClose: function (oAction) {
						if (oAction === "YES") {
							that.onTempScreenClrFun();
							that.tempPosDataFormClrFun();
							that.tempExpFalseFun();
						}
					}
				});
			} else if (that.byId("assignmentRb").getSelectedButton().getProperty("text") === "Permanent Assignment") {
				sap.m.MessageBox.information(areYouSureWantToClrFields, {
					icon: sap.m.MessageBox.Icon.INFORMATION,
					title: "Information",
					actions: ["YES", "NO"],
					onClose: function (oAction) {
						if (oAction === "YES") {
							that.onPermScreenClrFun();
							that.permPosDataFormClrFun();
							that.permExpFalseFun();
						}
					}
				});
			} else {
				sap.m.MessageBox.information(areYouSureWantToClrFields, {
					icon: sap.m.MessageBox.Icon.INFORMATION,
					title: "Information",
					actions: ["YES", "NO"],
					onClose: function (oAction) {
						if (oAction === "YES") {
							that.onPermScreenClrFun();
							that.permPosDataFormClrFun();
							that.permExpFalseFun();
						}
					}
				});
			}
		},
		onSave: function (oEvent) {
			var that = this;
			var plsEnterPosId = that.getView().getModel("i18n").getProperty("plsEnterPosId");
			var enterEmpId = that.getView().getModel("i18n").getProperty("enterEmpId");
			var empName = that.getView().byId("tempEmpNameTxt").getText();
			var enterReson = that.getView().getModel("i18n").getProperty("enterReson");
			var selStartDate = that.getView().getModel("i18n").getProperty("selStartDate");
			var selEndDate = that.getView().getModel("i18n").getProperty("selEndDate");
			var craftVal = that.byId("deptId").getSelectedKey();
			var union;
			if (craftVal === "E" || craftVal === "SE") {
				union = "E";
			} else if (craftVal === "M" || craftVal === "SM") {
				union = "M";
			} else if (craftVal === "T" || craftVal === "ST") {
				union = "T";
			} else if (craftVal === "D" || craftVal === "SD") {
				union = "D";
			} else if (craftVal === "L" || craftVal === "SL") {
				union = "L";
			} else if (craftVal === "C" || craftVal === "SC") {
				union = "C";
			} else if (craftVal === "N" || craftVal === "SN") {
				union = "N";
			} else if (craftVal === "I" || craftVal === "SI") {
				union = "I";
			}
			var aObject = {};
			var selRb = that.byId("assignmentRb").getSelectedButton().getText();
			var posIdVal = "";
			if (that.byId("positonIdInp").getTokens().length > 0) {
				posIdVal = that.byId("positonIdInp").getTokens()[0].getKey();
			}
			var posDesc = that.byId("tempPosNameTxt").getText();
			var empNo = "";
			if (that.byId("tempEmpNoInp").getTokens().length > 0) {
				empNo = that.byId("tempEmpNoInp").getTokens()[0].getKey();
			}
			var reasonDesc = that.byId("reasonHeaderCombo").getValue();
			var startDate = that.byId("tempStDate").getValue();
			var endDate = that.byId("tempEndDate").getValue();
			if (posIdVal.length < 1 && that.byId("assignmentRb").getSelectedButton().getText() !== "Holding Position Assignment") {
				that.byId("positonIdInp").setValueState("Error");
				sap.m.MessageToast.show(plsEnterPosId);
			} else if (empNo === "") {
				that.byId("positonIdInp").setValueState("None");
				that.byId("tempEmpNoInp").setValueState("Error");
				sap.m.MessageToast.show(enterEmpId);
			} else if (reasonDesc === "") {
				that.byId("positonIdInp").setValueState("None");
				that.byId("tempEmpNoInp").setValueState("None");
				//	that.byId("reasonHeaderCombo").setValueState("Error");
				sap.m.MessageToast.show(enterReson);
			} else if (startDate === "") {
				that.byId("positonIdInp").setValueState("None");
				that.byId("tempEmpNoInp").setValueState("None");
				that.byId("reasonHeaderCombo").setValueState("None");
				that.byId("tempStDate").setValueState("Error");
				sap.m.MessageToast.show(selStartDate);
			} else if (endDate === "") {
				that.byId("positonIdInp").setValueState("None");
				that.byId("tempEmpNoInp").setValueState("None");
				that.byId("reasonHeaderCombo").setValueState("None");
				that.byId("tempStDate").setValueState("None");
				that.byId("tempEndDate").setValueState("Error");
				sap.m.MessageToast.show(selEndDate);
			} else {
				that.byId("positonIdInp").setValueState("None");
				that.byId("tempEmpNoInp").setValueState("None");
				that.byId("reasonHeaderCombo").setValueState("None");
				that.byId("tempStDate").setValueState("None");
				that.byId("tempEndDate").setValueState("None");
				var StartDate;
				if (startDate.includes("/") !== true) {
					StartDate = startDate;
				} else {
					var splitStartDate = startDate.split("/");
					StartDate = splitStartDate[2] + "" + splitStartDate[0] + "" + splitStartDate[1];
				}
				var EndDate;
				if (endDate.includes("/") !== true) {
					EndDate = endDate;
				} else {
					var splitEndDate = endDate.split("/");
					EndDate = splitEndDate[2] + "" + splitEndDate[0] + "" + splitEndDate[1];
				}
				aObject.PosId = posIdVal;
				aObject.ReasonInput = reasonDesc;
				aObject.PosDesc = posDesc;
				if (startDate.includes("/") !== true) {
					aObject.Begda = startDate;
				} else {
					aObject.Begda = StartDate;
				}
				if (endDate.includes("/") !== true) {
					aObject.Endda = endDate;
				} else {
					aObject.Endda = EndDate;
				}
				aObject.EmpNo = empNo;
				aObject.Comments = that.byId("commentsTxt").getText();
				aObject.BullFlag = "";
				if (selRb === "Temporary Assignment") {
					aObject.Key = "T";
				} else if (selRb === "Permanent Assignment") {
					aObject.Key = "F";
				} else if (selRb === "Holding Position Assignment") {
					aObject.Key = "H";
				}
				aObject.Hkey = "";
				var newFields;
				that.addRoster = "";
				that.senDateValue = "";
				if (that.WmsgFlag !== "") {
					if (that.WmsgFlag.indexOf("Select one of the following roster") !== -1) {
						var comboItems = [];
						if (that.WmsgFlag.indexOf("H07911") !== -1) {
							comboItems.push(new sap.ui.core.ListItem({
								text: "H07911"
							}));
						}
						if (that.WmsgFlag.indexOf("H07912") !== -1) {
							comboItems.push(new sap.ui.core.ListItem({
								text: "H07912"
							}));
						}
						if (that.WmsgFlag.indexOf("H07913") !== -1) {
							comboItems.push(new sap.ui.core.ListItem({
								text: "H07913"
							}));
						}
						newFields = new sap.m.VBox({
							items: [new sap.m.Text({
									text: "Select one of the following rooster"
								}).addStyleClass("clsLabelColor"),
								new sap.m.ComboBox({
									items: comboItems,
									change: function (oEvt) {
										that.addRoster = oEvt.getSource().getValue();
									}
								})
							]
						});
					} else if (that.WmsgFlag.indexOf("Enter Seniority date") !== -1) {
						newFields = new sap.m.VBox({
							items: [new sap.m.Text({
								text: that.WmsgFlag
							}).addStyleClass("clsLabelColor"), new sap.m.DatePicker("datepicker", {
								valueFormat: "yyyyMMdd",
								displayFormat: "MM/dd/yyyy",
								change: function (oEvt) {
									that.senDateValue = oEvt.getSource().getValue();
								}
							})]
						});
					} else {
						newFields = new sap.m.Text({
							text: that.WmsgFlag
						}).addStyleClass("clsLabelColor");
					}
					that.pflag = "";
					if (that.WmsgFlag !== "") {
						if (that.WmsgFlag.includes("does not have seniority on Roster")) {
							that.pflag = "C,nosen";
						}
					}
					var oDialog = new sap.m.Dialog({
						title: "Confirm",
						type: "Message",
						content: newFields,
						beginButton: new sap.m.Button({
							text: "Continue",
							press: function () {
								aObject.Pflag = "C";
								if (that.WmsgFlag.indexOf("Enter Seniority date") !== -1 && that.senDateValue === "") {
									sap.m.MessageToast.show("Please enter Seniority date");
									return;
								}
								if (that.WmsgFlag.indexOf("Enter Seniority date") !== -1 && that.senDateValue !== "") {
									aObject.Pflag = "C2,nosen";
								}
								if (that.WmsgFlag.indexOf("Select one of the following roster") !== -1 && that.addRoster === "") {
									sap.m.MessageToast.show("Please select roster");
									return;
								}
								if (that.WmsgFlag.indexOf("Select one of the following roster") !== -1 && that.addRoster !== "") {
									aObject.Pflag = "C1,nosen";
								}
								aObject.psenioritydate = that.senDateValue;
								aObject.pdpg = that.addRoster;
								that.postDataFun(aObject, selRb);
								oDialog.close();
							}
						}),
						endButton: new sap.m.Button({
							text: "Cancel",
							press: function () {
								oDialog.close();
							}
						}),
						afterClose: function () {
							oDialog.destroy();
						}
					});
					oDialog.open();
					oDialog.setEscapeHandler(function (o) {
						o.reject();
					});
				} else {
					aObject.psenioritydate = that.senDateValue;
					aObject.pdpg = that.addRoster;
					that.postDataFun(aObject, selRb);
				}
			}
		},
		postDataFun: function (aObject, selRb) {
			var that = this;
			var createdSuccFully = that.getView().getModel("i18n").getProperty("createdSuccFully");
			var titleInfo = that.getView().getModel("i18n").getProperty("titleInfo");
			var titleConfirm = that.getView().getModel("i18n").getProperty("titleConfirm");
			var ok = that.getView().getModel("i18n").getProperty("ok");
			var yes = that.getView().getModel("i18n").getProperty("yes");
			var no = that.getView().getModel("i18n").getProperty("no");
			var PosID = "";
			if (that.byId("positonIdInp").getTokens().length > 0) {
				PosID = that.byId("positonIdInp").getTokens()[0].getKey();
			}
			var oPage = that.getView().byId("tempForceAssignmentPage");
			oPage.setBusy(true);
			oPage.setBusyIndicatorDelay(0);
			var oModel = that.getOwnerComponent().getModel();
			if (that.pflag !== "") {
				aObject.Pflag = that.pflag;
			}
			var iconS = sap.m.MessageBox.Icon.SUCCESS;

			oModel.create("/PosTempForcedSet", aObject, {
				success: function (oData) {
					oPage.setBusy(false);
					//sap.m.MessageToast.show(createdSuccFully);
					that.WmsgFlag = oData.WmsgFlag;
					if (that.WmsgFlag !== "") {
						that.onSave();
					} else {
						var msgTemp = that.byId("tempEmpNameTxt").getText() + " (" + aObject.EmpNo + ") has been successfully assigned to " +
							aObject.PosDesc + " (" + aObject.PosId + ")";
						if (that.byId("assignmentRb").getSelectedButton().getText() === "Holding Position Assignment") {
							msgTemp = that.byId("tempEmpNameTxt").getText() + " (" + aObject.EmpNo +
								") has been successfully assigned to holding position " +
								that.byId("engPosTitleIdF1").getText() + " (" + that.byId("engPosIdF1").getText() + ")";
						}
						sap.m.MessageBox.show(msgTemp, {
							icon: iconS,
							title: "Success",
							actions: ["OK"],
							onClose: function (oAction) {
								if (oAction === "OK") {
									if (selRb === "Temporary Assignment") {
										that.byId("commentsIndicatorIcon").setVisible(false);
										that.byId("commentsTxt").setText();
										that.byId("commentsBtn").setText("Add Comments");
										that.onTempValidationFun(selRb);
										var highDate = "12/31/9999";
										that.byId("tempEndDate").setEnabled(true);
										that.byId("tempEndDate").setValue(highDate);
										that.onPosAssignData(PosID, selRb);
									} else if (selRb === "Permanent Assignment") {
										that.byId("saveBtn").setEnabled(false);
										that.permValidationFun(selRb);
										that.onPosAssignData(PosID, selRb);
									} else {
										that.byId("tempEndDate").setEnabled(true);
									}
								}
							}
						});
					}

				},
				error: function (oResponse) {
					oPage.setBusy(false);
					//-----------------------------------------------------------------------	
					// Displaying response body message.
					//-----------------------------------------------------------------------
					var oMessage;
					var titleV = "Information";
					var iconV = sap.m.MessageBox.Icon.INFORMATION;
					if (oResponse.statusCode === 400 || oResponse.statusCode === "400") {
						if (JSON.parse(oResponse.responseText).error.innererror.errordetails[0] !== undefined) {
							oMessage = JSON.parse(oResponse.responseText).error.innererror.errordetails[0].message;
							if (JSON.parse(oResponse.responseText).error.innererror.errordetails[0].severity === "error") {
								titleV = "Error";
								iconV = sap.m.MessageBox.Icon.ERROR;
							}
						} else {
							oMessage = JSON.parse(oResponse.responseText).error.message.value;
						}
					} else if (oResponse.statusCode === 500) {
						oMessage = $(oResponse.responseText).find("message").first().text();
					}
					var msgSplit = oMessage.split(":");
					var msgType = msgSplit[0];
					if (msgType !== "W") {
						sap.m.MessageBox.information(oMessage, {
							icon: iconV,
							title: titleV,
							actions: ["OK"],
							onClose: function (oAction) {
								if (oAction === "OK") {
									if (selRb === "Temporary Assignment") {
										if (msgType === "S") {
											// that.changeValFlag = "";
											that.byId("commentsIndicatorIcon").setVisible(false);
											that.byId("commentsTxt").setText();
											that.byId("commentsBtn").setText("Add Comments");
											that.onTempValidationFun(selRb);
											var highDate = "12/31/9999";
											that.byId("tempEndDate").setEnabled(true);
											that.byId("tempEndDate").setValue(highDate);
											that.onPosAssignData(PosID, selRb);
										}
									} else if (selRb === "Permanent Assignment") {
										if (msgType === "S") {
											// that.changeValFlag = "";
											that.byId("commentsIndicatorIcon").setVisible(false);
											that.byId("commentsTxt").setText();
											that.byId("commentsBtn").setText("Add Comments");
											that.byId("tempEndDate").setEnabled(false);
											that.byId("tempEndDate").setValue("");
											that.permValidationFun(selRb);
											that.onPosAssignData(PosID, selRb);
										}
									}
								}
							}
						});
					} else {
						sap.m.MessageBox.information(oMessage, {
							icon: sap.m.MessageBox.Icon.INFORMATION,
							title: "Information",
							actions: ["OK"],
							onClose: function (oAction) {
								if (oAction === "OK") {
									if (selRb === "Temporary Assignment") {
										if (msgType === "S") {
											// that.changeValFlag = "";
											that.onTempValidationFun(selRb);
										} else if (msgType === "W") {
											aObject.BullFlag = "X";
											that.postAllowFun(aObject, selRb);
										}
									} else if (selRb === "Permanent Assignment") {
										if (msgType === "S") {
											// that.changeValFlag = "";
											that.permValidationFun(selRb);
										} else if (msgType === "W") {
											aObject.BullFlag = "X";
											that.postAllowFun(aObject, selRb);
										}
									}
								}
							}
						});
					}
				}
			});
		},
		postAllowFun: function (aObject, selRb) {
			var that = this;
			that.postDataFun(aObject, selRb);
		},
		onStEnSelectDateChange: function (oEvent) {
			var that = this;
			var selRb = this.byId("assignmentRb").getSelectedButton().getText();
			var selLabelId = oEvent.getParameter("id");
			var selectedLabelId = selLabelId.substring(25);
			that.oDP = oEvent.getSource();
			that.sValue = oEvent.getParameter("value");
			that.bValid = oEvent.getParameter("valid");

			if (selRb === "Temporary Assignment") {
				if (oEvent.getParameter("value").length === 0) {
					that.tempExpFalseFun();
					that.onTempPanelButtonValidation();
				} else {
					oEvent.getSource().setValue(that.sValue);
					var posValue = this.byId("positonIdInp").getTokens();
					var posText = this.byId("tempPosNameTxt").getText();
					this.byId("positonIdInp").setTokens([]);
					var empValue = this.byId("tempEmpNoInp").getTokens();
					this.empName = this.byId("tempEmpNameTxt").getText();
					this.byId("tempEmpNoInp").setTokens([]);
					var reskey = this.byId("reasonHeaderCombo").getSelectedKey();
					that.onTempScreenClrFun();
					that.tempExpFalseFun();
					oEvent.getSource().setValue(that.sValue);
					// that.onTempPanelButtonValidation();
					this.byId("positonIdInp").setTokens(posValue);
					this.byId("tempPosNameTxt").setText(posText);
					this.byId("tempEmpNoInp").setTokens(empValue);
					// this.byId("tempEmpNameTxt").setText(empName);
					this.byId("reasonHeaderCombo").setSelectedKey(reskey);

					// that.onTempValidationFun(selRb);
					// setTimeout(function () {
					this.byId("tempEmpNameTxt").setText(this.empName);
					// }, 3000);

					// if (selectedLabelId === "tempEndDate") {
					// 	that.onEndDateValidation();
					// } else {
					// 	that.forceEndDateSelectFlag = "X";
					// 	that.onStEnDateValidation();
					// }
					that.onTempValidationFun(selRb);
					// this.onHeaderReasonSelection();
					// this.byId("tempEmpNameTxt").setText(empName);
				}
			} else if (selRb === "Permanent Assignment" || selRb === "Holding Position Assignment") {
				if (oEvent.getParameter("value").length === 0) {
					that.permExpFalseFun();
					that.onForcePanelButtonValidation();
				} else {
					oEvent.getSource().setValue(that.sValue);

					var posValue = this.byId("positonIdInp").getTokens();
					var posText = this.byId("tempPosNameTxt").getText();
					this.byId("positonIdInp").setTokens([]);
					var empValue = this.byId("tempEmpNoInp").getTokens();
					this.empName = this.byId("tempEmpNameTxt").getText();
					this.byId("tempEmpNoInp").setTokens([]);
					var reskey = this.byId("reasonHeaderCombo").getSelectedKey();
					that.permExpFalseFun();
					that.onForcePanelButtonValidation();
					this.byId("positonIdInp").setTokens(posValue);
					this.byId("tempPosNameTxt").setText(posText);
					this.byId("tempEmpNoInp").setTokens(empValue);
					// this.byId("tempEmpNameTxt").setText(empName);
					this.byId("reasonHeaderCombo").setSelectedKey(reskey);

					that.permValidationFun(selRb);
					// if (selectedLabelId === "tempEndDate") {
					// 	that.onEndDateValidation();
					// } else {
					// 	that.forceEndDateSelectFlag = "X";
					// 	that.onStEnDateValidation();
					// }
				}
			}
		},
		onPosLiveChange: function (oEvent) {
			var that = this;
			var tempModel = new sap.ui.model.json.JSONModel({
				"results": []
			});
			var tempHistoryTable = that.byId("historyTable");
			tempHistoryTable.setModel(tempModel, "oHistModel");
			// forceHistModel
			var forceModel = new sap.ui.model.json.JSONModel({
				"results": []
			});
			var forceHistoryTable = that.byId("forceHistoryTable");
			forceHistoryTable.setModel(forceModel, "forceHistModel");
			if (oEvent) {

				oEvent.getSource().removeAllTokens();

			}
			if (sap.ui.getCore().byId("commentsArea")) {
				sap.ui.getCore().byId("commentsArea").setValue("");
				this.onCommentsSubmit();
			}
			var selRb = that.byId("assignmentRb").getSelectedButton().getProperty("text");
			// if (posId.trim().length === 0) {
			if (selRb === "Temporary Assignment") {
				that.onTempScreenClrFun();
				that.tempExpFalseFun();
			} else if (selRb === "Permanent Assignment") {
				that.onPermScreenClrFun();
				that.permExpFalseFun();
			}
		},
		onPosLiveChange1: function () {
			var that = this;
			var tempModel = new sap.ui.model.json.JSONModel({
				"results": []
			});
			var tempHistoryTable = that.byId("historyTable");
			tempHistoryTable.setModel(tempModel, "oHistModel");
			var forceModel = new sap.ui.model.json.JSONModel({
				"results": []
			});
			var forceHistoryTable = that.byId("forceHistoryTable");
			forceHistoryTable.setModel(forceModel, "forceHistModel");
			that.byId("positonIdInp").setTokens([]);
			if (sap.ui.getCore().byId("commentsArea")) {
				sap.ui.getCore().byId("commentsArea").setValue("");
				this.onCommentsSubmit();
			}
			var selRb = that.byId("assignmentRb").getSelectedButton().getProperty("text");
			// if (posId.trim().length === 0) {
			if (selRb === "Temporary Assignment") {
				that.onTempScreenClrFun();
				that.tempExpFalseFun();
			} else if (selRb === "Permanent Assignment") {
				that.onPermScreenClrFun();
				that.permExpFalseFun();
			}
		},
		onTempScreenClrFun: function () {
			var that = this;
			var tempItemsArray = [];
			that.changeValFlag = undefined;
			that.headerReasonSel = "";
			that.selReasonVal = "";
			that.posIdDialog = "";
			that.empSrvCalFlag = false;
			that.posSrvCalFlag = false;
			that.byId("positonIdInp").setValueState("None");
			that.byId("positonIdInp").setTokens([]);
			that.byId("tempPosNameTxt").setText();
			that.byId("posTypeIdTemp").setText();
			that.byId("unionCodeIdTemp").setText();
			that.byId("RDaysIdTemp").setText();
			that.byId("agreementIdTemp").setText();
			that.byId("AreaIdTemp").setText();
			that.byId("ShiftIdTemp").setText();
			that.byId("rosterNumIdTemp").setText();
			that.byId("CdlQualId").setText();
			that.byId("CdlQualIdTempEng").setText();

			that.byId("locTemp").setText();
			that.byId("posTitleTemp").setText();
			that.byId("tempStDate").setValueState("None");
			that.byId("tempEmpNoLabel").setVisible(true);
			that.byId("tempEmpNoInp").setVisible(true);
			that.byId("tempEmpNoInp").setTokens([]);
			that.byId("tempEmpNameTxt").setText("");
			that.byId("tempEmpNoInp").setValueState("None");
			that.byId("tempEndDate").setValueState("None");
			that.byId("reasonHeaderCombo").setSelectedKey("");
			that.byId("reasonHeaderCombo").setValueState("None");
			// that.byId("tempAssignmentPosDataForm").setVisible(false);
			that.byId("commentsIndicatorIcon").setVisible(false);
			that.byId("commentsTxt").setText();
			this.byId("commentsBtn").setText("Add Comments");
			that.defaultDate();
			var tempModel = new sap.ui.model.json.JSONModel({
				"results": tempItemsArray
			});
			var tempHistoryTable = that.byId("historyTable");
			tempHistoryTable.setModel(tempModel, "oHistModel");
			var forceModel = new sap.ui.model.json.JSONModel({
				"results": []
			});
			var forceHistoryTable = that.byId("forceHistoryTable");
			forceHistoryTable.setModel(forceModel, "forceHistModel");
			that.byId("saveBtn").setEnabled(false);
		},
		onPermScreenClrFun: function () {
			var that = this;
			var forceItemsArray = [];
			that.forceEndDateSelectFlag = "";
			that.changeValFlag = undefined;
			that.headerReasonSel = "";
			that.selReasonVal = "";
			that.posIdDialog = "";
			that.empSrvCalFlag = false;
			that.posSrvCalFlag = false;
			that.byId("positonIdInp").setValueState("None");
			that.byId("positonIdInp").setTokens([]);
			that.byId("tempPosNameTxt").setText();
			// that.byId("engPosTypeId").setText();
			// that.byId("engUnionCodeId").setText();
			// that.byId("engAgreementId").setText();
			// that.byId("engRosterNumId").setText();
			// that.byId("engCdlQualId").setText();
			// // that.byId("mechCdlQualId").setText();
			// that.byId("engLoc").setText();
			// that.byId("engPosTitle").setText();
			// that.byId("engPosIdF1").setText();
			// that.byId("engPosTitleIdF1").setText();
			that.byId("tempStDate").setValueState("None");
			that.byId("tempEmpNoLabel").setVisible(true);
			that.byId("tempEmpNoInp").setVisible(true);
			that.byId("tempEmpNoInp").setTokens([]);
			that.byId("tempEmpNameTxt").setText("");
			that.byId("tempEmpNoInp").setValueState("None");
			that.byId("reasonHeaderCombo").setSelectedKey("");
			that.byId("reasonHeaderCombo").setValueState("None");
			that.byId("tempEndDate").setValueState("None");
			// that.byId("forceAssignmentPosDataForm").setVisible(false);
			that.byId("commentsIndicatorIcon").setVisible(false);
			that.byId("commentsTxt").setText();
			this.byId("commentsBtn").setText("Add Comments");
			that.defaultDate();
			var forceModel = new sap.ui.model.json.JSONModel({
				"results": forceItemsArray
			});
			var forceHistoryTable = that.byId("forceHistoryTable");
			forceHistoryTable.setModel(forceModel, "forceHistModel");
			var tempModel = new sap.ui.model.json.JSONModel({
				"results": []
			});
			var tempHistoryTable = that.byId("historyTable");
			tempHistoryTable.setModel(tempModel, "oHistModel");
			that.byId("saveBtn").setEnabled(false);
		},
		onEmpNoLiveChange: function (oEvent) {
			var that = this;
			oEvent.getSource().removeAllTokens();
			// var tempModel = new sap.ui.model.json.JSONModel({
			// 	"results": []
			// });
			// var tempHistoryTable = that.byId("historyTable");
			//tempHistoryTable.setModel(tempModel, "oHistModel");
			that.byId("tempEmpNameTxt").setText("");
			if (sap.ui.getCore().byId("commentsArea")) {
				sap.ui.getCore().byId("commentsArea").setValue("");
				this.onCommentsSubmit();
			}
			var assignmentRb = this.byId("assignmentRb").getSelectedButton().getText();
			if (assignmentRb === "Temporary Assignment") {
				that.tempPosDataFormClrFun();
				that.tempExpFalseFun();
			} else if (assignmentRb === "Permanent Assignment") {
				that.permPosDataFormClrFun();
				that.permExpFalseFun();
			} else {
				that.tempPosDataFormClrFun();
				that.tempExpFalseFun();
			}
			// that.onForcePanelButtonValidation();
		},
		tempPosDataFormClrFun: function () {
			var that = this;
			that.byId("tempEmpNoInp").setValueState("None");
			that.byId("tempEmpNameTxt").setText("");
			that.byId("tempPosIdF1").setText("");
			that.byId("tempPosTitleIdF1").setText("");
			that.byId("tempPosTyF1").setText("");
			that.byId("tempLocF1").setText("");
			that.byId("tempUnionCodeIdF1").setText("");
			that.byId("tempAgreementIdF1").setText("");
			that.byId("tempRosterNumIdF1").setText("");
			that.byId("reasonComboTemp").setText("");
			// that.byId("tempAssignmentPosDataForm").setVisible(false);
			that.byId("saveBtn").setEnabled(false);
			// Added on 31/10/2022
			that.byId("tempAreaIdF1").setText("");
			that.byId("tempAreaIdF1").setText("");
			that.byId("tempRDaysIdF1").setText("");
			that.byId("ShiftIdF1Temp").setText("");
			that.byId("cdlQualComboTemp").setText("");
			that.byId("engcdlQualComboTemp").setText("");
			if (that.byId("forceHistoryTable").getModel("forceHistModel") !== undefined) {
				that.byId("forceHistoryTable").getModel("forceHistModel").setData({
					"results": ""
				});
			}
		},
		permPosDataFormClrFun: function () {
			var that = this;
			that.byId("tempEmpNoInp").setValueState("None");
			that.byId("tempEmpNameTxt").setText();
			// clearing current employe data when click cancel. 
			that.byId("tempPosIdF1").setText();
			that.byId("tempPosTitleIdF1").setText();
			that.byId("tempPosTyF1").setText();
			that.byId("tempLocF1").setText();
			that.byId("tempUnionCodeIdF1").setText();
			that.byId("tempAgreementIdF1").setText();
			that.byId("tempRosterNumIdF1").setText();
			that.byId("reasonComboTemp").setText();
			// that.byId("engPosIdF1").setText();
			// that.byId("engPosTitleIdF1").setText();
			// that.byId("engPosTypeF1").setText();
			// that.byId("engLocF1").setText();
			// that.byId("engUnionCodeIdF1").setText();
			// that.byId("engAgreementIdF1").setText();
			// that.byId("engRosterNumIdF1").setText();
			// that.byId("engCdlQualId").setText();
			// that.byId("mechCdlQualId").setText();
			//that.byId("reasonComboForce").setText();
			//that.byId("forceAssignmentPosDataForm").setVisible(false);
			that.byId("saveBtn").setEnabled(false);
		},
		tempExpFalseFun: function () {
			var that = this;
			// that.byId("PosIdFormTemp").setVisible(true);
			// that.byId("PositionEngFormId").setVisible(false);
			// that.byId("tempAssignmentPanel").setVisible(true);
			// that.byId("forceAssignmentPanel").setVisible(false);
			that.byId("forceAssignHistoryPanel").setVisible(false);
			that.byId("historyPanel").setVisible(true);
			that.byId("posDataPanel").setExpanded(false);
			that.byId("tempAssignmentPanel").setExpanded(false);
			that.byId("historyPanel").setExpanded(false);
		},
		tempExpTrueFun: function () {
			var that = this;
			// that.byId("PosIdFormTemp").setVisible(true);
			// that.byId("PositionEngFormId").setVisible(false);
			// that.byId("tempAssignmentPanel").setVisible(true);
			// that.byId("forceAssignmentPanel").setVisible(false);
			that.byId("historyPanel").setVisible(true);
			that.byId("posDataPanel").setExpanded(true);
			that.byId("tempAssignmentPanel").setExpanded(true);
			if (that.histDetailsArr.length > 0) {
				that.byId("historyPanel").setExpanded(true);
			} else {
				that.byId("historyPanel").setExpanded(false);
			}
		},
		permExpFalseFun: function () {
			var that = this;
			// that.byId("PosIdFormTemp").setVisible(false);
			// that.byId("PositionEngFormId").setVisible(true);
			// that.byId("tempAssignmentPanel").setVisible(false);
			// that.byId("forceAssignmentPanel").setVisible(true);
			that.byId("historyPanel").setVisible(false);
			that.byId("forceAssignHistoryPanel").setVisible(true);
			that.byId("posDataPanel").setExpanded(false);
			// that.byId("forceAssignmentPanel").setExpanded(false);
			that.byId("forceAssignHistoryPanel").setExpanded(false);

		},
		permExpTrueFun: function () {
			var that = this;
			// that.byId("PosIdFormTemp").setVisible(false);
			// that.byId("PositionEngFormId").setVisible(true);
			// that.byId("tempAssignmentPanel").setVisible(false);
			// that.byId("forceAssignmentPanel").setVisible(true);
			that.byId("historyPanel").setVisible(false);
			that.byId("posDataPanel").setExpanded(true);
			//that.byId("forceAssignmentPanel").setExpanded(true);
			if (that.histDetailsArr.length > 0) {
				that.byId("forceAssignHistoryPanel").setExpanded(true);
			} else {
				that.byId("forceAssignHistoryPanel").setExpanded(false);
			}
		},
		onHeaderReasonSelection: function (oEvent) {
			var that = this;
			var selRb = that.byId("assignmentRb").getSelectedButton().getProperty("text");
			var highDate = "12/31/9999";
			that.headerReasonSel = that.byId("reasonHeaderCombo").getValue();
			that.changeValFlag = "X";
			that.byId("reasonHeaderCombo").setValueState("None");
			if (selRb === "Temporary Assignment") {
				that.onTempValidationFun(selRb);
				that.byId("tempEndDate").setEnabled(true);
				that.byId("historyPanel").setVisible(true);
				that.byId("forceAssignHistoryPanel").setVisible(false);
			} else if (selRb === "Permanent Assignment") {
				that.permValidationFun(selRb);
				that.byId("tempEndDate").setValue(highDate);
				that.byId("tempEndDate").setEnabled(false);
				that.byId("historyPanel").setVisible(false);
				that.byId("forceAssignHistoryPanel").setVisible(true);
			} else if (selRb === "Holding Position Assignment") {
				if (that.byId("tempEmpNoInp").getTokens().length > 0) {
					that.fillEmployeeHierarchy(that.byId("tempEmpNoInp").getTokens()[0].getKey());
					that.changeValFlag = "X";
					that.byId("tempEndDate").setValue(highDate);
					that.byId("tempEndDate").setEnabled(false);
					that.byId("historyPanel").setVisible(false);
					that.byId("forceAssignHistoryPanel").setVisible(true);
				}
			}
			if (sap.ui.getCore().byId("commentsArea")) {
				sap.ui.getCore().byId("commentsArea").setValue("");
				this.onCommentsSubmit();
			}
			this.onTempPanelButtonValidation();
		},
		onTempValidationFun: function (selRb) {
			var that = this;
			var posId = "";
			if (that.byId("positonIdInp").getTokens().length > 0) {
				posId = that.byId("positonIdInp").getTokens()[0].getKey();
			}
			var empId = "";
			if (that.byId("tempEmpNoInp").getTokens().length > 0) {
				empId = that.byId("tempEmpNoInp").getTokens()[0].getKey();
			}
			if (that.byId("positonIdInp").getTokens().length === 0) {
				that.byId("positonIdInp").setValueState("Error");
				if (that.empSrvCalFlag !== true) {
					that.onEmpAssignData(empId, selRb);
				}
				that.tempExpFalseFun();
			} else if (that.byId("tempEmpNoInp").getTokens().length === 0) {
				that.byId("tempEmpNoInp").setValueState("Error");
				that.byId("positonIdInp").setValueState("None");
				if (that.posSrvCalFlag !== true) {
					that.onPosAssignData(posId, selRb);
				}
				that.tempExpFalseFun();
			} else if (that.byId("reasonHeaderCombo").getValue() === "") {
				//that.byId("reasonHeaderCombo").setValueState("Error");
				that.byId("tempEmpNoInp").setValueState("None");
				that.byId("positonIdInp").setValueState("None");
				if (that.posSrvCalFlag !== true) {
					that.onPosAssignData(posId, selRb);
				}
				if (that.empSrvCalFlag !== true) {
					that.onEmpAssignData(empId, selRb);
				}
				that.tempExpFalseFun();
			} else if (that.byId("tempStDate").getValue() === "") {
				that.byId("tempStDate").setValueState("Error");
				that.byId("reasonHeaderCombo").setValueState("None");
				that.byId("tempEmpNoInp").setValueState("None");
				that.byId("positonIdInp").setValueState("None");
				if (that.posSrvCalFlag !== true) {
					that.onPosAssignData(posId, selRb);
				}
				if (that.empSrvCalFlag !== true) {
					that.onEmpAssignData(empId, selRb);
				}
				that.tempExpFalseFun();
			} else if (that.byId("tempEndDate").getValue() === "") {
				that.byId("tempEndDate").setValueState("Error");
				that.byId("tempStDate").setValueState("None");
				that.byId("reasonHeaderCombo").setValueState("None");
				that.byId("tempEmpNoInp").setValueState("None");
				that.byId("positonIdInp").setValueState("None");
				if (that.posSrvCalFlag !== true) {
					that.onPosAssignData(posId, selRb);
				}
				if (that.empSrvCalFlag !== true) {
					that.onEmpAssignData(empId, selRb);
				}
				that.tempExpFalseFun();
			} else {
				that.byId("tempEndDate").setValueState("None");
				that.byId("tempStDate").setValueState("None");
				that.byId("reasonHeaderCombo").setValueState("None");
				that.byId("tempEmpNoInp").setValueState("None");
				that.byId("positonIdInp").setValueState("None");
				if (that.posSrvCalFlag !== true) {
					that.onPosAssignData(posId, selRb);
				}
				if (that.empSrvCalFlag !== true) {
					that.onEmpAssignData(empId, selRb);
				}
				that.tempExpTrueFun();
				that.onTempPanelButtonValidation();
			}
			var highDate = "12/31/9999";
			var selRb1 = that.byId("assignmentRb").getSelectedButton().getProperty("text");
			if (selRb1 === "Temporary Assignment") {
				that.byId("tempEndDate").setEnabled(true);
			} else if (selRb1 === "Permanent Assignment") {
				that.byId("tempEndDate").setValue(highDate);
				that.byId("tempEndDate").setEnabled(false);
			}
		},
		permValidationFun: function (selRb) {
			var that = this;
			var posId = "";
			if (that.byId("positonIdInp").getTokens().length > 0) {
				posId = that.byId("positonIdInp").getTokens()[0].getKey();
			}
			var empId = "";
			if (that.byId("tempEmpNoInp").getTokens().length > 0) {
				empId = that.byId("tempEmpNoInp").getTokens()[0].getKey();
			}
			if (that.byId("positonIdInp").getTokens().length === 0) {
				that.byId("positonIdInp").setValueState("Error");
				if (that.empSrvCalFlag !== true) {
					that.onEmpAssignData(empId, selRb);
				}
				that.permExpFalseFun();
			} else if (that.byId("tempEmpNoInp").getTokens().length === 0) {
				that.byId("tempEmpNoInp").setValueState("Error");
				that.byId("positonIdInp").setValueState("None");
				if (that.posSrvCalFlag !== true) {
					that.onPosAssignData(posId, selRb);
				}
				that.permExpFalseFun();
			} else if (that.byId("reasonHeaderCombo").getValue() === "") {
				//	that.byId("reasonHeaderCombo").setValueState("Error");
				that.byId("tempEmpNoInp").setValueState("None");
				that.byId("positonIdInp").setValueState("None");
				if (that.posSrvCalFlag !== true) {
					that.onPosAssignData(posId, selRb);
				}
				if (that.empSrvCalFlag !== true) {
					that.onEmpAssignData(empId, selRb);
				}
				that.permExpFalseFun();
			} else if (that.byId("tempStDate").getValue() === "") {
				that.byId("tempStDate").setValueState("Error");
				that.byId("reasonHeaderCombo").setValueState("None");
				that.byId("tempEmpNoInp").setValueState("None");
				that.byId("positonIdInp").setValueState("None");
				if (that.posSrvCalFlag !== true) {
					that.onPosAssignData(posId, selRb);
				}
				if (that.empSrvCalFlag !== true) {
					that.onEmpAssignData(empId, selRb);
				}
				that.permExpFalseFun();
			} else if (that.byId("tempEndDate").getValue() === "") {
				that.byId("tempEndDate").setValueState("Error");
				that.byId("tempStDate").setValueState("None");
				that.byId("reasonHeaderCombo").setValueState("None");
				that.byId("tempEmpNoInp").setValueState("None");
				that.byId("positonIdInp").setValueState("None");
				if (that.posSrvCalFlag !== true) {
					that.onPosAssignData(posId, selRb);
				}
				if (that.empSrvCalFlag !== true) {
					that.onEmpAssignData(empId, selRb);
				}
				that.permExpFalseFun();
			} else {
				that.byId("tempEndDate").setValueState("None");
				that.byId("tempStDate").setValueState("None");
				that.byId("reasonHeaderCombo").setValueState("None");
				that.byId("tempEmpNoInp").setValueState("None");
				that.byId("positonIdInp").setValueState("None");
				if (that.posSrvCalFlag !== true) {
					that.onPosAssignData(posId, selRb);
				}
				if (that.empSrvCalFlag !== true) {
					that.onEmpAssignData(empId, selRb);
				}
				that.permExpTrueFun();
				that.onForcePanelButtonValidation();
			}
			var highDate = "12/31/9999";
			var selRb1 = that.byId("assignmentRb").getSelectedButton().getProperty("text");
			if (selRb1 === "Temporary Assignment") {
				that.byId("tempEndDate").setEnabled(true);
			} else if (selRb1 === "Permanent Assignment") {
				that.byId("tempEndDate").setValue(highDate);
				that.byId("tempEndDate").setEnabled(false);
			}
		},
		onRadioButtonSelect: function (oEvent) {
			var that = this;
			that.selRBIndex = oEvent.getParameter("selectedIndex");
			var highDate = "12/31/9999";
			that.byId("positionLableId").setRequired(true);
			that.getView().byId("positonIdInp").setEditable(true);
			if (that.selRBIndex === 2) {
				that.byId("positionLableId").setRequired(false);
				that.getView().byId("positonIdInp").setTokens([]).setEditable(false);
				that.getView().byId("tempEmpNoInp").setTokens([]);
				that.getView().byId("tempPosNameTxt").setText("");
				that.getView().byId("tempEmpNameTxt").setText("");
				that.onPosLiveChange();
				that.changeValFlag = undefined;
				that.onTempScreenClrFun();
				that.tempExpFalseFun();
				that.onPermScreenClrFun();
				that.permExpFalseFun();
				that.tempPosDataFormClrFun();
			}
			if (that.getView().byId("positonIdInp").getTokens().length === 0 || that.getView().byId("tempEmpNoInp").getTokens().length === 0) {
				that.getView().byId("tempEmpNoInp").setTokens([]);
				that.getView().byId("positonIdInp").setTokens([]);
				that.getView().byId("tempPosNameTxt").setText("");
				that.getView().byId("tempEmpNameTxt").setText("");
				that.onPosLiveChange();
				that.changeValFlag = undefined;
			}
			that.getView().byId("reasonHeaderCombo").setSelectedKey("");
			that.defaultDate();
			that.reasonComboBox();

			if (that.selRBIndex === 0) {
				that.byId("tempEndDate").setEnabled(true);
				//	that.byId("tempEndDate").setValue(highDate);
			} else {
				that.byId("tempEndDate").setValue(highDate);
				that.byId("tempEndDate").setEnabled(false);
			}
			//	forceAssignHistoryPanel

		},
		onPosDataExpand: function () {
			var that = this;
			var plsEnterMndtFields = that.getView().getModel("i18n").getProperty("plsEnterMndtFields");
			if (that.byId("assignmentRb").getSelectedButton().getText() === "Holding Position Assignment") {
				if ((that.byId("reasonHeaderCombo").getValue() !== "" || that.headerReasonSel !==
						"") &&
					that.byId("tempEmpNoInp").getTokens().length !== 0 && that.byId("tempStDate").getValue() !== "" && that.byId("tempEndDate").getValue() !==
					"") {
					that.byId("posDataPanel").setExpanded(false);
				} else {
					that.byId("posDataPanel").setExpanded(false);
					sap.m.MessageToast.show(plsEnterMndtFields);
				}
			} else {
				if (that.byId("positonIdInp").getTokens().length !== 0 && (that.byId("reasonHeaderCombo").getValue() !== "" || that.headerReasonSel !==
						"") &&
					that.byId("tempEmpNoInp").getTokens().length !== 0 && that.byId("tempStDate").getValue() !== "" && that.byId("tempEndDate").getValue() !==
					"") {
					that.byId("posDataPanel").setExpanded(true);
				} else {
					that.byId("posDataPanel").setExpanded(false);
					sap.m.MessageToast.show(plsEnterMndtFields);
				}
			}

		},
		onTempCurrentEmpDataPanel: function () {
			var that = this;
			var plsEnterMndtFields = that.getView().getModel("i18n").getProperty("plsEnterMndtFields");
			if (that.byId("assignmentRb").getSelectedButton().getText() === "Holding Position Assignment") {
				if ((that.byId("reasonHeaderCombo").getValue() !== "" || that.headerReasonSel !== "") &&
					that.byId("tempEmpNoInp").getTokens().length !== 0 && that.byId("tempStDate").getValue() !== "" && that.byId("tempEndDate").getValue() !==
					"") {
					that.byId("tempAssignmentPanel").setExpanded(true);
				} else {
					that.byId("tempAssignmentPanel").setExpanded(false);
					sap.m.MessageToast.show(plsEnterMndtFields);
				}
			} else {
				if (that.byId("positonIdInp").getTokens().length !== 0 && (that.byId("reasonHeaderCombo").getValue() !== "" || that.headerReasonSel !==
						"") &&
					that.byId("tempEmpNoInp").getTokens().length !== 0 && that.byId("tempStDate").getValue() !== "" && that.byId("tempEndDate").getValue() !==
					"") {
					that.byId("tempAssignmentPanel").setExpanded(true);
				} else {
					that.byId("tempAssignmentPanel").setExpanded(false);
					sap.m.MessageToast.show(plsEnterMndtFields);
				}
			}
		},
		onForceCurrentEmpDataPanel: function () {
			var that = this;
			var plsEnterMndtFields = that.getView().getModel("i18n").getProperty("plsEnterMndtFields");

			if (that.byId("assignmentRb").getSelectedButton().getText() === "Holding Position Assignment") {
				if ((that.byId("reasonHeaderCombo").getValue() !== "" || that.headerReasonSel !==
						"") && that.byId("tempEmpNoInp").getTokens().length !== 0 && that.byId("tempStDate").getValue() !== "" && that.byId(
						"tempEndDate").getValue() !== "") {
					that.byId("forceAssignmentPanel").setExpanded(true);
				} else {
					that.byId("forceAssignmentPanel").setExpanded(false);
					sap.m.MessageToast.show(plsEnterMndtFields);
				}
			} else {

				if (that.byId("positonIdInp").getTokens().length !== 0 && (that.byId("reasonHeaderCombo").getValue() !== "" || that.headerReasonSel !==
						"") &&
					that.byId("tempEmpNoInp").getTokens().length !== 0 && that.byId("tempStDate").getValue() !== "" && that.byId("tempEndDate").getValue() !==
					"") {
					that.byId("forceAssignmentPanel").setExpanded(true);
				} else {
					that.byId("forceAssignmentPanel").setExpanded(false);
					sap.m.MessageToast.show(plsEnterMndtFields);
				}
			}
		},
		onTempCurrentOccupantsPanel: function () {
			var that = this;
			var plsEnterMndtFields = that.getView().getModel("i18n").getProperty("plsEnterMndtFields");
			var currOccuTableNodata = that.getView().getModel("i18n").getProperty("currOccuTableNodata");
			if (that.byId("assignmentRb").getSelectedButton().getText() === "Holding Position Assignment") {
				if ((that.byId("reasonHeaderCombo").getValue() !== "" || that.headerReasonSel !== "") &&
					that.byId("tempEmpNoInp").getTokens().length !== 0 && that.byId("tempStDate").getValue() !== "" && that.byId("tempEndDate").getValue() !==
					"") {
					if (that.histDetailsArr.length > 0) {
						that.byId("historyPanel").setExpanded(false);
					} else {
						that.byId("historyPanel").setExpanded(false);
						sap.m.MessageToast.show(currOccuTableNodata);
					}
				} else {
					that.byId("historyPanel").setExpanded(false);
					sap.m.MessageToast.show(plsEnterMndtFields);
				}
			} else {
				if (that.byId("positonIdInp").getTokens().length !== 0 && (that.byId("reasonHeaderCombo").getValue() !== "" || that.headerReasonSel !==
						"") &&
					that.byId("tempEmpNoInp").getTokens().length !== 0 && that.byId("tempStDate").getValue() !== "" && that.byId("tempEndDate").getValue() !==
					"") {
					if (that.histDetailsArr.length > 0) {
						that.byId("historyPanel").setExpanded(true);
					} else {
						that.byId("historyPanel").setExpanded(false);
						sap.m.MessageToast.show(currOccuTableNodata);
					}
				} else {
					that.byId("historyPanel").setExpanded(false);
					sap.m.MessageToast.show(plsEnterMndtFields);
				}
			}
		},
		onForceCrrentOccupantsPanel: function () {
			var that = this;
			var plsEnterMndtFields = that.getView().getModel("i18n").getProperty("plsEnterMndtFields");
			var currOccuTableNodata = that.getView().getModel("i18n").getProperty("currOccuTableNodata");
			if (that.byId("assignmentRb").getSelectedButton().getText() === "Holding Position Assignment") {
				if ((that.byId("reasonHeaderCombo").getValue() !== "" || that.headerReasonSel !== "") &&
					that.byId("tempEmpNoInp").getTokens().length !== 0 && that.byId("tempStDate").getValue() !== "" && that.byId("tempEndDate").getValue() !==
					"") {
					if (that.histDetailsArr.length > 0) {
						that.byId("forceAssignHistoryPanel").setExpanded(false);
					} else {
						that.byId("forceAssignHistoryPanel").setExpanded(false);
						sap.m.MessageToast.show(currOccuTableNodata);
					}
				} else {
					that.byId("forceAssignHistoryPanel").setExpanded(false);
					sap.m.MessageToast.show(plsEnterMndtFields);
				}
			} else {
				if (that.byId("positonIdInp").getTokens().length !== 0 && (that.byId("reasonHeaderCombo").getValue() !== "" || that.headerReasonSel !==
						"") &&
					that.byId("tempEmpNoInp").getTokens().length !== 0 && that.byId("tempStDate").getValue() !== "" && that.byId("tempEndDate").getValue() !==
					"") {
					if (that.histDetailsArr.length > 0) {
						that.byId("forceAssignHistoryPanel").setExpanded(true);
					} else {
						that.byId("forceAssignHistoryPanel").setExpanded(false);
						sap.m.MessageToast.show(currOccuTableNodata);
					}
				} else {
					that.byId("forceAssignHistoryPanel").setExpanded(false);
					sap.m.MessageToast.show(plsEnterMndtFields);
				}
			}
		},
		onEmpIdSubmit: function (oEvent) {
			var oEmpIdInp = oEvent.getSource();
			oEmpIdInp.fireValueHelpRequest();
		},
		//-----------------------------------------------------------------------	
		// Employee ID Dialogue.
		//-----------------------------------------------------------------------
		onEmpIdRequest: function (oEvent) {
			var that = this;
			var EmpId = oEvent.getSource().getValue().trim();
			if (!that._empIdValueDialog) {
				that._empIdValueDialog = sap.ui.xmlfragment("com.tempforceassignment.Temp_ForceAssignment.fragments.EmpID", that.getView()
					.getController());
				that.getView().addDependent(that._empIdValueDialog);
			}
			that._empIdValueDialog.open();
			that._empIdValueDialog.setEscapeHandler(function (o) {
				o.reject();
			});
			sap.ui.getCore().byId("empIdSearch").setValue(EmpId);
			sap.ui.getCore().byId("empIdSearch").fireSearch();
			that.empDialogFlag = true;
		},
		onEmpIdCancel: function () {
			var that = this;
			that.empIdTableClear();
			that._empIdValueDialog.close();
		},
		onEmployeeIdSubmit: function (oEvent) {
			var that = this;
			that.pswmsgFlagCheck = true;
			var oPath = oEvent.getSource().getBindingContextPath();
			var oTable = sap.ui.getCore().byId("employeeIdTable");
			var oContext = oTable.getModel("modelData").getProperty(oPath);
			that.fillEmployeeHierarchy(oContext.EmpId);
			that.changeValFlag = "X";
			if (sap.ui.getCore().byId("commentsArea")) {
				sap.ui.getCore().byId("commentsArea").setValue("");
				this.onCommentsSubmit();
			}
		},
		fillEmployeeHierarchy: function (empId) {
			var that = this;
			var plsEnterPosId = that.getView().getModel("i18n").getProperty("plsEnterPosId");
			that.changeValFlag = "X";
			var selRb = this.byId("assignmentRb").getSelectedButton().getText();
			if (selRb === "Temporary Assignment") {
				var posId = "";
				if (that.byId("positonIdInp").getTokens().length > 0) {
					posId = that.byId("positonIdInp").getTokens()[0].getKey();
				}
				if (that.byId("positonIdInp").getTokens().length === 0) {
					this.byId("positonIdInp").setValueState("Error");
					sap.m.MessageToast.show(plsEnterPosId);
					if (that.empSrvCalFlag !== true) {
						that.onEmpAssignData(empId, selRb);
					}
					that.tempExpFalseFun();
					that.byId("tempEmpNoInp").setTokens([new sap.m.Token({
						text: empId,
						key: empId
					})]);
					that.empIdTableClear();
					that._empIdValueDialog.close();
				} else if (that.byId("reasonHeaderCombo").getValue() === "") {
					//	that.byId("reasonHeaderCombo").setValueState("Error");
					that.byId("positonIdInp").setValueState("None");
					that.byId("tempEmpNoInp").setValueState("None");
					if (that.posSrvCalFlag !== true) {
						that.onPosAssignData(posId, selRb);
					}
					if (that.empSrvCalFlag !== true) {
						that.onEmpAssignData(empId, selRb);
					}
					that.tempExpFalseFun();
					that.byId("tempEmpNoInp").setTokens([new sap.m.Token({
						text: empId,
						key: empId
					})]);
					that.empIdTableClear();
					that._empIdValueDialog.close();
				} else if (that.byId("tempStDate").getValue() === "") {
					that.byId("tempStDate").setValueState("Error");
					that.byId("positonIdInp").setValueState("None");
					that.byId("tempEmpNoInp").setValueState("None");
					that.byId("reasonHeaderCombo").setValueState("None");
					if (that.posSrvCalFlag !== true) {
						that.onPosAssignData(posId, selRb);
					}
					if (that.empSrvCalFlag !== true) {
						that.onEmpAssignData(empId, selRb);
					}
					that.tempExpFalseFun();
					that.byId("tempEmpNoInp").setTokens([new sap.m.Token({
						text: empId,
						key: empId
					})]);
					that.empIdTableClear();
					that._empIdValueDialog.close();
				} else if (that.byId("tempEndDate").getValue() === "") {
					that.byId("tempEndDate").setValueState("Error");
					that.byId("positonIdInp").setValueState("None");
					that.byId("tempEmpNoInp").setValueState("None");
					that.byId("reasonHeaderCombo").setValueState("None");
					that.byId("tempStDate").setValueState("None");
					if (that.posSrvCalFlag !== true) {
						that.onPosAssignData(posId, selRb);
					}
					if (that.empSrvCalFlag !== true) {
						that.onEmpAssignData(empId, selRb);
					}
					that.tempExpFalseFun();
					that.byId("tempEmpNoInp").setTokens([new sap.m.Token({
						text: empId,
						key: empId
					})]);
					that.empIdTableClear();
					that._empIdValueDialog.close();
				} else {
					that.byId("tempEndDate").setValueState("None");
					that.byId("positonIdInp").setValueState("None");
					that.byId("tempEmpNoInp").setValueState("None");
					that.byId("reasonHeaderCombo").setValueState("None");
					that.byId("tempStDate").setValueState("None");
					if (that.posSrvCalFlag !== true) {
						that.onPosAssignData(posId, selRb);
					}
					that.byId("tempEmpNoInp").setTokens([new sap.m.Token({
						text: empId,
						key: empId
					})]);
					if (that.empSrvCalFlag !== true) {
						that.onEmpAssignData(empId, selRb);
					}
					that.tempExpTrueFun();
					that.empIdTableClear();
					that._empIdValueDialog.close();
				}
			} else if (selRb === "Permanent Assignment") {
				if (that.byId("positonIdInp").getTokens().length === 0) {
					this.byId("positonIdInp").setValueState("Error");
					sap.m.MessageToast.show(plsEnterPosId);
					if (that.empSrvCalFlag !== true) {
						that.onEmpAssignData(empId, selRb);
					}
					that.permExpFalseFun();
					that.byId("tempEmpNoInp").setTokens([new sap.m.Token({
						text: empId,
						key: empId
					})]);
					that.empIdTableClear();
					that._empIdValueDialog.close();
				} else if (that.byId("reasonHeaderCombo").getValue() === "") {
					//	that.byId("reasonHeaderCombo").setValueState("Error");
					that.byId("positonIdInp").setValueState("None");
					that.byId("tempEmpNoInp").setValueState("None");
					if (that.posSrvCalFlag !== true) {
						that.onPosAssignData(posId, selRb);
					}
					if (that.empSrvCalFlag !== true) {
						that.onEmpAssignData(empId, selRb);
					}
					that.permExpFalseFun();
					that.byId("tempEmpNoInp").setTokens([new sap.m.Token({
						text: empId,
						key: empId
					})]);
					that.empIdTableClear();
					that._empIdValueDialog.close();
				} else if (that.byId("tempStDate").getValue() === "") {
					that.byId("tempStDate").setValueState("Error");
					that.byId("positonIdInp").setValueState("None");
					that.byId("tempEmpNoInp").setValueState("None");
					that.byId("reasonHeaderCombo").setValueState("None");
					if (that.posSrvCalFlag !== true) {
						that.onPosAssignData(posId, selRb);
					}
					if (that.empSrvCalFlag !== true) {
						that.onEmpAssignData(empId, selRb);
					}
					that.permExpFalseFun();
					that.byId("tempEmpNoInp").setTokens([new sap.m.Token({
						text: empId,
						key: empId
					})]);
					that.empIdTableClear();
					that._empIdValueDialog.close();
				} else if (that.byId("tempEndDate").getValue() === "") {
					that.byId("tempEndDate").setValueState("Error");
					that.byId("positonIdInp").setValueState("None");
					that.byId("tempEmpNoInp").setValueState("None");
					that.byId("reasonHeaderCombo").setValueState("None");
					that.byId("tempStDate").setValueState("None");
					if (that.posSrvCalFlag !== true) {
						that.onPosAssignData(posId, selRb);
					}
					if (that.empSrvCalFlag !== true) {
						that.onEmpAssignData(empId, selRb);
					}
					that.permExpFalseFun();
					that.byId("tempEmpNoInp").setTokens([new sap.m.Token({
						text: empId,
						key: empId
					})]);
					that.empIdTableClear();
					that._empIdValueDialog.close();
				} else {
					that.byId("tempEndDate").setValueState("None");
					that.byId("positonIdInp").setValueState("None");
					that.byId("tempEmpNoInp").setValueState("None");
					that.byId("reasonHeaderCombo").setValueState("None");
					that.byId("tempStDate").setValueState("None");
					if (that.posSrvCalFlag !== true) {
						that.onPosAssignData(posId, selRb);
					}
					that.byId("tempEmpNoInp").setTokens([new sap.m.Token({
						text: empId,
						key: empId
					})]);
					if (that.empSrvCalFlag !== true) {
						that.onEmpAssignData(empId, selRb);
					}
					that.permExpTrueFun();
					that.empIdTableClear();
					that._empIdValueDialog.close();
				}
			} else if (selRb === "Holding Position Assignment") {
				if (that.byId("reasonHeaderCombo").getValue() === "") {
					//	that.byId("reasonHeaderCombo").setValueState("Error");
					that.byId("positonIdInp").setValueState("None");
					that.byId("tempEmpNoInp").setValueState("None");
					// if (that.posSrvCalFlag !== true) {
					// 	that.onPosAssignData(posId, selRb);
					// }
					if (that.empSrvCalFlag !== true) {
						that.onEmpAssignData(empId, selRb);
					}
					that.permExpFalseFun();
					that.byId("tempEmpNoInp").setTokens([new sap.m.Token({
						text: empId,
						key: empId
					})]);
					that.empIdTableClear();
					that._empIdValueDialog.close();
				} else if (that.byId("tempStDate").getValue() === "") {
					that.byId("tempStDate").setValueState("Error");
					that.byId("positonIdInp").setValueState("None");
					that.byId("tempEmpNoInp").setValueState("None");
					that.byId("reasonHeaderCombo").setValueState("None");
					if (that.posSrvCalFlag !== true) {
						that.onPosAssignData(posId, selRb);
					}
					if (that.empSrvCalFlag !== true) {
						that.onEmpAssignData(empId, selRb);
					}
					that.permExpFalseFun();
					that.byId("tempEmpNoInp").setTokens([new sap.m.Token({
						text: empId,
						key: empId
					})]);
					that.empIdTableClear();
					that._empIdValueDialog.close();
				} else if (that.byId("tempEndDate").getValue() === "") {
					that.byId("tempEndDate").setValueState("Error");
					that.byId("positonIdInp").setValueState("None");
					that.byId("tempEmpNoInp").setValueState("None");
					that.byId("reasonHeaderCombo").setValueState("None");
					that.byId("tempStDate").setValueState("None");
					if (that.posSrvCalFlag !== true) {
						that.onPosAssignData(posId, selRb);
					}
					if (that.empSrvCalFlag !== true) {
						that.onEmpAssignData(empId, selRb);
					}
					that.permExpFalseFun();
					that.byId("tempEmpNoInp").setTokens([new sap.m.Token({
						text: empId,
						key: empId
					})]);
					that.empIdTableClear();
					that._empIdValueDialog.close();
				} else {
					that.byId("tempEndDate").setValueState("None");
					that.byId("positonIdInp").setValueState("None");
					that.byId("tempEmpNoInp").setValueState("None");
					that.byId("reasonHeaderCombo").setValueState("None");
					that.byId("tempStDate").setValueState("None");
					// if (that.posSrvCalFlag !== true) {
					// 	that.onPosAssignData(posId, selRb);
					// }
					that.byId("tempEmpNoInp").setTokens([new sap.m.Token({
						text: empId,
						key: empId
					})]);
					if (that.empSrvCalFlag !== true) {
						that.onEmpAssignData(empId, selRb);
					}
					that.permExpTrueFun();
					that.empIdTableClear();
					that._empIdValueDialog.close();
					// //that.byId("tempEndDate").setValue(highDate);
					// that.byId("tempEndDate").setEnabled(false);
					// that.byId("historyPanel").setVisible(false);
					// that.byId("forceAssignHistoryPanel").setVisible(true);

					// if (sap.ui.getCore().byId("commentsArea")) {
					// 	sap.ui.getCore().byId("commentsArea").setValue("");
					// 	this.onCommentsSubmit();
					// }
					// this.onTempPanelButtonValidation();
					// that.empIdTableClear();
					// that._empIdValueDialog.close();
				}
			}
		},
		onEmpIdSearch: function () {
			var that = this;
			var oPage = sap.ui.getCore().byId("empIdDialogue");
			var craft = that.craftUnion;
			var union;
			if (craft === "Engineering") {
				union = "E";
			} else if (craft === "Mechanical") {
				union = "M";
			} else if (craft === "TCU") {
				union = "T";
			} else if (craft === "ILA") {
				union = "L";
			} else if (craft === "Conrail") {
				union = "C";
			} else if (craft === "IHB") {
				union = "I";
			} else if (craft === "NAHR") {
				union = "N";
			}
			var oJsonSup = new sap.ui.model.json.JSONModel({});
			var empIdTable = sap.ui.getCore().byId("employeeIdTable");
			empIdTable.setModel(oJsonSup, "modelData");
			var empId = sap.ui.getCore().byId("empIdSearch").getValue();
			if (empId.length > 0) {
				oPage.setBusy(true);
				oPage.setBusyIndicatorDelay(0);
				var queryFil = [];
				var employeeId = new sap.ui.model.Filter("EmpId", "EQ", empId);
				var craftUnion = new sap.ui.model.Filter("Craft", "EQ", union);
				queryFil.push(employeeId);
				queryFil.push(craftUnion);
				var oModel = that.getOwnerComponent().getModel();
				oModel.read("/EmpSearchHelpSetSet", {
					filters: queryFil,
					success: function (oData) {
						oPage.setBusy(false);
						if (oData.results.length > 0) {
							empIdTable.getModel("modelData").setData(oData);
							empIdTable.getModel("modelData").refresh();
							sap.ui.getCore().byId("employeeIdTable").setVisible(true);
						} else {
							sap.ui.getCore().byId("employeeIdTable").setVisible(false);
						}
					},
					error: function (oResponse) {
						oPage.setBusy(false);
						that.errorMessageFun(oResponse);
					}
				});
			} else {
				oPage.setBusy(false);
				empIdTable.getModel("modelData").setData({});
				empIdTable.getModel("modelData").refresh();
			}
		},
		onPosIdEnter: function (oEvent) {
			var oPosIdInp = oEvent.getSource();
			oPosIdInp.fireValueHelpRequest();
		},
		//-----------------------------------------------------------------------	
		// Position ID Dialogue.
		//-----------------------------------------------------------------------
		onPosIdRequest: function (oEvent) {
			var that = this;
			this.onPosLiveChange1();
			if (that.craftUnion === "Engineering") {
				var engPosId = oEvent.getSource().getValue().trim();
				if (!that._engPosIdValueDialog) {
					that._engPosIdValueDialog = sap.ui.xmlfragment("com.tempforceassignment.Temp_ForceAssignment.fragments.EngPosId", that.getView()
						.getController());
					that.getView().addDependent(that._engPosIdValueDialog);
				}
				that._engPosIdValueDialog.open();
				that._engPosIdValueDialog.setEscapeHandler(function (o) {
					o.reject();
				});
				sap.ui.getCore().byId("idEngIconTabBar").setSelectedKey("Position ID OR Title");
				sap.ui.getCore().byId("dialoguEngPosIdTitleSearch").setValue(engPosId);
				sap.ui.getCore().byId("dialoguEngPosIdTitleSearch").fireSearch();
				that.posIdDialog = "X";
			} else if (that.craftUnion === "Mechanical") {
				var mechPosId = oEvent.getSource().getValue().trim();
				if (!that._mechPosIdValueDialog) {
					that._mechPosIdValueDialog = sap.ui.xmlfragment("com.tempforceassignment.Temp_ForceAssignment.fragments.MechPosId", that.getView()
						.getController());
					that.getView().addDependent(that._mechPosIdValueDialog);
				}
				that._mechPosIdValueDialog.open();
				that._mechPosIdValueDialog.setEscapeHandler(function (o) {
					o.reject();
				});
				sap.ui.getCore().byId("idMechPosIconTabBar").setSelectedKey("Position ID OR Title");
				sap.ui.getCore().byId("dialoguMechPosIdOrTitleSearch").setValue(mechPosId);
				sap.ui.getCore().byId("dialoguMechPosIdOrTitleSearch").fireSearch();
				that.posIdDialog = "X";
			} else if (that.craftUnion === "TCU") {
				var tcuPosId = oEvent.getSource().getValue().trim();
				if (!that._tcuPosIdValueDialog) {
					that._tcuPosIdValueDialog = sap.ui.xmlfragment("com.tempforceassignment.Temp_ForceAssignment.fragments.TcuPosId", that.getView()
						.getController());
					that.getView().addDependent(that._tcuPosIdValueDialog);
				}
				that._tcuPosIdValueDialog.open();
				that._tcuPosIdValueDialog.setEscapeHandler(function (o) {
					o.reject();
				});
				that.onTcuDeptDropDown1();
				sap.ui.getCore().byId("idTcuPosIconTabBar").setSelectedKey("Position ID OR Title");
				sap.ui.getCore().byId("dialoguTcuPosIdOrTitleSearch").setValue(tcuPosId);
				sap.ui.getCore().byId("dialoguTcuPosIdOrTitleSearch").fireSearch();
				that.posIdDialog = "X";
				sap.ui.getCore().byId("tcuPosDeskIconTab").setVisible(false);
				sap.ui.getCore().byId("tcuPosDeptIconTab").setVisible(true);
			} else if (that.craftUnion === "ATDA") {
				var atdaPosId = oEvent.getSource().getValue().trim();
				if (!that._tcuPosIdValueDialog) {
					that._tcuPosIdValueDialog = sap.ui.xmlfragment("com.tempforceassignment.Temp_ForceAssignment.fragments.TcuPosId", that.getView()
						.getController());
					that.getView().addDependent(that._tcuPosIdValueDialog);
				}
				that._tcuPosIdValueDialog.open();
				that._tcuPosIdValueDialog.setEscapeHandler(function (o) {
					o.reject();
				});
				that.onTcuDeskDropDown();
				sap.ui.getCore().byId("idTcuPosIconTabBar").setSelectedKey("Position ID OR Title");
				sap.ui.getCore().byId("dialoguTcuPosIdOrTitleSearch").setValue(atdaPosId);
				sap.ui.getCore().byId("dialoguTcuPosIdOrTitleSearch").fireSearch();
				that.posIdDialog = "X";
				sap.ui.getCore().byId("tcuPosDeskIconTab").setVisible(true);
				sap.ui.getCore().byId("tcuPosDeptIconTab").setVisible(false);
			} else if (that.craftUnion === "ILA") {
				var ilaPosId = oEvent.getSource().getValue().trim();
				if (!that._ilaPosIdDialog) {
					that._ilaPosIdDialog = sap.ui.xmlfragment("com.tempforceassignment.Temp_ForceAssignment.fragments.PositionID", that.getView()
						.getController());
					that.getView().addDependent(that._ilaPosIdDialog);
				}
				that._ilaPosIdDialog.open();
				that._ilaPosIdDialog.setEscapeHandler(function (o) {
					o.reject();
				});
				sap.ui.getCore().byId("dialogueIlaPosIdOrTitleSearch").setValue(ilaPosId);
				sap.ui.getCore().byId("dialogueIlaPosIdOrTitleSearch").fireSearch();
				that.posIdDialog = "X";
			} else if (that.craftUnion === "Conrail") {
				var conPosId = oEvent.getSource().getValue().trim();
				if (!that._conIhbNahrPosIdDialog) {
					that._conIhbNahrPosIdDialog = sap.ui.xmlfragment("com.tempforceassignment.Temp_ForceAssignment.fragments.ConrailIhbNahr", that.getView()
						.getController());
					that.getView().addDependent(that._conIhbNahrPosIdDialog);
				}
				that._conIhbNahrPosIdDialog.open();
				that._conIhbNahrPosIdDialog.setEscapeHandler(function (o) {
					o.reject();
				});
				sap.ui.getCore().byId("idConIhbNahrPosIconTabBar").setSelectedKey("Position ID OR Title");
				sap.ui.getCore().byId("dialoguConIhbNahrPosIdOrTitleSearch").setValue(conPosId);
				sap.ui.getCore().byId("dialoguConIhbNahrPosIdOrTitleSearch").fireSearch();
				that.posIdDialog = "X";
			} else if (that.craftUnion === "IHB") {
				var ihbPosId = oEvent.getSource().getValue().trim();
				if (!that._conIhbNahrPosIdDialog) {
					that._conIhbNahrPosIdDialog = sap.ui.xmlfragment("com.tempforceassignment.Temp_ForceAssignment.fragments.ConrailIhbNahr", that.getView()
						.getController());
					that.getView().addDependent(that._conIhbNahrPosIdDialog);
				}
				that._conIhbNahrPosIdDialog.open();
				that._conIhbNahrPosIdDialog.setEscapeHandler(function (o) {
					o.reject();
				});
				sap.ui.getCore().byId("idConIhbNahrPosIconTabBar").setSelectedKey("Position ID OR Title");
				sap.ui.getCore().byId("dialoguConIhbNahrPosIdOrTitleSearch").setValue(ihbPosId);
				sap.ui.getCore().byId("dialoguConIhbNahrPosIdOrTitleSearch").fireSearch();
				that.posIdDialog = "X";
			} else if (that.craftUnion === "NAHR") {
				var nahrPosId = oEvent.getSource().getValue().trim();
				if (!that._conIhbNahrPosIdDialog) {
					that._conIhbNahrPosIdDialog = sap.ui.xmlfragment("com.tempforceassignment.Temp_ForceAssignment.fragments.ConrailIhbNahr", that.getView()
						.getController());
					that.getView().addDependent(that._conIhbNahrPosIdDialog);
				}
				that._conIhbNahrPosIdDialog.open();
				that._conIhbNahrPosIdDialog.setEscapeHandler(function (o) {
					o.reject();
				});
				sap.ui.getCore().byId("idConIhbNahrPosIconTabBar").setSelectedKey("Position ID OR Title");
				sap.ui.getCore().byId("dialoguConIhbNahrPosIdOrTitleSearch").setValue(nahrPosId);
				sap.ui.getCore().byId("dialoguConIhbNahrPosIdOrTitleSearch").fireSearch();
				that.posIdDialog = "X";
			}
		},
		onEngPosDataSubmit: function (oEvent) {
			var that = this;

			var oPath = oEvent.getSource().getBindingContextPath();
			var oTable = oEvent.getSource().getParent();
			var tableId = oEvent.getSource().getParent().getId();
			var oModel;
			if (tableId === "engPosIdOrTitleTabTable") {
				oModel = "engPosIdTitleModelData";
			} else if (tableId === "engUnionTabTable") {
				oModel = "engUnionModelData";
			} else if (tableId === "engPosSupTabTable") {
				oModel = "engPosIdSupModelData";
			} else if (tableId === "engPosDivTabTable") {
				oModel = "engPosDivModelData";
			} else if (tableId === "engPosCityTabTable") {
				oModel = "engPosCityModelData";
			} else if (tableId === "engPosStateTabTable") {
				oModel = "engPosStateModelData";
			} else if (tableId === "engPosGangIdTabTable") {
				oModel = "engPosGangIdModelData";
			} else if (tableId === "engPosEmpTabTable") {
				oModel = "engPosEmpModelData";
			}
			var oContext = oTable.getModel(oModel).getProperty(oPath);
			that.fillPositionHierarchy(oContext.PositionId);
			that.changeValFlag = "X";
			if (sap.ui.getCore().byId("commentsArea")) {
				sap.ui.getCore().byId("commentsArea").setValue("");
				this.onCommentsSubmit();
			}
			//	that.onPosLiveChange1();
		},
		onMechPosDataSubmit: function (oEvent) {
			var that = this;

			var oPath = oEvent.getSource().getBindingContextPath();
			var oTable = oEvent.getSource().getParent();
			var tableId = oEvent.getSource().getParent().getId();
			var oModel;
			if (tableId === "mechPosIdOrTitleTabTable") {
				oModel = "mechPosIdTitleModelData";
			} else if (tableId === "mechUnionTabTable") {
				oModel = "mechUnionModelData";
			} else if (tableId === "mechPosAreaTabTable") {
				oModel = "mechPosAreaModelData";
			} else if (tableId === "mechPosCraftTabTable") {
				oModel = "mechPosCraftModelData";
			} else if (tableId === "mechPosTerritoryTabTable") {
				oModel = "mechPosTerritoryModelData";
			} else if (tableId === "mechPosEmpTabTable") {
				oModel = "mechPosEmpModelData";
			}
			var oContext = oTable.getModel(oModel).getProperty(oPath);
			that.fillPositionHierarchy(oContext.PositionId);
			that.changeValFlag = "X";
			if (sap.ui.getCore().byId("commentsArea")) {
				sap.ui.getCore().byId("commentsArea").setValue("");
				this.onCommentsSubmit();
			}
			//	that.onPosLiveChange1();
		},
		onTcuDeskDropDown: function () {
			var that = this;

			var posDeskJsonPos = new sap.ui.model.json.JSONModel();
			var posDeskModel = that.getOwnerComponent().getModel("oDataSrv");
			posDeskModel.read("/PosDropDownsSet?$filter=Key eq 'K'", null, null,
				false,
				function (oData) {
					posDeskJsonPos.setData(oData);
					var posDeskTable = sap.ui.getCore().byId("dialoguTcuPosDeskSearch");
					posDeskTable.setModel(posDeskJsonPos, "TCUDeskSuggDropdown");
				},
				function (oResponse) {
					that.errorMessageforHelp(oResponse, "Error");
				});
		},
		onTcuDeptDropDown1: function () {
			var that = this;
			var deptJsonModel = new sap.ui.model.json.JSONModel();
			var deptModel = that.getOwnerComponent().getModel("oDataSrv");
			deptModel.read("/PosDropDownsSet?$filter=Key eq 'DEPT_CODE'", null, null,
				false,
				function (oData) {
					deptJsonModel.setData(oData);
					var tcuDptComboBox = sap.ui.getCore().byId("dialoguTcuPosDeptSearch");
					tcuDptComboBox.setModel(deptJsonModel, "tcuDeptDropDownModelData");
				},
				function (oResponse) {
					//-----------------------------------------------------------------------	
					// Displaying response body message.
					//-----------------------------------------------------------------------
					var oMessage;
					var mesLen = $(oResponse.response.body).find("message").first().prevObject.length;
					for (var i = 1; i < mesLen; i++) {
						var exception = $(oResponse.response.body).find("message").first().prevObject[i].innerText;
						if (exception !== "Exception raised without specific error") {
							var Message = $(oResponse.response.body).find("message").first().prevObject[i].innerText;
						} else {
							Message = "";
						}
						if (i === 1) {
							oMessage = Message;
						}
						if (i > 1) {
							oMessage = oMessage + "\r\n" + Message;
						}
					}
					if (oMessage === undefined) {
						oMessage = $(oResponse.response.body).find("message").first().prevObject[0].innerText;
					}
					sap.m.MessageBox.show(oMessage, {
						icon: sap.m.MessageBox.Icon.INFORMATION,
						title: "Departmant error",
						actions: [sap.m.MessageBox.Action.OK],
						onClose: function (oAction) {}
					});
				});
		},
		onTcuPosDataSubmit: function (oEvent) {
			var that = this;
			var oPath = oEvent.getSource().getBindingContextPath();
			var oTable = oEvent.getSource().getParent();
			var tableId = oEvent.getSource().getParent().getId();
			var oModel;
			if (tableId === "tcuPosIdOrTitleTabTable") {
				oModel = "tcuPosIdTitleModelData";
			} else if (tableId === "tcuPosDeptTabTable") {
				oModel = "tcuPosDeptModelData";
			} else if (tableId === "tcuPosEmpTabTable") {
				oModel = "tcuPosEmpModelData";
			} else if (tableId === "tcuPosDeskTabTable") {
				oModel = "tcuPosDeskModelData";
			}
			var oContext = oTable.getModel(oModel).getProperty(oPath);
			that.fillPositionHierarchy(oContext.PositionId);
			that.changeValFlag = "X";
			if (sap.ui.getCore().byId("commentsArea")) {
				sap.ui.getCore().byId("commentsArea").setValue("");
				this.onCommentsSubmit();
			}
		},
		onConIhbNahrPosDataSubmit: function (oEvent) {
			var that = this;
			var oPath = oEvent.getSource().getBindingContextPath();
			var oTable = oEvent.getSource().getParent();
			var tableId = oEvent.getSource().getParent().getId();
			var oModel;
			if (tableId === "conIhbNahrPosIdOrTitleTabTable") {
				oModel = "conIhbNahrPosIdTitleModelData";
			} else if (tableId === "conIhbNahrPosUnionTabTable") {
				oModel = "conIhbNahrPosUnionModelData";
			}
			var oContext = oTable.getModel(oModel).getProperty(oPath);
			that.fillPositionHierarchy(oContext.PositionId);
			that.changeValFlag = "X";
			if (sap.ui.getCore().byId("commentsArea")) {
				sap.ui.getCore().byId("commentsArea").setValue("");
				this.onCommentsSubmit();
			}
		},
		onEngPosDialogCancel: function () {
			var that = this;
			that.engTableClear();
			that._engPosIdValueDialog.close();
		},
		onMechPosDialogCancel: function () {
			var that = this;
			that.mechTableClear();
			that._mechPosIdValueDialog.close();
		},
		onTcuPosDialogCancel: function () {
			var that = this;
			that.tcuTableClear();
			that._tcuPosIdValueDialog.close();
		},
		onIlaPosIdCancel: function () {
			var that = this;
			that.ilaTableClear();
			that._ilaPosIdDialog.close();
		},
		onConIhbNahrPosDialogCancel: function () {
			var that = this;
			that.conIhbNahrTableClear();
			that._conIhbNahrPosIdDialog.close();
		},
		onEngPosSearch: function (oEvent) {
			var that = this;
			var selIconTab = sap.ui.getCore().byId("idEngIconTabBar").getSelectedKey();
			var selRb = that.byId("assignmentRb").getSelectedButton().getText();
			var union;
			if (selRb === "Temporary Assignment") {
				union = "ET";
			} else if (selRb === "Permanent Assignment") {
				union = "EP";
			}
			var oModel = that.getOwnerComponent().getModel();
			var queryFil = [];
			var key = new sap.ui.model.Filter("Key", "EQ", union);
			var oPage = sap.ui.getCore().byId("EngPosIdDialogue");
			if (selIconTab === "Position ID OR Title") {
				var posIdTitleJsonPos = new sap.ui.model.json.JSONModel({});
				var posIdTitleTable = sap.ui.getCore().byId("engPosIdOrTitleTabTable");
				posIdTitleTable.setModel(posIdTitleJsonPos, "engPosIdTitleModelData");
				var posIdOrTitle = sap.ui.getCore().byId("dialoguEngPosIdTitleSearch").getValue();
				if (posIdOrTitle.length > 0) {
					oPage.setBusy(true);
					oPage.setBusyIndicatorDelay(0);
					var posIdTitle = new sap.ui.model.Filter("PositionId", "EQ", posIdOrTitle);
					queryFil.push(posIdTitle);
					queryFil.push(key);
					oModel.read("/PositionSearchHelpSet", {
						filters: queryFil,
						success: function (oData) {
							oPage.setBusy(false);
							if (oData.results.length > 0) {
								posIdTitleTable.getModel("engPosIdTitleModelData").setData(oData);
								posIdTitleTable.getModel("engPosIdTitleModelData").refresh();
								sap.ui.getCore().byId("engPosIdOrTitleTabTable").setVisible(true);
							} else {
								sap.ui.getCore().byId("engPosIdOrTitleTabTable").setVisible(false);
							}
						},
						error: function (oResponse) {
							oPage.setBusy(false);
							that.errorMessageFun(oResponse);
						}
					});
				} else {
					oPage.setBusy(false);
					posIdTitleTable.getModel("engPosIdTitleModelData").setData({});
					posIdTitleTable.getModel("engPosIdTitleModelData").refresh();
				}
			} else if (selIconTab === "Assign Supervisor") {
				var posSupJsonPos = new sap.ui.model.json.JSONModel({});
				var posSupTable = sap.ui.getCore().byId("engPosSupTabTable");
				posSupTable.setModel(posSupJsonPos, "engPosIdSupModelData");
				var posSup = sap.ui.getCore().byId("dialoguEngPosSupSearch").getValue();
				if (posSup.length > 0) {
					oPage.setBusy(true);
					oPage.setBusyIndicatorDelay(0);
					var posSuperVisor = new sap.ui.model.Filter("AssignSup", "EQ", posSup);
					queryFil.push(posSuperVisor);
					queryFil.push(key);
					oModel.read("/PositionSearchHelpSet", {
						filters: queryFil,
						success: function (oData) {
							oPage.setBusy(false);
							if (oData.results.length > 0) {
								posSupTable.getModel("engPosIdSupModelData").setData(oData);
								posSupTable.getModel("engPosIdSupModelData").refresh();
								sap.ui.getCore().byId("engPosSupTabTable").setVisible(true);
							} else {
								sap.ui.getCore().byId("engPosSupTabTable").setVisible(false);
							}
						},
						error: function (oResponse) {
							oPage.setBusy(false);
							that.errorMessageFun(oResponse);
						}
					});
				} else {
					oPage.setBusy(false);
					posSupTable.getModel("engPosIdSupModelData").setData({});
					posSupTable.getModel("engPosIdSupModelData").refresh();
				}
			} else if (selIconTab === "City") {
				var posCityJsonPos = new sap.ui.model.json.JSONModel({});
				var posCityTable = sap.ui.getCore().byId("engPosCityTabTable");
				posCityTable.setModel(posCityJsonPos, "engPosCityModelData");
				var posCity = sap.ui.getCore().byId("dialoguEngPosCitySearch").getValue();
				if (posCity.length > 0) {
					oPage.setBusy(true);
					oPage.setBusyIndicatorDelay(0);
					var city = new sap.ui.model.Filter("City", "EQ", posCity);
					queryFil.push(city);
					queryFil.push(key);
					oModel.read("/PositionSearchHelpSet", {
						filters: queryFil,
						success: function (oData) {
							oPage.setBusy(false);
							if (oData.results.length > 0) {
								posCityTable.getModel("engPosCityModelData").setData(oData);
								posCityTable.getModel("engPosCityModelData").refresh();
								sap.ui.getCore().byId("engPosCityTabTable").setVisible(true);
							} else {
								sap.ui.getCore().byId("engPosCityTabTable").setVisible(false);
							}
						},
						error: function (oResponse) {
							oPage.setBusy(false);
							that.errorMessageFun(oResponse);
						}
					});
				} else {
					oPage.setBusy(false);
					posCityTable.getModel("engPosCityModelData").setData({});
					posCityTable.getModel("engPosCityModelData").refresh();
				}
			} else if (selIconTab === "Gang ID") {
				var posGangIdJsonPos = new sap.ui.model.json.JSONModel({});
				var posGangIdTable = sap.ui.getCore().byId("engPosGangIdTabTable");
				posGangIdTable.setModel(posGangIdJsonPos, "engPosGangIdModelData");
				var posGangId = sap.ui.getCore().byId("dialoguEngPosGangIdSearch").getValue();
				if (posGangId.length > 0) {
					oPage.setBusy(true);
					oPage.setBusyIndicatorDelay(0);
					var gang = new sap.ui.model.Filter("GangId", "EQ", posGangId);
					queryFil.push(gang);
					queryFil.push(key);
					oModel.read("/PositionSearchHelpSet", {
						filters: queryFil,
						success: function (oData) {
							oPage.setBusy(false);
							if (oData.results.length > 0) {
								posGangIdTable.getModel("engPosGangIdModelData").setData(oData);
								posGangIdTable.getModel("engPosGangIdModelData").refresh();
								sap.ui.getCore().byId("engPosCityTabTable").setVisible(true);
							} else {
								sap.ui.getCore().byId("engPosGangIdTabTable").setVisible(false);
							}
						},
						error: function (oResponse) {
							oPage.setBusy(false);
							that.errorMessageFun(oResponse);
						}
					});
				} else {
					oPage.setBusy(false);
					posGangIdTable.getModel("engPosGangIdModelData").setData({});
					posGangIdTable.getModel("engPosGangIdModelData").refresh();
				}
			}
		},
		onMechPosSearch: function () {
			var that = this;
			var oTable = sap.ui.getCore().byId("mechPosIdDialogue");
			var selIconTab = sap.ui.getCore().byId("idMechPosIconTabBar").getSelectedKey();
			var selRb = that.byId("assignmentRb").getSelectedButton().getText();
			var union;
			if (selRb === "Temporary Assignment") {
				union = "MT";
			} else if (selRb === "Permanent Assignment") {
				union = "MP";
			}
			var oModel = that.getOwnerComponent().getModel();
			var queryFil = [];
			var key = new sap.ui.model.Filter("Key", "EQ", union);
			if (selIconTab === "Position ID OR Title") {
				var posIdTitleJsonPos = new sap.ui.model.json.JSONModel({});
				var posIdTitleTable = sap.ui.getCore().byId("mechPosIdOrTitleTabTable");
				posIdTitleTable.setModel(posIdTitleJsonPos, "mechPosIdTitleModelData");
				var posIdOrTitle = sap.ui.getCore().byId("dialoguMechPosIdOrTitleSearch").getValue();
				if (posIdOrTitle.length > 0) {
					oTable.setBusy(true);
					oTable.setBusyIndicatorDelay(0);
					var posIdTitle = new sap.ui.model.Filter("PositionId", "EQ", posIdOrTitle);
					queryFil.push(posIdTitle);
					queryFil.push(key);
					oModel.read("/PositionSearchHelpSet", {
						filters: queryFil,
						success: function (oData) {
							oTable.setBusy(false);
							if (oData.results.length > 0) {
								for (var i = 0; i < oData.results.length; i++) {
									var arreaArray = [];
									var sunday = oData.results[i].Sunday;
									var monday = oData.results[i].Monday;
									var tuesday = oData.results[i].Tuesday;
									var wednesday = oData.results[i].Wednesday;
									var thursday = oData.results[i].Thursday;
									var friday = oData.results[i].Friday;
									var saturday = oData.results[i].Saturday;
									if (sunday !== "") {
										arreaArray.push(sunday);
									}
									if (monday !== "") {
										arreaArray.push(monday);
									}
									if (tuesday !== "") {
										arreaArray.push(tuesday);
									}
									if (wednesday !== "") {
										arreaArray.push(wednesday);
									}
									if (thursday !== "") {
										arreaArray.push(thursday);
									}
									if (friday !== "") {
										arreaArray.push(friday);
									}
									if (saturday !== "") {
										arreaArray.push(saturday);
									}
									oData.results[i].Area = that.majorityValFun(arreaArray);
									if (oData.results[i].Area === undefined) {
										oData.results[i].Area = oData.results[i].Monday;
									}
								}
								posIdTitleTable.getModel("mechPosIdTitleModelData").setData(oData);
								posIdTitleTable.getModel("mechPosIdTitleModelData").refresh();
								sap.ui.getCore().byId("mechPosIdOrTitleTabTable").setVisible(true);
							} else {
								sap.ui.getCore().byId("mechPosIdOrTitleTabTable").setVisible(false);
							}
						},
						error: function (oResponse) {
							oTable.setBusy(false);
							that.errorMessageFun(oResponse);
						}
					});
				} else {
					oTable.setBusy(false);
					posIdTitleTable.getModel("mechPosIdTitleModelData").setData({});
					posIdTitleTable.getModel("mechPosIdTitleModelData").refresh();
				}
			}
		},
		majorityValFun: function (arreaArray) {
			var mf = 1;
			var m = 0;
			var item;
			for (var i = 0; i < arreaArray.length; i++) {
				for (var j = i; j < arreaArray.length; j++) {
					if (arreaArray[i] === arreaArray[j]) {
						m++;
					}
					if (mf < m) {
						mf = m;
						item = arreaArray[i];
					}
				}
				m = 0;
			}
			return item;
		},
		onTcuPosSearch: function () {
			var that = this;
			var oTable = sap.ui.getCore().byId("tcuPosIdDialogue");
			var selIconTab = sap.ui.getCore().byId("idTcuPosIconTabBar").getSelectedKey();
			var selRb = that.byId("assignmentRb").getSelectedButton().getText();
			var oModel = that.getOwnerComponent().getModel();
			var queryFil = [];
			var unionKey;
			if (that.craftUnion === "TCU") {
				if (selRb === "Temporary Assignment") {
					unionKey = "TT";
				} else if (selRb === "Permanent Assignment") {
					unionKey = "TP";
				}
			} else if (that.craftUnion === "ATDA") {
				if (selRb === "Temporary Assignment") {
					unionKey = "DT";
				} else if (selRb === "Permanent Assignment") {
					unionKey = "DP";
				}
			}
			var key = new sap.ui.model.Filter("Key", "EQ", unionKey);
			if (that.craftUnion === "TCU") {
				if (selIconTab === "Position ID OR Title") {
					var posIdTitleJsonPos = new sap.ui.model.json.JSONModel({});
					var posIdTitleTable = sap.ui.getCore().byId("tcuPosIdOrTitleTabTable");
					posIdTitleTable.setModel(posIdTitleJsonPos, "tcuPosIdTitleModelData");
					var posIdOrTitle = sap.ui.getCore().byId("dialoguTcuPosIdOrTitleSearch").getValue();
					if (posIdOrTitle.length > 0) {
						oTable.setBusy(true);
						oTable.setBusyIndicatorDelay(0);
						var posIdTitle = new sap.ui.model.Filter("PositionId", "EQ", posIdOrTitle);
						queryFil.push(posIdTitle);
						queryFil.push(key);
						oModel.read("/PositionSearchHelpSet", {
							filters: queryFil,
							success: function (oData) {
								oTable.setBusy(false);
								if (oData.results.length > 0) {
									posIdTitleTable.getModel("tcuPosIdTitleModelData").setData(oData);
									posIdTitleTable.getModel("tcuPosIdTitleModelData").refresh();
									sap.ui.getCore().byId("tcuPosIdOrTitleTabTable").setVisible(true);
								} else {
									sap.ui.getCore().byId("tcuPosIdOrTitleTabTable").setVisible(false);
								}
							},
							error: function (oResponse) {
								oTable.setBusy(false);
								that.errorMessageFun(oResponse);
							}
						});
					} else {
						oTable.setBusy(false);
						posIdTitleTable.getModel("tcuPosIdTitleModelData").setData({});
						posIdTitleTable.getModel("tcuPosIdTitleModelData").refresh();
					}
				} else if (selIconTab === "Department") {
					var posDeptJsonPos = new sap.ui.model.json.JSONModel({});
					var posDeptTable = sap.ui.getCore().byId("tcuPosDeptTabTable");
					posDeptTable.setModel(posDeptJsonPos, "tcuPosDeptModelData");
					var posDept = sap.ui.getCore().byId("dialoguTcuPosDeptSearch").getValue();
					if (posDept.length > 0) {
						oTable.setBusy(true);
						oTable.setBusyIndicatorDelay(0);
						var department = new sap.ui.model.Filter("Department", "EQ", posDept);
						queryFil.push(department);
						queryFil.push(key);
						oModel.read("/PositionSearchHelpSet", {
							filters: queryFil,
							success: function (oData) {
								oTable.setBusy(false);
								if (oData.results.length > 0) {
									posDeptTable.getModel("tcuPosDeptModelData").setData(oData);
									posDeptTable.getModel("tcuPosDeptModelData").refresh();
									sap.ui.getCore().byId("tcuPosDeptTabTable").setVisible(true);
								} else {
									sap.ui.getCore().byId("tcuPosDeptTabTable").setVisible(false);
								}
							},
							error: function (oResponse) {
								oTable.setBusy(false);
								that.errorMessageFun(oResponse);
							}
						});
					} else {
						oTable.setBusy(false);
						posDeptTable.getModel("tcuPosDeptModelData").setData({});
						posDeptTable.getModel("tcuPosDeptModelData").refresh();
					}
				} else if (selIconTab === "Current Occupant") {
					var posIdTitleJsonPos = new sap.ui.model.json.JSONModel({});
					var posIdTitleTable = sap.ui.getCore().byId("tcuPosEmpTabTable");
					posIdTitleTable.setModel(posIdTitleJsonPos, "tcuPosEmpModelData");
					var posIdOrTitle = sap.ui.getCore().byId("dialoguTcuEmpSearch").getValue();
					if (posIdOrTitle.length > 0) {
						oTable.setBusy(true);
						oTable.setBusyIndicatorDelay(0);
						var posIdTitle = new sap.ui.model.Filter("CurntOcupnt", "EQ", posIdOrTitle);
						queryFil.push(posIdTitle);
						queryFil.push(key);
						oModel.read("/PositionSearchHelpSet", {
							filters: queryFil,
							success: function (oData) {
								oTable.setBusy(false);
								if (oData.results.length > 0) {
									posIdTitleTable.getModel("tcuPosEmpModelData").setData(oData);
									posIdTitleTable.getModel("tcuPosEmpModelData").refresh();
									sap.ui.getCore().byId("tcuPosEmpTabTable").setVisible(true);
								} else {
									sap.ui.getCore().byId("tcuPosEmpTabTable").setVisible(false);
								}
							},
							error: function (oResponse) {
								oTable.setBusy(false);
								that.errorMessageFun(oResponse);
							}
						});
					} else {
						oTable.setBusy(false);
						posIdTitleTable.getModel("tcuPosEmpTabTable").setData({});
						posIdTitleTable.getModel("tcuPosEmpTabTable").refresh();
					}
				}
			} else if (that.craftUnion === "ATDA") {
				if (selIconTab === "Position ID OR Title") {
					var atdaPosIdTitleJsonPos = new sap.ui.model.json.JSONModel({});
					var atdaPosIdTitleTable = sap.ui.getCore().byId("tcuPosIdOrTitleTabTable");
					atdaPosIdTitleTable.setModel(atdaPosIdTitleJsonPos, "tcuPosIdTitleModelData");
					var atdaPosIdOrTitle = sap.ui.getCore().byId("dialoguTcuPosIdOrTitleSearch").getValue();
					if (atdaPosIdOrTitle.length > 0) {
						oTable.setBusy(true);
						oTable.setBusyIndicatorDelay(0);
						var atdaPosIdTitle = new sap.ui.model.Filter("PositionId", "EQ", atdaPosIdOrTitle);
						queryFil.push(atdaPosIdTitle);
						queryFil.push(key);
						oModel.read("/PositionSearchHelpSet", {
							filters: queryFil,
							success: function (oData) {
								oTable.setBusy(false);
								if (oData.results.length > 0) {
									atdaPosIdTitleTable.getModel("tcuPosIdTitleModelData").setData(oData);
									atdaPosIdTitleTable.getModel("tcuPosIdTitleModelData").refresh();
									sap.ui.getCore().byId("tcuPosIdOrTitleTabTable").setVisible(true);
								} else {
									sap.ui.getCore().byId("tcuPosIdOrTitleTabTable").setVisible(false);
								}
							},
							error: function (oResponse) {
								oTable.setBusy(false);
								that.errorMessageFun(oResponse);
							}
						});
					} else {
						oTable.setBusy(false);
						atdaPosIdTitleTable.getModel("tcuPosIdTitleModelData").setData({});
						atdaPosIdTitleTable.getModel("tcuPosIdTitleModelData").refresh();
					}
				} else if (selIconTab === "Desk") {
					var atdaPosDeptJsonPos = new sap.ui.model.json.JSONModel({});
					var atdaPosDeptTable = sap.ui.getCore().byId("tcuPosDeskTabTable");
					atdaPosDeptTable.setModel(atdaPosDeptJsonPos, "tcuPosDeskModelData");
					var atdaPosDept = sap.ui.getCore().byId("dialoguTcuPosDeskSearch").getSelectedKey();
					if (atdaPosDept.length > 0) {
						oTable.setBusy(true);
						oTable.setBusyIndicatorDelay(0);
						var atdaDepartment = new sap.ui.model.Filter("Desk", "EQ", atdaPosDept);
						queryFil.push(atdaDepartment);
						queryFil.push(key);
						oModel.read("/PositionSearchHelpSet", {
							filters: queryFil,
							success: function (oData) {
								oTable.setBusy(false);
								if (oData.results.length > 0) {
									atdaPosDeptTable.getModel("tcuPosDeskModelData").setData(oData);
									atdaPosDeptTable.getModel("tcuPosDeskModelData").refresh();
									sap.ui.getCore().byId("tcuPosDeskTabTable").setVisible(true);
								} else {
									sap.ui.getCore().byId("tcuPosDeskTabTable").setVisible(false);
								}
							},
							error: function (oResponse) {
								oTable.setBusy(false);
								that.errorMessageFun(oResponse);
							}
						});
					} else {
						oTable.setBusy(false);
						atdaPosDeptTable.getModel("tcuPosDeskModelData").setData({});
						atdaPosDeptTable.getModel("tcuPosDeskModelData").refresh();
					}
				} else if (selIconTab === "Current Occupant") {
					var posIdTitleJsonPos = new sap.ui.model.json.JSONModel({});
					var posIdTitleTable = sap.ui.getCore().byId("tcuPosEmpTabTable");
					posIdTitleTable.setModel(posIdTitleJsonPos, "tcuPosEmpModelData");
					var posIdOrTitle = sap.ui.getCore().byId("dialoguTcuEmpSearch").getValue();
					if (posIdOrTitle.length > 0) {
						oTable.setBusy(true);
						oTable.setBusyIndicatorDelay(0);
						var posIdTitle = new sap.ui.model.Filter("CurntOcupnt", "EQ", posIdOrTitle);
						queryFil.push(posIdTitle);
						queryFil.push(key);
						oModel.read("/PositionSearchHelpSet", {
							filters: queryFil,
							success: function (oData) {
								oTable.setBusy(false);
								if (oData.results.length > 0) {
									posIdTitleTable.getModel("tcuPosEmpModelData").setData(oData);
									posIdTitleTable.getModel("tcuPosEmpModelData").refresh();
									sap.ui.getCore().byId("tcuPosEmpTabTable").setVisible(true);
								} else {
									sap.ui.getCore().byId("tcuPosEmpTabTable").setVisible(false);
								}
							},
							error: function (oResponse) {
								oTable.setBusy(false);
								that.errorMessageFun(oResponse);
							}
						});
					} else {
						oTable.setBusy(false);
						posIdTitleTable.getModel("tcuPosEmpModelData").setData({});
						posIdTitleTable.getModel("tcuPosEmpModelData").refresh();
					}
				}
			}
		},
		onIlaPosIdSearch: function () {
			var that = this;
			var oPage = sap.ui.getCore().byId("ilaPosIdDialogue");
			var selRb = that.byId("assignmentRb").getSelectedButton().getText();
			var union;
			if (selRb === "Temporary Assignment") {
				union = "LT";
			} else if (selRb === "Permanent Assignment") {
				union = "LP";
			}
			var oModel = that.getOwnerComponent().getModel();
			var queryFil = [];
			var key = new sap.ui.model.Filter("Key", "EQ", union);
			var ilaJsonPos = new sap.ui.model.json.JSONModel({});
			var ilaPosIdOrTitleTable = sap.ui.getCore().byId("ilaPosIdOrTitleTable");
			ilaPosIdOrTitleTable.setModel(ilaJsonPos, "ilaPosIdTitleModelData");
			var posIdOrTitle = sap.ui.getCore().byId("dialogueIlaPosIdOrTitleSearch").getValue();
			if (posIdOrTitle.length > 0) {
				oPage.setBusy(true);
				oPage.setBusyIndicatorDelay(0);
				var posIdTitle = new sap.ui.model.Filter("PositionId", "EQ", posIdOrTitle);
				queryFil.push(posIdTitle);
				queryFil.push(key);
				oModel.read("/PositionSearchHelpSet", {
					filters: queryFil,
					success: function (oData) {
						oPage.setBusy(false);
						if (oData.results.length > 0) {
							ilaPosIdOrTitleTable.getModel("ilaPosIdTitleModelData").setData(oData);
							ilaPosIdOrTitleTable.getModel("ilaPosIdTitleModelData").refresh();
							sap.ui.getCore().byId("ilaPosIdOrTitleTable").setVisible(true);
						} else {
							sap.ui.getCore().byId("ilaPosIdOrTitleTable").setVisible(false);
						}
					},
					error: function (oResponse) {
						oPage.setBusy(false);
						that.errorMessageFun(oResponse);
					}
				});
			} else {
				oPage.setBusy(false);
				ilaPosIdOrTitleTable.getModel("ilaPosIdTitleModelData").setData({});
				ilaPosIdOrTitleTable.getModel("ilaPosIdTitleModelData").refresh();
			}
		},
		onConIhbNahrPosSearch: function () {
			var that = this;
			var oPage = sap.ui.getCore().byId("conIhbNahrPosIdDialogue");
			var selIconTab = sap.ui.getCore().byId("idConIhbNahrPosIconTabBar").getSelectedKey();
			var selRb = that.byId("assignmentRb").getSelectedButton().getText();
			var oModel = that.getOwnerComponent().getModel();
			var unionKey;
			if (that.craftUnion === "Conrail") {
				if (selRb === "Temporary Assignment") {
					unionKey = "CT";
				} else if (selRb === "Permanent Assignment") {
					unionKey = "CP";
				}
			} else if (that.craftUnion === "IHB") {
				if (selRb === "Temporary Assignment") {
					unionKey = "IT";
				} else if (selRb === "Permanent Assignment") {
					unionKey = "IP";
				}
			} else if (that.craftUnion === "NAHR") {
				if (selRb === "Temporary Assignment") {
					unionKey = "NT";
				} else if (selRb === "Permanent Assignment") {
					unionKey = "NP";
				}
			}
			var queryFil = [];
			var key = new sap.ui.model.Filter("Key", "EQ", unionKey);
			if (selIconTab === "Position ID OR Title") {
				var posIdTitleJsonPos = new sap.ui.model.json.JSONModel({});
				var posIdTitleTable = sap.ui.getCore().byId("conIhbNahrPosIdOrTitleTabTable");
				posIdTitleTable.setModel(posIdTitleJsonPos, "conIhbNahrPosIdTitleModelData");
				var posIdOrTitle = sap.ui.getCore().byId("dialoguConIhbNahrPosIdOrTitleSearch").getValue();
				if (posIdOrTitle.length > 0) {
					oPage.setBusy(true);
					oPage.setBusyIndicatorDelay(0);
					var posIdTitle = new sap.ui.model.Filter("PositionId", "EQ", posIdOrTitle);
					queryFil.push(posIdTitle);
					queryFil.push(key);
					oModel.read("/PositionSearchHelpSet", {
						filters: queryFil,
						success: function (oData) {
							oPage.setBusy(false);
							if (oData.results.length > 0) {
								posIdTitleTable.getModel("conIhbNahrPosIdTitleModelData").setData(oData);
								posIdTitleTable.getModel("conIhbNahrPosIdTitleModelData").refresh();
								sap.ui.getCore().byId("conIhbNahrPosIdOrTitleTabTable").setVisible(true);
							} else {
								sap.ui.getCore().byId("conIhbNahrPosIdOrTitleTabTable").setVisible(false);
							}
						},
						error: function (oResponse) {
							oPage.setBusy(false);
							that.errorMessageFun(oResponse);
						}
					});
				} else {
					oPage.setBusy(false);
					posIdTitleTable.getModel("conIhbNahrPosIdTitleModelData").setData({});
					posIdTitleTable.getModel("conIhbNahrPosIdTitleModelData").refresh();
				}
			}
		},
		onIlaPosIdOrTitleSubmit: function (oEvent) {
			var that = this;

			var oPath = oEvent.getSource().getBindingContextPath();
			var oTable = sap.ui.getCore().byId("ilaPosIdOrTitleTable");
			var oContext = oTable.getModel("ilaPosIdTitleModelData").getProperty(oPath);
			that.fillPositionHierarchy(oContext.PositionId);
			that.changeValFlag = "X";
			if (sap.ui.getCore().byId("commentsArea")) {
				sap.ui.getCore().byId("commentsArea").setValue("");
				this.onCommentsSubmit();
			}
			//	that.onPosLiveChange1();
		},
		fillPositionHierarchy: function (posId) {
			var that = this;
			var plsEnterPosId = that.getView().getModel("i18n").getProperty("plsEnterPosId");
			that.changeValFlag = "X";
			var selRb = that.byId("assignmentRb").getSelectedButton().getText();
			if (posId.length < 1) {
				that.byId("posDataPanel").setExpanded(false);
				sap.m.MessageToast.show(plsEnterPosId);
			}
			var empId = "";
			if (that.byId("tempEmpNoInp").getTokens().length > 0) {
				empId = that.byId("tempEmpNoInp").getTokens()[0].getKey();
			}
			if (selRb === "Temporary Assignment") {
				that.byId("reasonHeaderCombo").setVisible(true);
				if (empId === "") {
					that.byId("positonIdInp").setValueState("None");
					that.byId("tempEmpNoInp").setValueState("Error");
					that.byId("posDataPanel").setExpanded(false);
					that.onPosAssignData(posId, selRb);
					that.tempExpFalseFun();
					if (that.craftUnion === "Engineering") {
						that.engTableClear();
						that._engPosIdValueDialog.close();
					} else if (that.craftUnion === "Mechanical") {
						that.mechTableClear();
						that._mechPosIdValueDialog.close();
					} else if (that.craftUnion === "TCU" || that.craftUnion === "ATDA") {
						that.tcuTableClear();
						that._tcuPosIdValueDialog.close();
					} else if (that.craftUnion === "ILA") {
						that.ilaTableClear();
						that._ilaPosIdDialog.close();
					} else if (that.craftUnion === "Conrail" || that.craftUnion === "IHB" || that.craftUnion === "NAHR") {
						that.conIhbNahrTableClear();
						that._conIhbNahrPosIdDialog.close();
					}
					that.byId("positonIdInp").setTokens([new sap.m.Token({
						text: posId,
						key: posId
					})]);
				} else if (that.byId("reasonHeaderCombo").getValue() === "") {
					that.byId("positonIdInp").setValueState("None");
					that.byId("tempEmpNoInp").setValueState("None");
					that.byId("reasonHeaderCombo").setValueState("Error");
					if (that.posSrvCalFlag !== true) {
						that.onPosAssignData(posId, selRb);
					}
					if (that.empSrvCalFlag !== true) {
						that.onEmpAssignData(empId, selRb);
					}
					that.tempExpFalseFun();
					if (that.craftUnion === "Engineering") {
						that.engTableClear();
						that._engPosIdValueDialog.close();
					} else if (that.craftUnion === "Mechanical") {
						that.mechTableClear();
						that._mechPosIdValueDialog.close();
					} else if (that.craftUnion === "TCU" || that.craftUnion === "ATDA") {
						that.tcuTableClear();
						that._tcuPosIdValueDialog.close();
					} else if (that.craftUnion === "ILA") {
						that.ilaTableClear();
						that._ilaPosIdDialog.close();
					} else if (that.craftUnion === "Conrail" || that.craftUnion === "IHB" || that.craftUnion === "NAHR") {
						that.conIhbNahrTableClear();
						that._conIhbNahrPosIdDialog.close();
					}
					that.byId("positonIdInp").setTokens([new sap.m.Token({
						text: posId,
						key: posId
					})]);
				} else if (that.byId("tempStDate").getValue() === "") {
					that.byId("tempStDate").setValueState("Error");
					that.byId("positonIdInp").setValueState("None");
					that.byId("tempEmpNoInp").setValueState("None");
					that.byId("reasonHeaderCombo").setValueState("None");
					if (that.posSrvCalFlag !== true) {
						that.onPosAssignData(posId, selRb);
					}
					if (that.empSrvCalFlag !== true) {
						that.onEmpAssignData(empId, selRb);
					}
					that.tempExpFalseFun();
					if (that.craftUnion === "Engineering") {
						that.engTableClear();
						that._engPosIdValueDialog.close();
					} else if (that.craftUnion === "Mechanical") {
						that.mechTableClear();
						that._mechPosIdValueDialog.close();
					} else if (that.craftUnion === "TCU" || that.craftUnion === "ATDA") {
						that.tcuTableClear();
						that._tcuPosIdValueDialog.close();
					} else if (that.craftUnion === "ILA") {
						that.ilaTableClear();
						that._ilaPosIdDialog.close();
					} else if (that.craftUnion === "Conrail" || that.craftUnion === "IHB" || that.craftUnion === "NAHR") {
						that.conIhbNahrTableClear();
						that._conIhbNahrPosIdDialog.close();
					}
					that.byId("positonIdInp").setTokens([new sap.m.Token({
						text: posId,
						key: posId
					})]);
				} else if (that.byId("tempEndDate").getValue() === "") {
					that.byId("tempEndDate").setValueState("Error");
					that.byId("positonIdInp").setValueState("None");
					that.byId("tempEmpNoInp").setValueState("None");
					that.byId("reasonHeaderCombo").setValueState("None");
					that.byId("tempStDate").setValueState("None");
					if (that.posSrvCalFlag !== true) {
						that.onPosAssignData(posId, selRb);
					}
					if (that.empSrvCalFlag !== true) {
						that.onEmpAssignData(empId, selRb);
					}
					that.tempExpFalseFun();
					if (that.craftUnion === "Engineering") {
						that.engTableClear();
						that._engPosIdValueDialog.close();
					} else if (that.craftUnion === "Mechanical") {
						that.mechTableClear();
						that._mechPosIdValueDialog.close();
					} else if (that.craftUnion === "TCU" || that.craftUnion === "ATDA") {
						that.tcuTableClear();
						that._tcuPosIdValueDialog.close();
					} else if (that.craftUnion === "ILA") {
						that.ilaTableClear();
						that._ilaPosIdDialog.close();
					} else if (that.craftUnion === "Conrail" || that.craftUnion === "IHB" || that.craftUnion === "NAHR") {
						that.conIhbNahrTableClear();
						that._conIhbNahrPosIdDialog.close();
					}
					that.byId("positonIdInp").setTokens([new sap.m.Token({
						text: posId,
						key: posId
					})]);
				} else {
					that.byId("tempEndDate").setValueState("None");
					that.byId("positonIdInp").setValueState("None");
					that.byId("tempEmpNoInp").setValueState("None");
					that.byId("reasonHeaderCombo").setValueState("None");
					that.byId("tempStDate").setValueState("None");
					if (that.posSrvCalFlag !== true) {
						that.onPosAssignData(posId, selRb);
					}
					if (that.empSrvCalFlag !== true) {
						that.onEmpAssignData(empId, selRb);
					}
					that.tempExpTrueFun();
					if (that.craftUnion === "Engineering") {
						that.engTableClear();
						that._engPosIdValueDialog.close();
					} else if (that.craftUnion === "Mechanical") {
						that.mechTableClear();
						that._mechPosIdValueDialog.close();
					} else if (that.craftUnion === "TCU" || that.craftUnion === "ATDA") {
						that.tcuTableClear();
						that._tcuPosIdValueDialog.close();
					} else if (that.craftUnion === "ILA") {
						that.ilaTableClear();
						that._ilaPosIdDialog.close();
					} else if (that.craftUnion === "Conrail" || that.craftUnion === "IHB" || that.craftUnion === "NAHR") {
						that.conIhbNahrTableClear();
						that._conIhbNahrPosIdDialog.close();
					}
					that.byId("positonIdInp").setTokens([new sap.m.Token({
						text: posId,
						key: posId
					})]);
				}
			} else if (selRb === "Permanent Assignment") {
				if (that.byId("tempEmpNoInp").getTokens().length === 0) {
					that.byId("tempEmpNoInp").setValueState("Error");
					that.byId("positonIdInp").setValueState("None");
					if (that.posSrvCalFlag !== true) {
						that.onPosAssignData(posId, selRb);
					}
					if (that.empSrvCalFlag !== true) {
						that.onEmpAssignData(empId, selRb);
					}
					that.permExpFalseFun();
					if (that.craftUnion === "Engineering") {
						that.engTableClear();
						that._engPosIdValueDialog.close();
					} else if (that.craftUnion === "Mechanical") {
						that.mechTableClear();
						that._mechPosIdValueDialog.close();
					} else if (that.craftUnion === "TCU" || that.craftUnion === "ATDA") {
						that.tcuTableClear();
						that._tcuPosIdValueDialog.close();
					} else if (that.craftUnion === "ILA") {
						that.ilaTableClear();
						that._ilaPosIdDialog.close();
					} else if (that.craftUnion === "Conrail" || that.craftUnion === "IHB" || that.craftUnion === "NAHR") {
						that.conIhbNahrTableClear();
						that._conIhbNahrPosIdDialog.close();
					}
					that.byId("positonIdInp").setTokens([new sap.m.Token({
						text: posId,
						key: posId
					})]);
				} else if (that.byId("reasonHeaderCombo").getValue() === "") {
					that.byId("positonIdInp").setValueState("None");
					that.byId("tempEmpNoInp").setValueState("None");
					that.byId("reasonHeaderCombo").setValueState("Error");
					if (that.posSrvCalFlag !== true) {
						that.onPosAssignData(posId, selRb);
					}
					if (that.empSrvCalFlag !== true) {
						that.onEmpAssignData(empId, selRb);
					}
					that.permExpFalseFun();
					if (that.craftUnion === "Engineering") {
						that.engTableClear();
						that._engPosIdValueDialog.close();
					} else if (that.craftUnion === "Mechanical") {
						that.mechTableClear();
						that._mechPosIdValueDialog.close();
					} else if (that.craftUnion === "TCU" || that.craftUnion === "ATDA") {
						that.tcuTableClear();
						that._tcuPosIdValueDialog.close();
					} else if (that.craftUnion === "ILA") {
						that.ilaTableClear();
						that._ilaPosIdDialog.close();
					} else if (that.craftUnion === "Conrail" || that.craftUnion === "IHB" || that.craftUnion === "NAHR") {
						that.conIhbNahrTableClear();
						that._conIhbNahrPosIdDialog.close();
					}
					that.byId("positonIdInp").setTokens([new sap.m.Token({
						text: posId,
						key: posId
					})]);
				} else if (that.byId("tempStDate").getValue() === "") {
					that.byId("tempStDate").setValueState("Error");
					that.byId("tempEmpNoInp").setValueState("None");
					that.byId("positonIdInp").setValueState("None");
					that.byId("reasonHeaderCombo").setValueState("None");
					if (that.posSrvCalFlag !== true) {
						that.onPosAssignData(posId, selRb);
					}
					if (that.empSrvCalFlag !== true) {
						that.onEmpAssignData(empId, selRb);
					}
					that.permExpFalseFun();
					if (that.craftUnion === "Engineering") {
						that.engTableClear();
						that._engPosIdValueDialog.close();
					} else if (that.craftUnion === "Mechanical") {
						that.mechTableClear();
						that._mechPosIdValueDialog.close();
					} else if (that.craftUnion === "TCU" || that.craftUnion === "ATDA") {
						that.tcuTableClear();
						that._tcuPosIdValueDialog.close();
					} else if (that.craftUnion === "ILA") {
						that.ilaTableClear();
						that._ilaPosIdDialog.close();
					} else if (that.craftUnion === "Conrail" || that.craftUnion === "IHB" || that.craftUnion === "NAHR") {
						that.conIhbNahrTableClear();
						that._conIhbNahrPosIdDialog.close();
					}
					that.byId("positonIdInp").setTokens([new sap.m.Token({
						text: posId,
						key: posId
					})]);
				} else if (that.byId("tempEndDate").getValue() === "") {
					that.byId("tempEndDate").setValueState("Error");
					that.byId("tempStDate").setValueState("None");
					that.byId("tempEmpNoInp").setValueState("None");
					that.byId("positonIdInp").setValueState("None");
					that.byId("reasonHeaderCombo").setValueState("None");
					if (that.posSrvCalFlag !== true) {
						that.onPosAssignData(posId, selRb);
					}
					if (that.empSrvCalFlag !== true) {
						that.onEmpAssignData(empId, selRb);
					}
					that.permExpFalseFun();
					if (that.craftUnion === "Engineering") {
						that.engTableClear();
						that._engPosIdValueDialog.close();
					} else if (that.craftUnion === "Mechanical") {
						that.mechTableClear();
						that._mechPosIdValueDialog.close();
					} else if (that.craftUnion === "TCU" || that.craftUnion === "ATDA") {
						that.tcuTableClear();
						that._tcuPosIdValueDialog.close();
					} else if (that.craftUnion === "ILA") {
						that.ilaTableClear();
						that._ilaPosIdDialog.close();
					} else if (that.craftUnion === "Conrail" || that.craftUnion === "IHB" || that.craftUnion === "NAHR") {
						that.conIhbNahrTableClear();
						that._conIhbNahrPosIdDialog.close();
					}
					that.byId("positonIdInp").setTokens([new sap.m.Token({
						text: posId,
						key: posId
					})]);
				} else {
					that.byId("tempEndDate").setValueState("None");
					that.byId("tempStDate").setValueState("None");
					that.byId("tempEmpNoInp").setValueState("None");
					that.byId("positonIdInp").setValueState("None");
					that.byId("reasonHeaderCombo").setValueState("None");
					if (that.posSrvCalFlag !== true) {
						that.onPosAssignData(posId, selRb);
					}
					if (that.empSrvCalFlag !== true) {
						that.onEmpAssignData(empId, selRb);
					}
					that.permExpTrueFun();
					if (that.craftUnion === "Engineering") {
						that.engTableClear();
						that._engPosIdValueDialog.close();
					} else if (that.craftUnion === "Mechanical") {
						that.mechTableClear();
						that._mechPosIdValueDialog.close();
					} else if (that.craftUnion === "TCU" || that.craftUnion === "ATDA") {
						that.tcuTableClear();
						that._tcuPosIdValueDialog.close();
					} else if (that.craftUnion === "ILA") {
						that.ilaTableClear();
						that._ilaPosIdDialog.close();
					} else if (that.craftUnion === "Conrail" || that.craftUnion === "IHB" || that.craftUnion === "NAHR") {
						that.conIhbNahrTableClear();
						that._conIhbNahrPosIdDialog.close();
					}
					that.byId("positonIdInp").setTokens([new sap.m.Token({
						text: posId,
						key: posId
					})]);
				}
			}
		},
		onPosAssignData: function (PosID, selRb) {
			var that = this;
			var unionKey;
			if (selRb === "Temporary Assignment") {
				unionKey = "T";
			} else if (selRb === "Permanent Assignment") {
				unionKey = "F";
			}
			var posId = "";
			if (that.posIdDialog === "X") {
				posId = PosID;
			} else {
				if (that.byId("positonIdInp").getTokens().length > 0) {
					posId = that.byId("positonIdInp").getTokens()[0].getKey();
				}
			}
			var queryFil = [];

			var startDate = this.byId("tempStDate").getValue();
			// var endDate = this.byId("tempEndDate").getValue();
			var StartDate;
			if (startDate.includes("/") !== true) {
				StartDate = startDate;
			} else {
				var splitStartDate = startDate.split("/");
				StartDate = splitStartDate[2] + "" + splitStartDate[0] + "" + splitStartDate[1];
			}

			var positionID = new sap.ui.model.Filter("PosId", "EQ", posId);
			var effectiveDate = new sap.ui.model.Filter("EffDate", "EQ", StartDate);
			var key = new sap.ui.model.Filter("Key", "EQ", unionKey);
			queryFil.push(positionID);
			queryFil.push(effectiveDate);
			queryFil.push(key);
			var oModel = that.getOwnerComponent().getModel();
			oModel.read("/PosDetailSet", {
				filters: queryFil,
				success: function (oData) {
					if (oData.results.length > 0) {
						that.posSrvCalFlag = true;
					}
					that.byId("positonIdInp").setValueState("None");
					var histDetailsArray = [];
					for (var j = 0; j < oData.results.length; j++) {
						var histDetailsObj = {};
						var histStartDate = oData.results[j].HistSdate;
						var histEndDate = oData.results[j].HistEdate;
						var histDesc = oData.results[j].HistDesc;
						var histHolder = oData.results[j].HistHolder;
						var histType = oData.results[j].Type;
						var historyType;
						if (histType === "00000000" || histType === "") {
							historyType = "";
						} else {
							historyType = histType;
						}
						var historyStartDate;
						if (histStartDate !== "" && histStartDate !== "00000000") {
							historyStartDate = histStartDate;
						} else if (histStartDate === "00000000") {
							historyStartDate = "";
						} else {
							historyStartDate = histStartDate;
						}
						var historyEndDate;
						if (histEndDate !== "" && histEndDate !== "00000000") {
							historyEndDate = histEndDate;
						} else if (histEndDate === "00000000") {
							historyEndDate = "";
						} else {
							historyEndDate = histEndDate;
						}
						var historyDesc;
						if (histDesc === "00000000" || histDesc === "") {
							historyDesc = "";
						} else {
							historyDesc = histDesc;
						}
						var historyHolder;
						if (histHolder === "00000000" || histHolder === "") {
							historyHolder = "";
						} else {
							historyHolder = histHolder;
						}
						if (historyDesc !== "" || historyEndDate !== "" || historyStartDate !== "" || historyHolder !== "" || historyType !== "") {
							histDetailsObj.HistDesc = historyDesc;
							histDetailsObj.HistEdate = historyEndDate;
							histDetailsObj.HistSdate = historyStartDate;
							histDetailsObj.HistHolder = historyHolder;
							histDetailsObj.Type = historyType;
							histDetailsArray.push(histDetailsObj);
							that.histDetailsArr = histDetailsArray;
						} else {
							histDetailsArray.push();
							that.histDetailsArr = histDetailsArray;
						}
					}
					var posDesc = "";
					if (oData.results.length > 0) {
						posDesc = oData.results[0].PosDesc;
					}
					//var posDesc = oData.results[0].PosDesc;
					var positionDesc;
					if (posDesc === "" || posDesc === "00000000") {
						positionDesc = "";
					} else {
						positionDesc = posDesc;
					}
					var PosEdate = oData.results[0].PosEdate;
					var vPosEdate;
					if (PosEdate === "" || PosEdate === "00000000") {
						vPosEdate = "";
					} else {
						vPosEdate = PosEdate;
					}
					var posType = oData.results[0].PosType;
					var positionType;
					if (posType === "" || posType === "00000000") {
						positionType = "";
					} else {
						positionType = posType;
					}
					var unionCode = oData.results[0].UnionCode;
					var unCode;
					if (unionCode === "" || unionCode === "00000000") {
						unCode = "";
					} else {
						unCode = unionCode;
					}
					var shift = oData.results[0].Shift;
					if (shift === "" || shift === "00000000") {
						shift = "";
					}
					var area = oData.results[0].Area;
					if (area === "" || area === "00000000") {
						area = "";
					}
					var rdays = oData.results[0].RDays;
					if (rdays === "" || rdays === "00000000") {
						rdays = "";
					}
					var agreementCode = oData.results[0].AggCode;
					var aggCode;
					if (agreementCode === "" || agreementCode === "00000000") {
						aggCode = "";
					} else {
						aggCode = agreementCode;
					}
					var rosterNo = oData.results[0].RosterNo;
					var rosterNum;
					if (rosterNo === "" || rosterNo === "00000000") {
						rosterNum = "";
					} else {
						rosterNum = rosterNo;
					}
					var cdlQual = oData.results[0].Quals;
					if (cdlQual === "" || cdlQual === "00000000") {
						cdlQual = "";
					}
					var jpid = oData.results[0].Jpid;
					var jpId;
					if (jpid === "" || jpid === "00000000") {
						jpId = "";
					} else {
						jpId = jpid;
					}
					var location = oData.results[0].Location;
					var loc;
					if (location === "" || location === "00000000") {
						loc = "";
					} else {
						loc = location;
					}
					// that.byId("engRDaysId").setText(rdays);
					if (selRb === "Temporary Assignment") {
						that.byId("tempPosNameTxt").setText(positionDesc);
						var highDate = "12/31/9999";
						that.byId("tempEndDate").setValue(highDate);
						that.byId("tempEndDate").setEnabled(true);
						that.byId("posTypeIdTemp").setText(positionType);
						that.byId("unionCodeIdTemp").setText(unCode);

						that.byId("RDaysIdTemp").setText(rdays);
						that.byId("agreementIdTemp").setText(aggCode);
						that.byId("AreaIdTemp").setText(area);
						that.byId("ShiftIdTemp").setText(shift);
						that.byId("rosterNumIdTemp").setText(rosterNum);
						that.byId("CdlQualId").setText(cdlQual);
						that.byId("CdlQualIdTempEng").setText(cdlQual);
						that.byId("posTitleTemp").setText(positionDesc);
						//that.byId("tempEmpNameTxt").setText("");

						that.byId("tempPosNameTxt").setText(positionDesc);
						//that.byId("tempEndDate").setEnabled(false);
						that.byId("tempEndDate").setValue(PosEdate);
						// that.byId("engPosTypeId").setText(positionType);
						// that.byId("engUnionCodeId").setText(unCode);
						// that.byId("engAgreementId").setText(aggCode);

						// that.byId("EngAreaId").setText(area);
						// that.byId("EngShiftId").setText(shift);

						// that.byId("engRosterNumId").setText(rosterNum);
						// 	that.byId("engCdlQualId").setText(cdlQual);
						// that.byId("mechCdlQualId").setText(cdlQual);
						// that.byId("engPosTitle").setText(positionDesc);
						// that.byId("tempEmpNameTxt").setText("");
						if (unCode !== "TCU") {
							that.byId("locTemp").setText(loc);
							//that.byId("tempLocHdrLabel").setVisible(true);
							//that.byId("locTemp").setVisible(true);
						} else {
							that.byId("locTemp").setText();
							//that.byId("tempLocHdrLabel").setVisible(false);
							//that.byId("locTemp").setVisible(false);
						}
						// --------------------------- History table model --------------------------------------
						var histTableModel = new sap.ui.model.json.JSONModel({
							"results": histDetailsArray
						});
						that.byId("historyTable").setModel(histTableModel, "oHistModel");
						var forceHistTableModel = new sap.ui.model.json.JSONModel({
							"results": histDetailsArray
						});
						that.byId("forceHistoryTable").setModel(forceHistTableModel, "forceHistModel");
					} else if (selRb === "Permanent Assignment") {
						that.byId("tempPosNameTxt").setText(positionDesc);
						var highDate = "12/31/9999";
						that.byId("tempEndDate").setValue(highDate);
						that.byId("tempEndDate").setEnabled(true);
						that.byId("posTypeIdTemp").setText(positionType);
						that.byId("unionCodeIdTemp").setText(unCode);
						that.byId("RDaysIdTemp").setText(rdays);

						// that.byId("CdlQualId").setText(cdlQual);
						that.byId("CdlQualIdTempEng").setText(cdlQual);
						that.byId("agreementIdTemp").setText(aggCode);
						that.byId("AreaIdTemp").setText(area);
						that.byId("ShiftIdTemp").setText(shift);
						that.byId("rosterNumIdTemp").setText(rosterNum);
						that.byId("CdlQualId").setText(cdlQual);
						that.byId("posTitleTemp").setText(positionDesc);
						that.byId("tempEmpNameTxt").setText("");

						that.byId("tempPosNameTxt").setText(positionDesc);
						that.byId("tempEndDate").setEnabled(false);
						that.byId("tempEndDate").setValue(PosEdate);
						// that.byId("engPosTypeId").setText(positionType);
						// that.byId("engUnionCodeId").setText(unCode);
						// that.byId("engRDaysId").setText(rdays);
						// that.byId("engAgreementId").setText(aggCode);
						// that.byId("engRosterNumId").setText(rosterNum);
						// that.byId("engCdlQualId").setText(cdlQual);
						// that.byId("mechCdlQualId").setText(cdlQual);
						// that.byId("engPosTitle").setText(positionDesc);
						that.byId("tempEmpNameTxt").setText("");
						// if (unCode !== "TCU") {
						// 	that.byId("engLoc").setText(loc);
						// 	that.byId("forceLocHdrLabel").setVisible(true);
						// 	that.byId("engLoc").setVisible(true);
						// } else {
						// 	that.byId("engLoc").setText();
						// 	that.byId("forceLocHdrLabel").setVisible(false);
						// 	that.byId("engLoc").setVisible(false);
						// }
						// --------------------------- History table model --------------------------------------
						var forceHistTableModel = new sap.ui.model.json.JSONModel({
							"results": histDetailsArray
						});
						that.byId("forceHistoryTable").setModel(forceHistTableModel, "forceHistModel");
						var histTableModel = new sap.ui.model.json.JSONModel({
							"results": histDetailsArray
						});
						that.byId("historyTable").setModel(histTableModel, "oHistModel");
						that.byId("tempEmpNameTxt").setText("");

						if (selRb === "Temporary Assignment") {
							that.onTempPanelButtonValidation();
						} else {
							that.onForcePanelButtonValidation();
						}
					}
				},
				error: function (oResponse) {
					that.posErrorMsgFun(oResponse);
				}
			});
		},
		posErrorMsgFun: function (oResponse) {
			var that = this;
			var titleError = that.getView().getModel("i18n").getProperty("titleError");
			var Close = that.getView().getModel("i18n").getProperty("close");
			//-----------------------------------------------------------------------	
			// Displaying response body message.
			//----------------------------------------------------------------------- 
			var oMessage = JSON.parse(oResponse.response.body).error.message.value;
			var errmsg;
			if (oMessage === "") {
				errmsg = oResponse.response.body;
			} else {
				errmsg = oMessage;
			}
			sap.m.MessageBox.information(errmsg, {
				icon: sap.m.MessageBox.Icon.INFORMATION,
				title: "Information",
				actions: ["OK"],
				onClose: function (oAction) {
					if (oAction === "OK") {}
				}
			});
		},
		onEmpAssignData: function (empId, selRb) {
			var that = this;
			var titleInfo = that.getView().getModel("i18n").getProperty("titleInfo");
			var ok = that.getView().getModel("i18n").getProperty("ok");
			var aObject = {};
			var posIdVal;
			if (that.byId("positonIdInp").getTokens().length > 0) {
				posIdVal = that.byId("positonIdInp").getTokens()[0].getKey();
			} else {
				posIdVal = "";
			}
			var startDate = this.byId("tempStDate").getValue();
			var endDate = this.byId("tempEndDate").getValue();
			var StartDate;
			if (startDate.includes("/") !== true) {
				StartDate = startDate;
			} else {
				var splitStartDate = startDate.split("/");
				StartDate = splitStartDate[2] + "" + splitStartDate[0] + "" + splitStartDate[1];
			}
			var EndDate;
			if (endDate.includes("/") !== true) {
				EndDate = endDate;
			} else {
				var splitEndDate = endDate.split("/");
				EndDate = splitEndDate[2] + "" + splitEndDate[0] + "" + splitEndDate[1];
			}
			aObject.PosId = posIdVal;
			if (startDate.includes("/") !== true) {
				aObject.Begda = startDate;
			} else {
				aObject.Begda = StartDate;
			}
			if (endDate.includes("/") !== true) {
				aObject.Endda = endDate;
			} else {
				aObject.Endda = EndDate;
			}
			aObject.PermHolder = "";
			aObject.EmpNo = empId;
			aObject.BullFlag = "";
			aObject.Key = "C";
			// if (that.byId("assignmentRb").getSelectedButton().getText() === "Holding Position Assignment") {
			// 	aObject.Key = "H";
			// }
			if (that.pflag !== "") {
				aObject.Pflag = that.pflag;
			}
			var oModel = that.getOwnerComponent().getModel();
			oModel.create("/PosTempForcedSet", aObject, {
				success: function (oData) {
					if (oData.length > 0) {
						that.empSrvCalFlag = true;
					}
					that.byId("tempEmpNoInp").setValueState("None");
					if (that.byId("tempEmpNoInp").getTokens().length > 0) {
						that.byId("tempEmpNameTxt").setText(oData.HolderDesc);
					}
					var posId = oData.PosId;
					var posDesc = oData.PosDesc;
					var posType = oData.PosType;
					var sPosDesc = oData.SposDesc;
					var holderDesc = oData.HolderDesc;
					var stDate = oData.Begda;
					var eDate = oData.Endda;
					var aggr = oData.Agreement;
					var jpId = oData.JpidEmp;
					var location = oData.Location;
					var rosterNo = oData.RosterNo;
					var status = oData.Status;
					var reason = oData.ReasonDesc;
					var EndDateFlag = oData.EndDateFlag;
					var unionCode = oData.UnionCode;
					that.WmsgFlag = oData.WmsgFlag;
					var Reason;
					if (reason === "" || reason === "00000000") {
						Reason = "";
					} else {
						Reason = reason;
					}
					var aggrCode;
					if (aggr === "" || aggr === "00000000") {
						aggrCode = "";
					} else {
						aggrCode = aggr;
					}
					var jpIdEmp;
					if (jpId === "" || jpId === "00000000") {
						jpIdEmp = "";
					} else {
						jpIdEmp = jpId;
					}
					var locEmp;
					if (location === "" || location === "00000000") {
						locEmp = "";
					} else {
						locEmp = location;
					}
					var rosterNoEmp;
					if (rosterNo === "" || rosterNo === "00000000") {
						rosterNoEmp = "";
					} else {
						rosterNoEmp = rosterNo;
					}
					var statusEmp;
					if (status === "" || status === "00000000") {
						statusEmp = "";
					} else {
						statusEmp = status;
					}
					var positionId;
					if (posId === "" || posId === "00000000") {
						positionId = "";
					} else {
						positionId = posId;
					}
					var positionDesc;
					if (posDesc === "" || posDesc === "00000000") {
						positionDesc = "";
					} else {
						positionDesc = posDesc;
					}
					var positionType;
					if (posType === "" || posType === "00000000") {
						positionType = "";
					} else {
						positionType = posType;
					}
					var sPositionDesc;
					if (sPosDesc === "" || sPosDesc === "00000000") {
						sPositionDesc = "";
					} else {
						sPositionDesc = sPosDesc;
					}
					var forceStartDate;
					if (stDate !== "" && stDate !== "00000000") {
						forceStartDate = stDate;
					} else if (stDate === "00000000") {
						forceStartDate = "";
					} else {
						forceStartDate = stDate;
					}
					var forceEndDate;
					if (eDate !== "" && eDate !== "00000000") {
						forceEndDate = eDate;
					} else if (eDate === "00000000") {
						forceEndDate = "";
					} else {
						forceEndDate = eDate;
					}
					var area = oData.Area;
					if (area === "" || area === "00000000") {
						area = "";
					}
					var shift = oData.Shift;
					if (shift === "" || shift === "00000000") {
						shift = "";
					}
					var rdays = oData.RDays;
					if (rdays === "" || rdays === "00000000") {
						rdays = "";
					}
					var quals = oData.Quals;
					if (quals === "" || quals === "00000000") {
						quals = "";
					}
					var unCode;
					if (unionCode === "" || unionCode === "00000000") {
						unCode = "";
					} else {
						unCode = unionCode;
					}

					if (Reason !== "" || positionId !== "" || positionDesc !== "" || positionType !== "" || sPositionDesc !== "" ||
						forceStartDate !==
						"" ||
						forceEndDate !== "" || unCode !== "" || aggrCode !== "" || jpIdEmp !== "" || locEmp !== "" || rosterNoEmp !== "" ||
						statusEmp !==
						"") {
						// // that.byId("engRDaysIdF1").setText(rdays);
						// that.byId("cdlQualComboForce").setText(quals);
						// that.byId("engShiftIdF1").setText(shift);
						// that.byId("engPosTypeF1").setText(positionType);
						that.byId("tempPosTyF1").setText(positionType);
						// that.byId("engAreaIdF1").setText(area);
						if (selRb === "Temporary Assignment" || selRb === "Holding Position Assignment") {
							// that.byId("forceAssignmentPosDataForm").setVisible(false);
							// that.byId("tempAssignmentPosDataForm").setVisible(true);
							if (positionId !== "99999999") {
								// that.byId("forceAssignmentPosDataForm").setVisible(false);
								// that.byId("tempAssignmentPosDataForm").setVisible(true);
								that.byId("tempPosIdF1").setText(positionId);
								that.byId("tempPosTitleIdF1").setText(positionDesc);
								if (positionDesc === "" || positionDesc === "00000000" || positionDesc === undefined) {} else {}
								that.byId("tempUnionCodeIdF1").setText(unCode);
								that.byId("tempLocF1").setText(locEmp);

								that.byId("ShiftIdF1Temp").setText(shift);
								that.byId("cdlQualComboTemp").setText(quals);
								that.byId("engcdlQualComboTemp").setText(quals);

								that.byId("tempAgreementIdF1").setText(aggrCode);
								that.byId("tempRosterNumIdF1").setText(rosterNoEmp);

								that.byId("tempAreaIdF1").setText(area);
								that.byId("tempRDaysIdF1").setText(rdays);
								that.byId("reasonComboTemp").setText(Reason);
								// that.byId("tempPosIdF1").setVisible(true);
								// that.byId("tempPosIdLabelF1").setVisible(true);
								// that.byId("tempPosTitleIdF1").setVisible(true);
								// that.byId("tempUnionCodeIdF1").setVisible(true);
								// that.byId("tempUnionCodeIdLabelF1").setVisible(true);
								// if (that.craftUnion === "Mechanical") {
								// 	that.byId("tempLocF1").setVisible(false);

								// } else {
								// 	that.byId("tempLocF1").setVisible(true);
								// }
								// if (that.craftUnion === "Mechanical") {
								// 	that.byId("engPosTypeF1").setVisible(true);
								// 	that.byId("engPosTypeLabelF1").setVisible(true);
								// 	that.byId("engAreaIdLabelF1").setVisible(false);
								// 	that.byId("engAreaIdF1").setVisible(false);
								// 	that.byId("engUnionCodeIdLabelF1").setVisible(false);
								// 	that.byId("engUnionCodeIdF1").setVisible(false);
								// 	that.byId("engShiftIdLabelF1").setVisible(true);
								// 	that.byId("engShiftIdF1").setVisible(true);
								// 	that.byId("reasonComboForce").setVisible(false);
								// 	that.byId("forceAssignReasonLabel").setVisible(false);
								// 	that.byId("engAgreementIdLabelF1").setVisible(false);
								// 	that.byId("engAgreementIdF1").setVisible(false);
								// 	that.byId("forcecdlQualLabel").setVisible(true);
								// 	that.byId("cdlQualComboForce").setVisible(true);
								// } else {
								// 	that.byId("engPosTypeF1").setVisible(false);
								// 	that.byId("engPosTypeLabelF1").setVisible(false);
								// 	that.byId("engAreaIdLabelF1").setVisible(true);
								// 	that.byId("engAreaIdF1").setVisible(true);
								// 	that.byId("engUnionCodeIdLabelF1").setVisible(true);
								// 	that.byId("engUnionCodeIdF1").setVisible(true);
								// 	that.byId("engShiftIdLabelF1").setVisible(false);
								// 	that.byId("engShiftIdF1").setVisible(false);
								// 	that.byId("forceAssignReasonLabel").setVisible(true);
								// 	that.byId("reasonComboForce").setVisible(true);
								// 	that.byId("engAgreementIdLabelF1").setVisible(true);
								// 	that.byId("engAgreementIdF1").setVisible(true);
								// 	that.byId("forcecdlQualLabel").setVisible(false);
								// 	that.byId("cdlQualComboForce").setVisible(false);
								// }

								// that.byId("tempLocLabelF1").setVisible(true);
								// that.byId("tempAgreementIdF1").setVisible(true);
								// that.byId("tempAgreementIdLabelF1").setVisible(true);
								// that.byId("tempRosterNumIdF1").setVisible(true);
								// that.byId("tempRosterNumIdLabelF1").setVisible(true);
								// that.byId("tempAssignReasonLabel").setVisible(true);
							} else {
								// that.byId("forceAssignmentPosDataForm").setVisible(false);
								// that.byId("tempAssignmentPosDataForm").setVisible(true);
								that.byId("tempPosIdF1").setText(positionId);
								// that.byId("tempPosIdF1").setVisible(true);
								// that.byId("tempPosIdLabelF1").setVisible(true);
								// that.byId("tempPosTitleIdF1").setVisible(true);
								if (positionDesc === "" || positionDesc === "00000000" || positionDesc === undefined) {
									that.byId("tempPosTitleIdF1").setText(positionDesc);
								} else {
									that.byId("tempPosTitleIdF1").setText(positionDesc);
								}
								// if (that.craftUnion === "Mechanical") {
								// 	that.byId("tempLocF1").setVisible(false);

								// } else {
								// 	that.byId("tempLocF1").setVisible(true);
								// }
								// if (that.craftUnion === "Mechanical") {
								// 	that.byId("engPosTypeF1").setVisible(true);
								// 	that.byId("engPosTypeLabelF1").setVisible(true);
								// 	that.byId("engAreaIdLabelF1").setVisible(false);
								// 	that.byId("engAreaIdF1").setVisible(false);
								// 	that.byId("engUnionCodeIdLabelF1").setVisible(false);
								// 	that.byId("engUnionCodeIdF1").setVisible(false);
								// 	that.byId("engShiftIdLabelF1").setVisible(true);
								// 	that.byId("engShiftIdF1").setVisible(true);
								// 	that.byId("reasonComboForce").setVisible(false);
								// 	that.byId("forceAssignReasonLabel").setVisible(false);
								// 	that.byId("engAgreementIdLabelF1").setVisible(false);
								// 	that.byId("engAgreementIdF1").setVisible(false);
								// 	that.byId("forcecdlQualLabel").setVisible(true);
								// 	that.byId("cdlQualComboForce").setVisible(true);
								// } else {
								// 	that.byId("engPosTypeF1").setVisible(false);
								// 	that.byId("engPosTypeLabelF1").setVisible(false);
								// 	that.byId("engAreaIdLabelF1").setVisible(true);
								// 	that.byId("engAreaIdF1").setVisible(true);
								// 	that.byId("engUnionCodeIdLabelF1").setVisible(true);
								// 	that.byId("engUnionCodeIdF1").setVisible(true);
								// 	that.byId("engShiftIdLabelF1").setVisible(false);
								// 	that.byId("engShiftIdF1").setVisible(false);
								// 	that.byId("forceAssignReasonLabel").setVisible(true);
								// 	that.byId("reasonComboForce").setVisible(true);
								// 	that.byId("engAgreementIdLabelF1").setVisible(true);
								// 	that.byId("engAgreementIdF1").setVisible(true);
								// 	that.byId("forcecdlQualLabel").setVisible(false);
								// 	that.byId("cdlQualComboForce").setVisible(false);
								// }

								// that.byId("tempUnionCodeIdF1").setVisible(false);
								// that.byId("tempUnionCodeIdLabelF1").setVisible(false);
								// that.byId("tempLocF1").setVisible(false);
								// that.byId("tempLocLabelF1").setVisible(false);
								// that.byId("tempAgreementIdF1").setVisible(false);
								// that.byId("tempAgreementIdLabelF1").setVisible(false);
								// that.byId("tempRosterNumIdF1").setVisible(false);
								// that.byId("tempRosterNumIdLabelF1").setVisible(false);
								// that.byId("tempAssignReasonLabel").setVisible(false);
							}
						} else if (selRb === "Permanent Assignment") {
							// that.byId("forceAssignmentPosDataForm").setVisible(true);
							// that.byId("tempAssignmentPosDataForm").setVisible(false);
							if (positionId !== "99999999") {
								// that.byId("forceAssignmentPosDataForm").setVisible(true);
								// that.byId("tempAssignmentPosDataForm").setVisible(false);
								that.byId("tempEmpNameTxt").setText(holderDesc);
								// added current employee bindings.
								that.byId("tempPosIdF1").setText(positionId);
								that.byId("tempPosTitleIdF1").setText(positionDesc);
								if (positionDesc === "" || positionDesc === "00000000" || positionDesc === undefined) {} else {}
								that.byId("tempUnionCodeIdF1").setText(unCode);
								that.byId("tempLocF1").setText(locEmp);

								that.byId("ShiftIdF1Temp").setText(shift);
								that.byId("cdlQualComboTemp").setText(quals);
								that.byId("engcdlQualComboTemp").setText(quals);

								that.byId("tempAgreementIdF1").setText(aggrCode);
								that.byId("tempRosterNumIdF1").setText(rosterNoEmp);

								that.byId("tempAreaIdF1").setText(area);
								that.byId("tempRDaysIdF1").setText(rdays);
								that.byId("reasonComboTemp").setText(Reason);
								// that.byId("engPosIdF1").setText(positionId);
								// that.byId("engPosTitleIdF1").setText(positionDesc);
								//if (positionDesc === "" || positionDesc === "00000000" || positionDesc === undefined) {} else {}
								// that.byId("engUnionCodeIdF1").setText(unCode);
								// that.byId("engLocF1").setText(locEmp);
								// that.byId("engAgreementIdF1").setText(aggrCode);

								// that.byId("engRosterNumIdF1").setText(rosterNoEmp);
								//	that.byId("reasonComboForce").setText(Reason);

								// that.byId("engPosIdF1").setVisible(true);
								// that.byId("engPosIdFLabel1").setVisible(true);
								// that.byId("engPosTitleIdF1").setVisible(true);

								// that.byId("engLocF1").setVisible(true);
								// that.byId("engLocLabelF1").setVisible(true);

								// if (that.craftUnion === "Mechanical") {
								// 	that.byId("engPosTypeF1").setVisible(true);
								// 	that.byId("engPosTypeLabelF1").setVisible(true);
								// 	that.byId("engAreaIdLabelF1").setVisible(false);
								// 	that.byId("engAreaIdF1").setVisible(false);
								// 	that.byId("engUnionCodeIdLabelF1").setVisible(false);
								// 	that.byId("engUnionCodeIdF1").setVisible(false);
								// 	that.byId("engShiftIdLabelF1").setVisible(true);
								// 	that.byId("engShiftIdF1").setVisible(true);
								// 	that.byId("reasonComboForce").setVisible(false);
								// 	that.byId("forceAssignReasonLabel").setVisible(false);
								// 	that.byId("engAgreementIdLabelF1").setVisible(false);
								// 	that.byId("engAgreementIdF1").setVisible(false);
								// 	that.byId("forcecdlQualLabel").setVisible(true);
								// 	that.byId("cdlQualComboForce").setVisible(true);
								// } else {
								// 	that.byId("engPosTypeF1").setVisible(false);
								// 	that.byId("engPosTypeLabelF1").setVisible(false);
								// 	that.byId("engAreaIdLabelF1").setVisible(true);
								// 	that.byId("engAreaIdF1").setVisible(true);
								// 	that.byId("engUnionCodeIdLabelF1").setVisible(true);
								// 	that.byId("engUnionCodeIdF1").setVisible(true);
								// 	that.byId("engShiftIdLabelF1").setVisible(false);
								// 	that.byId("engShiftIdF1").setVisible(false);
								// 	that.byId("forceAssignReasonLabel").setVisible(true);
								// 	that.byId("reasonComboForce").setVisible(true);
								// 	that.byId("engAgreementIdLabelF1").setVisible(true);
								// 	that.byId("engAgreementIdF1").setVisible(true);
								// 	that.byId("forcecdlQualLabel").setVisible(false);
								// 	that.byId("cdlQualComboForce").setVisible(false);
								// }

								// that.byId("engRosterNumIdF1").setVisible(true);
								// that.byId("engRosterNumIdLabelF1").setVisible(true);

							} else {

								// that.byId("forceAssignmentPosDataForm").setVisible(true);
								// that.byId("tempAssignmentPosDataForm").setVisible(false);
								// that.byId("engPosIdF1").setText(positionId);
								// that.byId("engPosIdF1").setVisible(true);
								// that.byId("engPosIdFLabel1").setVisible(true);
								// that.byId("engPosTitleIdF1").setVisible(true);
								// if (positionDesc === "" || positionDesc === "00000000" || positionDesc === undefined) {} else {}
								// that.byId("engUnionCodeIdF1").setVisible(false);
								// that.byId("engUnionCodeIdLabelF1").setVisible(false);
								// that.byId("engLocF1").setVisible(false);
								// that.byId("engLocLabelF1").setVisible(false);
								// that.byId("engAgreementIdF1").setVisible(false);
								// that.byId("engAreaIdLabelF1").setVisible(false);
								// that.byId("engPosTypeF1").setVisible(false);
								// that.byId("engPosTypeLabelF1").setVisible(false);
								// that.byId("engAreaIdF1").setVisible(false);
								// that.byId("engPosTypeF1").setVisible(false);
								// that.byId("engPosTypeLabelF1").setVisible(false);
								// that.byId("engAgreementIdLabelF1").setVisible(false);
								// that.byId("engRosterNumIdF1").setVisible(false);
								// that.byId("engRosterNumIdLabelF1").setVisible(false);
								// that.byId("forceAssignReasonLabel").setVisible(false);
								// that.byId("reasonComboForce").setVisible(false);
								// that.byId("engShiftIdLabelF1").setVisible(false);
								// that.byId("engShiftIdF1").setVisible(false);
								// if (that.craftUnion === "Mechanical") {
								// 	that.byId("engPosTypeF1").setVisible(true);
								// 	that.byId("engPosTypeLabelF1").setVisible(true);
								// 	that.byId("engAreaIdLabelF1").setVisible(false);
								// 	that.byId("engAreaIdF1").setVisible(false);
								// 	that.byId("engUnionCodeIdLabelF1").setVisible(false);
								// 	that.byId("engUnionCodeIdF1").setVisible(false);
								// 	that.byId("engShiftIdLabelF1").setVisible(true);
								// 	that.byId("engShiftIdF1").setVisible(true);
								// 	that.byId("reasonComboForce").setVisible(false);
								// 	that.byId("forceAssignReasonLabel").setVisible(false);
								// 	that.byId("engAgreementIdLabelF1").setVisible(false);
								// 	that.byId("engAgreementIdF1").setVisible(false);
								// 	that.byId("forcecdlQualLabel").setVisible(true);
								// 	that.byId("cdlQualComboForce").setVisible(true);
								// } else {
								// 	that.byId("engPosTypeF1").setVisible(false);
								// 	that.byId("engPosTypeLabelF1").setVisible(false);
								// 	that.byId("engAreaIdLabelF1").setVisible(true);
								// 	that.byId("engAreaIdF1").setVisible(true);
								// 	that.byId("engUnionCodeIdLabelF1").setVisible(true);
								// 	that.byId("engUnionCodeIdF1").setVisible(true);
								// 	that.byId("engShiftIdLabelF1").setVisible(false);
								// 	that.byId("engShiftIdF1").setVisible(false);
								// 	that.byId("forceAssignReasonLabel").setVisible(true);
								// 	that.byId("reasonComboForce").setVisible(true);
								// 	that.byId("engAgreementIdLabelF1").setVisible(true);
								// 	that.byId("engAgreementIdF1").setVisible(true);
								// 	that.byId("forcecdlQualLabel").setVisible(false);
								// 	that.byId("cdlQualComboForce").setVisible(false);
								// }

							}
						}
					} else {
						// that.byId("forceAssignmentPosDataForm").setVisible(false);
						// that.byId("tempAssignmentPosDataForm").setVisible(false);
					}

					if (selRb === "Holding Position Assignment") {
						// that.byId("forceAssignmentPosDataForm").setVisible(true);
						// that.byId("tempAssignmentPosDataForm").setVisible(false);
						// that.byId("forceAssignmentPosDataForm").setVisible(true);
						// that.byId("tempAssignmentPosDataForm").setVisible(false);
						that.byId("tempEmpNameTxt").setText(holderDesc);
						// that.byId("engPosIdF1").setText(positionId);
						// that.byId("engPosTitleIdF1").setText(positionDesc);
						// that.byId("engUnionCodeIdF1").setText(unCode);
						// that.byId("engLocF1").setText(locEmp);
						// that.byId("engAgreementIdF1").setText(aggrCode);
						// that.byId("engRosterNumIdF1").setText(rosterNoEmp);
						// that.byId("reasonComboForce").setText(Reason);
						// that.permExpTrueFun();
						//var that = this;
						// that.byId("PosIdFormTemp").setVisible(false);
						// that.byId("PositionEngFormId").setVisible(true);
						// that.byId("tempAssignmentPanel").setVisible(false);
						// that.byId("forceAssignmentPanel").setVisible(true);
						that.byId("historyPanel").setVisible(false);
						// that.byId("posDataPanel").setExpanded(true);
						// that.byId("tempAssignmentPanel").setExpanded(true);
						// that.byId("forceAssignmentPanel").setExpanded(true);
						// if (that.histDetailsArr.length > 0) {
						// 	that.byId("forceAssignHistoryPanel").setExpanded(true);
						// } else {
						// 	that.byId("forceAssignHistoryPanel").setExpanded(false);
						// }  
						//	return;
					}

					that.pflag = "";
					if (oData.pswmsgflag !== "") {
						if (oData.pswmsgflag.includes("does not have seniority on Roster")) {
							that.pflag = "C,nosen";
						}
					}
					if (oData.pswmsgflag !== "" && that.pswmsgFlagCheck) {
						var oDialog = new sap.m.Dialog({
							title: "Confirm",
							type: "Message",
							content: new sap.m.Text({
								text: oData.pswmsgflag
							}),
							beginButton: new sap.m.Button({
								text: "Continue",
								press: function () {
									oDialog.close();
									that.pswmsgFlagCheck = false;
								}
							}),
							endButton: new sap.m.Button({
								text: "Cancel",
								press: function () {
									that.byId("tempEmpNoInp").removeAllTokens();
									that.byId("tempEmpNameTxt").setText("");
									oDialog.close();
								}
							}),
							afterClose: function () {
								oDialog.destroy();
							}
						});
						oDialog.open();
						oDialog.setEscapeHandler(function (o) {
							o.reject();
						});

					}

					that.onTempPanelButtonValidation();
				},
				error: function (oResponse) {
					//-----------------------------------------------------------------------	
					// Displaying response body message.
					//-----------------------------------------------------------------------
					var oMessage;
					var titleV = "Information";
					var iconV = sap.m.MessageBox.Icon.INFORMATION;
					if (oResponse.statusCode === 400 || oResponse.statusCode === "400") {
						oMessage = JSON.parse(oResponse.responseText).error.innererror.errordetails[0].message;
						if (JSON.parse(oResponse.responseText).error.innererror.errordetails[0].severity === "error") {
							titleV = "Error";
							iconV = sap.m.MessageBox.Icon.ERROR;
						}
					} else if (oResponse.statusCode === 500) {
						oMessage = $(oResponse.responseText).find("message").first().text();
					}
					sap.m.MessageBox.information(oMessage, {
						icon: iconV,
						title: titleV,
						actions: ["OK"],
						onClose: function (oAction) {
							if (oAction === "OK") {
								if (selRb === "Temporary Assignment") {
									that.byId("tempEmpNoInp").setValueState("Error");
									that.byId("saveBtn").setEnabled(false);
								} else if (selRb === "Permanent Assignment") {
									that.byId("tempEmpNoInp").setValueState("Error");
									that.byId("saveBtn").setEnabled(false);
								} else {
									that.byId("saveBtn").setEnabled(false);
								}
							}
						}
					});
				}
			});
		},
		onStEnDateValidation: function () {
			var that = this;
			var plsEnterDateFormat = that.getView().getModel("i18n").getProperty("plsEnterDateFormat");
			var endDateShouldBeGrtrStDate = that.getView().getModel("i18n").getProperty("endDateShouldBeGrtrStDate");
			var startDate = this.byId("tempStDate").getValue();
			var endDate = this.byId("tempEndDate").getValue();
			if (that.bValid) {
				that.oDP.setValueState(sap.ui.core.ValueState.None);
			} else {
				that.oDP.setValueState(sap.ui.core.ValueState.Error);
				sap.m.MessageToast.show(plsEnterDateFormat);
			}
			if (startDate !== "") {
				var sDate = startDate.substring(0, 4) + "/" + startDate.substring(4, 6) + "/" + startDate.substring(6, 8);
			}
			if (endDate !== "") {
				var eDate = endDate.substring(0, 4) + "/" + endDate.substring(4, 6) + "/" + endDate.substring(6, 8);
			}
			if (new Date(eDate) < new Date(sDate)) {
				this.byId("tempEndDate").setValueState("Error");
				sap.m.MessageToast.show(endDateShouldBeGrtrStDate);
			} else {
				if (that.bValid) {
					that.oDP.setValueState(sap.ui.core.ValueState.None);
				} else {
					that.oDP.setValueState(sap.ui.core.ValueState.Error);
					sap.m.MessageToast.show(plsEnterDateFormat);
				}
			}
		},
		onEndDateValidation: function () {
			var that = this;
			var theForceDateIs = that.getView().getModel("i18n").getProperty("theForceDateIs");
			var doYouWantToChangeIt = that.getView().getModel("i18n").getProperty("doYouWantToChangeIt");
			var titleConfirm = that.getView().getModel("i18n").getProperty("titleConfirm");
			var plsEnterDateFormat = that.getView().getModel("i18n").getProperty("plsEnterDateFormat");
			var endDateShouldBeGrtrStDate = that.getView().getModel("i18n").getProperty("endDateShouldBeGrtrStDate");
			var yes = that.getView().getModel("i18n").getProperty("yes");
			var no = that.getView().getModel("i18n").getProperty("no");
			var assignmentRb = that.byId("assignmentRb").getSelectedButton().getText();
			var date = that.byId("tempEndDate").getValue().slice(0, 6).slice(4) + "/" + that.byId("tempEndDate").getValue().slice(6) + "/" +
				that.byId("tempEndDate")
				.getValue().slice(0, 4);
			if (date !== that.highDate) {
				var sDate = that.highDate.split("/");
				var cDate = sDate[2] + sDate[0] + sDate[1];
				if (cDate <= "99991231") {
					sap.m.MessageBox.information(theForceDateIs + that.highDate + doYouWantToChangeIt, {
						icon: sap.m.MessageBox.Icon.INFORMATION,
						title: "Information",
						actions: ["YES", "NO"],
						onClose: function (oAction) {
							if (oAction === "YES") {
								that.highDate = date;
								that.forceEndDateSelectFlag = "X";
								var startDate = that.byId("tempStDate").getValue();
								var endDate = that.byId("tempEndDate").getValue();
								if (that.bValid) {
									that.oDP.setValueState(sap.ui.core.ValueState.None);
								} else {
									that.oDP.setValueState(sap.ui.core.ValueState.Error);
									sap.m.MessageToast.show(plsEnterDateFormat);
								}
								if (startDate !== "") {
									var stDate = startDate.substring(0, 4) + "/" + startDate.substring(4, 6) + "/" + startDate.substring(6, 8);
								}
								if (endDate !== "") {
									var eDate = endDate.substring(0, 4) + "/" + endDate.substring(4, 6) + "/" + endDate.substring(6, 8);
								}
								if (new Date(eDate) < new Date(stDate)) {
									that.byId("tempEndDate").setValueState("Error");
									sap.m.MessageToast.show(endDateShouldBeGrtrStDate);
								} else {
									if (that.bValid) {
										that.oDP.setValueState(sap.ui.core.ValueState.None);
									} else {
										that.oDP.setValueState(sap.ui.core.ValueState.Error);
										sap.m.MessageToast.show(plsEnterDateFormat);
									}
								}
								if (assignmentRb === "Temporary Assignment") {
									that.onTempPanelButtonValidation();
								} else if (assignmentRb === "Permanent Assignment") {
									that.onForcePanelButtonValidation();
								}
							} else if (oAction === "NO") {
								if (that.highDate === "//") {
									that.byId("tempEndDate").setValue();
								} else {
									that.byId("tempEndDate").setValue(that.highDate);
								}
								if (assignmentRb === "Temporary Assignment") {
									that.onTempPanelButtonValidation();
								} else if (assignmentRb === "Permanent Assignment") {
									that.onForcePanelButtonValidation();
								}
							}
						}
					});
				}
			}
		},
		onTempPanelButtonValidation: function () {
			var that = this;
			if (that.byId("tempStDate").getValue() !== "" && that.byId("tempEndDate").getValue() !== "" && that.byId("tempStDate").getValueState() !==
				"Error" &&
				that.byId("tempEndDate").getValueState() !== "Error" && that.byId("tempEmpNoInp").getTokens().length !== 0 && that.byId(
					"tempEmpNoInp").getValueState() !== "Error" && that.byId("reasonHeaderCombo").getValue() !== "" && that.byId(
					"reasonHeaderCombo").getValueState() !== "Error") {
				that.byId("saveBtn").setEnabled(true);
				that.byId("posDataPanel").setExpanded(true);
				that.byId("tempAssignmentPanel").setExpanded(true);
				if (that.histDetailsArr.length > 0) {
					that.byId("historyPanel").setExpanded(true);
				} else {
					that.byId("historyPanel").setExpanded(false);
				}
			} else {
				that.byId("saveBtn").setEnabled(false);
				that.byId("posDataPanel").setExpanded(false);
				that.byId("tempAssignmentPanel").setExpanded(false);
				that.byId("historyPanel").setExpanded(false);
			}
		},
		onForcePanelButtonValidation: function () {
			var that = this;
			if (that.byId("tempStDate").getValue() !== "" && that.byId("tempEndDate").getValue() !== "" && that.byId("tempStDate").getValueState !==
				"Error" &&
				that.byId("tempEndDate").getValueState !== "Error" && that.byId("tempEmpNoInp").getTokens().length !== 0 && that.byId(
					"tempEmpNoInp").getValueState !== "Error" && that.byId("reasonHeaderCombo").getValue() !== "" && that.byId(
					"reasonHeaderCombo").getValueState !== "Error") {
				that.byId("saveBtn").setEnabled(true);
				that.byId("posDataPanel").setExpanded(true);
				//	that.byId("forceAssignmentPanel").setExpanded(true);
				if (that.histDetailsArr.length > 0) {
					that.byId("forceAssignHistoryPanel").setExpanded(true);
				} else {
					that.byId("forceAssignHistoryPanel").setExpanded(false);
				}
			} else {
				that.byId("saveBtn").setEnabled(false);
				that.byId("posDataPanel").setExpanded(false);
				//	that.byId("forceAssignmentPanel").setExpanded(false);
				that.byId("forceAssignHistoryPanel").setExpanded(false);
			}
		},
		defaultDate: function () {
			var that = this;
			var newDate = new Date();
			var currDay = newDate.getDate();
			var currMonth = newDate.getMonth() + 1;
			var currYear = newDate.getFullYear();
			if (currDay < 10) {
				currDay = "0" + currDay;
			} else {
				currDay = currDay;
			}
			if (currMonth < 10) {
				currMonth = "0" + currMonth;
			} else {
				currMonth = currMonth;
			}
			var currentDate = currMonth + "/" + currDay + "/" + currYear;
			that.byId("tempStDate").setValue(currentDate);
			var highDate = "12/31/9999";
			// that.highDate = "";
			var selRb = this.byId("assignmentRb").getSelectedButton().getText();
			if (selRb === "Temporary Assignment") {
				that.byId("tempEndDate").setValue(highDate);
				that.byId("tempEndDate").setEnabled(true);
			} else {
				that.byId("tempEndDate").setValue(highDate);
				that.byId("tempEndDate").setEnabled(false);
			}
		},
		//-----------------------------------------------------------------------	
		// Clearing tables in Engineering fragment.
		//-----------------------------------------------------------------------
		engTableClear: function () {
			//-----------------------------------------------------------------------	
			// Engineering Position ID and Title table.
			//-----------------------------------------------------------------------
			sap.ui.getCore().byId("dialoguEngPosIdTitleSearch").setValue();
			var posIdTitleEmptyArr = [];
			var posIdTitleJSONModel = new JSONModel({
				"results": posIdTitleEmptyArr
			});
			sap.ui.getCore().byId("engPosIdOrTitleTabTable").setModel(posIdTitleJSONModel, "engPosIdTitleModelData");
			sap.ui.getCore().byId("engPosIdOrTitleTabTable").setVisible(false);
			//-----------------------------------------------------------------------	
			// Engineering Position Supervisor table.
			//-----------------------------------------------------------------------
			sap.ui.getCore().byId("dialoguEngPosSupSearch").setValue();
			var posSupEmptyArr = [];
			var posSupJSONModel = new JSONModel({
				"results": posSupEmptyArr
			});
			sap.ui.getCore().byId("engPosSupTabTable").setModel(posSupJSONModel, "engPosIdSupModelData");
			sap.ui.getCore().byId("engPosSupTabTable").setVisible(false);
			//-----------------------------------------------------------------------	
			// Engineering Position City table.
			//-----------------------------------------------------------------------
			sap.ui.getCore().byId("dialoguEngPosCitySearch").setValue();
			var posCityEmptyArr = [];
			var posCityJSONModel = new JSONModel({
				"results": posCityEmptyArr
			});
			sap.ui.getCore().byId("engPosCityTabTable").setModel(posCityJSONModel, "engPosCityModelData");
			sap.ui.getCore().byId("engPosCityTabTable").setVisible(false);
			//-----------------------------------------------------------------------	
			// Engineering Position State table.
			//-----------------------------------------------------------------------
			sap.ui.getCore().byId("stateDropDown").setValue();
			var posStateEmptyArr = [];
			var posStateJSONModel = new JSONModel({
				"results": posStateEmptyArr
			});
			sap.ui.getCore().byId("engPosStateTabTable").setModel(posStateJSONModel, "engPosStateModelData");
			sap.ui.getCore().byId("engPosStateTabTable").setVisible(false);
			//-----------------------------------------------------------------------	
			// Engineering Position Division table.
			//-----------------------------------------------------------------------
			sap.ui.getCore().byId("EngDivDropDown").setValue();
			var posDivEmptyArr = [];
			var posDivJSONModel = new JSONModel({
				"results": posDivEmptyArr
			});
			sap.ui.getCore().byId("engPosDivTabTable").setModel(posDivJSONModel, "engPosDivModelData");
			sap.ui.getCore().byId("engPosDivTabTable").setVisible(false);
			//-----------------------------------------------------------------------	
			// Engineering Position Union table.
			//-----------------------------------------------------------------------
			sap.ui.getCore().byId("engUnionDropDown").setSelectedKey();
			var posUnionEmptyArr = [];
			var posUnionJSONModel = new JSONModel({
				"results": posUnionEmptyArr
			});
			sap.ui.getCore().byId("engUnionTabTable").setModel(posUnionJSONModel, "engUnionModelData");
			sap.ui.getCore().byId("engUnionTabTable").setVisible(false);
			//-----------------------------------------------------------------------	
			// Engineering Gang ID table.
			//-----------------------------------------------------------------------
			sap.ui.getCore().byId("dialoguEngPosGangIdSearch").setValue();
			var posGangIdEmptyArr = [];
			var posGangIdJSONModel = new JSONModel({
				"results": posGangIdEmptyArr
			});
			sap.ui.getCore().byId("engPosGangIdTabTable").setModel(posGangIdJSONModel, "engPosGangIdModelData");
			sap.ui.getCore().byId("engPosGangIdTabTable").setVisible(false);
		},
		//-----------------------------------------------------------------------	
		// Clearing tables in Mechanical fragment.
		//-----------------------------------------------------------------------
		mechTableClear: function () {
			//-----------------------------------------------------------------------	
			// Mechanical Position ID and Title table.
			//-----------------------------------------------------------------------
			sap.ui.getCore().byId("dialoguMechPosIdOrTitleSearch").setValue();
			var posIdTitleEmptyArr = [];
			var posIdTitleJSONModel = new JSONModel({
				"results": posIdTitleEmptyArr
			});
			sap.ui.getCore().byId("mechPosIdOrTitleTabTable").setModel(posIdTitleJSONModel, "mechPosIdTitleModelData");
			sap.ui.getCore().byId("mechPosIdOrTitleTabTable").setVisible(false);
			//-----------------------------------------------------------------------	
			// Mechanical Union table.
			//-----------------------------------------------------------------------
			sap.ui.getCore().byId("mechUnionDropDown").setValue();
			var unionEmptyArr = [];
			var unionJSONModel = new JSONModel({
				"results": unionEmptyArr
			});
			sap.ui.getCore().byId("mechUnionTabTable").setModel(unionJSONModel, "mechUnionModelData");
			sap.ui.getCore().byId("mechUnionTabTable").setVisible(false);
			//-----------------------------------------------------------------------	
			// Mechanical Area table.
			//-----------------------------------------------------------------------
			sap.ui.getCore().byId("mechAreaDropDown").setValue();
			var areaEmptyArr = [];
			var areaJSONModel = new JSONModel({
				"results": areaEmptyArr
			});
			sap.ui.getCore().byId("mechPosAreaTabTable").setModel(areaJSONModel, "mechPosAreaModelData");
			sap.ui.getCore().byId("mechPosAreaTabTable").setVisible(false);
			//-----------------------------------------------------------------------	
			// Mechanical Position Craft table.
			//-----------------------------------------------------------------------
			sap.ui.getCore().byId("mechCraftDropDown").setValue();
			var posCraftEmptyArr = [];
			var posCraftJSONModel = new JSONModel({
				"results": posCraftEmptyArr
			});
			sap.ui.getCore().byId("mechPosCraftTabTable").setModel(posCraftJSONModel, "mechPosCraftModelData");
			sap.ui.getCore().byId("mechPosCraftTabTable").setVisible(false);
			//-----------------------------------------------------------------------	
			// Mechanical Position Territory table.
			//-----------------------------------------------------------------------
			sap.ui.getCore().byId("mechTerritoryDropDown").setValue();
			var posTerritoryEmptyArr = [];
			var posTerritoryJSONModel = new JSONModel({
				"results": posTerritoryEmptyArr
			});
			sap.ui.getCore().byId("mechPosTerritoryTabTable").setModel(posTerritoryJSONModel, "mechPosTerritoryModelData");
			sap.ui.getCore().byId("mechPosTerritoryTabTable").setVisible(false);
		},
		//-----------------------------------------------------------------------	
		// Clearing tables in TCU fragment.
		//-----------------------------------------------------------------------
		tcuTableClear: function () {
			//-----------------------------------------------------------------------	
			// TCU Position ID and Title table.
			//-----------------------------------------------------------------------
			sap.ui.getCore().byId("dialoguTcuPosIdOrTitleSearch").setValue();
			var posIdTitleEmptyArr = [];
			var posIdTitleJSONModel = new JSONModel({
				"results": posIdTitleEmptyArr
			});
			sap.ui.getCore().byId("tcuPosIdOrTitleTabTable").setModel(posIdTitleJSONModel, "tcuPosIdTitleModelData");
			sap.ui.getCore().byId("tcuPosIdOrTitleTabTable").setVisible(false);
			//-----------------------------------------------------------------------	
			// TCU Position Department table.
			//-----------------------------------------------------------------------
			sap.ui.getCore().byId("dialoguTcuPosDeptSearch").setValue();
			var posDeptEmptyArr = [];
			var posDeptJSONModel = new JSONModel({
				"results": posDeptEmptyArr
			});
			sap.ui.getCore().byId("tcuPosDeptTabTable").setModel(posDeptJSONModel, "tcuPosDeptModelData");
			sap.ui.getCore().byId("tcuPosDeptTabTable").setVisible(false);
		},
		//-----------------------------------------------------------------------	
		// Clearing tables in ATDA or ILA fragment.
		//-----------------------------------------------------------------------
		ilaTableClear: function () {
			//-----------------------------------------------------------------------	
			// ATDA Or ILA Position ID and Title table.
			//-----------------------------------------------------------------------
			sap.ui.getCore().byId("dialogueIlaPosIdOrTitleSearch").setValue();
			var posIdTitleEmptyArr = [];
			var posIdTitleJSONModel = new JSONModel({
				"results": posIdTitleEmptyArr
			});
			sap.ui.getCore().byId("ilaPosIdOrTitleTable").setModel(posIdTitleJSONModel, "ilaPosIdTitleModelData");
			sap.ui.getCore().byId("ilaPosIdOrTitleTable").setVisible(false);
		},
		//-----------------------------------------------------------------------	
		// Clearing tables in Conrail or IHB or NAHR fragment.
		//-----------------------------------------------------------------------
		conIhbNahrTableClear: function () {
			//-----------------------------------------------------------------------	
			// Conrail or IHB or NAHR Position ID and Title table.
			//-----------------------------------------------------------------------
			sap.ui.getCore().byId("dialoguConIhbNahrPosIdOrTitleSearch").setValue();
			var posIdTitleEmptyArr = [];
			var posIdTitleJSONModel = new JSONModel({
				"results": posIdTitleEmptyArr
			});
			sap.ui.getCore().byId("conIhbNahrPosIdOrTitleTabTable").setModel(posIdTitleJSONModel, "conIhbNahrPosIdTitleModelData");
			sap.ui.getCore().byId("conIhbNahrPosIdOrTitleTabTable").setVisible(false);
			//-----------------------------------------------------------------------	
			// Conrail or IHB or NAHR Position Union table.
			//-----------------------------------------------------------------------
			sap.ui.getCore().byId("conIhbNahrUnionDropDown").setValue();
			var posUnionEmptyArr = [];
			var posUnionJSONModel = new JSONModel({
				"results": posUnionEmptyArr
			});
			sap.ui.getCore().byId("conIhbNahrPosUnionTabTable").setModel(posUnionJSONModel, "conIhbNahrPosUnionModelData");
			sap.ui.getCore().byId("conIhbNahrPosUnionTabTable").setVisible(false);
		},
		//-----------------------------------------------------------------------	
		// Clearing table in EmpID fragment.
		//-----------------------------------------------------------------------
		empIdTableClear: function () {
			//-----------------------------------------------------------------------	
			// Employee ID and Name table.
			//-----------------------------------------------------------------------
			sap.ui.getCore().byId("empIdSearch").setValue();
			var empIdNameEmptyArr = [];
			var empIdNameJSONModel = new JSONModel({
				"results": empIdNameEmptyArr
			});
			sap.ui.getCore().byId("employeeIdTable").setModel(empIdNameJSONModel, "modelData");
			sap.ui.getCore().byId("employeeIdTable").setVisible(false);
		},
		onStateDropDown: function (oEvent) {
			var that = this;
			var oPage = sap.ui.getCore().byId("EngPosIdDialogue");
			oPage.setBusy(true);
			oPage.setBusyIndicatorDelay(0);
			var queryFil = [];
			var key = new sap.ui.model.Filter("Key", "EQ", "S");
			var val = new sap.ui.model.Filter("Value", "EQ", "");
			queryFil.push(key);
			queryFil.push(val);
			var engStateJsonModel = new sap.ui.model.json.JSONModel();
			var oModel = that.getOwnerComponent().getModel();
			oModel.read("/PosDropDownsSet", {
				filters: queryFil,
				success: function (oData) {
					oPage.setBusy(false);
					engStateJsonModel.setData(oData);
					that.getView().setModel(engStateJsonModel, "engStateJsonModel");
					var oUniqJsonModel = that.getView().getModel("engStateJsonModel").getData().results;
					var uniqStateArr = that.uniqueDropDownValFun(oUniqJsonModel, "Value");
					var oStateArray = {
						results: uniqStateArr
					};
					var oStateModel = new sap.ui.model.json.JSONModel(oStateArray);
					var engStateTable = sap.ui.getCore().byId("stateDropDown");
					engStateTable.setModel(oStateModel, "engStateModelData");
				},
				error: function (oResponse) {
					oPage.setBusy(false);
					that.errorMessageFun(oResponse);
				}
			});
		},
		onStateSelectionChange: function (oEvent) {
			var that = this;
			var oPage = sap.ui.getCore().byId("EngPosIdDialogue");
			var posStateJsonPos = new sap.ui.model.json.JSONModel({});
			var posStateTable = sap.ui.getCore().byId("engPosStateTabTable");
			posStateTable.setModel(posStateJsonPos, "engPosStateModelData");
			var posState = oEvent.getSource().getValue();
			if (posState.length > 0) {
				oPage.setBusy(true);
				oPage.setBusyIndicatorDelay(0);
				var selRb = that.byId("assignmentRb").getSelectedButton().getText();
				var union;
				if (selRb === "Temporary Assignment") {
					union = "ET";
				} else if (selRb === "Permanent Assignment") {
					union = "EP";
				}
				var queryFil = [];
				var state = new sap.ui.model.Filter("State", "EQ", posState);
				var key = new sap.ui.model.Filter("Key", "EQ", union);
				queryFil.push(state);
				queryFil.push(key);
				var oModel = that.getOwnerComponent().getModel();
				oModel.read("/PositionSearchHelpSet", {
					filters: queryFil,
					success: function (oData) {
						oPage.setBusy(false);
						if (oData.results.length > 0) {
							posStateTable.getModel("engPosStateModelData").setData(oData);
							posStateTable.getModel("engPosStateModelData").refresh();
							sap.ui.getCore().byId("engPosStateTabTable").setVisible(true);
						} else {
							sap.ui.getCore().byId("engPosStateTabTable").setVisible(false);
						}
					},
					error: function (oResponse) {
						oPage.setBusy(false);
						that.errorMessageFun(oResponse);
					}
				});
			} else {
				oPage.setBusy(false);
				posStateTable.getModel("engPosStateModelData").setData({});
				posStateTable.getModel("engPosStateModelData").refresh();
			}
		},
		onDivDropDown: function () {
			var that = this;
			var oPage = sap.ui.getCore().byId("EngPosIdDialogue");
			oPage.setBusy(true);
			oPage.setBusyIndicatorDelay(0);
			var queryFil = [];
			var key = new sap.ui.model.Filter("Key", "EQ", "D");
			var val = new sap.ui.model.Filter("Value", "EQ", "");
			queryFil.push(key);
			queryFil.push(val);
			var engDivJsonModel = new sap.ui.model.json.JSONModel();
			var oModel = that.getOwnerComponent().getModel();
			oModel.read("/PosDropDownsSet", {
				filters: queryFil,
				success: function (oData) {
					oPage.setBusy(false);
					engDivJsonModel.setData(oData);
					that.getView().setModel(engDivJsonModel, "engDivJsonModel");
					var oUniqJsonModel = that.getView().getModel("engDivJsonModel").getData().results;
					var uniqDivArr = that.uniqueDropDownValFun(oUniqJsonModel, "Value");
					var oDivisionArray = {
						results: uniqDivArr
					};
					var oDivisionModel = new sap.ui.model.json.JSONModel(oDivisionArray);
					var engDivComboBox = sap.ui.getCore().byId("EngDivDropDown");
					engDivComboBox.setModel(oDivisionModel, "engDivModelData");
				},
				error: function (oResponse) {
					oPage.setBusy(false);
					that.errorMessageFun(oResponse);
				}
			});
		},
		onEngEmpSelectionChange: function (oEvent) {
			var that = this;
			var oPage = sap.ui.getCore().byId("EngPosIdDialogue");
			var posDivJsonPos = new sap.ui.model.json.JSONModel({});
			var posDivTable = sap.ui.getCore().byId("engPosEmpTabTable");
			posDivTable.setModel(posDivJsonPos, "engPosEmpModelData");
			var posDiv = oEvent.getSource().getValue();
			var posDivsion;
			if (posDiv.includes("&") === true) {
				var posDivSplit = posDiv.split("&");
				posDivsion = posDivSplit[0] + "and" + posDivSplit[1];
			} else {
				posDivsion = posDiv;
			}
			if (posDivsion.length > 0) {
				oPage.setBusy(true);
				oPage.setBusyIndicatorDelay(0);
				var selRb = that.byId("assignmentRb").getSelectedButton().getText();
				var union;
				if (selRb === "Temporary Assignment") {
					union = "ET";
				} else if (selRb === "Permanent Assignment") {
					union = "EP";
				}
				var queryFil = [];
				var division = new sap.ui.model.Filter("CurntOcupnt", "EQ", posDivsion);
				var key = new sap.ui.model.Filter("Key", "EQ", union);
				queryFil.push(division);
				queryFil.push(key);
				var oModel = that.getOwnerComponent().getModel();
				oModel.read("/PositionSearchHelpSet", {
					filters: queryFil,
					success: function (oData) {
						oPage.setBusy(false);
						if (oData.results.length > 0) {
							posDivTable.getModel("engPosEmpModelData").setData(oData);
							posDivTable.getModel("engPosEmpModelData").refresh();
							sap.ui.getCore().byId("engPosEmpTabTable").setVisible(true);
						} else {
							sap.ui.getCore().byId("engPosEmpTabTable").setVisible(false);
						}
					},
					error: function (oResponse) {
						oPage.setBusy(false);
						that.errorMessageFun(oResponse);
					}
				});
			} else {
				oPage.setBusy(false);
				posDivTable.getModel("engPosEmpModelData").setData({});
				posDivTable.getModel("engPosEmpModelData").refresh();
			}
		},
		onDivSelectionChange: function (oEvent) {
			var that = this;
			var oPage = sap.ui.getCore().byId("EngPosIdDialogue");
			var posDivJsonPos = new sap.ui.model.json.JSONModel({});
			var posDivTable = sap.ui.getCore().byId("engPosDivTabTable");
			posDivTable.setModel(posDivJsonPos, "engPosDivModelData");
			var posDiv = oEvent.getSource().getValue();
			var posDivsion;
			if (posDiv.includes("&") === true) {
				var posDivSplit = posDiv.split("&");
				posDivsion = posDivSplit[0] + "and" + posDivSplit[1];
			} else {
				posDivsion = posDiv;
			}
			if (posDivsion.length > 0) {
				oPage.setBusy(true);
				oPage.setBusyIndicatorDelay(0);
				var selRb = that.byId("assignmentRb").getSelectedButton().getText();
				var union;
				if (selRb === "Temporary Assignment") {
					union = "ET";
				} else if (selRb === "Permanent Assignment") {
					union = "EP";
				}
				var queryFil = [];
				var division = new sap.ui.model.Filter("Divison", "EQ", posDivsion);
				var key = new sap.ui.model.Filter("Key", "EQ", union);
				queryFil.push(division);
				queryFil.push(key);
				var oModel = that.getOwnerComponent().getModel();
				oModel.read("/PositionSearchHelpSet", {
					filters: queryFil,
					success: function (oData) {
						oPage.setBusy(false);
						if (oData.results.length > 0) {
							posDivTable.getModel("engPosDivModelData").setData(oData);
							posDivTable.getModel("engPosDivModelData").refresh();
							sap.ui.getCore().byId("engPosDivTabTable").setVisible(true);
						} else {
							sap.ui.getCore().byId("engPosDivTabTable").setVisible(false);
						}
					},
					error: function (oResponse) {
						oPage.setBusy(false);
						that.errorMessageFun(oResponse);
					}
				});
			} else {
				oPage.setBusy(false);
				posDivTable.getModel("engPosDivModelData").setData({});
				posDivTable.getModel("engPosDivModelData").refresh();
			}
		},
		onGangIdDropDown: function () {
			var that = this;
			var oPage = sap.ui.getCore().byId("EngPosIdDialogue");
			oPage.setBusy(true);
			oPage.setBusyIndicatorDelay(0);
			var queryFil = [];
			var key = new sap.ui.model.Filter("Key", "EQ", "G");
			var val = new sap.ui.model.Filter("Value", "EQ", "");
			queryFil.push(key);
			queryFil.push(val);
			var engGangIdJsonModel = new sap.ui.model.json.JSONModel();
			var oModel = that.getOwnerComponent().getModel();
			oModel.read("/PosDropDownsSet", {
				filters: queryFil,
				success: function (oData) {
					oPage.setBusy(false);
					engGangIdJsonModel.setData(oData);
					that.getView().setModel(engGangIdJsonModel, "engGangIdJsonModel");
					var oUniqJsonModel = that.getView().getModel("engGangIdJsonModel").getData().results;
					var uniqDivArr = that.uniqueDropDownValFun(oUniqJsonModel, "Value");
					var oGangIdArray = {
						results: uniqDivArr
					};
					var oGangIdModel = new sap.ui.model.json.JSONModel(oGangIdArray);
					oGangIdModel.setSizeLimit(oData.results.length);
					var engGangIdComboBox = sap.ui.getCore().byId("dialoguEngPosGangIdSearch");
					engGangIdComboBox.setModel(oGangIdModel, "engGangIdDropDownData");
				},
				error: function (oResponse) {
					oPage.setBusy(false);
					that.errorMessageFun(oResponse);
				}
			});
		},
		onEngGangIdSelectionChange: function (oEvent) {
			var that = this;
			var oPage = sap.ui.getCore().byId("EngPosIdDialogue");
			var posGangIdJsonPos = new sap.ui.model.json.JSONModel({});
			var posGangIdTable = sap.ui.getCore().byId("engPosGangIdTabTable");
			posGangIdTable.setModel(posGangIdJsonPos, "engPosGangIdModelData");
			var posGangId = oEvent.getSource().getValue();
			if (posGangId.length > 0) {
				oPage.setBusy(true);
				oPage.setBusyIndicatorDelay(0);
				var selRb = that.byId("assignmentRb").getSelectedButton().getText();
				var union;
				if (selRb === "Temporary Assignment") {
					union = "ET";
				} else if (selRb === "Permanent Assignment") {
					union = "EP";
				}
				var queryFil = [];
				var gang = new sap.ui.model.Filter("GangId", "EQ", posGangId);
				var key = new sap.ui.model.Filter("Key", "EQ", union);
				queryFil.push(gang);
				queryFil.push(key);
				var oModel = that.getOwnerComponent().getModel();
				oModel.read("/PositionSearchHelpSet", {
					filters: queryFil,
					success: function (oData) {
						oPage.setBusy(false);
						if (oData.results.length > 0) {
							posGangIdTable.getModel("engPosGangIdModelData").setData(oData);
							posGangIdTable.getModel("engPosGangIdModelData").refresh();
							sap.ui.getCore().byId("engPosGangIdTabTable").setVisible(true);
						} else {
							sap.ui.getCore().byId("engPosGangIdTabTable").setVisible(false);
						}
					},
					error: function (oResponse) {
						oPage.setBusy(false);
						that.errorMessageFun(oResponse);
					}
				});
			} else {
				oPage.setBusy(false);
				posGangIdTable.getModel("engPosGangIdModelData").setData({});
				posGangIdTable.getModel("engPosGangIdModelData").refresh();
			}
		},
		onCraftDropDown: function () {
			var that = this;
			var oPage = sap.ui.getCore().byId("mechPosIdDialogue");
			oPage.setBusy(true);
			oPage.setBusyIndicatorDelay(0);
			var queryFil = [];
			var key = new sap.ui.model.Filter("Key", "EQ", "C");
			var val = new sap.ui.model.Filter("Value", "EQ", "");
			queryFil.push(key);
			queryFil.push(val);
			var mechCraftJsonModel = new sap.ui.model.json.JSONModel();
			var oModel = that.getOwnerComponent().getModel();
			oModel.read("/PosDropDownsSet", {
				filters: queryFil,
				success: function (oData) {
					oPage.setBusy(false);
					mechCraftJsonModel.setData(oData);
					that.getView().setModel(mechCraftJsonModel, "mechCraftJsonModel");
					var oUniqJsonModel = that.getView().getModel("mechCraftJsonModel").getData().results;
					var uniqCraftArr = that.uniqueDropDownValFun(oUniqJsonModel, "Value");
					var oCraftArray = {
						results: uniqCraftArr
					};
					var oCraftModel = new sap.ui.model.json.JSONModel(oCraftArray);
					var mechCraftComboBox = sap.ui.getCore().byId("mechCraftDropDown");
					mechCraftComboBox.setModel(oCraftModel, "mechCraftModelData");
				},
				error: function (oResponse) {
					oPage.setBusy(false);
					that.errorMessageFun(oResponse);
				}
			});
		},
		onCraftSelectionChange: function (oEvent) {
			var that = this;
			var oPage = sap.ui.getCore().byId("mechPosIdDialogue");
			oPage.setBusy(true);
			oPage.setBusyIndicatorDelay(0);
			var posCraftJsonPos = new sap.ui.model.json.JSONModel({});
			var posCraftTable = sap.ui.getCore().byId("mechPosCraftTabTable");
			posCraftTable.setModel(posCraftJsonPos, "mechPosCraftModelData");
			var posCraft = oEvent.getSource().getValue();
			if (posCraft.length > 0) {
				var selRb = that.byId("assignmentRb").getSelectedButton().getText();
				var union;
				if (selRb === "Temporary Assignment") {
					union = "MT";
				} else if (selRb === "Permanent Assignment") {
					union = "MP";
				}
				var queryFil = [];
				var craft = new sap.ui.model.Filter("Craft", "EQ", posCraft);
				var key = new sap.ui.model.Filter("Key", "EQ", union);
				queryFil.push(craft);
				queryFil.push(key);
				var oModel = that.getOwnerComponent().getModel();
				oModel.read("/PositionSearchHelpSet", {
					filters: queryFil,
					success: function (oData) {
						oPage.setBusy(false);
						if (oData.results.length > 0) {
							for (var i = 0; i < oData.results.length; i++) {
								var arreaArray = [];
								var sunday = oData.results[i].Sunday;
								var monday = oData.results[i].Monday;
								var tuesday = oData.results[i].Tuesday;
								var wednesday = oData.results[i].Wednesday;
								var thursday = oData.results[i].Thursday;
								var friday = oData.results[i].Friday;
								var saturday = oData.results[i].Saturday;
								if (sunday !== "") {
									arreaArray.push(sunday);
								}
								if (monday !== "") {
									arreaArray.push(monday);
								}
								if (tuesday !== "") {
									arreaArray.push(tuesday);
								}
								if (wednesday !== "") {
									arreaArray.push(wednesday);
								}
								if (thursday !== "") {
									arreaArray.push(thursday);
								}
								if (friday !== "") {
									arreaArray.push(friday);
								}
								if (saturday !== "") {
									arreaArray.push(saturday);
								}
								oData.results[i].Area = that.majorityValFun(arreaArray);
								if (oData.results[i].Area === undefined) {
									oData.results[i].Area = oData.results[i].Monday;
								}
							}
							posCraftTable.getModel("mechPosCraftModelData").setData(oData);
							posCraftTable.getModel("mechPosCraftModelData").refresh();
							sap.ui.getCore().byId("mechPosCraftTabTable").setVisible(true);
						} else {
							sap.ui.getCore().byId("mechPosCraftTabTable").setVisible(false);
						}
					},
					error: function (oResponse) {
						oPage.setBusy(false);
						that.errorMessageFun(oResponse);
					}
				});
			} else {
				oPage.setBusy(false);
				posCraftTable.getModel("mechPosCraftModelData").setData({});
				posCraftTable.getModel("mechPosCraftModelData").refresh();
			}
		},
		onTerritoryDropDown: function () {
			var that = this;
			var oPage = sap.ui.getCore().byId("mechPosIdDialogue");
			oPage.setBusy(true);
			oPage.setBusyIndicatorDelay(0);
			var queryFil = [];
			var key = new sap.ui.model.Filter("Key", "EQ", "T");
			var val = new sap.ui.model.Filter("Value", "EQ", "");
			queryFil.push(key);
			queryFil.push(val);
			var mechTerritoryJsonModel = new sap.ui.model.json.JSONModel();
			var oModel = that.getOwnerComponent().getModel();
			oModel.read("/PosDropDownsSet", {
				filters: queryFil,
				success: function (oData) {
					oPage.setBusy(false);
					mechTerritoryJsonModel.setData(oData);
					that.getView().setModel(mechTerritoryJsonModel, "mechTerritoryJsonModel");
					var oUniqJsonModel = that.getView().getModel("mechTerritoryJsonModel").getData().results;
					var uniqTerritoryArr = that.uniqueDropDownValFun(oUniqJsonModel, "Value");
					var oTerritoryArray = {
						results: uniqTerritoryArr
					};
					var oTerritoryModel = new sap.ui.model.json.JSONModel(oTerritoryArray);
					var mechTerritoryComboBox = sap.ui.getCore().byId("mechTerritoryDropDown");
					mechTerritoryComboBox.setModel(oTerritoryModel, "mechTerritoryModelData");
				},
				error: function (oResponse) {
					oPage.setBusy(false);
					that.errorMessageFun(oResponse);
				}
			});
		},
		onMechTerritorySelectionChange: function (oEvent) {
			var that = this;
			var oPage = sap.ui.getCore().byId("mechPosIdDialogue");
			oPage.setBusy(true);
			oPage.setBusyIndicatorDelay(0);
			var posTerritoryJsonPos = new sap.ui.model.json.JSONModel({});
			var posTerritoryTable = sap.ui.getCore().byId("mechPosTerritoryTabTable");
			posTerritoryTable.setModel(posTerritoryJsonPos, "mechPosTerritoryModelData");
			var posTerritory = oEvent.getSource().getValue();
			if (posTerritory.length > 0) {
				var selRb = that.byId("assignmentRb").getSelectedButton().getText();
				var union;
				if (selRb === "Temporary Assignment") {
					union = "MT";
				} else if (selRb === "Permanent Assignment") {
					union = "MP";
				}
				var queryFil = [];
				var territory = new sap.ui.model.Filter("Territory", "EQ", posTerritory);
				var key = new sap.ui.model.Filter("Key", "EQ", union);
				queryFil.push(territory);
				queryFil.push(key);
				var oModel = that.getOwnerComponent().getModel();
				oModel.read("/PositionSearchHelpSet", {
					filters: queryFil,
					success: function (oData) {
						oPage.setBusy(false);
						if (oData.results.length > 0) {
							for (var i = 0; i < oData.results.length; i++) {
								var arreaArray = [];
								var sunday = oData.results[i].Sunday;
								var monday = oData.results[i].Monday;
								var tuesday = oData.results[i].Tuesday;
								var wednesday = oData.results[i].Wednesday;
								var thursday = oData.results[i].Thursday;
								var friday = oData.results[i].Friday;
								var saturday = oData.results[i].Saturday;
								if (sunday !== "") {
									arreaArray.push(sunday);
								}
								if (monday !== "") {
									arreaArray.push(monday);
								}
								if (tuesday !== "") {
									arreaArray.push(tuesday);
								}
								if (wednesday !== "") {
									arreaArray.push(wednesday);
								}
								if (thursday !== "") {
									arreaArray.push(thursday);
								}
								if (friday !== "") {
									arreaArray.push(friday);
								}
								if (saturday !== "") {
									arreaArray.push(saturday);
								}
								oData.results[i].Area = that.majorityValFun(arreaArray);
								if (oData.results[i].Area === undefined) {
									oData.results[i].Area = oData.results[i].Monday;
								}
							}
							posTerritoryTable.getModel("mechPosTerritoryModelData").setData(oData);
							posTerritoryTable.getModel("mechPosTerritoryModelData").refresh();
							sap.ui.getCore().byId("mechPosTerritoryTabTable").setVisible(true);
						} else {
							sap.ui.getCore().byId("mechPosTerritoryTabTable").setVisible(false);
						}
					},
					error: function (oResponse) {
						oPage.setBusy(false);
						that.errorMessageFun(oResponse);
					}
				});
			} else {
				oPage.setBusy(false);
				posTerritoryTable.getModel("mechPosTerritoryModelData").setData({});
				posTerritoryTable.getModel("mechPosTerritoryModelData").refresh();
			}
		},
		onMechEmpSelectionChange: function (oEvent) {
			var that = this;
			var oPage = sap.ui.getCore().byId("mechPosIdDialogue");
			oPage.setBusy(true);
			oPage.setBusyIndicatorDelay(0);
			var posTerritoryJsonPos = new sap.ui.model.json.JSONModel({});
			var posTerritoryTable = sap.ui.getCore().byId("mechPosEmpTabTable");
			posTerritoryTable.setModel(posTerritoryJsonPos, "mechPosEmpModelData");
			var posTerritory = oEvent.getSource().getValue();
			if (posTerritory.length > 0) {
				var selRb = that.byId("assignmentRb").getSelectedButton().getText();
				var union;
				if (selRb === "Temporary Assignment") {
					union = "MT";
				} else if (selRb === "Permanent Assignment") {
					union = "MP";
				}
				var queryFil = [];
				var territory = new sap.ui.model.Filter("CurntOcupnt", "EQ", posTerritory);
				var key = new sap.ui.model.Filter("Key", "EQ", union);
				queryFil.push(territory);
				queryFil.push(key);
				var oModel = that.getOwnerComponent().getModel();
				oModel.read("/PositionSearchHelpSet", {
					filters: queryFil,
					success: function (oData) {
						oPage.setBusy(false);
						if (oData.results.length > 0) {
							for (var i = 0; i < oData.results.length; i++) {
								var arreaArray = [];
								var sunday = oData.results[i].Sunday;
								var monday = oData.results[i].Monday;
								var tuesday = oData.results[i].Tuesday;
								var wednesday = oData.results[i].Wednesday;
								var thursday = oData.results[i].Thursday;
								var friday = oData.results[i].Friday;
								var saturday = oData.results[i].Saturday;
								if (sunday !== "") {
									arreaArray.push(sunday);
								}
								if (monday !== "") {
									arreaArray.push(monday);
								}
								if (tuesday !== "") {
									arreaArray.push(tuesday);
								}
								if (wednesday !== "") {
									arreaArray.push(wednesday);
								}
								if (thursday !== "") {
									arreaArray.push(thursday);
								}
								if (friday !== "") {
									arreaArray.push(friday);
								}
								if (saturday !== "") {
									arreaArray.push(saturday);
								}
								oData.results[i].Area = that.majorityValFun(arreaArray);

								if (oData.results[i].Area === undefined) {
									oData.results[i].Area = oData.results[i].Monday;
								}
							}
							posTerritoryTable.getModel("mechPosEmpModelData").setData(oData);
							posTerritoryTable.getModel("mechPosEmpModelData").refresh();
							sap.ui.getCore().byId("mechPosEmpTabTable").setVisible(true);
						} else {
							sap.ui.getCore().byId("mechPosEmpTabTable").setVisible(false);
						}
					},
					error: function (oResponse) {
						oPage.setBusy(false);
						that.errorMessageFun(oResponse);
					}
				});
			} else {
				oPage.setBusy(false);
				posTerritoryTable.getModel("mechPosEmpModelData").setData({});
				posTerritoryTable.getModel("mechPosEmpModelData").refresh();
			}
		},
		onUnionDropDown: function () {
			var that = this;
			var oPage;
			var selRb = that.byId("assignmentRb").getSelectedButton().getText();
			var value;
			if (that.craftUnion === "Engineering") {
				value = "E";
				oPage = sap.ui.getCore().byId("EngPosIdDialogue");
			} else if (that.craftUnion === "Mechanical") {
				value = "M";
				oPage = sap.ui.getCore().byId("mechPosIdDialogue");
			} else if (that.craftUnion === "Conrail") {
				value = "C";
				oPage = sap.ui.getCore().byId("conIhbNahrPosIdDialogue");
			} else if (that.craftUnion === "IHB") {
				// value = "H";
				value = "I";
				oPage = sap.ui.getCore().byId("conIhbNahrPosIdDialogue");
			} else if (that.craftUnion === "NAHR") {
				value = "N";
				oPage = sap.ui.getCore().byId("conIhbNahrPosIdDialogue");
			}
			oPage.setBusy(true);
			oPage.setBusyIndicatorDelay(0);
			var queryFil = [];
			var key = new sap.ui.model.Filter("Key", "EQ", "U");
			var val = new sap.ui.model.Filter("Value", "EQ", value);
			queryFil.push(key);
			queryFil.push(val);
			var unionJsonModel = new sap.ui.model.json.JSONModel();
			var oModel = that.getOwnerComponent().getModel();
			oModel.read("/PosDropDownsSet", {
				filters: queryFil,
				success: function (oData) {
					oPage.setBusy(false);
					unionJsonModel.setData(oData);
					that.getView().setModel(unionJsonModel, "unionJsonModel");
					var oUniqJsonModel = that.getView().getModel("unionJsonModel").getData().results;
					var uniqUnionArr = that.uniqueDropDownValFun(oUniqJsonModel, "Value");
					var oUnionArray = {
						results: uniqUnionArr
					};
					var oUnionModel = new sap.ui.model.json.JSONModel(oUnionArray);
					if (that.craftUnion === "Engineering") {
						var engUnionComboBox = sap.ui.getCore().byId("engUnionDropDown");
						engUnionComboBox.setModel(oUnionModel, "engUnionDropDownModelData");
					} else if (that.craftUnion === "Mechanical") {
						var mechUnionComboBox = sap.ui.getCore().byId("mechUnionDropDown");
						mechUnionComboBox.setModel(oUnionModel, "mechUnionDropDownModelData");
					} else if (that.craftUnion === "Conrail" || that.craftUnion === "IHB" || that.craftUnion === "NAHR") {
						var conIhbNahrUnionComboBox = sap.ui.getCore().byId("conIhbNahrUnionDropDown");
						conIhbNahrUnionComboBox.setModel(oUnionModel, "conIhbNahrUnionDropDownModelData");
					}
				},
				error: function (oResponse) {
					oPage.setBusy(false);
					that.errorMessageFun(oResponse);
				}
			});
		},
		//-----------------------------------------------------------------------	
		// Method for gettting uniq drop down values.
		//-----------------------------------------------------------------------
		uniqueDropDownValFun: function (oUniqJsonModel, Value) {
			var oArray = [];
			var checkArray = [];
			for (var i = 0; i < oUniqJsonModel.length; i++) {
				if (oArray.indexOf(oUniqJsonModel[i]["" + Value + ""]) === -1 && oUniqJsonModel[i]["" + Value + ""].trim() !== "") {
					oArray.push(oUniqJsonModel[i]["" + Value + ""]);
					var uObj = Object.assign({}, oUniqJsonModel[i]);
					checkArray.push(uObj);
				}
			}
			return checkArray;
		},
		onEngUnionSelectionChange: function (oEvent) {
			var that = this;
			var oPage = sap.ui.getCore().byId("EngPosIdDialogue");
			var posUnionJsonPos = new sap.ui.model.json.JSONModel({});
			var posUnionTable = sap.ui.getCore().byId("engUnionTabTable");
			posUnionTable.setModel(posUnionJsonPos, "engUnionModelData");
			//var posUnion = oEvent.getSource().getValue();
			var posUnion = sap.ui.getCore().byId("engUnionDropDown").getSelectedKey();
			if (posUnion.length > 0) {
				oPage.setBusy(true);
				oPage.setBusyIndicatorDelay(0);
				var queryFil = [];
				var union = new sap.ui.model.Filter("Union", "EQ", posUnion);
				var key = new sap.ui.model.Filter("Key", "EQ", "E");
				queryFil.push(union);
				queryFil.push(key);
				var oModel = that.getOwnerComponent().getModel();
				oModel.read("/PositionSearchHelpSet", {
					filters: queryFil,
					success: function (oData) {
						oPage.setBusy(false);
						if (oData.results.length > 0) {
							posUnionTable.getModel("engUnionModelData").setData(oData);
							posUnionTable.getModel("engUnionModelData").refresh();
							sap.ui.getCore().byId("engUnionTabTable").setVisible(true);
						} else {
							sap.ui.getCore().byId("engUnionTabTable").setVisible(false);
						}
					},
					error: function (oResponse) {
						oPage.setBusy(false);
						that.errorMessageFun(oResponse);
					}
				});
			} else {
				oPage.setBusy(false);
				posUnionTable.getModel("engUnionModelData").setData({});
				posUnionTable.getModel("engUnionModelData").refresh();
			}
		},
		onMechUnionSelectionChange: function (oEvent) {
			var that = this;
			var oPage = sap.ui.getCore().byId("mechPosIdDialogue");
			var posUnionJsonPos = new sap.ui.model.json.JSONModel({});
			var posUnionTable = sap.ui.getCore().byId("mechUnionTabTable");
			posUnionTable.setModel(posUnionJsonPos, "mechUnionModelData");
			var posUnion = oEvent.getSource().getValue();
			if (posUnion.length > 0) {
				oPage.setBusy(true);
				oPage.setBusyIndicatorDelay(0);
				var selRb = that.byId("assignmentRb").getSelectedButton().getText();
				var union1;
				if (selRb === "Temporary Assignment") {
					union1 = "MT";
				} else if (selRb === "Permanent Assignment") {
					union1 = "MP";
				}
				var queryFil = [];
				var union = new sap.ui.model.Filter("Union", "EQ", posUnion);
				var key = new sap.ui.model.Filter("Key", "EQ", union1);
				queryFil.push(union);
				queryFil.push(key);
				var oModel = that.getOwnerComponent().getModel();
				oModel.read("/PositionSearchHelpSet", {
					filters: queryFil,
					success: function (oData) {
						oPage.setBusy(false);
						if (oData.results.length > 0) {
							for (var i = 0; i < oData.results.length; i++) {
								var arreaArray = [];
								var sunday = oData.results[i].Sunday;
								var monday = oData.results[i].Monday;
								var tuesday = oData.results[i].Tuesday;
								var wednesday = oData.results[i].Wednesday;
								var thursday = oData.results[i].Thursday;
								var friday = oData.results[i].Friday;
								var saturday = oData.results[i].Saturday;
								if (sunday !== "") {
									arreaArray.push(sunday);
								}
								if (monday !== "") {
									arreaArray.push(monday);
								}
								if (tuesday !== "") {
									arreaArray.push(tuesday);
								}
								if (wednesday !== "") {
									arreaArray.push(wednesday);
								}
								if (thursday !== "") {
									arreaArray.push(thursday);
								}
								if (friday !== "") {
									arreaArray.push(friday);
								}
								if (saturday !== "") {
									arreaArray.push(saturday);
								}
								oData.results[i].Area = that.majorityValFun(arreaArray);
								if (oData.results[i].Area === undefined) {
									oData.results[i].Area = oData.results[i].Monday;
								}
							}
							posUnionTable.getModel("mechUnionModelData").setData(oData);
							posUnionTable.getModel("mechUnionModelData").refresh();
							sap.ui.getCore().byId("mechUnionTabTable").setVisible(true);
						} else {
							sap.ui.getCore().byId("mechUnionTabTable").setVisible(false);
						}
					},
					error: function (oResponse) {
						oPage.setBusy(false);
						that.errorMessageFun(oResponse);
					}
				});
			} else {
				oPage.setBusy(false);
				posUnionTable.getModel("mechUnionModelData").setData({});
				posUnionTable.getModel("mechUnionModelData").refresh();
			}
		},
		onConIhbNahrUnionSelectionChange: function (oEvent) {
			var that = this;
			var oPage = sap.ui.getCore().byId("conIhbNahrPosIdDialogue");
			var selRb = that.byId("assignmentRb").getSelectedButton().getText();
			var unionKey;
			if (that.craftUnion === "Conrail") {
				if (selRb === "Temporary Assignment") {
					unionKey = "CT";
				} else if (selRb === "Permanent Assignment") {
					unionKey = "CP";
				}
			} else if (that.craftUnion === "IHB") {
				if (selRb === "Temporary Assignment") {
					unionKey = "IT";
				} else if (selRb === "Permanent Assignment") {
					unionKey = "IP";
				}
			} else if (that.craftUnion === "NAHR") {
				if (selRb === "Temporary Assignment") {
					unionKey = "NT";
				} else if (selRb === "Permanent Assignment") {
					unionKey = "NP";
				}
			}
			var posUnionJsonPos = new sap.ui.model.json.JSONModel({});
			var posUnionTable = sap.ui.getCore().byId("conIhbNahrPosUnionTabTable");
			posUnionTable.setModel(posUnionJsonPos, "conIhbNahrPosUnionModelData");
			var posUnion = oEvent.getSource().getValue();
			if (posUnion.length > 0) {
				oPage.setBusy(true);
				oPage.setBusyIndicatorDelay(0);
				var queryFil = [];
				var union = new sap.ui.model.Filter("Union", "EQ", posUnion);
				var key = new sap.ui.model.Filter("Key", "EQ", unionKey);
				queryFil.push(union);
				queryFil.push(key);
				var oModel = that.getOwnerComponent().getModel();
				oModel.read("/PositionSearchHelpSet", {
					filters: queryFil,
					success: function (oData) {
						oPage.setBusy(false);
						if (oData.results.length > 0) {
							posUnionTable.getModel("conIhbNahrPosUnionModelData").setData(oData);
							posUnionTable.getModel("conIhbNahrPosUnionModelData").refresh();
							sap.ui.getCore().byId("conIhbNahrPosUnionTabTable").setVisible(true);
						} else {
							sap.ui.getCore().byId("conIhbNahrPosUnionTabTable").setVisible(false);
						}
					},
					error: function (oResponse) {
						oPage.setBusy(false);
						that.errorMessageFun(oResponse);
					}
				});
			} else {
				oPage.setBusy(false);
				posUnionTable.getModel("conIhbNahrPosUnionModelData").setData({});
				posUnionTable.getModel("conIhbNahrPosUnionModelData").refresh();
			}
		},
		onAreaDropDown: function () {
			var that = this;
			var oPage = sap.ui.getCore().byId("mechPosIdDialogue");
			oPage.setBusy(true);
			oPage.setBusyIndicatorDelay(0);
			var queryFil = [];
			var key = new sap.ui.model.Filter("Key", "EQ", "A");
			var val = new sap.ui.model.Filter("Value", "EQ", "");
			queryFil.push(key);
			queryFil.push(val);
			var areaJsonModel = new sap.ui.model.json.JSONModel();
			var oModel = that.getOwnerComponent().getModel();
			oModel.read("/PosDropDownsSet", {
				filters: queryFil,
				success: function (oData) {
					oPage.setBusy(false);
					areaJsonModel.setData(oData);
					that.getView().setModel(areaJsonModel, "areaJsonModel");
					var oUniqJsonModel = that.getView().getModel("areaJsonModel").getData().results;
					var uniqAreaArr = that.uniqueDropDownValFun(oUniqJsonModel, "Value");
					var oAreaArray = {
						results: uniqAreaArr
					};
					var oAreaModel = new sap.ui.model.json.JSONModel(oAreaArray);
					oAreaModel.setSizeLimit(99999);
					var areaComboBox = sap.ui.getCore().byId("mechAreaDropDown");
					areaComboBox.setModel(oAreaModel, "mechAreaDropDownModelData");
				},
				error: function (oResponse) {
					oPage.setBusy(false);
					that.errorMessageFun(oResponse);
				}
			});
		},
		onAreaSelectionChange: function (oEvent) {
			var that = this;
			var oPage = sap.ui.getCore().byId("mechPosIdDialogue");
			var posAreaJsonPos = new sap.ui.model.json.JSONModel({});
			var posAreaTable = sap.ui.getCore().byId("mechPosAreaTabTable");
			posAreaTable.setModel(posAreaJsonPos, "mechPosAreaModelData");
			var posArea = oEvent.getSource().getValue();
			if (posArea.length > 0) {
				oPage.setBusy(true);
				oPage.setBusyIndicatorDelay(0);
				var selRb = that.byId("assignmentRb").getSelectedButton().getText();
				var union;
				if (selRb === "Temporary Assignment") {
					union = "MT";
				} else if (selRb === "Permanent Assignment") {
					union = "MP";
				}
				var queryFil = [];
				var area = new sap.ui.model.Filter("Area", "EQ", posArea);
				var key = new sap.ui.model.Filter("Key", "EQ", union);
				queryFil.push(area);
				queryFil.push(key);
				var oModel = that.getOwnerComponent().getModel();
				oModel.read("/PositionSearchHelpSet", {
					filters: queryFil,
					success: function (oData) {
						oPage.setBusy(false);
						if (oData.results.length > 0) {
							posAreaTable.getModel("mechPosAreaModelData").setData(oData);
							posAreaTable.getModel("mechPosAreaModelData").refresh();
							sap.ui.getCore().byId("mechPosAreaTabTable").setVisible(true);
						} else {
							sap.ui.getCore().byId("mechPosAreaTabTable").setVisible(false);
						}
					},
					error: function (oResponse) {
						oPage.setBusy(false);
						that.errorMessageFun(oResponse);
					}
				});
			} else {
				oPage.setBusy(false);
				posAreaTable.getModel("mechPosAreaModelData").setData({});
				posAreaTable.getModel("mechPosAreaModelData").refresh();
			}
		},
		errorMessageFun: function (oResponse) {
			var that = this;
			var titleInfo = that.getView().getModel("i18n").getProperty("titleInfo");
			var ok = that.getView().getModel("i18n").getProperty("ok");
			//-----------------------------------------------------------------------	
			// Displaying response body message.
			//----------------------------------------------------------------------- 
			var oMessage;
			if (oResponse.statusCode === 400 || oResponse.statusCode === "400") {
				oMessage = JSON.parse(oResponse.responseText).error.message.value;
			} else if (oResponse.statusCode === 500) {
				oMessage = $(oResponse.responseText).find("message").first().text();
			}
			sap.m.MessageBox.information(oMessage, {
				icon: sap.m.MessageBox.Icon.INFORMATION,
				title: "Information",
				actions: ["OK"],
				onClose: function (oAction) {
					if (oAction === "OK") {
						var craft = that.craftUnion;
						if (craft === "Engineering") {
							if (that.empDialogFlag === true) {
								that.empDialogFlag = "";
							} else {
								var selIconTab = sap.ui.getCore().byId("idEngIconTabBar").getSelectedKey();
								if (selIconTab === "Position ID OR Title") {
									var posIdDescEmptyArr = [];
									var posIdDescJSONModel = new JSONModel({
										"results": posIdDescEmptyArr
									});
									sap.ui.getCore().byId("engPosIdOrTitleTabTable").setModel(posIdDescJSONModel, "engPosIdTitleModelData");
								} else if (selIconTab === "Union") {
									var engUnionEmptyArr = [];
									var engUnionJSONModel = new JSONModel({
										"results": engUnionEmptyArr
									});
									sap.ui.getCore().byId("engUnionTabTable").setModel(engUnionJSONModel, "engUnionModelData");
								} else if (selIconTab === "Assign Supervisor") {
									var assignSupEmptyArr = [];
									var assignSupJSONModel = new JSONModel({
										"results": assignSupEmptyArr
									});
									sap.ui.getCore().byId("engPosSupTabTable").setModel(assignSupJSONModel, "engPosIdSupModelData");
								} else if (selIconTab === "Division") {
									var divEmptyArr = [];
									var divJSONModel = new JSONModel({
										"results": divEmptyArr
									});
									sap.ui.getCore().byId("engPosDivTabTable").setModel(divJSONModel, "engPosDivModelData");
								} else if (selIconTab === "City") {
									var cityEmptyArr = [];
									var cityJSONModel = new JSONModel({
										"results": cityEmptyArr
									});
									sap.ui.getCore().byId("engPosCityTabTable").setModel(cityJSONModel, "engPosCityModelData");
								} else if (selIconTab === "State") {
									var stateEmptyArr = [];
									var stateJSONModel = new JSONModel({
										"results": stateEmptyArr
									});
									sap.ui.getCore().byId("engPosStateTabTable").setModel(stateJSONModel, "engPosStateModelData");
								}
							}
						} else if (craft === "Mechanical") {
							if (that.empDialogFlag === true) {
								that.empDialogFlag = "";
							} else {
								var mechSelIconTab = sap.ui.getCore().byId("idMechPosIconTabBar").getSelectedKey();
								if (mechSelIconTab === "Position ID OR Title") {
									var mechPosIdDescEmptyArr = [];
									var mechPosIdDescJSONModel = new JSONModel({
										"results": mechPosIdDescEmptyArr
									});
									sap.ui.getCore().byId("mechPosIdOrTitleTabTable").setModel(mechPosIdDescJSONModel, "mechPosIdTitleModelData");
								} else if (mechSelIconTab === "Union") {
									var mechUnionEmptyArr = [];
									var mechUnionJSONModel = new JSONModel({
										"results": mechUnionEmptyArr
									});
									sap.ui.getCore().byId("mechUnionTabTable").setModel(mechUnionJSONModel, "mechUnionModelData");
								} else if (mechSelIconTab === "Area") {
									var areaEmptyArr = [];
									var areaJSONModel = new JSONModel({
										"results": areaEmptyArr
									});
									sap.ui.getCore().byId("mechPosAreaTabTable").setModel(areaJSONModel, "mechPosAreaModelData");
								} else if (mechSelIconTab === "Craft") {
									var craftEmptyArr = [];
									var craftJSONModel = new JSONModel({
										"results": craftEmptyArr
									});
									sap.ui.getCore().byId("mechPosCraftTabTable").setModel(craftJSONModel, "mechPosCraftModelData");
								} else if (mechSelIconTab === "Territory") {
									var territoryEmptyArr = [];
									var territoryJSONModel = new JSONModel({
										"results": territoryEmptyArr
									});
									sap.ui.getCore().byId("mechPosTerritoryTabTable").setModel(territoryJSONModel, "mechPosTerritoryModelData");
								}
							}
						} else if (craft === "TCU" || craft === "ATDA") {
							if (that.empDialogFlag === true) {
								that.empDialogFlag = "";
							} else {
								var tcuSelIconTab = sap.ui.getCore().byId("idTcuPosIconTabBar").getSelectedKey();
								if (tcuSelIconTab === "Position ID OR Title") {
									var tcuPosIdDescEmptyArr = [];
									var tcuPosIdDescJSONModel = new JSONModel({
										"results": tcuPosIdDescEmptyArr
									});
									sap.ui.getCore().byId("tcuPosIdOrTitleTabTable").setModel(tcuPosIdDescJSONModel, "tcuPosIdTitleModelData");
								} else if (tcuSelIconTab === "Department") {
									var deptEmptyArr = [];
									var deptJSONModel = new JSONModel({
										"results": deptEmptyArr
									});
									sap.ui.getCore().byId("tcuPosDeptTabTable").setModel(deptJSONModel, "tcuPosDeptModelData");
								}
							}
						} else if (craft === "ILA") {
							if (that.empDialogFlag === true) {
								that.empDialogFlag = "";
							} else {
								var ilaPosIdDescEmptyArr = [];
								var ilaPosIdDescJSONModel = new JSONModel({
									"results": ilaPosIdDescEmptyArr
								});
								sap.ui.getCore().byId("ilaPosIdOrTitleTable").setModel(ilaPosIdDescJSONModel, "ilaPosIdTitleModelData");
							}
						} else if (craft === "Conrail" || craft === "IHB" || craft === "NAHR") {
							if (that.empDialogFlag === true) {
								that.empDialogFlag = "";
							} else {
								var conrailIhbNahrSelIconTab = sap.ui.getCore().byId("idConIhbNahrPosIconTabBar").getSelectedKey();
								if (conrailIhbNahrSelIconTab === "Position ID OR Title") {
									var conrailIhbNahrPosIdDescEmptyArr = [];
									var contrailIhbNahrPosIdDescJSONModel = new JSONModel({
										"results": conrailIhbNahrPosIdDescEmptyArr
									});
									sap.ui.getCore().byId("conIhbNahrPosIdOrTitleTabTable").setModel(contrailIhbNahrPosIdDescJSONModel,
										"conIhbNahrPosIdTitleModelData");
								} else if (conrailIhbNahrSelIconTab === "Union") {
									var conrailIhbNahrUnionEmptyArr = [];
									var conrailIhbNahrJSONModel = new JSONModel({
										"results": conrailIhbNahrUnionEmptyArr
									});
									sap.ui.getCore().byId("conIhbNahrPosUnionTabTable").setModel(conrailIhbNahrJSONModel, "conIhbNahrPosUnionModelData");
								}
							}
						}
					}
				}
			});
		},
		onAddComments: function () {
			var that = this;
			if (!that._commentsDialog) {
				that._commentsDialog = sap.ui.xmlfragment("com.tempforceassignment.Temp_ForceAssignment.fragments.Comments", that.getView()
					.getController());
				that.getView().addDependent(that._commentsDialog);
			}
			that._commentsDialog.open();
			that._commentsDialog.setEscapeHandler(function (o) {
				o.reject();
			});
			var oComment = this.byId("commentsTxt").getText();
			sap.ui.getCore().byId("commentsArea").setValue(oComment);
		},
		onCommentsSubmit: function () {
			var oComment = sap.ui.getCore().byId("commentsArea").getValue();
			this.byId("commentsTxt").setText(oComment);
			sap.ui.getCore().byId("commentsArea").setValue("");
			if (this.byId("commentsTxt").getText() !== "") {
				this.byId("commentsIndicatorIcon").setVisible(true);
				this.byId("commentsBtn").setText("Edit Comments");
				this.changeValFlag = "X";
			} else {
				this.byId("commentsIndicatorIcon").setVisible(false);
				this.byId("commentsBtn").setText("Add Comments");
			}
			this._commentsDialog.close();
		},
		onCommentsCancel: function () {
			var that = this;
			sap.ui.getCore().byId("commentsArea").setValue("");
			that._commentsDialog.close();
		},

		handleIconTabBarSelect: function (oEvent) {
			if (this.byId("deptId").getSelectedKey() === "E" || this.byId("deptId").getSelectedKey() === "SE") {
				sap.ui.getCore().byId("dialoguEngPosIdTitleSearch").setValue("").fireSearch();
				sap.ui.getCore().byId("engUnionDropDown").setSelectedKey("").fireChange();
				sap.ui.getCore().byId("dialoguEngPosSupSearch").setValue("").fireSearch();
				sap.ui.getCore().byId("EngDivDropDown").setSelectedKey("").fireChange();
				sap.ui.getCore().byId("dialoguEngPosCitySearch").setValue("").fireSearch();
				sap.ui.getCore().byId("stateDropDown").setSelectedKey("").fireChange();
				sap.ui.getCore().byId("dialoguEngPosGangIdSearch").setSelectedKey("").fireChange();
				sap.ui.getCore().byId("dialoguEngEmpSearch").setValue("").fireSearch();
			} else
			if (this.byId("deptId").getSelectedKey() === "M" || this.byId("deptId").getSelectedKey() === "SM") {
				sap.ui.getCore().byId("dialoguMechPosIdOrTitleSearch").setValue("").fireSearch();
				sap.ui.getCore().byId("mechUnionDropDown").setSelectedKey("").fireChange();
				sap.ui.getCore().byId("mechAreaDropDown").setSelectedKey("").fireChange();
				sap.ui.getCore().byId("mechCraftDropDown").setSelectedKey("").fireChange();
				sap.ui.getCore().byId("mechTerritoryDropDown").setSelectedKey("").fireChange();
				sap.ui.getCore().byId("dialoguMechEmpSearch").setValue("").fireSearch();
			} else
			if (this.byId("deptId").getSelectedKey() === "T" || this.byId("deptId").getSelectedKey() === "ST" || this.byId("deptId").getSelectedKey() ===
				"D" || this.byId("deptId").getSelectedKey() === "SD") {
				sap.ui.getCore().byId("dialoguTcuPosIdOrTitleSearch").setValue("").fireSearch();
				sap.ui.getCore().byId("dialoguTcuPosDeptSearch").setSelectedKey("").fireChange();
				sap.ui.getCore().byId("dialoguTcuPosDeskSearch").setSelectedKey("").fireChange();
				sap.ui.getCore().byId("dialoguTcuEmpSearch").setValue("").fireSearch();
			} else if (this.byId("deptId").getSelectedKey() === "L" || this.byId("deptId").getSelectedKey() === "SL") {
				sap.ui.getCore().byId("dialoguConIhbNahrPosIdOrTitleSearch").setValue("").fireSearch();
				sap.ui.getCore().byId("conIhbNahrUnionDropDown").setSelectedKey("").fireChange();
			}
			var selTab = oEvent.getParameter("selectedKey");

			if (selTab === "Union") {

				var that = this;
				var oPage;
				var selRb = that.byId("assignmentRb").getSelectedButton().getText();
				var value;
				if (that.craftUnion === "Engineering") {
					value = "E";
					oPage = sap.ui.getCore().byId("EngPosIdDialogue");
				} else if (that.craftUnion === "Mechanical") {
					value = "M";
					oPage = sap.ui.getCore().byId("mechPosIdDialogue");
				} else if (that.craftUnion === "Conrail") {
					value = "C";
					oPage = sap.ui.getCore().byId("conIhbNahrPosIdDialogue");
				} else if (that.craftUnion === "IHB") {
					value = "I";
					oPage = sap.ui.getCore().byId("conIhbNahrPosIdDialogue");
				} else if (that.craftUnion === "NAHR") {
					value = "N";
					oPage = sap.ui.getCore().byId("conIhbNahrPosIdDialogue");
				}
				oPage.setBusy(true);
				oPage.setBusyIndicatorDelay(0);
				var queryFil = [];
				var key = new sap.ui.model.Filter("Key", "EQ", "U");
				var val = new sap.ui.model.Filter("Value", "EQ", value);
				queryFil.push(key);
				queryFil.push(val);
				var unionJsonModel = new sap.ui.model.json.JSONModel();
				var oModel = that.getOwnerComponent().getModel();
				oModel.read("/PosDropDownsSet", {
					filters: queryFil,
					success: function (oData) {
						oPage.setBusy(false);
						unionJsonModel.setData(oData);
						that.getView().setModel(unionJsonModel, "unionJsonModel");
						var oUniqJsonModel = that.getView().getModel("unionJsonModel").getData().results;
						var uniqUnionArr = that.uniqueDropDownValFun(oUniqJsonModel, "Value");
						var oUnionArray = {
							results: uniqUnionArr
						};
						var oUnionModel = new sap.ui.model.json.JSONModel(oUnionArray);
						if (that.craftUnion === "Engineering") {
							var engUnionComboBox = sap.ui.getCore().byId("engUnionDropDown");
							engUnionComboBox.setModel(oUnionModel, "engUnionDropDownModelData");
						} else if (that.craftUnion === "Mechanical") {
							var mechUnionComboBox = sap.ui.getCore().byId("mechUnionDropDown");
							mechUnionComboBox.setModel(oUnionModel, "mechUnionDropDownModelData");
						} else if (that.craftUnion === "Conrail" || that.craftUnion === "IHB" || that.craftUnion === "NAHR") {
							var conIhbNahrUnionComboBox = sap.ui.getCore().byId("conIhbNahrUnionDropDown");
							conIhbNahrUnionComboBox.setModel(oUnionModel, "conIhbNahrUnionDropDownModelData");
						}
					},
					error: function (oResponse) {
						oPage.setBusy(false);
						that.errorMessageFun(oResponse);
					}
				});

			} else if (selTab === "Division") {

			} else if (selTab === "City") {

			} else if (selTab === "State") {

			} else if (selTab === "Gang ID") {

			}
		}
	});
});