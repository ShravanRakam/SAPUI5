sap.ui.define([
	"sap/ui/core/mvc/Controller",
	"sap/ui/model/json/JSONModel",
	"sap/ui/core/routing/History",
	"sap/ui/core/Fragment",
	"sap/m/MessageBox"
], function(Controller, JSONModel, History, Fragment, MessageBox) {
	"use strict";
	return Controller.extend("org.wfpRomaMaintenance.controller.SelectForm", {
		onInit: function() {
			var oRouter = sap.ui.core.UIComponent.getRouterFor(this);
			oRouter.getRoute("SelectForm").attachPatternMatched(this._onpatterntMatched, this);
		},
		_onpatterntMatched: function(oEvent) {
			var that = this;
			var oVisibleModel = new sap.ui.model.json.JSONModel({
				headerText: "",
				fragmentName: "",
				valueHelpTitle: "",
				IssueVacancy: false
			});
			that.getView().setModel(oVisibleModel, "visibleModel");
			var selectModel = new JSONModel(jQuery.sap.getModulePath("org.wfpRomaMaintenance", "/model/selectModel.json"));
			that.getView().setModel(selectModel, "selectModel");
			var path = oEvent.getParameter("arguments").path;
			var PositionId = oEvent.getParameter("arguments").PosId;
			var oModel = that.getView().getModel("visibleModel"),
				fragName;
			if (path === "Issue Vacancy") {
				oModel.setProperty("/headerText", "Issue Vacancy");
				oModel.setProperty("/fragmentName", "IssueVacancy");
				fragName = oModel.getProperty("/fragmentName");
				that.loadFragment(oEvent, fragName);
				that.IssueVacancyData(PositionId);
			} else if (path === "Fill Position") {
				oModel.setProperty("/headerText", "Fill Position");
				oModel.setProperty("/fragmentName", "fillPosition");
				fragName = oModel.getProperty("/fragmentName");
				that.loadFragment(oEvent, fragName);
			} else if (path === "Assign or Change Funding") {
				oModel.setProperty("/headerText", "Assign/Change Funding");
				oModel.setProperty("/fragmentName", "assignChangeFunding");
				fragName = oModel.getProperty("/fragmentName");
				that.loadFragment(oEvent, fragName);
			} else if (path === "Change Position Working Time") {
				oModel.setProperty("/headerText", "Change Position Working Time");
				oModel.setProperty("/fragmentName", "changePositionWorkTime");
				fragName = oModel.getProperty("/fragmentName");
				that.loadFragment(oEvent, fragName);
			} else if (path === "Extend Funding") {
				oModel.setProperty("/headerText", "Extend Funding");
				oModel.setProperty("/fragmentName", "ExtendFunding");
				fragName = oModel.getProperty("/fragmentName");
				that.loadFragment(oEvent, fragName);
			} else if (path === "Upgrade or Downgrade Position") {
				oModel.setProperty("/headerText", "Upgrade/Downgrade Funding");
				oModel.setProperty("/fragmentName", "upgradeDowngradePos");
				fragName = oModel.getProperty("/fragmentName");
				that.loadFragment(oEvent, fragName);
			} else if (path === "Change Position Job or Title") {
				oModel.setProperty("/headerText", "Change Position Job or Title");
				oModel.setProperty("/fragmentName", "changePositionJob");
				fragName = oModel.getProperty("/fragmentName");
				that.loadFragment(oEvent, fragName);
			} else if (path === "Transfer Position to another Org. Unit") {
				oModel.setProperty("/headerText", "Transfer Position to another Org. Unit");
				oModel.setProperty("/fragmentName", "TransferPosToAssign");
				fragName = oModel.getProperty("/fragmentName");
				that.loadFragment(oEvent, fragName);
			} else if (path === "Change Position Type") {
				oModel.setProperty("/headerText", "Change Position Type");
				oModel.setProperty("/fragmentName", "ChangePosType");
				fragName = oModel.getProperty("/fragmentName");
				that.loadFragment(oEvent, fragName);
			} else if (path === "Abolish Position") {
				oModel.setProperty("/headerText", "Abolish Position");
				oModel.setProperty("/fragmentName", "AbolishPosition");
				fragName = oModel.getProperty("/fragmentName");
				that.loadFragment(oEvent, fragName);
			} else if (path === "Transfer Employee") {
				oModel.setProperty("/headerText", "Transfer Employee");
				oModel.setProperty("/fragmentName", "transferEmployee");
				fragName = oModel.getProperty("/fragmentName");
				that.loadFragment(oEvent, fragName);
			} else if (path === "Extend Employee") {
				oModel.setProperty("/headerText", "Extend Employee");
				oModel.setProperty("/fragmentName", "extendEmployee");
				fragName = oModel.getProperty("/fragmentName");
				that.loadFragment(oEvent, fragName);
			} else if (path === "Promotion or Demotion") {
				oModel.setProperty("/headerText", "Promotion/Demotion Employee");
				oModel.setProperty("/fragmentName", "promotionDemotion");
				fragName = oModel.getProperty("/fragmentName");
				that.loadFragment(oEvent, fragName);
			} else if (path === "Change Employee Category") {
				oModel.setProperty("/headerText", "Change Employee Category");
				oModel.setProperty("/fragmentName", "changeEmpCat");
				fragName = oModel.getProperty("/fragmentName");
				that.loadFragment(oEvent, fragName);
			} else if (path === "Change Employee Contract Type") {
				oModel.setProperty("/headerText", "Change Employee Contract Type");
				oModel.setProperty("/fragmentName", "changeEmpConType");
				fragName = oModel.getProperty("/fragmentName");
				that.loadFragment(oEvent, fragName);
			} else if (path === "Extend Temporary Duty") {
				oModel.setProperty("/headerText", "Extend Temporary Duty");
				oModel.setProperty("/fragmentName", "extendTempDuty");
				fragName = oModel.getProperty("/fragmentName");
				that.loadFragment(oEvent, fragName);
			} else if (path === "Special Post Allowance") {
				oModel.setProperty("/headerText", "Special Post Allowance");
				oModel.setProperty("/fragmentName", "specialPostAlwnce");
				fragName = oModel.getProperty("/fragmentName");
				that.loadFragment(oEvent, fragName);
			} else if (path === "Create Org. Unit") {
				oModel.setProperty("/headerText", "Create Org. Unit");
				oModel.setProperty("/fragmentName", "CreateOrgUnit");
				fragName = oModel.getProperty("/fragmentName");
				that.loadFragment(oEvent, fragName);
			} else if (path === "Create Org. Unit Title") {
				oModel.setProperty("/headerText", "Create Org. Unit Title");
				oModel.setProperty("/fragmentName", "CreateOrgUnitTitle");
				fragName = oModel.getProperty("/fragmentName");
				that.loadFragment(oEvent, fragName);
			} else if (path === "Abolish Org. Unit") {
				oModel.setProperty("/headerText", "Abolish Org. Unit");
				oModel.setProperty("/fragmentName", "AbolishOrgUnit");
				fragName = oModel.getProperty("/fragmentName");
				that.loadFragment(oEvent, fragName);
			} else if (path === "Create Position") {
				oModel.setProperty("/headerText", "Create Position");
				oModel.setProperty("/fragmentName", "CreatePosition");
				fragName = oModel.getProperty("/fragmentName");
				that.loadFragment(oEvent, fragName);
			} else if (path === "Transfer Org. Unit") {
				oModel.setProperty("/headerText", "Transfer Org. Unit");
				oModel.setProperty("/fragmentName", "TransferOrgUnit");
				fragName = oModel.getProperty("/fragmentName");
				that.loadFragment(oEvent, fragName);
			}

		},
		loadFragment: function(oEvent, fragmentName) {
			var that = this,
				panel = oEvent.getParameters().view.getContent()[0].getContent()[0];
			panel.removeAllContent();
			Fragment.load({
				name: "org.wfpRomaMaintenance.fragments." + fragmentName,
				controller: that
			}).then(function(oFragment) {
				panel.addContent(oFragment);
			});
		},
		onPressBack: function() {
			var that = this;
			var oHistory, sPreviousHash;
			oHistory = History.getInstance();
			sPreviousHash = oHistory.getPreviousHash();
			if (sPreviousHash !== undefined) {
				window.history.go(-1);
				that.getView().getModel("oModel").setData({
					items: []
				});
			} else {
				this.getOwnerComponent().getRouter().navTo("RomaMaintenance", {}, true /*no history*/ );
			}
		},
		onPressSave: function() {
			var that = this;
			MessageBox.confirm("Are you sure, want to save Form?", {
				title: "Confimation",
				actions: [MessageBox.Action.YES, MessageBox.Action.NO],
				emphasizedAction: MessageBox.Action.YES,
				onClose: function(oAction) {
					if (oAction === "YES") {
						that.onPressBack();
					}
				}
			});
		},
		onPressF4Help: function(oEvent) {
			var that = this,
				oModel = that.getView().getModel("visibleModel"),
				getValueHelp = oEvent.getSource().getName();
			if (getValueHelp === "inpActualDutyStation") {
				oModel.setProperty("/valueHelpTitle", "Actual Duty Station");
			} else if (getValueHelp === "inpOrgUnit") {
				oModel.setProperty("/valueHelpTitle", "Organization Unit");
			} else if (getValueHelp === "inpPosText") {
				oModel.setProperty("/valueHelpTitle", "Position Number");
				var posModel = new JSONModel(jQuery.sap.getModulePath("org.wfpRomaMaintenance", "/model/positionData.json"));
				that.getView().setModel(posModel, "positionModel");

			} else if (getValueHelp === "inpTdyNTE") {
				oModel.setProperty("/valueHelpTitle", "TDY NTE");
			} else if (getValueHelp === "inpWorkSchedule") {
				oModel.setProperty("/valueHelpTitle", "Work Schedule Rule");
			} else if (getValueHelp === "inpApprovePSA") {
				oModel.setProperty("/valueHelpTitle", "Approved PSA Position");
			} else if (getValueHelp === "inpUSG") {
				oModel.setProperty("/valueHelpTitle", "Unique Under Secretary General");
			} else if (getValueHelp === "inpSPAPosText") {
				oModel.setProperty("/valueHelpTitle", "SPA Postion Number/Text");
			}

			if (!that.valueHelpDialog) {
				that.valueHelpDialog = sap.ui.xmlfragment("org.wfpRomaMaintenance.fragments.positionF4Help", that);
				that.getView().addDependent(that.valueHelpDialog);
			}
			that.valueHelpDialog.open();
		},
		onCancelValuehelp: function() {
			var that = this;
			that.valueHelpDialog.close();
			that.valueHelpDialog.destroy();
			that.valueHelpDialog = null;
		},
		onSelectItem: function(oEvent) {
			var that = this,
				oPath = oEvent.getSource().getParent().getContent()[0].getSelectedIndex(),
				selectedRow = that.getView().getModel("positionModel").getProperty("/results/" + oPath);
			var rowModel = new JSONModel(selectedRow);
			that.getView().setModel(rowModel, "oModel");
			that.onCancelValuehelp();
		},
		onChangeProposedAction: function(oEvent) {
			var that = this,
				selectedKey = oEvent.getSource().getSelectedKey(),
				actionReason,
				oModel;
			if (selectedKey === "Reassignment (06)") {
				actionReason = that.getView().getModel("selectModel").getProperty("/actionReasonReassign/");
				oModel = new JSONModel({
					items: actionReason
				});
				that.getView().setModel(oModel, "actionReason");
			} else if (selectedKey === "Temporary Duty(TDY) (22)") {
				actionReason = that.getView().getModel("selectModel").getProperty("/actionReasonTDY");
				oModel = new JSONModel({
					items: actionReason
				});
				that.getView().setModel(oModel, "actionReason");
			} else if (selectedKey === "SPA (18)") {
				actionReason = that.getView().getModel("selectModel").getProperty("/actionReasonSPA");
				oModel = new JSONModel({
					items: actionReason
				});
				that.getView().setModel(oModel, "actionReason");
			} else if (selectedKey === "Change of Category (21)") {
				actionReason = that.getView().getModel("selectModel").getProperty("/actionReasonChangeEmpCat");
				oModel = new JSONModel({
					items: actionReason
				});
				that.getView().setModel(oModel, "actionReason");
			} else if (selectedKey === "Conversion of Contract (04)") {
				actionReason = that.getView().getModel("selectModel").getProperty("/actionReasonChangeEmpConType");
				oModel = new JSONModel({
					items: actionReason
				});
				that.getView().setModel(oModel, "actionReason");
			} else if (selectedKey === "Temporary Duty(TDY)(22)") {
				actionReason = that.getView().getModel("selectModel").getProperty("/actionReasonExtTempDuty");
				oModel = new JSONModel({
					items: actionReason
				});
				that.getView().setModel(oModel, "actionReason");
			} else if (selectedKey === "") {
				oModel = new JSONModel({
					items: []
				});
				that.getView().setModel(oModel, "actionReason");
			}
		},

		IssueVacancyData: function(PositionId) {
			var that = this,
				url = "/sap/opu/odata/sap/ZPCR_POSITION_FORM_SRV/",
				oModel = new sap.ui.model.odata.v2.ODataModel(url, false),
				visible = that.getView().getModel("visibleModel");
			visible.setProperty("/IssueVacancy", true);
			oModel.read("/ZPCR_POSITION_FORMSet(PosId='" + PositionId + "')", {
				success: function(OData) {
					var IssueVacancyModel = new JSONModel(OData);
					that.getView().setModel(IssueVacancyModel, "IssueVacancyModel");
					visible.setProperty("/IssueVacancy", false);
				},
				error: function(error) {
					visible.setProperty("/IssueVacancy", false);
					MessageBox.error(JSON.parse(error.responseText).error.message.value);

				}
			});
		}
	});
});