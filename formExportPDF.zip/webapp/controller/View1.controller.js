/* global jsPDF:true */
/* jsPDF-AutoTable:true */
sap.ui.define([
	"sap/ui/core/mvc/Controller"
], function(Controller) {
	"use strict";

	return Controller.extend("formExportPDF.controller.View1", {
		onInit: function() {
			var omodel = new sap.ui.model.json.JSONModel();
			this.getView().setModel(omodel, "formModel");
		},
		// onDownloadPDF: function() {
		// 	// Extract form data
		// 	// var oView = this.getView();
		// 	var oData = this.getView().getModel("formModel").getData();

		// 	// Initialize jsPDF
		// 	var doc = new jsPDF();

		// 	// Add form data to PDF

		// 	doc.text("NORTHROP GRUMMAN SUPPLIER NO.: " + oData.northGrumman, 10, 10);
		// 	doc.text("CAGE CODE: " + oData.cageCode, 10, 20);
		// 	doc.text("FEDERAL TAX ID NO. or EIN: " + oData.fedralTax, 50, 20);
		// 	doc.text("DUNS NUMBER: " + oData.duneNo, 10, 30);
		// 	doc.text("UNIQUE ENTITY IDENTIFER NO." + oData.uniqueNo, 50, 30);
		// 	doc.text("SUPPLIER NAME" + oData.supName, 10, 40);
		// 	doc.text("SITE MANUFACTURING ADDRESS: " + oData.siteManfAdd, 10, 50);
		// 	doc.text("CITY/PROVINCE: " + oData.city, 10, 60);
		// 	doc.text("STATE: " + oData.state, 50, 60);
		// 	doc.text("ZIP/POSTAL CODE: " + oData.pstCode, 10, 70);
		// 	doc.text("COUNTRY: " + oData.country, 10, 80);
		// 	doc.text("TELEPHONE NUMBER: " + oData.telNo, 10, 90);
		// 	doc.text("FAX NUMBER: " + oData.faxNo, 60, 90);
		// 	doc.text("EMAIL ADDRESS: " + oData.emailAdd, 10, 100);
		// 	doc.text("SUPPLIER POINT OF CONTACT NAME: " + oData.suppContactName, 10, 110);
		// 	doc.text("NORTHROP GRUMMAN BUYER'S NAME(IF KNOWN): " + oData.northGrumanBuyerName, 10, 120);
		// 	doc.text("CONTRCTURAL ADDRESS: " + oData.ContractAdd, 10, 130);
		// 	doc.text("CITY/PROVINCE: " + oData.city1, 10, 140);
		// 	doc.text("STATE: " + oData.state1, 60, 140);
		// 	doc.text("ZIP/POSTAL CODE: " + oData.pstCode1, 10, 150);
		// 	doc.text("COUNTRY: " + oData.country1, 10, 160);

		// 	// Save the PDF
		// 	doc.save("form_data.pdf");
		// },
		onDownloadPDF: function() {
			var jsPDF = window.jspdf;

			// Get the form container element
			var formContainer = this.byId("SimpleFormChange354").getDomRef();

			// Use html2canvas to capture the form container as a canvas
			html2canvas(formContainer).then((canvas) => {
				// Convert the canvas to an image
				var imgData = canvas.toDataURL('image/png');

				// Create a new jsPDF instance
				var pdf = new jsPDF();

				// Add the image to the PDF
				pdf.addImage(imgData, 'PNG', 10, 10, 190, 0); // Adjust the dimensions as needed

				// Save the PDF
				pdf.save('form.pdf');
			});
		}
	});
});