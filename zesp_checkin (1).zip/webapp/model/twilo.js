var $jscomp = {
	scope: {}
};
$jscomp.defineProperty = "function" == typeof Object.defineProperties ? Object.defineProperty : function(b, e, h) {
	if (h.get || h.set) throw new TypeError("ES3 does not support getters and setters.");
	b != Array.prototype && b != Object.prototype && (b[e] = h.value)
};
$jscomp.getGlobal = function(b) {
	return "undefined" != typeof window && window === b ? b : "undefined" != typeof global && null != global ? global : b
};
$jscomp.global = $jscomp.getGlobal(this);
$jscomp.SYMBOL_PREFIX = "jscomp_symbol_";
$jscomp.initSymbol = function() {
	$jscomp.initSymbol = function() {};
	$jscomp.global.Symbol || ($jscomp.global.Symbol = $jscomp.Symbol)
};
$jscomp.symbolCounter_ = 0;
$jscomp.Symbol = function(b) {
	return $jscomp.SYMBOL_PREFIX + (b || "") + $jscomp.symbolCounter_++
};
$jscomp.initSymbolIterator = function() {
	$jscomp.initSymbol();
	var b = $jscomp.global.Symbol.iterator;
	b || (b = $jscomp.global.Symbol.iterator = $jscomp.global.Symbol("iterator"));
	"function" != typeof Array.prototype[b] && $jscomp.defineProperty(Array.prototype, b, {
		configurable: !0,
		writable: !0,
		value: function() {
			return $jscomp.arrayIterator(this)
		}
	});
	$jscomp.initSymbolIterator = function() {}
};
$jscomp.arrayIterator = function(b) {
	var e = 0;
	return $jscomp.iteratorPrototype(function() {
		return e < b.length ? {
			done: !1,
			value: b[e++]
		} : {
			done: !0
		}
	})
};
$jscomp.iteratorPrototype = function(b) {
	$jscomp.initSymbolIterator();
	b = {
		next: b
	};
	b[$jscomp.global.Symbol.iterator] = function() {
		return this
	};
	return b
};
$jscomp.inherits = function(b, e) {
	function h() {}
	h.prototype = e.prototype;
	b.prototype = new h;
	b.prototype.constructor = b;
	for (var a in e)
		if (Object.defineProperties) {
			var k = Object.getOwnPropertyDescriptor(e, a);
			k && Object.defineProperty(b, a, k)
		} else b[a] = e[a]
};
$jscomp.makeIterator = function(b) {
	$jscomp.initSymbolIterator();
	var e = b[Symbol.iterator];
	return e ? e.call(b) : $jscomp.arrayIterator(b)
};
$jscomp.arrayFromIterator = function(b) {
	for (var e, h = []; !(e = b.next()).done;) h.push(e.value);
	return h
};
$jscomp.arrayFromIterable = function(b) {
	return b instanceof Array ? b : $jscomp.arrayFromIterator($jscomp.makeIterator(b))
};
$jscomp.owns = function(b, e) {
	return Object.prototype.hasOwnProperty.call(b, e)
};
$jscomp.polyfill = function(b, e, h, a) {
	if (e) {
		h = $jscomp.global;
		b = b.split(".");
		for (a = 0; a < b.length - 1; a++) {
			var k = b[a];
			k in h || (h[k] = {});
			h = h[k]
		}
		b = b[b.length - 1];
		a = h[b];
		e = e(a);
		e != a && null != e && $jscomp.defineProperty(h, b, {
			configurable: !0,
			writable: !0,
			value: e
		})
	}
};
$jscomp.polyfill("Object.assign", function(b) {
	return b ? b : function(b, h) {
		for (var a = 1; a < arguments.length; a++) {
			var k = arguments[a];
			if (k)
				for (var l in k) $jscomp.owns(k, l) && (b[l] = k[l])
		}
		return b
	}
}, "es6-impl", "es3");
$jscomp.polyfill("WeakMap", function(b) {
	function e(g) {
		$jscomp.owns(g, a) || $jscomp.defineProperty(g, a, {
			value: {}
		})
	}

	function h(a) {
		var c = Object[a];
		c && (Object[a] = function(a) {
			e(a);
			return c(a)
		})
	}
	if (function() {
		if (!b || !Object.seal) return !1;
		try {
			var a = Object.seal({}),
				c = Object.seal({}),
				f = new b([
					[a, 2],
					[c, 3]
				]);
			if (2 != f.get(a) || 3 != f.get(c)) return !1;
			f.delete(a);
			f.set(c, 4);
			return !f.has(a) && 4 == f.get(c)
		} catch (u) {
			return !1
		}
	}()) return b;
	var a = "$jscomp_hidden_" + Math.random().toString().substring(2);
	h("freeze");
	h("preventExtensions");
	h("seal");
	var k = 0,
		l = function(a) {
			this.id_ = (k += Math.random() + 1).toString();
			if (a) {
				$jscomp.initSymbol();
				$jscomp.initSymbolIterator();
				a = $jscomp.makeIterator(a);
				for (var c; !(c = a.next()).done;) c = c.value, this.set(c[0], c[1])
			}
		};
	l.prototype.set = function(g, c) {
		e(g);
		if (!$jscomp.owns(g, a)) throw Error("WeakMap key fail: " + g);
		g[a][this.id_] = c;
		return this
	};
	l.prototype.get = function(g) {
		return $jscomp.owns(g, a) ? g[a][this.id_] : void 0
	};
	l.prototype.has = function(g) {
		return $jscomp.owns(g, a) && $jscomp.owns(g[a], this.id_)
	};
	l.prototype.delete =
		function(g) {
			return $jscomp.owns(g, a) && $jscomp.owns(g[a], this.id_) ? delete g[a][this.id_] : !1
	};
	return l
}, "es6-impl", "es3");
$jscomp.ASSUME_NO_NATIVE_MAP = !1;
$jscomp.polyfill("Map", function(b) {
	if (!$jscomp.ASSUME_NO_NATIVE_MAP && function() {
		if (!b || !b.prototype.entries || "function" != typeof Object.seal) return !1;
		try {
			var a = Object.seal({
					x: 4
				}),
				f = new b($jscomp.makeIterator([
					[a, "s"]
				]));
			if ("s" != f.get(a) || 1 != f.size || f.get({
				x: 4
			}) || f.set({
				x: 4
			}, "t") != f || 2 != f.size) return !1;
			var g = f.entries(),
				p = g.next();
			if (p.done || p.value[0] != a || "s" != p.value[1]) return !1;
			p = g.next();
			return p.done || 4 != p.value[0].x || "t" != p.value[1] || !g.next().done ? !1 : !0
		} catch (q) {
			return !1
		}
	}()) return b;
	$jscomp.initSymbol();
	$jscomp.initSymbolIterator();
	var e = new WeakMap,
		h = function(a) {
			this.data_ = {};
			this.head_ = l();
			this.size = 0;
			if (a) {
				a = $jscomp.makeIterator(a);
				for (var c; !(c = a.next()).done;) c = c.value, this.set(c[0], c[1])
			}
		};
	h.prototype.set = function(c, f) {
		var g = a(this, c);
		g.list || (g.list = this.data_[g.id] = []);
		g.entry ? g.entry.value = f : (g.entry = {
			next: this.head_,
			previous: this.head_.previous,
			head: this.head_,
			key: c,
			value: f
		}, g.list.push(g.entry), this.head_.previous.next = g.entry, this.head_.previous = g.entry, this.size++);
		return this
	};
	h.prototype.delete =
		function(c) {
			c = a(this, c);
			return c.entry && c.list ? (c.list.splice(c.index, 1), c.list.length || delete this.data_[c.id], c.entry.previous.next = c.entry.next,
				c.entry.next.previous = c.entry.previous, c.entry.head = null, this.size--, !0) : !1
	};
	h.prototype.clear = function() {
		this.data_ = {};
		this.head_ = this.head_.previous = l();
		this.size = 0
	};
	h.prototype.has = function(c) {
		return !!a(this, c).entry
	};
	h.prototype.get = function(c) {
		return (c = a(this, c).entry) && c.value
	};
	h.prototype.entries = function() {
		return k(this, function(a) {
			return [a.key,
				a.value
			]
		})
	};
	h.prototype.keys = function() {
		return k(this, function(a) {
			return a.key
		})
	};
	h.prototype.values = function() {
		return k(this, function(a) {
			return a.value
		})
	};
	h.prototype.forEach = function(a, f) {
		for (var c = this.entries(), g; !(g = c.next()).done;) g = g.value, a.call(f, g[1], g[0], this)
	};
	h.prototype[Symbol.iterator] = h.prototype.entries;
	var a = function(a, f) {
			var c;
			c = f && typeof f;
			"object" == c || "function" == c ? e.has(f) ? c = e.get(f) : (c = "" + ++g, e.set(f, c)) : c = "p_" + f;
			var p = a.data_[c];
			if (p && $jscomp.owns(a.data_, c))
				for (a = 0; a < p.length; a++) {
					var l =
						p[a];
					if (f !== f && l.key !== l.key || f === l.key) return {
						id: c,
						list: p,
						index: a,
						entry: l
					}
				}
			return {
				id: c,
				list: p,
				index: -1,
				entry: void 0
			}
		},
		k = function(a, f) {
			var c = a.head_;
			return $jscomp.iteratorPrototype(function() {
				if (c) {
					for (; c.head != a.head_;) c = c.previous;
					for (; c.next != c.head;) return c = c.next, {
						done: !1,
						value: f(c)
					};
					c = null
				}
				return {
					done: !0,
					value: void 0
				}
			})
		},
		l = function() {
			var a = {};
			return a.previous = a.next = a.head = a
		},
		g = 0;
	return h
}, "es6-impl", "es3");
$jscomp.EXPOSE_ASYNC_EXECUTOR = !0;
$jscomp.FORCE_POLYFILL_PROMISE = !1;
$jscomp.polyfill("Promise", function(b) {
	function e() {
		this.batch_ = null
	}
	if (b && !$jscomp.FORCE_POLYFILL_PROMISE) return b;
	e.prototype.asyncExecute = function(a) {
		null == this.batch_ && (this.batch_ = [], this.asyncExecuteBatch_());
		this.batch_.push(a);
		return this
	};
	e.prototype.asyncExecuteBatch_ = function() {
		var a = this;
		this.asyncExecuteFunction(function() {
			a.executeBatch_()
		})
	};
	var h = $jscomp.global.setTimeout;
	e.prototype.asyncExecuteFunction = function(a) {
		h(a, 0)
	};
	e.prototype.executeBatch_ = function() {
		for (; this.batch_ && this.batch_.length;) {
			var a =
				this.batch_;
			this.batch_ = [];
			for (var g = 0; g < a.length; ++g) {
				var c = a[g];
				delete a[g];
				try {
					c()
				} catch (f) {
					this.asyncThrow_(f)
				}
			}
		}
		this.batch_ = null
	};
	e.prototype.asyncThrow_ = function(a) {
		this.asyncExecuteFunction(function() {
			throw a;
		})
	};
	var a = function(a) {
		this.state_ = 0;
		this.result_ = void 0;
		this.onSettledCallbacks_ = [];
		var g = this.createResolveAndReject_();
		try {
			a(g.resolve, g.reject)
		} catch (c) {
			g.reject(c)
		}
	};
	a.prototype.createResolveAndReject_ = function() {
		function a(a) {
			return function(f) {
				c || (c = !0, a.call(g, f))
			}
		}
		var g = this,
			c = !1;
		return {
			resolve: a(this.resolveTo_),
			reject: a(this.reject_)
		}
	};
	a.prototype.resolveTo_ = function(b) {
		if (b === this) this.reject_(new TypeError("A Promise cannot resolve to itself"));
		else if (b instanceof a) this.settleSameAsPromise_(b);
		else {
			var g;
			a: switch (typeof b) {
				case "object":
					g = null != b;
					break a;
				case "function":
					g = !0;
					break a;
				default:
					g = !1
			}
			g ? this.resolveToNonPromiseObj_(b) : this.fulfill_(b)
		}
	};
	a.prototype.resolveToNonPromiseObj_ = function(a) {
		var g = void 0;
		try {
			g = a.then
		} catch (c) {
			this.reject_(c);
			return
		}
		"function" ==
			typeof g ? this.settleSameAsThenable_(g, a) : this.fulfill_(a)
	};
	a.prototype.reject_ = function(a) {
		this.settle_(2, a)
	};
	a.prototype.fulfill_ = function(a) {
		this.settle_(1, a)
	};
	a.prototype.settle_ = function(a, g) {
		if (0 != this.state_) throw Error("Cannot settle(" + a + ", " + g | "): Promise already settled in state" + this.state_);
		this.state_ = a;
		this.result_ = g;
		this.executeOnSettledCallbacks_()
	};
	a.prototype.executeOnSettledCallbacks_ = function() {
		if (null != this.onSettledCallbacks_) {
			for (var a = this.onSettledCallbacks_, g = 0; g < a.length; ++g) a[g].call(),
				a[g] = null;
			this.onSettledCallbacks_ = null
		}
	};
	var k = new e;
	a.prototype.settleSameAsPromise_ = function(a) {
		var g = this.createResolveAndReject_();
		a.callWhenSettled_(g.resolve, g.reject)
	};
	a.prototype.settleSameAsThenable_ = function(a, g) {
		var c = this.createResolveAndReject_();
		try {
			a.call(g, c.resolve, c.reject)
		} catch (f) {
			c.reject(f)
		}
	};
	a.prototype.then = function(b, g) {
		function c(a, c) {
			return "function" == typeof a ? function(d) {
				try {
					f(a(d))
				} catch (m) {
					l(m)
				}
			} : c
		}
		var f, l, p = new a(function(a, c) {
			f = a;
			l = c
		});
		this.callWhenSettled_(c(b, f),
			c(g, l));
		return p
	};
	a.prototype.catch = function(a) {
		return this.then(void 0, a)
	};
	a.prototype.callWhenSettled_ = function(a, g) {
		function c() {
			switch (f.state_) {
				case 1:
					a(f.result_);
					break;
				case 2:
					g(f.result_);
					break;
				default:
					throw Error("Unexpected state: " + f.state_);
			}
		}
		var f = this;
		null == this.onSettledCallbacks_ ? k.asyncExecute(c) : this.onSettledCallbacks_.push(function() {
			k.asyncExecute(c)
		})
	};
	a.resolve = function(b) {
		return b instanceof a ? b : new a(function(a, c) {
			a(b)
		})
	};
	a.reject = function(b) {
		return new a(function(a, c) {
			c(b)
		})
	};
	a.race = function(b) {
		return new a(function(g, c) {
			for (var f = $jscomp.makeIterator(b), k = f.next(); !k.done; k = f.next()) a.resolve(k.value).callWhenSettled_(g, c)
		})
	};
	a.all = function(b) {
		var g = $jscomp.makeIterator(b),
			c = g.next();
		return c.done ? a.resolve([]) : new a(function(f, b) {
			function p(a) {
				return function(d) {
					q[a] = d;
					k--;
					0 == k && f(q)
				}
			}
			var q = [],
				k = 0;
			do q.push(void 0), k++, a.resolve(c.value).callWhenSettled_(p(q.length - 1), b), c = g.next(); while (!c.done)
		})
	};
	$jscomp.EXPOSE_ASYNC_EXECUTOR && (a.$jscomp$new$AsyncExecutor = function() {
		return new e
	});
	return a
}, "es6-impl", "es3");
$jscomp.array = $jscomp.array || {};
$jscomp.iteratorFromArray = function(b, e) {
	$jscomp.initSymbolIterator();
	b instanceof String && (b += "");
	var h = 0,
		a = {
			next: function() {
				if (h < b.length) {
					var k = h++;
					return {
						value: e(k, b[k]),
						done: !1
					}
				}
				a.next = function() {
					return {
						done: !0,
						value: void 0
					}
				};
				return a.next()
			}
		};
	a[Symbol.iterator] = function() {
		return a
	};
	return a
};
$jscomp.polyfill("Array.prototype.keys", function(b) {
	return b ? b : function() {
		return $jscomp.iteratorFromArray(this, function(b) {
			return b
		})
	}
}, "es6-impl", "es3");
$jscomp.polyfill("Array.from", function(b) {
	return b ? b : function(b, h, a) {
		$jscomp.initSymbolIterator();
		h = null != h ? h : function(a) {
			return a
		};
		var k = [],
			l = b[Symbol.iterator];
		if ("function" == typeof l)
			for (b = l.call(b); !(l = b.next()).done;) k.push(h.call(a, l.value));
		else
			for (var l = b.length, g = 0; g < l; g++) k.push(h.call(a, b[g]));
		return k
	}
}, "es6-impl", "es3");
$jscomp.polyfill("Array.prototype.values", function(b) {
	return b ? b : function() {
		return $jscomp.iteratorFromArray(this, function(b, h) {
			return h
		})
	}
}, "es6", "es3");
$jscomp.polyfill("Array.prototype.entries", function(b) {
	return b ? b : function() {
		return $jscomp.iteratorFromArray(this, function(b, h) {
			return [b, h]
		})
	}
}, "es6-impl", "es3");
$jscomp.checkStringArgs = function(b, e, h) {
	if (null == b) throw new TypeError("The 'this' value for String.prototype." + h + " must not be null or undefined");
	if (e instanceof RegExp) throw new TypeError("First argument to String.prototype." + h + " must not be a regular expression");
	return b + ""
};
$jscomp.polyfill("String.prototype.repeat", function(b) {
	return b ? b : function(b) {
		var h = $jscomp.checkStringArgs(this, null, "repeat");
		if (0 > b || 1342177279 < b) throw new RangeError("Invalid count value");
		b |= 0;
		for (var a = ""; b;)
			if (b & 1 && (a += h), b >>>= 1) h += h;
		return a
	}
}, "es6-impl", "es3");
$jscomp.ASSUME_NO_NATIVE_SET = !1;
$jscomp.polyfill("Set", function(b) {
	if (!$jscomp.ASSUME_NO_NATIVE_SET && function() {
		if (!b || !b.prototype.entries || "function" != typeof Object.seal) return !1;
		try {
			var h = Object.seal({
					x: 4
				}),
				a = new b($jscomp.makeIterator([h]));
			if (!a.has(h) || 1 != a.size || a.add(h) != a || 1 != a.size || a.add({
				x: 4
			}) != a || 2 != a.size) return !1;
			var k = a.entries(),
				l = k.next();
			if (l.done || l.value[0] != h || l.value[1] != h) return !1;
			l = k.next();
			return l.done || l.value[0] == h || 4 != l.value[0].x || l.value[1] != l.value[0] ? !1 : k.next().done
		} catch (g) {
			return !1
		}
	}()) return b;
	$jscomp.initSymbol();
	$jscomp.initSymbolIterator();
	var e = function(b) {
		this.map_ = new Map;
		if (b) {
			b = $jscomp.makeIterator(b);
			for (var a; !(a = b.next()).done;) this.add(a.value)
		}
		this.size = this.map_.size
	};
	e.prototype.add = function(b) {
		this.map_.set(b, b);
		this.size = this.map_.size;
		return this
	};
	e.prototype.delete = function(b) {
		b = this.map_.delete(b);
		this.size = this.map_.size;
		return b
	};
	e.prototype.clear = function() {
		this.map_.clear();
		this.size = 0
	};
	e.prototype.has = function(b) {
		return this.map_.has(b)
	};
	e.prototype.entries = function() {
		return this.map_.entries()
	};
	e.prototype.values = function() {
		return this.map_.values()
	};
	e.prototype.keys = e.prototype.values;
	e.prototype[Symbol.iterator] = e.prototype.values;
	e.prototype.forEach = function(b, a) {
		var k = this;
		this.map_.forEach(function(l) {
			return b.call(a, l, l, k)
		})
	};
	return e
}, "es6-impl", "es3");
$jscomp.findInternal = function(b, e, h) {
	b instanceof String && (b = String(b));
	for (var a = b.length, k = 0; k < a; k++) {
		var l = b[k];
		if (e.call(h, l, k, b)) return {
			i: k,
			v: l
		}
	}
	return {
		i: -1,
		v: void 0
	}
};
$jscomp.polyfill("Array.prototype.find", function(b) {
	return b ? b : function(b, h) {
		return $jscomp.findInternal(this, b, h).v
	}
}, "es6-impl", "es3");
(function e$jscomp$0(e, h, a) {
	function k(c, f) {
		if (!h[c]) {
			if (!e[c]) {
				var g = "function" == typeof require && require;
				if (!f && g) return g(c, !0);
				if (l) return l(c, !0);
				f = Error("Cannot find module '" + c + "'");
				throw f.code = "MODULE_NOT_FOUND", f;
			}
			f = h[c] = {
				exports: {}
			};
			e[c][0].call(f.exports, function(a) {
				var f = e[c][1][a];
				return k(f ? f : a)
			}, f, f.exports, e$jscomp$0, e, h, a)
		}
		return h[c].exports
	}
	for (var l = "function" == typeof require && require, g = 0; g < a.length; g++) k(a[g]);
	return k
})({
	1: [
		function(b, e, h) {
			(function(a) {
				var k = a.Twilio || function() {};
				Object.assign(k, b("./twilio"));
				a.Twilio = k
			})("undefined" !== typeof window ? window : global)
		}, {
			"./twilio": 2
		}
	],
	2: [
		function(b, e, h) {
			h.Device = b("./twilio/device").Device;
			h.PStream = b("./twilio/pstream").PStream;
			h.Connection = b("./twilio/connection").Connection
		}, {
			"./twilio/connection": 4,
			"./twilio/device": 5,
			"./twilio/pstream": 11
		}
	],
	3: [
		function(b, e, h) {
			function a(c, f, b, r) {
				if (!(this instanceof a)) return new a(c, f, b, r);
				d.call(this);
				r = Object.assign({
					AudioContext: "undefined" !== typeof AudioContext && AudioContext,
					mediaDevices: n,
					setSinkId: "undefined" !== typeof HTMLAudioElement && HTMLAudioElement.prototype.setSinkId
				}, r);
				m.mixinLog(this, "[AudioHelper]");
				this.log.enabled = r.logEnabled;
				this.log.warnings = r.logWarnings;
				var p = new Map,
					q = new Map,
					B = r.mediaDevices,
					t = B && B.enumerateDevices || !1,
					u = "function" === typeof r.setSinkId,
					h = t && u,
					F = !(!r.AudioContext && !r.audioContext);
				r.soundOptions && l(this, r.soundOptions);
				var w = u = null;
				F && (u = r.audioContext || new r.AudioContext, w = u.createAnalyser(), w.fftSize = 32, w.smoothingTimeConstant = .3);
				var e = this;
				Object.defineProperties(this, {
					_audioContext: {
						value: u
					},
					_getUserMedia: {
						value: b
					},
					_inputDevice: {
						value: null,
						writable: !0
					},
					_inputStream: {
						value: null,
						writable: !0
					},
					_inputVolumeAnalyser: {
						value: w
					},
					_isPollingInputVolume: {
						value: !1,
						writable: !0
					},
					_onActiveInputChanged: {
						value: f
					},
					_mediaDevices: {
						value: B
					},
					_unknownDeviceIndexes: {
						value: {}
					},
					_updateAvailableDevices: {
						value: g.bind(null, this)
					},
					availableInputDevices: {
						enumerable: !0,
						value: p
					},
					availableOutputDevices: {
						enumerable: !0,
						value: q
					},
					inputDevice: {
						enumerable: !0,
						get: function() {
							return e._inputDevice
						}
					},
					inputStream: {
						enumerable: !0,
						get: function() {
							return e._inputStream
						}
					},
					isVolumeSupported: {
						enumerable: !0,
						value: F
					},
					isOutputSelectionSupported: {
						enumerable: !0,
						value: h
					},
					ringtoneDevices: {
						enumerable: !0,
						value: new v("ringtone", q, c, h)
					},
					speakerDevices: {
						enumerable: !0,
						value: new v("speaker", q, c, h)
					}
				});
				this.on("newListener", function(a) {
					"inputVolume" === a && e._maybeStartPollingVolume()
				});
				this.on("removeListener", function(a) {
					"inputVolume" === a && e._maybeStopPollingVolume()
				});
				this.once("newListener", function() {
					h || console.warn("Warning: This browser does not support audio output selection.");
					F || console.warn("Warning: This browser does not support Twilio's volume indicator feature.")
				});
				t && k(this)
			}

			function k(a) {
				a._mediaDevices.addEventListener("devicechange", a._updateAvailableDevices);
				a._mediaDevices.addEventListener("deviceinfochange", a._updateAvailableDevices);
				g(a).then(function() {
					a.isOutputSelectionSupported && Promise.all([a.speakerDevices.set("default"), a.ringtoneDevices.set("default")]).catch(function(d) {
						a.log.warn("Warning: Unable to set audio output devices. " + d)
					})
				})
			}

			function l(a,
				d) {
				function n(a, d) {
					"undefined" !== typeof d && (c[a] = d);
					return c[a]
				}
				var c = d.__dict__;
				c && Object.keys(c).forEach(function(d) {
					a[d] = n.bind(null, d)
				})
			}

			function g(a) {
				return a._mediaDevices.enumerateDevices().then(function(d) {
					q(a, u(d, "audiooutput"), a.availableOutputDevices, c);
					q(a, u(d, "audioinput"), a.availableInputDevices, f);
					var n = a.availableOutputDevices.get("default") || Array.from(a.availableOutputDevices.values())[0];
					[a.speakerDevices, a.ringtoneDevices].forEach(function(d) {
						!d.get().size && a.availableOutputDevices.size &&
							d.set(n.deviceId)
					})
				})
			}

			function c(a, d) {
				return a.speakerDevices._delete(d) | a.ringtoneDevices._delete(d)
			}

			function f(a, d) {
				if (!a.inputDevice || a.inputDevice.deviceId !== d.deviceId) return !1;
				t(a, null);
				a._inputDevice = null;
				a._maybeStopPollingVolume();
				(d = a.availableInputDevices.get("default") || Array.from(a.availableInputDevices.values())[0]) && a.setInputDevice(d.deviceId);
				return !0
			}

			function u(a, d) {
				return a.filter(function(a) {
					return a.kind === d
				})
			}

			function p(a) {
				return a.deviceId
			}

			function q(a, d, n, c) {
				var m = d.map(p),
					f = Array.from(n.values()).map(p),
					b = [],
					m = w.difference(f, m);
				m.forEach(function(d) {
					var m = n.get(d);
					n.delete(d);
					c(a, m) && b.push(m)
				});
				var g = !1;
				d.forEach(function(d) {
					var c = n.get(d.deviceId),
						m;
					m = {
						deviceId: d.deviceId,
						groupId: d.groupId,
						kind: d.kind,
						label: d.label
					};
					if (!m.label)
						if ("default" === m.deviceId) m.label = "Default";
						else {
							var f = d.deviceId,
								b = d.kind,
								v = a._unknownDeviceIndexes;
							v[b] || (v[b] = {});
							var p = v[b][f];
							p || (p = Object.keys(v[b]).length + 1, v[b][f] = p);
							m.label = "Unknown " + B[m.kind] + " Device " + p
						}
					m = new r(m);
					c && c.label ===
						m.label || (n.set(d.deviceId, m), g = !0)
				});
				if (g || m.length) null !== a.inputDevice && "default" === a.inputDevice.deviceId && (a.log.warn(
					"Calling getUserMedia after device change to ensure that the tracks of the active device (default) have not gone stale."), a._setInputDevice(
					a._inputDevice.deviceId, !0)), a.emit("deviceChange", b)
			}

			function t(a, d) {
				a._inputStream && a._inputStream.getTracks().forEach(function(a) {
					a.stop()
				});
				a._inputStream = d
			}
			var d = b("events").EventEmitter;
			h = b("util").inherits;
			var m = b("./log"),
				r = b("./shims/mediadeviceinfo"),
				n = b("./shims/mediadevices"),
				v = b("./outputdevicecollection"),
				w = b("./util");
			h(a, d);
			a.prototype._maybeStartPollingVolume = function() {
				if (this.isVolumeSupported && this._inputStream && (this._inputVolumeSource && (this._inputVolumeSource.disconnect(), this._inputVolumeSource =
					null), this._inputVolumeSource = this._audioContext.createMediaStreamSource(this._inputStream), this._inputVolumeSource.connect(
					this._inputVolumeAnalyser), !this._isPollingInputVolume)) {
					var a = new Uint8Array(this._inputVolumeAnalyser.frequencyBinCount),
						d = this;
					this._isPollingInputVolume = !0;
					requestAnimationFrame(function A() {
						if (d._isPollingInputVolume) {
							d._inputVolumeAnalyser.getByteFrequencyData(a);
							var n = w.average(a);
							d.emit("inputVolume", n / 255);
							requestAnimationFrame(A)
						}
					})
				}
			};
			a.prototype._maybeStopPollingVolume = function() {
				!this.isVolumeSupported || !this._isPollingInputVolume || this._inputStream && this.listenerCount("inputVolume") || (this._inputVolumeSource &&
					(this._inputVolumeSource.disconnect(), this._inputVolumeSource = null), this._isPollingInputVolume = !1)
			};
			a.prototype.setInputDevice = function(a) {
				return w.isFirefox() ? Promise.reject(Error(
					"Firefox does not currently support opening multiple audio input tracks simultaneously, even across different tabs. As a result, Device.audio.setInputDevice is disabled on Firefox until support is added.\nRelated BugZilla thread: https://bugzilla.mozilla.org/show_bug.cgi?id=1299324"
				)) : this._setInputDevice(a, !1)
			};
			a.prototype._setInputDevice = function(a, d) {
				if ("string" !== typeof a) return Promise.reject(Error("Must specify the device to set"));
				var n = this.availableInputDevices.get(a);
				if (!n) return Promise.reject(Error("Device not found: " + a));
				if (this._inputDevice && this._inputDevice.deviceId === a && this._inputStream) {
					if (!d) return Promise.resolve();
					this._inputStream.getTracks().forEach(function(a) {
						a.stop()
					})
				}
				var m = this;
				return this._getUserMedia({
					audio: {
						deviceId: {
							exact: a
						}
					}
				}).then(function(a) {
					return m._onActiveInputChanged(a).then(function() {
						t(m, a);
						m._inputDevice = n;
						m._maybeStartPollingVolume()
					})
				})
			};
			a.prototype.unsetInputDevice = function() {
				if (!this.inputDevice) return Promise.resolve();
				var a = this;
				return this._onActiveInputChanged(null).then(function() {
					t(a, null);
					a._inputDevice = null;
					a._maybeStopPollingVolume()
				})
			};
			a.prototype._unbind = function() {
				this._mediaDevices.removeEventListener("devicechange", this._updateAvailableDevices);
				this._mediaDevices.removeEventListener("deviceinfochange", this._updateAvailableDevices)
			};
			var B = {
				audiooutput: "Audio Output",
				audioinput: "Audio Input"
			};
			e.exports = a
		}, {
			"./log": 8,
			"./outputdevicecollection": 10,
			"./shims/mediadeviceinfo": 22,
			"./shims/mediadevices": 23,
			"./util": 27,
			events: 34,
			util: 49
		}
	],
	4: [
		function(b, e, h) {
			function a(m, b, n, v) {
				function r() {}

				function p() {
					var a = {
						call_sid: e.parameters.CallSid,
						client_name: m._clientName,
						sdk_version: u.getReleaseVersion(),
						selected_region: m.options.region
					};
					m.stream && (m.stream.gateway && (a.gateway = m.stream.gateway), m.stream.region && (a.region = m.stream.region));
					a.direction = e._direction;
					return a
				}

				function q() {
					0 !== y.length && x.postMetrics("quality-metrics-samples", "metrics-sample", y.splice(0), p())
				}

				function l(a) {
					var d = {
						threshold: a.threshold.value
					};
					a.values ? d.values = a.values.map(function(a) {
						return "number" === typeof a ? Math.round(100 * a) / 100 : a
					}) : a.value && (d.value = a.value);
					return {
						data: d
					}
				}

				function h(a, n) {
					var m = (/^audio/.test(n.name) ? "audio-level-" : "network-quality-") + "warning" + (a ? "-cleared" : "-raised"),
						c = d[n.threshold.name] + t[n.name];
					if ("constant-audio-input-level" !== c || !e.isMuted()) {
						var f = a ? "info" : "warning";
						"constant-audio-output-level" === c && (f = "info");
						x.post(f, m, c, l(n), e);
						"constant-audio-output-level" !== c && e.emit(a ? "warning-cleared" : "warning", c)
					}
				}
				if (!(this instanceof a)) return new a(m, b, n, v);
				var e = this;
				u.monitorEventEmitter("Twilio.Connection", this);
				this._soundcache = m.soundcache;
				this.message = b || {};
				v = this.options = Object.assign({
					audioConstraints: m.options.audioConstraints,
					callParameters: {},
					debug: !1,
					encrypt: !1,
					iceServers: m.options.iceServers,
					logPrefix: "[Connection]",
					MediaStream: v.mediaStreamFactory || m.options.MediaStream || m.options.mediaStreamFactory || c.PeerConnection,
					offerSdp: null,
					rtcConstraints: m.options.rtcConstraints
				}, v);
				this.parameters =
					v.callParameters;
				this._status = "pending";
				this._isAnswered = !1;
				this._direction = this.parameters.CallSid ? "INCOMING" : "OUTGOING";
				this.sendHangup = !0;
				g.mixinLog(this, this.options.logPrefix);
				this.log.enabled = this.options.debug;
				this.log.warnings = this.options.warnings;
				this._onHangup = this._onCancel = r;
				var x = this._publisher = v.publisher;
				"INCOMING" === this._direction && x.info("connection", "incoming", null, this);
				var C = this._monitor = new f;
				C.disableWarnings();
				var y = [],
					D = 0;
				C.on("sample", function(a) {
					20 > D ? D++ : 20 === D && C.enableWarnings();
					a.inputVolume = e._latestInputVolume;
					a.outputVolume = e._latestOutputVolume;
					y.push(a);
					10 <= y.length && q()
				});
				C.on("warning-cleared", h.bind(null, !0));
				C.on("warning", h.bind(null, !1));
				this.mediaStream = new this.options.MediaStream(m, n);
				this.on("volume", function(a, d) {
					e._latestInputVolume = a;
					e._latestOutputVolume = d
				});
				this.mediaStream.onvolume = this.emit.bind(this, "volume");
				this.mediaStream.oniceconnectionstatechange = function(a) {
					x.post("failed" === a ? "error" : "debug", "ice-connection-state", a, null, e)
				};
				this.mediaStream.onicegatheringstatechange =
					function(a) {
						x.debug("signaling-state", a, null, e)
				};
				this.mediaStream.onsignalingstatechange = function(a) {
					x.debug("signaling-state", a, null, e)
				};
				this.mediaStream.ondisconnect = function(a) {
					e.log(a);
					x.warn("network-quality-warning-raised", "ice-connectivity-lost", {
						message: a
					}, e);
					e.emit("warning", "ice-connectivity-lost")
				};
				this.mediaStream.onreconnect = function(a) {
					e.log(a);
					x.info("network-quality-warning-cleared", "ice-connectivity-lost", {
						message: a
					}, e);
					e.emit("warning-cleared", "ice-connectivity-lost")
				};
				this.mediaStream.onerror =
					function(a) {
						!0 === a.disconnect && e._disconnect(a.info && a.info.message);
						var d = {
							code: a.info.code,
							message: a.info.message || "Error with mediastream",
							info: a.info,
							connection: e
						};
						e.log("Received an error from MediaStream:", a);
						e.emit("error", d)
				};
				this.mediaStream.onopen = function() {
					"open" !== e._status && ("ringing" === e._status || "connecting" === e._status ? (e.mute(!1), e._maybeTransitionToOpen()) : e.mediaStream
						.close())
				};
				this.mediaStream.onclose = function() {
					e._status = "closed";
					m.sounds.__dict__.disconnect && m.soundcache.get("disconnect").play();
					C.disable();
					q();
					e.emit("disconnect", e)
				};
				this.outboundConnectionId = u.generateConnectionUUID();
				this.pstream = m.stream;
				this._onCancel = function(a) {
					e.parameters.CallSid === a.callsid && (e._status = "closed", e.emit("cancel"), e.pstream.removeListener("cancel", e._onCancel))
				};
				this.pstream && (this.pstream.on("cancel", this._onCancel), this.pstream.on("ringing", this._onRinging.bind(this)));
				this.on("error", function(a) {
					x.error("connection", "error", {
						code: a.code,
						message: a.message
					}, e);
					e.pstream && "disconnected" === e.pstream.status &&
						k(e)
				});
				this.on("disconnect", function() {
					k(e)
				});
				return this
			}

			function k(a) {
				function d() {
					a.pstream && (a.pstream.removeListener("cancel", a._onCancel), a.pstream.removeListener("hangup", a._onHangup))
				}
				d();
				setTimeout(d, 0)
			}
			e = b("events").EventEmitter;
			var l = b("./util").Exception,
				g = b("./log"),
				c = b("./rtc"),
				f = b("./rtc/monitor"),
				u = b("./util"),
				p = [1, 2, 3, 4, 5],
				q = "one-way-audio choppy-audio dropped-call audio-latency noisy-call echo".split(" "),
				t = {
					audioOutputLevel: "audio-output-level",
					audioInputLevel: "audio-input-level",
					packetsLostFraction: "packet-loss",
					jitter: "jitter",
					rtt: "rtt",
					mos: "mos"
				},
				d = {
					min: "low-",
					max: "high-",
					maxDuration: "constant-"
				};
			b("util").inherits(a, e);
			a.toString = function() {
				return "[Twilio.Connection class]"
			};
			a.prototype.toString = function() {
				return "[Twilio.Connection instance]"
			};
			a.prototype.sendDigits = function(a) {
				function d(a) {
					if (a.length) {
						var n = a.shift();
						n.length && c.insertDTMF(n, 160, 70);
						setTimeout(d.bind(null, a), 500)
					}
				}
				if (a.match(/[^0-9*#w]/)) throw new l("Illegal character passed into sendDigits");
				var n = [];
				a.split("").forEach(function(a) {
					a = "w" !== a ? "dtmf" + a : "";
					"dtmf*" === a && (a = "dtmfs");
					"dtmf#" === a && (a = "dtmfh");
					n.push(a)
				});
				(function B(a) {
					var d = n.shift();
					a.get(d).play();
					n.length && setTimeout(B.bind(null, a), 200)
				})(this._soundcache);
				var c = this.mediaStream.getOrCreateDTMFSender();
				if (c) {
					if (!("canInsertDTMF" in c) || c.canInsertDTMF) {
						this.log("Sending digits using RTCDTMFSender");
						d(a.split("w"));
						return
					}
					this.log("RTCDTMFSender cannot insert DTMF")
				}
				this.log("Sending digits over PStream");
				null !== this.pstream && "disconnected" !==
					this.pstream.status ? (a = {
						dtmf: a,
						callsid: this.parameters.CallSid
					}, this.pstream.publish("dtmf", a)) : (a = {
						error: {}
					}, this.emit("error", {
						code: a.error.code || 31E3,
						message: a.error.message || "Could not send DTMF: Signaling channel is disconnected",
						connection: this
					}))
			};
			a.prototype.status = function() {
				return this._status
			};
			a.prototype.mute = function(a) {
				if ("undefined" === typeof a) a = !0, this.log.deprecated(
					".mute() is deprecated. Please use .mute(true) or .mute(false) to mute or unmute a call instead.");
				else if ("function" ===
					typeof a) {
					this.addListener("mute", a);
					return
				}
				this.isMuted() !== a && (this.mediaStream.mute(a), a = this.isMuted(), this._publisher.info("connection", a ? "muted" : "unmuted",
					null, this), this.emit("mute", a, this))
			};
			a.prototype.isMuted = function() {
				return this.mediaStream.isMuted
			};
			a.prototype.unmute = function() {
				this.log.deprecated(".unmute() is deprecated. Please use .mute(false) to unmute a call instead.");
				this.mute(!1)
			};
			a.prototype.accept = function(a) {
				function d() {
					function a(a) {
						c._publisher.info("connection", "accepted-by-local",
							null, c);
						c._monitor.enable(a)
					}

					function d(a) {
						c._publisher.info("connection", "accepted-by-remote", null, c);
						c._monitor.enable(a)
					}
					if ("connecting" !== c._status) k(c), c.mediaStream.close();
					else {
						var n = [],
							m;
						for (m in c.message) n.push(encodeURIComponent(m) + "=" + encodeURIComponent(c.message[m]));
						m = "function" === typeof c.options.getSinkIds && c.options.getSinkIds();
						Array.isArray(m) && c.mediaStream._setSinkIds(m).catch(function() {});
						n = n.join("&");
						"INCOMING" === c._direction ? (c._isAnswered = !0, c.mediaStream.answerIncomingCall(c.parameters.CallSid,
							c.options.offerSdp, c.options.rtcConstraints, c.options.iceServers, a)) : (c.pstream.once("answer", c._onAnswer.bind(c)), c.mediaStream
							.makeOutgoingCall(c.pstream.token, n, c.outboundConnectionId, c.options.rtcConstraints, c.options.iceServers, d));
						c._onHangup = function(a) {
							if (a.callsid && (c.parameters.CallSid || c.outboundConnectionId)) {
								if (a.callsid !== c.parameters.CallSid && a.callsid !== c.outboundConnectionId) return
							} else if (a.callsid) return;
							c.log("Received HANGUP from gateway");
							a.error && (a = {
								code: a.error.code || 31E3,
								message: a.error.message || "Error sent from gateway in HANGUP",
								connection: c
							}, c.log("Received an error from the gateway:", a), c.emit("error", a));
							c.sendHangup = !1;
							c._publisher.info("connection", "disconnected-by-remote", null, c);
							c._disconnect(null, !0);
							k(c)
						};
						c.pstream.addListener("hangup", c._onHangup)
					}
				}
				if ("function" === typeof a) this.addListener("accept", a);
				else if ("pending" === this._status) {
					var n = a || this.options.audioConstraints,
						c = this;
					this._status = "connecting";
					a = "function" === typeof this.options.getInputStream &&
						this.options.getInputStream();
					(a ? this.mediaStream.setInputTracksFromStream(a) : this.mediaStream.openWithConstraints(n)).then(function() {
							c._publisher.info("get-user-media", "succeeded", {
								data: {
									audioConstraints: n
								}
							}, c);
							d()
						}, function(a) {
							var d, m;
							a.code && a.code === a.PERMISSION_DENIED || a.name && "PermissionDeniedError" === a.name ? (m = 31208, d =
								"User denied access to microphone, or the web browser did not allow microphone access at this address.", c._publisher.error(
									"get-user-media", "denied", {
										data: {
											audioConstraints: n,
											error: a
										}
									}, c)) : (m = 31201, d = "Error occurred while accessing microphone: " + a.name + (a.message ? " (" + a.message + ")" : ""), c._publisher
								.error("get-user-media", "failed", {
									data: {
										audioConstraints: n,
										error: a
									}
								}, c));
							return c._die(d, m)
						})
				}
			};
			a.prototype.reject = function(a) {
				"function" === typeof a ? this.addListener("reject", a) : "pending" === this._status && (this.pstream.publish("reject", {
					callsid: this.parameters.CallSid
				}), this.emit("reject"), this.mediaStream.reject(this.parameters.CallSid), this._publisher.info("connection", "rejected-by-local",
					null, this))
			};
			a.prototype.ignore = function(a) {
				"function" === typeof a ? this.addListener("cancel", a) : "pending" === this._status && (this._status = "closed", this.emit("cancel"),
					this.mediaStream.ignore(this.parameters.CallSid), this._publisher.info("connection", "ignored-by-local", null, this))
			};
			a.prototype.cancel = function(a) {
				this.log.deprecated(".cancel() is deprecated. Please use .ignore() instead.");
				this.ignore(a)
			};
			a.prototype.disconnect = function(a) {
				"function" === typeof a ? this.addListener("disconnect", a) : this._disconnect()
			};
			a.prototype._disconnect = function(a, d) {
				a = "string" === typeof a ? a : null;
				if ("open" === this._status || "connecting" === this._status || "ringing" === this._status) {
					this.log("Disconnecting...");
					if (null !== this.pstream && "disconnected" !== this.pstream.status && this.sendHangup) {
						var c = this.parameters.CallSid || this.outboundConnectionId;
						c && (c = {
							callsid: c
						}, a && (c.message = a), this.pstream.publish("hangup", c))
					}
					k(this);
					this.mediaStream.close();
					d || this._publisher.info("connection", "disconnected-by-local", null, this)
				}
			};
			a.prototype.error =
				function(a) {
					"function" === typeof a && this.addListener("error", a)
			};
			a.prototype._die = function(a, d) {
				this._disconnect();
				this.emit("error", {
					message: a,
					code: d
				})
			};
			a.prototype._setCallSid = function(a) {
				if (a = a.callsid) this.parameters.CallSid = a, this.mediaStream.callSid = a
			};
			a.prototype._setSinkIds = function(a) {
				return this.mediaStream._setSinkIds(a)
			};
			a.prototype._setInputTracksFromStream = function(a) {
				return this.mediaStream.setInputTracksFromStream(a)
			};
			a.prototype._onRinging = function(a) {
				this._setCallSid(a);
				if ("connecting" ===
					this._status || "ringing" === this._status) {
					var d = !!a.sdp;
					this.options.enableRingingState ? (this._status = "ringing", this._publisher.info("connection", "outgoing-ringing", {
						hasEarlyMedia: d
					}, this), this.emit("ringing", d)) : d && this._onAnswer(a)
				}
			};
			a.prototype._onAnswer = function(a) {
				this._isAnswered || (this._setCallSid(a), this._isAnswered = !0, this._maybeTransitionToOpen())
			};
			a.prototype._maybeTransitionToOpen = function() {
				this.mediaStream && "open" === this.mediaStream.status && this._isAnswered && (this._status = "open", this.emit("accept",
					this))
			};
			a.prototype.volume = function(a) {
				if (!window || !window.AudioContext && !window.webkitAudioContext) console.warn("This browser does not support Connection.volume");
				else if ("function" === typeof a) this.on("volume", a)
			};
			a.prototype.getLocalStream = function() {
				return this.mediaStream && this.mediaStream.stream
			};
			a.prototype.getRemoteStream = function() {
				return this.mediaStream && this.mediaStream._remoteStream
			};
			a.prototype.postFeedback = function(a, d) {
				if ("undefined" === typeof a || null === a) return this._postFeedbackDeclined();
				if (-1 === p.indexOf(a)) throw Error("Feedback score must be one of: " + p);
				if ("undefined" !== typeof d && null !== d && -1 === q.indexOf(d)) throw Error("Feedback issue must be one of: " + q);
				return this._publisher.post("info", "feedback", "received", {
					quality_score: a,
					issue_name: d
				}, this, !0)
			};
			a.prototype._postFeedbackDeclined = function() {
				return this._publisher.post("info", "feedback", "received-none", null, this, !0)
			};
			a.prototype._getTempCallSid = function() {
				return this.outboundConnectionId
			};
			a.prototype._getRealCallSid = function() {
				return /^TJ/.test(this.parameters.CallSid) ?
					null : this.parameters.CallSid
			};
			h.Connection = a
		}, {
			"./log": 8,
			"./rtc": 14,
			"./rtc/monitor": 16,
			"./util": 27,
			events: 34,
			util: 49
		}
	],
	5: [
		function(b, e, h) {
			function a(n, b) {
				function g(a) {
					a = a.forEach ? a : [a];
					Array.from(z.soundcache.entries()).forEach(function(d) {
						"incoming" !== d[0] && d[1].setSinkIds(a)
					});
					z._connectionSinkIds = a;
					var d = z._activeConnection;
					return d ? d._setSinkIds(a) : Promise.resolve()
				}

				function v(a) {
					return Promise.resolve(z.soundcache.get("incoming").setSinkIds(a))
				}

				function k(a) {
					if (z._activeConnection) {
						var d = !0 ===
							I ? "A call is currently in-progress. Leaving or reloading this page will end the call." : I;
						return (a || window.event).returnValue = d
					}
				}

				function h() {
					z.disconnectAll()
				}
				if (!u.enabled()) throw new f.Exception(
					"twilio.js 1.3 requires WebRTC/ORTC browser support. For more information, see <https://www.twilio.com/docs/api/client/twilio-js>. If you have any questions about this announcement, please contact Twilio Support at <help@twilio.com>."
				);
				if (!(this instanceof a)) return new a(n, b);
				f.monitorEventEmitter("Twilio.Device",
					this);
				if (!n) throw new f.Exception("Capability token is not valid or missing.");
				b = b || {};
				for (var e in b);
				var A = {
					logPrefix: "[Device]",
					chunderw: "chunderw-vpc-gll.twilio.com",
					eventgw: "eventgw.twilio.com",
					Sound: b.soundFactory || t,
					connectionFactory: d,
					pStreamFactory: r,
					noRegister: !1,
					encrypt: !1,
					closeProtection: !1,
					secureSignaling: !0,
					warnings: !0,
					audioConstraints: !0,
					iceServers: [],
					region: "gll",
					dscp: !0,
					sounds: {}
				};
				b = b || {};
				e = b.chunderw;
				for (var x in A) x in b || (b[x] = A[x]);
				b.rtcConstraints = b.dscp ? {
					optional: [{
						googDscp: !0
					}]
				} : {};
				this.options = b;
				this.token = n;
				this._region = this._status = "offline";
				this._connectionSinkIds = ["default"];
				this._connectionInputStream = null;
				this.connections = [];
				this._activeConnection = null;
				this.sounds = new q({
					incoming: !0,
					outgoing: !0,
					disconnect: !0
				});
				c.mixinLog(this, this.options.logPrefix);
				this.log.enabled = this.options.debug;
				n = {
					gll: "chunderw-vpc-gll.twilio.com",
					au1: "chunderw-vpc-gll-au1.twilio.com",
					br1: "chunderw-vpc-gll-br1.twilio.com",
					de1: "chunderw-vpc-gll-de1.twilio.com",
					ie1: "chunderw-vpc-gll-ie1.twilio.com",
					jp1: "chunderw-vpc-gll-jp1.twilio.com",
					sg1: "chunderw-vpc-gll-sg1.twilio.com",
					us1: "chunderw-vpc-gll-us1.twilio.com",
					"us1-tnx": "chunderw-vpc-gll-us1-tnx.twilio.com",
					"us2-tnx": "chunderw-vpc-gll-us2-tnx.twilio.com",
					"ie1-tnx": "chunderw-vpc-gll-ie1-tnx.twilio.com",
					"us1-ix": "chunderw-vpc-gll-us1-ix.twilio.com",
					"us2-ix": "chunderw-vpc-gll-us2-ix.twilio.com",
					"ie1-ix": "chunderw-vpc-gll-ie1-ix.twilio.com"
				};
				x = {
					au: "au1",
					br: "br1",
					ie: "ie1",
					jp: "jp1",
					sg: "sg1",
					"us-va": "us1",
					"us-or": "us1"
				};
				A = b.region.toLowerCase();
				A in
					x && (this.log.deprecated("Region " + A + " is deprecated, please use " + x[A] + "."), A = x[A]);
				if (!(A in n)) throw new f.Exception("Region " + b.region + " is invalid. Valid values are: " + Object.keys(n).join(", "));
				b.chunderw = e || n[A];
				this.soundcache = new Map;
				e = "undefined" !== typeof document ? document.createElement("audio") : {};
				var C;
				try {
					C = e.canPlayType && !!e.canPlayType("audio/mpeg").replace(/no/, "")
				} catch (J) {
					C = !1
				}
				var y;
				try {
					y = e.canPlayType && !!e.canPlayType("audio/ogg;codecs='vorbis'").replace(/no/, "")
				} catch (J) {
					y = !1
				}
				e =
					"mp3";
				y && !C && (e = "ogg");
				C = {
					incoming: {
						filename: "incoming",
						shouldLoop: !0
					},
					outgoing: {
						filename: "outgoing",
						maxDuration: 3E3
					},
					disconnect: {
						filename: "disconnect",
						maxDuration: 3E3
					},
					dtmf1: {
						filename: "dtmf-1",
						maxDuration: 1E3
					},
					dtmf2: {
						filename: "dtmf-2",
						maxDuration: 1E3
					},
					dtmf3: {
						filename: "dtmf-3",
						maxDuration: 1E3
					},
					dtmf4: {
						filename: "dtmf-4",
						maxDuration: 1E3
					},
					dtmf5: {
						filename: "dtmf-5",
						maxDuration: 1E3
					},
					dtmf6: {
						filename: "dtmf-6",
						maxDuration: 1E3
					},
					dtmf7: {
						filename: "dtmf-7",
						maxDuration: 1E3
					},
					dtmf8: {
						filename: "dtmf-8",
						maxDuration: 1E3
					},
					dtmf9: {
						filename: "dtmf-9",
						maxDuration: 1E3
					},
					dtmf0: {
						filename: "dtmf-0",
						maxDuration: 1E3
					},
					dtmfs: {
						filename: "dtmf-star",
						maxDuration: 1E3
					},
					dtmfh: {
						filename: "dtmf-hash",
						maxDuration: 1E3
					}
				};
				y = f.getTwilioRoot() + "sounds/releases/" + f.getSoundVersion() + "/";
				for (var D in C) n = C[D], x = y + n.filename + "." + e + "?cache=1_4_23", n = new this.options.Sound(D, b.sounds[D] || x, {
					maxDuration: n.maxDuration,
					minDuration: n.minDuration,
					shouldLoop: n.shouldLoop,
					audioContext: this.options.disableAudioContextSounds ? null : a.audioContext
				}), this.soundcache.set(D,
					n);
				var z = this,
					E = this._publisher = new p("twilio-js-sdk", this.token, {
						host: this.options.eventgw,
						defaultPayload: function(a) {
							var d = {
								client_name: z._clientName,
								platform: u.getMediaEngine(),
								sdk_version: f.getReleaseVersion(),
								selected_region: z.options.region
							};
							if (a) {
								var c = a._getRealCallSid();
								c && (d.call_sid = c);
								(c = a._getTempCallSid()) && (d.temp_call_sid = c);
								d.direction = a._direction
							}
							if (a = z.stream)(c = a.gateway) && (d.gateway = c), (a = a.region) && (d.region = a);
							return d
						}
					});
				!1 === b.publishEvents && E.disable();
				(this.audio = new l(function(a,
					d) {
					return ("ringtone" === a ? v(d) : g(d)).then(function() {
						E.info("audio", a + "-devices-set", {
							audio_device_ids: d
						}, z._activeConnection)
					}, function(c) {
						E.error("audio", a + "-devices-set-failed", {
							audio_device_ids: d,
							message: c.message
						}, z._activeConnection);
						throw c;
					})
				}, function(a) {
					var d = z._activeConnection;
					if (d && !a) return Promise.reject(Error("Cannot unset input device while a call is in progress."));
					z._connectionInputStream = a;
					return d ? d._setInputTracksFromStream(a) : Promise.resolve()
				}, m, {
					audioContext: a.audioContext,
					logEnabled: !!this.options.debug,
					logWarnings: !!this.options.warnings,
					soundOptions: this.sounds
				})).on("deviceChange", function(a) {
					var d = z._activeConnection;
					a = a.map(function(a) {
						return a.deviceId
					});
					E.info("audio", "device-change", {
						lost_active_device_ids: a
					}, d);
					d && d.mediaStream._onInputDevicesChanged()
				});
				this.mediaPresence = {
					audio: !this.options.noRegister
				};
				this.register(this.token);
				var I = this.options.closeProtection;
				I && "undefined" !== typeof window && (window.addEventListener ? window.addEventListener("beforeunload",
					k) : window.attachEvent && window.attachEvent("onbeforeunload", k));
				"undefined" !== typeof window && (window.addEventListener ? window.addEventListener("unload", h) : window.attachEvent && window.attachEvent(
					"onunload", h));
				this.on("error", function() {});
				return this
			}

			function k(a, d, c) {
				var n = {
					getSinkIds: function() {
						return a._connectionSinkIds
					},
					getInputStream: function() {
						return a._connectionInputStream
					},
					debug: a.options.debug,
					encrypt: a.options.encrypt,
					warnings: a.options.warnings,
					publisher: a._publisher,
					enableRingingState: a.options.enableRingingState
				};
				c = c || {};
				for (var b in n) b in c || (c[b] = n[b]);
				var f = a.options.connectionFactory(a, d, m, c);
				f.once("accept", function() {
					a._activeConnection = f;
					a._removeConnection(f);
					a.audio._maybeStartPollingVolume();
					a.emit("connect", f)
				});
				f.addListener("error", function(d) {
					"closed" === f.status() && a._removeConnection(f);
					a.audio._maybeStopPollingVolume();
					a.emit("error", d)
				});
				f.once("cancel", function() {
					a.log("Canceled: " + f.parameters.CallSid);
					a._removeConnection(f);
					a.audio._maybeStopPollingVolume();
					a.emit("cancel", f)
				});
				f.once("disconnect",
					function() {
						a.audio._maybeStopPollingVolume();
						a._removeConnection(f);
						a._activeConnection === f && (a._activeConnection = null);
						a.emit("disconnect", f)
					});
				f.once("reject", function() {
					a.log("Rejected: " + f.parameters.CallSid);
					a.audio._maybeStopPollingVolume();
					a._removeConnection(f)
				});
				return f
			}
			var l = b("./audiohelper");
			e = b("events").EventEmitter;
			var g = b("util"),
				c = b("./log"),
				f = b("./util"),
				u = b("./rtc"),
				p = b("./eventpublisher"),
				q = b("./options").Options,
				t = b("./sound"),
				d = b("./connection").Connection,
				m = b("./rtc/getusermedia"),
				r = b("./pstream").PStream;
			g.inherits(a, e);
			a.toString = function() {
				return "[Twilio.Device class]"
			};
			a.prototype.toString = function() {
				return "[Twilio.Device instance]"
			};
			a.prototype.register = function(a) {
				var d = f.objectize(a);
				this._accountSid = d.iss;
				this._clientName = d.scope["client:incoming"] ? d.scope["client:incoming"].params.clientName : null;
				this.stream ? (this.stream.setToken(a), this._publisher.setToken(a)) : this._setupStream(a)
			};
			a.prototype.registerPresence = function() {
				this.token && (f.objectize(this.token).scope["client:incoming"] &&
					(this.mediaPresence.audio = !0), this._sendPresence())
			};
			a.prototype.unregisterPresence = function() {
				this.mediaPresence.audio = !1;
				this._sendPresence()
			};
			a.prototype.connect = function(a, d) {
				if ("function" === typeof a) return this.addListener("connect", a);
				if (this._activeConnection) throw Error("A Connection is already active");
				a = a || {};
				d = d || this.options.audioConstraints;
				a = this._activeConnection = k(this, a);
				this.connections.splice(0).forEach(function(a) {
					a.ignore()
				});
				this.soundcache.get("incoming").stop();
				if (this.sounds.__dict__.outgoing) {
					var c =
						this;
					a.accept(function() {
						c.soundcache.get("outgoing").play()
					})
				}
				a.accept(d);
				return a
			};
			a.prototype.disconnectAll = function() {
				for (var a = [].concat(this.connections), d = 0; d < a.length; d++) a[d].disconnect();
				this._activeConnection && this._activeConnection.disconnect();
				0 < this.connections.length && this.log("Connections left pending: " + this.connections.length)
			};
			a.prototype.destroy = function() {
				this._stopRegistrationTimer();
				this.audio._unbind();
				this.stream && (this.stream.destroy(), this.stream = null)
			};
			a.prototype.disconnect =
				function(a) {
					this.addListener("disconnect", a)
			};
			a.prototype.incoming = function(a) {
				this.addListener("incoming", a)
			};
			a.prototype.offline = function(a) {
				this.addListener("offline", a)
			};
			a.prototype.ready = function(a) {
				this.addListener("ready", a)
			};
			a.prototype.error = function(a) {
				this.addListener("error", a)
			};
			a.prototype.status = function() {
				return this._activeConnection ? "busy" : this._status
			};
			a.prototype.activeConnection = function() {
				return this._activeConnection || this.connections[0]
			};
			a.prototype.region = function() {
				return this._region
			};
			a.prototype._sendPresence = function() {
				this.stream && (this.stream.register(this.mediaPresence), this.mediaPresence.audio ? this._startRegistrationTimer() : this._stopRegistrationTimer())
			};
			a.prototype._startRegistrationTimer = function() {
				clearTimeout(this.regTimer);
				var a = this;
				this.regTimer = setTimeout(function() {
					a._sendPresence()
				}, 3E4)
			};
			a.prototype._stopRegistrationTimer = function() {
				clearTimeout(this.regTimer)
			};
			a.prototype._setupStream = function(a) {
				var d = this;
				this.log("Setting up PStream");
				this.stream = this.options.pStreamFactory(a, {
					chunderw: this.options.chunderw,
					debug: this.options.debug,
					secureSignaling: this.options.secureSignaling
				});
				this.stream.addListener("connected", function(a) {
					d._region = {
						US_EAST_VIRGINIA: "us1",
						US_WEST_OREGON: "us2",
						ASIAPAC_SYDNEY: "au1",
						SOUTH_AMERICA_SAO_PAULO: "br1",
						EU_IRELAND: "ie1",
						ASIAPAC_TOKYO: "jp1",
						ASIAPAC_SINGAPORE: "sg1"
					}[a.region] || a.region;
					d._sendPresence()
				});
				this.stream.addListener("close", function() {
					d.stream = null
				});
				this.stream.addListener("ready", function() {
					d.log("Stream is ready");
					"offline" === d._status &&
						(d._status = "ready");
					d.emit("ready", d)
				});
				this.stream.addListener("offline", function() {
					d.log("Stream is offline");
					d._status = "offline";
					d._region = "offline";
					d.emit("offline", d)
				});
				this.stream.addListener("error", function(a) {
					var c = a.error;
					c && (a.callsid && (c.connection = d._findConnection(a.callsid)), 31205 === c.code && d._stopRegistrationTimer(), d.log(
						"Received error: ", c), d.emit("error", c))
				});
				this.stream.addListener("invite", function(a) {
					function c() {
						d.connections.length || d.soundcache.get("incoming").stop()
					}
					if (d._activeConnection) d.log("Device busy; ignoring incoming invite");
					else if (a.callsid && a.sdp) {
						var f = a.parameters || {};
						f.CallSid = f.CallSid || a.callsid;
						var b = k(d, {}, {
							offerSdp: a.sdp,
							callParameters: f
						});
						d.connections.push(b);
						b.once("accept", function() {
							d.soundcache.get("incoming").stop()
						});
						["cancel", "error", "reject"].forEach(function(a) {
							b.once(a, c)
						});
						d._showIncomingConnection(b, d.sounds.__dict__.incoming ? function() {
							return d.soundcache.get("incoming").play()
						} : function() {
							return Promise.resolve()
						})
					} else d.emit("error", {
						message: "Malformed invite from gateway"
					})
				})
			};
			a.prototype._showIncomingConnection =
				function(a, d) {
					var c = this,
						b;
					return Promise.race([d(), new Promise(function(a, d) {
						b = setTimeout(function() {
							d(Error("Playing incoming ringtone took too long; it might not play. Continuing execution..."))
						}, 2E3)
					})]).catch(function(a) {
						console.warn(a.message)
					}).then(function() {
						clearTimeout(b);
						c.emit("incoming", a)
					})
			};
			a.prototype._removeConnection = function(a) {
				for (var d = this.connections.length - 1; 0 <= d; d--) a === this.connections[d] && this.connections.splice(d, 1)
			};
			a.prototype._findConnection = function(a) {
				for (var d = 0; d <
					this.connections.length; d++) {
					var c = this.connections[d];
					if (c.parameters.CallSid === a || c.outboundConnectionId === a) return c
				}
				return null
			};
			h.Device = function(d) {
				function c(a) {
					d.instance ? a() : m.push(a)
				}

				function b(a) {
					a = (a.code ? a.code + ": " : "") + a.message;
					if (d.instance) {
						for (var c = 0, g = d.instance.listeners("error"), m = 0; m < g.length; m++) g[m] !== b && c++;
						if (1 < c) return;
						d.instance.log(a)
					}
					throw new f.Exception(a);
				}
				var g = [],
					m = [],
					n = {
						instance: null,
						setup: function(c, f) {
							d.audioContext || ("undefined" !== typeof AudioContext ? d.audioContext =
								new AudioContext : "undefined" !== typeof webkitAudioContext && (d.audioContext = new webkitAudioContext));
							var n;
							if (d.instance) d.instance.log("Found existing Device; using new token but ignoring options"), d.instance.token = c, d.instance.register(
								c);
							else {
								d.instance = new a(c, f);
								d.error(b);
								d.sounds = d.instance.sounds;
								for (n = 0; n < m.length; n++) m[n]();
								m = []
							}
							for (n = 0; n < g.length; n++) g[n](c, f);
							g = [];
							return d
						},
						connect: function(a, b) {
							if ("function" === typeof a) return c(function() {
								d.instance.addListener("connect", a)
							}), null;
							if (!d.instance) throw new f.Exception("Run Twilio.Device.setup()");
							return 0 < d.instance.connections.length ? (d.instance.emit("error", {
								message: "A connection is currently active"
							}), null) : d.instance.connect(a, b)
						},
						disconnectAll: function() {
							c(function() {
								d.instance.disconnectAll()
							});
							return d
						},
						disconnect: function(a) {
							c(function() {
								d.instance.addListener("disconnect", a)
							});
							return d
						},
						status: function() {
							if (!d.instance) throw new f.Exception("Run Twilio.Device.setup()");
							return d.instance.status()
						},
						region: function() {
							if (!d.instance) throw new f.Exception("Run Twilio.Device.setup()");
							return d.instance.region()
						},
						ready: function(a) {
							c(function() {
								d.instance.addListener("ready", a)
							});
							return d
						},
						error: function(a) {
							c(function() {
								a !== b && d.instance.removeListener("error", b);
								d.instance.addListener("error", a)
							});
							return d
						},
						offline: function(a) {
							c(function() {
								d.instance.addListener("offline", a)
							});
							return d
						},
						incoming: function(a) {
							c(function() {
								d.instance.addListener("incoming", a)
							});
							return d
						},
						destroy: function() {
							d.instance && d.instance.destroy();
							return d
						},
						cancel: function(a) {
							c(function() {
								d.instance.addListener("cancel",
									a)
							});
							return d
						},
						activeConnection: function() {
							return d.instance ? d.instance.activeConnection() : null
						}
					},
					r;
				for (r in n) d[r] = n[r];
				Object.defineProperties(d, {
					audio: {
						get: function() {
							return d.instance.audio
						}
					}
				});
				return d
			}(a)
		}, {
			"./audiohelper": 3,
			"./connection": 4,
			"./eventpublisher": 6,
			"./log": 8,
			"./options": 9,
			"./pstream": 11,
			"./rtc": 14,
			"./rtc/getusermedia": 13,
			"./sound": 24,
			"./util": 27,
			events: 34,
			util: 49
		}
	],
	6: [
		function(b, e, h) {
			function a(b, c, f) {
				if (!(this instanceof a)) return new a(b, c, f);
				f = Object.assign({
					defaultPayload: function() {
						return {}
					},
					host: "eventgw.twilio.com"
				}, f);
				var g = f.defaultPayload;
				"function" !== typeof g && (g = function() {
					return Object.assign({}, f.defaultPayload)
				});
				var p = !0;
				Object.defineProperties(this, {
					_defaultPayload: {
						value: g
					},
					_isEnabled: {
						get: function() {
							return p
						},
						set: function(a) {
							p = a
						}
					},
					_host: {
						value: f.host
					},
					_request: {
						value: f.request || l
					},
					_token: {
						value: c,
						writable: !0
					},
					isEnabled: {
						enumerable: !0,
						get: function() {
							return p
						}
					},
					productName: {
						enumerable: !0,
						value: b
					},
					token: {
						enumerable: !0,
						get: function() {
							return this._token
						}
					}
				})
			}

			function k(a) {
				return {
					timestamp: (new Date(a.timestamp)).toISOString(),
					total_packets_received: a.totals.packetsReceived,
					total_packets_lost: a.totals.packetsLost,
					total_packets_sent: a.totals.packetsSent,
					total_bytes_received: a.totals.bytesReceived,
					total_bytes_sent: a.totals.bytesSent,
					packets_received: a.packetsReceived,
					packets_lost: a.packetsLost,
					packets_lost_fraction: a.packetsLostFraction && Math.round(100 * a.packetsLostFraction) / 100,
					audio_level_in: a.audioInputLevel,
					audio_level_out: a.audioOutputLevel,
					call_volume_input: a.inputVolume,
					call_volume_output: a.outputVolume,
					jitter: a.jitter,
					rtt: a.rtt,
					mos: a.mos && Math.round(100 * a.mos) / 100
				}
			}
			var l = b("./request");
			a.prototype._post = function(a, c, b, k, p, q, l) {
				if (!this.isEnabled && !l) return Promise.resolve();
				c = {
					publisher: this.productName,
					group: b,
					name: k,
					timestamp: (new Date).toISOString(),
					level: c.toUpperCase(),
					payload_type: "application/json",
					private: !1,
					payload: p && p.forEach ? p.slice(0) : Object.assign(this._defaultPayload(q), p)
				};
				var d = {
						url: "https://" + this._host + "/v2/" + a,
						body: c,
						headers: {
							"Content-Type": "application/json",
							"X-Twilio-Token": this.token
						}
					},
					f =
					this;
				return new Promise(function(a, c) {
					f._request.post(d, function(d) {
						d ? c(d) : a()
					})
				})
			};
			a.prototype.post = function(a, c, b, k, p, q) {
				return this._post("EndpointEvents", a, c, b, k, p, q)
			};
			a.prototype.debug = function(a, c, b, k) {
				return this.post("debug", a, c, b, k)
			};
			a.prototype.info = function(a, c, b, k) {
				return this.post("info", a, c, b, k)
			};
			a.prototype.warn = function(a, c, b, k) {
				return this.post("warning", a, c, b, k)
			};
			a.prototype.error = function(a, c, b, k) {
				return this.post("error", a, c, b, k)
			};
			a.prototype.postMetrics = function(a, c, b, l) {
				b = b.map(k).map(function(a) {
					return Object.assign(a,
						l)
				});
				return this._post("EndpointMetrics", "info", a, c, b)
			};
			a.prototype.setToken = function(a) {
				this._token = a
			};
			a.prototype.enable = function() {
				this._isEnabled = !0
			};
			a.prototype.disable = function() {
				this._isEnabled = !1
			};
			e.exports = a
		}, {
			"./request": 12
		}
	],
	7: [
		function(b, e, h) {
			function a(b) {
				function k() {}
				if (!(this instanceof a)) return new a(b);
				b = b || {};
				var g = {
						interval: 10,
						now: function() {
							return (new Date).getTime()
						},
						repeat: function(a, c) {
							return setInterval(a, c)
						},
						stop: function(a, c) {
							return clearInterval(a, c)
						},
						onsleep: k,
						onwakeup: k
					},
					c;
				for (c in g) c in b || (b[c] = g[c]);
				this.interval = b.interval;
				this.lastbeat = 0;
				this.pintvl = null;
				this.onsleep = b.onsleep;
				this.onwakeup = b.onwakeup;
				this.repeat = b.repeat;
				this.stop = b.stop;
				this.now = b.now
			}
			a.toString = function() {
				return "[Twilio.Heartbeat class]"
			};
			a.prototype.toString = function() {
				return "[Twilio.Heartbeat instance]"
			};
			a.prototype.beat = function() {
				this.lastbeat = this.now();
				if (this.sleeping()) {
					if (this.onwakeup) this.onwakeup();
					var a = this;
					this.pintvl = this.repeat.call(null, function() {
						a.check()
					}, 1E3 * this.interval)
				}
			};
			a.prototype.check = function() {
				var a = this.now() - this.lastbeat;
				if (!this.sleeping() && a >= 1E3 * this.interval) {
					if (this.onsleep) this.onsleep();
					this.stop.call(null, this.pintvl);
					this.pintvl = null
				}
			};
			a.prototype.sleeping = function() {
				return null === this.pintvl
			};
			h.Heartbeat = a
		}, {}
	],
	8: [
		function(b, e, h) {
			h.mixinLog = function(a, b) {
				function k() {
					if (k.enabled)
						for (var a = k.prefix ? k.prefix + " " : "", b = 0; b < arguments.length; b++) {
							var g = arguments[b];
							k.handler("string" === typeof g ? a + g : g)
						}
				}

				function g() {
					if (k.warnings)
						for (var a = 0; a < arguments.length; a++) k.warnHandler(arguments[a])
				}
				k.enabled = !0;
				k.prefix = b || "";
				k.defaultHandler = function(a) {
					"undefined" !== typeof console && console.log(a)
				};
				k.handler = k.defaultHandler;
				k.warnings = !0;
				k.defaultWarnHandler = function(a) {
					"undefined" !== typeof console && ("function" === typeof console.warn ? console.warn(a) : "function" === typeof console.log &&
						console.log(a))
				};
				k.warnHandler = k.defaultWarnHandler;
				k.deprecated = g;
				k.warn = g;
				a.log = k
			}
		}, {}
	],
	9: [
		function(b, e, h) {
			var a = b("./log"),
				k = b("./strings").SOUNDS_DEPRECATION_WARNING;
			h.Options = function() {
				function b(g, c) {
					function f(a,
						c, d) {
						return function(b, f) {
							f || l || (l = !0, d.deprecated(k));
							"undefined" !== typeof b && (a[c] = b);
							return a[c]
						}
					}
					if (!(this instanceof b)) return new b(g);
					this.__dict__ = {};
					g = g || {};
					c = c || {};
					a.mixinLog(this, "[Sounds]");
					var l = !1,
						p;
					for (p in g) this[p] = f(this.__dict__, p, this.log), this[p](g[p], !0);
					for (p in c) this[p](c[p], !0)
				}
				return b
			}()
		}, {
			"./log": 8,
			"./strings": 26
		}
	],
	10: [
		function(b, e, h) {
			function a(a, b, c, f) {
				Object.defineProperties(this, {
					_activeDevices: {
						value: new Set
					},
					_availableDevices: {
						value: b
					},
					_beforeChange: {
						value: c
					},
					_isSupported: {
						value: f
					},
					_name: {
						value: a
					}
				})
			}
			b = b("./util");
			var k = b.getTwilioRoot() + "sounds/releases/" + b.getSoundVersion() + "/outgoing.mp3";
			a.prototype._delete = function(a) {
				a = this._activeDevices.delete(a);
				var b = this._availableDevices.get("default") || Array.from(this._availableDevices.values())[0];
				!this._activeDevices.size && b && this._activeDevices.add(b);
				b = Array.from(this._activeDevices).map(function(a) {
					return a.deviceId
				});
				this._beforeChange(this._name, b);
				return a
			};
			a.prototype.get = function() {
				return this._activeDevices
			};
			a.prototype.set =
				function(a) {
					if (!this._isSupported) return Promise.reject(Error("This browser does not support audio output selection"));
					a = Array.isArray(a) ? a : [a];
					if (!a.length) return Promise.reject(Error("Must specify at least one device to set"));
					var b = [],
						c = a.map(function(a) {
							var c = this._availableDevices.get(a);
							c || b.push(a);
							return c
						}, this);
					if (b.length) return Promise.reject(Error("Devices not found: " + b.join(", ")));
					var f = this;
					return (new Promise(function(c) {
						c(f._beforeChange(f._name, a))
					})).then(function() {
						f._activeDevices.clear();
						c.forEach(f._activeDevices.add, f._activeDevices)
					})
			};
			a.prototype.test = function(a) {
				if (!this._isSupported) return Promise.reject(Error("This browser does not support audio output selection"));
				a = a || k;
				return this._activeDevices.size ? Promise.all(Array.from(this._activeDevices).map(function(b) {
					var c = new Audio([a]);
					return c.setSinkId(b.deviceId).then(function() {
						return c.play()
					})
				})) : Promise.reject(Error("No active output devices to test"))
			};
			e.exports = a
		}, {
			"./util": 27
		}
	],
	11: [
		function(b, e, h) {
			function a(b, k) {
				if (!(this instanceof a)) return new a(b, k);
				g.monitorEventEmitter("Twilio.PStream", this);
				var f = {
					logPrefix: "[PStream]",
					chunderw: "chunderw-vpc-gll.twilio.com",
					secureSignaling: !0,
					transportFactory: c,
					debug: !1
				};
				k = k || {};
				for (var q in f) q in k || (k[q] = f[q]);
				this.options = k;
				this.token = b || "";
				this.status = "disconnected";
				this.host = this.options.chunderw;
				this.region = this.gateway = null;
				l.mixinLog(this, this.options.logPrefix);
				this.log.enabled = this.options.debug;
				this.on("error", function() {});
				var e = this;
				this.addListener("ready", function() {
					e.status =
						"ready"
				});
				this.addListener("offline", function() {
					e.status = "offline"
				});
				this.addListener("close", function() {
					e.destroy()
				});
				this.transport = this.options.transportFactory({
					host: this.host,
					debug: this.options.debug,
					secureSignaling: this.options.secureSignaling
				});
				this.transport.onopen = function() {
					e.status = "connected";
					e.setToken(e.token)
				};
				this.transport.onclose = function() {
					"disconnected" !== e.status && ("offline" !== e.status && e.emit("offline", e), e.status = "disconnected")
				};
				this.transport.onerror = function(a) {
					e.emit("error",
						a)
				};
				this.transport.onmessage = function(a) {
					a = g.splitObjects(a.data);
					for (var d = 0; d < a.length; d++) {
						var c = JSON.parse(a[d]),
							b = c.type,
							c = c.payload || {};
						c.gateway && (e.gateway = c.gateway);
						c.region && (e.region = c.region);
						e.emit(b, c)
					}
				};
				this.transport.open();
				return this
			}
			e = b("events").EventEmitter;
			var k = b("util"),
				l = b("./log"),
				g = b("./util"),
				c = b("./wstransport").WSTransport;
			k.inherits(a, e);
			a.toString = function() {
				return "[Twilio.PStream class]"
			};
			a.prototype.toString = function() {
				return "[Twilio.PStream instance]"
			};
			a.prototype.setToken =
				function(a) {
					this.log("Setting token and publishing listen");
					this.token = a;
					a = {
						token: a,
						browserinfo: g.getSystemInfo()
					};
					this.publish("listen", a)
			};
			a.prototype.register = function(a) {
				this.publish("register", {
					media: a
				})
			};
			a.prototype.destroy = function() {
				this.log("Closing PStream");
				this.transport.close();
				return this
			};
			a.prototype.publish = function(a, c) {
				a = JSON.stringify({
					type: a,
					version: g.getPStreamVersion(),
					payload: c
				});
				this.transport.send(a)
			};
			h.PStream = a
		}, {
			"./log": 8,
			"./util": 27,
			"./wstransport": 28,
			events: 34,
			util: 49
		}
	],
	12: [
		function(b, e, h) {
			var a = "undefined" === typeof XMLHttpRequest ? b("xmlhttprequest").XMLHttpRequest : XMLHttpRequest;
			b = function(b, e, g) {
				var c;
				c = c || a;
				var f = new c;
				f.open(b, e.url, !0);
				f.onreadystatechange = function() {
					4 === f.readyState && (200 <= f.status && 300 > f.status ? g(null, f.responseText) : g(Error(f.responseText)))
				};
				for (var k in e.headers) f.setRequestHeader(k, e.headers[k]);
				f.send(JSON.stringify(e.body))
			};
			b.get = function(a, b) {
				return new this("GET", a, b)
			};
			b.post = function(a, b) {
				return new this("POST", a, b)
			};
			e.exports =
				b
		}, {
			xmlhttprequest: 50
		}
	],
	13: [
		function(b, e, h) {
			var a = b("../util");
			e.exports = function(b, e) {
				e = e || {};
				e.util = e.util || a;
				e.navigator = e.navigator || ("undefined" !== typeof navigator ? navigator : null);
				return (new Promise(function(a, c) {
					if (!e.navigator) throw Error("getUserMedia is not supported");
					switch ("function") {
						case typeof(e.navigator.mediaDevices && e.navigator.mediaDevices.getUserMedia):
							return a(e.navigator.mediaDevices.getUserMedia(b));
						case typeof e.navigator.webkitGetUserMedia:
							return e.navigator.webkitGetUserMedia(b,
								a, c);
						case typeof e.navigator.mozGetUserMedia:
							return e.navigator.mozGetUserMedia(b, a, c);
						case typeof e.navigator.getUserMedia:
							return e.navigator.getUserMedia(b, a, c);
						default:
							throw Error("getUserMedia is not supported");
					}
				})).catch(function(a) {
					throw e.util.isFirefox() && "NotReadableError" === a.name ? Error(
						"Firefox does not currently support opening multiple audio input trackssimultaneously, even across different tabs.\nRelated Bugzilla thread: https://bugzilla.mozilla.org/show_bug.cgi?id=1299324"
					) : a;
				})
			}
		}, {
			"../util": 27
		}
	],
	14: [
		function(b, e, h) {
			var a = b("./peerconnection");
			e.exports = {
				enabled: function(b) {
					"undefined" !== typeof b && (a.enabled = b);
					return a.enabled
				},
				getMediaEngine: function() {
					return "undefined" !== typeof RTCIceGatherer ? "ORTC" : "WebRTC"
				},
				PeerConnection: a
			}
		}, {
			"./peerconnection": 18
		}
	],
	15: [
		function(b, e, h) {
			function a(d) {
				if (!(this instanceof a)) return new a(d);
				var c = this;
				Object.defineProperties(this, {
					size: {
						enumerable: !0,
						get: function() {
							return c._map.size
						}
					},
					_map: {
						value: d
					}
				});
				$jscomp.initSymbol();
				$jscomp.initSymbolIterator();
				$jscomp.initSymbol();
				$jscomp.initSymbolIterator();
				this[Symbol.iterator] = d[Symbol.iterator]
			}

			function k(a) {
				return {
					type: "transport",
					id: a.id,
					timestamp: Date.parse(a.timestamp),
					bytesSent: void 0,
					bytesReceived: void 0,
					rtcpTransportStatsId: void 0,
					dtlsState: void 0,
					selectedCandidatePairId: a.stat("selectedCandidatePairId"),
					localCertificateId: a.stat("localCertificateId"),
					remoteCertificateId: a.stat("remoteCertificateId")
				}
			}

			function l(a) {
				return {
					type: "codec",
					id: a.id,
					timestamp: Date.parse(a.timestamp),
					payloadType: void 0,
					mimeType: a.stat("mediaType") + "/" + a.stat("googCodecName"),
					clockRate: void 0,
					channels: void 0,
					sdpFmtpLine: void 0,
					implementation: void 0
				}
			}

			function g(a) {
				return {
					type: "track",
					id: a.id,
					timestamp: Date.parse(a.timestamp),
					trackIdentifier: a.stat("googTrackId"),
					remoteSource: void 0,
					ended: void 0,
					kind: a.stat("mediaType"),
					detached: void 0,
					ssrcIds: void 0,
					frameWidth: w(a, "googFrameWidthReceived") ? r(a, "googFrameWidthReceived") : r(a, "googFrameWidthSent"),
					frameHeight: w(a, "googFrameHeightReceived") ? r(a, "googFrameHeightReceived") : r(a, "googFrameHeightSent"),
					framesPerSecond: void 0,
					framesSent: r(a, "framesEncoded"),
					framesReceived: void 0,
					framesDecoded: r(a, "framesDecoded"),
					framesDropped: void 0,
					framesCorrupted: void 0,
					partialFramesLost: void 0,
					fullFramesLost: void 0,
					audioLevel: w(a, "audioOutputLevel") ? r(a, "audioOutputLevel") / 32767 : (r(a, "audioInputLevel") || 0) / 32767,
					echoReturnLoss: n(a, "googEchoCancellationReturnLoss"),
					echoReturnLossEnhancement: n(a, "googEchoCancellationReturnLossEnhancement")
				}
			}

			function c(a, d) {
				return {
					id: a.id,
					timestamp: Date.parse(a.timestamp),
					ssrc: a.stat("ssrc"),
					associateStatsId: void 0,
					isRemote: void 0,
					mediaType: a.stat("mediaType"),
					trackId: "track-" + a.id,
					transportId: a.stat("transportId"),
					codecId: "codec-" + a.id,
					firCount: d ? r(a, "googFirsSent") : void 0,
					pliCount: d ? r(a, "googPlisSent") : r(a, "googPlisReceived"),
					nackCount: d ? r(a, "googNacksSent") : r(a, "googNacksReceived"),
					sliCount: void 0,
					qpSum: r(a, "qpSum")
				}
			}

			function f(a) {
				var d = c(a, !0);
				Object.assign(d, {
					type: "inbound-rtp",
					packetsReceived: r(a, "packetsReceived"),
					bytesReceived: r(a, "bytesReceived"),
					packetsLost: r(a,
						"packetsLost"),
					jitter: m(a.stat("googJitterReceived")),
					fractionLost: void 0,
					roundTripTime: m(a.stat("googRtt")),
					packetsDiscarded: void 0,
					packetsRepaired: void 0,
					burstPacketsLost: void 0,
					burstPacketsDiscarded: void 0,
					burstLossCount: void 0,
					burstDiscardCount: void 0,
					burstLossRate: void 0,
					burstDiscardRate: void 0,
					gapLossRate: void 0,
					gapDiscardRate: void 0,
					framesDecoded: r(a, "framesDecoded")
				});
				return d
			}

			function u(a) {
				var d = c(a, !1);
				Object.assign(d, {
					type: "outbound-rtp",
					remoteTimestamp: void 0,
					packetsSent: r(a, "packetsSent"),
					bytesSent: r(a, "bytesSent"),
					targetBitrate: void 0,
					framesEncoded: r(a, "framesEncoded")
				});
				return d
			}

			function p(a, d) {
				var c = a.id,
					b = Date.parse(a.timestamp),
					f = a.stat("ipAddress"),
					m = r(a, "portNumber"),
					g = a.stat("transport"),
					p;
				a: switch (p = a.stat("candidateType"), p) {
					case "peerreflexive":
						p = "prflx";
						break a;
					case "serverreflexive":
						p = "srflx"
				}
				return {
					type: d ? "remote-candidate" : "local-candidate",
					id: c,
					timestamp: b,
					transportId: void 0,
					isRemote: d,
					ip: f,
					port: m,
					protocol: g,
					candidateType: p,
					priority: n(a, "priority"),
					url: void 0,
					relayProtocol: void 0,
					deleted: void 0
				}
			}

			function q(a) {
				return {
					type: "candidate-pair",
					id: a.id,
					timestamp: Date.parse(a.timestamp),
					transportId: a.stat("googChannelId"),
					localCandidateId: a.stat("localCandidateId"),
					remoteCandidateId: a.stat("remoteCandidateId"),
					state: void 0,
					priority: void 0,
					nominated: void 0,
					writable: v(a, "googWritable"),
					readable: void 0,
					bytesSent: r(a, "bytesSent"),
					bytesReceived: r(a, "bytesReceived"),
					lastPacketSentTimestamp: void 0,
					lastPacketReceivedTimestamp: void 0,
					totalRoundTripTime: void 0,
					currentRoundTripTime: m(a.stat("googRtt")),
					availableOutgoingBitrate: void 0,
					availableIncomingBitrate: void 0,
					requestsReceived: r(a, "requestsReceived"),
					requestsSent: r(a, "requestsSent"),
					responsesReceived: r(a, "responsesReceived"),
					responsesSent: r(a, "responsesSent"),
					retransmissionsReceived: void 0,
					retransmissionsSent: void 0,
					consentRequestsSent: r(a, "consentRequestsSent")
				}
			}

			function t(a) {
				return {
					type: "certificate",
					id: a.id,
					timestamp: Date.parse(a.timestamp),
					fingerprint: a.stat("googFingerprint"),
					fingerprintAlgorithm: a.stat("googFingerprintAlgorithm"),
					base64Certificate: a.stat("googDerBase64"),
					issuerCertificateId: a.stat("googIssuerId")
				}
			}

			function d(a) {
				return {
					type: "data-channel",
					id: a.id,
					timestamp: Date.parse(a.timestamp),
					label: a.stat("label"),
					protocol: a.stat("protocol"),
					datachannelid: a.stat("datachannelid"),
					transportId: a.stat("transportId"),
					state: a.stat("state"),
					messagesSent: void 0,
					bytesSent: void 0,
					messagesReceived: void 0,
					bytesReceived: void 0
				}
			}

			function m(a) {
				return isNaN(a) || "" === a ? void 0 : parseInt(a, 10) / 1E3
			}

			function r(a, d) {
				var c = a.stat(d);
				return w(a, d) ? parseInt(c, 10) : void 0
			}

			function n(a, d) {
				var c =
					a.stat(d);
				return w(a, d) ? parseFloat(c) : void 0
			}

			function v(a, d) {
				var c = a.stat(d);
				return w(a, d) ? "true" === c || !0 === c : void 0
			}

			function w(a, d) {
				a = a.stat(d);
				return "undefined" !== typeof a && "" !== a
			}
			if (b = "undefined" !== typeof window ? window.RTCStatsReport : void 0) a.prototype = Object.create(b.prototype), a.prototype.constructor =
				a;
			"entries forEach get has keys values".split(" ").forEach(function(d) {
				a.prototype[d] = function() {
					return this._map[d].apply(this._map, arguments)
				}
			});
			a.fromArray = function(d) {
				return new a(d.reduce(function(a,
					d) {
					a.set(d.id, d);
					return a
				}, new Map))
			};
			a.fromRTCStatsResponse = function(c) {
				var b, m = new Map;
				c = c.result().reduce(function(a, c) {
					var n = c.id;
					switch (c.type) {
						case "googCertificate":
							a.set(n, t(c));
							break;
						case "datachannel":
							a.set(n, d(c));
							break;
						case "googCandidatePair":
							v(c, "googActiveConnection") && (b = n);
							a.set(n, q(c));
							break;
						case "localcandidate":
							a.set(n, p(c, !1));
							break;
						case "remotecandidate":
							a.set(n, p(c, !0));
							break;
						case "ssrc":
							w(c, "packetsReceived") ? a.set("rtp-" + n, f(c)) : a.set("rtp-" + n, u(c));
							a.set("track-" + n, g(c));
							a.set("codec-" + n, l(c));
							break;
						case "googComponent":
							var r = k(c);
							m.set(r.selectedCandidatePairId, n);
							a.set(n, k(c))
					}
					return a
				}, new Map);
				if (b) {
					var n = m.get(b);
					n && (c.get(n).dtlsState = "connected")
				}
				return new a(c)
			};
			e.exports = a
		}, {}
	],
	16: [
		function(b, e, h) {
			function a(c) {
				if (!(this instanceof a)) return new a(c);
				c = c || {};
				var b = Object.assign({}, u, c.thresholds);
				Object.defineProperties(this, {
					_activeWarnings: {
						value: new Map
					},
					_currentStreaks: {
						value: new Map
					},
					_peerConnection: {
						value: c.peerConnection,
						writable: !0
					},
					_sampleBuffer: {
						value: []
					},
					_sampleInterval: {
						value: null,
						writable: !0
					},
					_thresholds: {
						value: b
					},
					_warningsEnabled: {
						value: !0,
						writable: !0
					}
				});
				c.peerConnection && this.enable();
				g.call(this)
			}

			function k(a, c) {
				return c.reduce(function(c, d) {
					return c + (d < a ? 1 : 0)
				}, 0)
			}

			function l(a, c) {
				return c.reduce(function(c, d) {
					return c + (d > a ? 1 : 0)
				}, 0)
			}
			var g = b("events").EventEmitter,
				c = b("./stats");
			h = b("util").inherits;
			var f = b("./mos"),
				u = {
					audioInputLevel: {
						maxDuration: 10
					},
					audioOutputLevel: {
						maxDuration: 10
					},
					packetsLostFraction: {
						max: 1
					},
					jitter: {
						max: 30
					},
					rtt: {
						max: 400
					},
					mos: {
						min: 3
					}
				};
			h(a, g);
			a.createSample = function(a, c) {
				var b = a.packetsReceived - (c && c.totals.packetsReceived || 0),
					d = a.packetsLost - (c && c.totals.packetsLost || 0),
					m = b + d,
					m = 0 < m ? d / m * 100 : 0,
					g = a.packetsReceived + a.packetsLost;
				return {
					timestamp: a.timestamp,
					totals: {
						packetsReceived: a.packetsReceived,
						packetsLost: a.packetsLost,
						packetsSent: a.packetsSent,
						packetsLostFraction: 0 < g ? a.packetsLost / g * 100 : 100,
						bytesReceived: a.bytesReceived,
						bytesSent: a.bytesSent
					},
					packetsSent: a.packetsSent - (c && c.totals.packetsSent || 0),
					packetsReceived: b,
					packetsLost: d,
					packetsLostFraction: m,
					audioInputLevel: a.audioInputLevel,
					audioOutputLevel: a.audioOutputLevel,
					jitter: a.jitter,
					rtt: a.rtt,
					mos: f.calculate(a, c && m)
				}
			};
			a.prototype.enable = function(a) {
				if (a) {
					if (this._peerConnection && a !== this._peerConnection) throw Error(
						"Attempted to replace an existing PeerConnection in RTCMonitor.enable");
					this._peerConnection = a
				}
				if (!this._peerConnection) throw Error("Can not enable RTCMonitor without a PeerConnection");
				this._sampleInterval = this._sampleInterval || setInterval(this._fetchSample.bind(this),
					1E3);
				return this
			};
			a.prototype.disable = function() {
				clearInterval(this._sampleInterval);
				this._sampleInterval = null;
				return this
			};
			a.prototype.getSample = function() {
				var b = this;
				return c(this._peerConnection).then(function(c) {
					return a.createSample(c, b._sampleBuffer.length && b._sampleBuffer[b._sampleBuffer.length - 1])
				})
			};
			a.prototype._fetchSample = function() {
				var a = this;
				return this.getSample().then(function(c) {
					a._addSample(c);
					a._raiseWarnings();
					a.emit("sample", c);
					return c
				}, function(c) {
					a.disable();
					a.emit("error",
						c)
				})
			};
			a.prototype._addSample = function(a) {
				var c = this._sampleBuffer;
				c.push(a);
				5 < c.length && c.splice(0, c.length - 5)
			};
			a.prototype._raiseWarnings = function() {
				if (this._warningsEnabled)
					for (var a in this._thresholds) this._raiseWarningsForStat(a)
			};
			a.prototype.enableWarnings = function() {
				this._warningsEnabled = !0;
				return this
			};
			a.prototype.disableWarnings = function() {
				this._warningsEnabled && this._activeWarnings.clear();
				this._warningsEnabled = !1;
				return this
			};
			a.prototype._raiseWarningsForStat = function(a) {
				var c = this._sampleBuffer,
					b = this._thresholds[a],
					d = c.slice(-5),
					d = d.map(function(d) {
						return d[a]
					});
				if (!d.some(function(a) {
					return "undefined" === typeof a || null === a
				})) {
					var f;
					"number" === typeof b.max && (f = l(b.max, d), 3 <= f ? this._raiseWarning(a, "max", {
						values: d
					}) : 0 >= f && this._clearWarning(a, "max", {
						values: d
					}));
					"number" === typeof b.min && (f = k(b.min, d), 3 <= f ? this._raiseWarning(a, "min", {
						values: d
					}) : 0 >= f && this._clearWarning(a, "min", {
						values: d
					}));
					"number" === typeof b.maxDuration && 1 < c.length && (d = c.slice(-2), c = d[0][a], f = d[1][a], d = this._currentStreaks.get(a) ||
						0, c = c === f ? d + 1 : 0, this._currentStreaks.set(a, c), c >= b.maxDuration ? this._raiseWarning(a, "maxDuration", {
							value: c
						}) : 0 === c && this._clearWarning(a, "maxDuration", {
							value: d
						}))
				}
			};
			a.prototype._clearWarning = function(a, c, b) {
				var d = a + ":" + c,
					f = this._activeWarnings.get(d);
				!f || 5E3 > Date.now() - f.timeRaised || (this._activeWarnings.delete(d), this.emit("warning-cleared", Object.assign({
					name: a,
					threshold: {
						name: c,
						value: this._thresholds[a][c]
					}
				}, b)))
			};
			a.prototype._raiseWarning = function(a, c, b) {
				var d = a + ":" + c;
				this._activeWarnings.has(d) ||
					(this._activeWarnings.set(d, {
					timeRaised: Date.now()
				}), this.emit("warning", Object.assign({
					name: a,
					threshold: {
						name: c,
						value: this._thresholds[a][c]
					}
				}, b)))
			};
			e.exports = a
		}, {
			"./mos": 17,
			"./stats": 20,
			events: 34,
			util: 49
		}
	],
	17: [
		function(b, e, h) {
			function a(a) {
				return "number" === typeof a && !isNaN(a) && isFinite(a) && 0 <= a
			}
			e.exports = {
				calculate: function(b, e) {
					if (!(b && a(b.rtt) && a(b.jitter) && a(e))) return null;
					var g = b.rtt + 2 * b.jitter + 10;
					b = 0;
					switch (!0) {
						case 160 > g:
							b = 94.768 - g / 40;
							break;
						case 1E3 > g:
							b = 94.768 - (g - 120) / 10;
							break;
						case 1E3 <=
							g:
							b = 94.768 - g / 100
					}
					g = .01;
					switch (!0) {
						case -1 === e:
							b = g = 0;
							break;
						case e <= b / 2.5:
							g = 2.5;
							break;
						case e > b / 2.5 && 100 > e:
							g = .25
					}
					e = b - e * g;
					e = 1 + .035 * e + 7E-6 * e * (e - 60) * (100 - e);
					return 1 <= e && 4.6 > e ? e : null
				}
			}
		}, {}
	],
	18: [
		function(b, e, h) {
			function a(d, c, b) {
				function n() {}
				if (!d || !c) throw Error("Device and getUserMedia are required arguments");
				if (!(this instanceof a)) return new a(d, c, b);
				this.onvolume = this.onicecandidate = this.oniceconnectionstatechange = this.onsignalingstatechange = this.onreconnect = this.ondisconnect =
					this.onclose = this.onerror =
					this.onopen = n;
				this.version = null;
				this.pstream = d.stream;
				this.stream = null;
				this.sinkIds = new Set(["default"]);
				this.outputs = new Map;
				this.status = "connecting";
				this.callSid = null;
				this.isMuted = !1;
				this.getUserMedia = c;
				c = "undefined" !== typeof window && (window.AudioContext || window.webkitAudioContext);
				this._isSinkSupported = !!c && "undefined" !== typeof HTMLAudioElement && HTMLAudioElement.prototype.setSinkId;
				this._audioContext = c && d.audio._audioContext;
				this._dtmfSender = this._mediaStreamSource = this._masterAudioDeviceId = this._masterAudio =
					null;
				this._dtmfSenderUnsupported = !1;
				this._callEvents = [];
				this._nextTimeToPublish = Date.now();
				this._onAnswerOrRinging = n;
				this._remoteStream = null;
				this._shouldManageStream = !0;
				f.mixinLog(this, "[Twilio.PeerConnection]");
				this.log.enabled = d.options.debug;
				this.log.warnings = d.options.warnings;
				this._iceConnectionStateMachine = new u(q, "new");
				this._signalingStateMachine = new u(t, "stable");
				this.options = b = b || {};
				this.navigator = b.navigator || ("undefined" !== typeof navigator ? navigator : null);
				this.util = b.util || p;
				return this
			}

			function k(a, c) {
				"function" === typeof a.addTrack ? c.getAudioTracks().forEach(function(d) {
					a.addTrack(d, c)
				}) : a.addStream(c)
			}

			function l(a) {
				var d = "undefined" !== typeof MediaStream ? new MediaStream : new webkitMediaStream;
				a.getAudioTracks().forEach(d.addTrack, d);
				return d
			}

			function g(a, c) {
				"function" === typeof a.removeTrack ? a.getSenders().forEach(function(d) {
					a.removeTrack(d)
				}) : a.removeStream(c)
			}

			function c(a, c) {
				if ("undefined" !== typeof a.srcObject) a.srcObject = c;
				else if ("undefined" !== typeof a.mozSrcObject) a.mozSrcObject =
					c;
				else if ("undefined" !== typeof a.src) {
					var d = a.options.window || window;
					a.src = (d.URL || d.webkitURL).createObjectURL(c)
				} else return !1;
				return !0
			}
			var f = b("../log"),
				u = b("../statemachine"),
				p = b("../util");
			b = b("./rtcpc");
			var q = {
					new: ["checking", "closed"],
					checking: ["new", "connected", "failed", "closed", "completed"],
					connected: ["new", "disconnected", "completed", "closed"],
					completed: ["new", "disconnected", "closed", "completed"],
					failed: ["new", "disconnected", "closed"],
					disconnected: ["connected", "completed", "failed", "closed"],
					closed: []
				},
				t = {
					stable: ["have-local-offer", "have-remote-offer", "closed"],
					"have-local-offer": ["stable", "closed"],
					"have-remote-offer": ["stable", "closed"],
					closed: []
				};
			a.prototype.uri = function() {
				return this._uri
			};
			a.prototype.openWithConstraints = function(a) {
				return this.getUserMedia({
					audio: a
				}).then(this._setInputTracksFromStream.bind(this, !1))
			};
			a.prototype.setInputTracksFromStream = function(a) {
				var d = this;
				return this._setInputTracksFromStream(!0, a).then(function() {
					d._shouldManageStream = !1
				})
			};
			a.prototype._createAnalyser =
				function(a, c) {
					var d = c.createAnalyser();
					d.fftSize = 32;
					d.smoothingTimeConstant = .3;
					c.createMediaStreamSource(a).connect(d);
					return d
			};
			a.prototype._setVolumeHandler = function(a) {
				this.onvolume = a
			};
			a.prototype._startPollingVolume = function() {
				if (this._audioContext && this.stream && this._remoteStream) {
					var a = this._audioContext,
						c = (this._inputAnalyser = this._createAnalyser(this.stream, a)).frequencyBinCount,
						b = new Uint8Array(c),
						a = (this._outputAnalyser = this._createAnalyser(this._remoteStream, a)).frequencyBinCount,
						f = new Uint8Array(a),
						g = this;
					requestAnimationFrame(function B() {
						if (g._audioContext)
							if ("closed" === g.status) g._inputAnalyser.disconnect(), g._outputAnalyser.disconnect();
							else {
								g._inputAnalyser.getByteFrequencyData(b);
								var a = g.util.average(b);
								g._outputAnalyser.getByteFrequencyData(f);
								var d = g.util.average(f);
								g.onvolume(a / 255, d / 255);
								requestAnimationFrame(B)
							}
					})
				}
			};
			a.prototype._stopStream = function(a) {
				this._shouldManageStream && ("function" === typeof MediaStreamTrack.prototype.stop ? ("function" === typeof a.getAudioTracks ? a.getAudioTracks() :
					a.audioTracks).forEach(function(a) {
					a.stop()
				}) : a.stop())
			};
			a.prototype._setInputTracksFromStream = function(a, c) {
				var d = this;
				if (!c) return Promise.reject(Error("Can not set input stream to null while in a call"));
				if (!c.getAudioTracks().length) return Promise.reject(Error("Supplied input stream has no audio tracks"));
				var b = this.stream;
				b ? (this._stopStream(b), g(this.version.pc, b), b.getAudioTracks().forEach(b.removeTrack, b), c.getAudioTracks().forEach(b.addTrack,
					b), k(this.version.pc, c)) : this.stream = a ? l(c) : c;
				this.mute(this.isMuted);
				return this.version ? new Promise(function(a, c) {
					d.version.createOffer({
						audio: !0
					}, function() {
						d.version.processAnswer(d._answerSdp, function() {
							d._audioContext && (d._inputAnalyser = d._createAnalyser(d.stream, d._audioContext));
							a(d.stream)
						}, c)
					}, c)
				}) : Promise.resolve(this.stream)
			};
			a.prototype._onInputDevicesChanged = function() {
				this.stream && this.stream.getAudioTracks().every(function(a) {
					return "ended" === a.readyState
				}) && this._shouldManageStream && this.openWithConstraints(!0)
			};
			a.prototype._setSinkIds =
				function(a) {
					if (!this._isSinkSupported) return Promise.reject(Error("Audio output selection is not supported by this browser"));
					this.sinkIds = new Set(a.forEach ? a : [a]);
					return this.version ? this._updateAudioOutputs() : Promise.resolve()
			};
			a.prototype._updateAudioOutputs = function() {
				var a = Array.from(this.sinkIds).filter(function(a) {
						return !this.outputs.has(a)
					}, this),
					c = Array.from(this.outputs.keys()).filter(function(a) {
						return !this.sinkIds.has(a)
					}, this),
					b = this,
					a = a.map(this._createAudioOutput, this);
				return Promise.all(a).then(function() {
					return Promise.all(c.map(b._removeAudioOutput,
						b))
				})
			};
			a.prototype._createAudio = function(a) {
				return new Audio(a)
			};
			a.prototype._createAudioOutput = function(a) {
				var d = this._audioContext.createMediaStreamDestination();
				this._mediaStreamSource.connect(d);
				var b = this._createAudio();
				c(b, d.stream);
				var f = this;
				return b.setSinkId(a).then(function() {
					return b.play()
				}).then(function() {
					f.outputs.set(a, {
						audio: b,
						dest: d
					})
				})
			};
			a.prototype._removeAudioOutputs = function() {
				return Array.from(this.outputs.keys()).map(this._removeAudioOutput, this)
			};
			a.prototype._disableOutput =
				function(a, c) {
					if (a = a.outputs.get(c)) a.audio && (a.audio.pause(), a.audio.src = ""), a.dest && a.dest.disconnect()
			};
			a.prototype._reassignMasterOutput = function(a, c) {
				var d = a.outputs.get(c);
				a.outputs.delete(c);
				var b = this,
					f = Array.from(a.outputs.keys())[0] || "default";
				return d.audio.setSinkId(f).then(function() {
					b._disableOutput(a, f);
					a.outputs.set(f, d);
					a._masterAudioDeviceId = f
				}).catch(function(b) {
					a.outputs.set(c, d);
					throw b;
				})
			};
			a.prototype._removeAudioOutput = function(a) {
				if (this._masterAudioDeviceId === a) return this._reassignMasterOutput(this,
					a);
				this._disableOutput(this, a);
				this.outputs.delete(a);
				return Promise.resolve()
			};
			a.prototype._onAddTrack = function(a, b) {
				var d = a._masterAudio = this._createAudio();
				c(d, b);
				d.play();
				var f = Array.from(a.outputs.keys())[0] || "default";
				a._masterAudioDeviceId = f;
				a.outputs.set(f, {
					audio: d
				});
				a._mediaStreamSource = a._audioContext.createMediaStreamSource(b);
				a.pcStream = b;
				a._updateAudioOutputs()
			};
			a.prototype._fallbackOnAddTrack = function(a, b) {
				var d = document && document.createElement("audio");
				d.autoplay = !0;
				c(d, b) || a.log("Error attaching stream to element.");
				a.outputs.set("default", {
					audio: d
				})
			};
			a.prototype._setupPeerConnection = function(a, c) {
				var d = this,
					b = this._getProtocol();
				b.create(this.log, a, c);
				k(b.pc, this.stream);
				b.pc["ontrack" in b.pc ? "ontrack" : "onaddstream"] = function(a) {
					a = d._remoteStream = a.stream || a.streams[0];
					d._isSinkSupported ? d._onAddTrack(d, a) : d._fallbackOnAddTrack(d, a);
					d._startPollingVolume()
				};
				return b
			};
			a.prototype._setupChannel = function() {
				var a = this,
					c = this.version.pc;
				a.version.pc.onopen = function() {
					a.status = "open";
					a.onopen()
				};
				a.version.pc.onstatechange =
					function() {
						a.version.pc && "stable" === a.version.pc.readyState && (a.status = "open", a.onopen())
				};
				a.version.pc.onsignalingstatechange = function() {
					var d = c.signalingState;
					a.log('signalingState is "' + d + '"');
					try {
						a._signalingStateMachine.transition(d)
					} catch (n) {
						a.log("Failed to transition to signaling state " + d + ": " + n)
					}
					a.version.pc && "stable" === a.version.pc.signalingState && (a.status = "open", a.onopen());
					a.onsignalingstatechange(c.signalingState)
				};
				c.onicecandidate = function(c) {
					a.onicecandidate(c.candidate)
				};
				c.oniceconnectionstatechange =
					function() {
						var d = c.iceConnectionState,
							b = a._iceConnectionStateMachine.currentState;
						try {
							a._iceConnectionStateMachine.transition(d)
						} catch (v) {
							a.log("Failed to transition to ice connection state " + d + ": " + v)
						}
						switch (d) {
							case "connected":
								"disconnected" === b && (b = "ICE liveliness check succeeded. Connection with Twilio restored", a.log(b), a.onreconnect(b));
								break;
							case "disconnected":
								b = "ICE liveliness check failed. May be having trouble connecting to Twilio";
								a.log(b);
								a.ondisconnect(b);
								break;
							case "failed":
								b = ("checking" ===
									b ? "ICE negotiation with Twilio failed." : "Connection with Twilio was interrupted.") + " Call will terminate.";
								a.log(b);
								a.onerror({
									info: {
										code: 31003,
										message: b
									},
									disconnect: !0
								});
								break;
							default:
								a.log('iceConnectionState is "' + d + '"')
						}
						a.oniceconnectionstatechange(d)
				}
			};
			a.prototype._initializeMediaStream = function(a, c) {
				if ("open" === this.status) return !1;
				if ("disconnected" === this.pstream.status) return this.onerror({
					info: {
						code: 31E3,
						message: "Cannot establish connection. Client is disconnected"
					}
				}), this.close(), !1;
				this.version =
					this._setupPeerConnection(a, c);
				this._setupChannel();
				return !0
			};
			a.prototype.makeOutgoingCall = function(a, c, b, f, g, e) {
				function d() {
					e(m.version.pc)
				}

				function n(a) {
					m.onerror({
						info: {
							code: 31E3,
							message: "Error processing answer: " + (a.message || a)
						}
					})
				}
				if (this._initializeMediaStream(f, g)) {
					var m = this;
					this.callSid = b;
					this._onAnswerOrRinging = function(a) {
						a.sdp && (m._answerSdp = a.sdp, "closed" !== m.status && m.version.processAnswer(a.sdp, d, n), m.pstream.removeListener("answer", m._onAnswerOrRinging),
							m.pstream.removeListener("ringing",
								m._onAnswerOrRinging))
					};
					this.pstream.on("answer", this._onAnswerOrRinging);
					this.pstream.on("ringing", this._onAnswerOrRinging);
					this.version.createOffer({
						audio: !0
					}, function() {
						"closed" !== m.status && m.pstream.publish("invite", {
							sdp: m.version.getSDP(),
							callsid: m.callSid,
							twilio: {
								accountsid: a ? m.util.objectize(a).iss : null,
								params: c
							}
						})
					}, function(a) {
						m.onerror({
							info: {
								code: 31E3,
								message: "Error creating the offer: " + (a.message || a)
							}
						})
					})
				}
			};
			a.prototype.answerIncomingCall = function(a, c, b, f, g) {
				if (this._initializeMediaStream(b,
					f)) {
					this._answerSdp = c.replace(/^a=setup:actpass$/gm, "a=setup:passive");
					this.callSid = a;
					var d = this;
					this.version.processSDP(c, {
						audio: !0
					}, function() {
						"closed" !== d.status && (d.pstream.publish("answer", {
							callsid: a,
							sdp: d.version.getSDP()
						}), g(d.version.pc))
					}, function(a) {
						d.onerror({
							info: {
								code: 31E3,
								message: "Error creating the answer: " + (a.message || a)
							}
						})
					})
				}
			};
			a.prototype.close = function() {
				this.version && this.version.pc && ("closed" !== this.version.pc.signalingState && this.version.pc.close(), this.version.pc = null);
				this.stream &&
					(this.mute(!1), this._stopStream(this.stream));
				this.stream = null;
				this.pstream && this.pstream.removeListener("answer", this._onAnswerOrRinging);
				this._removeAudioOutputs();
				this._mediaStreamSource && this._mediaStreamSource.disconnect();
				this._inputAnalyser && this._inputAnalyser.disconnect();
				this._outputAnalyser && this._outputAnalyser.disconnect();
				this.status = "closed";
				this.onclose()
			};
			a.prototype.reject = function(a) {
				this.callSid = a
			};
			a.prototype.ignore = function(a) {
				this.callSid = a
			};
			a.prototype.mute = function(a) {
				this.isMuted =
					a;
				this.stream && ("function" === typeof this.stream.getAudioTracks ? this.stream.getAudioTracks() : this.stream.audioTracks).forEach(
					function(c) {
						c.enabled = !a
					})
			};
			a.prototype.getOrCreateDTMFSender = function() {
				if (this._dtmfSender || this._dtmfSenderUnsupported) return this._dtmfSender || null;
				var a = this,
					c = this.version.pc;
				if (!c) return this.log("No RTCPeerConnection available to call createDTMFSender on"), null;
				if ("function" === typeof c.getSenders && ("function" === typeof RTCDTMFSender || "function" === typeof RTCDtmfSender)) {
					var b =
						c.getSenders().find(function(a) {
							return a.dtmf
						});
					if (b && b.dtmf) return this.log("Using RTCRtpSender#dtmf"), this._dtmfSender = b.dtmf
				}
				if ("function" === typeof c.createDTMFSender && "function" === typeof c.getLocalStreams) {
					b = c.getLocalStreams().map(function(c) {
						return (c = a._getAudioTracks(c)) && c[0]
					})[0];
					if (!b) return this.log("No local audio MediaStreamTrack available on the RTCPeerConnection to pass to createDTMFSender"), null;
					this.log("Creating RTCDTMFSender");
					return this._dtmfSender = c.createDTMFSender(b)
				}
				this.log("RTCPeerConnection does not support RTCDTMFSender");
				this._dtmfSenderUnsupported = !0;
				return null
			};
			a.prototype._canStopMediaStreamTrack = function() {
				return "function" === typeof MediaStreamTrack.prototype.stop
			};
			a.prototype._getAudioTracks = function(a) {
				return "function" === typeof a.getAudioTracks ? a.getAudioTracks() : a.audioTracks
			};
			a.prototype._getProtocol = function() {
				return a.protocol
			};
			a.protocol = b.test() ? new b : null;
			a.enabled = !!a.protocol;
			e.exports = a
		}, {
			"../log": 8,
			"../statemachine": 25,
			"../util": 27,
			"./rtcpc": 19
		}
	],
	19: [
		function(b, e, h) {
			function a() {
				"undefined" === typeof window ?
					this.log("No RTCPeerConnection implementation available. The window object was not found.") : g.isEdge() ? (this.RTCPeerConnection =
						l.RTCPeerConnection, window.RTCSessionDescription = l.RTCSessionDescription, window.RTCIceCandidate = l.RTCIceCandidate) :
					"function" === typeof window.RTCPeerConnection ? this.RTCPeerConnection = window.RTCPeerConnection : "function" === typeof window.webkitRTCPeerConnection ?
					this.RTCPeerConnection = webkitRTCPeerConnection : "function" === typeof window.mozRTCPeerConnection ? (this.RTCPeerConnection =
						mozRTCPeerConnection, window.RTCSessionDescription = mozRTCSessionDescription, window.RTCIceCandidate = mozRTCIceCandidate) : this.log(
						"No RTCPeerConnection implementation available")
			}

			function k(a, b, g) {
				return function() {
					var c = Array.prototype.slice.call(arguments);
					return (new Promise(function(f) {
						f(a.apply(b, c))
					})).catch(function() {
						return new Promise(function(f, e) {
							a.apply(b, g ? [f, e].concat(c) : c.concat([f, e]))
						})
					})
				}
			}
			var l = b("ortc-adapter"),
				g = b("../util");
			a.prototype.create = function(a, b, g) {
				this.log = a;
				this.pc = new this.RTCPeerConnection({
						iceServers: g
					},
					b)
			};
			a.prototype.createModernConstraints = function(a) {
				if ("undefined" === typeof a) return null;
				var c = {};
				"undefined" !== typeof webkitRTCPeerConnection ? (c.mandatory = {}, "undefined" !== typeof a.audio && (c.mandatory.OfferToReceiveAudio =
					a.audio), "undefined" !== typeof a.video && (c.mandatory.OfferToReceiveVideo = a.video)) : ("undefined" !== typeof a.audio && (c.offerToReceiveAudio =
					a.audio), "undefined" !== typeof a.video && (c.offerToReceiveVideo = a.video));
				return c
			};
			a.prototype.createOffer = function(a, b, g) {
				var c = this;
				a = this.createModernConstraints(a);
				k(this.pc.createOffer, this.pc, !0)(a).then(function(a) {
					return c.pc && k(c.pc.setLocalDescription, c.pc, !1)(new RTCSessionDescription(a))
				}).then(b, g)
			};
			a.prototype.createAnswer = function(a, b, g) {
				var c = this;
				a = this.createModernConstraints(a);
				k(this.pc.createAnswer, this.pc, !0)(a).then(function(a) {
					return c.pc && k(c.pc.setLocalDescription, c.pc, !1)(new RTCSessionDescription(a))
				}).then(b, g)
			};
			a.prototype.processSDP = function(a, b, g, e) {
				var c = this;
				a = new RTCSessionDescription({
					sdp: a,
					type: "offer"
				});
				k(this.pc.setRemoteDescription,
					this.pc, !1)(a).then(function() {
					c.createAnswer(b, g, e)
				})
			};
			a.prototype.getSDP = function() {
				return this.pc.localDescription.sdp
			};
			a.prototype.processAnswer = function(a, b, g) {
				this.pc && k(this.pc.setRemoteDescription, this.pc, !1)(new RTCSessionDescription({
					sdp: a,
					type: "answer"
				})).then(b, g)
			};
			a.test = function() {
				if ("object" === typeof navigator) {
					var a = navigator.mediaDevices && navigator.mediaDevices.getUserMedia || navigator.webkitGetUserMedia || navigator.mozGetUserMedia ||
						navigator.getUserMedia;
					if (a && "function" === typeof window.RTCPeerConnection ||
						a && "function" === typeof window.webkitRTCPeerConnection) return !0;
					if (a && "function" === typeof window.mozRTCPeerConnection) {
						try {
							if ("function" !== typeof(new window.mozRTCPeerConnection).getLocalStreams) return !1
						} catch (f) {
							return !1
						}
						return !0
					}
					if ("undefined" !== typeof RTCIceGatherer) return !0
				}
				return !1
			};
			e.exports = a
		}, {
			"../util": 27,
			"ortc-adapter": 35
		}
	],
	20: [
		function(b, e, h) {
			function a() {}

			function k(c) {
				var b = null,
					f = new a,
					g;
				Array.from(c.values()).forEach(function(a) {
					var d = a.type.replace("-", "");
					g = g || a.timestamp;
					switch (d) {
						case "inboundrtp":
							f.timestamp =
								f.timestamp || a.timestamp;
							f.jitter = 1E3 * a.jitter;
							f.packetsLost = a.packetsLost;
							f.packetsReceived = a.packetsReceived;
							f.bytesReceived = a.bytesReceived;
							if (a = c.get(a.trackId)) f.audioOutputLevel = 32767 * a.audioLevel;
							break;
						case "outboundrtp":
							f.timestamp = a.timestamp;
							f.packetsSent = a.packetsSent;
							f.bytesSent = a.bytesSent;
							a.codecId && c.get(a.codecId) && (d = c.get(a.codecId).mimeType, f.codecName = d && d.match(/(.*\/)?(.*)/)[2]);
							if (a = c.get(a.trackId)) f.audioInputLevel = 32767 * a.audioLevel;
							break;
						case "transport":
							"connected" === a.dtlsState &&
								(b = a.id)
					}
				});
				f.timestamp || (f.timestamp = g);
				var e = c.get(b);
				if (!e) return f;
				e = c.get(e.selectedCandidatePairId);
				if (!e) return f;
				var d = c.get(e.localCandidateId),
					m = c.get(e.remoteCandidateId);
				Object.assign(f, {
					localAddress: d && d.ip,
					remoteAddress: m && m.ip,
					rtt: e && 1E3 * e.currentRoundTripTime
				});
				return f
			}
			var l = b("./mockrtcstatsreport"),
				g = !1;
			if ("undefined" !== typeof window) {
				b = !!window.navigator.userAgent.match("CriOS");
				h = !!window.navigator.userAgent.match("Electron");
				var c = "undefined" !== typeof window.chrome && "Google Inc." ===
					window.navigator.vendor && -1 === window.navigator.userAgent.indexOf("OPR") && -1 === window.navigator.userAgent.indexOf("Edge"),
					g = b || h || c
			}
			e.exports = function(a, c) {
				c = Object.assign({
					createRTCSample: k
				}, c);
				if (!a) return Promise.reject(Error("PeerConnection is null"));
				if ("function" !== typeof a.getStats) return Promise.reject(Error("WebRTC statistics are unsupported"));
				if (g) return (new Promise(function(c, b) {
					return a.getStats(c, b)
				})).then(l.fromRTCStatsResponse).then(c.createRTCSample);
				var b;
				try {
					b = a.getStats()
				} catch (q) {
					b =
						(new Promise(function(c, d) {
						return a.getStats(c, d)
					})).then(l.fromRTCStatsResponse)
				}
				return b.then(c.createRTCSample)
			}
		}, {
			"./mockrtcstatsreport": 15
		}
	],
	21: [
		function(b, e, h) {
			function a() {
				Object.defineProperties(this, {
					_eventEmitter: {
						value: new k
					},
					_handlers: {
						value: {}
					}
				})
			}
			var k = b("events").EventEmitter;
			a.prototype.dispatchEvent = function(a) {
				return this._eventEmitter.emit(a.type, a)
			};
			a.prototype.addEventListener = function() {
				return this._eventEmitter.addListener.apply(this._eventEmitter, arguments)
			};
			a.prototype.removeEventListener =
				function() {
					return this._eventEmitter.removeListener.apply(this._eventEmitter, arguments)
			};
			a.prototype._defineEventHandler = function(a) {
				var b = this;
				Object.defineProperty(this, "on" + a, {
					get: function() {
						return b._handlers[a]
					},
					set: function(c) {
						var f = b._handlers[a];
						!f || "function" !== typeof c && "undefined" !== typeof c && null !== c || (b._handlers[a] = null, b.removeEventListener(a, f));
						"function" === typeof c && (b._handlers[a] = c, b.addEventListener(a, c))
					}
				})
			};
			e.exports = a
		}, {
			events: 34
		}
	],
	22: [
		function(b, e, h) {
			e.exports = function(a) {
				Object.defineProperties(this, {
					deviceId: {
						get: function() {
							return a.deviceId
						}
					},
					groupId: {
						get: function() {
							return a.groupId
						}
					},
					kind: {
						get: function() {
							return a.kind
						}
					},
					label: {
						get: function() {
							return a.label
						}
					}
				})
			}
		}, {}
	],
	23: [
		function(b, e, h) {
			function a() {
				p.call(this);
				this._defineEventHandler("devicechange");
				this._defineEventHandler("deviceinfochange");
				var a = [];
				Object.defineProperties(this, {
					_deviceChangeIsNative: {
						value: f(this, "devicechange")
					},
					_deviceInfoChangeIsNative: {
						value: f(this, "deviceinfochange")
					},
					_knownDevices: {
						value: a
					},
					_pollInterval: {
						value: null,
						writable: !0
					}
				});
				"function" === typeof q.enumerateDevices && q.enumerateDevices().then(function(c) {
					c.sort(u).forEach([].push, a)
				});
				this._eventEmitter.on("newListener", function(a) {
					if ("devicechange" === a || "deviceinfochange" === a) this._pollInterval = this._pollInterval || setInterval(g.bind(null, this), 500)
				}.bind(this));
				this._eventEmitter.on("removeListener", function() {
					this._pollInterval && !l(this) && (clearInterval(this._pollInterval), this._pollInterval = null)
				}.bind(this))
			}

			function k(a, c) {
				var d = c.reduce(function(a, c) {
					return a.set(c.deviceId,
						c.label || null)
				}, new Map);
				return a.some(function(a) {
					var c = d.get(a.deviceId);
					return "undefined" !== typeof c && c !== a.label
				})
			}

			function l(a) {
				return 0 < ["devicechange", "deviceinfochange"].reduce(function(c, b) {
					return c + a._eventEmitter.listenerCount(b)
				}, 0)
			}

			function g(a) {
				q.enumerateDevices().then(function(b) {
					var d = a._knownDevices,
						f = d.slice();
					[].splice.apply(d, [0, d.length].concat(b.sort(u)));
					a._deviceChangeIsNative || d.length === f.length && !c("deviceId", d, f) || a.dispatchEvent(new Event("devicechange"));
					!a._deviceInfoChangeIsNative &&
						k(d, f) && a.dispatchEvent(new Event("deviceinfochange"))
				})
			}

			function c(a, c, b) {
				return c.some(function(c, d) {
					return c[a] !== b[d][a]
				})
			}

			function f(a, c) {
				function b(c) {
					a.dispatchEvent(c)
				}
				var d = "on" + c;
				return d in q ? ("addEventListener" in q ? q.addEventListener(c, b) : q[d] = b, !0) : !1
			}

			function u(a, c) {
				return a.deviceId < c.deviceId
			}
			var p = b("./eventtarget");
			b = b("util").inherits;
			var q = "undefined" !== typeof navigator && navigator.mediaDevices;
			b(a, p);
			q && "function" === typeof q.enumerateDevices && (a.prototype.enumerateDevices = function() {
				return q.enumerateDevices.apply(q,
					arguments)
			});
			a.prototype.getUserMedia = function() {
				return q.getUserMedia.apply(q, arguments)
			};
			e.exports = q ? new a : null
		}, {
			"./eventtarget": 21,
			util: 49
		}
	],
	24: [
		function(b, e, h) {
			function a(b, c, f) {
				if (!(this instanceof a)) return new a(b, c, f);
				if (!b || !c) throw Error("name and url are required arguments");
				f = Object.assign({
					AudioFactory: "undefined" !== typeof Audio ? Audio : null,
					maxDuration: 0,
					shouldLoop: !1
				}, f);
				f.AudioPlayer = f.audioContext ? l.bind(l, f.audioContext) : f.AudioFactory;
				Object.defineProperties(this, {
					_activeEls: {
						value: new Set
					},
					_Audio: {
						value: f.AudioPlayer
					},
					_isSinkSupported: {
						value: null !== f.AudioFactory && "function" === typeof f.AudioFactory.prototype.setSinkId
					},
					_maxDuration: {
						value: f.maxDuration
					},
					_maxDurationTimeout: {
						value: null,
						writable: !0
					},
					_playPromise: {
						value: null,
						writable: !0
					},
					_shouldLoop: {
						value: f.shouldLoop
					},
					_sinkIds: {
						value: ["default"]
					},
					isPlaying: {
						enumerable: !0,
						get: function() {
							return !!this._playPromise
						}
					},
					name: {
						enumerable: !0,
						value: b
					},
					url: {
						enumerable: !0,
						value: c
					}
				});
				this._Audio && k(this._Audio, c)
			}

			function k(a, c) {
				a = new a(c);
				a.preload =
					"auto";
				a.muted = !0;
				a.play()
			}
			var l = b("AudioPlayer");
			a.prototype.setSinkIds = function(a) {
				this._isSinkSupported && (a = a.forEach ? a : [a], [].splice.apply(this._sinkIds, [0, this._sinkIds.length].concat(a)))
			};
			a.prototype.stop = function() {
				this._activeEls.forEach(function(a) {
					a.pause();
					a.src = "";
					a.load()
				});
				this._activeEls.clear();
				clearTimeout(this._maxDurationTimeout);
				this._maxDurationTimeout = this._playPromise = null
			};
			a.prototype.play = function() {
				this.isPlaying && this.stop();
				0 < this._maxDuration && (this._maxDurationTimeout =
					setTimeout(this.stop.bind(this), this._maxDuration));
				var a = this,
					c = this._playPromise = Promise.all(this._sinkIds.map(function(b) {
						if (!a._Audio) return Promise.resolve();
						var f = new a._Audio(a.url);
						f.loop = a._shouldLoop;
						f.addEventListener("ended", function() {
							a._activeEls.delete(f)
						});
						return (new Promise(function(a) {
							f.addEventListener("canplaythrough", a)
						})).then(function() {
							return a.isPlaying && a._playPromise === c ? (a._isSinkSupported ? f.setSinkId(b) : Promise.resolve()).then(function() {
								a._activeEls.add(f);
								return f.play()
							}).then(function() {
									return f
								},
								function(c) {
									a._activeEls.delete(f);
									throw c;
								}) : Promise.resolve()
						})
					}));
				return c
			};
			e.exports = a
		}, {
			AudioPlayer: 33
		}
	],
	25: [
		function(b, e, h) {
			function a(b, c) {
				if (!(this instanceof a)) return new a(b, c);
				var f = c;
				Object.defineProperties(this, {
					_currentState: {
						get: function() {
							return f
						},
						set: function(a) {
							f = a
						}
					},
					currentState: {
						enumerable: !0,
						get: function() {
							return f
						}
					},
					states: {
						enumerable: !0,
						value: b
					},
					transitions: {
						enumerable: !0,
						value: []
					}
				});
				Object.freeze(this)
			}

			function k(a, c) {
				Object.defineProperties(this, {
					from: {
						enumerable: !0,
						value: a
					},
					to: {
						enumerable: !0,
						value: c
					}
				})
			}

			function l(a, c) {
				if (!(this instanceof l)) return new l(a, c);
				Error.call(this);
				k.call(this, a, c);
				Object.defineProperties(this, {
					message: {
						enumerable: !0,
						value: "Invalid transition from " + ("string" === typeof a ? '"' + a + '"' : "null") + ' to "' + c + '"'
					}
				});
				Object.freeze(this)
			}
			b = b("util").inherits;
			a.prototype.transition = function(a) {
				var c = this.currentState,
					b = this.states[c],
					c = b && -1 !== b.indexOf(a) ? new k(c, a) : new l(c, a);
				this.transitions.push(c);
				this._currentState = a;
				if (c instanceof l) throw c;
				return this
			};
			b(l, Error);
			e.exports = a
		}, {
			util: 49
		}
	],
	26: [
		function(b, e, h) {
			h.SOUNDS_DEPRECATION_WARNING =
				"Device.sounds is deprecated and will be removed in the next breaking release. Please use the new functionality available on Device.audio.";
			h.generateEventWarning = function(a, b, e) {
				return "The number of " + a + " listeners on " + b + " exceeds the recommended number of " + e +
					". While twilio.js will continue to function normally, this may be indicative of an application error. Note that " + a +
					" listeners exist for the lifetime of the " +
					b + "."
			}
		}, {}
	],
	27: [
		function(b, e, h) {
			function a(c) {
				if (!(this instanceof a)) return new a(c);
				this.message = c
			}

			function k(a) {
				return function() {
					var c = Array.prototype.slice.call(arguments, 0);
					a.memo = a.memo || {};
					a.memo[c] || (a.memo[c] = a.apply(null, c));
					return a.memo[c]
				}
			}

			function l(c) {
				c = c.split(".");
				if (3 !== c.length) throw new a("Wrong number of segments");
				return m(c[1])
			}

			function g(a) {
				if ("" === a) return {};
				if (-1 === a.indexOf("&") && -1 === a.indexOf("=")) return a;
				a = a.split("&");
				for (var c = {}, b = 0; b < a.length; b++) {
					var d = a[b].split("=");
					c[decodeURIComponent(d[0])] = g(decodeURIComponent(d[1]))
				}
				return c
			}

			function c(a) {
				try {
					return btoa(a)
				} catch (v) {
					return (new Buffer(a)).toString("base64")
				}
			}

			function f(a) {
				try {
					return atob(a)
				} catch (v) {
					try {
						return (new Buffer(a, "base64")).toString("ascii")
					} catch (w) {
						return base64.decode(a)
					}
				}
			}

			function u(a, c) {
				return a === c ? !0 : typeof a !== typeof c ? !1 : a instanceof Date && c instanceof Date ? a.getTime() === c.getTime() : "object" !==
					typeof a && "object" !== typeof c ? a === c : p(a, c)
			}

			function p(a, c) {
				if ("undefined" === typeof a || null ===
					a || "undefined" === typeof c || null === c || a.prototype !== c.prototype) return !1;
				try {
					var b = r(a),
						d = r(c)
				} catch (G) {
					return !1
				}
				if (b.length !== d.length) return !1;
				b.sort();
				d.sort();
				for (d = b.length - 1; 0 <= d; d--) {
					var f = b[d];
					if (!u(a[f], c[f])) return !1
				}
				return !0
			}

			function q(a) {
				var c = [],
					b;
				for (b in a) {
					var d = "object" === typeof a[b] ? q(a[b]) : a[b];
					c.push(encodeURIComponent(b) + "=" + encodeURIComponent(d))
				}
			}
			var t = b("events").EventEmitter,
				d = b("./strings").generateEventWarning;
			a.prototype.toString = function() {
				return "Twilio.Exception: " + this.message
			};
			var m = k(function(a) {
				var c = a.length % 4;
				0 < c && (a += Array(4 - c + 1).join("="));
				a = a.replace(/-/g, "+").replace(/_/g, "/");
				a = f(a);
				return JSON.parse(a)
			});
			b = k(function(c) {
				c = l(c);
				for (var b = 0 === c.scope.length ? [] : c.scope.split(" "), d = {}, f = 0; f < b.length; f++) {
					var e;
					e = b[f].match(/^scope:(\w+):(\w+)\??(.*)$/);
					if (!e || 4 !== e.length) throw new a("Bad scope URI");
					e = {
						service: e[1],
						privilege: e[2],
						params: g(e[3])
					};
					d[e.service + ":" + e.privilege] = e
				}
				c.scope = d;
				return c
			});
			var r = "function" === typeof Object.keys ? Object.keys : function(a) {
				var c = [],
					b;
				for (b in a) c.push(b);
				return c
			};
			h.getPStreamVersion = function() {
				return "1.4"
			};
			h.getReleaseVersion = function() {
				return "1.4.27"
			};
			h.getSoundVersion = function() {
				return "1.0.0"
			};
			h.dummyToken = function(a) {
				var b = {
						iss: "AC1111111111111111111111111111111",
						exp: 14E8
					},
					d;
				for (d in b) a[d] = a[d] || b[d];
				a = c(JSON.stringify(a));
				a = a.replace(/=/g, "").replace(/\+/g, "-").replace(/\//g, "_");
				return ["*", a, "*"].join(".")
			};
			h.Exception = a;
			h.decode = l;
			h.btoa = c;
			h.atob = f;
			h.objectize = b;
			h.urlencode = function(a, c) {
				var b = [],
					d;
				c = c || !1;
				for (var f in a)
					if (c &&
						a[f] instanceof Array)
						for (var e in a[f]) d = a[f][e], b.push(encodeURIComponent(f) + "=" + encodeURIComponent(d));
					else d = a[f], b.push(encodeURIComponent(f) + "=" + encodeURIComponent(d));
				return b.join("&")
			};
			h.encodescope = function(a, c, b) {
				a = ["scope", a, c].join(":");
				c = !0;
				for (var d in b) {
					void 0;
					c = !1;
					break
				}
				return c ? a : a + "?" + q(b)
			};
			h.Set = Set;
			h.bind = function(a, c) {
				var b = Array.prototype.slice.call(arguments, 2);
				return function() {
					var d = Array.prototype.slice.call(arguments);
					return a.apply(c, b.concat(d))
				}
			};
			h.getSystemInfo = function() {
				var a =
					"undefined" !== typeof navigator ? navigator : {};
				return {
					p: "browser",
					v: "1.4",
					h: "a885942",
					browser: {
						userAgent: a.userAgent || "unknown",
						platform: a.platform || "unknown"
					},
					plugin: "rtc"
				}
			};
			h.splitObjects = function(a) {
				a = "string" !== typeof a ? "" : a.trim ? a.trim() : a.replace(/^\s+|\s+$/g, "");
				return 0 === a.length ? [] : a.split("\n")
			};
			h.generateConnectionUUID = function() {
				return "TJSxxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx".replace(/[xy]/g, function(a) {
					var c = 16 * Math.random() | 0;
					return ("x" === a ? c : c & 3 | 8).toString(16)
				})
			};
			h.getTwilioRoot = function() {
				return "https://media.twiliocdn.com/sdk/js/client/"
			};
			h.monitorEventEmitter = function(a, c) {
				function b(f) {
					var e = t.listenerCount(c, f);
					f = d(f, a, 10);
					10 <= e && ("undefined" !== typeof console && (console.warn ? console.warn(f) : console.log && console.log(f)), c.removeListener(
						"newListener", b))
				}
				c.setMaxListeners(0);
				c.on("newListener", b)
			};
			h.deepEqual = u;
			h.average = function(a) {
				return a.reduce(function(a, c) {
					return a + c
				}) / a.length
			};
			h.difference = function(a, c, b) {
				b = b || function(a) {
					return a
				};
				var d = new Set(c.map(b));
				return a.filter(function(a) {
					return !d.has(b(a))
				})
			};
			h.isFirefox = function(a) {
				return (a =
					a || ("undefined" === typeof window ? global.navigator : window.navigator)) && "string" === typeof a.userAgent && /firefox|fxios/i.test(
					a.userAgent)
			};
			h.isEdge = function(a) {
				return (a = a || ("undefined" === typeof window ? global.navigator : window.navigator)) && "string" === typeof a.userAgent &&
					/edge\/\d+/i.test(a.userAgent)
			}
		}, {
			"./strings": 26,
			events: 34
		}
	],
	28: [
		function(b, e, h) {
			function a() {}

			function k(b) {
				if (!(this instanceof k)) return new k(b);
				this.sock = null;
				this.onerror = this.onmessage = this.onclose = this.onopen = a;
				var f = {
					logPrefix: "[WSTransport]",
					chunderw: "chunderw-vpc-gll.twilio.com",
					reconnect: !0,
					debug: !1,
					secureSignaling: !0,
					WebSocket: c
				};
				b = b || {};
				for (var e in f) e in b || (b[e] = f[e]);
				this.options = b;
				this._WebSocket = b.WebSocket;
				g.mixinLog(this, this.options.logPrefix);
				this.log.enabled = this.options.debug;
				this.defaultReconnect = this.options.reconnect;
				this.uri = (this.options.secureSignaling ? "wss://" : "ws://") + this.options.host + "/signal";
				return this
			}
			var l = b("./heartbeat").Heartbeat,
				g = b("./log"),
				c = b("ws");
			k.prototype.msgQueue = [];
			k.prototype.open = function(a) {
				this.log("Opening socket");
				this.sock && 2 > this.sock.readyState ? this.log("Socket already open.") : (this.options.reconnect = this.defaultReconnect, this.heartbeat &&
					(this.heartbeat.onsleep = function() {}), this.heartbeat = new l({
						interval: 15
					}), this.sock = this._connect(a))
			};
			k.prototype.send = function(a) {
				if (this.sock)
					if (0 === this.sock.readyState) this.msgQueue.push(a);
					else try {
						this.sock.send(a)
					} catch (u) {
						this.log("Error while sending. Closing socket: " + u.message), this.sock.close()
					}
			};
			k.prototype.close = function() {
				this.log("Closing socket");
				this.options.reconnect = !1;
				this.sock && (this.sock.close(), this.sock = null);
				this.heartbeat && (this.heartbeat.onsleep = function() {})
			};
			k.prototype._cleanupSocket = function(c) {
				c && (this.log("Cleaning up socket"), c.onopen = function() {
					c.close()
				}, c.onmessage = a, c.onerror = a, c.onclose = a, 2 > c.readyState && c.close())
			};
			k.prototype._connect = function(a) {
				var c = ++a || 1;
				this.log("attempting to connect");
				var b = null;
				try {
					b = new this._WebSocket(this.uri)
				} catch (r) {
					return this.onerror({
							code: 31E3,
							message: r.message || "Could not connect to " + this.uri
						}), this.close(),
						null
				}
				var f = this,
					e = this.sock,
					d = null,
					g = setTimeout(function() {
						f.log("connection attempt timed out");
						b.onclose = function() {};
						b.close();
						f.onclose();
						f._tryReconnect(c)
					}, 5E3);
				b.onopen = function() {
					clearTimeout(g);
					f._cleanupSocket(e);
					d = (new Date).getTime();
					f.log("Socket opened");
					f.heartbeat.onsleep = function() {
						f.log("Heartbeat timed out. closing socket");
						f.sock.onclose = function() {};
						f.sock.close();
						f.onclose();
						f._tryReconnect(c)
					};
					f.heartbeat.beat();
					f.onopen();
					for (var a = 0; a < f.msgQueue.length; a++) f.sock.send(f.msgQueue[a]);
					f.msgQueue = []
				};
				b.onclose = function() {
					clearTimeout(g);
					f._cleanupSocket(e);
					f.heartbeat.onsleep = function() {};
					d && 10 < ((new Date).getTime() - d) / 1E3 && (c = 1);
					f.log("Socket closed");
					f.onclose();
					f._tryReconnect(c)
				};
				b.onerror = function(a) {
					f.log("Socket received error: " + a.message);
					f.onerror({
						code: 31E3,
						message: a.message || "WSTransport socket error"
					})
				};
				b.onmessage = function(a) {
					f.heartbeat.beat();
					if ("\n" === a.data) f.send("\n");
					else f.onmessage(a)
				};
				return b
			};
			k.prototype._tryReconnect = function(a) {
				a = a || 0;
				if (this.options.reconnect) {
					this.log("Attempting to reconnect.");
					var c = this,
						b = 0,
						b = 5 > a ? 30 + Math.round(50 * Math.random() * Math.pow(2, a)) : 3E3;
					setTimeout(function() {
						c.open(a)
					}, b)
				}
			};
			h.WSTransport = k
		}, {
			"./heartbeat": 7,
			"./log": 8,
			ws: 29
		}
	],
	29: [
		function(b, e, h) {
			e.exports = WebSocket
		}, {}
	],
	30: [
		function(b, e, h) {
			function a(a, b, e) {
				return k(this, void 0, void 0, function() {
					function c(c, m) {
						for (;;) switch (f) {
							case 0:
								return k = new b, k.open("GET", e, !0), k.responseType = "arraybuffer", f = 1, {
									value: new Promise(function(a) {
										k.addEventListener("load", a);
										k.send()
									}),
									done: !1
								};
							case 1:
								if (void 0 === m) {
									f = 2;
									break
								}
								f = -1;
								throw m;
							case 2:
								g = d = c;
								try {
									return f = -1, {
										value: a.decodeAudioData(g.target.response),
										done: !0
									}
								} catch (w) {
									f = 3;
									break
								}
							case 3:
								return f = -1, {
									value: new Promise(function(c) {
										a.decodeAudioData(g.target.response, c)
									}),
									done: !0
								};
							case 4:
								f = -1;
							default:
								return {
									value: void 0,
									done: !0
								}
						}
					}
					var f = 0,
						g, d, k, h = {
							next: function(a) {
								return c(a, void 0)
							},
							throw : function(a) {
								return c(void 0, a)
							},
							return : function(a) {
								throw Error("Not yet implemented");
							}
						};
					$jscomp.initSymbolIterator();
					h[Symbol.iterator] = function() {
						return this
					};
					return h
				})
			}
			var k = this &&
				this.__awaiter || function(a, b, e, g) {
					return new(e || (e = Promise))(function(c, f) {
						function d(a) {
							try {
								h(g.next(a))
							} catch (v) {
								f(v)
							}
						}

						function k(a) {
							try {
								h(g["throw"](a))
							} catch (v) {
								f(v)
							}
						}

						function h(a) {
							a.done ? c(a.value) : (new e(function(c) {
								c(a.value)
							})).then(d, k)
						}
						h((g = g.apply(a, b || [])).next())
					})
				};
			Object.defineProperty(h, "__esModule", {
				value: !0
			});
			var l = b("./Deferred"),
				g = b("./EventTarget");
			b = function(a, b, e) {
				var c;
				b = void 0 === b ? {} : b;
				e = void 0 === e ? {} : e;
				c = g.default.call(this) || this;
				c._audioNode = null;
				c._pendingPlayDeferreds = [];
				c._loop = !1;
				c._src = "";
				c._sinkId = "default";
				"string" !== typeof b && (e = b);
				c._audioContext = a;
				c._audioElement = new(e.AudioFactory || Audio);
				c._bufferPromise = c._createPlayDeferred().promise;
				c._destination = c._audioContext.destination;
				c._gainNode = c._audioContext.createGain();
				c._gainNode.connect(c._destination);
				c._XMLHttpRequest = e.XMLHttpRequestFactory || XMLHttpRequest;
				c.addEventListener("canplaythrough", function() {
					c._resolvePlayDeferreds()
				});
				"string" === typeof b && (c.src = b);
				return c
			};
			$jscomp.inherits(b, g.default);
			b.prototype.load = function() {
				this._load(this._src)
			};
			b.prototype.pause = function() {
				this.paused || (this._audioElement.pause(), this._audioNode.stop(), this._audioNode.disconnect(this._gainNode), this._audioNode = null,
					this._rejectPlayDeferreds(Error("The play() request was interrupted by a call to pause().")))
			};
			b.prototype.play = function() {
				return k(this, void 0, void 0, function() {
					function a(a, c) {
						for (;;) switch (b) {
							case 0:
								k = h;
								if (h.paused) {
									b = 1;
									break
								}
								b = 2;
								return {
									value: h._bufferPromise,
									done: !1
								};
							case 2:
								if (void 0 === c) {
									b =
										3;
									break
								}
								b = -1;
								throw c;
							case 3:
								if (h.paused) {
									b = 4;
									break
								}
								b = -1;
								return {
									value: void 0,
									done: !0
								};
							case 4:
								throw b = -1, Error("The play() request was interrupted by a call to pause().");
							case 1:
								return h._audioNode = h._audioContext.createBufferSource(), h._audioNode.loop = h.loop, h._audioNode.addEventListener("ended",
									function() {
										k._audioNode && k._audioNode.loop || k.dispatchEvent("ended")
									}), b = 5, {
									value: h._bufferPromise,
									done: !1
								};
							case 5:
								if (void 0 === c) {
									b = 6;
									break
								}
								b = -1;
								throw c;
							case 6:
								e = g = a;
								if (!h.paused) {
									b = 7;
									break
								}
								b = -1;
								throw Error("The play() request was interrupted by a call to pause().");
							case 7:
								h._audioNode.buffer = e;
								h._audioNode.connect(h._gainNode);
								h._audioNode.start();
								if (!h._audioElement.srcObject) {
									b = 8;
									break
								}
								b = -1;
								return {
									value: h._audioElement.play(),
									done: !0
								};
							case 8:
								b = -1;
							default:
								return {
									value: void 0,
									done: !0
								}
						}
					}
					var b = 0,
						e, g, k, h = this,
						d = {
							next: function(c) {
								return a(c, void 0)
							},
							throw : function(c) {
								return a(void 0, c)
							},
							return : function(a) {
								throw Error("Not yet implemented");
							}
						};
					$jscomp.initSymbolIterator();
					d[Symbol.iterator] = function() {
						return this
					};
					return d
				})
			};
			b.prototype.setSinkId = function(a) {
				return k(this,
					void 0, void 0, function() {
						function c(c, d) {
							for (;;) switch (b) {
								case 0:
									if ("function" === typeof e._audioElement.setSinkId) {
										b = 1;
										break
									}
									b = -1;
									throw Error("This browser does not support setSinkId.");
								case 1:
									if (a !== e.sinkId) {
										b = 2;
										break
									}
									b = -1;
									return {
										value: void 0,
										done: !0
									};
								case 2:
									if ("default" !== a) {
										b = 3;
										break
									}
									e.paused || e._gainNode.disconnect(e._destination);
									e._audioElement.srcObject = null;
									e._destination = e._audioContext.destination;
									e._gainNode.connect(e._destination);
									e._sinkId = a;
									b = -1;
									return {
										value: void 0,
										done: !0
									};
								case 3:
									return b =
										4, {
											value: e._audioElement.setSinkId(a),
											done: !1
										};
								case 4:
									if (void 0 === d) {
										b = 5;
										break
									}
									b = -1;
									throw d;
								case 5:
									if (!e._audioElement.srcObject) {
										b = 6;
										break
									}
									b = -1;
									return {
										value: void 0,
										done: !0
									};
								case 6:
									e._gainNode.disconnect(e._audioContext.destination), e._destination = e._audioContext.createMediaStreamDestination(), e._audioElement
										.srcObject = e._destination.stream, e._sinkId = a, e._gainNode.connect(e._destination), b = -1;
								default:
									return {
										value: void 0,
										done: !0
									}
							}
						}
						var b = 0,
							e = this,
							g = {
								next: function(a) {
									return c(a, void 0)
								},
								throw : function(a) {
									return c(void 0,
										a)
								},
								return : function(a) {
									throw Error("Not yet implemented");
								}
							};
						$jscomp.initSymbolIterator();
						g[Symbol.iterator] = function() {
							return this
						};
						return g
					})
			};
			b.prototype._createPlayDeferred = function() {
				var a = new l.default;
				this._pendingPlayDeferreds.push(a);
				return a
			};
			b.prototype._load = function(c) {
				var b = this;
				this._src && this._src !== c && this.pause();
				this._src = c;
				this._bufferPromise = new Promise(function(f, e) {
					return k(b, void 0, void 0, function() {
						function b(b, h) {
							for (;;) switch (e) {
								case 0:
									if (c) {
										e = 1;
										break
									}
									e = -1;
									return {
										value: k._createPlayDeferred().promise,
										done: !0
									};
								case 1:
									return e = 2, {
										value: a(k._audioContext, k._XMLHttpRequest, c),
										done: !1
									};
								case 2:
									if (void 0 === h) {
										e = 3;
										break
									}
									e = -1;
									throw h;
								case 3:
									d = g = b, k.dispatchEvent("canplaythrough"), f(d), e = -1;
								default:
									return {
										value: void 0,
										done: !0
									}
							}
						}
						var e = 0,
							d, g, k = this,
							h = {
								next: function(a) {
									return b(a, void 0)
								},
								throw : function(a) {
									return b(void 0, a)
								},
								return : function(a) {
									throw Error("Not yet implemented");
								}
							};
						$jscomp.initSymbolIterator();
						h[Symbol.iterator] = function() {
							return this
						};
						return h
					})
				})
			};
			b.prototype._rejectPlayDeferreds = function(a) {
				var c =
					this._pendingPlayDeferreds;
				c.splice(0, c.length).forEach(function(c) {
					c = c.reject;
					return c(a)
				})
			};
			b.prototype._resolvePlayDeferreds = function(a) {
				var c = this._pendingPlayDeferreds;
				c.splice(0, c.length).forEach(function(c) {
					c = c.resolve;
					return c(a)
				})
			};
			$jscomp.global.Object.defineProperties(b.prototype, {
				destination: {
					configurable: !0,
					enumerable: !0,
					get: function() {
						return this._destination
					}
				},
				loop: {
					configurable: !0,
					enumerable: !0,
					get: function() {
						return this._loop
					},
					set: function(a) {
						if (!a && this.loop && !this.paused) {
							var c =
								function() {
									b._audioNode.removeEventListener("ended", c);
									b.pause()
								},
								b = this;
							this._audioNode.addEventListener("ended", c)
						}
						this._loop = a
					}
				},
				muted: {
					configurable: !0,
					enumerable: !0,
					get: function() {
						return 0 === this._gainNode.gain.value
					},
					set: function(a) {
						this._gainNode.gain.value = a ? 0 : 1
					}
				},
				paused: {
					configurable: !0,
					enumerable: !0,
					get: function() {
						return null === this._audioNode
					}
				},
				src: {
					configurable: !0,
					enumerable: !0,
					get: function() {
						return this._src
					},
					set: function(a) {
						this._load(a)
					}
				},
				sinkId: {
					configurable: !0,
					enumerable: !0,
					get: function() {
						return this._sinkId
					}
				}
			});
			h.default = b
		}, {
			"./Deferred": 31,
			"./EventTarget": 32
		}
	],
	31: [
		function(b, e, h) {
			Object.defineProperty(h, "__esModule", {
				value: !0
			});
			b = function() {
				var a = this;
				this.promise = new Promise(function(b, e) {
					a._resolve = b;
					a._reject = e
				})
			};
			$jscomp.global.Object.defineProperties(b.prototype, {
				reject: {
					configurable: !0,
					enumerable: !0,
					get: function() {
						return this._reject
					}
				},
				resolve: {
					configurable: !0,
					enumerable: !0,
					get: function() {
						return this._resolve
					}
				}
			});
			h.default = b
		}, {}
	],
	32: [
		function(b, e, h) {
			Object.defineProperty(h, "__esModule", {
				value: !0
			});
			var a = b("events");
			b = function() {
				this._eventEmitter = new a.EventEmitter
			};
			b.prototype.addEventListener = function(a, b) {
				return this._eventEmitter.addListener(a, b)
			};
			b.prototype.dispatchEvent = function(a, b) {
				for (var e = [], c = 1; c < arguments.length; ++c) e[c - 1] = arguments[c];
				return this._eventEmitter.emit.apply(this._eventEmitter, [].concat([a], $jscomp.arrayFromIterable(e)))
			};
			b.prototype.removeEventListener = function(a, b) {
				return this._eventEmitter.removeListener(a, b)
			};
			h.default = b
		}, {
			events: 34
		}
	],
	33: [
		function(b, e, h) {
			b = b("./AudioPlayer");
			e.exports = b.default
		}, {
			"./AudioPlayer": 30
		}
	],
	34: [
		function(b, e, h) {
			function a() {
				this._events = this._events || {};
				this._maxListeners = this._maxListeners || void 0
			}

			function k(a) {
				return "function" === typeof a
			}

			function l(a) {
				return "object" === typeof a && null !== a
			}
			e.exports = a;
			a.EventEmitter = a;
			a.prototype._events = void 0;
			a.prototype._maxListeners = void 0;
			a.defaultMaxListeners = 10;
			a.prototype.setMaxListeners = function(a) {
				if ("number" !== typeof a || 0 > a || isNaN(a)) throw TypeError("n must be a positive number");
				this._maxListeners =
					a;
				return this
			};
			a.prototype.emit = function(a) {
				var c, b, e, g;
				this._events || (this._events = {});
				if ("error" === a && (!this._events.error || l(this._events.error) && !this._events.error.length)) {
					c = arguments[1];
					if (c instanceof Error) throw c;
					b = Error('Uncaught, unspecified "error" event. (' + c + ")");
					b.context = c;
					throw b;
				}
				b = this._events[a];
				if (void 0 === b) return !1;
				if (k(b)) switch (arguments.length) {
					case 1:
						b.call(this);
						break;
					case 2:
						b.call(this, arguments[1]);
						break;
					case 3:
						b.call(this, arguments[1], arguments[2]);
						break;
					default:
						c =
							Array.prototype.slice.call(arguments, 1), b.apply(this, c)
				} else if (l(b))
					for (c = Array.prototype.slice.call(arguments, 1), g = b.slice(), b = g.length, e = 0; e < b; e++) g[e].apply(this, c);
				return !0
			};
			a.prototype.addListener = function(b, c) {
				if (!k(c)) throw TypeError("listener must be a function");
				this._events || (this._events = {});
				this._events.newListener && this.emit("newListener", b, k(c.listener) ? c.listener : c);
				this._events[b] ? l(this._events[b]) ? this._events[b].push(c) : this._events[b] = [this._events[b], c] : this._events[b] = c;
				l(this._events[b]) &&
					!this._events[b].warned && (c = void 0 !== this._maxListeners ? this._maxListeners : a.defaultMaxListeners) && 0 < c && this._events[
						b].length > c && (this._events[b].warned = !0, console.error(
						"(node) warning: possible EventEmitter memory leak detected. %d listeners added. Use emitter.setMaxListeners() to increase limit.",
						this._events[b].length), "function" === typeof console.trace && console.trace());
				return this
			};
			a.prototype.on = a.prototype.addListener;
			a.prototype.once = function(a, c) {
				function b() {
					this.removeListener(a, b);
					e ||
						(e = !0, c.apply(this, arguments))
				}
				if (!k(c)) throw TypeError("listener must be a function");
				var e = !1;
				b.listener = c;
				this.on(a, b);
				return this
			};
			a.prototype.removeListener = function(a, c) {
				var b, e, g;
				if (!k(c)) throw TypeError("listener must be a function");
				if (!this._events || !this._events[a]) return this;
				b = this._events[a];
				g = b.length;
				e = -1;
				if (b === c || k(b.listener) && b.listener === c) delete this._events[a], this._events.removeListener && this.emit("removeListener", a,
					c);
				else if (l(b)) {
					for (; 0 < g--;)
						if (b[g] === c || b[g].listener &&
							b[g].listener === c) {
							e = g;
							break
						}
					if (0 > e) return this;
					1 === b.length ? (b.length = 0, delete this._events[a]) : b.splice(e, 1);
					this._events.removeListener && this.emit("removeListener", a, c)
				}
				return this
			};
			a.prototype.removeAllListeners = function(a) {
				var c;
				if (!this._events) return this;
				if (!this._events.removeListener) return 0 === arguments.length ? this._events = {} : this._events[a] && delete this._events[a], this;
				if (0 === arguments.length) {
					for (c in this._events) "removeListener" !== c && this.removeAllListeners(c);
					this.removeAllListeners("removeListener");
					this._events = {};
					return this
				}
				c = this._events[a];
				if (k(c)) this.removeListener(a, c);
				else if (c)
					for (; c.length;) this.removeListener(a, c[c.length - 1]);
				delete this._events[a];
				return this
			};
			a.prototype.listeners = function(a) {
				return this._events && this._events[a] ? k(this._events[a]) ? [this._events[a]] : this._events[a].slice() : []
			};
			a.prototype.listenerCount = function(a) {
				if (this._events) {
					a = this._events[a];
					if (k(a)) return 1;
					if (a) return a.length
				}
				return 0
			};
			a.listenerCount = function(a, c) {
				return a.listenerCount(c)
			}
		}, {}
	],
	35: [
		function(b,
			e, h) {
			e.exports.RTCIceCandidate = b("./rtcicecandidate");
			e.exports.RTCPeerConnection = b("./rtcpeerconnection");
			e.exports.RTCSessionDescription = b("./rtcsessiondescription")
		}, {
			"./rtcicecandidate": 38,
			"./rtcpeerconnection": 39,
			"./rtcsessiondescription": 41
		}
	],
	36: [
		function(b, e, h) {
			function a(b, e, g, c, f, h, p, q, t, d) {
				if (!(this instanceof a)) return new a(b, e, g, c, f, h, p, q, t, d);
				var k = !1;
				b = b || "0.0.0.0";
				p = "number" === typeof p ? p : 9;
				q = "boolean" === typeof q ? q : !0;
				t = t || null;
				d = d || null;
				Object.defineProperties(this, {
					_address: {
						get: function() {
							return b
						},
						set: function(a) {
							b = a
						}
					},
					_candidates: {
						value: []
					},
					_port: {
						get: function() {
							return p
						},
						set: function(a) {
							p = a
						}
					},
					_rejected: {
						get: function() {
							return k
						},
						set: function(a) {
							k = a
						}
					},
					_streamId: {
						get: function() {
							return t
						},
						set: function(a) {
							t = a
						}
					},
					_track: {
						get: function() {
							return d
						},
						set: function(a) {
							d = a
						}
					},
					_triples: {
						value: new Set
					},
					candidates: {
						enumerable: !0,
						get: function() {
							return this._candidates.slice()
						}
					},
					capabilities: {
						enumerable: !0,
						value: g
					},
					defaultCandidate: {
						enumerable: !0,
						get: function() {
							return this._candidates.length ? this._candidates[0] :
								null
						}
					},
					direction: {
						enumerable: !0,
						value: c
					},
					kind: {
						enumerable: !0,
						value: f
					},
					port: {
						enumerable: !0,
						get: function() {
							return p
						}
					},
					rtcpMux: {
						enumerable: !0,
						value: q
					},
					streamId: {
						enumerable: !0,
						get: function() {
							return t
						}
					},
					track: {
						enumerable: !0,
						get: function() {
							return d
						}
					}
				});
				e && e.forEach(this.addCandidate, this)
			}
			a.prototype.addCandidate = function(a) {
				var b = [a.ip, a.port, a.protocol].join(" ");
				return this._triples.has(b) ? !1 : (this._triples.add(b), this._candidates.push(a), !0)
			};
			a.prototype.copy = function(b, e, g, c, f, h, p) {
				return new a(this.address,
					e, g || this.capabilities, c || this.direction, this.kind, this.mid, f, this.rtcpMux, h, p)
			};
			a.prototype.copyAndReject = function() {
				return (new a(null, this.candidates, this.capabilities, this.direction, this.kind, this.mid, null, this.rtcpMux)).reject()
			};
			a.prototype.reject = function() {
				this.setPort(0);
				return this
			};
			a.prototype.setAddress = function(a) {
				this._address = a;
				return this
			};
			a.prototype.setPort = function(a) {
				this._port = a;
				return this
			};
			e.exports = a
		}, {}
	],
	37: [
		function(b, e, h) {
			function a(b, e) {
				if (!(this instanceof a)) return new a(b,
					e);
				Event.call(this, b, e);
				Object.defineProperties(this, {
					stream: {
						enumerable: !0,
						value: e.stream
					}
				})
			}
			e.exports = a
		}, {}
	],
	38: [
		function(b, e, h) {
			function a(b) {
				if (!(this instanceof a)) return new a(b);
				Object.defineProperties(this, {
					candidate: {
						enumerable: !0,
						value: b.candidate
					},
					sdpMLineIndex: {
						enumerable: !0,
						value: b.sdpMLineIndex
					}
				})
			}
			e.exports = a
		}, {}
	],
	39: [
		function(b, e, h) {
			function a(c) {
				if (!(this instanceof a)) return new a(c);
				c = {
					gatherPolicy: c.gatherPolicy || "all",
					iceServers: []
				};
				var b = new RTCIceGatherer(c),
					d = !1;
				b.onlocalcandidate =
					this._onlocalcandidate.bind(this);
				var e = null,
					f = !1,
					g = 0,
					h = new RTCIceTransport,
					k = null;
				h.onicestatechange = this._onicestatechange.bind(this);
				var q = new RTCDtlsTransport(h);
				q.ondtlsstatechange = this._ondtlsstatechange.bind(this);
				var l = "stable",
					p = null,
					t = null,
					u = null,
					y = null;
				Object.defineProperties(this, {
					_dtlsTransport: {
						value: q
					},
					_dtmfSenders: {
						value: new Map
					},
					_gatherOptions: {
						value: c
					},
					_iceCandidatesAdded: {
						get: function() {
							return g
						},
						set: function(a) {
							g = a
						}
					},
					_iceGatherer: {
						value: b
					},
					_iceGatheringCompleted: {
						get: function() {
							return d
						},
						set: function(a) {
							d = a
						}
					},
					_iceTransport: {
						value: h
					},
					_localCandidates: {
						value: new Set
					},
					_localDescription: {
						get: function() {
							return t
						},
						set: function(a) {
							t = a
						}
					},
					_localStreams: {
						value: new Set
					},
					_midCounters: {
						value: {
							audio: 0,
							video: 0
						}
					},
					_remoteCandidates: {
						value: new Set
					},
					_remoteDescription: {
						get: function() {
							return u
						},
						set: function(a) {
							u = a
						}
					},
					_remoteStreams: {
						value: []
					},
					_rtpReceivers: {
						value: new Map
					},
					_rtpSenders: {
						value: new Map
					},
					_signalingState: {
						get: function() {
							return l
						},
						set: function(a) {
							l = a;
							if (this.onsignalingstatechange) this.onsignalingstatechange()
						}
					},
					_streamIds: {
						value: new Map
					},
					iceConnectionState: {
						enumerable: !0,
						get: function() {
							return h.state
						}
					},
					iceGatheringState: {
						enumerable: !0,
						get: function() {
							return d ? "gathering" : "complete"
						}
					},
					localDescription: {
						enumerable: !0,
						get: function() {
							return t
						}
					},
					onaddstream: {
						enumerable: !0,
						get: function() {
							return y
						},
						set: function(a) {
							y = a
						}
					},
					onicecandidate: {
						enumerable: !0,
						get: function() {
							return e
						},
						set: function(a) {
							e = a;
							if (!f) try {
								b.getLocalCandidates().forEach(b.onlocalcandidate)
							} catch (z) {}
							f = !0
						}
					},
					oniceconnectionstatechange: {
						enumerable: !0,
						get: function() {
							return k
						},
						set: function(a) {
							k = a
						}
					},
					onsignalingstatechange: {
						enumerable: !0,
						get: function() {
							return p
						},
						set: function(a) {
							p = a
						}
					},
					remoteDescription: {
						enumerable: !0,
						get: function() {
							return u
						}
					},
					signalingState: {
						enumerable: !0,
						get: function() {
							return l
						}
					}
				})
			}

			function k(a) {
				return Error("Invalid signaling state: " + a)
			}

			function l(a, c) {
				var b = [];
				a.forEach(function(a) {
					c.forEach(function(c) {
						a.name === c.name && a.clockRate === c.clockRate && a.numChannels === c.numChannels && b.push(c)
					})
				});
				return b
			}
			var g = b("./mediasection"),
				c =
				b("./mediastreamevent"),
				f = b("./rtcicecandidate"),
				u = b("./rtcpeerconnectioniceevent"),
				p = b("./rtcsessiondescription"),
				q = b("sdp-transform"),
				t = b("./sdp-utils");
			a.prototype._makeMid = function(a) {
				return a + ++this._midCounters[a]
			};
			a.prototype._ondtlsstatechange = function(a) {
				void 0
			};
			a.prototype._onicestatechange = function(a) {
				if (this.oniceconnectionstatechange) this.oniceconnectionstatechange(a)
			};
			a.prototype._onlocalcandidate = function(a) {
				Object.keys(a.candidate).length || (this._iceGatheringCompleted = !0);
				this._localCandidates.add(a.candidate);
				if (this.onicecandidate) {
					a = a.candidate;
					if (Object.keys(a).length) {
						var c = ["a=candidate", a.foundation, 1, a.protocol, a.priority, a.ip, a.port, a.type];
						a.relatedAddress && (c = c.concat(["raddr", a.relatedAddress, "rport", a.relatedPort]));
						c.push("generation 0");
						a = new f({
							candidate: c.join(" "),
							sdpMLineIndex: 0
						})
					} else a = null;
					this.onicecandidate(new u("icecandidate", {
						candidate: a
					}))
				}
			};
			a.prototype._sendRtp = function(a) {
				var c = a.kind;
				this._rtpSenders.forEach(function(b) {
					b.track.kind === c && b.send(a.capabilities)
				}, this);
				return this
			};
			a.prototype._sendAndReceiveRtp = function(a) {
				a.forEach(function(a) {
					"sendrecv" !== a.direction && "sendonly" !== a.direction || this._sendRtp(a);
					"sendrecv" !== a.direction && "recvonly" !== a.direction || this._receiveRtp(a)
				}, this);
				return this
			};
			a.prototype._receiveRtp = function(a) {
				var b = new RTCRtpReceiver(this._dtlsTransport, a.capabilities.type);
				b.receive(a.capabilities);
				a = b.track;
				this._rtpReceivers.set(a, b);
				b = new MediaStream;
				b.addTrack(a);
				this._remoteStreams.push(b);
				if (this.onaddstream) this.onaddstream(new c("addstream", {
					stream: b
				}));
				return this
			};
			a.prototype._startDtlsTransport = function(a) {
				this._dtlsTransport.start(a);
				return this
			};
			a.prototype._startIceTransport = function(a) {
				this._iceTransport.start(this._iceGatherer, a, "have-local-offer" === this.signalingState ? "controlling" : "controlled");
				return this
			};
			a.prototype.addIceCandidate = function(a, c, b) {
				if (!c) return new Promise(this.addIceCandidate.bind(this, a));
				void 0;
				this._iceCandidatesAdded++;
				a ? (b = a.candidate.indexOf("candidate:"), a = a.candidate.slice(b + 10).replace(/ +/g, " ").split(" "),
					b = {
						foundation: a[0],
						protocol: a[2],
						priority: parseInt(a[3]),
						ip: a[4],
						port: parseInt(a[5]),
						type: a[7],
						relatedAddress: null,
						relatedPort: 0,
						tcpType: "active"
					}, "host" !== b.type && (b.relatedAddress = a[9], b.relatedPort = parseInt(a[11])), a = b) : a = {};
				b = [a.ip, a.port, a.transport].join(" ");
				this._remoteCandidates.has(b) || (this._remoteCandidates.add(b), this._iceTransport.addRemoteCandidate(a));
				c && c()
			};
			a.prototype.addStream = function(a) {
				this._localStreams.add(a);
				a.getTracks().forEach(function(c) {
					var b = new RTCRtpSender(c, this._dtlsTransport);
					this._rtpSenders.set(c, b);
					this._streamIds.set(c, a.id)
				}, this)
			};
			a.prototype.close = function() {
				this._signalingState = "closed";
				this._rtpReceivers.forEach(function(a) {
					a.stop()
				});
				this._dtlsTransport.stop();
				this._iceTransport.stop()
			};
			a.prototype.createAnswer = function(a, c) {
				if ("function" !== typeof a) return new Promise(this.createAnswer.bind(this));
				if ("have-remote-offer" !== this.signalingState) return void c(k(this.signalingState));
				c = t.parseDescription(this.remoteDescription);
				var b = {
					audio: [],
					video: []
				};
				this.getLocalStreams().forEach(function(a) {
					b.audio =
						b.audio.concat(a.getAudioTracks());
					b.video = b.video.concat(a.getVideoTracks())
				});
				c = c.mediaSections.map(function(a) {
						var c = a.kind,
							d = a.direction,
							e = a.capabilities,
							f = RTCRtpSender.getCapabilities(c),
							f = l(e.codecs, f.codecs),
							e = {
								codecs: f
							},
							g;
						if (!f.length) return a.copyAndReject();
						"inactive" === d || "recvonly" === d && !b[c].length ? c = "inactive" : "recvonly" === d ? (g = b[c].shift(), c = "sendonly") : c =
							"sendrecv" === d ? (g = b[c].shift()) ? "sendrecv" : "recvonly" : "recvonly";
						d = this._streamIds.get(g);
						return a.copy(null, null, e, c, null, d, g)
					},
					this);
				c.forEach(function(a) {
					this._localCandidates.forEach(a.addCandidate, a)
				}, this);
				var d = t.makeInitialSDPBlob();
				t.addMediaSectionsToSDPBlob(d, c);
				t.addIceParametersToSDPBlob(d, this._iceGatherer.getLocalParameters());
				t.addDtlsParametersToSDPBlob(d, this._dtlsTransport.getLocalParameters());
				c = new p({
					sdp: q.write(d),
					type: "answer"
				});
				a(c)
			};
			a.prototype.createDTMFSender = function(a) {
				if (!this._dtmfSenders.has(a)) {
					var c = this._rtpSenders.get(a),
						c = new RTCDtmfSender(c);
					this._dtmfSenders.set(a, c)
				}
				return this._dtmfSenders.get(a)
			};
			a.prototype.createOffer = function(a, c, b) {
				if ("function" !== typeof a) return new Promise(function(c, b) {
					this.createOffer(c, b, a)
				}.bind(this));
				var d = {
						audio: null,
						video: null
					},
					e = {
						audio: 0,
						video: 0
					};
				b = b || {};
				["optional", "mandatory"].forEach(function(a) {
					a in b && ("OfferToReceiveAudio" in b[a] && (d.audio = Number(b[a].OfferToReceiveAudio)), "OfferToReceiveVideo" in b[a] && (d.video =
						Number(b[a].OfferToReceiveVideo)))
				});
				var f = [],
					h = {
						audio: d.audio,
						video: d.video
					};
				this.getLocalStreams().forEach(function(a) {
					var c = a.getAudioTracks(),
						b = a.getVideoTracks();
					e.audio += c.length;
					e.video += b.length;
					c.concat(b).forEach(function(c) {
						var b = c.kind,
							d = RTCRtpSender.getCapabilities(b),
							e, k = this._makeMid(b);
						null === h.audio ? e = "sendrecv" : h[b] ? (h[b]--, e = "sendrecv") : e = "sendonly";
						c = new g(null, null, d, e, b, k, null, null, a.id, c);
						f.push(c)
					}, this)
				}, this);
				["audio", "video"].forEach(function(a) {
					var c = Math.max(d[a] - e[a], 0);
					if (c)
						for (var b = RTCRtpSender.getCapabilities(a), h; c--;) h = this._makeMid(a), h = new g(null, null, b, "recvonly", a, h), f.push(h)
				}, this);
				f.forEach(function(a) {
					this._localCandidates.forEach(a.addCandidate,
						a)
				}, this);
				c = t.makeInitialSDPBlob();
				t.addMediaSectionsToSDPBlob(c, f);
				t.addIceParametersToSDPBlob(c, this._iceGatherer.getLocalParameters());
				t.addDtlsParametersToSDPBlob(c, this._dtlsTransport.getLocalParameters());
				c = new p({
					sdp: q.write(c),
					type: "offer"
				});
				a(c)
			};
			a.prototype.getLocalStreams = function() {
				return Array.from(this._localStreams)
			};
			a.prototype.getRemoteStreams = function() {
				return this._remoteStreams.slice()
			};
			a.prototype.removeStream = function(a) {
				this._localStreams.delete(a);
				a.getTracks().forEach(function(a) {
					this._rtpSenders.get(a).stop();
					this._rtpSenders.delete(a);
					this._streamIds.delete(a)
				}, this)
			};
			a.prototype.setLocalDescription = function(a, c, b) {
				if (!c) return new Promise(this.setLocalDescription.bind(this, a));
				switch (this.signalingState) {
					case "stable":
						b = "have-local-offer";
						break;
					case "have-remote-offer":
						b = "stable";
						break;
					default:
						return void b(k(this.signalingState))
				}
				var d = t.parseDescription(a);
				if ("have-remote-offer" === this.signalingState) {
					d.mediaSections.forEach(this._sendRtp, this);
					var e = t.parseDescription(this.remoteDescription).mediaSections[0].capabilities.encodings[0].ssrc;
					d.mediaSections.forEach(function(a) {
						a.capabilities.encodings.forEach(function(a) {
							a.ssrc = e
						});
						a.capabilities.rtcp.ssrc = e
					});
					d.mediaSections.forEach(this._receiveRtp, this)
				}
				this._localDescription = a;
				this._signalingState = b;
				c()
			};
			a.prototype.setRemoteDescription = function(a, c, b) {
				if (!c) return new Promise(this.setRemoteDescription.bind(this, a));
				switch (this.signalingState) {
					case "stable":
						b = "have-remote-offer";
						break;
					case "have-local-offer":
						b = "stable";
						break;
					default:
						return void b(k(this.signalingState))
				}
				var d = t.parseDescription(a);
				"closed" !== this._iceTransport.state && "completed" !== this._iceTransport.state && (d.mediaSections.forEach(function(a) {
					a.candidates.forEach(this._iceTransport.addRemoteCandidate, this._iceTransport)
				}, this), this._startIceTransport(d.iceParameters[0]), this._startDtlsTransport(d.dtlsParameters[0]));
				"have-local-offer" === this.signalingState && (d.mediaSections.forEach(this._receiveRtp, this), d.mediaSections.forEach(this._sendRtp,
					this));
				this._remoteDescription = a;
				this._signalingState = b;
				c()
			};
			e.exports = a
		}, {
			"./mediasection": 36,
			"./mediastreamevent": 37,
			"./rtcicecandidate": 38,
			"./rtcpeerconnectioniceevent": 40,
			"./rtcsessiondescription": 41,
			"./sdp-utils": 42,
			"sdp-transform": 44
		}
	],
	40: [
		function(b, e, h) {
			function a(b, e) {
				if (!(this instanceof a)) return new a(b, e);
				Event.call(this, b, e);
				Object.defineProperties(this, {
					candidate: {
						enumerable: !0,
						value: e.candidate
					}
				})
			}
			e.exports = a
		}, {}
	],
	41: [
		function(b, e, h) {
			function a(b) {
				if (!(this instanceof a)) return new a(b);
				Object.defineProperties(this, {
					sdp: {
						enumerable: !0,
						value: b.sdp
					},
					type: {
						enumerable: !0,
						value: b.type
					}
				})
			}
			e.exports = a
		}, {}
	],
	42: [
		function(b, e, h) {
			function a(a, c, b) {
				a = a || {};
				a.candidates = a.candidates || [];
				if (!c) return a;
				c.forEach(function(c) {
					if (c.foundation) {
						var d = {
							foundation: c.foundation,
							transport: c.protocol,
							priority: c.priority,
							ip: c.ip,
							port: c.port,
							type: c.type,
							generation: 0
						};
						c.relatedAddress && (d.raddr = c.relatedAddress, d.rport = c.relatedPort);
						if ("number" === typeof b) d.component = b, a.candidates.push(d);
						else {
							d.component = 1;
							a.candidates.push(d);
							c = {};
							for (var e in d) c[e] = d[e];
							c.component = 2;
							a.candidates.push(c)
						}
					} else a.endOfCandidates =
						"end-of-candidates"
				});
				return a
			}

			function k(c, b, d) {
				c = c || {};
				if (!c.media) return c;
				c.media.forEach(function(c) {
					a(c, b, d)
				});
				return c
			}

			function l(a, c) {
				a = a || {};
				if (!a.media) return a;
				a.media.forEach(function(a) {
					a = a || {};
					var b = c.fingerprints;
					b.length && (a.fingerprint = {
						type: b[0].algorithm,
						hash: b[0].value
					})
				});
				return a
			}

			function g(a, c) {
				a = a || {};
				if (!a.media) return a;
				a.media.forEach(function(a) {
					a = a || {};
					a.iceUfrag = c.usernameFragment;
					a.icePwd = c.password
				});
				return a
			}

			function c(c, b) {
				var d = b.streamId;
				d && (c.msidSemantic = c.msidSemantic || {
					semantic: "WMS",
					token: []
				}, c.msidSemantic.token.push(d));
				var e = b.mid;
				if (e) {
					c.groups = c.groups || [];
					var h = !1;
					c.groups.forEach(function(a) {
						"BUNDLE" === a.type && (a.mids.push(e), h = !0)
					});
					h || c.groups.push({
						type: "BUNDLE",
						mids: [e]
					})
				}
				var g = [],
					k = [],
					l = [];
				b.capabilities.codecs.forEach(function(a) {
					var c = a.preferredPayloadType;
					g.push(c);
					var b = {
						payload: c,
						codec: a.name,
						rate: a.clockRate
					};
					1 < a.numChannels && (b.encoding = a.numChannels);
					k.push(b);
					switch (a.name) {
						case "telephone-event":
							a.parameters && a.parameters.events && l.push({
								payload: c,
								config: a.parameters.events
							})
					}
				});
				var q = [];
				if (d && b.track) var d = Math.floor(4294967296 * Math.random()),
					p = f(),
					t = b.track.id,
					q = q.concat([{
						id: d,
						attribute: "cname",
						value: p
					}, {
						id: d,
						attribute: "msid",
						value: b.streamId + " " + t
					}, {
						id: d,
						attribute: "mslabel",
						value: t
					}, {
						id: d,
						attribute: "label",
						value: t
					}]);
				d = b.defaultCandidate;
				q = {
					rtp: k,
					fmtp: l,
					type: b.kind,
					port: d ? d.port : 9,
					payloads: g.join(" "),
					protocol: "RTP/SAVPF",
					direction: b.direction,
					connection: {
						version: 4,
						ip: d ? d.ip : "0.0.0.0"
					},
					rtcp: {
						port: d ? d.port : 9,
						netType: "IN",
						ipVer: 4,
						address: d ?
							d.ip : "0.0.0.0"
					},
					ssrcs: q
				};
				e && (q.mid = e);
				b.rtcpMux && (q.rtcpMux = "rtcp-mux");
				a(q, b.candidates);
				c.media.push(q);
				return c
			}

			function f() {
				for (var a = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789+/".split(""), c = 16, b = ""; c--;) b += a[Math.floor(
					Math.random() * a.length)];
				return b
			}
			var u = b("./mediasection"),
				p = b("sdp-transform");
			e.exports.addCandidatesToSDPBlob = function(a, c, b) {
				a = a || {};
				k(a, c, b);
				return a
			};
			e.exports.addDtlsParametersToSDPBlob = function(a, c) {
				a = a || {};
				l(a, c);
				return a
			};
			e.exports.addIceParametersToSDPBlob =
				function(a, c) {
					a = a || {};
					g(a, c);
					return a
			};
			e.exports.addMediaSectionsToSDPBlob = function(a, b) {
				b.forEach(c.bind(null, a));
				return a
			};
			e.exports.makeInitialSDPBlob = function(a) {
				a = a || Math.floor(4294967296 * Math.random());
				return {
					version: 0,
					origin: {
						username: "-",
						sessionId: a,
						sessionVersion: 0,
						netType: "IN",
						ipVer: 4,
						address: "127.0.0.1"
					},
					name: "-",
					timing: {
						start: 0,
						stop: 0
					},
					connection: {
						version: 4,
						ip: "0.0.0.0"
					},
					media: []
				}
			};
			e.exports.parseDescription = function(a) {
				a = p.parse(a.sdp);
				var c = [],
					b = [],
					e = [],
					f = [],
					h = [a];
				a.media && (h = h.concat(a.media));
				h.forEach(function(a) {
					a.iceUfrag && a.icePwd && a.fingerprint && (c.push({
						usernameFragment: a.iceUfrag,
						password: a.icePwd
					}), b.push({
						fingerprints: [{
							algorithm: a.fingerprint.type,
							value: a.fingerprint.hash
						}]
					}));
					if (a.rtp && "video" !== a.type) {
						var d = a.connection ? a.connection.ip : null,
							h = a.direction,
							g = a.type,
							k = a.mid,
							l = a.port || null,
							m = "rtcp-mux" === a.rtcpMux,
							p, n, q;
						(a.ssrcs || []).forEach(function(a) {
							switch (a.attribute) {
								case "cname":
									n = a.id;
									p = a.value;
									break;
								case "label":
								case "mslabel":
									n = a.id;
									break;
								case "msid":
									n = a.id, q = a.value.split(" ")[0]
							}
						});
						var t = {
								type: g,
								muxId: k,
								codecs: a.rtp.map(function(a) {
									var c = {
										name: a.codec,
										payloadType: parseInt(a.payload),
										clockRate: parseInt(a.rate),
										numChannels: a.encoding || 1,
										rtcpFeedback: [],
										parameters: {}
									};
									switch (a.codec) {
										case "telephone-event":
											c.parameters.events = "0-16"
									}
									return c
								}),
								headerExtensions: [],
								encodings: a.rtp.map(function(a) {
									return {
										ssrc: n,
										codecPayloadType: parseInt(a.payload),
										active: !0
									}
								}),
								rtcp: {
									ssrc: n,
									cname: p,
									mux: m
								}
							},
							r = new u(d, e, t, h, g, k, l, m, q);
						(a.candidates || []).forEach(function(a) {
							a = {
								foundation: String(a.foundation),
								protocol: a.transport,
								priority: a.priority,
								ip: a.ip,
								port: a.port,
								type: a.type,
								relatedAddress: a.raddr,
								relatedPort: a.rport
							};
							e.push(a);
							r.addCandidate(a)
						});
						void 0;
						"end-of-candidates" === a.endOfCandidates && r.addCandidate({});
						f.push(r)
					}
				});
				return {
					iceParameters: c,
					dtlsParameters: b,
					mediaSections: f
				}
			}
		}, {
			"./mediasection": 36,
			"sdp-transform": 44
		}
	],
	43: [
		function(b, e, h) {
			var a = e.exports = {
				v: [{
					name: "version",
					reg: /^(\d*)$/
				}],
				o: [{
					name: "origin",
					reg: /^(\S*) (\d*) (\d*) (\S*) IP(\d) (\S*)/,
					names: "username sessionId sessionVersion netType ipVer address".split(" "),
					format: "%s %s %d %s IP%d %s"
				}],
				s: [{
					name: "name"
				}],
				i: [{
					name: "description"
				}],
				u: [{
					name: "uri"
				}],
				e: [{
					name: "email"
				}],
				p: [{
					name: "phone"
				}],
				z: [{
					name: "timezones"
				}],
				r: [{
					name: "repeats"
				}],
				t: [{
					name: "timing",
					reg: /^(\d*) (\d*)/,
					names: ["start", "stop"],
					format: "%d %d"
				}],
				c: [{
					name: "connection",
					reg: /^IN IP(\d) (\S*)/,
					names: ["version", "ip"],
					format: "IN IP%d %s"
				}],
				b: [{
					push: "bandwidth",
					reg: /^(TIAS|AS|CT|RR|RS):(\d*)/,
					names: ["type", "limit"],
					format: "%s:%s"
				}],
				m: [{
					reg: /^(\w*) (\d*) ([\w\/]*)(?: (.*))?/,
					names: ["type", "port", "protocol",
						"payloads"
					],
					format: "%s %d %s %s"
				}],
				a: [{
					push: "rtp",
					reg: /^rtpmap:(\d*) ([\w\-\.]*)(?:\s*\/(\d*)(?:\s*\/(\S*))?)?/,
					names: ["payload", "codec", "rate", "encoding"],
					format: function(a) {
						return a.encoding ? "rtpmap:%d %s/%s/%s" : a.rate ? "rtpmap:%d %s/%s" : "rtpmap:%d %s"
					}
				}, {
					push: "fmtp",
					reg: /^fmtp:(\d*) ([\S| ]*)/,
					names: ["payload", "config"],
					format: "fmtp:%d %s"
				}, {
					name: "control",
					reg: /^control:(.*)/,
					format: "control:%s"
				}, {
					name: "rtcp",
					reg: /^rtcp:(\d*)(?: (\S*) IP(\d) (\S*))?/,
					names: ["port", "netType", "ipVer", "address"],
					format: function(a) {
						return null !=
							a.address ? "rtcp:%d %s IP%d %s" : "rtcp:%d"
					}
				}, {
					push: "rtcpFbTrrInt",
					reg: /^rtcp-fb:(\*|\d*) trr-int (\d*)/,
					names: ["payload", "value"],
					format: "rtcp-fb:%d trr-int %d"
				}, {
					push: "rtcpFb",
					reg: /^rtcp-fb:(\*|\d*) ([\w-_]*)(?: ([\w-_]*))?/,
					names: ["payload", "type", "subtype"],
					format: function(a) {
						return null != a.subtype ? "rtcp-fb:%s %s %s" : "rtcp-fb:%s %s"
					}
				}, {
					push: "ext",
					reg: /^extmap:([\w_\/]*) (\S*)(?: (\S*))?/,
					names: ["value", "uri", "config"],
					format: function(a) {
						return null != a.config ? "extmap:%s %s %s" : "extmap:%s %s"
					}
				}, {
					push: "crypto",
					reg: /^crypto:(\d*) ([\w_]*) (\S*)(?: (\S*))?/,
					names: ["id", "suite", "config", "sessionConfig"],
					format: function(a) {
						return null != a.sessionConfig ? "crypto:%d %s %s %s" : "crypto:%d %s %s"
					}
				}, {
					name: "setup",
					reg: /^setup:(\w*)/,
					format: "setup:%s"
				}, {
					name: "mid",
					reg: /^mid:([^\s]*)/,
					format: "mid:%s"
				}, {
					name: "msid",
					reg: /^msid:(.*)/,
					format: "msid:%s"
				}, {
					name: "ptime",
					reg: /^ptime:(\d*)/,
					format: "ptime:%d"
				}, {
					name: "maxptime",
					reg: /^maxptime:(\d*)/,
					format: "maxptime:%d"
				}, {
					name: "direction",
					reg: /^(sendrecv|recvonly|sendonly|inactive)/
				}, {
					name: "icelite",
					reg: /^(ice-lite)/
				}, {
					name: "iceUfrag",
					reg: /^ice-ufrag:(\S*)/,
					format: "ice-ufrag:%s"
				}, {
					name: "icePwd",
					reg: /^ice-pwd:(\S*)/,
					format: "ice-pwd:%s"
				}, {
					name: "fingerprint",
					reg: /^fingerprint:(\S*) (\S*)/,
					names: ["type", "hash"],
					format: "fingerprint:%s %s"
				}, {
					push: "candidates",
					reg: /^candidate:(\S*) (\d*) (\S*) (\d*) (\S*) (\d*) typ (\S*)(?: raddr (\S*) rport (\d*))?(?: tcptype (\S*))?(?: generation (\d*))?(?: network-id (\d*))?(?: network-cost (\d*))?/,
					names: "foundation component transport priority ip port type raddr rport tcptype generation network-id network-cost".split(" "),
					format: function(a) {
						var b;
						b = "candidate:%s %d %s %d %s %d typ %s" + (null != a.raddr ? " raddr %s rport %d" : "%v%v");
						b += null != a.tcptype ? " tcptype %s" : "%v";
						null != a.generation && (b += " generation %d");
						b += null != a["network-id"] ? " network-id %d" : "%v";
						return b += null != a["network-cost"] ? " network-cost %d" : "%v"
					}
				}, {
					name: "endOfCandidates",
					reg: /^(end-of-candidates)/
				}, {
					name: "remoteCandidates",
					reg: /^remote-candidates:(.*)/,
					format: "remote-candidates:%s"
				}, {
					name: "iceOptions",
					reg: /^ice-options:(\S*)/,
					format: "ice-options:%s"
				}, {
					push: "ssrcs",
					reg: /^ssrc:(\d*) ([\w_]*)(?::(.*))?/,
					names: ["id", "attribute", "value"],
					format: function(a) {
						var b = "ssrc:%d";
						null != a.attribute && (b += " %s", null != a.value && (b += ":%s"));
						return b
					}
				}, {
					push: "ssrcGroups",
					reg: /^ssrc-group:(\w*) (.*)/,
					names: ["semantics", "ssrcs"],
					format: "ssrc-group:%s %s"
				}, {
					name: "msidSemantic",
					reg: /^msid-semantic:\s?(\w*) (\S*)/,
					names: ["semantic", "token"],
					format: "msid-semantic: %s %s"
				}, {
					push: "groups",
					reg: /^group:(\w*) (.*)/,
					names: ["type", "mids"],
					format: "group:%s %s"
				}, {
					name: "rtcpMux",
					reg: /^(rtcp-mux)/
				}, {
					name: "rtcpRsize",
					reg: /^(rtcp-rsize)/
				}, {
					name: "sctpmap",
					reg: /^sctpmap:([\w_\/]*) (\S*)(?: (\S*))?/,
					names: ["sctpmapNumber", "app", "maxMessageSize"],
					format: function(a) {
						return null != a.maxMessageSize ? "sctpmap:%s %s %s" : "sctpmap:%s %s"
					}
				}, {
					push: "invalid",
					names: ["value"]
				}]
			};
			Object.keys(a).forEach(function(b) {
				a[b].forEach(function(a) {
					a.reg || (a.reg = /(.*)/);
					a.format || (a.format = "%s")
				})
			})
		}, {}
	],
	44: [
		function(b, e, h) {
			e = b("./parser");
			b = b("./writer");
			h.write = b;
			h.parse = e.parse;
			h.parseFmtpConfig = e.parseFmtpConfig;
			h.parsePayloads = e.parsePayloads;
			h.parseRemoteCandidates = e.parseRemoteCandidates
		}, {
			"./parser": 45,
			"./writer": 46
		}
	],
	45: [
		function(b, e, h) {
			var a = function(a) {
					return String(Number(a)) === a ? Number(a) : a
				},
				k = b("./grammar"),
				l = RegExp.prototype.test.bind(/^([a-z])=(.*)/);
			h.parse = function(c) {
				var b = {},
					e = [],
					h = b;
				c.split(/(\r\n|\r|\n)/).filter(l).forEach(function(c) {
					var b = c[0],
						d = c.slice(2);
					"m" === b && (e.push({
						rtp: [],
						fmtp: []
					}), h = e[e.length - 1]);
					for (c = 0; c < (k[b] || []).length; c += 1) {
						var f = k[b][c];
						if (f.reg.test(d)) {
							b = f;
							c = h;
							f = d;
							d = b.name && b.names;
							b.push && !c[b.push] ? c[b.push] = [] : d && !c[b.name] && (c[b.name] = {});
							var d = b.push ? {} : d ? c[b.name] : c,
								f = f.match(b.reg),
								g = d,
								l = b.names,
								p = b.name;
							if (p && !l) g[p] = a(f[1]);
							else
								for (p = 0; p < l.length; p += 1) null != f[p + 1] && (g[l[p]] = a(f[p + 1]));
							b.push && c[b.push].push(d);
							break
						}
					}
				});
				b.media = e;
				return b
			};
			var g = function(c, b) {
				b = b.split(/=(.+)/, 2);
				2 === b.length && (c[b[0]] = a(b[1]));
				return c
			};
			h.parseFmtpConfig = function(a) {
				return a.split(/\;\s?/).reduce(g, {})
			};
			h.parsePayloads = function(a) {
				return a.split(" ").map(Number)
			};
			h.parseRemoteCandidates = function(c) {
				var b = [];
				c = c.split(" ").map(a);
				for (var e = 0; e < c.length; e += 3) b.push({
					component: c[e],
					ip: c[e + 1],
					port: c[e + 2]
				});
				return b
			}
		}, {
			"./grammar": 43
		}
	],
	46: [
		function(b, e, h) {
			var a = b("./grammar"),
				k = /%[sdv%]/g,
				l = function(a) {
					var c = 1,
						b = arguments,
						e = b.length;
					return a.replace(k, function(a) {
						if (c >= e) return a;
						var d = b[c];
						c += 1;
						switch (a) {
							case "%%":
								return "%";
							case "%s":
								return String(d);
							case "%d":
								return Number(d);
							case "%v":
								return ""
						}
					})
				},
				g = function(a, c, b) {
					var e = c.format instanceof Function ? c.format(c.push ?
						b : b[c.name]) : c.format;
					a = [a + "=" + e];
					if (c.names)
						for (e = 0; e < c.names.length; e += 1) {
							var d = c.names[e];
							c.name ? a.push(b[c.name][d]) : a.push(b[c.names[e]])
						} else a.push(b[c.name]);
					return l.apply(null, a)
				},
				c = "vosiuepcbtrza".split(""),
				f = ["i", "c", "b", "a"];
			e.exports = function(b, e) {
				e = e || {};
				null == b.version && (b.version = 0);
				null == b.name && (b.name = " ");
				b.media.forEach(function(a) {
					null == a.payloads && (a.payloads = "")
				});
				var h = e.innerOrder || f,
					k = [];
				(e.outerOrder || c).forEach(function(c) {
					a[c].forEach(function(a) {
						a.name in b && null !=
							b[a.name] ? k.push(g(c, a, b)) : a.push in b && null != b[a.push] && b[a.push].forEach(function(b) {
								k.push(g(c, a, b))
							})
					})
				});
				b.media.forEach(function(c) {
					k.push(g("m", a.m[0], c));
					h.forEach(function(b) {
						a[b].forEach(function(a) {
							a.name in c && null != c[a.name] ? k.push(g(b, a, c)) : a.push in c && null != c[a.push] && c[a.push].forEach(function(c) {
								k.push(g(b, a, c))
							})
						})
					})
				});
				return k.join("\r\n") + "\r\n"
			}
		}, {
			"./grammar": 43
		}
	],
	47: [
		function(b, e, h) {
			e.exports = "function" === typeof Object.create ? function(a, b) {
				a.super_ = b;
				a.prototype = Object.create(b.prototype, {
					constructor: {
						value: a,
						enumerable: !1,
						writable: !0,
						configurable: !0
					}
				})
			} : function(a, b) {
				a.super_ = b;
				var e = function() {};
				e.prototype = b.prototype;
				a.prototype = new e;
				a.prototype.constructor = a
			}
		}, {}
	],
	48: [
		function(b, e, h) {
			e.exports = function(a) {
				return a && "object" === typeof a && "function" === typeof a.copy && "function" === typeof a.fill && "function" === typeof a.readUInt8
			}
		}, {}
	],
	49: [
		function(b, e, h) {
			function a(a, b) {
				var d = {
					seen: [],
					stylize: l
				};
				3 <= arguments.length && (d.depth = arguments[2]);
				4 <= arguments.length && (d.colors = arguments[3]);
				m(b) ? d.showHidden = b : b && h._extend(d, b);
				v(d.showHidden) && (d.showHidden = !1);
				v(d.depth) && (d.depth = 2);
				v(d.colors) && (d.colors = !1);
				v(d.customInspect) && (d.customInspect = !0);
				d.colors && (d.stylize = k);
				return c(d, a, d.depth)
			}

			function k(c, b) {
				return (b = a.styles[b]) ? "\u001b[" + a.colors[b][0] + "m" + c + "\u001b[" + a.colors[b][1] + "m" : c
			}

			function l(a, c) {
				return a
			}

			function g(a) {
				var c = {};
				a.forEach(function(a, b) {
					c[a] = !0
				});
				return c
			}

			function c(a, b, e) {
				if (a.customInspect && b && H(b.inspect) && b.inspect !== h.inspect && (!b.constructor || b.constructor.prototype !==
					b)) {
					var k = b.inspect(e, a);
					n(k) || (k = c(a, k, e));
					return k
				}
				if (k = f(a, b)) return k;
				var l = Object.keys(b),
					m = g(l);
				a.showHidden && (l = Object.getOwnPropertyNames(b));
				if (G(b) && (0 <= l.indexOf("message") || 0 <= l.indexOf("description"))) return u(b);
				if (0 === l.length) {
					if (H(b)) return a.stylize("[Function" + (b.name ? ": " + b.name : "") + "]", "special");
					if (w(b)) return a.stylize(RegExp.prototype.toString.call(b), "regexp");
					if (F(b)) return a.stylize(Date.prototype.toString.call(b), "date");
					if (G(b)) return u(b)
				}
				var k = "",
					E = !1,
					r = ["{", "}"];
				d(b) &&
					(E = !0, r = ["[", "]"]);
				H(b) && (k = " [Function" + (b.name ? ": " + b.name : "") + "]");
				w(b) && (k = " " + RegExp.prototype.toString.call(b));
				F(b) && (k = " " + Date.prototype.toUTCString.call(b));
				G(b) && (k = " " + u(b));
				if (0 === l.length && (!E || 0 == b.length)) return r[0] + k + r[1];
				if (0 > e) return w(b) ? a.stylize(RegExp.prototype.toString.call(b), "regexp") : a.stylize("[Object]", "special");
				a.seen.push(b);
				l = E ? p(a, b, e, m, l) : l.map(function(c) {
					return q(a, b, e, m, c, E)
				});
				a.seen.pop();
				return t(l, k, r)
			}

			function f(a, b) {
				if (v(b)) return a.stylize("undefined",
					"undefined");
				if (n(b)) return b = "'" + JSON.stringify(b).replace(/^"|"$/g, "").replace(/'/g, "\\'").replace(/\\"/g, '"') + "'", a.stylize(b,
					"string");
				if (r(b)) return a.stylize("" + b, "number");
				if (m(b)) return a.stylize("" + b, "boolean");
				if (null === b) return a.stylize("null", "null")
			}

			function u(a) {
				return "[" + Error.prototype.toString.call(a) + "]"
			}

			function p(a, b, c, d, e) {
				for (var f = [], h = 0, g = b.length; h < g; ++h) Object.prototype.hasOwnProperty.call(b, String(h)) ? f.push(q(a, b, c, d, String(h), !
					0)) : f.push("");
				e.forEach(function(e) {
					e.match(/^\d+$/) ||
						f.push(q(a, b, c, d, e, !0))
				});
				return f
			}

			function q(a, b, d, e, f, h) {
				var g, k;
				b = Object.getOwnPropertyDescriptor(b, f) || {
					value: b[f]
				};
				b.get ? k = b.set ? a.stylize("[Getter/Setter]", "special") : a.stylize("[Getter]", "special") : b.set && (k = a.stylize("[Setter]",
					"special"));
				Object.prototype.hasOwnProperty.call(e, f) || (g = "[" + f + "]");
				k || (0 > a.seen.indexOf(b.value) ? (k = null === d ? c(a, b.value, null) : c(a, b.value, d - 1), -1 < k.indexOf("\n") && (k = h ? k.split(
					"\n").map(function(a) {
					return "  " + a
				}).join("\n").substr(2) : "\n" + k.split("\n").map(function(a) {
					return "   " +
						a
				}).join("\n"))) : k = a.stylize("[Circular]", "special"));
				if (v(g)) {
					if (h && f.match(/^\d+$/)) return k;
					g = JSON.stringify("" + f);
					g.match(/^"([a-zA-Z_][a-zA-Z_0-9]*)"$/) ? (g = g.substr(1, g.length - 2), g = a.stylize(g, "name")) : (g = g.replace(/'/g, "\\'").replace(
						/\\"/g, '"').replace(/(^"|"$)/g, "'"), g = a.stylize(g, "string"))
				}
				return g + ": " + k
			}

			function t(a, b, c) {
				var d = 0;
				return 60 < a.reduce(function(a, b) {
						d++;
						0 <= b.indexOf("\n") && d++;
						return a + b.replace(/\u001b\[\d\d?m/g, "").length + 1
					}, 0) ? c[0] + ("" === b ? "" : b + "\n ") + " " + a.join(",\n  ") +
					" " + c[1] : c[0] + b + " " + a.join(", ") + " " + c[1]
			}

			function d(a) {
				return Array.isArray(a)
			}

			function m(a) {
				return "boolean" === typeof a
			}

			function r(a) {
				return "number" === typeof a
			}

			function n(a) {
				return "string" === typeof a
			}

			function v(a) {
				return void 0 === a
			}

			function w(a) {
				return B(a) && "[object RegExp]" === Object.prototype.toString.call(a)
			}

			function B(a) {
				return "object" === typeof a && null !== a
			}

			function F(a) {
				return B(a) && "[object Date]" === Object.prototype.toString.call(a)
			}

			function G(a) {
				return B(a) && ("[object Error]" === Object.prototype.toString.call(a) ||
					a instanceof Error)
			}

			function H(a) {
				return "function" === typeof a
			}

			function A(a) {
				return 10 > a ? "0" + a.toString(10) : a.toString(10)
			}

			function x() {
				var a = new Date,
					b = [A(a.getHours()), A(a.getMinutes()), A(a.getSeconds())].join(":");
				return [a.getDate(), z[a.getMonth()], b].join(" ")
			}
			var C = /%[sdj%]/g;
			h.format = function(b) {
				if (!n(b)) {
					for (var c = [], d = 0; d < arguments.length; d++) c.push(a(arguments[d]));
					return c.join(" ")
				}
				for (var d = 1, e = arguments, f = e.length, c = String(b).replace(C, function(a) {
					if ("%%" === a) return "%";
					if (d >= f) return a;
					switch (a) {
						case "%s":
							return String(e[d++]);
						case "%d":
							return Number(e[d++]);
						case "%j":
							try {
								return JSON.stringify(e[d++])
							} catch (K) {
								return "[Circular]"
							}
						default:
							return a
					}
				}), g = e[d]; d < f; g = e[++d]) c = null !== g && B(g) ? c + (" " + a(g)) : c + (" " + g);
				return c
			};
			h.deprecate = function(a, b) {
				if (v(global.process)) return function() {
					return h.deprecate(a, b).apply(this, arguments)
				};
				if (!0 === process.noDeprecation) return a;
				var c = !1;
				return function() {
					if (!c) {
						if (process.throwDeprecation) throw Error(b);
						process.traceDeprecation ? console.trace(b) :
							console.error(b);
						c = !0
					}
					return a.apply(this, arguments)
				}
			};
			var y = {},
				D;
			h.debuglog = function(a) {
				v(D) && (D = process.env.NODE_DEBUG || "");
				a = a.toUpperCase();
				if (!y[a])
					if ((new RegExp("\\b" + a + "\\b", "i")).test(D)) {
						var b = process.pid;
						y[a] = function() {
							var c = h.format.apply(h, arguments);
							console.error("%s %d: %s", a, b, c)
						}
					} else y[a] = function() {};
				return y[a]
			};
			h.inspect = a;
			a.colors = {
				bold: [1, 22],
				italic: [3, 23],
				underline: [4, 24],
				inverse: [7, 27],
				white: [37, 39],
				grey: [90, 39],
				black: [30, 39],
				blue: [34, 39],
				cyan: [36, 39],
				green: [32, 39],
				magenta: [35,
					39
				],
				red: [31, 39],
				yellow: [33, 39]
			};
			a.styles = {
				special: "cyan",
				number: "yellow",
				"boolean": "yellow",
				undefined: "grey",
				"null": "bold",
				string: "green",
				date: "magenta",
				regexp: "red"
			};
			h.isArray = d;
			h.isBoolean = m;
			h.isNull = function(a) {
				return null === a
			};
			h.isNullOrUndefined = function(a) {
				return null == a
			};
			h.isNumber = r;
			h.isString = n;
			h.isSymbol = function(a) {
				return "symbol" === typeof a
			};
			h.isUndefined = v;
			h.isRegExp = w;
			h.isObject = B;
			h.isDate = F;
			h.isError = G;
			h.isFunction = H;
			h.isPrimitive = function(a) {
				return null === a || "boolean" === typeof a || "number" ===
					typeof a || "string" === typeof a || "symbol" === typeof a || "undefined" === typeof a
			};
			h.isBuffer = b("./support/isBuffer");
			var z = "Jan Feb Mar Apr May Jun Jul Aug Sep Oct Nov Dec".split(" ");
			h.log = function() {
				console.log("%s - %s", x(), h.format.apply(h, arguments))
			};
			h.inherits = b("inherits");
			h._extend = function(a, b) {
				if (!b || !B(b)) return a;
				for (var c = Object.keys(b), d = c.length; d--;) a[c[d]] = b[c[d]];
				return a
			}
		}, {
			"./support/isBuffer": 48,
			inherits: 47
		}
	],
	50: [
		function(b, e, h) {
			h.XMLHttpRequest = XMLHttpRequest
		}, {}
	]
}, {}, [1]);