jQuery.sap.require("chep.checkin.model.Formatter");
sap.ui.define([], function() {
	"use strict";

	return {
		PlantChange: function(parentPlant, childPlant, name) {

			if (parentPlant !== "") {
			 var sParentPlant = name ;
			 return sParentPlant;
			} else {
			 var sChildPlant = childPlant + " - " + name ;
			 return sChildPlant;
			}

		}

	};

});