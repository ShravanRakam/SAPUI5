var loggedUser;
var empNameID;
var vLoadPlant;
var sPassthrough;
var sDocId;
var oInsCreateDailog;
var sLocation;
var sOrdertype;
var oRouterObject;
var kioskId;
var sLanguage;
var listDelvDialog;
var sCHEPOrders;
var milkRunFlag;
var pAddDelivery;
var sChDateFormat;
var sVendor;
var vDropservice;
var sRegion;
var sHaulierFlg;
var vAuthorized;
var sForMobValid;
/*For Tip Reload*/
var sPreloadOrder;
var delNumFlag;
var sDropHook;
var vCHtrilerid;
var vHaulierName;
var vDhservice;
var pgmodel;
var sParentPlant;
var oTriploadUA;
var oHeaderUAflag;
var oUAbtnFlag;
var tUAbtnFlagtr;
var shDel;
var yardStopFlag;

sap.ui.define([
	"sap/ui/core/mvc/Controller",
	"sap/m/MessageToast",
	"sap/m/MessageBox",
	"sap/ui/model/json/JSONModel",
	"chep/checkin/model/formatter"
], function(Controller, MessageToast, MessageBox, JSONModel, formatter) {
	"use strict";
	return Controller.extend("chep.checkin.controller.CheckIn", {

		formatter: formatter,

		onInit: function() {
			jQuery.sap.require("jquery.sap.storage");
			var that = this;
			this.setInitialFocus(this.byId("deliverynum"));
			var oRouter = sap.ui.core.UIComponent.getRouterFor(this);
			that.fnCreateBusyDialog("pallet.svg");
			pgmodel = new JSONModel({ // start - model used for displaying the page numbers
				"pgStart": "0",
				"pgEnd": "0"
			});
			that.getView().setModel(pgmodel, "pgmodel");
			var y = "/sap/bc/ui2/start_up";
			var xmlHttp = null;
			xmlHttp = new XMLHttpRequest();
			xmlHttp.onreadystatechange = function() {
				if (xmlHttp.readyState === 4 && xmlHttp.status === 200) {
					var oUserData = JSON.parse(xmlHttp.responseText);
					loggedUser = oUserData.id;
					empNameID = oUserData.fullName;
					sChDateFormat = oUserData.dateFormat;
					that.getView().byId("empNameID").setText(empNameID);
					//	that.getView().byId("pageNo").setText("2 of 5");
					that.getView().getModel("pgmodel").setProperty("/pgStart", "2");
					that.getView().getModel("pgmodel").setProperty("/pgEnd", "5");
				}
			};
			sLanguage = jQuery.sap.storage(jQuery.sap.storage.Type.local).get("sysLang");
			MessageBox._rb = sap.ui.getCore().getLibraryResourceBundle("sap.m", sLanguage);
			kioskId = jQuery.sap.storage(jQuery.sap.storage.Type.local).get("KioskId");
			that.getView().byId("langId").setText(sLanguage);

			xmlHttp.open("GET", y, false);
			xmlHttp.send(null);

			//-----------Read the header data for bar----------------//

			oRouter.getRoute("CheckIn").attachPatternMatched(this._onObjectMatched, this);

			//-----------Setting the clock and date------------------//
			/*setInterval(function() {
				//	var result = that.GetClock();
				var sCurrDate = new Date();
				var dd = sCurrDate.getDate();
				var mm = sCurrDate.getMonth() + 1; //January is 0!
				var yyyy = sCurrDate.getFullYear();
				if (dd < 10) {
					dd = '0' + dd;
				}
				if (mm < 10) {
					mm = '0' + mm;
				}
				var sDate = yyyy.toString() + mm.toString() + dd.toString();
				var dFormDate = that.fnSetUserDateFormat(sDate, sChDateFormat);
				//	var sDate = sCurrDate.toLocaleDateString();
				var sCurrTime = sCurrDate.toLocaleTimeString();
				var result = dFormDate + " " + sCurrTime;

				if (that.getView().byId("oDateID") !== undefined) {
					that.getView().byId("oDateID").setText(result);
				}
				if (that.getView().byId("oDateID1") !== undefined) {
					that.getView().byId("oDateID1").setText(result);
				}

			}, 1000);*/

			setInterval(function() {

				var oTimeZone = jQuery.sap.storage(jQuery.sap.storage.Type.local).get("sTimeZone");
				var oDayLightSaving = jQuery.sap.storage(jQuery.sap.storage.Type.local).get("sDayLightSaving");
				var oFlag = jQuery.sap.storage(jQuery.sap.storage.Type.local).get("sFlag");

				if (oFlag === false || oFlag === "false" || oFlag === null || oFlag === undefined) {
					var resultBrowser = that.realDateTimeClockBrowser();

					if (that.getView().byId("oDateID") !== undefined) {
						that.getView().byId("oDateID").setText(resultBrowser);
					}
					if (that.getView().byId("oDateID1") !== undefined) {
						that.getView().byId("oDateID1").setText(resultBrowser);
					}

				} else if (oFlag === true || oFlag === "true") {
					var result = that.realDateTimeClock(oTimeZone, oDayLightSaving);

					if (that.getView().byId("oDateID") !== undefined) {
						that.getView().byId("oDateID").setText(result);
					}
					if (that.getView().byId("oDateID1") !== undefined) {
						that.getView().byId("oDateID1").setText(result);
					}

				}

			}, 1000);

			var ParentPlant = jQuery.sap.storage(jQuery.sap.storage.Type.local).get("ParentPlant");
			that.ParentPlant = ParentPlant;

		}, // end of onInit

		realDateTimeClockBrowser: function() {
			var that = this;
			var sCurrDate = new Date();
			var dd = sCurrDate.getDate();
			var mm = sCurrDate.getMonth() + 1; //January is 0!
			var yyyy = sCurrDate.getFullYear();
			if (dd < 10) {
				dd = '0' + dd;
			}
			if (mm < 10) {
				mm = '0' + mm;
			}
			var sDate = yyyy.toString() + mm.toString() + dd.toString();
			var dFormDate = that.fnSetUserDateFormat(sDate, sChDateFormat);
			//	var sDate = sCurrDate.toLocaleDateString();
			var sCurrTime = sCurrDate.toLocaleTimeString();
			var result = dFormDate + " " + sCurrTime;
			return result;
		},

		realDateTimeClock: function(TimeZone, DayLightSaving) {
			var that = this;

			/*	var sData = that.getView().getModel("HeaderDetailsPlant").getData();
			var TimeZone = sData.UTC_DIFF;
			var DayLightSaving = sData.DST_DIFF;*/

			var timeZoneOutput = [TimeZone.slice(0, 3), ":", TimeZone.slice(3, 5)].join('');

			if (DayLightSaving === "") {
				DayLightSaving = "0";
			}

			// var DayLightSavingOutput = [DayLightSaving.slice(0, 2), ":", DayLightSaving.slice(2, 4)].join('');

			if (timeZoneOutput.startsWith("-")) {
				var concatTimeZoneDayLight = parseInt(TimeZone.slice(1, 3)) - parseInt(DayLightSaving.slice(0, 2));
			} else if (timeZoneOutput.startsWith("+")) {
				var concatTimeZoneDayLight = parseInt(TimeZone.slice(1, 3)) + parseInt(DayLightSaving.slice(0, 2));
			}

			var finalOffset = [TimeZone.slice(0, 1), concatTimeZoneDayLight, ":", TimeZone.slice(3, 5)].join('');

			var _now = new Date();

			//var timeZoneOutput = "+11:00";
			var date = that.timezoneShifter(_now, finalOffset);

			var resultDate = that.formatTimeClock(date);
			return resultDate;
		},

		timezoneShifter: function(date, timezone) {

			var isBehindGTM = false;
			if (timezone.startsWith("-")) {
				timezone = timezone.substr(1);
				isBehindGTM = true;
			}

			var hDiff = timezone.split(":").map(myFunction);

			function myFunction(t) {
				return parseInt(t);
			}

			var value = isBehindGTM ? 1 : -1;
			var diff = (hDiff[0] * 60 + hDiff[1]) * value;
			var currentDiff = new Date().getTimezoneOffset();

			return new Date(date.valueOf() + (currentDiff - diff) * 60 * 1000);
		},

		formatTimeClock: function(_now) {
			var that = this;
			var sCurrDate = _now;
			var dd = sCurrDate.getDate();
			var mm = sCurrDate.getMonth() + 1; //January is 0!
			var yyyy = sCurrDate.getFullYear();
			if (dd < 10) {
				dd = '0' + dd;
			}
			if (mm < 10) {
				mm = '0' + mm;
			}
			var sDate = yyyy.toString() + mm.toString() + dd.toString();
			var dFormDate = that.fnSetUserDateFormat(sDate, sChDateFormat);
			//	var sDate = sCurrDate.toLocaleDateString();
			var sCurrTime = sCurrDate.toLocaleTimeString();
			var result = dFormDate + " " + sCurrTime;
			return result;
		},

		setInitialFocus: function(control) {
			this.getView().addEventDelegate({
				onAfterShow: function() {
					setTimeout(function() {
						control.focus();
					}.bind(this), 0);
				}
			}, this);
		},

		_onObjectMatched: function() {
			var that = this;
			var oUACheckin = new sap.ui.model.json.JSONModel({
				UnknownBtn: false,
				cntnueBtn: false,
				onUacontinueBtn: false,
				variabgeText: true
			});
			that.getOwnerComponent().setModel(oUACheckin, "UAunknwnModel");
			that.getView().byId("langId").setText(sLanguage);
			jQuery.sap.storage(jQuery.sap.storage.Type.local).put("DeliveryNumber", "");
			//that.getView().byId("pageNo").setText("2 of 5");
			that.getView().getModel("pgmodel").setProperty("/pgStart", "2");
			that.getView().getModel("pgmodel").setProperty("/pgEnd", "5");
			// var flagObj = {};
			// flagObj.covidFlag = null; 

			// that.byId("deliverynum").focus();
			this.getPlantOnUser();
			that.fnCreateBusyDialog("pallet.svg");
			sCHEPOrders = [];
			sPreloadOrder = [];
			var chepModel1 = new sap.ui.model.json.JSONModel({
				"results": sCHEPOrders
			});
			if (that.byId("DetailTable_ID") !== undefined) {
				that.byId("DetailTable_ID").setVisible(false);
				that.byId("DetailTable_ID").setModel(chepModel1, "deliveryMod");
			}
			var tipPreloadMod = new sap.ui.model.json.JSONModel({
				"results": sPreloadOrder
			});
			if (that.byId("tipPreloadTab") !== undefined) {
				that.byId("tipPreloadTab").setVisible(false);
				that.byId("tipPreloadTab").setModel(tipPreloadMod, "tipPreMod");
			}
			pAddDelivery = '';
			var milkTableData = [];
			var preloadTableData = [];
			jQuery.sap.storage(jQuery.sap.storage.Type.local).put("milkRunList", milkTableData);
			jQuery.sap.storage(jQuery.sap.storage.Type.local).put("tipReloadList", preloadTableData);
			oInsCreateDailog.close();
			that.shipContinueCheck = "";
			that.salesOrderPopUp = "";
		},

		getPlantOnUser: function() {
			var that = this;
			this.getView().byId("addDelv").setVisible(false);
			this.getView().byId("DetailTable_ID").setVisible(false);

			var url = "/sap/opu/odata/sap/ZGW_DELIVERY_AP_SRV";
			var oModel = new sap.ui.model.odata.ODataModel(url, {
				loadMetadataAsync: false
			});
			oRouterObject = that.getRouter();
			oModel.read("/HeaderDetailsSet('" + loggedUser + "')", null, null, false, function(oData, oResponse) {
					if (oResponse.statusCode === 200) {
						oHeaderUAflag = oData.UaTripload;
						jQuery.sap.storage(jQuery.sap.storage.Type.local).put("oHeaderUA", oHeaderUAflag);
						var oODataJSONModel2 = new sap.ui.model.json.JSONModel();
						oODataJSONModel2.setData(oData);
						that.getView().setModel(oODataJSONModel2, "HeaderDetails");

						//---------Start of Multi Plant Changes----------// 

						sParentPlant = oData.ParentPlant;

						if (sParentPlant !== "") { // If MultiPlant config is true then we are sending parent plant otherwise sending login plant
							vLoadPlant = sParentPlant;
						} else {
							vLoadPlant = oData.Plant;
						}

						// vLoadPlant = oData.Plant;

						//---------End of Multi Plant Changes----------// 
						sHaulierFlg = oData.HaulierFlag;

						oInsCreateDailog.close();
						that.getAuthorizedFlag();
						jQuery.sap.storage(jQuery.sap.storage.Type.local).put("sContract", sHaulierFlg);
						// jQuery.sap.storage(jQuery.sap.storage.Type.local).put("covidFlag", oData.CovidFlag);

					}
				},
				function(error) {
					oInsCreateDailog.close();
					MessageBox.show("Error");
				});
		},

		//------Function for "I don't have Chep Order Number" button visibilty------//
		getAuthorizedFlag: function() {
			var that = this;
			var sService = "/sap/opu/odata/sap/ZGW_CHECKIN_SRV";
			var oModel = new sap.ui.model.odata.ODataModel(sService);

			// var sParentPlant = that.ParentPlant;
			// var vPlant;
			// if (sParentPlant !== "" || sParentPlant !== " ") {
			// 	vPlant = sParentPlant;
			// } else {
			// 	vPlant = vLoadPlant;
			// }

			oModel.read("/HeaderDetailsSet(Plant='" + vLoadPlant + "')", null, null, false,
				function(oData) {

					vAuthorized = oData.Unauthorized;
					milkRunFlag = oData.MilkRun;
					sForMobValid = oData.MobileValidFlag;
					if (vAuthorized === "false") {
						that.getView().byId("unknown").setVisible(false);
					} else {
						that.getView().byId("unknown").setVisible(true);
					}
					sPassthrough = oData.PassThrough;
					vDropservice = oData.DropService;
					vDhservice = oData.DH_EX;
					sRegion = oData.Region;
					vCHtrilerid = oData.CH_TID;
					vHaulierName = oData.CH_HN;
					yardStopFlag = oData.YardStop;

					var oPlantModelUA = new sap.ui.model.json.JSONModel(oData);
					that.getView().setModel(oPlantModelUA, "oUAplantModel");

					// jQuery.sap.storage(jQuery.sap.storage.Type.local).put("covidFlag", oData.CovidFlag);
					//	sHaulierFlg = oData.HaulierFlg;
				});
			that.getView().byId("deliverynum").setValue("");
			jQuery.sap.storage(jQuery.sap.storage.Type.local).put("vDropservice", vDropservice);
			jQuery.sap.storage(jQuery.sap.storage.Type.local).put("sRegion", sRegion);
			jQuery.sap.storage(jQuery.sap.storage.Type.local).put("sForMobValid", sForMobValid);
			jQuery.sap.storage(jQuery.sap.storage.Type.local).put("vDhservice", vDhservice);
			jQuery.sap.storage(jQuery.sap.storage.Type.local).put("vCHtrilerid", vCHtrilerid);
			jQuery.sap.storage(jQuery.sap.storage.Type.local).put("vHaulierName", vHaulierName);
			//ctrm-1329
			jQuery.sap.storage(jQuery.sap.storage.Type.local).put("yardStopFlag", yardStopFlag);
		},

		//-----------Function to create Busy Dialog---------------//

		fnCreateBusyDialog: function(sImage) {
			var that = this;
			oInsCreateDailog = new sap.m.Dialog({
				showHeader: false
			}).addStyleClass("busyDialog sapUiTinyMargin");
			var sComponentName = that.getOwnerComponent().getMetadata().getComponentName();
			var imgUrl = $.sap.getModulePath(sComponentName, "/images/");
			var oImage = new sap.m.Image().addStyleClass("sapUiMediumMargin");
			oImage.setSrc(imgUrl + sImage);
			oInsCreateDailog.addContent(oImage);
			oInsCreateDailog.open();
		},

		//----Function to accept only number for the input field "Chep Order Number"----//
		onDeliveryNumber: function(evt) {
			var that = this;
			that.byId("deliverynum").setValueState(sap.ui.core.ValueState.None);
			this.byId("deliverynum").focus();
			var deliverynumber = this.byId("deliverynum").getValue().trim();

			if (deliverynumber.length > 10) {
				var deliverynum = deliverynumber.substring(0, deliverynumber.length - 1);
				this.getView().byId("deliverynum").setValue(deliverynum);
			}
			if (deliverynumber.length < 10) {
				// if (deliverynumber.length === 8) {
				// 	var oShipmentNumber = "00" + deliverynumber;
				// 	that.onValidateDelNum(oShipmentNumber);
				// } else {
				sCHEPOrders = [];
				sPreloadOrder = [];
				jQuery.sap.storage(jQuery.sap.storage.Type.local).put("DeliveryNumber", deliverynumber);
				if (this.byId("addDelv") !== undefined) {
					this.byId("addDelv").setVisible(false);
				}
				if (that.byId("unknown") !== undefined) {
					if (vAuthorized === "false") {
						that.byId("unknown").setVisible(false);
					} else {
						that.byId("unknown").setVisible(true);
					}
				}
				if (this.byId("DetailTable_ID") !== undefined) {
					this.byId("DetailTable_ID").setVisible(false);
					var data1 = [];
					var oModel11 = new sap.ui.model.json.JSONModel({
						"results": data1
					});
					that.getView().byId("DetailTable_ID").setModel(oModel11, "deliveryMod");
				}
				if (this.byId("tipPreloadTab") !== undefined) {
					this.byId("tipPreloadTab").setVisible(false);
					var tipPrloadEmt = [];
					var tipPrloadoModelEmp = new sap.ui.model.json.JSONModel({
						"results": tipPrloadEmt
					});
					that.getView().byId("tipPreloadTab").setModel(tipPrloadoModelEmp, "tipPreMod");
				}
				// }
			} else {
				if (deliverynumber.length === 10) {
					// that.onValidateDelNum(deliverynumber);
					var i18nModel = that.getOwnerComponent();
					var oModelCheck = that.getOwnerComponent().getModel("checkedMod");
					jQuery.sap.storage(jQuery.sap.storage.Type.local).put("DeliveryNumber", deliverynumber);
					// var sParentPlant = that.ParentPlant;
					oInsCreateDailog.open();
					var oModelMilk = that.getOwnerComponent().getModel("milkMod");
					oModelMilk.read("/MilkrunSet(Deliveryno='" + deliverynumber + "')", {
						success: function(oData) {},
						error: function(oError) {
							var sDuplicate = (JSON.parse(oError.responseText).error.message.value);
							if (sDuplicate !== 'X') {
								oInsCreateDailog.close();
							} else {
								that.fnCreateBusyDialog("pallet.svg");
								oModelCheck.read("/CheckInSet(Werks='" + vLoadPlant + "',DocId='" + deliverynumber + "')", {
									success: function(oData, oResponse) {
										if (oResponse.statusCode === "200" || oResponse.statusCode === 200) {

											sDocId = oData.DocId;
											sOrdertype = oData.OrderType;
											sDropHook = oData.DropHook;
											oTriploadUA = oData.UA_TRIPLOAD;
											jQuery.sap.storage(jQuery.sap.storage.Type.local).put("oTripLoadUA", oTriploadUA);
											jQuery.sap.storage(jQuery.sap.storage.Type.local).put("dropNpickup", sDropHook);
											if (((sOrdertype.toLowerCase() === "Collect") || (sOrdertype.toLowerCase() === "collect")) || ((sOrdertype ===
													"Raw Materials")) ||
												((sOrdertype.toLowerCase() === "STO Receipt") || (sOrdertype.toLowerCase() === "sto receipt"))) {

												delNumFlag = "R";
												jQuery.sap.storage(jQuery.sap.storage.Type.local).put("sDeliveryType", delNumFlag);
												//	if (milkRunFlag === "true") {
												if (that.byId("deliverynum") !== undefined) {
													that.byId("deliverynum").setValueState(sap.ui.core.ValueState.None);
												}
												// jQuery.sap.storage(jQuery.sap.storage.Type.local).put("DeliveryNumber", deliverynumber);
												sCHEPOrders = [];
												//	that.fnCreateBusyDialog("pallet.svg");
												/*Code Added for Milk run to set Visibity of Add Button*/
												if (that.byId("addDelv") !== undefined) {
													that.byId("addDelv").setVisible(true);
												}
												if (that.byId("DetailTable_ID") !== undefined) {
													that.byId("DetailTable_ID").setVisible(true);
													var oModelEmpty = new sap.ui.model.json.JSONModel({
														"results": sCHEPOrders
													});
													that.getView().byId("DetailTable_ID").setModel(oModelEmpty, "deliveryMod");
													//	oInsCreateDailog.close();
												}
												if (that.byId("unknown") !== undefined) {
													that.byId("unknown").setVisible(false);
												}
												//	oInsCreateDailog.close();
												var chepEntry = {};
												chepEntry.chepdeliverynumber = sDocId;
												chepEntry.OrderType = sOrdertype; // Lumber load processing adding order type
												chepEntry.Plant = oData.Werks;
												sCHEPOrders.push(chepEntry);
												var chepModel = new sap.ui.model.json.JSONModel({
													"results": sCHEPOrders
												});
												that.byId("DetailTable_ID").setModel(chepModel, "deliveryMod");
												oInsCreateDailog.close();
												/*	} else {
												if (that.byId("addDelv") !== undefined) {
													that.byId("addDelv").setVisible(false);
												}
												if (that.byId("DetailTable_ID") !== undefined) {
													that.byId("DetailTable_ID").setVisible(false);
												}
												if (that.byId("unknown") !== undefined) {
													if (vAuthorized === "false") {
														that.byId("unknown").setVisible(false);
													} else {
														that.byId("unknown").setVisible(true);
													}
												}
												oInsCreateDailog.close();
											}*/
												that.shipContinueCheck = "C";
											} else if (((sOrdertype.toLowerCase() === "Issue") || (sOrdertype.toLowerCase() === "issue")) ||
												((sOrdertype.toLowerCase() === "STO Issue") || (sOrdertype.toLowerCase() === "sto issue"))) {
												if (that.byId("deliverynum") !== undefined) {
													that.byId("deliverynum").setValueState(sap.ui.core.ValueState.None);
												}
												// jQuery.sap.storage(jQuery.sap.storage.Type.local).put("DeliveryNumber", deliverynumber);
												delNumFlag = "I";
												jQuery.sap.storage(jQuery.sap.storage.Type.local).put("sDeliveryType", delNumFlag);
												sPreloadOrder = [];

												if (that.byId("addDelv") !== undefined) {
													that.byId("addDelv").setVisible(true);
												}
												if (that.byId("tipPreloadTab") !== undefined) {
													that.byId("tipPreloadTab").setVisible(true);
													var tipEmpty = new sap.ui.model.json.JSONModel({
														"results": sPreloadOrder
													});
													that.getView().byId("tipPreloadTab").setModel(tipEmpty, "tipPreMod");
												}

												if (that.byId("DetailTable_ID") !== undefined) {
													that.byId("DetailTable_ID").setVisible(false);
												}
												if (that.byId("unknown") !== undefined) {
													that.byId("unknown").setVisible(false);
												}
												var chepEntryTip = {};
												chepEntryTip.chepdeliverynumber = sDocId;
												chepEntryTip.Plant = oData.Werks;
												sPreloadOrder.push(chepEntryTip);
												var chepTipModel = new sap.ui.model.json.JSONModel({
													"results": sPreloadOrder
												});
												that.byId("tipPreloadTab").setModel(chepTipModel, "tipPreMod");
												oInsCreateDailog.close();
												that.shipContinueCheck = "C";
											} else if (sOrdertype === "SO" || sOrdertype === "PO" || sOrdertype === "SH") {
												//Get associated deliveries based on Sales/Purchase/Shipment Order
												var sAllDelForShip = JSON.parse(oData.JsonDeliveries);
												var oModelDeliveries = new sap.ui.model.json.JSONModel(sAllDelForShip);
												that.getView().setModel(oModelDeliveries, "oModelDeliveries");
												if (that.byId("addDelv") !== undefined) {
													that.byId("addDelv").setVisible(true);
												}
												if (that.byId("unknown") !== undefined) {
													that.byId("unknown").setVisible(false);
												}
												that._getDialogDeliverieslist().open();
												oInsCreateDailog.close();
												that.shipContinueCheck = "C";
											} else {
												if (that.byId("addDelv") !== undefined) {
													that.byId("addDelv").setVisible(false);
												}
												if (that.byId("DetailTable_ID") !== undefined) {
													that.byId("DetailTable_ID").setVisible(false);
												}
												if (that.byId("tipPreloadTab") !== undefined) {
													that.byId("tipPreloadTab").setVisible(false);
												}
												if (that.byId("unknown") !== undefined) {
													if (vAuthorized === "false") {
														that.byId("unknown").setVisible(false);
													} else {
														that.byId("unknown").setVisible(true);
													}
												}
												oInsCreateDailog.close();
											}
										}
									},
									error: function(errorMessage) {

										//	var oMessage = (JSON.parse(oError.responseText).error.message.value);
										if (that.byId("addDelv") !== undefined) {
											that.byId("addDelv").setVisible(false);
										}
										if (that.byId("DetailTable_ID") !== undefined) {
											that.byId("DetailTable_ID").setVisible(false);
										}
										if (that.byId("tipPreloadTab") !== undefined) {
											that.byId("tipPreloadTab").setVisible(false);
										}
										if (that.byId("unknown") !== undefined) {
											//	that.byId("unknown").setVisible(true);
											if (vAuthorized === "false") {
												that.byId("unknown").setVisible(false);
											} else {
												that.byId("unknown").setVisible(true);
											}

										}
										var oErrorMessage = JSON.parse(errorMessage.responseText).error.message.value;
										var oMessage = "";
										// if (oErrorMessage.includes("01")) {
										if (oErrorMessage.includes("01") && (!oErrorMessage.includes("BH_RULES"))) {
											oErrorMessage = oErrorMessage.split("01");
											oMessage = oErrorMessage[1] + " - " + i18nModel.getModel("i18n").getProperty('errorSAPBlockMsg');
										} else if (oErrorMessage === "Cancel") {
											oMessage = i18nModel.getModel("i18n").getProperty('cancelDelErrorMsg');
										} else if (oErrorMessage === "SINGLE") {
											oMessage = i18nModel.getModel("i18n").getProperty('vl02ErrorMsg');
										} else if (oErrorMessage === "Invalid") {
											oMessage = i18nModel.getModel("i18n").getProperty('InvalidErrorMsg');
										}
										//Begin of changes by Sharmila
										else if (oErrorMessage.includes("Invalid-Plant")) {

											// ESP-3491  start
											document.addEventListener('keydown', function(event) {
												// if the keyCode is 8 ( backscape key was pressed )
												if (that.FlagOk === "" || that.FlagOk === undefined) {
													if (event.keyCode === 8 || event.keyCode === 46 || event.keyCode === 38 || event.keyCode === 40 || event.keyCode ===
														86) {
														// prevent default behaviour
														event.preventDefault();
														that.FlagOk = "";
														return false;
													}
												}

											});
											// ESP-3491  end

											//Raise error message for driver location
											var plant_name = oErrorMessage.replace("Invalid-Plant-", "");
											var oMessage1 = i18nModel.getModel("i18n").getProperty('InvalidPlantErrorMsg');
											//Sharmila For Split the messges//
											var formattedString = oMessage1.split(".");
											var oVal1 = formattedString[0].concat("." + "\n");
											var oVal2 = formattedString[1].concat("\n");
											var oVal3 = formattedString[2].concat("." + "\n");
											oMessage = oVal1 + oVal2 + oVal3;
											oMessage = oMessage.replace("{Del #}", deliverynumber);
											oMessage = oMessage.replace("{Plant code and Name}", plant_name);
										} else if (oErrorMessage.includes("STO")) {
											//Raise error message for STO
											oMessage = i18nModel.getModel("i18n").getProperty('errorSTOMsg');
										} else if (oErrorMessage.includes("Invalid_BH")) {
											//Raise error message for invalid business Hours
											oMessage = i18nModel.getModel("i18n").getProperty('errorBHV');
										} else if (oErrorMessage.includes("BH_RULES")) {
											//Raise error message for invalid business Hours
											var t = oErrorMessage.replace('BH_RULES/', "");
											var hrs = t.split('/'); // separtes shift hours
											var sHrs = hrs.join(' ').trim();
											var shifthours = sHrs.split(' ');
											var time = '';
											for (var i = 0; i < shifthours.length; i++) {
												if (i % 2 === 0) {
													var val = " " + i18nModel.getModel("i18n").getProperty('To') + " ";
													time = time + shifthours[i].slice(0, 2) + ":" + shifthours[i].slice(2, 4) + ":" + shifthours[i].slice(4, 6) + " " +
														shifthours[i].slice(6, 8) + " " + val;
												} else {
													if (i < shifthours.length - 1) {
														var val = " " + i18nModel.getModel("i18n").getProperty('And') + " ";
														time = time + shifthours[i].slice(0, 2) + ":" + shifthours[i].slice(2, 4) + ":" + shifthours[i].slice(4, 6) + " " +
															shifthours[i].slice(6, 8) + "" + val;
													} else {
														time = time + shifthours[i].slice(0, 2) + ":" + shifthours[i].slice(2, 4) + ":" + shifthours[i].slice(4, 6) + " " +
															shifthours[i].slice(6, 8);
													}
												}

											}
											var sAMTimeValue = time.split(" ")[1];
											var sPMTimeValue = time.split(" ")[6];
											var valueTime = time.split(" ")[5];
											if (valueTime === undefined) {
												valueTime = "";
											}
											var getAMvalue;
											if (sAMTimeValue === "AM" || sAMTimeValue === "am") {
												getAMvalue = i18nModel.getModel("i18n").getProperty('am');
											} else if (sAMTimeValue === "PM" || sAMTimeValue === "pm") {
												getAMvalue = i18nModel.getModel("i18n").getProperty('pm');
											} else if (sAMTimeValue === "" || sAMTimeValue === undefined) {
												getAMvalue = " ";
											}
											var getPMvalue;
											if (sPMTimeValue === "AM" || sPMTimeValue === "am") {
												getPMvalue = i18nModel.getModel("i18n").getProperty('am');
											} else if (sPMTimeValue === "PM" || sPMTimeValue === "pm") {
												getPMvalue = i18nModel.getModel("i18n").getProperty('pm');
											} else if (sPMTimeValue === "" || sPMTimeValue === undefined) {
												getPMvalue = " ";
											}

											var sTimeValue = time.split(" ")[0] + " " + getAMvalue + " " + time.split(" ")[2] + " " + time.split(" ")[3] + " " +
												time.split(
													" ")[4] + " " + valueTime + " " + getPMvalue;
											// console.log(time);
											//	 var msg = i18nModel.getModel("i18n").getProperty('errorBHrules');
											var msg = i18nModel.getModel("i18n").getProperty('erroroutSideBHrs');
											oMessage = msg.replace("{timings}", sTimeValue);
										} else if (oErrorMessage.includes("Invalid-Delivery")) {
											oMessage = i18nModel.getModel("i18n").getProperty('noShipmentCreated');
										} else if (oErrorMessage.includes("Delivery-Not-Found")) {
											oMessage = i18nModel.getModel("i18n").getProperty('deliveryNotFound');
										}

										//End of changes by Sharmila
										else {
											oMessage = oErrorMessage;
										}
										// ESP-3491  start
										that.FlagOk = "";
										// ESP-3491  end
										sap.m.MessageBox.show(
											oMessage, {
												icon: sap.m.MessageBox.Icon.ERROR,
												title: i18nModel.getModel("i18n").getProperty('submitError'), //"Error during submitting!""Error"
												// ESP-3491  start
												onClose: function(oAction) {
													if (oAction === MessageBox.Action.OK) {
														that.FlagOk = "X";
														that.byId("deliverynum").focus();
													}
												}
												// ESP-3491  end
											});
										oInsCreateDailog.close();

										// var oMessage = "";
										// if (oErrorMessage.includes("01")) {
										// 	oErrorMessage = oErrorMessage.split("01");
										// 	oMessage = oErrorMessage[1] + " - " + i18nModel.getModel("i18n").getProperty('errorSAPBlockMsg');
										// } else {
										// 	oMessage = oErrorMessage;
										// }
										// sap.m.MessageBox.show(
										// 	oMessage, {
										// 		icon: sap.m.MessageBox.Icon.ERROR,

										// 		title: i18nModel.getModel("i18n").getProperty('submitError') //"Error during submitting!""Error"
										// 	});
										// oInsCreateDailog.close();
									}
								});
							}
						}
					});

					oModelCheck.attachRequestCompleted(function() {
						oInsCreateDailog.close();
					});
					oModelCheck.attachRequestFailed(function() {
						oInsCreateDailog.close();
					});
				} else {
					oTriploadUA = "";
					jQuery.sap.storage(jQuery.sap.storage.Type.local).put("oTripLoadUA", oTriploadUA);
				}
			}
			oInsCreateDailog.close();
		},

		//Begin of changes by Sharmila

		_getDialogDeliverieslist: function() {
			var that = this;
			var oView = that.getView();
			if (!that.dialog) {
				that.dialog = sap.ui.xmlfragment("chep.checkin.Fragments.DeliveriesChecklist", that);
			}
			oView.addDependent(that.dialog);
			return that.dialog;
		},

		onBackDeliverieslist: function() {
			var that = this;
			that._getDialogDeliverieslist().close();
		},
		onProceedDeliverieslist: function(oEvent) {
			var that = this;
			var tabledata;
			var i;
			var temp = sap.ui.getCore().byId("deliveriesTableID").getSelectedItems();
			if (temp.length > 0) {
				for (i = 0; i < temp.length; i++) {
					sOrdertype = temp[i].getBindingContext("oModelDeliveries").getObject().ORDER_TYPE;
					if (((sOrdertype.toLowerCase() === "Issue") || (sOrdertype.toLowerCase() === "issue")) ||
						((sOrdertype.toLowerCase() === "STO Issue") || (sOrdertype.toLowerCase() === "sto issue"))) {
						that.byId("tipPreloadTab").setVisible(true);
						delNumFlag = "I";
						tabledata = that.byId("tipPreloadTab").getModel("tipPreMod").getData();
						tabledata.results.push({
							"chepdeliverynumber": temp[i].getBindingContext("oModelDeliveries").getObject().DELIV
						});
						that.byId("tipPreloadTab").getModel("tipPreMod").setData(tabledata);
					} else if (((sOrdertype.toLowerCase() === "Collect") || (sOrdertype.toLowerCase() === "collect")) || ((sOrdertype ===
							"Raw Materials")) ||
						((sOrdertype.toLowerCase() === "STO Receipt") || (sOrdertype.toLowerCase() === "sto receipt"))) {
						that.byId("DetailTable_ID").setVisible(true);
						delNumFlag = "R";
						tabledata = that.byId("DetailTable_ID").getModel("deliveryMod").getData();
						tabledata.results.push({
							"chepdeliverynumber": temp[i].getBindingContext("oModelDeliveries").getObject().DELIV
						});
						that.byId("DetailTable_ID").getModel("deliveryMod").setData(tabledata);
					}
				}
				that.salesOrderPopUp = "S";
				that._getDialogDeliverieslist().close();
			} else {
				var i18noModel = that.getOwnerComponent();
				var oerrorUpdate = i18noModel.getModel("i18n").getProperty('errorDuringUpdate');
				var oDuplicate = i18noModel.getModel("i18n").getProperty('selectAnyOne');
				MessageBox.show(
					oDuplicate, {
						icon: MessageBox.Icon.ERROR,
						title: oerrorUpdate
					});
			}
		},
		//End of changes by Sharmila	

		onAddDeliveryNoliveChange: function() {
			if (sap.ui.getCore().byId("addDeliveryNo") !== undefined) {
				var deliverynumber = sap.ui.getCore().byId("addDeliveryNo").getValue().trim();
				if (deliverynumber !== "") {
					sap.ui.getCore().byId("addDeliveryNo").setValueState(sap.ui.core.ValueState.None);
				}
				if (deliverynumber !== "") {
					sap.ui.getCore().byId("addDeliveryNo").setValueState(sap.ui.core.ValueState.None);
					if (deliverynumber.length > 10) {
						var deliverynum = deliverynumber.substring(0, deliverynumber.length - 1);
						sap.ui.getCore().byId("addDeliveryNo").setValue(deliverynum);
					}
				}
			}
		},
		onAddDelivery: function() {
			var that = this;
			that.fnCreateBusyDialog("pallet.svg");
			var deliverynumber = this.byId("deliverynum").getValue().trim();

			if (deliverynumber === "") {
				this.byId("deliverynum").setValueState(sap.ui.core.ValueState.Error);
			} else {
				var i18nModel = that.getOwnerComponent();

				if (!that.addDelvDialog) {
					that.addDelvDialog = sap.ui.xmlfragment("chep.checkin.fragments.AddDelivery", that);
					that.getView().addDependent(that.addDelvDialog);
				}
				var sDuplicate;
				jQuery.sap.syncStyleClass("sapUiSizeCompact", that.getView(), that.addDelvDialog);
				that.byId("deliverynum").setValueState(sap.ui.core.ValueState.None);
				if (deliverynumber.length === 8) { // Added leading zeros for shipment number
					deliverynumber = "00" + deliverynumber;
				}
				if (that.salesOrderPopUp === "S") {
					deliverynumber = that.getView().getModel("oModelDeliveries").getData()[0].DELIV;
				} else {
					deliverynumber = deliverynumber;
				}
				var oModelCheck = that.getOwnerComponent().getModel("checkedMod");
				var oModelMilk = that.getOwnerComponent().getModel("milkMod");
				// var sParentPlant = that.ParentPlant;
				oModelMilk.read("/MilkrunSet(Deliveryno='" + deliverynumber + "')", {
					success: function(oData) {},
					error: function(oError) {
						sDuplicate = (JSON.parse(oError.responseText).error.message.value);
						var errorUpdate = i18nModel.getModel("i18n").getProperty('errorDuringUpdate');
						var dupUpdate = i18nModel.getModel("i18n").getProperty('orderInvalid');
						if (sDuplicate !== 'X') {
							MessageBox.show(
								dupUpdate, {
									icon: MessageBox.Icon.ERROR,
									title: errorUpdate
								});
							oInsCreateDailog.close();
						} else {
							oModelCheck.read("/CheckInSet(Werks='" + vLoadPlant + "',DocId='" + deliverynumber + "')", {
								success: function(oData, oResponse) {
									if (sRegion === "US") {
										jQuery.sap.storage(jQuery.sap.storage.Type.local).put("sVendor", oData.Carrier);
									} else {
										jQuery.sap.storage(jQuery.sap.storage.Type.local).put("sVendor", oData.Vendor);
									}

									if (oResponse.statusCode === "200" || oResponse.statusCode === 200) {
										sDocId = oData.DocId;
										sOrdertype = oData.OrderType;
										shDel = oData.ShCondition;
										var sHeaderMsg = oResponse.headers.message; //CheckedIn message
										if (sHeaderMsg !== undefined) { // for Valid and Submitted number
											if (sHeaderMsg !== "") {
												oInsCreateDailog.close();
												//	var oMessage = sHeaderMsg;
												switch (sHeaderMsg) {
													case "CheckedIn":
														var oMessage = i18nModel.getModel("i18n").getProperty('checkdIn');
														break;
													case "Completed":
														var oMessage = i18nModel.getModel("i18n").getProperty('orderCompleted');
														break;
												}
												var submitError = i18nModel.getModel("i18n").getProperty('submitError');
												MessageBox.show(
													oMessage, {
														icon: MessageBox.Icon.ERROR,
														title: submitError //"Error during submitting!"
													});
											}
											oInsCreateDailog.close();
										} else if (((sOrdertype.toLowerCase() === "Collect") || (sOrdertype.toLowerCase() === "collect")) ||
											((sOrdertype.toLowerCase() === "STO Receipt") || ((sOrdertype === "Raw Materials")) || (sOrdertype.toLowerCase() ===
												"sto receipt"))) {
											that.addDelvDialog.open();
											/*UA Trpload Changes by vinod START*/
											// if(deliverynumber !== ""){
											// 	that.getView().getModel("UAunknwnModel").setProperty("/UnknownBtn", false);
											// }
											if (oTriploadUA === "X" && shDel === "Z1" && deliverynumber === "") {
												that.getView().getModel("UAunknwnModel").setProperty("/UnknownBtn", true);
											} else {
												that.getView().getModel("UAunknwnModel").setProperty("/UnknownBtn", false);
											}
											/*UA Trpload Changes bu vinod END*/
											if (sap.ui.getCore().byId("addDeliveryNo") !== undefined) {
												that.setInitialFocus(sap.ui.getCore().byId("addDeliveryNo"));
											}
											if (sap.ui.getCore().byId("addDeliveryNo") !== undefined) {
												sap.ui.getCore().byId("addDeliveryNo").setValue("");
											}
											// jQuery.sap.storage(jQuery.sap.storage.Type.local).put("DeliveryNumber", deliverynumber);
											that.shipContinueCheck = "C";
											oInsCreateDailog.close();
										} else if (((sOrdertype.toLowerCase() === "Issue") || (sOrdertype.toLowerCase() === "issue")) ||
											((sOrdertype.toLowerCase() === "STO Issue") || (sOrdertype.toLowerCase() === "sto issue"))) {
											// jQuery.sap.storage(jQuery.sap.storage.Type.local).put("DeliveryNumber", deliverynumber);
											that.addDelvDialog.open();
											/*UA Trpload Changes bu vinod START*/
											if (oTriploadUA === "X" && shDel === "Z1") {
												that.getView().getModel("UAunknwnModel").setProperty("/UnknownBtn", true);
											} else {
												that.getView().getModel("UAunknwnModel").setProperty("/UnknownBtn", false);
											}
											/*UA Trpload Changes bu vinod END*/
											if (sap.ui.getCore().byId("addDeliveryNo") !== undefined) {
												that.setInitialFocus(sap.ui.getCore().byId("addDeliveryNo"));
											}
											if (sap.ui.getCore().byId("addDeliveryNo") !== undefined) {
												sap.ui.getCore().byId("addDeliveryNo").setValue("");
											}
											that.shipContinueCheck = "C";
											oInsCreateDailog.close();
										} else if (sOrdertype === "SO" || sOrdertype === "PO" || sOrdertype === "SH") {

											that.addDelvDialog.open();
											if (sap.ui.getCore().byId("addDeliveryNo") !== undefined) {
												that.setInitialFocus(sap.ui.getCore().byId("addDeliveryNo"));
											}
											if (sap.ui.getCore().byId("addDeliveryNo") !== undefined) {
												sap.ui.getCore().byId("addDeliveryNo").setValue("");
											}
											oInsCreateDailog.close();
											that.shipContinueCheck = "C";
										}
										//End of changes by Sharmila
										else {
											oInsCreateDailog.close();
											MessageBox.show(
												i18nModel.getModel("i18n").getProperty('orderInvalid'), {
													icon: MessageBox.Icon.ERROR,
													title: i18nModel.getModel("i18n").getProperty('submitError') //"Error during submitting!"
												});
										}
									}
								},
								error: function(oError) {
									oInsCreateDailog.close();
									//	var oMessage = (JSON.parse(oError.responseText).error.message.value);
									var oMessage = i18nModel.getModel("i18n").getProperty('orderInvalid');
									var submitError = i18nModel.getModel("i18n").getProperty('submitError');
									MessageBox.show(
										oMessage, {
											icon: MessageBox.Icon.ERROR,
											title: submitError //"Error during submitting!"
										});
								}
							});
							oModelCheck.attachRequestCompleted(function() {
								oInsCreateDailog.close();
							});
							oModelCheck.attachRequestFailed(function() {
								oInsCreateDailog.close();
							});
						}
					}
				});
			}
		},
		addDialogueAfterOpen: function(oEvent) {
			setTimeout(function() {
				sap.ui.getCore().byId("addDeliveryNo").focus();
			}.bind(this), 0);

		},
		onValidDelivery: function(deliverynumber) {
			var that = this;
			var i18nModel = that.getOwnerComponent();
			var oModelCheck = that.getOwnerComponent().getModel("checkedMod");
			var oModelMilk = that.getOwnerComponent().getModel("milkMod");

			if (deliverynumber.length === 8) { // Added leading zeros for shipment number
				deliverynumber = "00" + deliverynumber;

			}

			// var sParentPlant = that.ParentPlant;
			var onDataFromTab = that.onGetAllDataFromTables();
			oModelMilk.read("/MilkrunSet(Deliveryno='" + deliverynumber + "')", {
				success: function(oData) {},
				error: function(oError) {
					oInsCreateDailog.close();
					var sDuplicate = (JSON.parse(oError.responseText).error.message.value);
					var errorUpdate = i18nModel.getModel("i18n").getProperty('errorDuringUpdate');
					if (sDuplicate !== 'X') {
						that.addDelvDialog.close();
						var dupUpdate = i18nModel.getModel("i18n").getProperty('orderInvalid');
						MessageBox.show(
							dupUpdate, {
								icon: MessageBox.Icon.ERROR,
								title: errorUpdate
							});
					} else {
						oModelCheck.read("/CheckInSet(Werks='" + vLoadPlant + "',DocId='" + deliverynumber + "')", {
							success: function(oData, oResponse) {
								if (sRegion === "US") {
									jQuery.sap.storage(jQuery.sap.storage.Type.local).put("sVendor", oData.Carrier);
								} else {
									jQuery.sap.storage(jQuery.sap.storage.Type.local).put("sVendor", oData.Vendor);
								}
								if (oResponse.statusCode === "200" || oResponse.statusCode === 200) {
									sDocId = oData.DocId;
									sOrdertype = oData.OrderType;
									var ShCondition = oData.ShCondition;
									var sVendorAdd,
										oShpDel = oData.ShCondition;
									if (sRegion === "US") {
										sVendorAdd = oData.Carrier;
									} else {
										sVendorAdd = oData.Vendor;
									}

									//	var sCnameCarrier = oData.Location;
									/*find if the array has the delivery*/
									/*Shipment Validation*/
									var sDuplicateDel = "";
									for (var i = 0; i < onDataFromTab.length; i++) {
										if (onDataFromTab[i].chepdeliverynumber === sDocId) {
											sDuplicateDel = "X";
											break;
										}
									}
									/*Shipment Validation*/
									var sHeaderMsg = oResponse.headers.message; //CheckedIn message
									if (sHeaderMsg !== undefined) { // for Valid and Submitted number
										that.addDelvDialog.close();
										if (sHeaderMsg !== "") {
											//	var oMessage = sHeaderMsg;
											switch (sHeaderMsg) {
												case "CheckedIn":
													var oMessage = i18nModel.getModel("i18n").getProperty('checkdIn');
													break;
												case "Completed":
													var oMessage = i18nModel.getModel("i18n").getProperty('orderCompleted');
													break;
											}
											var submitError = i18nModel.getModel("i18n").getProperty('submitError');
											MessageBox.show(
												oMessage, {
													icon: MessageBox.Icon.ERROR,
													title: submitError //"Error during submitting!"
												});
										}
										oInsCreateDailog.close();
									} else if (((sOrdertype.toLowerCase() === "Collect") || (sOrdertype.toLowerCase() === "collect")) ||
										((sOrdertype.toLowerCase() === "STO Receipt") || ((sOrdertype === "Raw Materials")) || (sOrdertype.toLowerCase() ===
											"sto receipt"))) {

										if ((oTriploadUA === "X" || oHeaderUAflag === "X") && oUAbtnFlag === "X") {
											var errorUpdateUA = i18nModel.getModel("i18n").getProperty('errorDuringUpdate');
											if (((sOrdertype.toLowerCase() === "Collect") || (sOrdertype.toLowerCase() === "collect"))) {
												var dupUpdateUA = i18nModel.getModel("i18n").getProperty('youCannot');
												MessageBox.show(
													dupUpdateUA, {
														icon: MessageBox.Icon.ERROR,
														title: errorUpdateUA
													});
											}
										} else {
											if (jQuery.sap.storage(jQuery.sap.storage.Type.local).get("sVendor") === sVendorAdd) {
												if (that.byId("DetailTable_ID") !== undefined) {
													that.byId("DetailTable_ID").setVisible(true);
												}

												if (sDuplicateDel !== "X") {
													var chepEntry = {};
													chepEntry.chepdeliverynumber = sDocId;
													chepEntry.Plant = oData.Werks;

													if (that.salesOrderPopUp === "S") {
														var sDeliveryModel = that.byId("DetailTable_ID").getModel("deliveryMod").getData().results;
														sDeliveryModel.push(chepEntry);
														var chepModel1 = new sap.ui.model.json.JSONModel({
															"results": sDeliveryModel
														});
														that.byId("DetailTable_ID").setModel(chepModel1, "deliveryMod");

													} else {
														sCHEPOrders.push(chepEntry);
														var chepModel1 = new sap.ui.model.json.JSONModel({
															"results": sCHEPOrders
														});
														that.byId("DetailTable_ID").setModel(chepModel1, "deliveryMod");
													}

													that.addDelvDialog.close();
												} else {
													var oerrorUpdate = i18nModel.getModel("i18n").getProperty('errorDuringUpdate');
													var oDuplicate = i18nModel.getModel("i18n").getProperty('sameOrderNum');
													MessageBox.show(
														oDuplicate, {
															icon: MessageBox.Icon.ERROR,
															title: oerrorUpdate
														});
												}
											}
											/*else {
											var errorMessage = i18nModel.getModel("i18n").getProperty('dupCarrier');
											errorMessage = errorMessage.replace("{DocId}", sDocId);
											oInsCreateDailog.close();
											MessageBox.show(
												errorMessage, {
													icon: MessageBox.Icon.ERROR,
													title: i18nModel.getModel("i18n").getProperty('errorAddOrd') //"Error during submitting!"
												});
										}*/
											/* For Lumber Load Process CTRM-1189*/
											else {
												if (sRegion === "US") { // lumber loading start
													if (sOrdertype === "Raw Materials" || sOrdertype === "STO Receipt") {
														var chepEntryRaw = {};
														chepEntryRaw.chepdeliverynumber = sDocId;
														chepEntryRaw.Plant = oData.Werks;
														chepEntryRaw.OrderType = sOrdertype; // Lumber load processing adding order type
														sCHEPOrders.push(chepEntryRaw);
														var chepRawModel = new sap.ui.model.json.JSONModel({
															"results": sCHEPOrders
														});
														that.byId("DetailTable_ID").setModel(chepRawModel, "deliveryMod");
														that.addDelvDialog.close();
													} else {
														var errorMessage1 = i18nModel.getModel("i18n").getProperty('dupCarrier');
														errorMessage1 = errorMessage1.replace("{DocId}", sDocId);
														oInsCreateDailog.close();
														MessageBox.show(
															errorMessage1, {
																icon: MessageBox.Icon.ERROR,
																title: i18nModel.getModel("i18n").getProperty('errorAddOrd') //"Error during submitting!"
															});
													}
												} else {
													var errorMessage = i18nModel.getModel("i18n").getProperty('dupCarrier');
													errorMessage = errorMessage.replace("{DocId}", sDocId);
													oInsCreateDailog.close();
													MessageBox.show(
														errorMessage, {
															icon: MessageBox.Icon.ERROR,
															title: i18nModel.getModel("i18n").getProperty('errorAddOrd') //"Error during submitting!"
														});
												}
											}
										}
										oInsCreateDailog.close();
									} else if (((sOrdertype.toLowerCase() === "Issue") || (sOrdertype.toLowerCase() === "issue")) ||
										((sOrdertype.toLowerCase() === "STO Issue") || (sOrdertype.toLowerCase() === "sto issue"))) {

										// if ((shDel !== ShCondition && shDel !== undefined) || (ShCondition !== "Z1" && oHeaderUAflag === "X")) {
										//below line is added to fix esp-4295 unable to add two z2 deliveries
										if (((shDel !== ShCondition && shDel !== undefined) || ((ShCondition !== "Z1" && oUAbtnFlag === "X")) && oHeaderUAflag ===
											"X")) {

											// if (ShCondition !== "Z1" && oHeaderUAflag === "X") {
											var errorMsgUA = i18nModel.getModel("i18n").getProperty('ouAdelCheckinTyp');
											errorMsgUA = errorMsgUA.replace("{DocId}", sDocId).replace("{ShCondition}", ShCondition);
											oInsCreateDailog.close();
											MessageBox.show(
												errorMsgUA, {
													icon: MessageBox.Icon.ERROR,
													title: i18nModel.getModel("i18n").getProperty('errorAddOrd') //"Error during submitting!"
												});
											// }
										} else if (sRegion === "US" && sOrdertype === "STO Issue" || sOrdertype === "sto issue") { // lumber loading start
											var errorMessageLumLoad = i18nModel.getModel("i18n").getProperty('dupCarrier');
											errorMessageLumLoad = errorMessageLumLoad.replace("{DocId}", sDocId);
											oInsCreateDailog.close();
											MessageBox.show(
												errorMessageLumLoad, {
													icon: MessageBox.Icon.ERROR,
													title: i18nModel.getModel("i18n").getProperty('errorAddOrd') //"Error during submitting!"
												});

										} else {
											if (jQuery.sap.storage(jQuery.sap.storage.Type.local).get("sVendor") === sVendorAdd) {
												if (that.byId("deliverynum") !== undefined) {
													that.byId("deliverynum").setValueState(sap.ui.core.ValueState.None);
												}
												// jQuery.sap.storage(jQuery.sap.storage.Type.local).put("DeliveryNumber", deliverynumber);

												/*Code Added for Milk run to set Visibity of Add Button*/
												if (that.byId("addDelv") !== undefined) {
													that.byId("addDelv").setVisible(true);
												}
												if (that.byId("tipPreloadTab") !== undefined) {
													that.byId("tipPreloadTab").setVisible(true);
												}
												if (that.byId("unknown") !== undefined) {
													that.byId("unknown").setVisible(false);
												}

												if (sDuplicateDel !== "X") {
													var TipChepEntry = {};
													TipChepEntry.chepdeliverynumber = sDocId;
													TipChepEntry.Plant = oData.Werks;
													if (that.salesOrderPopUp === "S") {
														var sTipModel = that.byId("tipPreloadTab").getModel("tipPreMod").getData().results;
														sTipModel.push(TipChepEntry);
														var tipModel = new sap.ui.model.json.JSONModel({
															"results": sTipModel
														});
														that.byId("tipPreloadTab").setModel(tipModel, "tipPreMod");
													} else {
														sPreloadOrder.push(TipChepEntry);
														var tipModel = new sap.ui.model.json.JSONModel({
															"results": sPreloadOrder
														});
														that.byId("tipPreloadTab").setModel(tipModel, "tipPreMod");
													}

													that.addDelvDialog.close();
												} else {
													var oerrorUpdate = i18nModel.getModel("i18n").getProperty('errorDuringUpdate');
													var oDuplicate = i18nModel.getModel("i18n").getProperty('sameOrderNum');
													MessageBox.show(
														oDuplicate, {
															icon: MessageBox.Icon.ERROR,
															title: oerrorUpdate
														});
												}
											} else {
												var errorMessage = i18nModel.getModel("i18n").getProperty('dupCarrier');
												errorMessage = errorMessage.replace("{DocId}", sDocId);
												oInsCreateDailog.close();
												MessageBox.show(
													errorMessage, {
														icon: MessageBox.Icon.ERROR,
														title: i18nModel.getModel("i18n").getProperty('errorAddOrd') //"Error during submitting!"
													});
											}
										}

										if (sCHEPOrders.length > 0) {
											if (that.byId("DetailTable_ID") !== undefined) {
												that.byId("DetailTable_ID").setVisible(true);
											}
										}

										oInsCreateDailog.close();

									}
									//Begin of changes by Sharmila
									else if (sOrdertype === "SO" || sOrdertype === "PO" || sOrdertype === "SH") {

										/*Get the Data from the Issues and Returns Table*/
										var sFinalArray = that.onGetAllDataFromTables();
										var sAllDelForShip = JSON.parse(oData.JsonDeliveries);
										if (sAllDelForShip.length > 0) {
											var sRemovedDel = that.onFilterDeliveries(sFinalArray, sAllDelForShip);
											if (sRemovedDel.length > 0) {
												var oModelDeliveries = new sap.ui.model.json.JSONModel(sRemovedDel);
												that.getView().setModel(oModelDeliveries, "oModelDeliveries");
												that.addDelvDialog.close();
												that._getDialogDeliverieslist().open();
											} else {
												that.addDelvDialog.close();
												var oerrorUpdate = i18nModel.getModel("i18n").getProperty('errorDuringUpdate');
												var oDuplicate = i18nModel.getModel("i18n").getProperty('alreadyShip');
												MessageBox.show(
													oDuplicate, {
														icon: MessageBox.Icon.ERROR,
														title: oerrorUpdate
													});
											}
										}
									} else {
										oInsCreateDailog.close();
										MessageBox.show(
											i18nModel.getModel("i18n").getProperty('orderInvalid'), {
												icon: MessageBox.Icon.ERROR,
												title: i18nModel.getModel("i18n").getProperty('submitError') //"Error during submitting!"
											});
									}
								}
							},
							error: function(oErrorMsg) {
								// var i18nModel = that.getOwnerComponent();
								var oErrorMessage = (JSON.parse(oErrorMsg.responseText).error.message.value);
								var oMessage;
								if (oErrorMessage !== "" || oErrorMessage !== undefined) {
									oMessage = oErrorMessage;
									// if (oErrorMessage.includes("01")) {
									if (oErrorMessage.includes("01") && (!oErrorMessage.includes("BH_RULES"))) {
										oErrorMessage = oErrorMessage.split("01");
										oMessage = oErrorMessage[1] + " - " + i18nModel.getModel("i18n").getProperty('errorSAPBlockMsg');
									} else if (oErrorMessage === "Cancel") {
										oMessage = i18nModel.getModel("i18n").getProperty('cancelDelErrorMsg');
									} else if (oErrorMessage === "SINGLE") {
										oMessage = i18nModel.getModel("i18n").getProperty('vl02ErrorMsg');
									}
									//Begin of changes by Sharmila
									else if (oErrorMessage.includes("Invalid-Plant")) {
										//Raise error message for driver location
										var plant_name = oErrorMessage.replace("Invalid-Plant-", "");
										var oMessage1 = i18nModel.getModel("i18n").getProperty('InvalidPlantErrorMsg');
										//Sharmila For Split the messges//
										var formattedString = oMessage1.split(".");
										var oVal1 = formattedString[0].concat("." + "\n");
										var oVal2 = formattedString[1].concat("\n");
										var oVal3 = formattedString[2].concat("." + "\n");
										oMessage = oVal1 + oVal2 + oVal3;
										oMessage = oMessage.replace("{Del #}", deliverynumber);
										oMessage = oMessage.replace("{Plant code and Name}", plant_name);
									} else if (oErrorMessage.includes("STO")) {
										//Raise error message for STO
										oMessage = i18nModel.getModel("i18n").getProperty('errorSTOMsg');

									} else if (oErrorMessage.includes("Invalid_BH")) {
										//Raise error message for invalid business Hours
										oMessage = i18nModel.getModel("i18n").getProperty('errorBHV');
									} else if (oErrorMessage.includes("BH_RULES")) {
										//Raise error message for invalid business Hours
										var t = oErrorMessage.replace('BH_RULES/', "");
										var hrs = t.split('/'); // separtes shift hours
										var sHrs = hrs.join(' ').trim();
										var shifthours = sHrs.split(' ');
										var time = '';
										for (var i = 0; i < shifthours.length; i++) {
											if (i % 2 === 0) {
												var val = " " + i18nModel.getModel("i18n").getProperty('To') + " ";
												time = time + shifthours[i].slice(0, 2) + ":" + shifthours[i].slice(2, 4) + ":" + shifthours[i].slice(4, 6) + " " +
													shifthours[i].slice(6, 8) + " " + val;
											} else {
												if (i < shifthours.length - 1) {
													var val = " " + i18nModel.getModel("i18n").getProperty('And') + " ";
													time = time + shifthours[i].slice(0, 2) + ":" + shifthours[i].slice(2, 4) + ":" + shifthours[i].slice(4, 6) + " " +
														shifthours[i].slice(6, 8) + "" + val;
												} else {
													time = time + shifthours[i].slice(0, 2) + ":" + shifthours[i].slice(2, 4) + ":" + shifthours[i].slice(4, 6) + " " +
														shifthours[i].slice(6, 8);
												}
											}

										}
										// console.log(time);
										//	var msg = i18nModel.getModel("i18n").getProperty('errorBHrules');
										var msg = i18nModel.getModel("i18n").getProperty('erroroutSideBHrs');
										oMessage = msg.replace("{timings}", time);
									} else if (oErrorMessage.includes("Invalid-Delivery")) {
										oMessage = i18nModel.getModel("i18n").getProperty('noShipmentCreated');
									} else if (oErrorMessage.includes("Delivery-Not-Found")) {
										oMessage = i18nModel.getModel("i18n").getProperty('deliveryNotFound');
									}
									//End of changes by Sharmila
									else {
										oMessage = oErrorMessage;
									}
								} else {
									oMessage = i18nModel.getModel("i18n").getProperty('orderInvalid');
								}
								// for Invalid chep order number with passthrough flag false
								// var oMessage = (JSON.parse(oErrorMsg.responseText).error.message.value);
								oInsCreateDailog.close();

								var submitError = i18nModel.getModel("i18n").getProperty('submitError');
								MessageBox.show(
									oMessage, {
										icon: MessageBox.Icon.ERROR,
										title: submitError //"Error during submitting!"
									});
							}
						});
					}
				}
			});
		},

		onGetAllDataFromTables: function() {
			var that = this;
			var oView = that.getView();
			var sReturnData = oView.byId("DetailTable_ID").getModel("deliveryMod").getData().results;
			var sIssueData = oView.byId("tipPreloadTab").getModel("tipPreMod").getData().results;
			return sReturnData.concat(sIssueData);
		},

		onFilterDeliveries: function(addedDel, serviceDel) {
			serviceDel = serviceDel.filter(function(item) {
				for (var i = 0, len = addedDel.length; i < len; i++) {
					if (addedDel[i].chepdeliverynumber === item.DELIV) {
						return false;
					}
				}
				return true;
			});
			return serviceDel;
		},

		onAddDeliveries: function() {
			var that = this;
			var deliverynumber;
			if (sap.ui.getCore().byId("addDeliveryNo") !== undefined) {
				deliverynumber = sap.ui.getCore().byId("addDeliveryNo").getValue().trim();
			}
			if (deliverynumber === "") {
				sap.ui.getCore().byId("addDeliveryNo").setValueState(sap.ui.core.ValueState.Error);
				var enterOrderNum = that.getView().getModel("i18n").getProperty('enterOrderNum');
				var submitError = that.getView().getModel("i18n").getProperty('submitError');
				var oMessage = enterOrderNum; //"Please Enter Order Number";
				MessageBox.show(
					oMessage, {
						icon: MessageBox.Icon.ERROR,
						title: submitError //"Error during submitting!"
					});
			} else {

				var sDeliveryFlag;
				var sDeliveryFlagTip;
				var i18nModel = that.getOwnerComponent();
				if (that.getView().byId("DetailTable_ID") !== undefined) {
					var milkTableData = that.getView().byId("DetailTable_ID").getModel("deliveryMod").getData().results;
				}
				if (milkTableData.length !== 0) {
					for (var i = 0; i < milkTableData.length; i++) {
						if (deliverynumber === milkTableData[i].chepdeliverynumber) {
							sDeliveryFlag = 'X';
							var errorUpdate = i18nModel.getModel("i18n").getProperty('errorDuringUpdate');
							var sDuplicate = i18nModel.getModel("i18n").getProperty('orderInvalid');
							MessageBox.show(
								sDuplicate, {
									icon: MessageBox.Icon.ERROR,
									title: errorUpdate
								});
							break;
						}
					}
				}

				if (that.getView().byId("tipPreloadTab") !== undefined) {
					var tipTableData = that.getView().byId("tipPreloadTab").getModel("tipPreMod").getData().results;
				}
				if (tipTableData.length !== 0) {
					for (var iCount = 0; iCount < tipTableData.length; iCount++) {
						if (deliverynumber === tipTableData[iCount].chepdeliverynumber) {
							sDeliveryFlagTip = 'X';
							var errorUpdate1 = i18nModel.getModel("i18n").getProperty('errorDuringUpdate');
							var sDuplicate1 = i18nModel.getModel("i18n").getProperty('orderInvalid');
							MessageBox.show(
								sDuplicate1, {
									icon: MessageBox.Icon.ERROR,
									title: errorUpdate1
								});
							break;
						}
					}
				}

				if (sDeliveryFlag !== "X" && sDeliveryFlagTip !== "X") {
					that.fnCreateBusyDialog("pallet.svg");
					that.onValidDelivery(deliverynumber);
				}
			}
		},

		onItemDelete: function(e) {
			var that = this;
			var i18nModel = that.getOwnerComponent();
			var noDataText = i18nModel.getModel("i18n").getProperty('noData');
			that.fnCreateBusyDialog("pallet.svg");
			if (e.getSource().getParent().getParent().getItems().length > 0) {
				var path1 = e.getSource().oPropagatedProperties.oBindingContexts.deliveryMod.sPath;
				var index = parseInt(path1.substring(path1.lastIndexOf('/') + 1));
				var m = e.getSource().getModel("deliveryMod");
				var d = m.getData().results;
				d.splice(index, 1);
				m.setProperty("/results", d);
				that.getView().byId("DetailTable_ID").setNoDataText(noDataText);
				oInsCreateDailog.close();
			}
		},
		onPreDelete: function(e) {
			var that = this;
			var i18nModel = that.getOwnerComponent();
			var noDataText = i18nModel.getModel("i18n").getProperty('noData');
			that.fnCreateBusyDialog("pallet.svg");
			if (e.getSource().getParent().getParent().getItems().length > 0) {
				var path1 = e.getSource().oPropagatedProperties.oBindingContexts.tipPreMod.sPath;
				var index = parseInt(path1.substring(path1.lastIndexOf('/') + 1));
				var m = e.getSource().getModel("tipPreMod");
				var d = m.getData().results;
				d.splice(index, 1);
				m.setProperty("/results", d);
				that.getView().byId("tipPreloadTab").setNoDataText(noDataText);
				oInsCreateDailog.close();
			}
		},

		onCancelDelv: function() {
			var that = this;
			if (sap.ui.getCore().byId("addDeliveryNo") !== undefined) {
				sap.ui.getCore().byId("addDeliveryNo").setValue("");
			}
			that.addDelvDialog.close();
		},

		onListDeliveriesOK: function() {
			listDelvDialog.close();
		},

		//-----------Function for Cancel Button---------------//
		onCancel: function() {
			var that = this;
			if (that.byId("deliverynum") !== undefined) {
				that.byId("deliverynum").setValue("");
			}

			jQuery.sap.storage(jQuery.sap.storage.Type.local).put("DeliveryNumber", "");

			if (that.byId("DetailTable_ID") !== undefined) {

				var data1 = [];
				var oModel11 = new sap.ui.model.json.JSONModel({
					"results": data1
				});
				that.getView().byId("DetailTable_ID").setModel(oModel11, "deliveryMod");
				that.byId("DetailTable_ID").setVisible(false);
			}
			if (that.byId("tipPreloadTab") !== undefined) {

				var tipPrloadEmt = [];
				var tipPrloadoModelEmp = new sap.ui.model.json.JSONModel({
					"results": tipPrloadEmt
				});
				that.getView().byId("tipPreloadTab").setModel(tipPrloadoModelEmp, "tipPreMod");
				that.byId("tipPreloadTab").setVisible(false);
			}

			if (that.byId("unknown") !== undefined) {

				// that.getView().byId("unknown").setVisible(true);
				if (vAuthorized === "false") { // Based on config UA button is disabled(ESP-3800)
					that.getView().byId("unknown").setVisible(false);
				} else {
					that.getView().byId("unknown").setVisible(true);
				}
			}

			if (that.byId("addDelv") !== undefined) {
				that.getView().byId("addDelv").setVisible(false);
			}
			if (that.byId("DetailTable_ID") !== undefined) {
				that.getView().byId("DetailTable_ID").setVisible(false);
			}
			if (that.byId("tipPreloadTab") !== undefined) {
				that.getView().byId("tipPreloadTab").setVisible(false);
			}

			if (kioskId !== "XXXXXXXXXX") {
				var oCrossAppNavigator = sap.ushell.Container.getService("CrossApplicationNavigation");
				var hash = "ZESP_CHECKIN-display?sap-language=" + sLanguage + "&KIOSK_ID=" + kioskId + "&/EULADeclined";
				oCrossAppNavigator.toExternal({
					target: {
						shellHash: hash
					}
				});
			}
		},

		//-----------Back button functionality---------------//
		onNavBack: function() {
			var that = this;
			var oRouter = sap.ui.core.UIComponent.getRouterFor(this);
			oRouter.navTo("Agreement");
			if (this.byId("deliverynum") !== undefined) {
				this.byId("deliverynum").setValue("");
			}
			if (this.byId("addDelv") !== undefined) {
				this.getView().byId("addDelv").setVisible(false);
			}
			if (this.byId("DetailTable_ID") !== undefined) {
				this.getView().byId("DetailTable_ID").setVisible(false);
			}
			if (this.byId("tipPreloadTab") !== undefined) {
				this.getView().byId("tipPreloadTab").setVisible(false);
			}
			this.byId("deliverynum").setValueState(sap.ui.core.ValueState.None);
			that.shipContinueCheck = "";
			that.salesOrderPopUp = "";
		},

		//----------------------Continue button functionality---------------------//
		onContinue: function() {
			var that = this;
			var deliverynumber;
			if (oTriploadUA === "X") {
				deliverynumber = that.getView().byId("deliverynum").getValue().trim();
			}
			/*Tip/Preload Change*/
			var sMilkData = that.getView().byId("DetailTable_ID").getModel("deliveryMod").getData().results;
			var sMilkDataissues = that.getView().byId("tipPreloadTab").getModel("tipPreMod").getData().results; //Sharmila
			if (sMilkData.length > 0) {
				// deliverynumber = sMilkData[0].chepdeliverynumber;
				// jQuery.sap.storage(jQuery.sap.storage.Type.local).put("DeliveryNumber", deliverynumber);
				if (sRegion === "US") { // Lumber load processing CTRM 1189
					for (var i = 0; i < sMilkData.length; i++) {
						if (sMilkData[i].OrderType === "STO Receipt") { // Lumber load processing CTRM 1189
							deliverynumber = sMilkData[i].chepdeliverynumber;
						} else {
							if (sParentPlant) {
								if (sMilkData[i].Plant === sParentPlant) {
									deliverynumber = sMilkData[i].chepdeliverynumber;
									break;
								} else {
									deliverynumber = sMilkData[0].chepdeliverynumber;
								}
							} else {
								deliverynumber = sMilkData[0].chepdeliverynumber;
							}

						}
					}
					jQuery.sap.storage(jQuery.sap.storage.Type.local).put("DeliveryNumber", deliverynumber);
				} else {
					if (sParentPlant) {
						for (var j = 0; j < sMilkData.length; j++) {
							if (sMilkData[j].Plant === sParentPlant) {
								deliverynumber = sMilkData[j].chepdeliverynumber;
								break;
							} else {
								deliverynumber = sMilkData[0].chepdeliverynumber;
							}
						}

					} else {
						deliverynumber = sMilkData[0].chepdeliverynumber;
					}
					jQuery.sap.storage(jQuery.sap.storage.Type.local).put("DeliveryNumber", deliverynumber);
				}
			}
			//Begin of changes by Sharmila
			else if (sMilkDataissues.length >= 1) {

				if (sParentPlant) {
					for (var iCount = 0; iCount < sMilkDataissues.length; iCount++) {
						if (sMilkDataissues[iCount].Plant === sParentPlant) {
							deliverynumber = sMilkDataissues[iCount].chepdeliverynumber;
							break;
						} else {
							deliverynumber = sMilkDataissues[0].chepdeliverynumber;
						}
					}
				} else {

					deliverynumber = sMilkDataissues[0].chepdeliverynumber;
				}
				jQuery.sap.storage(jQuery.sap.storage.Type.local).put("DeliveryNumber", deliverynumber);
			}
			//End of changes by Sharmila
			else {
				deliverynumber = jQuery.sap.storage(jQuery.sap.storage.Type.local).get("DeliveryNumber");
			}
			if (deliverynumber === "") {
				that.byId("deliverynum").setValueState(sap.ui.core.ValueState.Error);
				var enterOrderNum = that.getView().getModel("i18n").getProperty('enterOrderNum');
				var submitError = that.getView().getModel("i18n").getProperty('submitError');
				var oMessage = enterOrderNum; //"Please Enter Order Number";
				MessageBox.show(
					oMessage, {
						icon: MessageBox.Icon.ERROR,
						title: submitError //"Error during submitting!"
					});
			} else if (deliverynumber !== "") {
				that.byId("deliverynum").setValueState(sap.ui.core.ValueState.None);
				var oModelCheck = that.getOwnerComponent().getModel("checkedMod");
				var i18nModel = that.getOwnerComponent();
				if (that.getView().byId("DetailTable_ID") !== undefined) {
					var milkTableData = that.getView().byId("DetailTable_ID").getModel("deliveryMod").getData().results;
				}
				if (that.getView().byId("tipPreloadTab") !== undefined) {
					var tipTableData = that.getView().byId("tipPreloadTab").getModel("tipPreMod").getData().results;
				}

				//------------Start of code for Adding Leading zeros when checked in with Shipment number -----------//

				if (deliverynumber.length === 8) {
					deliverynumber = "00" + deliverynumber;

				}

				//------------End of code for Adding Leading zeros when checked in with Shipment number -----------//

				that.fnCreateBusyDialog("pallet.svg");
				jQuery.sap.storage(jQuery.sap.storage.Type.local).put("milkRunList", milkTableData);
				jQuery.sap.storage(jQuery.sap.storage.Type.local).put("tipReloadList", tipTableData);

				var oRetnUA = this.getView().byId("DetailTable_ID").getModel("deliveryMod").getData().results;
				jQuery.sap.storage(jQuery.sap.storage.Type.local).put("milkRunListUA", oRetnUA);
				var oIssueUA = this.getView().byId("tipPreloadTab").getModel("tipPreMod").getData().results;
				jQuery.sap.storage(jQuery.sap.storage.Type.local).put("tipReloadListUA", oIssueUA);

				// var sParentPlant = that.ParentPlant;
				if ((oTriploadUA === "X" || oHeaderUAflag === "X") && oUAbtnFlag === "X") {
					that.onNoPress();
				} else {
					oModelCheck.read("/CheckInSet(Werks='" + vLoadPlant + "',DocId='" + deliverynumber + "')", {
						success: function(oData, oResponse) {
							if (oResponse.statusCode === "200") {
								oInsCreateDailog.close();
								sDocId = oData.DocId;
								// if user enters Sales order number get delivery number associated with that sales order number
								jQuery.sap.storage(jQuery.sap.storage.Type.local).put("DeliveryNumberforSalesOrder", sDocId);
								jQuery.sap.storage(jQuery.sap.storage.Type.local).put("DeliveryNumber", sDocId);
								sOrdertype = oData.OrderType;
								sLocation = oData.Location;
								var sLfart = oData.Lfart;
								jQuery.sap.storage(jQuery.sap.storage.Type.local).put("sLfrt", sLfart);
								if (sRegion !== "US") {
									jQuery.sap.storage(jQuery.sap.storage.Type.local).put("Lifnr", oData.Vendor);
								} else {
									jQuery.sap.storage(jQuery.sap.storage.Type.local).put("Scac", oData.Carrier);
								}
								jQuery.sap.storage(jQuery.sap.storage.Type.local).put("ShipCondition", oData.ShCondition);
								jQuery.sap.storage(jQuery.sap.storage.Type.local).put("Ordertype", sOrdertype);
								jQuery.sap.storage(jQuery.sap.storage.Type.local).put("Location", sLocation);

								// if (sOrdertype === "SO" || sOrdertype === "PO" || sOrdertype === "SH") {
								// 	//Get associated deliveries based on Sales/Purchase/Shipment Order
								// 	var sAllDelForShip = JSON.parse(oData.JsonDeliveries);
								// 	var oModelDeliveries = new sap.ui.model.json.JSONModel(sAllDelForShip);
								// 	that.getView().setModel(oModelDeliveries, "oModelDeliveries");
								// 	if (that.byId("addDelv") !== undefined) {
								// 		that.byId("addDelv").setVisible(true);
								// 	}
								// 	if (that.byId("unknown") !== undefined) {
								// 		that.byId("unknown").setVisible(false);
								// 	}
								// 	that._getDialogDeliverieslist().open();
								// oInsCreateDailog.close();

								// 	} else {

								// 		var sHeaderMsg = oResponse.headers.message; //CheckedIn message

								// 		if (sHeaderMsg !== undefined) { // for Valid and Submitted number
								// 			if (sHeaderMsg !== "") {
								// 				switch (sHeaderMsg) {
								// 					case "CheckedIn":
								// 						var oMessage = i18nModel.getModel("i18n").getProperty('checkdIn');
								// 						break;
								// 					case "Completed":
								// 						var oMessage = i18nModel.getModel("i18n").getProperty('orderCompleted');
								// 						break;
								// 				}
								// 				//	var oMessage = sHeaderMsg;
								// 				var submitError = i18nModel.getModel("i18n").getProperty('submitError');
								// 				MessageBox.show(
								// 					oMessage, {
								// 						icon: MessageBox.Icon.ERROR,
								// 						title: submitError //"Error during submitting!"
								// 					});
								// 			}
								// 		} else {
								// 			oInsCreateDailog.close();
								// 			//	jQuery.sap.storage(jQuery.sap.storage.Type.local).put("DeliveryNumber", sDocId);
								// 			jQuery.sap.storage(jQuery.sap.storage.Type.local).put("validFlag", true);
								// 			oRouterObject.navTo("DeliveryDetails");
								// 		}
								// 	}

								//------------Start of code for displaying list of deliveries popup for the given shipment when click on continue buttton-----------//

								if (that.shipContinueCheck === "") {
									if (((sOrdertype.toLowerCase() === "Collect") || (sOrdertype.toLowerCase() === "collect")) || ((sOrdertype ===
											"Raw Materials")) ||
										((sOrdertype.toLowerCase() === "STO Receipt") || (sOrdertype.toLowerCase() === "sto receipt"))) {

										delNumFlag = "R";
										jQuery.sap.storage(jQuery.sap.storage.Type.local).put("sDeliveryType", delNumFlag);
										//	if (milkRunFlag === "true") {
										if (that.byId("deliverynum") !== undefined) {
											that.byId("deliverynum").setValueState(sap.ui.core.ValueState.None);
										}
										// jQuery.sap.storage(jQuery.sap.storage.Type.local).put("DeliveryNumber", deliverynumber);
										sCHEPOrders = [];
										//	that.fnCreateBusyDialog("pallet.svg");
										/*Code Added for Milk run to set Visibity of Add Button*/
										if (that.byId("addDelv") !== undefined) {
											that.byId("addDelv").setVisible(true);
										}
										if (that.byId("DetailTable_ID") !== undefined) {
											that.byId("DetailTable_ID").setVisible(true);
											var oModelEmpty = new sap.ui.model.json.JSONModel({
												"results": sCHEPOrders
											});
											that.getView().byId("DetailTable_ID").setModel(oModelEmpty, "deliveryMod");
											//	oInsCreateDailog.close();
										}
										if (that.byId("unknown") !== undefined) {
											that.byId("unknown").setVisible(false);
										}
										//	oInsCreateDailog.close();
										var chepEntry = {};
										chepEntry.chepdeliverynumber = sDocId;
										chepEntry.OrderType = sOrdertype; // Lumber load processing adding order type
										chepEntry.Plant = oData.Werks;
										sCHEPOrders.push(chepEntry);
										var chepModel = new sap.ui.model.json.JSONModel({
											"results": sCHEPOrders
										});
										that.byId("DetailTable_ID").setModel(chepModel, "deliveryMod");

										that.shipContinueCheck = "C";
										// oInsCreateDailog.close();
										/*	} else {
													if (that.byId("addDelv") !== undefined) {
														that.byId("addDelv").setVisible(false);
													}
													if (that.byId("DetailTable_ID") !== undefined) {
														that.byId("DetailTable_ID").setVisible(false);
													}
													if (that.byId("unknown") !== undefined) {
														if (vAuthorized === "false") {
															that.byId("unknown").setVisible(false);
														} else {
															that.byId("unknown").setVisible(true);
														}
													}
													oInsCreateDailog.close();
												}*/
									} else if (((sOrdertype.toLowerCase() === "Issue") || (sOrdertype.toLowerCase() === "issue")) ||
										((sOrdertype.toLowerCase() === "STO Issue") || (sOrdertype.toLowerCase() === "sto issue"))) {
										if (that.byId("deliverynum") !== undefined) {
											that.byId("deliverynum").setValueState(sap.ui.core.ValueState.None);
										}
										// jQuery.sap.storage(jQuery.sap.storage.Type.local).put("DeliveryNumber", deliverynumber);
										delNumFlag = "I";
										jQuery.sap.storage(jQuery.sap.storage.Type.local).put("sDeliveryType", delNumFlag);
										sPreloadOrder = [];

										if (that.byId("addDelv") !== undefined) {
											that.byId("addDelv").setVisible(true);
										}
										if (that.byId("tipPreloadTab") !== undefined) {
											that.byId("tipPreloadTab").setVisible(true);
											var tipEmpty = new sap.ui.model.json.JSONModel({
												"results": sPreloadOrder
											});
											that.getView().byId("tipPreloadTab").setModel(tipEmpty, "tipPreMod");
										}

										if (that.byId("DetailTable_ID") !== undefined) {
											that.byId("DetailTable_ID").setVisible(false);
										}
										if (that.byId("unknown") !== undefined) {
											that.byId("unknown").setVisible(false);
										}
										var chepEntryTip = {};
										chepEntryTip.chepdeliverynumber = sDocId;
										chepEntryTip.Plant = oData.Werks;
										sPreloadOrder.push(chepEntryTip);
										var chepTipModel = new sap.ui.model.json.JSONModel({
											"results": sPreloadOrder
										});
										that.byId("tipPreloadTab").setModel(chepTipModel, "tipPreMod");
										that.shipContinueCheck = "C";
										// oInsCreateDailog.close();

									} else if (sOrdertype === "SO" || sOrdertype === "PO" || sOrdertype === "SH") {
										//Get associated deliveries based on Sales/Purchase/Shipment Order
										var sAllDelForShip = JSON.parse(oData.JsonDeliveries);
										var oModelDeliveries = new sap.ui.model.json.JSONModel(sAllDelForShip);
										that.getView().setModel(oModelDeliveries, "oModelDeliveries");
										if (that.byId("addDelv") !== undefined) {
											that.byId("addDelv").setVisible(true);
										}
										if (that.byId("unknown") !== undefined) {
											that.byId("unknown").setVisible(false);
										}
										that._getDialogDeliverieslist().open();
										that.shipContinueCheck = "C";
										// oInsCreateDailog.close();

									} else {

										var sHeaderMsg = oResponse.headers.message; //CheckedIn message

										if (sHeaderMsg !== undefined) { // for Valid and Submitted number
											if (sHeaderMsg !== "") {
												switch (sHeaderMsg) {
													case "CheckedIn":
														var oMessage = i18nModel.getModel("i18n").getProperty('checkdIn');
														break;
													case "Completed":
														var oMessage = i18nModel.getModel("i18n").getProperty('orderCompleted');
														break;
												}
												//	var oMessage = sHeaderMsg;
												var submitError = i18nModel.getModel("i18n").getProperty('submitError');
												MessageBox.show(
													oMessage, {
														icon: MessageBox.Icon.ERROR,
														title: submitError //"Error during submitting!"
													});
											}
											//------------End of code for displaying list of deliveries popup for the given shipment when click on continue buttton-----------//
										} else {
											oInsCreateDailog.close();
											//	jQuery.sap.storage(jQuery.sap.storage.Type.local).put("DeliveryNumber", sDocId);
											jQuery.sap.storage(jQuery.sap.storage.Type.local).put("validFlag", true);
											oRouterObject.navTo("DeliveryDetails");
										}
									}
								} else {
									oInsCreateDailog.close();
									//	jQuery.sap.storage(jQuery.sap.storage.Type.local).put("DeliveryNumber", sDocId);
									jQuery.sap.storage(jQuery.sap.storage.Type.local).put("validFlag", true);
									oRouterObject.navTo("DeliveryDetails");
								}
							}
						},
						error: function(oError) {
							oInsCreateDailog.close();
							jQuery.sap.storage(jQuery.sap.storage.Type.local).put("Lifnr", "");
							jQuery.sap.storage(jQuery.sap.storage.Type.local).put("Scac", "");
							jQuery.sap.storage(jQuery.sap.storage.Type.local).put("ShipCondition", "");
							jQuery.sap.storage(jQuery.sap.storage.Type.local).put("validFlag", false);
							if (oError.responseText !== "") {
								var oErrorMessage = (JSON.parse(oError.responseText).error);
								if (oErrorMessage !== undefined) {
									if (oErrorMessage.message !== undefined) {
										var invalidBHMessage = oErrorMessage.message.value;
									}
								}
							}

							if (invalidBHMessage.includes("Invalid_BH")) {
								//Raise error message for invalid business Hours
								var oBHErrorMessage = i18nModel.getModel("i18n").getProperty('errorBHV');
								var errorTitle = i18nModel.getModel("i18n").getProperty('submitError');
								MessageBox.show(
									oBHErrorMessage, {
										icon: MessageBox.Icon.ERROR,
										title: errorTitle //"Error during submitting!"
									});
							} else if (invalidBHMessage.includes("Invalid-Delivery")) {
								var oShipMentNotCreatedMsg = i18nModel.getModel("i18n").getProperty('noShipmentCreated');
								var Title = i18nModel.getModel("i18n").getProperty('submitError');
								MessageBox.show(
									oShipMentNotCreatedMsg, {
										icon: MessageBox.Icon.ERROR,
										title: Title //"Error during submitting!"
									});
							} else if (invalidBHMessage.includes("Delivery-Not-Found")) {
								var oDeliveryNotFound = i18nModel.getModel("i18n").getProperty('deliveryNotFound');
								var ErrTitle = i18nModel.getModel("i18n").getProperty('submitError');
								MessageBox.show(
									oDeliveryNotFound, {
										icon: MessageBox.Icon.ERROR,
										title: ErrTitle //"Error during submitting!"
									});
							} else if (invalidBHMessage.includes("BH_RULES")) {
								//Raise error message for invalid business Hours
								var t = invalidBHMessage.replace('BH_RULES/', "");
								var hrs = t.split('/'); // separtes shift hours
								var sHrs = hrs.join(' ').trim();
								var shifthours = sHrs.split(' ');
								var time = '';
								for (var i = 0; i < shifthours.length; i++) {
									if (i % 2 === 0) {
										var val = " " + i18nModel.getModel("i18n").getProperty('To') + " ";
										time = time + shifthours[i].slice(0, 2) + ":" + shifthours[i].slice(2, 4) + ":" + shifthours[i].slice(4, 6) + " " +
											shifthours[i].slice(6, 8) + " " + val;
									} else {
										if (i < shifthours.length - 1) {
											var val = " " + i18nModel.getModel("i18n").getProperty('And') + " ";
											time = time + shifthours[i].slice(0, 2) + ":" + shifthours[i].slice(2, 4) + ":" + shifthours[i].slice(4, 6) + " " +
												shifthours[i].slice(6, 8) + "" + val;
										} else {
											time = time + shifthours[i].slice(0, 2) + ":" + shifthours[i].slice(2, 4) + ":" + shifthours[i].slice(4, 6) + " " +
												shifthours[i].slice(6, 8);
										}
									}

								}
								// console.log(time);
								//	var msg = i18nModel.getModel("i18n").getProperty('errorBHrules');
								var msg = i18nModel.getModel("i18n").getProperty('erroroutSideBHrs');
								var sMessage = msg.replace("{timings}", time);
								var errorTitle = i18nModel.getModel("i18n").getProperty('submitError');
								MessageBox.show(
									sMessage, {
										icon: MessageBox.Icon.ERROR,
										title: errorTitle //"Error during submitting!"
									});
							} else {
								if (sPassthrough === "true") { // for Invalid chep order number with passthrough flag true
									var that = this;
									var passThrough = i18nModel.getModel("i18n").getProperty('passThrough');
									var yesPassThrPress = i18nModel.getModel("i18n").getProperty("passthroughYes");
									var noPassThrPress = i18nModel.getModel("i18n").getProperty("passthroughNo");
									MessageBox._rb = sap.ui.getCore().getLibraryResourceBundle("sap.m", sLanguage);
									MessageBox.show(
										passThrough, {
											icon: MessageBox.Icon.ERROR,
											title: i18nModel.getModel("i18n").getProperty('orderNotValid'),
											//*** ESP -2427 ***//
											actions: [yesPassThrPress, noPassThrPress],
											onClose: function(oAction) {
												if (oAction === yesPassThrPress) {
													var vDoc = "P";
													jQuery.sap.storage(jQuery.sap.storage.Type.local).put("issueDrop", "");
													jQuery.sap.storage(jQuery.sap.storage.Type.local).put("returnDrop", "");
													jQuery.sap.storage(jQuery.sap.storage.Type.local).put("PageType", "CI");
													oRouterObject.navTo("TrailerInformation", {
														objectId: vDoc
													});
												} else if (noPassThrPress) {
													oRouterObject.navTo("CheckIn");
												}
											}
										});
								} else { // for Invalid chep order number with passthrough flag false
									//    var oMessage = (JSON.parse(oError.responseText).error.message.value);
									oInsCreateDailog.close();
									jQuery.sap.storage(jQuery.sap.storage.Type.local).put("PageType", "");
									var oMessage = i18nModel.getModel("i18n").getProperty('orderNotValid');
									var submitError = i18nModel.getModel("i18n").getProperty('submitError');
									MessageBox.show(
										oMessage, {
											icon: MessageBox.Icon.ERROR,
											title: submitError //"Error during submitting!"
										});
								}
							}
							//    jQuery.sap.storage(jQuery.sap.storage.Type.local).put("DeliveryNumber", deliverynumber);
						}
					});
				}
			}
		},

		onExit: function() {
			if (this.byId("deliverynum") !== undefined) {
				this.byId("deliverynum").setValue("");
			}
			sCHEPOrders = [];
			sPreloadOrder = [];
		},

		getRouter: function() {
			return sap.ui.core.UIComponent.getRouterFor(this);
		},

		//----------------------------------------------------------------------------------
		//Function to set logged in User Date pattern
		//----------------------------------------------------------------------------------
		fnSetUserDateFormat: function(rDate, sInsDateFormat) {
			if (rDate !== "") {
				var dFormDate;
				switch (sInsDateFormat) {
					case "1":
						dFormDate = rDate.slice(6, 8) + "." + rDate.slice(4, 6) + "." + rDate.slice(0, 4);
						break;
					case "2":
						dFormDate = rDate.slice(4, 6) + "/" + rDate.slice(6, 8) + "/" + rDate.slice(0, 4);
						break;
					case "3":
						dFormDate = rDate.slice(4, 6) + "-" + rDate.slice(6, 8) + "-" + rDate.slice(0, 4);
						break;
					case "4":
						dFormDate = rDate.slice(0, 4) + "." + rDate.slice(4, 6) + "." + rDate.slice(6, 8);
						break;
					case "5":
						dFormDate = rDate.slice(0, 4) + "/" + rDate.slice(4, 6) + "/" + rDate.slice(6, 8);
						break;
					case "6":
						dFormDate = rDate.slice(0, 4) + "-" + rDate.slice(4, 6) + "-" + rDate.slice(6, 8);
						break;
					case "A":
						dFormDate = rDate.slice(0, 4) + "/" + rDate.slice(4, 6) + "/" + rDate.slice(6, 8);
						break;
					case "B":
						dFormDate = rDate.slice(0, 4) + "/" + rDate.slice(4, 6) + "/" + rDate.slice(6, 8);
						break;
					case "C":
						dFormDate = rDate.slice(0, 4) + "/" + rDate.slice(4, 6) + "/" + rDate.slice(6, 8);
						break;
				}
			} else {
				var dFormDate = "";
			}
			return dFormDate;
		},

		//----Function for Opening th Drop and Hook Dialog-----//
		openDropHookFragment: function() {
			if (!this._DopandHookDialog) {
				this._DopandHookDialog = sap.ui.xmlfragment("chep.checkin.fragments.DropHook", this);
				this.getView().addDependent(this._DopandHookDialog);
			}
			jQuery.sap.syncStyleClass("sapUiSizeCompact", this.getView(), this._DopandHookDialog);
			this._DopandHookDialog.open();
		},

		//----Function for Opening th Drop and PickUp Dialog-----//
		openDropPickUpFragment: function() {
			if (!this._DropandPickDialog) {
				this._DropandPickDialog = sap.ui.xmlfragment("chep.checkin.fragments.DropPickup", this);
				this.getView().addDependent(this._DropandPickDialog);
			}
			jQuery.sap.syncStyleClass("sapUiSizeCompact", this.getView(), this._DropandPickDialog);
			this._DropandPickDialog.open();
		},

		//----Function for "Yes" button in Passthrough messagebox-----//
		//----Function for "I don't have Chep order number" button-----//

		onUnknown: function() {
			var that = this;
			that.byId("deliverynum").setValueState(sap.ui.core.ValueState.None);
			jQuery.sap.storage(jQuery.sap.storage.Type.local).put("PageType", "UA");
			var sPageType = jQuery.sap.storage(jQuery.sap.storage.Type.local).get("PageType");
			if (sPageType === "UA") {
				//this.byId("pageNo").setText("2 of 4");
				that.getView().getModel("pgmodel").setProperty("/pgStart", "2");
				that.getView().getModel("pgmodel").setProperty("/pgEnd", "4");
			}
			//	if ((vDropservice === "true") && (sRegion === "US")) {
			if (vDropservice === "true" || oHeaderUAflag === "X") {
				// that.openDropHookFragment();
				that.openDropPickUpFragment();
				if (oHeaderUAflag === "X") {
					that.getView().getModel("UAunknwnModel").setProperty("/onUacontinueBtn", true);
				}
				if (sRegion === "EU" || sRegion === "AR" || sRegion === "LATAM" || sRegion === "ZA" || sRegion === "AP" || sRegion === "CA") {
					that.getView().getModel("UAunknwnModel").setProperty("/variabgeText", false);
				}
			} else {
				jQuery.sap.storage(jQuery.sap.storage.Type.local).put("issueDrop", "");
				jQuery.sap.storage(jQuery.sap.storage.Type.local).put("returnDrop", "");
				jQuery.sap.storage(jQuery.sap.storage.Type.local).put("trailerTypeFV", "");
				jQuery.sap.storage(jQuery.sap.storage.Type.local).put("Lifnr", "");
				jQuery.sap.storage(jQuery.sap.storage.Type.local).put("ShipCondition", "");
				jQuery.sap.storage(jQuery.sap.storage.Type.local).put("Scac", "");
				jQuery.sap.storage(jQuery.sap.storage.Type.local).put("DeliveryNumber", "UA");
				jQuery.sap.storage(jQuery.sap.storage.Type.local).put("OrderType", "");
				if (!this.byId("deliverynum") === undefined) {
					this.byId("deliverynum").setValue("");
				}
				var oRouter = sap.ui.core.UIComponent.getRouterFor(this);
				var vDoc = "U";
				oRouter.navTo("TrailerInformation", {
					objectId: vDoc
				});
			}
		},
		onYesPress: function() {
			var that = this;
			if (!that._trailerfacilityDialog) {
				that._trailerfacilityDialog = sap.ui.xmlfragment("chep.checkin.fragments.HookedTrailer", that);
				that.getView().addDependent(that._trailerfacilityDialog);
			}
			// toggle compact style
			jQuery.sap.syncStyleClass("sapUiSizeCompact", that.getView(), that._trailerfacilityDialog);
			jQuery.sap.storage(jQuery.sap.storage.Type.local).put("sDandHBtnPress", "X");
			jQuery.sap.storage(jQuery.sap.storage.Type.local).put("dropNpickup", "X");
			jQuery.sap.storage(jQuery.sap.storage.Type.local).put("tUAbtnFlagtr", "");
			jQuery.sap.storage(jQuery.sap.storage.Type.local).put("trailerLive", "");
			// that._DopandHookDialog.close();
			that._DropandPickDialog.close();
			jQuery.sap.delayedCall(0, null, function() {
				that._trailerfacilityDialog.open();
			});
		},

		onNoPress: function() {
			var vDoc = "U",
				trailerLive = "X",
				oDelUAissue;
			jQuery.sap.storage(jQuery.sap.storage.Type.local).put("trailerLive", trailerLive);
			jQuery.sap.storage(jQuery.sap.storage.Type.local).put("Lifnr", "");
			jQuery.sap.storage(jQuery.sap.storage.Type.local).put("Scac", "");
			jQuery.sap.storage(jQuery.sap.storage.Type.local).put("ShipCondition", "");
			jQuery.sap.storage(jQuery.sap.storage.Type.local).put("DeliveryNumber", "UA");
			jQuery.sap.storage(jQuery.sap.storage.Type.local).put("issueDrop", "");
			jQuery.sap.storage(jQuery.sap.storage.Type.local).put("OrderType", "");
			jQuery.sap.storage(jQuery.sap.storage.Type.local).put("returnDrop", "X");
			jQuery.sap.storage(jQuery.sap.storage.Type.local).put("trailerTypeFV", "");
			jQuery.sap.storage(jQuery.sap.storage.Type.local).put("sLiveBtnPress", "X");
			jQuery.sap.storage(jQuery.sap.storage.Type.local).put("dropNpickup", "");
			jQuery.sap.storage(jQuery.sap.storage.Type.local).put("sDandHBtnPress", ""); // D&H senario empty the storage value onyespress action
			var oRetnUA = this.getView().byId("DetailTable_ID").getModel("deliveryMod").getData().results;
			jQuery.sap.storage(jQuery.sap.storage.Type.local).put("milkRunListUA", oRetnUA);
			var oIssueUA = this.getView().byId("tipPreloadTab").getModel("tipPreMod").getData().results;
			jQuery.sap.storage(jQuery.sap.storage.Type.local).put("tipReloadListUA", oIssueUA);
			jQuery.sap.storage(jQuery.sap.storage.Type.local).put("tUAbtnFlagtr", "");

			if (oTriploadUA === "X" && oUAbtnFlag === "X") {
				jQuery.sap.storage(jQuery.sap.storage.Type.local).put("DeliveryNumber", "UA");
				oDelUAissue = this.getView().byId("deliverynum").getValue().trim();
				jQuery.sap.storage(jQuery.sap.storage.Type.local).put("DeliveryNumberUA", oDelUAissue);
			} else if (oHeaderUAflag === "X" && oUAbtnFlag === "X") {
				jQuery.sap.storage(jQuery.sap.storage.Type.local).put("DeliveryNumber", "UA");
				oDelUAissue = sap.ui.getCore().byId("addDeliveryNo").getValue().trim();
				jQuery.sap.storage(jQuery.sap.storage.Type.local).put("DeliveryNumberUA", oDelUAissue);
			}
			if ((oTriploadUA === "X" || oHeaderUAflag === "X") && oUAbtnFlag === "X") {
				vDoc = vDoc + ",UA," + oDelUAissue;
			}

			if (!this.byId("deliverynum") === undefined) {
				this.byId("deliverynum").setValue("");
			}

			var oRouter = sap.ui.core.UIComponent.getRouterFor(this);

			oRouter.navTo("TrailerInformation", {
				objectId: vDoc
			});
		},

		onIssueEmptyTrailerPress: function() {
			jQuery.sap.storage(jQuery.sap.storage.Type.local).put("Lifnr", "");
			jQuery.sap.storage(jQuery.sap.storage.Type.local).put("Scac", "");
			jQuery.sap.storage(jQuery.sap.storage.Type.local).put("ShipCondition", "");
			jQuery.sap.storage(jQuery.sap.storage.Type.local).put("DeliveryNumber", "UA");
			jQuery.sap.storage(jQuery.sap.storage.Type.local).put("issueDrop", "");
			jQuery.sap.storage(jQuery.sap.storage.Type.local).put("OrderType", "");
			jQuery.sap.storage(jQuery.sap.storage.Type.local).put("returnDrop", "E");
			jQuery.sap.storage(jQuery.sap.storage.Type.local).put("trailerTypeFV", "");
			this._trailerfacilityDialog.close();

			if (!this.byId("deliverynum") === undefined) {
				this.byId("deliverynum").setValue("");
			}
			var oRouter = sap.ui.core.UIComponent.getRouterFor(this);
			var vDoc = "U";
			oRouter.navTo("TrailerInformation", {
				objectId: vDoc
			});
		},

		onIssueLoadedTrailerPress: function() {
			jQuery.sap.storage(jQuery.sap.storage.Type.local).put("Lifnr", "");
			jQuery.sap.storage(jQuery.sap.storage.Type.local).put("Scac", "");
			jQuery.sap.storage(jQuery.sap.storage.Type.local).put("ShipCondition", "");
			jQuery.sap.storage(jQuery.sap.storage.Type.local).put("DeliveryNumber", "UA");
			jQuery.sap.storage(jQuery.sap.storage.Type.local).put("issueDrop", "");
			jQuery.sap.storage(jQuery.sap.storage.Type.local).put("OrderType", "");
			jQuery.sap.storage(jQuery.sap.storage.Type.local).put("returnDrop", "L");
			jQuery.sap.storage(jQuery.sap.storage.Type.local).put("trailerTypeFV", "");
			this._trailerfacilityDialog.close();
			if (!this.byId("deliverynum") === undefined) {
				this.byId("deliverynum").setValue("");
			}
			var oRouter = sap.ui.core.UIComponent.getRouterFor(this);
			var vDoc = "U";
			oRouter.navTo("TrailerInformation", {
				objectId: vDoc
			});
		},

		onIssueBobtailPress: function() {
			jQuery.sap.storage(jQuery.sap.storage.Type.local).put("Lifnr", "");
			jQuery.sap.storage(jQuery.sap.storage.Type.local).put("Scac", "");
			jQuery.sap.storage(jQuery.sap.storage.Type.local).put("ShipCondition", "");
			jQuery.sap.storage(jQuery.sap.storage.Type.local).put("DeliveryNumber", "UA");
			jQuery.sap.storage(jQuery.sap.storage.Type.local).put("issueDrop", "");
			jQuery.sap.storage(jQuery.sap.storage.Type.local).put("OrderType", "");
			jQuery.sap.storage(jQuery.sap.storage.Type.local).put("returnDrop", "B");
			jQuery.sap.storage(jQuery.sap.storage.Type.local).put("trailerTypeFV", "");
			this._trailerfacilityDialog.close();
			if (!this.byId("deliverynum") === undefined) {
				this.byId("deliverynum").setValue("");
			}
			var oRouter = sap.ui.core.UIComponent.getRouterFor(this);
			var vDoc = "U";
			oRouter.navTo("TrailerInformation", {
				objectId: vDoc
			});
		},

		//Return Table upDateFinished
		onUpdateFinishForAdd: function(oEvent) {
			if (delNumFlag === "R") { //to Enable/Disble Remove Icon based on the DelNumber Type
				if (oEvent.getSource().getItems()[0] !== undefined) {
					if (this.getView().byId(oEvent.getSource().getItems()[0].getAggregation("cells")[1].getId()) !== undefined) {
						this.getView().byId(oEvent.getSource().getItems()[0].getAggregation("cells")[1].getId()).setVisible(false);
					}
				}
			} else {
				if (oEvent.getSource().getItems()[0] !== undefined) {
					if (this.getView().byId(oEvent.getSource().getItems()[0].getAggregation("cells")[1].getId()) !== undefined) {
						this.getView().byId(oEvent.getSource().getItems()[0].getAggregation("cells")[1].getId()).setVisible(true);
					}
				}
			}

		},
		//Issue Table upDateFinished
		onUpdateFinishForPre: function(oEvent) {
			if (delNumFlag === "I") { //to Enable/Disble Remove Icon based on the DelNumber Type
				if (oEvent.getSource().getItems()[0] !== undefined) {
					if (this.getView().byId(oEvent.getSource().getItems()[0].getAggregation("cells")[1].getId()) !== undefined) {
						this.getView().byId(oEvent.getSource().getItems()[0].getAggregation("cells")[1].getId()).setVisible(false);
					}
				}
			} else {
				if (oEvent.getSource().getItems()[0] !== undefined) {
					if (this.getView().byId(oEvent.getSource().getItems()[0].getAggregation("cells")[1].getId()) !== undefined) {
						this.getView().byId(oEvent.getSource().getItems()[0].getAggregation("cells")[1].getId()).setVisible(true);
					}
				}
			}

		},
		onUnknownUApress: function() {
			var that = this;
			var UAdelVries = [];
			if (that.getView().byId("DetailTable_ID").getModel("deliveryMod") === undefined) {
				var oModelUA = new sap.ui.model.json.JSONModel({
					"results": UAdelVries
				});

				that.getView().setModel(oModelUA, "deliveryMod");
				that.addDelvDialog.Close();
			}
			UAdelVries = that.getView().byId("DetailTable_ID").getModel("deliveryMod").getData().results;
			var oUaDelvry = "UA";
			var chepEntry = {};
			chepEntry.chepdeliverynumber = oUaDelvry;
			chepEntry.Plant = sParentPlant;
			var index = UAdelVries.findIndex(function(item) {
				return item.chepdeliverynumber === "UA";
			});
			if (index === -1) {
				UAdelVries.push(chepEntry);
			}
			that.getView().byId("DetailTable_ID").getModel("deliveryMod").setData({
				"results": UAdelVries
			});
			oUAbtnFlag = "X";
			jQuery.sap.storage(jQuery.sap.storage.Type.local).put("oUAbtn", oUAbtnFlag);
			that.getView().byId("DetailTable_ID").updateBindings(true);
			that.byId("DetailTable_ID").setVisible(true);
			that.onNoPress();
			that.onCancelDelv();
		},

		onUpdateFinishForAddDelivery: function(oEvent) {
			if (oEvent.getSource().getItems()[0] !== undefined) {
				if (sap.ui.getCore().byId(oEvent.getSource().getItems()[0].getAggregation("cells")[1].getId()) !== undefined) {
					sap.ui.getCore().byId(oEvent.getSource().getItems()[0].getAggregation("cells")[1].getId()).setVisible(false);
				}
			}
		},
		onUApress: function() {
			var that = this;
			jQuery.sap.storage(jQuery.sap.storage.Type.local).put("trailerLive", "");
			if (oHeaderUAflag === "X") {
				that.onCheckUaDialog();
			}
		},
		onCheckUaDialog: function() {
			var that = this;
			var UAdelVries = [];
			if (that.getView().byId("DetailTable_ID").getModel("deliveryMod") === undefined) {
				var oModelUA = new sap.ui.model.json.JSONModel({
					"results": UAdelVries
				});

				that.getView().setModel(oModelUA, "deliveryMod");
				that.addDelvDialog.Close();
			}
			UAdelVries = that.getView().byId("DetailTable_ID").getModel("deliveryMod").getData().results;
			var oUaDelvry = "UA";
			var chepEntry = {};
			chepEntry.chepdeliverynumber = oUaDelvry;
			chepEntry.Plant = sParentPlant;
			var oIndex = UAdelVries.findIndex(function(item) {
				return item.chepdeliverynumber === oUaDelvry;

			});
			if (oIndex === -1) {
				UAdelVries.push(chepEntry);
			}
			that.getView().byId("DetailTable_ID").getModel("deliveryMod").setData({
				"results": UAdelVries
			});
			oUAbtnFlag = "X";
			jQuery.sap.storage(jQuery.sap.storage.Type.local).put("oUAbtn", oUAbtnFlag);
			that.getView().byId("DetailTable_ID").updateBindings(true);
			that.byId("DetailTable_ID").setVisible(true);
			if (!that.addDelvDialog) {
				that.addDelvDialog = sap.ui.xmlfragment("chep.checkin.fragments.AddDelivery", that);
				that.getView().addDependent(that.addDelvDialog);
			}
			that._DropandPickDialog.close();
			that.addDelvDialog.open();
			sap.ui.getCore().byId("addDeliveryNo").setValue("");
			if (oHeaderUAflag === "X") {
				that.getView().getModel("UAunknwnModel").setProperty("/cntnueBtn", true);
				that.getView().getModel("UAunknwnModel").setProperty("/UnknownBtn", false);
			} else {
				that.getView().getModel("UAunknwnModel").setProperty("/UnknownBtn", false);
				that.getView().getModel("UAunknwnModel").setProperty("/cntnueBtn", false);
			}

		}
	});
});