var loggedUser;
var empNameID;
var vLoadPlant;
var sRegion;
var oInsCreateDailog;
var checkMilkDialog;
var storeMilkList;
var tipMilkList;
var sCheckDateFormat;
var sLiveCode;
var sDropCode;
var sPickCode;
var pgmodel;
var yardStop;
sap.ui.define([
	"sap/ui/core/mvc/Controller",
	"sap/m/MessageBox",
	"sap/ui/model/json/JSONModel",
	"chep/checkin/model/formatter"
], function(Controller, MessageBox, JSONModel, formatter) {
	"use strict";

	return Controller.extend("chep.checkin.controller.CheckinSuccessful", {

		formatter: formatter,

		onInit: function() {
			jQuery.sap.require("jquery.sap.storage");

			var that = this;
			this.setInitialFocus(this.byId("successOkBtn"));
			this.getView().byId("navBack").setVisible(false);
			var oRouter = sap.ui.core.UIComponent.getRouterFor(this);
			oRouter.getRoute("CheckinSuccessful").attachPatternMatched(this._onObjectMatched, this);
			pgmodel = new JSONModel({ // start - model used for displaying the page numbers
				"pgStart": "0",
				"pgEnd": "0"
			});
			that.getView().setModel(pgmodel, "pgmodel");
			that.fnCreateBusyDialog("pallet.svg");
			var y = "/sap/bc/ui2/start_up";
			var xmlHttp = null;
			xmlHttp = new XMLHttpRequest();
			xmlHttp.onreadystatechange = function() {
				if (xmlHttp.readyState === 4 && xmlHttp.status === 200) {
					var oUserData = JSON.parse(xmlHttp.responseText);
					loggedUser = oUserData.id;
					empNameID = oUserData.fullName;
					sCheckDateFormat = oUserData.dateFormat;
					var sLanguage = jQuery.sap.storage(jQuery.sap.storage.Type.local).get("sysLang");
					that.getView().byId("langId").setText(sLanguage);
					that.getView().byId("empNameID").setText(empNameID);
					that.byId("Header_Desktop_Bar_ID").setVisible(true);
				}
			};
			xmlHttp.open("GET", y, false);
			xmlHttp.send(null);

			//-----------------------------------------------------------------------------------------------------------------------------------------------	
			// Read the header data for bar
			//-----------------------------------------------------------------------------------------------------------------------------------------------
			var url = "/sap/opu/odata/sap/ZGW_DELIVERY_AP_SRV";
			var oModel = new sap.ui.model.odata.ODataModel(url);

			oModel.read("/HeaderDetailsSet('" + loggedUser + "')", null, null, true, function(oData) {
					var oODataJSONModel2 = new sap.ui.model.json.JSONModel();
					oODataJSONModel2.setData(oData);
					that.getView().setModel(oODataJSONModel2, "HeaderDetails");
					vLoadPlant = oData.Plant;
					sRegion = oData.Region;
					oInsCreateDailog.close();
				},
				function(error) {
					oInsCreateDailog.close();
					MessageBox.show("Error");
				});

			//-------------Setting the clock and date---------------//
			/*	setInterval(function() {
				var sCurrDate = new Date();
				var dd = sCurrDate.getDate();
				var mm = sCurrDate.getMonth() + 1; //January is 0!
				var yyyy = sCurrDate.getFullYear();
				if (dd < 10) {
					dd = '0' + dd;
				}
				if (mm < 10) {
					mm = '0' + mm;
				}
				var sDate = yyyy.toString() + mm.toString() + dd.toString();
				var dFormDate = that.fnSetUserDateFormat(sDate, sCheckDateFormat);
				//	var sDate = sCurrDate.toLocaleDateString();
				var sCurrTime = sCurrDate.toLocaleTimeString();
				var result = dFormDate + " " + sCurrTime;

				if (that.getView().byId("oDateID") !== undefined) {
					that.getView().byId("oDateID").setText(result);
				}
				if (that.getView().byId("oDateID1") !== undefined) {
					that.getView().byId("oDateID1").setText(result);
				}
			}, 1000);*/

			setInterval(function() {

				var oTimeZone = jQuery.sap.storage(jQuery.sap.storage.Type.local).get("sTimeZone");
				var oDayLightSaving = jQuery.sap.storage(jQuery.sap.storage.Type.local).get("sDayLightSaving");
				var oFlag = jQuery.sap.storage(jQuery.sap.storage.Type.local).get("sFlag");

				if (oFlag === false || oFlag === "false" || oFlag === null || oFlag === undefined) {
					var resultBrowser = that.realDateTimeClockBrowser();

					if (that.getView().byId("oDateID") !== undefined) {
						that.getView().byId("oDateID").setText(resultBrowser);
					}
					if (that.getView().byId("oDateID1") !== undefined) {
						that.getView().byId("oDateID1").setText(resultBrowser);
					}

				} else if (oFlag === true || oFlag === "true") {
					var result = that.realDateTimeClock(oTimeZone, oDayLightSaving);

					if (that.getView().byId("oDateID") !== undefined) {
						that.getView().byId("oDateID").setText(result);
					}
					if (that.getView().byId("oDateID1") !== undefined) {
						that.getView().byId("oDateID1").setText(result);
					}

				}

			}, 1000);

		},

		// Function to change the time based on timezone

		realDateTimeClockBrowser: function() {
			var that = this;
			var sCurrDate = new Date();
			var dd = sCurrDate.getDate();
			var mm = sCurrDate.getMonth() + 1; //January is 0!
			var yyyy = sCurrDate.getFullYear();
			if (dd < 10) {
				dd = '0' + dd;
			}
			if (mm < 10) {
				mm = '0' + mm;
			}
			var sDate = yyyy.toString() + mm.toString() + dd.toString();
			var dFormDate = that.fnSetUserDateFormat(sDate, sCheckDateFormat);
			//	var sDate = sCurrDate.toLocaleDateString();
			var sCurrTime = sCurrDate.toLocaleTimeString();
			var result = dFormDate + " " + sCurrTime;
			return result;
		},

		realDateTimeClock: function(TimeZone, DayLightSaving) {
			var that = this;

			/*	var sData = that.getView().getModel("HeaderDetailsPlant").getData();
			var TimeZone = sData.UTC_DIFF;
			var DayLightSaving = sData.DST_DIFF;*/

			var timeZoneOutput = [TimeZone.slice(0, 3), ":", TimeZone.slice(3, 5)].join('');

			if (DayLightSaving === "") {
				DayLightSaving = "0";
			}

			// var DayLightSavingOutput = [DayLightSaving.slice(0, 2), ":", DayLightSaving.slice(2, 4)].join('');

			if (timeZoneOutput.startsWith("-")) {
				var concatTimeZoneDayLight = parseInt(TimeZone.slice(1, 3)) - parseInt(DayLightSaving.slice(0, 2));
			} else if (timeZoneOutput.startsWith("+")) {
				var concatTimeZoneDayLight = parseInt(TimeZone.slice(1, 3)) + parseInt(DayLightSaving.slice(0, 2));
			}

			var finalOffset = [TimeZone.slice(0, 1), concatTimeZoneDayLight, ":", TimeZone.slice(3, 5)].join('');

			var _now = new Date();

			//var timeZoneOutput = "+11:00";
			var date = that.timezoneShifter(_now, finalOffset);

			var resultDate = that.formatTimeClock(date);
			return resultDate;
		},

		timezoneShifter: function(date, timezone) {

			var isBehindGTM = false;
			if (timezone.startsWith("-")) {
				timezone = timezone.substr(1);
				isBehindGTM = true;
			}

			var hDiff = timezone.split(":").map(myFunction);

			function myFunction(t) {
				return parseInt(t);
			}

			var value = isBehindGTM ? 1 : -1;
			var diff = (hDiff[0] * 60 + hDiff[1]) * value;
			var currentDiff = new Date().getTimezoneOffset();

			return new Date(date.valueOf() + (currentDiff - diff) * 60 * 1000);
		},

		formatTimeClock: function(_now) {
			var that = this;
			var sCurrDate = _now;
			var dd = sCurrDate.getDate();
			var mm = sCurrDate.getMonth() + 1; //January is 0!
			var yyyy = sCurrDate.getFullYear();
			if (dd < 10) {
				dd = '0' + dd;
			}
			if (mm < 10) {
				mm = '0' + mm;
			}
			var sDate = yyyy.toString() + mm.toString() + dd.toString();
			var dFormDate = that.fnSetUserDateFormat(sDate, sCheckDateFormat);
			//	var sDate = sCurrDate.toLocaleDateString();
			var sCurrTime = sCurrDate.toLocaleTimeString();
			var result = dFormDate + " " + sCurrTime;
			return result;
		},

		//-----------------To Set Auto Focus on OK Button-------------------//	
		setInitialFocus: function(control) {
			this.getView().addEventDelegate({
				onAfterShow: function() {
					setTimeout(function() {
						control.focus();
					}.bind(this), 0);
				}
			}, this);
		},

		_onObjectMatched: function(oEvent) {
			var that = this;
			storeMilkList = jQuery.sap.storage(jQuery.sap.storage.Type.local).get("milkRunList");
			tipMilkList = jQuery.sap.storage(jQuery.sap.storage.Type.local).get("tipReloadList");
			if ((storeMilkList !== undefined) || (tipMilkList !== undefined)) {
				if (((storeMilkList.length > 1) || (storeMilkList.length > 0 && tipMilkList.length > 0)) || ((tipMilkList.length > 1) || (
					tipMilkList.length > 0 && storeMilkList.length > 0))) {
					that.byId("milkRunSuccessBtId").setVisible(true);
				} else {
					that.byId("milkRunSuccessBtId").setVisible(false);
				}
			}
			var sPageType = jQuery.sap.storage(jQuery.sap.storage.Type.local).get("PageType");
			if (sPageType === "DD") {
				//that.getView().byId("pageNo").setText("5 of 5");
				that.getView().getModel("pgmodel").setProperty("/pgStart", "5");
				that.getView().getModel("pgmodel").setProperty("/pgEnd", "5");

			} else {
				//that.getView().byId("pageNo").setText("4 of 4");
				that.getView().getModel("pgmodel").setProperty("/pgStart", "4");
				that.getView().getModel("pgmodel").setProperty("/pgEnd", "4");
			}
			var DeliveryNumber = jQuery.sap.storage(jQuery.sap.storage.Type.local).get("DeliveryNumber");
			that.getView().byId("orderNum").setText(DeliveryNumber);
			var TrailerId = jQuery.sap.storage(jQuery.sap.storage.Type.local).get("TrailerId");
			that.getView().byId("trailerid").setText(TrailerId);

			/*TrailerID dispaly ifor EU region*/
			var VehicleregionID = jQuery.sap.storage(jQuery.sap.storage.Type.local).get("vCHtrilerid");
			var VehiclReg = jQuery.sap.storage(jQuery.sap.storage.Type.local).get("trailerIdVehicleReg");
			//var trailerIdVehicleReg = this.byId("Trailer_Id").getValue();
			var TrailerId = jQuery.sap.storage(jQuery.sap.storage.Type.local).get("TrailerId");
			if (sRegion === "EU") {
				if (VehicleregionID !== true) {
					var trailerIdVehicleReg = VehiclReg;
					that.getView().byId("trailerid").setText(trailerIdVehicleReg);
				} else {
					that.getView().byId("trailerid").setText(TrailerId);
				}
			} else {
				that.getView().byId("trailerid").setText(TrailerId);
			}

			var backMessId = jQuery.sap.storage(jQuery.sap.storage.Type.local).get("backEndMessage");
			var dropInstructions = jQuery.sap.storage(jQuery.sap.storage.Type.local).get("dropInst");
			var pickInstructions = jQuery.sap.storage(jQuery.sap.storage.Type.local).get("pickInst");
			var issueDrop = jQuery.sap.storage(jQuery.sap.storage.Type.local).get("issueDrop");
			var retDrop = jQuery.sap.storage(jQuery.sap.storage.Type.local).get("returnDrop");
			var objectId = jQuery.sap.storage(jQuery.sap.storage.Type.local).get("objectID");
			var vDropservice = jQuery.sap.storage(jQuery.sap.storage.Type.local).get("vDropservice");
			var vDandHservice = jQuery.sap.storage(jQuery.sap.storage.Type.local).get("vDhservice");
			var dropNpickFlag = jQuery.sap.storage(jQuery.sap.storage.Type.local).get("dropNpickup");
			//ctrm-1329
			var yardStopFlag = jQuery.sap.storage(jQuery.sap.storage.Type.local).get("yardStopFlag");
			yardStop = jQuery.sap.storage(jQuery.sap.storage.Type.local).get("yardStop");
			var i18nModel = that.getOwnerComponent();

			// 	var dropmsgtrue = i18nModel.getModel("i18n").getProperty('DropserviceDandH');
			// 	that.getView().byId("dropserveidtrue").setText(dropmsgtrue);
			// } else {
			// 	var dropmsgFalse = i18nModel.getModel("i18n").getProperty('DropserviceDandHfalse');
			// 	that.getView().byId("dropserveidtrue").setText(dropmsgFalse);
			// }

			if (vDropservice === "true") {
				if (dropInstructions !== "") {
					var sDropMsg = dropInstructions.split(":");
					if (sDropMsg !== undefined) {
						sDropCode = sDropMsg[0];
						//	var sBuilding = sDropMsg[3];
						var sLocation = sDropMsg[4];
						var sDropCheckTime = sDropMsg[5];
					}
					var sDropIns;
					switch (sDropCode) {
						case "R1":
							sDropIns = i18nModel.getModel("i18n").getProperty('R1');
							break;
						case "R10":
							sDropIns = i18nModel.getModel("i18n").getProperty('R10');
							sDropIns = sDropIns.replace("{YLOCT}", sLocation);
							break;
						case "R5":
							sDropIns = i18nModel.getModel("i18n").getProperty('R5');
							break;
						case "R6":
							sDropIns = i18nModel.getModel("i18n").getProperty('R6');
							sDropIns = sDropIns.replace("{location}", sLocation);
							break;
						case "R7":
							sDropIns = i18nModel.getModel("i18n").getProperty('R7');
							break;
						case "R8":
							sDropIns = i18nModel.getModel("i18n").getProperty('R8');
							break;
						case "R9":
							sDropIns = i18nModel.getModel("i18n").getProperty('R9');
							sDropIns = sDropIns.replace("{building}", sLocation);
							break;
						case "R20":
							sDropIns = i18nModel.getModel("i18n").getProperty('R20');
							sDropCode = "R8";
							break;
						case "O1":
							sDropIns = i18nModel.getModel("i18n").getProperty('O1');
							break;
					}

					if (sDropCheckTime !== undefined) {
						var dLocDate = sDropCheckTime.trim();
					}
					// dLocDate: 20180511072938
					if (dLocDate !== undefined) {
						var sDate = dLocDate.slice(0, 8);
						var dCheckDate = that.fnSetUserDateFormat(sDate, sCheckDateFormat);
						var dLocTime = dLocDate.slice(8, 10) + ":" + dLocDate.slice(10, 12) + ":" + dLocDate.slice(12, 14);
						var dLocDateTime = dCheckDate + " " + dLocTime;
						that.getView().byId("locDatTim").setText(dLocDateTime);
					}
				}

				if (pickInstructions !== "") {
					var sPickMsg = pickInstructions.split(":");
					if (sPickMsg !== undefined) {
						sPickCode = sPickMsg[0];
						var sDelNumber = sPickMsg[1];
						var sYard = sPickMsg[2];
						var sDoor = sPickMsg[3];
						var sLocation = sPickMsg[4];
						var sTrailerNumber = sPickMsg[5];
						// var sSmsCode = sPickMsg[6];
						var sPickCheckTime = sPickMsg[7];
					}
					var sPickIns;
					switch (sPickCode) {
						case "O1":
							sPickIns = i18nModel.getModel("i18n").getProperty('O1');
							break;
						case "O6":
							sPickIns = i18nModel.getModel("i18n").getProperty('O6');
							sPickIns = sPickIns.replace("{trailerloc}", sLocation);
							sPickIns = sPickIns.replace("{trailernum}", sTrailerNumber);
							// sPickIns = sPickIns.replace("{code}", sSmsCode);
							break;
						case "O7":
							sPickIns = i18nModel.getModel("i18n").getProperty('O7');
							// sPickIns = sPickIns.replace("{code}", sSmsCode);
							break;
						case "O8":
							sPickIns = i18nModel.getModel("i18n").getProperty('O8');
							sPickIns = sPickIns.replace("{delnum}", sDelNumber);
							sPickIns = sPickIns.replace("{trailerloc}", sLocation);
							sPickIns = sPickIns.replace("{trailernum}", sTrailerNumber);
							that.getView().byId("locationBack").setText(sProceedMsg);
							that.getView().byId("locationBackValue").setText(sLiveInst);
							break;
						case "O9":
							sPickIns = i18nModel.getModel("i18n").getProperty('O9');
							sPickIns = sPickIns.replace("{delnum}", sDelNumber);
							break;
						case "O10":
							sPickIns = i18nModel.getModel("i18n").getProperty('O10');
							sPickIns = sPickIns.replace("{delnum}", sDelNumber);
							break;
						case "O12":
							sPickIns = i18nModel.getModel("i18n").getProperty('O12');
							break;
						case "O13":
							sPickIns = i18nModel.getModel("i18n").getProperty('O13');
							break;
						case "O14":
							sPickIns = i18nModel.getModel("i18n").getProperty('O14');
							break;
						case "O15":
							sPickIns = i18nModel.getModel("i18n").getProperty('O15');
							break;
						case "R9":
							sPickIns = i18nModel.getModel("i18n").getProperty('R9');
							sPickIns = sPickIns.replace("{building}", sLocation);
							break;
						case "R10":
							sPickIns = i18nModel.getModel("i18n").getProperty('R10');
							sPickIns = sPickIns.replace("{YLOCT}", sLocation);
							break;
					}
					if (sDropCheckTime === undefined) {
						if (sPickCheckTime !== undefined) {
							var sLocDate = sPickCheckTime.trim();
						}
						if (sLocDate !== undefined) {
							var sPickDate = sLocDate.slice(0, 8);
							var dPickDate = that.fnSetUserDateFormat(sPickDate, sCheckDateFormat);
							var dPickTime = sLocDate.slice(8, 10) + ":" + sLocDate.slice(10, 12) + ":" + sLocDate.slice(12, 14);
							var sPickDateTime = dPickDate + " " + dPickTime;
							that.getView().byId("locDatTim").setText(sPickDateTime);
						}
					}
				}

				//	backMessId = "PROCEED:P99: |25 Mins| 20180410151355 ";
				//	backMessId = "R1:::::25 Mins:20180410151355";
				if (backMessId !== "") {
					var sLiveMsg = backMessId.split(":");
					if (sLiveMsg !== undefined) {
						sLiveCode = sLiveMsg[0];
						var sDelNumber = sLiveMsg[1];
						var sLocation = sLiveMsg[3];
						var sTrailerNumber = sLiveMsg[2];
						var sETA = sLiveMsg[5];
						var sCheckinDate = sLiveMsg[6];
					}
					var sLiveInst;
					var sProceedMsg = i18nModel.getModel("i18n").getProperty('proceedTo');
					switch (sLiveCode) {
						case "L1":
							sLiveInst = i18nModel.getModel("i18n").getProperty('L1');
							that.getView().byId("locationBack").setText(sProceedMsg);
							that.getView().byId("locationBackValue").setText(sLiveInst);
							break;
						case "R1":
							sLiveInst = i18nModel.getModel("i18n").getProperty('R1');
							that.getView().byId("locationBack").setText(sProceedMsg);
							that.getView().byId("locationBackValue").setText(sLiveInst);
							break;

						case "R10":
							sPickIns = i18nModel.getModel("i18n").getProperty('R10');
							sPickIns = sPickIns.replace("{YLOCT}", sLocation);
							break;
						case "O1":
							sLiveInst = i18nModel.getModel("i18n").getProperty('O1');
							that.getView().byId("locationBack").setText(sProceedMsg);
							that.getView().byId("locationBackValue").setText(sLiveInst);
							break;
						case "O8":
							sLiveInst = i18nModel.getModel("i18n").getProperty('O8');
							sLiveInst = sLiveInst.replace("{delnum}", sDelNumber);
							sLiveInst = sLiveInst.replace("{trailerloc}", sLocation);
							sLiveInst = sLiveInst.replace("{trailernum}", sTrailerNumber);
							break;
						case "O13":
							sLiveInst = i18nModel.getModel("i18n").getProperty('O13');
							that.getView().byId("locationBack").setText(sProceedMsg);
							that.getView().byId("locationBackValue").setText(sLiveInst);
							break;
						case "O20":
							sLiveInst = i18nModel.getModel("i18n").getProperty('O20');
							that.getView().byId("locationBack").setText(sProceedMsg);
							that.getView().byId("locationBackValue").setText(sLiveInst);
							sLiveCode = "O13";
							break;
					}

					if ((sLiveCode === "L1") && (vDandHservice === "false")) {
						sLiveInst = i18nModel.getModel("i18n").getProperty('L2');
						that.getView().byId("locationBack").setText(sProceedMsg);
						that.getView().byId("locationBackValue").setText(sLiveInst);
					} else if ((sLiveCode === "L1") && (dropNpickFlag === "")) {
						sLiveInst = i18nModel.getModel("i18n").getProperty('L2');
						that.getView().byId("locationBack").setText(sProceedMsg);
						that.getView().byId("locationBackValue").setText(sLiveInst);
					}
					// if((sRegion === "US") && (vDandHservice === "false" || vDandHservice === false)){
					// if(((sRegion === "US") && (vDandHservice === "false" || vDandHservice === false))|| (sRegion === "US")){
					// 		sLiveInst = i18nModel.getModel("i18n").getProperty('L2');
					// 		that.getView().byId("locationBack").setText(sProceedMsg);
					// 		that.getView().byId("locationBackValue").setText(sLiveInst);
					// }
					/*	if ((sLiveCode === "R1") || (sLiveCode === "O1")) {
						var sLiveInst;
						sLiveInst = i18nModel.getModel("i18n").getProperty('R1');
						that.getView().byId("locationBack").setText("PROCEED");
						that.getView().byId("locationBackValue").setText(sLiveInst);
					}*/

					if (sCheckinDate !== undefined) {
						var sLocDate = sCheckinDate.trim();
					}

					if (sLocDate !== undefined) {
						var sPickDate = sLocDate.slice(0, 8);
						var dPickDate = that.fnSetUserDateFormat(sPickDate, sCheckDateFormat);
						var dPickTime = sLocDate.slice(8, 10) + ":" + sLocDate.slice(10, 12) + ":" + sLocDate.slice(12, 14);
						var sPickDateTime = dPickDate + " " + dPickTime;
						that.getView().byId("locDatTim").setText(sPickDateTime);
					}

					if (sETA !== undefined) {
						var sLocEst = sETA;
					}
					// if (sLocEst !== undefined) {
					// 	that.getView().byId("estimatedTime").setText(sLocEst);
					// }
				}

				if (((issueDrop === "X") || (retDrop === "X")) || (objectId === "P")) {
					if (sLiveCode !== "O13") {
						var successTitle = i18nModel.getModel("i18n").getProperty('checkinsuccess');
						that.getView().byId("successTitle").setText(successTitle);
						that.getView().byId("lblOrderNumber").setVisible(true);
						that.getView().byId("orderNum").setVisible(true);
						that.getView().byId("lblTrailerId").setVisible(true);
						that.getView().byId("trailerid").setVisible(true);
						that.getView().byId("checkinDate").setVisible(true);
						// that.getView().byId("eta").setVisible(true);
						// that.getView().byId("estimatedTime").setVisible(true);
						that.getView().byId("locationBack").setVisible(true);
						that.getView().byId("locationBackValue").setVisible(true);
						that.getView().byId("dropInstructions").setVisible(false);
						that.getView().byId("pickupInstructions").setVisible(false);
						that.getView().byId("dropIns").setVisible(false);
						that.getView().byId("pickIns").setVisible(false);
						that.getView().byId("emergencyIns").setVisible(false);
				that.getView().byId("emergencyInstructions").setVisible(false);	
					} else {
						var rejectTitle = i18nModel.getModel("i18n").getProperty('checkinReject');
						that.getView().byId("successTitle").setText(rejectTitle);
						that.getView().byId("lblOrderNumber").setVisible(true);
						that.getView().byId("orderNum").setVisible(true);
						that.getView().byId("lblTrailerId").setVisible(false);
						that.getView().byId("trailerid").setVisible(false);
						that.getView().byId("checkinDate").setVisible(true);
						// that.getView().byId("eta").setVisible(false);
						// that.getView().byId("estimatedTime").setVisible(false);
						that.getView().byId("locationBack").setVisible(true);
						that.getView().byId("locationBackValue").setVisible(true);
						that.getView().byId("dropInstructions").setVisible(false);
						that.getView().byId("pickupInstructions").setVisible(false);
						that.getView().byId("dropIns").setVisible(false);
						that.getView().byId("pickIns").setVisible(false);
						that.getView().byId("emergencyIns").setVisible(false);
				that.getView().byId("emergencyInstructions").setVisible(false);	
					}
				} else {
					if (((sDropCode !== undefined) && (sDropCode !== "R8")) || ((sPickCode !== undefined) && (sPickCode !== "O13"))) {
						var successMsg = i18nModel.getModel("i18n").getProperty('checkinsuccess');
						that.getView().byId("successTitle").setText(successMsg);
					} else {
						var rejectMsg = i18nModel.getModel("i18n").getProperty('checkinReject');
						that.getView().byId("successTitle").setText(rejectMsg);
					}
					that.getView().byId("locationBack").setVisible(false);
					that.getView().byId("locationBackValue").setVisible(false);
					if ((dropInstructions !== "") && (pickInstructions === "")) {
						that.getView().byId("lblOrderNumber").setVisible(false);
						that.getView().byId("orderNum").setVisible(false);
						that.getView().byId("lblTrailerId").setVisible(false);
						that.getView().byId("trailerid").setVisible(false);
						that.getView().byId("checkinDate").setVisible(true);
						that.getView().byId("locDatTim").setVisible(true);
						// that.getView().byId("eta").setVisible(false);
						// that.getView().byId("estimatedTime").setVisible(false);
						that.getView().byId("dropInstructions").setVisible(true);
						that.getView().byId("dropIns").setVisible(true);
						that.getView().byId("pickupInstructions").setVisible(false);
						that.getView().byId("pickIns").setVisible(false);
						that.getView().byId("dropInstructions").setText(sDropIns);
						that.getView().byId("emergencyIns").setVisible(false);
				that.getView().byId("emergencyInstructions").setVisible(false);	
					} else if ((pickInstructions !== "") && (dropInstructions === "")) {
						that.getView().byId("lblOrderNumber").setVisible(false);
						that.getView().byId("orderNum").setVisible(false);
						that.getView().byId("lblTrailerId").setVisible(false);
						that.getView().byId("trailerid").setVisible(false);
						that.getView().byId("checkinDate").setVisible(true);
						that.getView().byId("locDatTim").setVisible(true);
						// that.getView().byId("eta").setVisible(false);
						// that.getView().byId("estimatedTime").setVisible(false);
						that.getView().byId("dropInstructions").setVisible(false);
						that.getView().byId("dropIns").setVisible(false);
						that.getView().byId("pickupInstructions").setVisible(true);
						that.getView().byId("pickIns").setVisible(true);
						that.getView().byId("pickupInstructions").setText(sPickIns);
						that.getView().byId("emergencyIns").setVisible(false);
				that.getView().byId("emergencyInstructions").setVisible(false);	
					} else if ((pickInstructions !== "") && (dropInstructions !== "")) {
						that.getView().byId("lblOrderNumber").setVisible(false);
						that.getView().byId("orderNum").setVisible(false);
						that.getView().byId("lblTrailerId").setVisible(false);
						that.getView().byId("trailerid").setVisible(false);
						that.getView().byId("checkinDate").setVisible(true);
						that.getView().byId("locDatTim").setVisible(true);
						// that.getView().byId("eta").setVisible(false);
						// that.getView().byId("estimatedTime").setVisible(false);
						that.getView().byId("dropInstructions").setVisible(true);
						that.getView().byId("dropIns").setVisible(true);
						that.getView().byId("pickupInstructions").setVisible(true);
						that.getView().byId("pickIns").setVisible(true);
						that.getView().byId("dropInstructions").setText(sDropIns);
						that.getView().byId("pickupInstructions").setText(sPickIns);
						that.getView().byId("emergencyIns").setVisible(false);
				that.getView().byId("emergencyInstructions").setVisible(false);	
					} else {
						that.getView().byId("lblOrderNumber").setVisible(false);
						that.getView().byId("orderNum").setVisible(false);
						that.getView().byId("lblTrailerId").setVisible(false);
						that.getView().byId("trailerid").setVisible(false);
						that.getView().byId("checkinDate").setVisible(true);
						that.getView().byId("locDatTim").setVisible(true);
						// that.getView().byId("eta").setVisible(false);
						// that.getView().byId("estimatedTime").setVisible(false);
						that.getView().byId("locationBack").setVisible(false);
						that.getView().byId("locationBackValue").setVisible(false);
						that.getView().byId("dropInstructions").setVisible(false);
						that.getView().byId("pickupInstructions").setVisible(false);
						that.getView().byId("dropIns").setVisible(false);
						that.getView().byId("pickIns").setVisible(false);
						that.getView().byId("emergencyIns").setVisible(false);
						that.getView().byId("emergencyInstructions").setVisible(false);
					}
				}
			} else {
				var successTitle = i18nModel.getModel("i18n").getProperty('checkinsuccess');
				that.getView().byId("successTitle").setText(successTitle);
				that.getView().byId("lblOrderNumber").setVisible(true);
				that.getView().byId("orderNum").setVisible(true);
				that.getView().byId("lblTrailerId").setVisible(true);
				that.getView().byId("trailerid").setVisible(true);
				that.getView().byId("checkinDate").setVisible(true);
				// that.getView().byId("eta").setVisible(true);
				that.getView().byId("locationBack").setVisible(true);
				that.getView().byId("locationBackValue").setVisible(true);
				that.getView().byId("dropInstructions").setVisible(false);
				that.getView().byId("pickupInstructions").setVisible(false);
				that.getView().byId("dropIns").setVisible(false);
				that.getView().byId("pickIns").setVisible(false);
				//ctrm-1329
				if (yardStopFlag === true || yardStopFlag === "true") {
					that.getView().byId("emergencyIns").setVisible(true);
					that.getView().byId("emergencyInstructions").setVisible(true);
					that.getView().byId("emergencyInstructions").setText(yardStop);
				} else {
					that.getView().byId("emergencyIns").setVisible(false);
					that.getView().byId("emergencyInstructions").setVisible(false);
				}

				//PROCEED:SERVICE BAY 01: |25 Mins| 20180516124633
				if (backMessId !== "") {
					var msgList = backMessId.split("|");
					if (msgList !== undefined) {
						var msgLoc = msgList[0].split(":");
					}
					if (msgLoc[0] !== undefined) {
						var sProceed = msgLoc[0].trim();
					}

					var sProceedMsg;
					var oBhhrs = jQuery.sap.storage(jQuery.sap.storage.Type.local).get("backEndMessage").slice(9, 26);
					if (sProceed === "PROCEED") {
						sProceedMsg = i18nModel.getModel("i18n").getProperty('proceedTo');
					}
					that.getView().byId("locationBack").setText(sProceedMsg);
					//		that.getView().byId("locationBack").setText(msgLoc[0]);

					if (msgLoc[1] !== undefined) {
						var sLocation = msgLoc[1].trim();
					}

					/* Check In successfull message for EU CA and US Regions */
					if ((sRegion === "EU" || (sRegion === undefined)) || (sRegion === "CA" || (sRegion === undefined)) || ((sRegion === "US" || (
						sRegion === undefined)) && (vDandHservice !== true))) {
						var psLocation = i18nModel.getModel("i18n").getProperty('L2');
						that.getView().byId("locationBackValue").setText(psLocation);
					}

					if ((oBhhrs === "Check in rejected") && (sRegion === "EU" || (sRegion === undefined)) || (sRegion === "CA" || (sRegion ===
						undefined))) {
						that.getView().byId("locationBackValue").setText(sLocation);
					} else {
						that.getView().byId("locationBackValue").setText(sLocation);
					}

					if (msgList[1] !== undefined) {
						var sLocEst = msgList[1];
						// if (sLocEst !== undefined) {
						// 	that.getView().byId("estimatedTime").setText(sLocEst);
						// }
					}
					if (msgList[2] !== undefined) {
						var sLocDate = msgList[2].trim();
						if (sLocDate !== undefined) {
							var sLocDateTime = sLocDate.slice(6, 8) + "." + sLocDate.slice(4, 6) + "." + sLocDate.slice(0, 4) + " " + sLocDate.slice(8, 10) +
								":" + sLocDate.slice(10, 12) + ":" + sLocDate.slice(12, 14);
						}
						if (sLocDateTime !== undefined) {
							that.getView().byId("locDatTim").setText(sLocDateTime);
						}
					}
					if (msgList[3] !== undefined) {
						var resultTitleCode = msgList[3];
						if (resultTitleCode !== undefined) {
							if (resultTitleCode === "R") {
								var rejTitle = i18nModel.getModel("i18n").getProperty('checkinReject');
								that.getView().byId("successTitle").setText(rejTitle);
							}
						}
					}
				}
			}
			// var successText = i18nModel.getModel("i18n").getProperty('checkinsuccess');
			// var CheckInSuccess = that.getView().byId("successTitle").getText();
			// var oDropDHtrailer = jQuery.sap.storage(jQuery.sap.storage.Type.local).get("sDandHBtnPress");
			// if (CheckInSuccess === successText) {
			// 	if ((vDropservice === "true" && sRegion !== "US")) {
			// 		if (vDandHservice === "true") { // D&H exception turned On
			// 			/* 0 or " "  Live*/
			// 			if (dropNpickFlag === "X") { // checks SCACS & GLIDS in yard settings App
			// 				var dropmsgFalse = i18nModel.getModel("i18n").getProperty('DropserviceDandHfalse'); /*D&H*/
			// 				that.getView().byId("dropserveidtrue").setText(dropmsgFalse);
			// 			} else {
			// 				var dropmsgtrue = i18nModel.getModel("i18n").getProperty('DropserviceDandH'); /* LIVE*/
			// 				that.getView().byId("dropserveidtrue").setText(dropmsgtrue);
			// 			}
			// 		} else { // D&H exception is Turned off
			// 			if (oDropDHtrailer === "X") { // checks flag from checkin controller
			// 				var dropmsgFalse1 = i18nModel.getModel("i18n").getProperty('DropserviceDandHfalse'); /*D&H*/
			// 				that.getView().byId("dropserveidtrue").setText(dropmsgFalse1);
			// 			} else { // checks flag from checkin controller for Live  
			// 				var dropmsgtrueLive = i18nModel.getModel("i18n").getProperty('DropserviceDandH'); /* LIVE*/
			// 				that.getView().byId("dropserveidtrue").setText(dropmsgtrueLive);
			// 			}
			// 		}
			// 	}
			// }
		},
		addMinutes: function(time, minsToAdd) {
			function D(J) {
				return (J < 10 ? '0' : '') + J;
			}

			var piece = time.split(':');

			var mins = piece[0] * 60 + +piece[1] + +minsToAdd;

			return D(mins % (24 * 60) / 60 | 0) + ':' + D(mins % 60);
		},

		//----------------------------------------------------------------------------------
		//Function to create Busy Dialog
		//----------------------------------------------------------------------------------

		fnCreateBusyDialog: function(sImage) {
			var that = this;
			oInsCreateDailog = new sap.m.Dialog({
				showHeader: false
			}).addStyleClass("busyDialog sapUiTinyMargin");
			var sComponentName = that.getOwnerComponent().getMetadata().getComponentName();
			var imgUrl = $.sap.getModulePath(sComponentName, "/images/");
			var oImage = new sap.m.Image().addStyleClass("sapUiMediumMargin");
			oImage.setSrc(imgUrl + sImage);
			oInsCreateDailog.addContent(oImage);
			oInsCreateDailog.open();
		},

		//----------------------------------------------------------------------------------
		//Function to set logged in User Date pattern
		//----------------------------------------------------------------------------------
		fnSetUserDateFormat: function(rDate, sInsDateFormat) {
			if (rDate !== "") {
				var dFormDate;
				switch (sInsDateFormat) {
					case "1":
						dFormDate = rDate.slice(6, 8) + "." + rDate.slice(4, 6) + "." + rDate.slice(0, 4);
						break;
					case "2":
						dFormDate = rDate.slice(4, 6) + "/" + rDate.slice(6, 8) + "/" + rDate.slice(0, 4);
						break;
					case "3":
						dFormDate = rDate.slice(4, 6) + "-" + rDate.slice(6, 8) + "-" + rDate.slice(0, 4);
						break;
					case "4":
						dFormDate = rDate.slice(0, 4) + "." + rDate.slice(4, 6) + "." + rDate.slice(6, 8);
						break;
					case "5":
						dFormDate = rDate.slice(0, 4) + "/" + rDate.slice(4, 6) + "/" + rDate.slice(6, 8);
						break;
					case "6":
						dFormDate = rDate.slice(0, 4) + "-" + rDate.slice(4, 6) + "-" + rDate.slice(6, 8);
						break;
					case "A":
						dFormDate = rDate.slice(0, 4) + "/" + rDate.slice(4, 6) + "/" + rDate.slice(6, 8);
						break;
					case "B":
						dFormDate = rDate.slice(0, 4) + "/" + rDate.slice(4, 6) + "/" + rDate.slice(6, 8);
						break;
					case "C":
						dFormDate = rDate.slice(0, 4) + "/" + rDate.slice(4, 6) + "/" + rDate.slice(6, 8);
						break;
				}
			} else {
				var dFormDate = "";
			}
			return dFormDate;
		},

		onNavBack: function() {
			oInsCreateDailog.open();
			var oRouter = sap.ui.core.UIComponent.getRouterFor(this);
			oRouter.navTo("CheckIn");
			oInsCreateDailog.close();
		},

		onOk: function() {
			if (sap.ui.Device.system.tablet && !sap.ui.Device.system.desktop) {
				var oCrossAppNavigatorTab = sap.ushell.Container.getService("CrossApplicationNavigation");
				oCrossAppNavigatorTab.toExternal({
					target: {
						semanticObject: "#Shell-home"
					}
				});
			} else {
				var sysLang = jQuery.sap.storage(jQuery.sap.storage.Type.local).get("sysLang");
				var kioskId = jQuery.sap.storage(jQuery.sap.storage.Type.local).get("KioskId");
				if (kioskId !== "XXXXXXXXXX") {
					var oCrossAppNavigator = sap.ushell.Container.getService("CrossApplicationNavigation");
					var hash = "ZESP_CHECKIN-display?sap-language=" + sysLang + "&KIOSK_ID=" + kioskId + "&/EULADeclined";
					oCrossAppNavigator.toExternal({
						target: {
							shellHash: hash
						}
					});
				} else {
					var oCrossAppNavigatorTab2 = sap.ushell.Container.getService("CrossApplicationNavigation");
					oCrossAppNavigatorTab2.toExternal({
						target: {
							semanticObject: "#Shell-home"
						}
					});
				}
			}
		},
		onListOfDel: function() {
			oInsCreateDailog.open();
			if (!checkMilkDialog) {
				checkMilkDialog = sap.ui.xmlfragment("fragSucess", "chep.checkin.fragments.ListOfDeliveries", this);
				this.getView().addDependent(checkMilkDialog);
			}
			jQuery.sap.syncStyleClass("sapUiSizeCompact", this.getView(), this.listDelvDialog);

			if (storeMilkList !== undefined) {
				if (storeMilkList.length > 0) {
					sap.ui.getCore().byId("fragSucess--DetailTable_ID").setVisible(true);
					var milkoModel = new sap.ui.model.json.JSONModel({
						"results": storeMilkList
					});
					sap.ui.getCore().byId("fragSucess--DetailTable_ID").setModel(milkoModel, "deliveryMod");
				} else {
					sap.ui.getCore().byId("fragSucess--DetailTable_ID").setVisible(false);
					sap.ui.getCore().byId("fragSucess--tipTableId").setVisible(true);
				}

			}
			if (tipMilkList !== undefined) {
				if (tipMilkList.length > 0) {
					sap.ui.getCore().byId("fragSucess--tipTableId").setVisible(true);
					var tipoModel = new sap.ui.model.json.JSONModel({
						"results": tipMilkList
					});
					sap.ui.getCore().byId("fragSucess--tipTableId").setModel(tipoModel, "tipListMod");
				} else {
					sap.ui.getCore().byId("fragSucess--tipTableId").setVisible(false);
					sap.ui.getCore().byId("fragSucess--DetailTable_ID").setVisible(true);
				}

			}

			/*if (storeMilkList !== undefined) {
				var milkoModel = new sap.ui.model.json.JSONModel({
					"results": storeMilkList
				});
				sap.ui.getCore().byId("fragSucess--DetailTable_ID").setModel(milkoModel, "deliveryMod");
			}
			if (tipMilkList !== undefined) {
				var tipoModel = new sap.ui.model.json.JSONModel({
					"results": tipMilkList
				});
				sap.ui.getCore().byId("fragSucess--tipTableId").setModel(tipoModel, "tipListMod");
			}*/
			oInsCreateDailog.close();
			checkMilkDialog.open();
		},

		onItemDelete: function(e) {
			oInsCreateDailog.open();
			if (e.getSource().getParent().getParent().getItems().length > 0) {
				var path1 = e.getSource().oPropagatedProperties.oBindingContexts.deliveryMod.sPath;
				var index = parseInt(path1.substring(path1.lastIndexOf('/') + 1));
				var m = e.getSource().getModel("deliveryMod");
				var d = m.getData().results;
				d.splice(index, 1);
				m.setProperty("/results", d);
				oInsCreateDailog.close();
			}

		},

		onListDeliveriesOK: function() {
			checkMilkDialog.close();
		},

		onUpdateFinishForAddDelivery: function(oEvent) {
			if (oEvent.getSource().getItems().length !== 0) {
				for (var i = 0; i < oEvent.getSource().getItems().length; i++) {
					oEvent.getSource().getItems()[i].getAggregation("cells")[1].setEnabled(false);
				}
			}
		},
		TipForAddDelivery: function(oEvent) {
			if (oEvent.getSource().getItems().length !== 0) {
				for (var i = 0; i < oEvent.getSource().getItems().length; i++) {
					oEvent.getSource().getItems()[i].getAggregation("cells")[1].setEnabled(false);
				}
			}
		}
	});
});