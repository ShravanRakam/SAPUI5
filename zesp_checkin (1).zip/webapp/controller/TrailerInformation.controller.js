var loggedUser;
var empNameID;
var vLoadPlant;
var vAction;
var oInsCreateDailog;
var sLanguage;
var sCheckinDateFormat;
var listMilkDialog;
var storeTraMilk;
var tipMilkList;
var tipStore;
var delNumber;
var sRegion;
var sObjectId;
// var DeliveryNumber;
var docId;
var ContractResults;
var sDelnum;
var sHaulierFlag;
var sHaulier1;
var sAddress1;
var sVatCode1;
var sHaulier2;
var sAddress2;
var sVatCode2;
var shipCondition;
var Haulier1;
var Address1;
var VatCode1;
var Haulier2;
var Address2;
var VatCode2;
var sDelType;
var delNumberforSO;
var sCupuData; // YMS Phase2 for CUPU service
var sLfrt;
var dropNpickFlag;
var sMblNumValidationFlag;
var ppeFlag;
var covidPositiveFlag;
var covidDeclineFlag;
var sPrflow;
var checkintypeservice;
var ztimestamp; //for Multi glid 
var zSigni;
var UAbuttonVisible;
var hNameVisFlag, hAddVisFlag, hVatVisFlag;
var pgmodel;
var sParentPlant;
var vtrploadUA;
var vHeaderUA;
var oDelNumUA;
var oDelNum;
var sUAbtnflag;
var trailerLive;

sap.ui.define([
	"sap/ui/core/mvc/Controller",
	"sap/m/MessageBox",
	"sap/m/MessageToast",
	"sap/m/Dialog",
	"sap/m/Button",
	"sap/m/Text",
	"sap/ui/model/Filter",
	"sap/ui/model/json/JSONModel",
	"chep/checkin/model/formatter"
], function(Controller, MessageBox, MessageToast, Dialog, Button, Text, Filter, JSONModel, formatter) {
	"use strict";
	return Controller.extend("chep.checkin.controller.TrailerInformation", {

		formatter: formatter,

		onInit: function() {
			jQuery.sap.require("jquery.sap.storage");
			var that = this;

			if ((sRegion === "US") || ((sRegion === "CA"))) {
				this.setInitialFocus(this.byId("driver_Name"));
			} else {
				this.setInitialFocus(this.byId("reg_Id"));
			}

			var oRouter = sap.ui.core.UIComponent.getRouterFor(this);
			oRouter.getRoute("TrailerInformation").attachPatternMatched(this._onObjectMatched, this);
			that.fnCreateBusyDialog("pallet.svg");
			pgmodel = new JSONModel({ // start - model used for displaying the page numbers
				"pgStart": "0",
				"pgEnd": "0"
			});
			that.getView().setModel(pgmodel, "pgmodel");
			var y = "/sap/bc/ui2/start_up";
			var xmlHttp = null;
			xmlHttp = new XMLHttpRequest();
			xmlHttp.onreadystatechange = function() {
				if (xmlHttp.readyState === 4 && xmlHttp.status === 200) {
					var oUserData = JSON.parse(xmlHttp.responseText);
					loggedUser = oUserData.id;
					empNameID = oUserData.fullName;
					sCheckinDateFormat = oUserData.dateFormat;
					sLanguage = jQuery.sap.storage(jQuery.sap.storage.Type.local).get("sysLang");
					that.getView().byId("langId").setText(sLanguage);
					that.getView().byId("empNameID").setVisible(false);
					that.getView().byId("empNameIDLab").setVisible(false);
					that.getView().byId("chepOrderNo").setVisible(true);
					that.byId("Header_Desktop_Bar_ID").setVisible(true);
				}
			};
			xmlHttp.open("GET", y, false);
			xmlHttp.send(null);

			//-----------------------------------------------------------------------------------------------------------------------------------------------	
			// Setting the clock and date
			//-----------------------------------------------------------------------------------------------------------------------------------------------
			/*	setInterval(function() {
				var sCurrDate = new Date();
				var dd = sCurrDate.getDate();
				var mm = sCurrDate.getMonth() + 1; //January is 0!
				var yyyy = sCurrDate.getFullYear();
				if (dd < 10) {
					dd = '0' + dd;
				}
				if (mm < 10) {
					mm = '0' + mm;
				}
				var sDate = yyyy.toString() + mm.toString() + dd.toString();
				var dFormDate = that.fnSetUserDateFormat(sDate, sCheckinDateFormat);
				var sCurrTime = sCurrDate.toLocaleTimeString();
				var result = dFormDate + " " + sCurrTime;

				if (that.getView().byId("oDateID") !== undefined) {
					that.getView().byId("oDateID").setText(result);
				}
				if (that.getView().byId("oDateID1") !== undefined) {
					that.getView().byId("oDateID1").setText(result);
				}
			}, 1000);*/

			setInterval(function() {

				var oTimeZone = jQuery.sap.storage(jQuery.sap.storage.Type.local).get("sTimeZone");
				var oDayLightSaving = jQuery.sap.storage(jQuery.sap.storage.Type.local).get("sDayLightSaving");
				var oFlag = jQuery.sap.storage(jQuery.sap.storage.Type.local).get("sFlag");

				if (oFlag === false || oFlag === "false" || oFlag === null || oFlag === undefined) {
					var resultBrowser = that.realDateTimeClockBrowser();

					if (that.getView().byId("oDateID") !== undefined) {
						that.getView().byId("oDateID").setText(resultBrowser);
					}
					if (that.getView().byId("oDateID1") !== undefined) {
						that.getView().byId("oDateID1").setText(resultBrowser);
					}

				} else if (oFlag === true || oFlag === "true") {
					var result = that.realDateTimeClock(oTimeZone, oDayLightSaving);

					if (that.getView().byId("oDateID") !== undefined) {
						that.getView().byId("oDateID").setText(result);
					}
					if (that.getView().byId("oDateID1") !== undefined) {
						that.getView().byId("oDateID1").setText(result);
					}

				}

			}, 1000);

		},

		// Function to change the time based on timezone

		realDateTimeClockBrowser: function() {
			var that = this;
			var sCurrDate = new Date();
			var dd = sCurrDate.getDate();
			var mm = sCurrDate.getMonth() + 1; //January is 0!
			var yyyy = sCurrDate.getFullYear();
			if (dd < 10) {
				dd = '0' + dd;
			}
			if (mm < 10) {
				mm = '0' + mm;
			}
			var sDate = yyyy.toString() + mm.toString() + dd.toString();
			var dFormDate = that.fnSetUserDateFormat(sDate, sCheckinDateFormat);
			//	var sDate = sCurrDate.toLocaleDateString();
			var sCurrTime = sCurrDate.toLocaleTimeString();
			var result = dFormDate + " " + sCurrTime;
			return result;
		},

		realDateTimeClock: function(TimeZone, DayLightSaving) {
			var that = this;

			/*	var sData = that.getView().getModel("HeaderDetailsPlant").getData();
			var TimeZone = sData.UTC_DIFF;
			var DayLightSaving = sData.DST_DIFF;*/

			var timeZoneOutput = [TimeZone.slice(0, 3), ":", TimeZone.slice(3, 5)].join('');

			if (DayLightSaving === "") {
				DayLightSaving = "0";
			}

			// var DayLightSavingOutput = [DayLightSaving.slice(0, 2), ":", DayLightSaving.slice(2, 4)].join('');

			if (timeZoneOutput.startsWith("-")) {
				var concatTimeZoneDayLight = parseInt(TimeZone.slice(1, 3)) - parseInt(DayLightSaving.slice(0, 2));
			} else if (timeZoneOutput.startsWith("+")) {
				var concatTimeZoneDayLight = parseInt(TimeZone.slice(1, 3)) + parseInt(DayLightSaving.slice(0, 2));
			}

			var finalOffset = [TimeZone.slice(0, 1), concatTimeZoneDayLight, ":", TimeZone.slice(3, 5)].join('');

			var _now = new Date();

			//var timeZoneOutput = "+11:00";
			var date = that.timezoneShifter(_now, finalOffset);

			var resultDate = that.formatTimeClock(date);
			return resultDate;
		},

		timezoneShifter: function(date, timezone) {

			var isBehindGTM = false;
			if (timezone.startsWith("-")) {
				timezone = timezone.substr(1);
				isBehindGTM = true;
			}

			var hDiff = timezone.split(":").map(myFunction);

			function myFunction(t) {
				return parseInt(t);
			}

			var value = isBehindGTM ? 1 : -1;
			var diff = (hDiff[0] * 60 + hDiff[1]) * value;
			var currentDiff = new Date().getTimezoneOffset();

			return new Date(date.valueOf() + (currentDiff - diff) * 60 * 1000);
		},

		formatTimeClock: function(_now) {
			var that = this;
			var sCurrDate = _now;
			var dd = sCurrDate.getDate();
			var mm = sCurrDate.getMonth() + 1; //January is 0!
			var yyyy = sCurrDate.getFullYear();
			if (dd < 10) {
				dd = '0' + dd;
			}
			if (mm < 10) {
				mm = '0' + mm;
			}
			var sDate = yyyy.toString() + mm.toString() + dd.toString();
			var dFormDate = that.fnSetUserDateFormat(sDate, sCheckinDateFormat);
			//	var sDate = sCurrDate.toLocaleDateString();
			var sCurrTime = sCurrDate.toLocaleTimeString();
			var result = dFormDate + " " + sCurrTime;
			return result;
		},

		setInitialFocus: function(control) {
			this.getView().addEventDelegate({
				onAfterShow: function() {
					setTimeout(function() {
						control.focus();
					}.bind(this), 0);
				}
			}, this);
		},

		mblnumber: function(e) {
			this.getView().byId("Mobile_Num").setValueState(sap.ui.core.ValueState.None);
			var iValue = this.getView().byId("Mobile_Num").getValue();
			//To restrict user to enter only characters
			// iValue = iValue.replace(/[^\d]/g, '');
			iValue = iValue.replace(/[a-zA-Z@,./\\|^#&$%*(){}+=_:;!>""<?~''`\-\[\]\]]/g, "");
			this.getView().byId("Mobile_Num").setValue(iValue);

			var mblnum = this.getView().byId("Mobile_Num").getValue();
			if (mblnum.length === 1 && mblnum === "0") {
				mblnum = mblnum.slice(0, -1);
				this.getView().byId("Mobile_Num").setValue(mblnum);
			}
			if (mblnum.length > 20) {
				var mobilenumber = mblnum.substring(0, mblnum.length - 1);
				this.getView().byId("Mobile_Num").setValue(mobilenumber);
			}
		},

		_onObjectMatched: function(oEvent) {
			var that = this;
			var oArg = oEvent.getParameter("arguments");
			sObjectId = oArg.objectId.split(",")[0];

			trailerLive = jQuery.sap.storage(jQuery.sap.storage.Type.local).get("trailerLive");
			vtrploadUA = jQuery.sap.storage(jQuery.sap.storage.Type.local).get("oTripLoadUA");
			sUAbtnflag = jQuery.sap.storage(jQuery.sap.storage.Type.local).get("oUAbtn");
			vHeaderUA = jQuery.sap.storage(jQuery.sap.storage.Type.local).get("oHeaderUA");
			if (vtrploadUA === "X") {
				oDelNumUA = oArg.objectId.split(",")[1];
				oDelNum = oArg.objectId.split(",")[2];
			}
			sHaulierFlag = jQuery.sap.storage(jQuery.sap.storage.Type.local).get("sContract");
			storeTraMilk = jQuery.sap.storage(jQuery.sap.storage.Type.local).get("milkRunList");
			tipMilkList = jQuery.sap.storage(jQuery.sap.storage.Type.local).get("tipReloadList");
			sDelType = jQuery.sap.storage(jQuery.sap.storage.Type.local).get("sDeliveryType");
			sRegion = jQuery.sap.storage(jQuery.sap.storage.Type.local).get("sRegion");
			if ((storeTraMilk !== undefined) || (tipMilkList !== undefined)) {
				if (((storeTraMilk.length > 1) || (storeTraMilk.length > 0 && tipMilkList.length > 0)) || ((tipMilkList.length > 1) || (
					tipMilkList.length >
					0 && storeTraMilk.length > 0))) {
					that.byId("milkRunBtId").setVisible(true);
				} else {
					that.byId("milkRunBtId").setVisible(false);
				}
			}

			if (sHaulierFlag === "true") {

				if ((sObjectId === "U") || (sObjectId === "P")) {
					that.byId("subContracter").setVisible(false);
					that.byId("haulierDataCheck").setVisible(false);
				} else {
					that.byId("subContracter").setVisible(true);
					that.byId("haulierDataCheck").setVisible(true);
				}
			} else {
				that.byId("subContracter").setVisible(false);
				that.byId("haulierDataCheck").setVisible(false);
			}

			var i18n = that.getOwnerComponent();

			var trailerInformation = i18n.getModel("i18n").getProperty('trailerinfo');
			this.byId("trailerInfoForm").setText(trailerInformation);
			MessageBox._rb = sap.ui.getCore().getLibraryResourceBundle("sap.m", sLanguage);
			var sPageType = jQuery.sap.storage(jQuery.sap.storage.Type.local).get("PageType");

			if ((sRegion === "US") || ((sRegion === "CA"))) {
				this.byId("registrationLabel").setVisible(false);
				this.byId("reg_Id").setVisible(false);
				this.byId("driverName").addStyleClass("driverNameCSS");
			} else {
				this.byId("registrationLabel").setVisible(true);
				this.byId("reg_Id").setVisible(true);
				this.byId("driverName").removeStyleClass("driverNameCSS");
			}

			if (sPageType === "DD") {
				//	that.getView().byId("pageNo").setText("4 of 5");
				that.getView().getModel("pgmodel").setProperty("/pgStart", "4");
				that.getView().getModel("pgmodel").setProperty("/pgEnd", "5");
			} else {
				//	that.getView().byId("pageNo").setText("3 of 4");
				that.getView().getModel("pgmodel").setProperty("/pgStart", "3");
				that.getView().getModel("pgmodel").setProperty("/pgEnd", "4");
			}

			var url = "/sap/opu/odata/sap/ZGW_DELIVERY_AP_SRV";
			var oModel = new sap.ui.model.odata.ODataModel(url);

			oModel.read("/HeaderDetailsSet('" + loggedUser + "')", null, null, false, function(oData) {
					var oODataJSONModel2 = new sap.ui.model.json.JSONModel();
					oODataJSONModel2.setData(oData);
					that.getView().setModel(oODataJSONModel2, "HeaderDetails");

					//---------Start of Multi Plant Changes----------// 
					sParentPlant = oData.ParentPlant;
					if (sParentPlant !== "") {
						vLoadPlant = sParentPlant;
					} else {
						vLoadPlant = oData.Plant;
					}

					// vLoadPlant = oData.Plant;
					//---------End of Multi Plant Changes----------// 
					sPrflow = oData.Prflow;
					oInsCreateDailog.close();
				},
				function(error) {
					oInsCreateDailog.close();
					MessageBox.show("Error");
				});

			this.trailersize();
			this.onProductCodeValue();
			jQuery.sap.storage(jQuery.sap.storage.Type.local).put("objectID", sObjectId);
			vAction = sObjectId;

			var sReturnDropBob = jQuery.sap.storage(jQuery.sap.storage.Type.local).get("returnDrop");
			var sIssueDropBob = jQuery.sap.storage(jQuery.sap.storage.Type.local).get("issueDrop");
			if ((sReturnDropBob === "B") || (sIssueDropBob === "B")) {
				sObjectId = "B";
			}

			var driverInformation = i18n.getModel("i18n").getProperty('driverInfo');
			that.getView().byId("chepOrderNo").setText(that.getView().getModel("i18n").getProperty('orderNum') + "-" + jQuery.sap.storage(
				jQuery.sap
				.storage.Type.local).get("DeliveryNumber"));
			if (sObjectId === "U") {
				this.byId("trailersubmit").setVisible(true);
				this.byId("trailercancel").setVisible(true);
				this.byId("trailerpass").setVisible(false);
				this.byId("tarilerType").setVisible(true);
				this.byId("size").setVisible(true);
				this.byId("lblTarilerId").setVisible(true);
				this.byId("Trailer_Id").setVisible(true);
			} else if (sObjectId === "P") {
				this.byId("trailersubmit").setVisible(false);
				this.byId("trailercancel").setVisible(false);
				this.byId("trailerpass").setVisible(true);
				this.byId("tarilerType").setVisible(true);
				this.byId("size").setVisible(true);
				this.byId("lblTarilerId").setVisible(true);
				this.byId("Trailer_Id").setVisible(true);
			} else if (sObjectId === "B") {
				//	this.getView().byId("orderNum").setText(DeliveryNumber);
				this.byId("trailersubmit").setVisible(true);
				this.byId("trailercancel").setVisible(true);
				this.byId("trailerpass").setVisible(false);
				this.byId("tarilerType").setVisible(false);
				this.byId("size").setVisible(false);
				this.byId("lblTarilerId").setVisible(false);
				this.byId("Trailer_Id").setVisible(false);
				this.byId("trailerInfoForm").setText(driverInformation);
			} else {
				//this.getView().byId("orderNum").setText(DeliveryNumber);
				this.byId("trailersubmit").setVisible(true);
				this.byId("trailercancel").setVisible(true);
				this.byId("trailerpass").setVisible(false);
				this.byId("tarilerType").setVisible(true);
				this.byId("size").setVisible(true);
				this.byId("lblTarilerId").setVisible(true);
				this.byId("Trailer_Id").setVisible(true);
			}
			var dataAvailable = i18n.getModel("i18n").getProperty('contractorAvailableData');
			var noDataAvailable = i18n.getModel("i18n").getProperty('noContractorData');
			ContractResults = [];
			// sDelnum = jQuery.sap.storage(jQuery.sap.storage.Type.local).get("DeliveryNumber");
			delNumberforSO = jQuery.sap.storage(jQuery.sap.storage.Type.local).get("DeliveryNumberforSalesOrder");

			var sContractService = "/sap/opu/odata/sap/ZGW_DELIVERY_AP_SRV/";
			var oHaulierModel = new sap.ui.model.odata.ODataModel(sContractService);
			oHaulierModel.read("/HaulierDetailsSet?$filter=DocId eq '" + delNumberforSO + "' and Werks eq '" + vLoadPlant + "'", null, null,
				false,
				function(oData, oResponse) {
					if ((oResponse.statusCode === 200) || (oResponse.statusCode === "200")) {
						oInsCreateDailog.close();
						ContractResults = oData.results;
						if ((ContractResults[0].Haulier !== "") && (ContractResults[0].Address !== "") && (ContractResults[0].VatCode !== "")) {
							that.byId("dataCheck").setSelected(true);
							that.byId("dataCheck").setEnabled(false);
							that.byId("contractorData").setText(dataAvailable);
							that.byId("contractorData").removeStyleClass("noHaulierData");
							that.byId("contractorData").addStyleClass("availableHaulierData");

						} else {
							that.byId("dataCheck").setSelected(false);
							that.byId("contractorData").setText(noDataAvailable);
							that.byId("contractorData").removeStyleClass("availableHaulierData");
							that.byId("contractorData").addStyleClass("noHaulierData");

						}
					}
				},
				function(error) {
					oInsCreateDailog.close();
					MessageBox.show("Error");
				});

			var HaulierObj = {
				"HaulierName": ContractResults[0].Haulier

			};
			var sNewModel = new sap.ui.model.json.JSONModel(HaulierObj);

			that.getView().setModel(sNewModel, "HaulierModel");

			shipCondition = jQuery.sap.storage(jQuery.sap.storage.Type.local).get("ShipCondition");
			sLfrt = jQuery.sap.storage(jQuery.sap.storage.Type.local).get("sLfrt");
			if (sRegion === "US") {
				if (sHaulierFlag === "true") {
					if ((shipCondition === "Z1" || shipCondition === "Z4") || (shipCondition === "Z3") || (sLfrt === "ZVBS")) {
						that.getView().byId("sizecompany").setSelectedKey("CUPU");
						that.getView().byId("sizecompany").setEnabled(false);
						that.getView().byId("transportNameSelect").setVisible(false);
						that.onTransportNameSelect();
					} else if ((shipCondition === "Z2") && (sLfrt !== "ZVBS")) {
						var vCarrier = jQuery.sap.storage(jQuery.sap.storage.Type.local).get("Scac");
						if (vCarrier !== "") {
							var oScacData = that.getView().byId("sizecompany").getModel().getData();
							var scacCode;
							for (var j = 0; j < oScacData.length; j++) {
								if (oScacData[j].ScacCode !== "") {
									if (oScacData[j].ScacCode !== "CUPU") {
										scacCode = vCarrier;
									}
								}
								if (oScacData[j].ScacCode === vCarrier) {
									var scacFlag = "X";
								}

							}
							if (scacCode !== undefined) {
								if (scacFlag !== undefined) { // scacCode is not found in scacset
									this.byId("sizecompany").setSelectedKey(scacCode);
									this.byId("sizecompany").setEnabled(false);
								} else {
									this.byId("sizecompany").setSelectedKey("");
									this.byId("sizecompany").setEnabled(true);
								}
							} else {
								this.byId("sizecompany").setSelectedKey("");
								this.byId("sizecompany").setEnabled(true);
							}
						} else {
							this.byId("sizecompany").setEnabled(true);
						}
					}
				} //end of Haulierflag condition
				else {
					if ((shipCondition === "Z1" || shipCondition === "Z4") || (shipCondition === "Z3") || (sLfrt === "ZVBS")) {
						that.getView().byId("sizecompany").setSelectedKey("CUPU");
						that.getView().byId("sizecompany").setEnabled(false);
						this.getView().byId("transportname").setVisible(true);
						that.getView().byId("transportNameSelect").setVisible(true);
						that.onTransportNameSelect();

					} else if ((shipCondition === "Z2") && (sLfrt !== "ZVBS")) {
						var vCarrier = jQuery.sap.storage(jQuery.sap.storage.Type.local).get("Scac");
						if (vCarrier !== "") {
							var oScacData = that.getView().byId("sizecompany").getModel().getData();
							var scacCode;
							for (var j = 0; j < oScacData.length; j++) {
								if (oScacData[j].ScacCode !== "") {
									if (oScacData[j].ScacCode !== "CUPU") {
										scacCode = vCarrier;
									}
								}
								if (oScacData[j].ScacCode === vCarrier) {
									var sFlag = "X";
								}
							}
							if (scacCode !== undefined) {
								if (sFlag !== undefined) {
									this.byId("sizecompany").setSelectedKey(scacCode);
									this.byId("sizecompany").setEnabled(false);
								} else {
									//	this.byId("sizecompany").setSelectedKey(scacCode);
									this.byId("sizecompany").setEnabled(true);
								}

								//	this.byId("sizecompany").setSelectedKey(scacCode);
								//	this.byId("sizecompany").setEnabled(false);
							} else {
								//	this.byId("sizecompany").setSelectedKey("");
								this.byId("sizecompany").setEnabled(true);
							}
							if (scacCode === "CUPU") {
								this.getView().byId("transportname").setVisible(true);
								this.getView().byId("companyScacode").setVisible(true);
							} else {
								this.getView().byId("transportname").setVisible(false);
								this.getView().byId("companyScacode").setVisible(false);
							}
						}
					} else {
						this.byId("sizecompany").setEnabled(true);
					}
				}
			} //end of USXP Plant condition
			else { // code for other than USXP Plant
				if (sHaulierFlag === "true") {
					if ((shipCondition === "Z1" || shipCondition === "Z4") || (shipCondition === "Z3") || (sLfrt === "ZVBS")) {
						that.getView().byId("sizecompany").setSelectedKey("0000999999");
						that.getView().byId("sizecompany").setEnabled(false);
						// this.getView().byId("transportname").setVisible(true);
						// that.getView().byId("companyScacode").setVisible(true);

					} else if ((shipCondition === "Z2") && (sLfrt !== "ZVBS")) {
						var sLifnr = jQuery.sap.storage(jQuery.sap.storage.Type.local).get("Lifnr");
						if (sLifnr !== "") {
							var oVendorData = that.getView().byId("sizecompany").getModel().getData();
							var sVendor;
							var newData = {
								werks: vLoadPlant,
								Lifnr: sLifnr,
								Name1: ContractResults[0].Haulier
							};
							oVendorData.push(newData);

							var vSize1 = that.getView().byId("sizecompany");
							var vTrailerSize1 = new sap.ui.model.json.JSONModel(oVendorData);
							vTrailerSize1.setSizeLimit(oVendorData.length);
							var oTemplate11 = new sap.ui.core.ListItem({
								text: "{Name1}",
								key: "{Lifnr}"
							});
							vSize1.setModel(vTrailerSize1);
							vSize1.bindItems("/", oTemplate11);
							vSize1.getModel().refresh();

							for (var i = 0; i < oVendorData.length; i++) {
								if (oVendorData[i].Lifnr !== "") {
									if (oVendorData[i].Lifnr !== "0000999999") {
										sVendor = sLifnr;
									}
								}
								if (oVendorData[i].Lifnr === sLifnr) {
									var vendorFlag = "X";
								}
							}
							if (sVendor !== undefined) {
								if (vendorFlag !== undefined) {
									this.byId("sizecompany").setSelectedKey(sVendor);
									this.byId("sizecompany").setEnabled(false);
								} else {
									// this.byId("sizecompany").setSelectedKey("");
									this.byId("sizecompany").setEnabled(true);
								}
							} else {
								// this.byId("sizecompany").setSelectedKey("");
								this.byId("sizecompany").setEnabled(true);
							}

						} else {
							this.byId("sizecompany").setEnabled(true);
						}
					}
				} else {
					if ((shipCondition === "Z1" || shipCondition === "Z4") || (shipCondition === "Z3") || (sLfrt === "ZVBS")) {
						that.getView().byId("sizecompany").setSelectedKey("0000999999");
						that.getView().byId("sizecompany").setEnabled(false);
						this.getView().byId("transportname").setVisible(true);
						that.getView().byId("companyScacode").setVisible(true);

					} else if ((shipCondition === "Z2") && (sLfrt !== "ZVBS")) {
						var sLifnr = jQuery.sap.storage(jQuery.sap.storage.Type.local).get("Lifnr");
						if (sLifnr !== "") {
							var oVendorData = that.getView().byId("sizecompany").getModel().getData();
							var sVendor;
							for (var i = 0; i < oVendorData.length; i++) {
								if (oVendorData[i].Lifnr !== "") {
									if (oVendorData[i].Lifnr !== "0000999999") {
										sVendor = sLifnr;
									}
								}
								if (oVendorData[i].Lifnr === sLifnr) {
									var sVendorFlag = "X";
								}
							}
							if (sVendor !== undefined) {
								if (sVendorFlag !== undefined) {
									this.byId("sizecompany").setSelectedKey(sVendor);
									this.byId("sizecompany").setEnabled(false);
								} else {
									// this.byId("sizecompany").setSelectedKey("");
									this.byId("sizecompany").setEnabled(true);
								}
							} else {
								// this.byId("sizecompany").setSelectedKey("");
								this.byId("sizecompany").setEnabled(true);
							}
							if (sLifnr === "0000999999") {
								this.getView().byId("transportname").setVisible(true);
								this.getView().byId("companyScacode").setVisible(true);
							} else {
								this.getView().byId("transportname").setVisible(false);
								this.getView().byId("companyScacode").setVisible(false);
							}
							/*	if (sVendor !== undefined) {
								this.byId("sizecompany").setSelectedKey(sVendor);
								this.byId("sizecompany").setEnabled(false);
							} else {
								this.byId("sizecompany").setSelectedKey("");
								this.byId("sizecompany").setEnabled(true);
							}
							if (sLifnr === "0000999999") {
								this.getView().byId("transportname").setVisible(true);
								this.getView().byId("companyScacode").setVisible(true);
							} else {
								this.getView().byId("transportname").setVisible(false);
								this.getView().byId("companyScacode").setVisible(false);
							}*/
						}
					} else {
						this.byId("sizecompany").setEnabled(true);
					}
				}
			} // end of Other Plant condition

			this.byId("reg_Id").setValue("");
			this.byId("Trailer_Id").setValue("");
			this.byId("size").setValue("");
			this.byId("driver_Name").setValue("");
			this.byId("companyScacode").setValue("");
			//this.byId("sizecompany").setValue("");
			this.byId("Mobile_Num").setValue("");
			//this.byId("trailertype").setValue("");
			//----------For Enable the TrailID info Button-------//
			//----------Change Format of Trailer Number field in Truck Driver Screen to a free field for all Brazil plants-------//
			/*	if (sRegion === "LATAM" && sPrflow === "01") {
				this.byId("Trailer_IdBtn").setVisible(true);
			}*/
			//----------Change Format of Trailer Number field in Truck Driver Screen to a free field for all Brazil plants-------//
			//  Checking Houlier Data model return to Trailer information controller

			var HolierModel = that.getOwnerComponent().getModel("HolierModeldata");
			if (HolierModel !== undefined) {
				var oacceptCheck = HolierModel.getData();
				if (oacceptCheck.length > 0) {
					that.getView().byId("holierAcceptd").setVisible(true);
					that.getView().byId("noHoliuerId").setVisible(false);
				} else {
					that.getView().byId("holierAcceptd").setVisible(false);
					that.getView().byId("noHoliuerId").setVisible(true);
				}
			} else {
				that.getView().byId("addDelivery").setVisible(false);
				that.getView().byId("noHoliuerId").setVisible(false);
				that.getView().byId("holierAcceptd").setVisible(false);
			}
			/*Haulier Dialog if there is no Custmer enable the Button*/
			// var noCustmer = new sap.ui.model.json.JSONModel([{
			// 	CustmerButon: false
			// }]);
			// that.getView().setModel(noCustmer, "CustmerModel");

			var oModelRoute = new sap.ui.model.json.JSONModel([{
				Lifnr: "",
				quantity: "",
				Zcintime: "",
				Lfimg: "",
				Werks: "",
				GlidEditable: true,
				noGlid: false,
				glidempty: "",
				glidRegion: false,
				newGlid: true,
				productCode: "",
				parentId: null,
				nodeid: 0
			}]);
			that.getView().setModel(oModelRoute, "NewrowModel");

			sRegion = jQuery.sap.storage(jQuery.sap.storage.Type.local).get("sRegion");
			// 			if (sObjectId !== "U") {

			/*-----------Start of Remito Code Changes -----------*/

			var sNoRemitoDetailsText = i18n.getModel("i18n").getProperty('remitoDetailsNotAdded');

			var oPlant = new sap.ui.model.json.JSONModel({
				sPlant: sRegion,
				glidVisibleLATAM: false,
				sNotaBtnVis: false,
				remitoDetailsState: "Error",
				remitoDetailsText: sNoRemitoDetailsText,
				remitoIcon: "sap-icon://sys-cancel-2"
			});

			that.getView().setModel(oPlant, "oPlantModel");

			var sRemitoFlagCheck = jQuery.sap.storage(jQuery.sap.storage.Type.local).get("RemitoFlag");
			// var sOrdertype = jQuery.sap.storage(jQuery.sap.storage.Type.local).get("Ordertype");
			if (sRemitoFlagCheck === "true" || sRemitoFlagCheck === true) {
				if (storeTraMilk.length > 0 && sObjectId !== "U") {
					// if ((sOrdertype === "Collect" || sOrdertype === "collect") || (sOrdertype === "STO Receipt" || sOrdertype === "sto receipt")) {
					that.getView().getModel("oPlantModel").setProperty("/sNotaBtnVis", true);
					that.remitoNumValidationCheck();
				} else {
					that.getView().getModel("oPlantModel").setProperty("/sNotaBtnVis", false);
				}
			} else {
				that.getView().getModel("oPlantModel").setProperty("/sNotaBtnVis", false);
			}
			/*-----------End of Remito Code Changes -----------*/
			// }

			// that.sDeviceType = "";
			$.urlParam = function(name) {
				var results = new RegExp('[\?&]' + name + '=([^&#]*)').exec(window.location.href);
				if (results == null) {
					return null;
				} else {
					return decodeURI(results[1]) || 0;
				}
			};

			var sFilteredApp = $.urlParam("KIOSK_FLAG");
			if (sFilteredApp === null) {
				that.sDeviceType = "Browser";
			} else {
				that.sDeviceType = "KIOSK";
			}

		},

		remitoNumValidationCheck: function() {

			var that = this;
			var i18n = that.getOwnerComponent();
			var sRemitoDetailsAdded = i18n.getModel("i18n").getProperty('remitoDetailsAdded');
			var sNoRemitoDetailsText = i18n.getModel("i18n").getProperty('remitoDetailsNotAdded');

			var sReturnDelNum = jQuery.sap.storage(jQuery.sap.storage.Type.local).get("milkRunList");

			var sInitialArray = [];

			var oEntry = {};
			oEntry.WERKS = vLoadPlant;
			oEntry.DOC_ID = delNumberforSO;
			oEntry.QUERY = "R";

			if (sReturnDelNum.length !== 0) {
				for (var kCount = 0; kCount < sReturnDelNum.length; kCount++) {
					var sItemsData = {
						"WERKS": sReturnDelNum[kCount].Plant,
						"DOC_ID": sReturnDelNum[kCount].chepdeliverynumber
						// "NFKEY": sDataModel[kCount].NFKEY
					};
					sInitialArray.push(sItemsData);
				}

				oEntry.HeaderItem_Nav = sInitialArray;
				// oEntry.HEADER_ITEM_ASSOCSet = sInitialArray;
				that.fnCreateBusyDialog("pallet.svg");
				that.getOwnerComponent().getModel("remitoDataModel").create("/ETS_HEADER", oEntry, {
					success: function(oData, oResponse) {
						if (oResponse.statusCode === 201 || oResponse.statusCode === "201") {
							oInsCreateDailog.close();
							var sRemitoDataFromService = oData.HeaderItem_Nav.results;
							var sRemitoNumData = $.grep(sRemitoDataFromService, function(e) {
								return e.NFKEY !== "";
							});
							if (sRemitoNumData.length > 0) {
								that.getView().getModel("oPlantModel").setProperty("/remitoDetailsState", "Success");
								that.getView().getModel("oPlantModel").setProperty("/remitoDetailsText", sRemitoDetailsAdded);
								that.getView().getModel("oPlantModel").setProperty("/remitoIcon", "sap-icon://sys-enter-2");
							} else {
								that.getView().getModel("oPlantModel").setProperty("/remitoDetailsState", "Error");
								that.getView().getModel("oPlantModel").setProperty("/remitoDetailsText", sNoRemitoDetailsText);
								that.getView().getModel("oPlantModel").setProperty("/remitoIcon", "sap-icon://sys-cancel-2");
							}
						}
					},
					error: function(oError) {
						oInsCreateDailog.close();
						var oMessage;
						if (oMessage === undefined) {
							oMessage = JSON.parse(oError.responseText).error.message.value;
						}
						sap.m.MessageBox.show(
							oMessage, {
								icon: sap.m.MessageBox.Icon.ERROR,
								title: i18n.getModel("i18n").getProperty('error')
							});
					}
				});
			}
		},

		//----------For Adding Sub-Contractors-------//
		onContractPress: function() {
			var that = this;
			that.fnCreateBusyDialog("pallet.svg");
			// sDelnum = jQuery.sap.storage(jQuery.sap.storage.Type.local).get("DeliveryNumber");

			if (!this._contractorDialog) {
				this._contractorDialog = sap.ui.xmlfragment("chep.checkin.fragments.AddSubContractors", this);
				this.getView().addDependent(this._contractorDialog);
			}
			jQuery.sap.syncStyleClass("sapUiSizeCompact", this.getView(), this._contractorDialog);

			this._contractorDialog.open();
			oInsCreateDailog.close();

			if ((shipCondition === "Z1" || shipCondition === "Z4") || (shipCondition === "Z3") || (sLfrt === "ZVBS")) {
				//	sap.ui.getCore().byId("secondaryHaulierDetails").setVisible(false);
				//	sap.ui.getCore().byId("secondaryHaulierDetails").setEditable(false);
				sap.ui.getCore().byId("hauliername2").setEditable(false);
				sap.ui.getCore().byId("address2").setEditable(false);
				sap.ui.getCore().byId("vatcode2").setEditable(false);
				sap.ui.getCore().byId("hauliername2").setEnabled(false);
				sap.ui.getCore().byId("address2").setEnabled(false);
				sap.ui.getCore().byId("vatcode2").setEnabled(false);
				sap.ui.getCore().byId("clearData2").setEnabled(false);
			} else {
				//	sap.ui.getCore().byId("secondaryHaulierDetails").setVisible(true);
				//	sap.ui.getCore().byId("secondaryHaulierDetails").setEditable(true);
				sap.ui.getCore().byId("hauliername2").setEditable(true);
				sap.ui.getCore().byId("address2").setEditable(true);
				sap.ui.getCore().byId("vatcode2").setEditable(true);
				sap.ui.getCore().byId("hauliername2").setEnabled(true);
				sap.ui.getCore().byId("address2").setEnabled(true);
				sap.ui.getCore().byId("vatcode2").setEnabled(true);
				sap.ui.getCore().byId("clearData2").setEnabled(true);
			}

			var sContractService = "/sap/opu/odata/sap/ZGW_DELIVERY_AP_SRV/";
			var oHaulierModel = new sap.ui.model.odata.ODataModel(sContractService);
			oHaulierModel.read("/HaulierDetailsSet?$filter=DocId eq '" + delNumberforSO + "' and Werks eq '" + vLoadPlant + "'", null, null,
				false,
				function(oData, oResponse) {
					if ((oResponse.statusCode === 200) || (oResponse.statusCode === "200")) {
						oInsCreateDailog.close();
						ContractResults = oData.results;
						Haulier1 = ContractResults[0].Haulier;
						Address1 = ContractResults[0].Address;
						VatCode1 = ContractResults[0].VatCode;
						hNameVisFlag = ContractResults[0].CH_HN; // VAT changes for EU Region
						hAddVisFlag = ContractResults[0].CH_HA; // VAT changes for EU Region
						hVatVisFlag = ContractResults[0].CH_HVAT; // VAT changes for EU Region
						Haulier2 = ContractResults[1].Haulier;
						Address2 = ContractResults[1].Address;
						VatCode2 = ContractResults[1].VatCode;
					}
				},
				function(error) {
					oInsCreateDailog.close();
					MessageBox.show("Error");
				});

			/*		Haulier1 = ContractResults[0].Haulier;
			Address1 = ContractResults[0].Address;
			VatCode1 = ContractResults[0].VatCode;

			Haulier2 = ContractResults[1].Haulier;
			Address2 = ContractResults[1].Address;
			VatCode2 = ContractResults[1].VatCode;*/
			/*  For Z1  dleveries added condition*/

			if (shipCondition !== "Z1" || shipCondition !== "Z4") {
				if (Haulier1 !== "") {
					sap.ui.getCore().byId("hauliername1").setValue(Haulier1);
					sap.ui.getCore().byId("hauliername1").setEnabled(false);
				} else {
					var sSizeFilter = that.byId("sizecompany").getSelectedKey();
					if ((sSizeFilter === "0000999999") || (sSizeFilter === "CUPU") || (sSizeFilter === "")) {
						sap.ui.getCore().byId("hauliername1").setValue("");
						sap.ui.getCore().byId("hauliername1").setEnabled(true);
					} else {
						var sSelectedHaulier = this.byId("sizecompany").getSelectedItem().getText();
						sap.ui.getCore().byId("hauliername1").setValue(sSelectedHaulier);
						sap.ui.getCore().byId("hauliername1").setEnabled(false);
					}
				}
				if (Address1 !== "") {
					sap.ui.getCore().byId("address1").setValue(Address1);
					sap.ui.getCore().byId("address1").setEnabled(false);
				} else {
					sap.ui.getCore().byId("address1").setValue("");
					sap.ui.getCore().byId("address1").setEnabled(true);
				}
				if (VatCode1 !== "") {
					sap.ui.getCore().byId("vatcode1").setValue(VatCode1);
					sap.ui.getCore().byId("vatcode1").setEnabled(false);
				} else {
					sap.ui.getCore().byId("vatcode1").setValue("");
					sap.ui.getCore().byId("vatcode1").setEnabled(true);
				}
				if ((Haulier1 !== "") && (Address1 !== "") && (VatCode1 !== "")) {
					sap.ui.getCore().byId("clearData1").setEnabled(false);
				} else {
					sap.ui.getCore().byId("clearData1").setEnabled(true);
				}

				sap.ui.getCore().byId("hauliername2").setValue(Haulier2);
				sap.ui.getCore().byId("address2").setValue(Address2);
				sap.ui.getCore().byId("vatcode2").setValue(VatCode2);
			}
			if (shipCondition === "Z1" || shipCondition === "Z4") {
				sap.ui.getCore().byId("address1").setValue(Address1);
				sap.ui.getCore().byId("vatcode1").setValue(VatCode1);
			}
		},

		onContractCancel: function() {
			oInsCreateDailog.close();
			this._contractorDialog.close();
		},

		onContractSubmit: function() {
			var that = this;
			that.fnCreateBusyDialog("pallet.svg");
			// sDelnum = jQuery.sap.storage(jQuery.sap.storage.Type.local).get("DeliveryNumber");

			var createHaulierMod = that.getOwnerComponent().getModel("HaulierMod");
			createHaulierMod.setUseBatch(false);
			var sHeaderData;
			createHaulierMod.read("/HeaderSet(DocId='" + delNumberforSO + "',Werks='" + vLoadPlant + "')?$expand=HaulierDetailsNavig", {
				success: function(oData, oResponse) {
					if ((oResponse.statusCode === 200) || (oResponse.statusCode === "200")) {

						sHeaderData = oData;
						var i18nModel = that.getOwnerComponent();
						sHaulier1 = sap.ui.getCore().byId("hauliername1").getValue();
						sAddress1 = sap.ui.getCore().byId("address1").getValue();
						sVatCode1 = sap.ui.getCore().byId("vatcode1").getValue();

						sHaulier2 = sap.ui.getCore().byId("hauliername2").getValue();
						sAddress2 = sap.ui.getCore().byId("address2").getValue();
						sVatCode2 = sap.ui.getCore().byId("vatcode2").getValue();

						/* VAT changes for EU Region*/
						var valFlag = "";
						if (sHaulier1 === "" && hNameVisFlag === "false") {
							valFlag = "X";
						}
						if (sAddress1 === "" && hAddVisFlag === "false") {
							valFlag = "X";
						}
						if (sVatCode1 === "" && hVatVisFlag === "false") {
							valFlag = "X";
						}

						if (valFlag === "X" &&
							((sHaulier2 === "") || (sAddress2 === "") || (sVatCode2 === ""))) {
							var addSubcontractors = i18nModel.getModel("i18n").getProperty('contractorSubmit');
							var submitError = that.getView().getModel("i18n").getProperty('submitError');
							var oMessage = addSubcontractors; //"Please Enter Order Number";
							MessageBox.show(
								oMessage, {
									icon: sap.m.MessageBox.Icon.ERROR,
									title: submitError //"Error during submitting!"
								});
						} else {
							var ContItems = [];
							var oContractEntry1 = {
								"Werks": vLoadPlant,
								"DocId": sHeaderData.DocId,
								"Haulier": sHaulier1,
								"Address": sAddress1,
								"VatCode": sVatCode1
							};
							ContItems.push(oContractEntry1);
							var oContractEntry2 = {
								"Werks": vLoadPlant,
								"DocId": sHeaderData.DocId,
								"Haulier": sHaulier2,
								"Address": sAddress2,
								"VatCode": sVatCode2
							};
							ContItems.push(oContractEntry2);

							var oEntry = {};
							oEntry.HaulierDetailsNavig = ContItems;
							oEntry.Werks = vLoadPlant;
							oEntry.DocId = sHeaderData.DocId;
							oEntry.OrdType = sHeaderData.OrdType;
							var HaulierMod = that.getOwnerComponent().getModel("HaulierModCreate");
							HaulierMod.create("/HeaderSet", oEntry, {
								success: function(odata, response) {
									if (response.statusCode === "201") {
										var dataAvailable = that.getView().getModel("i18n").getProperty('contractorAvailableData');
										that.byId("contractorData").setText(dataAvailable);
										that.byId("dataCheck").setSelected(true);
										that.byId("contractorData").removeStyleClass("noHaulierData");
										that.byId("contractorData").addStyleClass("availableHaulierData");
										that._contractorDialog.close();
										var haulierInfo = that.getView().getModel("i18n").getProperty('success');
										var oMsg = that.getView().getModel("i18n").getProperty('haulierInfo');
										MessageBox.show(
											oMsg, {
												icon: sap.m.MessageBox.Icon.SUCCESS,
												title: haulierInfo //Success Message

											});

										oInsCreateDailog.close();
									}
								},
								error: function() {
									var noDataAvailable = that.getView().getModel("i18n").getProperty('noContractorData');
									that.byId("contractorData").setText(noDataAvailable);
									that.byId("dataCheck").setSelected(false);
									that.byId("contractorData").removeStyleClass("availableHaulierData");
									that.byId("contractorData").addStyleClass("noHaulierData");
									oInsCreateDailog.close();
									var submitError = that.getView().getModel("i18n").getProperty('submitError');
									var oMessage = that.getView().getModel("i18n").getProperty('submitError');
									MessageBox.show(
										oMessage, {
											icon: sap.m.MessageBox.Icon.ERROR,
											title: submitError //"Error during submitting!"
										});
								}
							});
						}
						oInsCreateDailog.close();
					}
				},
				error: function(oError) {
					oInsCreateDailog.close();
					var submitError = that.getView().getModel("i18n").getProperty('submitError');
					var oMessage = that.getView().getModel("i18n").getProperty('submitError');
					MessageBox.show(
						oMessage, {
							icon: sap.m.MessageBox.Icon.ERROR,
							title: submitError //"Error during submitting!"
						});
				}
			});

			createHaulierMod.attachRequestCompleted(function() {

			});
			createHaulierMod.attachRequestFailed(function() {

			});

		},

		onHaulier1Livechange: function() {
			sap.ui.getCore().byId("hauliername1").setValueState(sap.ui.core.ValueState.None);

			var alphaNumeric = sap.ui.getCore().byId("hauliername1").getValue();
			var regex = /^[a-zA-Z0-9 ]+$/;
			if (regex.test(alphaNumeric) === false) {
				var theStringMinusOne = alphaNumeric.substring(0, alphaNumeric.length - 1);
				sap.ui.getCore().byId("hauliername1").setValue(theStringMinusOne);
			}

		},

		onAddress1Livechange: function() {
			sap.ui.getCore().byId("address1").setValueState(sap.ui.core.ValueState.None);

			var alphaNumeric = sap.ui.getCore().byId("address1").getValue();
			var regex = /^[a-zA-Z0-9 ]+$/;
			if (regex.test(alphaNumeric) === false) {
				var theStringMinusOne = alphaNumeric.substring(0, alphaNumeric.length - 1);
				sap.ui.getCore().byId("address1").setValue(theStringMinusOne);
			}

		},

		onVatCode1Livechange: function() {
			sap.ui.getCore().byId("vatcode1").setValueState(sap.ui.core.ValueState.None);
			var alphaNumeric = sap.ui.getCore().byId("vatcode1").getValue();
			var regex = /^[a-zA-Z0-9]+$/;
			if (regex.test(alphaNumeric) === false) {
				var theStringMinusOne = alphaNumeric.substring(0, alphaNumeric.length - 1);
				sap.ui.getCore().byId("vatcode1").setValue(theStringMinusOne);
			}
		},

		onHaluier2LiveChange: function() {
			var alphaNumeric = sap.ui.getCore().byId("hauliername2").getValue();
			var regex = /^[a-zA-Z0-9 ]+$/;
			if (regex.test(alphaNumeric) === false) {
				var theStringMinusOne = alphaNumeric.substring(0, alphaNumeric.length - 1);
				sap.ui.getCore().byId("hauliername2").setValue(theStringMinusOne);
			}

		},
		onAddress2Livechange: function() {
			var alphaNumeric = sap.ui.getCore().byId("address2").getValue();
			var regex = /^[a-zA-Z0-9 ]+$/;
			if (regex.test(alphaNumeric) === false) {
				var theStringMinusOne = alphaNumeric.substring(0, alphaNumeric.length - 1);
				sap.ui.getCore().byId("address2").setValue(theStringMinusOne);
			}

		},
		onVatCode2Livechange: function() {
			var alphaNumeric = sap.ui.getCore().byId("vatcode2").getValue();
			var regex = /^[a-zA-Z0-9]+$/;
			if (regex.test(alphaNumeric) === false) {
				var theStringMinusOne = alphaNumeric.substring(0, alphaNumeric.length - 1);
				sap.ui.getCore().byId("vatcode2").setValue(theStringMinusOne);
			}
		},

		onContractClear1: function() {
			sap.ui.getCore().byId("hauliername1").setValue("");
			sap.ui.getCore().byId("hauliername1").setEnabled(true);
			sap.ui.getCore().byId("address1").setValue("");
			sap.ui.getCore().byId("address1").setEnabled(true);
			sap.ui.getCore().byId("vatcode1").setValue("");
			sap.ui.getCore().byId("vatcode1").setEnabled(true);
		},

		onContractClear2: function() {
			sap.ui.getCore().byId("hauliername2").setValue("");
			sap.ui.getCore().byId("address2").setValue("");
			sap.ui.getCore().byId("vatcode2").setValue("");
		},

		//----------For displaying Transport Name input field based on Company selection-------//
		onCompanyChange: function(oEvent) {
			/*	var sSizeFilter = this.byId("sizecompany").getSelectedKey();
			if ((sSizeFilter === "0000999999") || (sSizeFilter === "CUPU")) {
				this.getView().byId("transportname").setVisible(true);
				this.getView().byId("companyScacode").setVisible(true);
			} else {
				this.getView().byId("transportname").setVisible(false);
				this.getView().byId("companyScacode").setVisible(false);
			}*/
			var that = this;
			var streamName;
			// var OcomapnySelected = that.getView().byId("sizecompany").getSelectedKey();
			// if (OcomapnySelected === "") {
			// 	that.getView().byId("addDelivery").setVisible(false);
			// 	that.getView().byId("holierAcceptd").setVisible(false);
			// 	that.getView().byId("noHoliuerId").setVisible(false);
			// } else {
			// 	that.getView().byId("addDelivery").setVisible(true);
			// 	var HolierModel = that.getOwnerComponent().getModel("HolierModeldata");
			// 	if (HolierModel !== undefined) {
			// 		var oacceptCheck = HolierModel.getData();
			// 		if (oacceptCheck.length > 0) {
			// 			that.getView().byId("holierAcceptd").setVisible(true);
			// 			that.getView().byId("noHoliuerId").setVisible(false);
			// 		} else {
			// 			that.getView().byId("holierAcceptd").setVisible(false);
			// 			that.getView().byId("noHoliuerId").setVisible(true);
			// 		}
			// 	} else {
			// 		that.getView().byId("noHoliuerId").setVisible(true);
			// 	}
			// }
			var sSizeFilter = this.byId("sizecompany").getSelectedKey();
			if (sSizeFilter === "CUPU") {
				// if CUPU - delevery buttun and text will be not visible
				// that.getView().byId("addDelivery").setVisible(false);
				// that.getView().byId("holierAcceptd").setVisible(false);
				// that.getView().byId("noHoliuerId").setVisible(false);

				//**--transport request change- start***////
				var lableCustomerName = that.getOwnerComponent().getModel("i18n").getProperty("customerName");
				if (that.getView().byId("transportname") !== undefined) {
					that.getView().byId("transportname").setVisible(true);
					that.getView().byId("transportname").setText(lableCustomerName);
					this.CustomerFlag = "CN";
				}
				if (that.getView().byId("transportNameSelect") !== undefined) {
					that.getView().byId("transportNameSelect").setVisible(true);
					var customerNameInput = that.byId("transportNameSelect");
				}

				var sLiveBtnPress = jQuery.sap.storage(jQuery.sap.storage.Type.local).get("sLiveBtnPress");
				var sDandHBtnPress = jQuery.sap.storage(jQuery.sap.storage.Type.local).get("sDandHBtnPress");
				var sDelNum = jQuery.sap.storage(jQuery.sap.storage.Type.local).get("DeliveryNumber");
				if (sDelNum === "UA" && sDandHBtnPress === "X" || sDelNum === "UA" && sLiveBtnPress === "X") {
					if (that.getView().byId("transportNameSelect") !== undefined) {
						that.getView().byId("transportNameSelect").setValueHelpOnly(true);
					} else {
						if (that.getView().byId("transportNameSelect") !== undefined) {
							that.getView().byId("transportNameSelect").setValueHelpOnly(false);
						}
					}

				} else {
					if (that.getView().byId("transportNameSelect") !== undefined) {
						that.getView().byId("transportNameSelect").setValueHelpOnly(false);
					}

				}

				var sServiceUrl = "/sap/opu/odata/sap/ZGW_CHECKIN_SRV";
				var oModel = new sap.ui.model.odata.ODataModel(sServiceUrl);
				oModel.read("/CupuTrpsSet?$filter=Scacgrp eq '" + vLoadPlant + "' and Scac eq '" + "CUPU" + "' ", null, null, false,

					function(oData) {
						var valueHelpModel = new sap.ui.model.json.JSONModel();
						valueHelpModel.setData(oData);
						valueHelpModel.setSizeLimit(oData.results.length);
						that.getView().setModel(valueHelpModel, "customerValueHelpDlgModel");
						if (customerNameInput !== undefined) {
							customerNameInput.setFilterFunction(function(sTerm, oItem) {
								// A case-insensitive 'string contains' style filter
								return oItem.getText().match(new RegExp(sTerm, "i"));
							});
						}

					});
				//**-- transport request change-end***////
			} else if (sSizeFilter === "0000999999") {
				var lableTransportName = that.getOwnerComponent().getModel("i18n").getProperty("transportName");
				that.getView().byId("transportname").setText(lableTransportName);
				that.getView().byId("transportname").setVisible(true);
				that.getView().byId("companyScacode").setVisible(true);
			} else {
				that.getView().byId("transportname").setVisible(false);
				that.getView().byId("companyScacode").setVisible(false);
				that.getView().byId("transportNameSelect").setVisible(false);
			}

			/*Asset recovery changes based on Add delevery buttuon visibility*/

			var sServiceUrlDandH = "/sap/opu/odata/sap/ZGW_YARD_SETTINGS_SRV";
			var oModelDandH = new sap.ui.model.odata.ODataModel(sServiceUrlDandH);

			if (sRegion === "US") {
				streamName = "ZDH_SCAC" + "_" + vLoadPlant;
			} else {
				streamName = "ZDH_VEND" + "_" + vLoadPlant;
			}
			var AssetSelectedKey = oEvent.getSource().getSelectedKey();
			var sEmptyTrailerDH = jQuery.sap.storage(jQuery.sap.storage.Type.local).get("returnDrop");
			oModelDandH.read("DH_EXCEPTIONSSet?$filter=Streamname eq '" + streamName + "' and Scac_Flag eq '" + "AR" + "' ", null, null, false,
				function(oData) {
					for (var i = 0; i < oData.results.length; i++) {
						if (sRegion === "EU" || sRegion === "ZA" || sRegion === "LATAM") {
							var oParameterId = oData.results[i].Paramid;
							var parmetrID = "0000" + oParameterId;
							if (parmetrID === AssetSelectedKey) {
								that.getView().byId("addDelivery").setVisible(true);
								if (AssetSelectedKey !== "0000999999") {
									var HolierModel = that.getView().getModel("HolierModeldata");
									if (HolierModel !== undefined) {
										var oacceptCheck = HolierModel.getData();
										if (oacceptCheck.length > 0) {
											that.getView().byId("addDelivery").setVisible(true);
											that.getView().byId("holierAcceptd").setVisible(false);
											that.getView().byId("noHoliuerId").setVisible(false);
										} else {
											that.getView().byId("holierAcceptd").setVisible(false);
											that.getView().byId("noHoliuerId").setVisible(false);
										}
									} else {
										that.getView().byId("noHoliuerId").setVisible(true);
									}
									break;
								} else {
									that.getView().byId("addDelivery").setVisible(true);
									that.getView().byId("holierAcceptd").setVisible(false);
									that.getView().byId("noHoliuerId").setVisible(false);
								}

							} else {
								that.getView().byId("addDelivery").setVisible(false);
								that.getView().byId("noHoliuerId").setVisible(false);
								that.getView().byId("holierAcceptd").setVisible(false);

							}
						}
						/*If region US*/
						else if (sRegion === "US") {
							if (oData.results[i].Paramid === AssetSelectedKey) {
								if (sEmptyTrailerDH === "L" || sEmptyTrailerDH === "X") {
									that.getView().byId("addDelivery").setVisible(true);
									var HolierModelUS = that.getView().getModel("HolierModeldata");
									if (HolierModelUS !== undefined) {
										var oacceptCheckUS = HolierModelUS.getData();
										if (oacceptCheckUS.length > 0) {
											that.getView().byId("addDelivery").setVisible(true);
											that.getView().byId("holierAcceptd").setVisible(true);
											that.getView().byId("noHoliuerId").setVisible(false);
										} else {
											that.getView().byId("holierAcceptd").setVisible(false);
											that.getView().byId("noHoliuerId").setVisible(true);
										}
									} else {
										that.getView().byId("noHoliuerId").setVisible(true);
									}
									break;
								}
							} else {
								that.getView().byId("addDelivery").setVisible(false);
								that.getView().byId("noHoliuerId").setVisible(false);
								that.getView().byId("holierAcceptd").setVisible(false);

							}
						}
					}

				});
		},
		/************* value help for customer name when CUPU is selected for US region - start ******/
		customerValueHelpTrlrInfoView: function(oEvent) {
			var that = this;
			var sInputValue = oEvent.getSource().getValue();
			if (!that.custNameValueHelpDailog) {
				that.custNameValueHelpDailog = sap.ui.xmlfragment("chep.checkin.fragments.custNameValueHelpTrailerInfo", that);
				that.getView().addDependent(that.custNameValueHelpDailog);
			}
			var sServiceUrl = "/sap/opu/odata/sap/ZGW_CHECKIN_SRV";
			var oModel = new sap.ui.model.odata.ODataModel(sServiceUrl);
			oModel.read("/CupuTrpsSet?$filter=Scacgrp eq '" + vLoadPlant + "' and Scac eq '" + "CUPU" + "' ", null, null, false,

				function(oData) {
					var valueHelpModel = new sap.ui.model.json.JSONModel();
					var valueHelpModelDup = new sap.ui.model.json.JSONModel();
					valueHelpModel.setData(oData);
					valueHelpModelDup.setData(oData);
					valueHelpModel.setSizeLimit(oData.results.length);
					that.getView().setModel(valueHelpModel, "customerValueHelpDlgModel");
					// var sDataStore = JSON.parse(JSON.stringify(oData));
					that.getView().setModel(valueHelpModelDup, "customerValueHelpDlgModelDup");

				});

			// that._oSelectProdCodeDescDailog.open();

			// create a filter for the binding
			that.custNameValueHelpDailog.getBinding("items").filter([new Filter(
				"Name1",
				sap.ui.model.FilterOperator.Contains, sInputValue
			)]);

			// open value help dialog filtered by the input value
			that.custNameValueHelpDailog.open(sInputValue);

		},
		customerNameInputSearch: function(oEvent) {
			var sQuery = oEvent.getParameter("value");
			var oBinding = oEvent.getSource().getBinding("suggestionItems");
			if (sQuery) {
				var glidName = new sap.ui.model.Filter("Name1", sap.ui.model.FilterOperator.Contains, sQuery);
				var glidNumber = new sap.ui.model.Filter("Lifnr", sap.ui.model.FilterOperator.Contains, sQuery);
				var aFilters = new sap.ui.model.Filter([glidName, glidNumber]);
				oBinding.filter(aFilters);

			} else {
				oBinding.filter([]);

			}

		},
		handleSearchCustmrName: function(oEvent) {
			var that = this;
			var sQuery = oEvent.getParameter("value");
			if (sQuery === "") {
				var sDiglogModel = that.getView().getModel("customerValueHelpDlgModelDup").getData();
				var sRebindModel = new sap.ui.model.json.JSONModel(sDiglogModel);
				that.getView().setModel(sRebindModel, "customerValueHelpDlgModel");
				if (this.getView().byId("transportNameSelect") !== undefined) {
					var productInput1 = this.getView().byId("transportNameSelect");
					productInput1.setValue("");
				}
			}
			var oBinding = oEvent.getSource().getBinding("items");
			if (sQuery) {
				var glidName = new sap.ui.model.Filter("Name1", sap.ui.model.FilterOperator.Contains, sQuery);
				var glidNumber = new sap.ui.model.Filter("Lifnr", sap.ui.model.FilterOperator.Contains, sQuery);
				var aFilters = new sap.ui.model.Filter([glidName, glidNumber]);
				var sLiveBtnPress = jQuery.sap.storage(jQuery.sap.storage.Type.local).get("sLiveBtnPress");
				var sDandHBtnPress = jQuery.sap.storage(jQuery.sap.storage.Type.local).get("sDandHBtnPress");
				var sDelNum = jQuery.sap.storage(jQuery.sap.storage.Type.local).get("DeliveryNumber");
				var arrayOfObject = this.getView().getModel("customerValueHelpDlgModelDup").getData().results;
				if (sDelNum === "UA" && sDandHBtnPress === "X" || sDelNum === "UA" && sLiveBtnPress === "X") {
					// if (oBinding.getLength() === 0 || oBinding.getLength() === 1) {
					var sFilterAry = arrayOfObject.filter(function(obj) {
						return obj["Name1"].toLowerCase().includes(sQuery.toLowerCase()) || obj["Lifnr"].toLowerCase().includes(sQuery.toLowerCase());
					});
					if (sFilterAry.length === 0) {
						sFilterAry.push({
							"Lifnr": "999999999",
							"Name1": "Customer Name not Listed"
						});
					}
					this.getView().getModel("customerValueHelpDlgModel").setData({
						"results": sFilterAry
					});
					// var glidNameSearch = new sap.ui.model.Filter("Name1", sap.ui.model.FilterOperator.Contains, "Customer Name not listed");
					// var aFiltersDH = new sap.ui.model.Filter([glidNameSearch]);
					// oBinding.filter(aFiltersDH);
					// } 
					// else {
					// 	// oBinding.filter([]);
					// 	oBinding.filter(aFilters);
					// }
				} else {
					oBinding.filter(aFilters);
				}
			}
			// else {
			// 	oBinding.filter([]);
			// }
		},

		handleValueHelpConfirm: function(evt) {
			var oSelectedItem = evt.getParameter("selectedItem").getBindingContext("customerValueHelpDlgModel").getObject().Name1;
			this.oSelectedLifnr = evt.getParameter("selectedItem").getBindingContext("customerValueHelpDlgModel").getObject().Lifnr;
			if (oSelectedItem) {
				if (this.getView().byId("transportNameSelect") !== undefined) {
					var productInput = this.getView().byId("transportNameSelect");
					productInput.setValue(oSelectedItem);
				}

			}

			evt.getSource().getBinding("items").filter([]);
		},
		/************* value help for customer name when CUPU is selected for US region - end of code******/
		/*****************YMS Phase2 CUPU Service binding**********************/
		onTransportNameSelect: function() {
			var that = this;
			var sServiceUrl = "/sap/opu/odata/sap/ZGW_CHECKIN_SRV";
			var oModel = new sap.ui.model.odata.ODataModel(sServiceUrl);
			oModel.read("/CupuTrpsSet?$filter=Scacgrp eq '" + vLoadPlant + "' and Scac eq '" + "CUPU" + "' ", null, null, false,
				function(oData) {
					var sTransNameSelect = that.byId("transportNameSelect");
					var transportModel = new sap.ui.model.json.JSONModel(oData);
					transportModel.setSizeLimit(oData.results.length);
					that.getView().setModel(transportModel, "customerValueHelpDlgModel");
					if (sTransNameSelect !== undefined) {
						sTransNameSelect.setFilterFunction(function(sTerm, oItem) {
							// A case-insensitive 'string contains' style filter
							return oItem.getText().match(new RegExp(sTerm, "i"));
						});
					}
					// var oTemplate11 = new sap.ui.core.ListItem({
					// 	text: "{Name1}",
					// 	key: "{Scac}",
					// 	additionalText: "{Lifnr}" //"{Lifnr}"
					// });
					// sTransNameSelect.setModel(transportModel);
					// // sTransNameSelect.bindItems("/", oTemplate11);
					// sTransNameSelect.getModel().refresh();
				});

		},

		onTransNameSelChange: function(oEvent) {
			var that = this;
			// console.log(oEvent);
			var vLifnr = oEvent.getParameters().selectedItem.getAdditionalText();

			var lifnrObj = {};
			lifnrObj.Lifnr = vLifnr;
			var vLifnrModel = new sap.ui.model.json.JSONModel(lifnrObj);
			that.getView().setModel(vLifnrModel, "lifnrMod");
			// 	var that = this;
			// 	var oSelectedName = that.getView().byId("transportNameSelect").getSelectedItem().getText();
			// 	if (oSelectedName === "ADD NEW") {
			// 		if (!this.selDialog) {
			// 			this.selDialog = sap.ui.xmlfragment("chep.checkin.fragments.TransportNameSelect", this);
			// 			this.getView().addDependent(this.selDialog);
			// 		}
			// 		jQuery.sap.syncStyleClass("sapUiSizeCompact", this.getView(), this.selDialog);
			// 		this.selDialog.open();
			// 	}

		},
		addNewTransName: function() {
			var that = this;
			var sNewTransName = sap.ui.getCore().byId("newTransportName").getValue();
			if (sNewTransName === "") {
				var enterTransName = that.getView().getModel("i18n").getProperty('enterTransName');
				var submitError = that.getView().getModel("i18n").getProperty('submitError');

				MessageBox.show(
					enterTransName, {
						icon: MessageBox.Icon.ERROR,
						title: submitError //"Error during submitting!"
					});
			} else {
				jQuery.sap.storage(jQuery.sap.storage.Type.local).put("newTransportName", sNewTransName);

				sap.ui.getCore().byId("newTransportName").setValue("");
				// this.byId("transportNameSelect").setSelectedKey("");
				this.byId("transportNameSelect").setValue("");

				this.selDialog.close();
			}

		},
		cancelTransName: function() {

			this.selDialog.close();
			sap.ui.getCore().byId("newTransportName").setValue("");
			// this.byId("transportNameSelect").setSelectedKey("");
			this.byId("transportNameSelect").setValue("");
		},

		//---------For binding trailer size data to dropdown in trailerpanel-------------------//
		trailersize: function() {
			var that = this;
			// sRegion = jQuery.sap.storage(jQuery.sap.storage.Type.local).get("sRegion");
			var sService = "/sap/opu/odata/sap/ZGW_CHECKIN_SRV/";
			var oModel = new sap.ui.model.odata.ODataModel(sService);
			oModel.read("/TrailerSizeSet?$filter=Werks eq '" + vLoadPlant + "' and Spras eq '" + sLanguage + "' ", null, null, false,
				function(oData) {
					var vTrailerSize = new sap.ui.model.json.JSONModel(oData);
					var vSize = that.getView().byId("size");
					vTrailerSize.setSizeLimit(oData.results.length);
					vSize.setModel(vTrailerSize, "tSize");
				});

			if (sRegion === "US") {
				var url = "/sap/opu/odata/sap/ZGW_DELIVERY_AP_SRV";
				var oScacModel = new sap.ui.model.odata.ODataModel(url);
				oScacModel.read("/ScacSet?$filter=Werks eq '" + vLoadPlant + "' ", null, null,
					false,
					function(oData) {
						var vSize1 = that.getView().byId("sizecompany");
						var oScacJson = new sap.ui.model.json.JSONModel(oData.results);
						oScacJson.setSizeLimit(oData.results.length);
						//	vSize1.setModel(oScacJson, "tSize1");
						var oTemplate11 = new sap.ui.core.ListItem({
							text: "{Name1}",
							key: "{ScacCode}"
						});
						vSize1.setModel(oScacJson);
						vSize1.bindItems("/", oTemplate11);
						vSize1.getModel().refresh();
					});
			} else {
				var sService1 = "/sap/opu/odata/sap/ZGW_DELIVERY_AP_SRV/";
				var oModel1 = new sap.ui.model.odata.ODataModel(sService1);
				oModel1.read("/VendorsSet?$filter=Werks eq '" + vLoadPlant + "'", null, null, false,
					function(oData) {
						var vSize1 = that.getView().byId("sizecompany");
						var vTrailerSize1 = new sap.ui.model.json.JSONModel(oData.results);
						vTrailerSize1.setSizeLimit(oData.results.length);
						var oTemplate11 = new sap.ui.core.ListItem({
							text: "{Name1}",
							key: "{Lifnr}"
						});
						vSize1.setModel(vTrailerSize1);
						vSize1.bindItems("/", oTemplate11);
						vSize1.getModel().refresh();
						//	vSize1.setModel(vTrailerSize1, "tSize1");
					});
			}

			//	var sServicePhExt = "/sap/opu/odata/sap/ZGW_CHECKIN_SRV/";
			var oModel = new sap.ui.model.odata.ODataModel(sService);
			oModel.read("/PhoneExtSet?$filter=Werks eq '" + vLoadPlant + "'", null, null, false,
				function(oDataPhExt) {
					var countryCodeArray = [];
					var countryResults = oDataPhExt.results;
					for (var i = 0; i < countryResults.length; i++) {
						var countryEntry = {};
						countryEntry.PhExt = countryResults[i].PhExt;
						countryEntry.Country = countryResults[i].Country;
						countryEntry.extCountry = countryResults[i].PhExt + "\xa0\xa0\xa0\xa0\xa0" + "(" + countryResults[i].CountryName + ")";
						countryCodeArray.push(countryEntry);
					}
					var vPhoneExt = new sap.ui.model.json.JSONModel(countryCodeArray);
					var vCounrtyCodes = that.getView().byId("countryCode");
					if (countryResults.length > 1) {
						// countryCodeArray.unshift({}); Commented by Sharmila
						vPhoneExt.setSizeLimit(countryCodeArray.length);
						vCounrtyCodes.setModel(vPhoneExt, "phoneExts"); //Added by Sharmila
						vCounrtyCodes.setSelectedKey(countryCodeArray[0].PhExt); //Added by Sharmila
						//vCounrtyCodes.setSelectedText(countryCodeArray[0].extCountry);
					} else {
						vPhoneExt.setSizeLimit(countryCodeArray.length);
						vCounrtyCodes.setModel(vPhoneExt, "phoneExts");
					}

				});
		},
		onCountrycodeChange: function(selectedText) {
			//	var selectedText = oEvent.getSource().getSelectedItem().getText();
			return selectedText.split("(")[0].trim();
			//oEvent.getSource().getSelectedItem().setText(sTextGivesCode);
		},
		OnTrailerSizeSelect: function() {
			//	var that = this;
			//	var sSizeFilter = that.byId("size").get();
			//	that.getView().byId("trailertype").setValue(sSizeFilter);
			//	var vSize = that.getView().byId("size").getModel("tSize");
		},

		openDropHookFragment: function() {
			if (!this._DopandHookDialog) {
				this._DopandHookDialog = sap.ui.xmlfragment("chep.checkin.fragments.DropHook", this);
				this.getView().addDependent(this._DopandHookDialog);
			}
			jQuery.sap.syncStyleClass("sapUiSizeCompact", this.getView(), this._DopandHookDialog);
			this._DopandHookDialog.open();
		},

		//----Function for Opening th Drop and PickUp Dialog-----//
		openDropPickUpFragment: function() {
			if (!this._DropandPickDialog) {
				this._DropandPickDialog = sap.ui.xmlfragment("chep.checkin.fragments.DropPickup", this);
				this.getView().addDependent(this._DropandPickDialog);
			}
			jQuery.sap.syncStyleClass("sapUiSizeCompact", this.getView(), this._DropandPickDialog);
			this._DropandPickDialog.open();
			this.getOwnerComponent().getModel("UAunknwnModel").setProperty("/onUacontinueBtn", false);
		},
		onCheckCovid: function() {
			if (!this.prvNotice) {
				this.prvNotice = sap.ui.xmlfragment("chep.checkin.fragments.privacyNotice", this);
				this.getView().addDependent(this.prvNotice);
			}
			this.prvNotice.open();
		},
		onAcceptPrivacyNote: function() {
			var that = this;
			this.prvNotice.close();
			if (!this.covidQtnsDialog) {
				this.covidQtnsDialog = sap.ui.xmlfragment("chep.checkin.fragments.covidQuestions", this);
				this.getView().addDependent(this.covidQtnsDialog);
			}
			var covidQuestions = {
				qtns: [{
					question: that.getView().getModel("i18n").getProperty("covidQtn1"),
					Answer: "X"
				}, {
					question: that.getView().getModel("i18n").getProperty("covidQtn2"),
					Answer: "X"
				}, {
					question: that.getView().getModel("i18n").getProperty("covidQtn3"),
					Answer: "X"
				}, {
					question: that.getView().getModel("i18n").getProperty("covidQtn4"),
					Answer: ""
				}]
			};
			var covidModel = {
				dialogTitle: that.getView().getModel("i18n").getProperty("checkList"),
				covidQtnsTableVisibility: true,
				ppePanelVisibility: false
			};

			var ppeText = {
				ppe: "<ul><li>" + that.getView().getModel("i18n").getProperty("ppeInfo1") + "</li><br/>" +
					"<li>" + that.getView().getModel("i18n").getProperty("ppeInfo2") + "</li><br/>" +
					"<li>" + that.getView().getModel("i18n").getProperty("ppeInfo3") + "</li><br/>" +
					"<li>" + that.getView().getModel("i18n").getProperty("ppeInfo4") + "<br/>" +
					"<ul><li>" + that.getView().getModel("i18n").getProperty("ppeInfo41") + "</li><br/>" +
					"<li>" + that.getView().getModel("i18n").getProperty("ppeInfo42") + "</li><br/>" +
					"<li>" + that.getView().getModel("i18n").getProperty("ppeInfo43") + "</li><br/>" +
					"<li>" + that.getView().getModel("i18n").getProperty("ppeInfo44") + "</li><br/>" +
					"<li>" + that.getView().getModel("i18n").getProperty("ppeInfo45") + "</li></ul></li>"
			};

			var covidQtnsModelData = new sap.ui.model.json.JSONModel();
			covidQtnsModelData.setData(covidQuestions.qtns);
			this.getView().setModel(covidQtnsModelData, "covidQtnsModel");

			var ppeModelData = new sap.ui.model.json.JSONModel(ppeText);
			this.getView().setModel(ppeModelData, "ppeModel");

			var covidModelData = new sap.ui.model.json.JSONModel(covidModel);
			this.getView().setModel(covidModelData, "covidModel");
			this.covidQtnsDialog.open();
		},
		onDeclinePrivacyNote: function() {
			var that = this;
			MessageBox.warning(this.getView().getModel("i18n").getProperty("confirmDecline"), {
				actions: [that.getView().getModel("i18n").getProperty("Confirm"), that.getView().getModel("i18n").getProperty(
					"DeclinePrivacyNote")],
				title: that.getView().getModel("i18n").getProperty("confirmation"),
				emphasizedAction: "Confirm",
				onClose: function(sAction) {
					if (sAction === that.getView().getModel("i18n").getProperty("Confirm")) {
						covidDeclineFlag = "D";
						that.prvNotice.close();
						that.CheckinSummaryconfirm();
					}
				}
			});
		},
		onToggle: function(oEvent) {
			if (oEvent.getSource().getState() === true) {
				this.getView().getModel("covidQtnsModel").getData()[parseInt(oEvent.getSource().getParent().getBindingContextPath().split(
					"/")[1])].Answer = "X";
			} else {
				this.getView().getModel("covidQtnsModel").getData()[parseInt(oEvent.getSource().getParent().getBindingContextPath().split(
					"/")[1])].Answer = "";
			}
		},
		qContinue: function() {
			var mandatoryQtn = this.getView().getModel("covidQtnsModel").getData()[3].Answer;
			var covidQtn1 = this.getView().getModel("covidQtnsModel").getData()[0].Answer;
			var covidQtn2 = this.getView().getModel("covidQtnsModel").getData()[1].Answer;
			var covidQtn3 = this.getView().getModel("covidQtnsModel").getData()[2].Answer;
			if (mandatoryQtn === "" && ppeFlag !== "X") {
				ppeFlag = "X";
				this.getView().getModel("covidModel").setProperty("/ppePanelVisibility", true);
				this.getView().getModel("covidModel").setProperty("/covidQtnsTableVisibility", false);
				this.getView().getModel("covidModel").setProperty("/dialogTitle", this.getView().getModel("i18n").getProperty("ppeInformation"));
			} else {
				if (mandatoryQtn !== "X") {
					ppeFlag = "";
					this.getView().getModel("covidQtnsModel").setProperty("/3/Answer", "X");
					this.getView().getModel("covidQtnsModel").updateBindings(true);
					this.getView().getModel("covidModel").setProperty("/ppePanelVisibility", false);
					this.getView().getModel("covidModel").setProperty("/covidQtnsTableVisibility", true);
					this.getView().getModel("covidModel").setProperty("/dialogTitle", this.getView().getModel("i18n").getProperty("checkList"));
				} else {
					this.covidQtnsDialog.close();
					if (covidQtn1 === "X" || covidQtn2 === "X" || covidQtn3 === "X") {
						covidPositiveFlag = "C";
					} else {
						covidPositiveFlag = "";
					}
					ppeFlag = "";
					this.CheckinSummaryconfirm();
				}
			}
		},
		qtnsDialogClose: function() {
			ppeFlag = "";
			this.getView().getModel("covidModel").setProperty("/ppePanelVisibility", false);
			this.getView().getModel("covidModel").setProperty("/covidQtnsTableVisibility", true);
			this.getView().getModel("covidModel").setProperty("/dialogTitle", this.getView().getModel("i18n").getProperty("checkList"));
			this.covidQtnsDialog.close();
		},
		//--------------Validations and Submit button functionality------------//
		onTrailerSubmit: function() {
			var that = this;
			/*  Added vehilcle regidtarion and trailer id validation for EU region */
			var vTrailerIDregion = jQuery.sap.storage(jQuery.sap.storage.Type.local).get("vCHtrilerid");
			var vHaulierNameregion = jQuery.sap.storage(jQuery.sap.storage.Type.local).get("vHaulierName");

			var trailerid = this.byId("Trailer_Id").getValue().trim();
			jQuery.sap.storage(jQuery.sap.storage.Type.local).put("TrailerId", trailerid);
			// var KioskId = jQuery.sap.storage(jQuery.sap.storage.Type.local).get("KioskId");
			var KioskId = "XXXXXXXXXX";
			// var vDropservice = jQuery.sap.storage(jQuery.sap.storage.Type.local).get("vDropservice");
			// var sOrderType = jQuery.sap.storage(jQuery.sap.storage.Type.local).get("OrderType");
			docId = jQuery.sap.storage(jQuery.sap.storage.Type.local).get("DeliveryNumber");
			var aregid = this.byId("reg_Id").getValue();
			var driverName = this.byId("driver_Name").getValue();
			var sCtryCode = this.byId("countryCode").getSelectedKey();
			var cell = this.byId("Mobile_Num").getValue();
			var trailerId = this.byId("Trailer_Id").getValue();

			/*CTRM-760   -- Trailer+Number --*/
			// if(sRegion === "EU"){
			//  if (vTrailerIDregion !== true && trailerId === ""){
			//  	 trailerId = this.byId("reg_Id").getValue();
			//  }
			// }
			var trailerSizeKey = this.byId("size").getSelectedKey();
			if (trailerSizeKey !== "") {
				var trailerSize = this.byId("size").getSelectedItem().getText();
			}
			var carrier = this.byId("sizecompany").getSelectedKey();
			if (this.byId("companyScacode").getVisible() === true) {
				var carrierName = this.byId("companyScacode").getValue();
			}
			if (this.byId("transportNameSelect").getVisible() === true) {
				var sTransportName = this.byId("transportNameSelect").getValue();
			}

			var customerFlag = this.CustomerFlag;

			sDelnum = jQuery.sap.storage(jQuery.sap.storage.Type.local).get("DeliveryNumber");
			var contractorCheck = that.byId("dataCheck").getSelected();
			var submitError = that.getView().getModel("i18n").getProperty('submitError');
			var glidModelCheck = that.getView().getModel("NewrowModel");
			var oGlidData = glidModelCheck.getData();
			UAbuttonVisible = that.getView().byId("addDelivery").getVisible();
			var sSizeFilter = that.byId("sizecompany").getSelectedKey(); // EU and ZA validation removed

			var sAddRemitoDtlsBtnVis = that.getView().getModel("oPlantModel").getProperty("/sNotaBtnVis");
			var remitoDataCheck = that.getView().getModel("oPlantModel").getProperty("/remitoDetailsState");

			if (((KioskId === "") || (KioskId === null)) && (sRegion !== "US")) {
				jQuery.sap.storage(jQuery.sap.storage.Type.local).put("issueDrop", "");
				jQuery.sap.storage(jQuery.sap.storage.Type.local).put("returnDrop", "");
				var sKioskID = that.getView().getModel("i18n").getProperty('kioskMessage');
				var oMessage = sKioskID;
				MessageBox.show(
					oMessage, {
						icon: MessageBox.Icon.ERROR,
						title: submitError //"Error during submitting!"
					});
			} else if ((aregid === "") && ((sRegion !== "US") && (sRegion !== "CA"))) {
				var enterRegNum = that.getView().getModel("i18n").getProperty('enterRegNum');
				var oMessage = enterRegNum; //"Please Enter Registration Number";
				MessageBox.show(
					oMessage, {
						icon: MessageBox.Icon.ERROR,
						title: submitError //"Error during submitting!"
					});
			} else if (driverName === "") {
				var enterdriverName = that.getView().getModel("i18n").getProperty('enterdriverName');
				var Message = enterdriverName; //"Please Enter Driver Name";
				MessageBox.show(
					Message, {
						icon: MessageBox.Icon.ERROR,
						title: submitError //"Error during submitting!"
					});
			} else if (carrier === "") {
				var selectCompanyName = that.getView().getModel("i18n").getProperty('selectCompanyName');
				var msg = selectCompanyName; //"Please Select Company Name";
				MessageBox.show(
					msg, {
						icon: MessageBox.Icon.ERROR,
						title: submitError //"Error during submitting!"
					});
			} else if (carrierName === "") {
				var enterTransName = that.getView().getModel("i18n").getProperty('enterTransportName');
				var omsg = enterTransName; //"Please Select Trailer Type";
				MessageBox.show(
					omsg, {
						icon: MessageBox.Icon.ERROR,
						title: submitError //"Error during submitting!"
					});
			} else if (sTransportName === "") {
				if (customerFlag === "CN") {
					var selectTransName1 = that.getView().getModel("i18n").getProperty('selectCustName'); //"Please Select CustomerName";
					MessageBox.show(
						selectTransName1, {
							icon: MessageBox.Icon.ERROR,
							title: submitError //"Error during submitting!"
						});
				} else {
					var selectTransName = that.getView().getModel("i18n").getProperty('selectTransportName'); //"Please Select TransportName";

					MessageBox.show(
						selectTransName, {
							icon: MessageBox.Icon.ERROR,
							title: submitError //"Error during submitting!"
						});
				}
			} else if (sCtryCode === "") {
				var selectCntryCode = that.getView().getModel("i18n").getProperty('selectCntryCode');
				var oMsg = selectCntryCode; //"Please Select Country Code";
				MessageBox.show(
					oMsg, {
						icon: MessageBox.Icon.ERROR,
						title: submitError //"Error during submitting!"
					});

			} else if (cell === "") {
				var enterMobileNum = that.getView().getModel("i18n").getProperty('enterMobileNum');
				var omsg = enterMobileNum; //"Please Enter Mobile Number";
				MessageBox.show(
					omsg, {
						icon: MessageBox.Icon.ERROR,
						title: submitError //"Error during submitting!"
					});
			}
			// else if ((cell.length < 9) && (sCtryCode !== "LT")) {
			// 	var enterValidMobileNum = that.getView().getModel("i18n").getProperty('enterValidMobileNum');
			// 	var omsg = enterValidMobileNum; //"Please Enter Valid Mobile Number";
			// 	MessageBox.show(
			// 		omsg, {
			// 			icon: MessageBox.Icon.ERROR,
			// 			title: submitError //"Error during submitting!"
			// 		});
			// } 
			else if ((cell.length < 8) && (sCtryCode === "LT" || sCtryCode === "GT" || sCtryCode === "CR")) {
				var enterValidLTNum = that.getView().getModel("i18n").getProperty('enterValidMobileNum');
				MessageBox.show(
					enterValidLTNum, {
						icon: MessageBox.Icon.ERROR,
						title: submitError //"Error during submitting!"
					});
			} else if ((cell.length > 8) && (sCtryCode === "LT" || sCtryCode === "GT" || sCtryCode === "CR")) {
				var enterValidLTNum1 = that.getView().getModel("i18n").getProperty('enterValidMobileNum');
				MessageBox.show(
					enterValidLTNum1, {
						icon: MessageBox.Icon.ERROR,
						title: submitError //"Error during submitting!"
					});
			} else if ((cell.length < 10) && (sCtryCode === "MX")) {
				var enterValidNumMX = that.getView().getModel("i18n").getProperty('enterValidMobileNum');
				MessageBox.show(
					enterValidNumMX, {
						icon: MessageBox.Icon.ERROR,
						title: submitError //"Error during submitting!"
					});
			} else if ((trailerId === "") && (sObjectId !== "B") && sRegion !== "EU") {

				var enterTrailerId = that.getView().getModel("i18n").getProperty('enterTrailerId');
				var msg1 = enterTrailerId; //"Please Enter Trailer Id";
				MessageBox.show(
					msg1, {
						icon: MessageBox.Icon.ERROR,
						title: submitError //"Error during submitting!"
					});

			} else if ((trailerSizeKey === "") && (sObjectId !== "B")) {
				var selectTrailerType = that.getView().getModel("i18n").getProperty('selectTrailerType');
				var omsg = selectTrailerType; //"Please Select Trailer Type";
				MessageBox.show(
					omsg, {
						icon: MessageBox.Icon.ERROR,
						title: submitError //"Error during submitting!"
					});
			} else if ((sHaulierFlag === "true") && ((sObjectId !== "P") && (sObjectId !== "U")) && (contractorCheck === false)) {
				var addSubcontractors = that.getView().getModel("i18n").getProperty('contractorSubmit');
				var oMessage = addSubcontractors; //"Please Enter Order Number";
				MessageBox.show(
					oMessage, {
						icon: sap.m.MessageBox.Icon.ERROR,
						title: submitError //"Error during submitting!"
					});

			} else if ((sRegion !== "EU" && sRegion !== "ZA" && sRegion !== "LATAM" && ((UAbuttonVisible === true && oGlidData.length > 0) && (
				oGlidData[0].Lifnr === "" && oGlidData[0].quantity === ""))) && (sSizeFilter !== "0000999999")) {
				var adddeleveryAction = that.getView().getModel("i18n").getProperty('DeleveryDetailsValidation');
				var oMessageDeleveryUA = adddeleveryAction; //"Please Enter GLID Details";
				MessageBox.show(
					oMessageDeleveryUA, {
						icon: sap.m.MessageBox.Icon.ERROR,
						title: submitError //"Error during submitting!"
					});

			} else if ((sAddRemitoDtlsBtnVis === "true" || sAddRemitoDtlsBtnVis === true) && remitoDataCheck === "Error") {
				var sAddRemitoDetails = that.getView().getModel("i18n").getProperty('enterRemitoDetails');
				MessageBox.show(
					sAddRemitoDetails, {
						icon: sap.m.MessageBox.Icon.ERROR,
						title: submitError //"Error during submitting!"
					});

			}

			/*	else if (sCntry !== "" && cell !== "") {
				var sMobileNo = sCntry + cell;
				var SID = "AC15d2113327f157079fa9986bd7e35d35";
				var Key = "1473d3e0a199d6e5386fb25369de4c82";
				$.ajax({
					type: "GET",
					crossDomain: true,
					url: "https://lookups.twilio.com/v1/PhoneNumbers/" + sMobileNo + "?Type=carrier",
					headers: {
						'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8'
					},
					beforeSend: function(xhr) {
						xhr.setRequestHeader("Authorization", "Basic " + btoa(SID + ":" + Key));
					},
					async: true,
					data: {}
				}).done(function(results) {
					//	console.log(results);
				}).error(function(data) {
					var sValidMobileNum = that.getView().getModel("i18n").getProperty('enterValidMobileNum');
					var omsg = sValidMobileNum; //"Please Enter Valid Mobile Number";
					MessageBox.show(
						omsg, {
							icon: MessageBox.Icon.ERROR,
							title: submitError //"Error during submitting!"
						});
				});
			} */
			else {

				// var sReturnDrop = jQuery.sap.storage(jQuery.sap.storage.Type.local).get("returnDrop");
				// if ((vAction === "U") && (sReturnDrop !== "")) {
				// 	if ((vAction === "U") && (sReturnDrop === "X")) {
				// 		that.fnOnSubmit();
				// 	} else {
				// 		if (!this._trailerfacilityDialog) {
				// 			this._trailerfacilityDialog = sap.ui.xmlfragment("chep.checkin.fragments.FacilityTrailer", this);
				// 			this.getView().addDependent(this._trailerfacilityDialog);
				// 		}
				// 		// toggle compact style
				// 		jQuery.sap.syncStyleClass("sapUiSizeCompact", this.getView(), this._trailerfacilityDialog);
				// 		this._trailerfacilityDialog.open();
				// 	}
				// } else if ((vAction === "U") && (sReturnDrop === "L")) {
				// 	that.fnOnSubmit();
				// } else if ((vDropservice === "true") && ((sOrderType === "Collect") || ((sOrderType === "Raw Materials")) || (sOrderType ===
				// 		"STO Receipt"))) {
				// 	jQuery.sap.storage(jQuery.sap.storage.Type.local).put("issueDrop", "");
				// 	// that.openDropHookFragment();
				// 	dropNpickFlag = jQuery.sap.storage(jQuery.sap.storage.Type.local).get("dropNpickup");
				// 	if (dropNpickFlag === "X") {
				// 		that.onYesPress();
				// 	} else {
				// 		that.openDropPickUpFragment();
				// 	}
				// } else {
				// 	that.fnOnSubmit();
				// }
				/*Code Added by Arun*/
				jQuery.sap.syncStyleClass("sapUiSizeCompact", this.getView(), this.prvNotice);

				// var covidFlag = that.getOwnerComponent().getModel("flagsModel").getProperty("/covidFlag");
				// if (covidFlag === true || covidFlag === "true") {
				// 	this.onCheckCovid();
				// } else {
				/**********************Trailer ID Validations *******************************/
				//----------Change Format of Trailer Number field in Truck Driver Screen to a free field for all Brazil plants-------//
				/*	if (sRegion === "LATAM" && sPrflow === "01") {
					if ((trailerid.match(/([A-Za-z0-9]-[A-Za-z]{3})$/g)) || (trailerid.match(/([A-Za-z0-9]-[A-Za-z]{2})$/g))) {
						that.onSubmitWithValidations();
					} else {
						var entertID = that.getView().getModel("i18n").getProperty('entervalidTrailerID');
						var Message = entertID; //"Please Enter A Valid Trailer ID Number";
						MessageBox.show(
							Message, {
								icon: MessageBox.Icon.ERROR,
								title: submitError //"Error during submitting!"
							});
					}
				} else {*/
				that.onSubmitWithValidations();
				// }
				//----------Change Format of Trailer Number field in Truck Driver Screen to a free field for all Brazil plants-------//
				// that.onSubmitWithValidations();
				// }
			}
		},
		onValidateMobile: function() {
			var that = this;
			var oView = that.getView();
			/*	var sObjData = that.getView().getModel("oModelTraSummary").getData();*/
			if (that.byId("countryCode") !== undefined) {
				var sCtryText = that.onCountrycodeChange(that.byId("countryCode").getSelectedItem().getText());
			}
			if (that.byId("Mobile_Num").getValue() !== undefined) {
				var cell = that.byId("Mobile_Num").getValue();
				var MobileCellVal = sCtryText + cell;
			}

			that.fnCreateBusyDialog("pallet.svg");
			that.getOwnerComponent().getModel("UtilitiesModel").read("/mobile_validSet('" + MobileCellVal + "')", {
				success: function(oData) {
					/*Handle if Error or Sucess*/
					if (oData.Status === "E") {
						sMblNumValidationFlag = "E";
						oView.getModel("oModelTraSummary").setProperty("/validPhoneFlagVis", true);
						oView.getModel("oModelTraSummary").updateBindings();
					} else {
						sMblNumValidationFlag = "";
						oView.getModel("oModelTraSummary").setProperty("/validPhoneFlagVis", false);
						oView.getModel("oModelTraSummary").updateBindings();
					}
					oInsCreateDailog.close();
				},
				error: function(oError) {
					oInsCreateDailog.close();
				}
			});
		},

		//Begin of changes by Sharmila
		_trailerSummary: function() {
			var that = this;
			var trailerSummary = {};
			if (sRegion === "US" && (trailerLive !== "X")) {
				var returnDrop = jQuery.sap.storage(jQuery.sap.storage.Type.local).get("returnDrop");
				var sIssueDrop = jQuery.sap.storage(jQuery.sap.storage.Type.local).get("issueDrop");
				var oModelCheck = that.getOwnerComponent().getModel("createMod");
				oModelCheck.setHeaders({
					"X-Requested-With": "XMLHttpRequest",
					"Content-Type": "application/atom+xml",
					"slug": "image.jpg",
					"DataServiceVersion": "2.0",
					"X-CSRF-Token": "Fetch"
				});
				var trailerid = this.byId("Trailer_Id").getValue().trim();
				trailerid = trailerid.replace(/ /g, "%20");
				trailerid = trailerid.replace(/#/g, "%23");

				var carrier = this.byId("sizecompany").getSelectedKey();
				if (this.oSelectedLifnr === undefined) {
					this.oSelectedLifnr = "";
				}
				oModelCheck.read("/Locations_ValidationSet(Werks='" + vLoadPlant + "',TrailerId='" + trailerid + "',Scac_Id='" + carrier +
					"',Customer_id='" + this.oSelectedLifnr + "',Action='" + vAction + "',Ret_drop='" + returnDrop + "',Iss_drop='" + sIssueDrop +
					"')", {
						success: function(oData, oResponse) {
							if ((oResponse.statusCode === 200) || (oResponse.statusCode === "200")) {
								if (that.byId("reg_Id") !== undefined) {
									trailerSummary.reg_Id = that.byId("reg_Id").getValue();
									if (trailerSummary.reg_Id === "") {
										trailerSummary.reg_IdVisible = false;
									}

								} else {
									trailerSummary.reg_IdVisible = false;
								}
								if (that.byId("driver_Name") !== undefined) {
									trailerSummary.driver_Name = that.byId("driver_Name").getValue();
								}
								if (that.byId("countryCode") !== undefined && that.byId("Mobile_Num") !== undefined) {
									trailerSummary.countryCode = that.onCountrycodeChange(that.byId("countryCode").getSelectedItem().getProperty("text")) +
										"\xa0\xa0" +
										that.byId("Mobile_Num").getValue();
									trailerSummary.validPhoneFlagVis = false;
								}

								/*Arun Changes for Mobile*/

								if (that.byId("Trailer_Id") !== undefined) {
									trailerSummary.Trailer_Id = that.byId("Trailer_Id").getValue();
									if (trailerSummary.Trailer_Id === "") {
										trailerSummary.Trailer_IdVisible = false;
									}
								} else {
									trailerSummary.Trailer_IdVisible = false;
								}

								if (that.byId("size").getSelectedKey() !== "") {
									trailerSummary.size = that.byId("size").getSelectedItem().getText();
								} else {
									trailerSummary.sizeVisible = false;
								}
								if (that.byId("sizecompany").getSelectedKey() !== "") {
									trailerSummary.sizecompany = that.byId("sizecompany").getSelectedItem().getText();
								} else {
									trailerSummary.sizecompanyVisible = false;
								}
								if (that.byId("companyScacode") !== undefined) {
									if (that.byId("companyScacode").getVisible() === true) {
										trailerSummary.carrierName = that.byId("companyScacode").getValue();
									} else {
										trailerSummary.carrierNameVisible = false;
									}
								} else {
									trailerSummary.carrierNameVisible = false;
								}
								if (that.byId("transportNameSelect") !== undefined) {
									if (that.byId("transportNameSelect").getVisible() === true) {
										trailerSummary.transportNameSelect = that.byId("transportNameSelect").getValue();
									} else {
										trailerSummary.transportNameVisible = false;
									}
								} else {
									trailerSummary.transportNameVisible = false;
								}

								/*	trailerSummary.driver_Name = this.byId("driver_Name").getValue();
								trailerSummary.countryCode = this.onCountrycodeChange(this.byId("countryCode").getSelectedItem().getProperty("text"));
								trailerSummary.Mobile_Num = this.byId("Mobile_Num").getValue();
								trailerSummary.Trailer_Id = this.byId("Trailer_Id").getValue();

								trailerSummary.transportNameSelect = this.byId("companyScacode").getValue();
								if (trailerSummary.transportNameSelect === undefined || trailerSummary.transportNameSelect === "") {
									trailerSummary.transportNameVisible = false;
								}
								trailerSummary.sizecompany = this.getView().byId("sizecompany").getProperty("value");
								if (trailerSummary.sizecompany === undefined || trailerSummary.sizecompany === "") {
									trailerSummary.sizecompanyVisible = false;
								}
								trailerSummary.size = this.byId("size").getSelectedItem().getText();
								// this.byId("size").getSelectedKey()
								if (trailerSummary.size === undefined || trailerSummary.size === "") {
									trailerSummary.sizeVisible = false;
								}*/

								var oModelTraSummary = new sap.ui.model.json.JSONModel();
								oModelTraSummary.setData(trailerSummary);
								that.getView().setModel(
									oModelTraSummary, "oModelTraSummary");

								if (!that._CheckinSummaryDialog) {
									that._CheckinSummaryDialog = sap.ui.xmlfragment("chep.checkin.fragments.CheckinSummary", that);
									that.getView().addDependent(that._CheckinSummaryDialog);
								}
								jQuery.sap.syncStyleClass("sapUiSizeCompact", that.getView(), that._CheckinSummaryDialog);
								that._CheckinSummaryDialog.open();

								var sForMobValid = jQuery.sap.storage(jQuery.sap.storage.Type.local).get("sForMobValid");
								if (sForMobValid === null || sForMobValid === undefined) {
									sForMobValid = false;
								}
								if (sForMobValid === true || sForMobValid === "true") {
									that.onValidateMobile();
								}
							}
						},
						error: function() {
							oInsCreateDailog.close();
							var dupTrailerNumerr = that.getView().getModel("i18n").getProperty('dupTrailerNumbCheck');
							var Trerror = that.getView().getModel("i18n").getProperty('InvalidErrorMsg');
							MessageBox.show(
								dupTrailerNumerr, {
									icon: MessageBox.Icon.ERROR,
									title: Trerror //"Error during submitting!"
								});

							if (that.byId("trailersubmit") !== undefined) {
								that.byId("trailersubmit").setVisible(true);
							}
						}
					});
			} else {
				if (that.byId("reg_Id") !== undefined) {
					trailerSummary.reg_Id = that.byId("reg_Id").getValue();
					if (trailerSummary.reg_Id === "") {
						trailerSummary.reg_IdVisible = false;
					}

				} else {
					trailerSummary.reg_IdVisible = false;
				}
				if (that.byId("driver_Name") !== undefined) {
					trailerSummary.driver_Name = that.byId("driver_Name").getValue();
				}
				if (this.byId("countryCode") !== undefined && that.byId("Mobile_Num") !== undefined) {
					trailerSummary.countryCode = that.onCountrycodeChange(that.byId("countryCode").getSelectedItem().getProperty("text")) +
						"\xa0\xa0" +
						that.byId("Mobile_Num").getValue();
					trailerSummary.validPhoneFlagVis = false;
				}

				/*Arun Changes for Mobile*/

				if (that.byId("Trailer_Id") !== undefined) {
					trailerSummary.Trailer_Id = that.byId("Trailer_Id").getValue();
					if (trailerSummary.Trailer_Id === "") {
						trailerSummary.Trailer_IdVisible = false;
					}
				} else {
					trailerSummary.Trailer_IdVisible = false;
				}

				if (that.byId("size").getSelectedKey() !== "") {
					trailerSummary.size = that.byId("size").getSelectedItem().getText();
				} else {
					trailerSummary.sizeVisible = false;
				}
				if (that.byId("sizecompany").getSelectedKey() !== "") {
					trailerSummary.sizecompany = that.byId("sizecompany").getSelectedItem().getText();
				} else {
					trailerSummary.sizecompanyVisible = false;
				}
				if (that.byId("companyScacode") !== undefined) {
					if (that.byId("companyScacode").getVisible() === true) {
						trailerSummary.carrierName = that.byId("companyScacode").getValue();
					} else {
						trailerSummary.carrierNameVisible = false;
					}
				} else {
					trailerSummary.carrierNameVisible = false;
				}
				if (that.byId("transportNameSelect") !== undefined) {
					if (that.byId("transportNameSelect").getVisible() === true) {
						trailerSummary.transportNameSelect = that.byId("transportNameSelect").getValue();
					} else {
						trailerSummary.transportNameVisible = false;
					}
				} else {
					trailerSummary.transportNameVisible = false;
				}

				/*	trailerSummary.driver_Name = this.byId("driver_Name").getValue();
				trailerSummary.countryCode = this.onCountrycodeChange(this.byId("countryCode").getSelectedItem().getProperty("text"));
				trailerSummary.Mobile_Num = this.byId("Mobile_Num").getValue();
				trailerSummary.Trailer_Id = this.byId("Trailer_Id").getValue();

				trailerSummary.transportNameSelect = this.byId("companyScacode").getValue();
				if (trailerSummary.transportNameSelect === undefined || trailerSummary.transportNameSelect === "") {
					trailerSummary.transportNameVisible = false;
				}
				trailerSummary.sizecompany = this.getView().byId("sizecompany").getProperty("value");
				if (trailerSummary.sizecompany === undefined || trailerSummary.sizecompany === "") {
					trailerSummary.sizecompanyVisible = false;
				}
				trailerSummary.size = this.byId("size").getSelectedItem().getText();
				// this.byId("size").getSelectedKey()
				if (trailerSummary.size === undefined || trailerSummary.size === "") {
					trailerSummary.sizeVisible = false;
				}*/

				var oModelTraSummary = new sap.ui.model.json.JSONModel();
				oModelTraSummary.setData(trailerSummary);
				that.getView().setModel(
					oModelTraSummary, "oModelTraSummary");

				if (!that._CheckinSummaryDialog) {
					that._CheckinSummaryDialog = sap.ui.xmlfragment("chep.checkin.fragments.CheckinSummary", that);
					that.getView().addDependent(that._CheckinSummaryDialog);
				}
				jQuery.sap.syncStyleClass("sapUiSizeCompact", that.getView(), that._CheckinSummaryDialog);
				that._CheckinSummaryDialog.open();

				var sForMobValid = jQuery.sap.storage(jQuery.sap.storage.Type.local).get("sForMobValid");
				if (sForMobValid === null || sForMobValid === undefined) {
					sForMobValid = false;
				}
				if (sForMobValid === true || sForMobValid === "true") {
					that.onValidateMobile();
				}
			}
		},
		CheckinSummaryDialogClose: function() {
			var that = this;
			/*Enable Submit button on press Submit*/
			if (sObjectId !== "P") {
				if (that.byId("trailersubmit") !== undefined) {
					that.byId("trailersubmit").setVisible(true);
				}
			} else {
				if (that.byId("trailerpass") !== undefined) {
					that.byId("trailerpass").setVisible(true);
				}
			}
			that._CheckinSummaryDialog.close();
			oInsCreateDailog.close();
		},
		//End of changes by Sharmila

		onSubmitWithValidations: function() {
			var that = this;
			// console.log(oData);
			var vDropservice = jQuery.sap.storage(jQuery.sap.storage.Type.local).get("vDropservice");
			var sOrderType = jQuery.sap.storage(jQuery.sap.storage.Type.local).get("OrderType");
			var sReturnDrop = jQuery.sap.storage(jQuery.sap.storage.Type.local).get("returnDrop");
			/*Disable Submit button on press Submit and if not equal to passthrough*/
			if (sObjectId !== "P") {
				if (that.byId("trailersubmit") !== undefined) {
					that.byId("trailersubmit").setVisible(false);
				}
			} else {
				if (that.byId("trailerpass") !== undefined) {
					that.byId("trailerpass").setVisible(false);
				}
			}
			/*Disable Submit button on press Submit*/
			if ((vAction === "U") && (sReturnDrop !== "")) {
				if ((vAction === "U") && (sReturnDrop === "X")) {
					that.fnOnSubmit();
				} else {
					if (!this._trailerfacilityDialog) {
						this._trailerfacilityDialog = sap.ui.xmlfragment("chep.checkin.fragments.FacilityTrailer", this);
						this.getView().addDependent(this._trailerfacilityDialog);
					}
					// toggle compact style
					jQuery.sap.syncStyleClass("sapUiSizeCompact", this.getView(), this._trailerfacilityDialog);
					this._trailerfacilityDialog.open();
				}
			} else if ((vAction === "U") && (sReturnDrop === "L")) {
				that.fnOnSubmit();
			} else if ((vDropservice === "true") && ((sOrderType === "Collect") || ((sOrderType === "Raw Materials")) || (sOrderType ===
				"STO Receipt"))) {
				jQuery.sap.storage(jQuery.sap.storage.Type.local).put("issueDrop", "");
				// that.openDropHookFragment();
				dropNpickFlag = jQuery.sap.storage(jQuery.sap.storage.Type.local).get("dropNpickup");
				var DandHserviceflag = jQuery.sap.storage(jQuery.sap.storage.Type.local).get("vDhservice"); // live phase drop2
				if (DandHserviceflag === "true") { // live phase drop2- checking D&H flag
					if (dropNpickFlag === "X") {
						that.onYesPress();
					} else {
						jQuery.sap.storage(jQuery.sap.storage.Type.local).put("returnDrop", "X");
						that.fnOnSubmit();
						// that.openDropPickUpFragment();
					}
				} else {
					that.openDropPickUpFragment();
				}
			} else { // order type Issue
				var DandHserviceflag1 = jQuery.sap.storage(jQuery.sap.storage.Type.local).get("vDhservice"); // live phase drop2
				if (DandHserviceflag1 === "true") { // live phase drop2- checking D&H flag
					if (dropNpickFlag === "") {
						jQuery.sap.storage(jQuery.sap.storage.Type.local).put("issueDrop", "X");
					}
				}
				that.fnOnSubmit();
			}

		},

		onYesPress: function() {
			if (!this._trailerfacilityDialog) {
				this._trailerfacilityDialog = sap.ui.xmlfragment("chep.checkin.fragments.FacilityTrailer", this);
				this.getView().addDependent(this._trailerfacilityDialog);
			}
			var that = this;
			jQuery.sap.storage(jQuery.sap.storage.Type.local).put("trailerLive", "");
			var sDelNumber = jQuery.sap.storage(jQuery.sap.storage.Type.local).get("DeliveryNumber");
			var sScacCode = jQuery.sap.storage(jQuery.sap.storage.Type.local).get("Scac");
			jQuery.sap.storage(jQuery.sap.storage.Type.local).put("sDandHBtnPress", "X"); // Added for D&H message
			if (sScacCode === "") {
				sScacCode = that.byId("sizecompany").getSelectedKey();
			}
			// that._DopandHookDialog.close();
			if (dropNpickFlag !== "X") {
				that._DropandPickDialog.close();
			}
			var i18nModel = that.getOwnerComponent();
			var url = "/sap/opu/odata/sap/ZGW_CHECKIN_SRV/";
			var oModelCheck = new sap.ui.model.odata.v2.ODataModel(url);
			oModelCheck.setHeaders({
				"X-Requested-With": "XMLHttpRequest",
				"Content-Type": "application/atom+xml",
				"slug": "image.jpg",
				"DataServiceVersion": "2.0",
				"X-CSRF-Token": "Fetch"
			});
			oModelCheck.useBatch = true;
			oModelCheck.read("/ValidateDelSet(Werks='" + vLoadPlant + "',DocId='" + sDelNumber + "',Carrier='" + sScacCode +
				"',Action='" + "S" + "')", {
					success: function(oData, oResponse) {
						if ((oResponse.statusCode === 200) || (oResponse.statusCode === "200")) {
							oInsCreateDailog.close();
							var sHeaderMsg = oResponse.headers.message; //CheckedIn message
							if (sHeaderMsg !== undefined) { // for Valid and Submitted number
								if (sHeaderMsg !== "") {
									if (sHeaderMsg === "Success") {
										//	that.fnOnSubmit();
										jQuery.sap.syncStyleClass("sapUiSizeCompact", that.getView(), that._trailerfacilityDialog);
										that._trailerfacilityDialog.open();
									} else if (sHeaderMsg === "Completed") {
										var oMessage = i18nModel.getModel("i18n").getProperty('orderCompleted');
										var submitError = i18nModel.getModel("i18n").getProperty('submitError');
										MessageBox.show(
											oMessage, {
												icon: MessageBox.Icon.ERROR,
												title: submitError, //"Error during submitting!"
												actions: [sap.m.MessageBox.Action.OK],
												onClose: function(oAction) {
													if (oAction == "OK") {
														var oRouter = sap.ui.core.UIComponent.getRouterFor(that);
														oRouter.navTo("CheckIn");
													}
												}.bind(that)
											});
									}
								}
							} else {
								var oMessage = i18nModel.getModel("i18n").getProperty('enterValOrderNum');
								var submitError = i18nModel.getModel("i18n").getProperty('submitError');
								MessageBox.show(
									oMessage, {
										icon: MessageBox.Icon.ERROR,
										actions: [sap.m.MessageBox.Action.OK],
										onClose: function(oAction) {
											if (oAction == "OK") {
												var oRouter = sap.ui.core.UIComponent.getRouterFor(that);
												oRouter.navTo("CheckIn");
											}
										}.bind(that)
									});
							}

						} else {
							oInsCreateDailog.close();
							var oMessage = i18nModel.getModel("i18n").getProperty('enterValOrderNum');
							var submitError = i18nModel.getModel("i18n").getProperty('submitError');
							MessageBox.show(
								oMessage, {
									icon: MessageBox.Icon.ERROR,
									actions: [sap.m.MessageBox.Action.OK],
									onClose: function(oAction) {
										if (oAction == "OK") {
											var oRouter = sap.ui.core.UIComponent.getRouterFor(that);
											oRouter.navTo("CheckIn");
										}
									}.bind(that)
								});
						}
					},
					error: function() {
						oInsCreateDailog.close();
						var oMessage = i18nModel.getModel("i18n").getProperty('enterValOrderNum');
						var submitError = i18nModel.getModel("i18n").getProperty('submitError');
						MessageBox.show(
							oMessage, {
								icon: MessageBox.Icon.ERROR,
								actions: [sap.m.MessageBox.Action.OK],
								onClose: function(oAction) {
									if (oAction == "OK") {
										var oRouter = sap.ui.core.UIComponent.getRouterFor(that);
										oRouter.navTo("CheckIn");
									}
								}.bind(that)
							});
					}
				});
		},

		onNoPress: function() {
			var that = this;
			jQuery.sap.storage(jQuery.sap.storage.Type.local).put("trailerLive", "X");
			jQuery.sap.storage(jQuery.sap.storage.Type.local).put("returnDrop", "X");
			jQuery.sap.storage(jQuery.sap.storage.Type.local).put("issueDrop", "");
			var sDelNumber = jQuery.sap.storage(jQuery.sap.storage.Type.local).get("DeliveryNumber");
			var sScacCode = jQuery.sap.storage(jQuery.sap.storage.Type.local).get("Scac");
			jQuery.sap.storage(jQuery.sap.storage.Type.local).put("sDandHBtnPress", ""); // Added for D&H message
			if (sScacCode === "") {
				sScacCode = that.byId("sizecompany").getSelectedKey();
			}
			// this._DopandHookDialog.close();
			this._DropandPickDialog.close();
			//	that.fnOnSubmit();
			var i18nModel = that.getOwnerComponent();
			var url = "/sap/opu/odata/sap/ZGW_CHECKIN_SRV/";
			var oModelCheck = new sap.ui.model.odata.v2.ODataModel(url);
			oModelCheck.setHeaders({
				"X-Requested-With": "XMLHttpRequest",
				"Content-Type": "application/atom+xml",
				"slug": "image.jpg",
				"DataServiceVersion": "2.0",
				"X-CSRF-Token": "Fetch"
			});
			oModelCheck.useBatch = true;
			oModelCheck.read("/ValidateDelSet(Werks='" + vLoadPlant + "',DocId='" + sDelNumber + "',Carrier='" + sScacCode +
				"',Action='" +
				"N" + "')", {
					success: function(oData, oResponse) {
						if ((oResponse.statusCode === 200) || (oResponse.statusCode === "200")) {
							oInsCreateDailog.close();
							var sHeaderMsg = oResponse.headers.message; //CheckedIn message
							if (sHeaderMsg !== undefined) { // for Valid and Submitted number
								if (sHeaderMsg !== "") {
									if (sHeaderMsg === "Success") {
										that.fnOnSubmit();
									} else if (sHeaderMsg === "Completed") {
										var oMessage = i18nModel.getModel("i18n").getProperty('orderCompleted');
										var submitError = i18nModel.getModel("i18n").getProperty('submitError');
										MessageBox.show(
											oMessage, {
												icon: MessageBox.Icon.ERROR,
												title: submitError, //"Error during submitting!"
												actions: [sap.m.MessageBox.Action.OK],
												onClose: function(oAction) {
													if (oAction == "OK") {
														var oRouter = sap.ui.core.UIComponent.getRouterFor(that);
														oRouter.navTo("CheckIn");
													}
												}.bind(that)
											});
									}
								}
							} else {
								var oMessage = i18nModel.getModel("i18n").getProperty('enterValOrderNum');
								var submitError = i18nModel.getModel("i18n").getProperty('submitError');
								MessageBox.show(
									oMessage, {
										icon: MessageBox.Icon.ERROR,
										actions: [sap.m.MessageBox.Action.OK],
										onClose: function(oAction) {
											if (oAction == "OK") {
												var oRouter = sap.ui.core.UIComponent.getRouterFor(that);
												oRouter.navTo("CheckIn");
											}
										}.bind(that)
									});
							}

						} else {
							oInsCreateDailog.close();
							var oMessage = i18nModel.getModel("i18n").getProperty('enterValOrderNum');
							var submitError = i18nModel.getModel("i18n").getProperty('submitError');
							MessageBox.show(
								oMessage, {
									icon: MessageBox.Icon.ERROR,
									actions: [sap.m.MessageBox.Action.OK],
									onClose: function(oAction) {
										if (oAction == "OK") {
											var oRouter = sap.ui.core.UIComponent.getRouterFor(that);
											oRouter.navTo("CheckIn");
										}
									}.bind(that)
								});
						}
					},
					error: function() {
						oInsCreateDailog.close();
						var oMessage = i18nModel.getModel("i18n").getProperty('enterValOrderNum');
						var submitError = i18nModel.getModel("i18n").getProperty('submitError');
						MessageBox.show(
							oMessage, {
								icon: MessageBox.Icon.ERROR,
								actions: [sap.m.MessageBox.Action.OK],
								onClose: function(oAction) {
									if (oAction == "OK") {
										var oRouter = sap.ui.core.UIComponent.getRouterFor(that);
										oRouter.navTo("CheckIn");
									}
								}.bind(that)
							});
					}
				});
		},

		ontrailerType: function() {
			if (!this._Tailertype) {
				this._Tailertype = sap.ui.xmlfragment("chep.checkin.fragments.TrailerType", this);
				this.getView().addDependent(this._Tailertype);
			}
			jQuery.sap.syncStyleClass("sapUiSizeCompact", this.getView(), this._Tailertype);
			this._Tailertype.open();
		},

		onEmptyTrailerPress: function() {
			var that = this;
			this._trailerfacilityDialog.close();
			if (vAction === "F") {
				jQuery.sap.storage(jQuery.sap.storage.Type.local).put("returnDrop", "E");
			}
			if (vAction === "U") {
				jQuery.sap.storage(jQuery.sap.storage.Type.local).put("issueDrop", "E");
			} else {
				jQuery.sap.storage(jQuery.sap.storage.Type.local).put("issueDrop", "");
			}
			that.ontrailerType();
		},

		onFlatBedPress: function() {
			var that = this;
			this._Tailertype.close();
			jQuery.sap.storage(jQuery.sap.storage.Type.local).put("trailerTypeFV", "FLAT");
			that.fnOnSubmit();
		},

		ontrailerVanPress: function() {
			var that = this;
			this._Tailertype.close();
			jQuery.sap.storage(jQuery.sap.storage.Type.local).put("trailerTypeFV", "VAN");
			that.fnOnSubmit();
		},

		onLoadedTrailerPress: function() {
			jQuery.sap.storage(jQuery.sap.storage.Type.local).put("trailerTypeFV", "");
			if (vAction === "F") {
				jQuery.sap.storage(jQuery.sap.storage.Type.local).put("returnDrop", "L");
			}
			this._trailerfacilityDialog.close();
			if (vAction === "U") {
				jQuery.sap.storage(jQuery.sap.storage.Type.local).put("issueDrop", "L");
				if (!this.outBoundUADialog) {
					this.outBoundUADialog = sap.ui.xmlfragment("chep.checkin.fragments.UnAuthorisedOutbound", this);
					this.getView().addDependent(this.outBoundUADialog);
				}
				// toggle compact style
				jQuery.sap.syncStyleClass("sapUiSizeCompact", this.getView(), this.outBoundUADialog);
				this.outBoundUADialog.open();
			} else {
				jQuery.sap.storage(jQuery.sap.storage.Type.local).put("issueDrop", "");
				if (!this.outBoundDialog) {
					this.outBoundDialog = sap.ui.xmlfragment("chep.checkin.fragments.OutBound", this);
					this.getView().addDependent(this.outBoundDialog);
					this.outBoundDialog.open();
				}
				// toggle compact style
				jQuery.sap.syncStyleClass("sapUiSizeCompact", this.getView(), this.outBoundDialog);
			}
		},

		onBobTailPress: function() {
			var that = this;
			jQuery.sap.storage(jQuery.sap.storage.Type.local).put("trailerTypeFV", "");
			if (vAction === "F") {
				jQuery.sap.storage(jQuery.sap.storage.Type.local).put("returnDrop", "B");
			}
			if (vAction === "U") {
				jQuery.sap.storage(jQuery.sap.storage.Type.local).put("issueDrop", "B");
			} else {
				jQuery.sap.storage(jQuery.sap.storage.Type.local).put("issueDrop", "");
			}
			this._trailerfacilityDialog.close();
			that.fnOnSubmit();
		},

		onOutBoundSubmitpress: function() {
			var that = this;
			that.fnCreateBusyDialog("pallet.svg");
			var i18nModel = that.getOwnerComponent();
			var sDelNumber = sap.ui.getCore().byId("docId").getValue().trim();
			if (sDelNumber === "") {
				oInsCreateDailog.close();
				sap.ui.getCore().byId("docId").setValueState(sap.ui.core.ValueState.Error);
				var enterOrderNum = this.getView().getModel("i18n").getProperty('enterOrderNum');
				var submitError = this.getView().getModel("i18n").getProperty('submitError');
				var oMessage = enterOrderNum; //"Please Enter Order Number";
				MessageBox.show(
					oMessage, {
						icon: MessageBox.Icon.ERROR,
						title: submitError //"Error during submitting!"
					});
			} else if (sDelNumber !== "") {
				sap.ui.getCore().byId("docId").setValueState(sap.ui.core.ValueState.None);
				var url = "/sap/opu/odata/sap/ZGW_CHECKIN_SRV/";
				var sScacCode;
				if (sRegion !== "US") {
					sScacCode = jQuery.sap.storage(jQuery.sap.storage.Type.local).get("Lifnr");
				} else {
					sScacCode = jQuery.sap.storage(jQuery.sap.storage.Type.local).get("Scac");
				}
				if (sScacCode === "") {
					sScacCode = that.byId("sizecompany").getSelectedKey();
				}
				var oModelCheck = new sap.ui.model.odata.v2.ODataModel(url);
				oModelCheck.setHeaders({
					"X-Requested-With": "XMLHttpRequest",
					"Content-Type": "application/atom+xml",
					"slug": "image.jpg",
					"DataServiceVersion": "2.0",
					"X-CSRF-Token": "Fetch"
				});
				oModelCheck.useBatch = true;
				oModelCheck.read("/ValidateDelSet(Werks='" + vLoadPlant + "',DocId='" + sDelNumber + "',Carrier='" + sScacCode +
					"',Action='" +
					"C" + "')", {
						success: function(oData, oResponse) {
							if ((oResponse.statusCode === 200) || (oResponse.statusCode === "200")) {
								oInsCreateDailog.close();
								var sHeaderMsg = oResponse.headers.message; //CheckedIn message
								if (sHeaderMsg !== undefined) { // for Valid and Submitted number
									if (sHeaderMsg !== "") {
										if (sHeaderMsg === "Success") {
											delNumber = sDelNumber;
											sap.ui.getCore().byId("docId").setValue("");
											that.outBoundDialog.close();
											that.outBoundDialog.destroy();
											that.outBoundDialog = null;
											that.fnOnSubmit();
										} else {
											var oMessage = i18nModel.getModel("i18n").getProperty('enterValOrderNum');
											var submitError = i18nModel.getModel("i18n").getProperty('submitError');
											MessageBox.show(
												oMessage, {
													icon: MessageBox.Icon.ERROR,
													title: submitError //"Error during submitting!"
												});
											sap.ui.getCore().byId("docId").setValue("");
										}
									}
								} else {
									var oMessage = i18nModel.getModel("i18n").getProperty('enterValOrderNum');
									var submitError = i18nModel.getModel("i18n").getProperty('submitError');
									MessageBox.show(
										oMessage, {
											icon: MessageBox.Icon.ERROR,
											title: submitError //"Error during submitting!"
										});
									sap.ui.getCore().byId("docId").setValue("");
								}
							} else {
								oInsCreateDailog.close();
							}
						},
						error: function() {
							oInsCreateDailog.close();
							sap.ui.getCore().byId("docId").setValue("");
							that.outBoundDialog.close();
							that.outBoundDialog.destroy();
							that.outBoundDialog = null;
							that.notValidDialog();
						}
					});
			}
		},

		notValidDialog: function() {
			if (!this.outBoundNvDialog) {
				this.outBoundNvDialog = sap.ui.xmlfragment("chep.checkin.fragments.OutBoundNotValid", this);
				this.getView().addDependent(this.outBoundNvDialog);
			}
			// toggle compact style
			jQuery.sap.syncStyleClass("sapUiSizeCompact", this.getView(), this.outBoundNvDialog);
			this.outBoundNvDialog.open();
		},

		outBoundLiveChange: function() {
			var outBoundDelNum = sap.ui.getCore().byId("docId").getValue().trim();
			if (outBoundDelNum !== "") {
				sap.ui.getCore().byId("docId").setValueState(sap.ui.core.ValueState.None);
			}
			if (outBoundDelNum !== "") {
				sap.ui.getCore().byId("docId").setValueState(sap.ui.core.ValueState.None);
				if (outBoundDelNum.length > 10) {
					var sDeliveryNum = outBoundDelNum.substring(0, outBoundDelNum.length - 1);
					sap.ui.getCore().byId("docId").getView().byId("docId").setValue(sDeliveryNum);
				}
			}
		},

		onOutBoundNvSubmitPress: function() {
			var that = this;
			that.fnCreateBusyDialog("pallet.svg");
			var i18nModel = that.getOwnerComponent();
			var sDelNumber = sap.ui.getCore().byId("notValidRefNum").getValue().trim();
			if (sDelNumber === "") {
				oInsCreateDailog.close();
				sap.ui.getCore().byId("notValidRefNum").setValueState(sap.ui.core.ValueState.Error);
				var enterOrderNum = this.getView().getModel("i18n").getProperty('enterOrderNum');
				var submitError = this.getView().getModel("i18n").getProperty('submitError');
				var oMessage = enterOrderNum; //"Please Enter Order Number";
				MessageBox.show(
					oMessage, {
						icon: MessageBox.Icon.ERROR,
						title: submitError //"Error during submitting!"
					});
			} else if (sDelNumber !== "") {
				sap.ui.getCore().byId("notValidRefNum").setValueState(sap.ui.core.ValueState.None);
				var url = "/sap/opu/odata/sap/ZGW_CHECKIN_SRV/";
				var oModelCheck = new sap.ui.model.odata.v2.ODataModel(url);
				oModelCheck.setHeaders({
					"X-Requested-With": "XMLHttpRequest",
					"Content-Type": "application/atom+xml",
					"slug": "image.jpg",
					"DataServiceVersion": "2.0",
					"X-CSRF-Token": "Fetch"
				});
				oModelCheck.useBatch = true;
				var sCarrier;
				if (sRegion !== "US") {
					sCarrier = jQuery.sap.storage(jQuery.sap.storage.Type.local).get("Lifnr");
				} else {
					sCarrier = jQuery.sap.storage(jQuery.sap.storage.Type.local).get("Scac");
				}
				//	oModelCheck.read("/CheckInSet(Werks='" + vLoadPlant + "',DocId='" + sDelNumber + "')", {
				oModelCheck.read("/ValidateDelSet(Werks='" + vLoadPlant + "',DocId='" + sDelNumber + "',Carrier='" + sCarrier +
					"',Action='" +
					"C" + "')", {
						success: function(oData, oResponse) {
							if ((oResponse.statusCode === 200) || (oResponse.statusCode === "200")) {
								oInsCreateDailog.close();
								var sOrderType = oData.OrderType;
								var sHeaderMsg = oResponse.headers.message; //CheckedIn message
								if (sHeaderMsg !== undefined) { // for Valid and Submitted number
									if (sHeaderMsg !== "") {
										if (sHeaderMsg === "Success") {
											delNumber = sDelNumber;
											sap.ui.getCore().byId("notValidRefNum").setValue("");
											that.outBoundNvDialog.close();
											that.fnOnSubmit();
										} else {
											var oMessage = i18nModel.getModel("i18n").getProperty('enterValOrderNum');
											var submitError = i18nModel.getModel("i18n").getProperty('submitError');
											MessageBox.show(
												oMessage, {
													icon: MessageBox.Icon.ERROR,
													title: submitError //"Error during submitting!"
												});
											sap.ui.getCore().byId("notValidRefNum").setValue("");
										}
									}
								} else {
									var oMessage = i18nModel.getModel("i18n").getProperty('enterValOrderNum');
									var submitError = i18nModel.getModel("i18n").getProperty('submitError');
									MessageBox.show(
										oMessage, {
											icon: MessageBox.Icon.ERROR,
											title: submitError //"Error during submitting!"
										});
									sap.ui.getCore().byId("notValidRefNum").setValue("");
								}

								/*	if (sOrderType.toLowerCase() === "Issue" || sOrderType.toLowerCase() === "issue") {
									delNumber = sDelNumber;
									sap.ui.getCore().byId("notValidRefNum").setValue("");
									that.outBoundNvDialog.close();
									that.fnOnSubmit();
								} else {
									var subError = that.getView().getModel("i18n").getProperty('submitError');
									var enterValOrderNum = that.getView().getModel("i18n").getProperty('enterValOrderNum');
									var oMessageVal = enterValOrderNum; //"Please Enter Valid Order Number";
									MessageBox.show(
										oMessageVal, {
											icon: MessageBox.Icon.ERROR,
											title: subError //"Error during submitting!"
										});
									sap.ui.getCore().byId("notValidRefNum").setValue("");
								}*/
							} else {
								oInsCreateDailog.close();
							}
						},
						error: function() {
							oInsCreateDailog.close();
							var subError = that.getView().getModel("i18n").getProperty('submitError');
							var enterValOrderNum = that.getView().getModel("i18n").getProperty('enterValOrderNum');
							var oMessageVal = enterValOrderNum; //"Please Enter Valid Order Number";
							MessageBox.show(
								oMessageVal, {
									icon: MessageBox.Icon.ERROR,
									title: subError //"Error during submitting!"
								});
							sap.ui.getCore().byId("notValidRefNum").setValue("");
							//	that.outBoundNvDialog.close();
						}
					});
			}

		},

		onOutBoundNvCancelPress: function() {
			var that = this;
			this.outBoundNvDialog.close();
			that.fnOnSubmit();
		},

		notValidLiveChange: function() {
			var notValidDelNum = sap.ui.getCore().byId("notValidRefNum").getValue().trim();
			if (notValidDelNum !== "") {
				sap.ui.getCore().byId("notValidRefNum").setValueState(sap.ui.core.ValueState.None);
			}
			if (notValidDelNum !== "") {
				sap.ui.getCore().byId("notValidRefNum").setValueState(sap.ui.core.ValueState.None);
				if (notValidDelNum.length > 10) {
					var sDeliveryNum = notValidDelNum.substring(0, notValidDelNum.length - 1);
					sap.ui.getCore().byId("notValidRefNum").getView().byId("notValidRefNum").setValue(sDeliveryNum);
				}
			}

		},

		onOutBoundUASubmitpress: function() {
			var that = this;
			that.fnCreateBusyDialog("pallet.svg");
			var sUADelnum = sap.ui.getCore().byId("docIdUA").getValue().trim();
			if (sUADelnum === "") {
				oInsCreateDailog.close();
				sap.ui.getCore().byId("docIdUA").setValueState(sap.ui.core.ValueState.Error);
				var enterOrderNum = this.getView().getModel("i18n").getProperty('enterOrderNum');
				var submitError = this.getView().getModel("i18n").getProperty('submitError');
				var oMessage = enterOrderNum; //"Please Enter Order Number";
				MessageBox.show(
					oMessage, {
						icon: MessageBox.Icon.ERROR,
						title: submitError //"Error during submitting!"
					});
			} else if (sUADelnum !== "") {
				sap.ui.getCore().byId("docIdUA").setValueState(sap.ui.core.ValueState.None);
				var url = "/sap/opu/odata/sap/ZGW_CHECKIN_SRV/";
				var i18nModel = that.getOwnerComponent();
				var sScacCode;
				if (sRegion !== "US") {
					sScacCode = jQuery.sap.storage(jQuery.sap.storage.Type.local).get("Lifnr");
				} else {
					sScacCode = jQuery.sap.storage(jQuery.sap.storage.Type.local).get("Scac");
				}
				if (sScacCode === "") {
					sScacCode = that.byId("sizecompany").getSelectedKey();
				}
				var oModelCheck = new sap.ui.model.odata.v2.ODataModel(url);
				oModelCheck.setHeaders({
					"X-Requested-With": "XMLHttpRequest",
					"Content-Type": "application/atom+xml",
					"slug": "image.jpg",
					"DataServiceVersion": "2.0",
					"X-CSRF-Token": "Fetch"
				});
				oModelCheck.useBatch = true;
				//	oModelCheck.read("/CheckInSet(Werks='" + vLoadPlant + "',DocId='" + sUADelnum + "')", {
				oModelCheck.read("/ValidateDelSet(Werks='" + vLoadPlant + "',DocId='" + sUADelnum + "',Carrier='" + sScacCode +
					"',Action='" +
					"C" + "')", {
						success: function(oData, oResponse) {
							if ((oResponse.statusCode === 200) || (oResponse.statusCode === "200")) {
								oInsCreateDailog.close();
								var sOrderType = oData.OrderType;
								/*	if (((sOrderType.toLowerCase() === "Issue") || (sOrderType.toLowerCase() === "issue")) ||
								((sOrderType.toLowerCase() === "STO Issue") || (sOrderType.toLowerCase() === "sto issue"))) {
								delNumber = sUADelnum;
								sap.ui.getCore().byId("docIdUA").setValue("");
								that.outBoundUADialog.close();
								that.fnOnSubmit();
							} else {
								var subError = that.getView().getModel("i18n").getProperty('submitError');
								var enterValOrderNum = that.getView().getModel("i18n").getProperty('enterValOrderNum');
								var oMessageVal = enterValOrderNum; //"Please Enter Valid Order Number";
								MessageBox.show(
									oMessageVal, {
										icon: MessageBox.Icon.ERROR,
										title: subError //"Error during submitting!"
									});
								sap.ui.getCore().byId("docIdUA").setValue("");
							}*/
								var sHeaderMsg = oResponse.headers.message; //CheckedIn message
								if (sHeaderMsg !== undefined) { // for Valid and Submitted number
									if (sHeaderMsg !== "") {
										if (sHeaderMsg === "Success") {
											delNumber = sUADelnum;
											sap.ui.getCore().byId("docIdUA").setValue("");
											that.outBoundUADialog.close();
											that.fnOnSubmit();
										} else {
											var oMessage = i18nModel.getModel("i18n").getProperty('enterValOrderNum');
											var submitError = i18nModel.getModel("i18n").getProperty('submitError');
											MessageBox.show(
												oMessage, {
													icon: MessageBox.Icon.ERROR,
													title: submitError //"Error during submitting!"
												});
											sap.ui.getCore().byId("docIdUA").setValue("");
										}
									}
								} else {
									var oMessage = i18nModel.getModel("i18n").getProperty('enterValOrderNum');
									var submitError = i18nModel.getModel("i18n").getProperty('submitError');
									MessageBox.show(
										oMessage, {
											icon: MessageBox.Icon.ERROR,
											title: submitError //"Error during submitting!"
										});
									sap.ui.getCore().byId("docIdUA").setValue("");
								}
							} else {
								oInsCreateDailog.close();
							}
						},
						error: function() {
							oInsCreateDailog.close();
							var subError = that.getView().getModel("i18n").getProperty('submitError');
							var enterValOrderNum = that.getView().getModel("i18n").getProperty('enterValOrderNum');
							var oMessageVal = enterValOrderNum; //"Please Enter Valid Order Number";
							MessageBox.show(
								oMessageVal, {
									icon: MessageBox.Icon.ERROR,
									title: subError //"Error during submitting!"
								});
							sap.ui.getCore().byId("docIdUA").setValue("");
						}
					});
			}
		},

		UALiveChange: function() {
			var sDeliveryNoUA = sap.ui.getCore().byId("docIdUA").getValue().trim();
			if (sDeliveryNoUA !== "") {
				sap.ui.getCore().byId("docIdUA").setValueState(sap.ui.core.ValueState.None);
			}
			if (sDeliveryNoUA !== "") {
				sap.ui.getCore().byId("docIdUA").setValueState(sap.ui.core.ValueState.None);
				if (sDeliveryNoUA.length > 10) {
					var sDeliveryNumUA = sDeliveryNoUA.substring(0, sDeliveryNoUA.length - 1);
					sap.ui.getCore().byId("docIdUA").getView().byId("docIdUA").setValue(sDeliveryNumUA);
				}
			}
		},

		onUADontHaveOrderNumPress: function() {
			var that = this;
			that.outBoundUADialog.close();
			delNumber = "UA";
			that.fnOnSubmit();
		},

		onOutBoundDontHaveOrderNumPress: function() {
			var that = this;
			that.outBoundDialog.close();
			that.outBoundDialog.destroy();
			that.outBoundDialog = null;
			delNumber = "UA";
			that.fnOnSubmit();
		},
		//Begin of Changes by Sharmila
		confCheckIn: function() {
			var that = this;
			this._CheckinSummaryDialog.close();
			var covidFlag = that.getOwnerComponent().getModel("flagsModel").getProperty("/covidFlag");
			if (covidFlag === true || covidFlag === "true") {
				this.onCheckCovid();
			} else {
				that.CheckinSummaryconfirm();
			}
		},
		CheckinSummaryconfirm: function() {
			var that = this;
			//Begin of changes Sharmila

			if (that._CheckinSummaryDialog !== undefined) {
				that._CheckinSummaryDialog.close();
			}
			//End of changes Sharmila
			that.fnCreateBusyDialog("pallet.svg");
			var vDropservice = jQuery.sap.storage(jQuery.sap.storage.Type.local).get("vDropservice");
			storeTraMilk = jQuery.sap.storage(jQuery.sap.storage.Type.local).get("milkRunList");
			// that.getOwnerComponent().getModel("MobileSerModel").setUseBatch(false);
			var sCtryCode = that.onCountrycodeChange(this.byId("countryCode").getSelectedItem().getText());

			if (storeTraMilk.length !== 0) {

				if (sParentPlant) {
					for (var i = 0; i < storeTraMilk.length; i++) {
						if (storeTraMilk[i].Plant === sParentPlant) {
							docId = storeTraMilk[i].chepdeliverynumber;
							break;
						} else {
							docId = storeTraMilk[0].chepdeliverynumber;
						}
					}
				} else {
					docId = storeTraMilk[0].chepdeliverynumber;
				}

			} else {
				docId = jQuery.sap.storage(jQuery.sap.storage.Type.local).get("DeliveryNumber");
			}

			var aregid = this.byId("reg_Id").getValue();
			var driverName = this.byId("driver_Name").getValue();
			var sCtryCode = this.byId("countryCode").getSelectedKey();
			if (sObjectId !== "B") {
				var trailerId = this.byId("Trailer_Id").getValue();
				var trailerSize = this.byId("size").getSelectedItem().getText();
				var trailerSizeKey = this.byId("size").getSelectedKey();
			}
			var carrier = this.byId("sizecompany").getSelectedKey();
			var sysLang = jQuery.sap.storage(jQuery.sap.storage.Type.local).get("sysLang");
			var cell = this.byId("Mobile_Num").getValue();
			var KioskId = jQuery.sap.storage(jQuery.sap.storage.Type.local).get("KioskId");

			if (that.getView().getModel("lifnrMod") !== undefined) {
				var lifnr = that.getView().getModel("lifnrMod").getProperty("/Lifnr");
			}

			var sCheckInSystem = that.sDeviceType;

			var oEntry = {};

			oEntry.Werks = vLoadPlant;
			oEntry.DocId = docId;
			if ((sRegion !== "US") && (sRegion !== "CA")) {
				oEntry.Registration = aregid;
			} else {
				oEntry.Registration = "";
			}
			oEntry.Action = vAction; //"F";

			oEntry.TrailerType = trailerSize;
			oEntry.DriverName = driverName;
			/*CTRM-760   -- Trailer+Number --*/
			var vTrailerIDregion = jQuery.sap.storage(jQuery.sap.storage.Type.local).get("vCHtrilerid");
			var trailerIdVehicleReg = this.byId("Trailer_Id").getValue();

			if (sRegion === "EU") {
				if (vTrailerIDregion !== true && trailerIdVehicleReg === "") {
					trailerIdVehicleReg = this.byId("reg_Id").getValue();
					oEntry.TrailerId = trailerIdVehicleReg;
				} else {
					oEntry.TrailerId = trailerId;
				}
			} else {
				oEntry.TrailerId = trailerId;
			}
			jQuery.sap.storage(jQuery.sap.storage.Type.local).put("trailerIdVehicleReg", trailerIdVehicleReg);
			if (sRegion === "US") {
				oEntry.Carrier = carrier;
				oEntry.TrailerSize = trailerSizeKey;
				oEntry.Vendor = lifnr;
			} else {
				oEntry.Vendor = carrier;
				oEntry.TrailerSize = trailerSizeKey;
			}
			var sCountry = that.onCountrycodeChange(this.byId("countryCode").getSelectedItem().getText());
			var sIssueDrop = jQuery.sap.storage(jQuery.sap.storage.Type.local).get("issueDrop");
			var sReturnDrop = jQuery.sap.storage(jQuery.sap.storage.Type.local).get("returnDrop");
			var sTrailerType = jQuery.sap.storage(jQuery.sap.storage.Type.local).get("trailerTypeFV");
			if (sIssueDrop === null) {
				sIssueDrop = "";
			}
			if (sReturnDrop === null) {
				sReturnDrop = "";
			}
			if (sTrailerType === null) {
				sTrailerType = "";
			}
			// Mobile number Passing
			if (covidDeclineFlag === "D") {
				oEntry.Invalid_Ph = "D";
			} else {
				if (sMblNumValidationFlag === "E" && covidPositiveFlag === "C") {
					// oEntry.Inv_PhoneNo = sCountry + " " + "XXXXXXXXXX";
					oEntry.Invalid_Ph = "B";
				} else if (covidPositiveFlag === "C") {
					oEntry.Invalid_Ph = "C";
				} else if (sMblNumValidationFlag === "E") {
					oEntry.Invalid_Ph = "X";
				}
			}
			oEntry.Cell = sCountry + " " + cell;
			oEntry.Country = sCtryCode;
			oEntry.Spras = sysLang;

			if (sap.ui.Device.system.tablet && !sap.ui.Device.system.desktop) {
				oEntry.Kiosk_ID = "T";
			} else {

				if (sCheckInSystem === "Browser") {
					oEntry.Kiosk_ID = "B";
				} else {
					oEntry.Kiosk_ID = loggedUser;
				}

				// oEntry.Kiosk_ID = loggedUser;

				//  if (KioskId !== "XXXXXXXXXX") {
				//  	oEntry.Kiosk_ID = loggedUser;
				//  } else {

				//  	oEntry.Kiosk_ID = KioskId;
				// }
			}
			oEntry.Iss_Drop = sIssueDrop;
			oEntry.Ret_Drop = sReturnDrop;
			oEntry.Pick_Ins = sTrailerType;
			if (delNumber !== undefined) {
				oEntry.Iss_Docid = delNumber;
			}
			var carrierName;
			// var lifnr;
			/*if ((this.byId("sizecompany").getSelectedKey() === "0000999999") || (this.byId("sizecompany").getSelectedKey() === "CUPU")) {
				carrierName = this.byId("companyScacode").getValue();
				carrierName = carrierName.toUpperCase();
				if (sCupuData > 0) {
					carrierName = this.byId("transportNameSelect").getSelectedItem().getText();
				} else {
					carrierName = this.byId("companyScacode").getValue();
					carrierName = carrierName.toUpperCase();
				}
			} else {
				carrierName = this.byId("sizecompany").getSelectedItem().getText();
			}*/

			if (this.byId("sizecompany").getSelectedKey() === "CUPU") {
				carrierName = this.byId("transportNameSelect").getValue();
				// 
				// if (this.byId("transportNameSelect").getSelectedItem().getText() === "ADD NEW") {
				// 	carrierName = jQuery.sap.storage(jQuery.sap.storage.Type.local).get("newTransportName");
				// 	carrierName = carrierName.toUpperCase();
				// } else {
				// 	carrierName = this.byId("transportNameSelect").getSelectedItem().getText();
				// }

			} else if (this.byId("sizecompany").getSelectedKey() === "0000999999") {
				if ((sHaulierFlag === "true") && (shipCondition === "Z1" || shipCondition === "Z4")) {
					// carrierName = sap.ui.getCore().byId("hauliername1").getValue();
					carrierName = that.getView().getModel("HaulierModel").getProperty("/HaulierName");
				} else {
					carrierName = this.byId("companyScacode").getValue();
					carrierName = carrierName.toUpperCase();
				}

			} else {
				carrierName = this.byId("sizecompany").getSelectedItem().getText();
			}
			var oModelMilk = that.getOwnerComponent().getModel("milkMod");
			var oModelMilkTip = that.getOwnerComponent().getModel("saveIssue");

			var sDelnoForTip;
			if (storeTraMilk.length !== 0) {
				sDelnoForTip = storeTraMilk[0].chepdeliverynumber;
			}
			tipStore = jQuery.sap.storage(jQuery.sap.storage.Type.local).get("tipReloadList");
			oInsCreateDailog.open();
			/*Have one issue and One Return then store*/
			if (tipStore.length > 0 && storeTraMilk.length !== 0) {
				var oHeaderTip = {};
				oHeaderTip.Deliveryno = sDelnoForTip; //docId;
				var arrayTip = [];
				for (var iCount = 0; iCount < tipStore.length; iCount++) {
					var dataGettingTip = {
						"Mrnumber": "",
						"Mritem": "",
						"Deliveryno": tipStore[iCount].chepdeliverynumber,
						"DelFlag": " "
					};
					arrayTip.push(dataGettingTip);
				}
				oHeaderTip.milkrunSet = arrayTip;
				if (arrayTip.length > 0) {
					oModelMilkTip.create("/MilkrunheaderSet", oHeaderTip, {
						success: function(oData, oResponse) {
							oEntry.CarrierName = carrierName;
							if (tipStore.length > 0 && storeTraMilk.length !== 0) {
								oEntry.Iss_Docid = tipStore[0].chepdeliverynumber;
								oEntry.OrderType = "T";
								if (storeTraMilk.length > 1) {
									var oHeader = {};
									oHeader.Deliveryno = "X";
									var array = [];
									for (var i = 0; i < storeTraMilk.length; i++) {
										var dataGetting = {
											"Mrnumber": "",
											"Mritem": "",
											"Deliveryno": storeTraMilk[i].chepdeliverynumber,
											"DelFlag": " "
										};
										array.push(dataGetting);
									}
									oHeader.milkrunSet = array;
									var oModelMilkT = that.getOwnerComponent().getModel("milkMod");
									oModelMilkT.create("/MilkrunheaderSet", oHeader, {
										success: function(oData, oResponse) {
											that.onFnSingleRI(oEntry);
											oInsCreateDailog.close();
										},
										error: function(oError) {
											oInsCreateDailog.close();
										}
									});

								} else {
									that.onFnSingleRI(oEntry);
								}
							}
							oInsCreateDailog.close();
						},
						error: function(oError) {
							oInsCreateDailog.close();
						}
					});
				}
			} else if (tipStore.length > 1 && storeTraMilk.length === 0) {
				oInsCreateDailog.open();
				var oIssueHeader = {};
				oIssueHeader.Deliveryno = "I";
				var oIssueArray = [];
				for (var j = 0; j < tipStore.length; j++) {
					var oMultiIssuedataGetting = {
						"Mrnumber": "",
						"Mritem": "",
						"Deliveryno": tipStore[j].chepdeliverynumber,
						"DelFlag": " "
					};
					oIssueArray.push(oMultiIssuedataGetting);
				}
				oIssueHeader.milkrunSet = oIssueArray;
				var oModelMilkT = that.getOwnerComponent().getModel("milkMod");
				oEntry.CarrierName = carrierName;
				oModelMilkT.create("/MilkrunheaderSet", oIssueHeader, {
					success: function(oData, oResponse) {
						that.onFnSingleRI(oEntry);
						oInsCreateDailog.close();
					},
					error: function(oError) {
						oInsCreateDailog.close();
					}
				});
			} else {
				if (storeTraMilk.length > 1) {
					oInsCreateDailog.open();
					var oHeader = {};
					oHeader.Deliveryno = "X";
					var array = [];
					for (var i = 0; i < storeTraMilk.length; i++) {
						var dataGetting = {
							"Mrnumber": "",
							"Mritem": "",
							"Deliveryno": storeTraMilk[i].chepdeliverynumber,
							"DelFlag": " "
						};
						array.push(dataGetting);
					}
					oHeader.milkrunSet = array;
					var oModelCreate = that.getOwnerComponent().getModel("createMod");
					var i18nModel = that.getOwnerComponent();
					oEntry.CarrierName = carrierName;
					/*Tip Preload*/
					if (tipStore.length > 0) {
						oEntry.Iss_Docid = tipStore[0].chepdeliverynumber;
						oEntry.OrderType = "T";
					}
					if (array.length > 1 && array.length !== 1) {
						oModelMilk.create("/MilkrunheaderSet", oHeader, {
							success: function(oData, oResponse) {
								oModelCreate.create("/CheckInSet", oEntry, {
									success: function(odata, response) {
										if (response.statusCode === "201") {
											checkintypeservice = oData.Checkin_Type;
											jQuery.sap.storage(jQuery.sap.storage.Type.local).put("checkintypeservice", checkintypeservice);

											var sNewMessage = odata.Message;
											if (sNewMessage !== undefined) {
												if (sNewMessage !== "") {
													jQuery.sap.storage(jQuery.sap.storage.Type.local).put("backEndMessage", sNewMessage);
												} else {
													var getBackMes = response.headers.message;
													if (getBackMes !== undefined) {
														jQuery.sap.storage(jQuery.sap.storage.Type.local).put("backEndMessage", getBackMes);
													} else {
														getBackMes = "";
														jQuery.sap.storage(jQuery.sap.storage.Type.local).put("backEndMessage", getBackMes);
													}
												}
											} else {
												var getBackMes = response.headers.message;
												if (getBackMes !== undefined) {
													jQuery.sap.storage(jQuery.sap.storage.Type.local).put("backEndMessage", getBackMes);
												} else {
													getBackMes = "";
													jQuery.sap.storage(jQuery.sap.storage.Type.local).put("backEndMessage", getBackMes);
												}
											}
											// var getBackMes = response.headers.message;
											// if (getBackMes !== undefined) {
											// 	jQuery.sap.storage(jQuery.sap.storage.Type.local).put("backEndMessage", getBackMes);
											// } else {
											// 	getBackMes = "";
											// 	jQuery.sap.storage(jQuery.sap.storage.Type.local).put("backEndMessage", getBackMes);
											// }
											if (vDropservice !== "true") {
												if (getBackMes !== "") {
													oInsCreateDailog.close();
													var oRouter = that.getRouter();
													oRouter.navTo("CheckinSuccessful");
												} else {
													oInsCreateDailog.close();
													var trailerSubmitError = i18nModel.getModel("i18n").getProperty('trailerSubmitError');
													MessageBox.show(
														trailerSubmitError, {
															icon: MessageBox.Icon.ERROR,
															title: i18nModel.getModel("i18n").getProperty('submitError'), //"Error during submitting!"
															actions: [sap.m.MessageBox.Action.OK],
															onClose: function(oAction) {
																if (oAction === "OK") {
																	that.onDecline(); //restrict multiple entries for CA3L plant
																}
															}.bind(that)
														});

												}
											} else {
												var dropInst = odata.Drop_Ins;
												var pickInst = odata.Pick_Ins;
												jQuery.sap.storage(jQuery.sap.storage.Type.local).put("dropInst", dropInst);
												jQuery.sap.storage(jQuery.sap.storage.Type.local).put("pickInst", pickInst);
												oInsCreateDailog.close();
												var oRouter = that.getRouter();
												oRouter.navTo("CheckinSuccessful");
											}
										} else {
											oInsCreateDailog.close();
										}
									},
									error: function(oError) {
										oInsCreateDailog.close();
										var errorMessage = "";
										if (oError.responseText !== "") {
											var sCheckInError = JSON.parse(oError.responseText).error;
											if (sCheckInError !== undefined) {
												if (sCheckInError.message !== undefined) {
													errorMessage = sCheckInError.message.value;
												}
											}
										}
										if (errorMessage.includes("Cancelled") || errorMessage.includes("DELETED")) {
											var oMsg = errorMessage.split(":");
											var sDelNum = oMsg[1]; //Delivery
											var sReason = oMsg[2]; //Cancelled Reason 
											if (sReason === undefined) {
												sReason = "";
											}
											var sCancelDelNumMsg = "";
											if (sRegion === "EU") {
												var sCancelledDeliveryMsgEU = i18nModel.getModel("i18n").getProperty('cancelledDeliveryMsgEU');
												sCancelDelNumMsg = sCancelledDeliveryMsgEU.replace("{delNumber}", sDelNum);
											} else {
												var sDltcanclDelMsgNotEU = i18nModel.getModel("i18n").getProperty('dltcanclDelMsgNotEU');
												sCancelDelNumMsg = sDltcanclDelMsgNotEU.replace("{delNumber}", sDelNum);
											}
											MessageBox.show(
												sCancelDelNumMsg, {
													icon: MessageBox.Icon.ERROR,
													title: i18nModel.getModel("i18n").getProperty('submitError'),
													actions: [sap.m.MessageBox.Action.OK],
													onClose: function(oAction) {
														if (oAction === "OK") {
															var oRouter = sap.ui.core.UIComponent.getRouterFor(that);
															oRouter.navTo("CheckIn");
														}
													}.bind(that)
												});
										} else {
											var trailerSubmitError = i18nModel.getModel("i18n").getProperty('trailerSubmitError');
											MessageBox.show(
												trailerSubmitError, {
													icon: MessageBox.Icon.ERROR,
													title: i18nModel.getModel("i18n").getProperty('submitError'),
													actions: [sap.m.MessageBox.Action.OK],
													onClose: function(oAction) {
														if (oAction === "OK") {
															that.onDecline();
														}
													}.bind(that)
												});
										}
									}
								});
								//	oInsCreateDailog.close();
							},
							error: function(oError) {
								oInsCreateDailog.close();
							}
						});
					}
				} else {
					oEntry.CarrierName = carrierName;
					if (tipStore.length > 0 && storeTraMilk.length !== 0) {
						oEntry.Iss_Docid = tipStore[0].chepdeliverynumber;
						oEntry.OrderType = "T";
					}
					that.onFnSingleRI(oEntry);
				}
				jQuery.sap.storage(jQuery.sap.storage.Type.local).put("OrderType", "");
			}
		},

		//to restrict multiple checkin
		onDecline: function() {
			var KioskId = jQuery.sap.storage(jQuery.sap.storage.Type.local).get("KioskId");
			if (sap.ui.Device.system.tablet && !sap.ui.Device.system.desktop) {
				var oCrossAppNavigatorTab = sap.ushell.Container.getService("CrossApplicationNavigation");
				oCrossAppNavigatorTab.toExternal({
					target: {
						semanticObject: "#Shell-home"
					}
				});
			} else {
				if (KioskId !== "XXXXXXXXXX") {
					var oCrossAppNavigator = sap.ushell.Container.getService("CrossApplicationNavigation");
					var hash = "ZESP_CHECKIN-display?sap-language=" + sLanguage + "&KIOSK_ID=" + KioskId + "&/EULADeclined";
					oCrossAppNavigator.toExternal({
						target: {
							shellHash: hash
						}
					});
				} else {
					var oCrossAppNavigatorTab3 = sap.ushell.Container.getService("CrossApplicationNavigation");
					oCrossAppNavigatorTab3.toExternal({
						target: {
							semanticObject: "#Shell-home"
						}
					});
				}
			}
		},
		//to restrict multiple checkin

		fnOnSubmit: function() {
			var that = this;
			that._trailerSummary(); //Added by Sharmila
		},
		//End of Changes by Sharmila
		onFnSingleRI: function(oEntry) {
			var that = this;
			var oHolierData = that.getView().getModel("HolierModeldata");
			var vDropservice = jQuery.sap.storage(jQuery.sap.storage.Type.local).get("vDropservice");
			var oModelCreate = that.getOwnerComponent().getModel("createMod");
			var i18nModel = that.getOwnerComponent();
			var OnaAddelevery = that.getView().byId("addDelivery").getVisible();
			var oTriploadUA = jQuery.sap.storage(jQuery.sap.storage.Type.local).get("oTripLoadUA");
			var milkRunListData = jQuery.sap.storage(jQuery.sap.storage.Type.local).get("milkRunListUA");
			var tipMilkList1 = jQuery.sap.storage(jQuery.sap.storage.Type.local).get("tipReloadListUA");
			var iputDel = jQuery.sap.storage(jQuery.sap.storage.Type.local).get("DeliveryNumber");
			if (oTriploadUA === "X" && (milkRunListData.length > 0 || tipMilkList1.length > 0)) {
				var oDelNumUA = jQuery.sap.storage(jQuery.sap.storage.Type.local).get("DeliveryNumberUA");
				if (oDelNumUA !== null && oDelNumUA !== undefined) {
					oEntry['UA_TR_Del'] = oDelNumUA;
				} else {
					oEntry['UA_TR_Del'] = iputDel;
				}
			}
			if (sUAbtnflag === "X" && (milkRunListData.length > 0 || tipMilkList1.length > 0)) {
				var oDelNumUAhedr = jQuery.sap.storage(jQuery.sap.storage.Type.local).get("DeliveryNumberUA");
				if (oDelNumUAhedr !== null && oDelNumUAhedr !== undefined) {
					oEntry['UA_TR_Del'] = oDelNumUAhedr;
				} else {
					oEntry['UA_TR_Del'] = iputDel;
				}
			}
			zSigni = oEntry.TrailerId; // Added Trailr id for UA multi glids
			var sCheckOrderType = jQuery.sap.storage(jQuery.sap.storage.Type.local).put("Ordertype");
			oModelCreate.create("/CheckInSet", oEntry, {
				success: function(odata, response) {
					var oTimestamp = response.headers.message;
					// if (oTimestamp) {
					// 	var timestampTrim = oTimestamp;
					// 	ztimestamp = timestampTrim.slice(-14);
					// } else {
					// 	ztimestamp = "";
					// }
					if (sRegion === "US") {
						if (oTimestamp) {
							var timestampTrim = oTimestamp;
							ztimestamp = timestampTrim.slice(-14);
						} else {
							ztimestamp = "";
						}
					} else {
						if (oTimestamp) {
							var timestampTrim = oTimestamp;
							ztimestamp = timestampTrim.slice(-15);
						} else {
							ztimestamp = "";
						}
					}
					// zSigni = odata.TrailerId;
					if (response.statusCode === "201") {
						if (OnaAddelevery === true && oHolierData !== undefined) {
							that.onHaulierSubmit();
						}
						checkintypeservice = odata.Checkin_Type;
						jQuery.sap.storage(jQuery.sap.storage.Type.local).put("checkintypeservice", checkintypeservice);
						//ctrm-1329
						var yardStop = odata.Yard_stop;
						jQuery.sap.storage(jQuery.sap.storage.Type.local).put("yardStop", yardStop);
						// var getBackMes = response.headers.message;
						// if (getBackMes !== undefined) {
						// 	jQuery.sap.storage(jQuery.sap.storage.Type.local).put("backEndMessage", getBackMes);
						// } else {
						// 	getBackMes = "";
						// 	jQuery.sap.storage(jQuery.sap.storage.Type.local).put("backEndMessage", getBackMes);
						// }
						var sNewMessage = odata.Message;
						if (sNewMessage !== undefined) {
							if (sNewMessage !== "") {
								jQuery.sap.storage(jQuery.sap.storage.Type.local).put("backEndMessage", sNewMessage);
							} else {
								var getBackMes = response.headers.message;
								if (getBackMes !== undefined) {
									jQuery.sap.storage(jQuery.sap.storage.Type.local).put("backEndMessage", getBackMes);
								} else {
									getBackMes = "";
									jQuery.sap.storage(jQuery.sap.storage.Type.local).put("backEndMessage", getBackMes);
								}
							}
						} else {
							var getBackMes = response.headers.message;
							if (getBackMes !== undefined) {
								jQuery.sap.storage(jQuery.sap.storage.Type.local).put("backEndMessage", getBackMes);
							} else {
								getBackMes = "";
								jQuery.sap.storage(jQuery.sap.storage.Type.local).put("backEndMessage", getBackMes);
							}
						}
						if (vDropservice !== "true") {
							if (getBackMes !== "") {
								oInsCreateDailog.close();
								var oRouter = that.getRouter();
								oRouter.navTo("CheckinSuccessful");
							} else {
								oInsCreateDailog.close();
								//	var that = this;
								var trailerSubmitError = i18nModel.getModel("i18n").getProperty('trailerSubmitError');
								MessageBox.show(
									trailerSubmitError, {
										icon: MessageBox.Icon.ERROR,
										title: i18nModel.getModel("i18n").getProperty('submitError'), //"Error during submitting!"
										actions: [sap.m.MessageBox.Action.OK],
										onClose: function(oAction) {
											if (oAction === "OK") {
												that.onDecline(); //restrict multiple entries for CA3L plant
											}
										}.bind(that)
									});

							}
						} else {
							var dropInst = odata.Drop_Ins;
							var pickInst = odata.Pick_Ins;
							jQuery.sap.storage(jQuery.sap.storage.Type.local).put("dropInst", dropInst);
							jQuery.sap.storage(jQuery.sap.storage.Type.local).put("pickInst", pickInst);
							oInsCreateDailog.close();
							var oRouter = that.getRouter();
							oRouter.navTo("CheckinSuccessful");
						}

					} else {
						oInsCreateDailog.close();
					}
				},
				error: function(oError) {
					oInsCreateDailog.close();
					var errorMessage = "";
					if (oError.responseText !== "") {
						var sLivecheckInError = JSON.parse(oError.responseText).error;
						if (sLivecheckInError !== undefined) {
							if (sLivecheckInError.message !== undefined) {
								errorMessage = sLivecheckInError.message.value;
							}
						}
					}
					var trailerSubmitError;
					if (errorMessage.includes("Cancelled") || errorMessage.includes("DELETED")) {
						var oMsg = errorMessage.split(":");
						var sDelNum = oMsg[1]; //Delivery
						var sReason = oMsg[2]; //Cancelled Reason 
						if (sReason === undefined) {
							sReason = "";
						}
						var sCancelDelNumMsg = "";
						if (sRegion === "EU") {
							var sCancelledDeliveryMsgEU = i18nModel.getModel("i18n").getProperty('cancelledDeliveryMsgEU');
							sCancelDelNumMsg = sCancelledDeliveryMsgEU.replace("{delNumber}", sDelNum);
						} else {
							var sDltcanclDelMsgNotEU = i18nModel.getModel("i18n").getProperty('dltcanclDelMsgNotEU');
							sCancelDelNumMsg = sDltcanclDelMsgNotEU.replace("{delNumber}", sDelNum);
						}
						MessageBox.show(
							sCancelDelNumMsg, {
								icon: MessageBox.Icon.ERROR,
								title: i18nModel.getModel("i18n").getProperty('submitError'),
								actions: [sap.m.MessageBox.Action.OK],
								onClose: function(oAction) {
									if (oAction === "OK") {
										var oRouter = sap.ui.core.UIComponent.getRouterFor(that);
										oRouter.navTo("CheckIn");
									}
								}.bind(that)
							});
					} else {
						if (errorMessage === "Live checkin is not possible") {
							trailerSubmitError = i18nModel.getModel("i18n").getProperty('liveErrorMsg');
						} else {
							trailerSubmitError = i18nModel.getModel("i18n").getProperty('trailerSubmitError');
						}
						MessageBox.show(
							trailerSubmitError, {
								icon: MessageBox.Icon.ERROR,
								title: i18nModel.getModel("i18n").getProperty('submitError'),
								actions: [sap.m.MessageBox.Action.OK],
								onClose: function(oAction) {
									if (oAction === "OK") {
										that.onDecline();
									}
								}.bind(that)
							});
					}

				}
			});

		},

		getRouter: function() {
			return sap.ui.core.UIComponent.getRouterFor(this);
		},

		//------------Cancel button functionality-------------//

		onTrailerCancel: function() {
			jQuery.sap.storage(jQuery.sap.storage.Type.local).put("PageType", "");
			oInsCreateDailog.open();
			var oRouter = sap.ui.core.UIComponent.getRouterFor(this);
			oRouter.navTo("CheckIn");
			if (sap.ui.getCore().byId("chepOrderNo") !== undefined) {
				sap.ui.getCore().byId("chepOrderNo").setText("");
			}
			this.byId("reg_Id").setValue("");
			this.byId("Trailer_Id").setValue("");
			this.byId("size").setSelectedKey("");
			this.byId("driver_Name").setValue("");
			this.byId("companyScacode").setValue("");
			this.byId("sizecompany").setSelectedKey("");
			this.byId("Mobile_Num").setValue("");
			this.byId("countryCode").setSelectedKey("");
			this.byId("transportNameSelect").setVisible(false);
			// this.byId("transportNameSelect").setSelectedKey("");
			this.byId("transportNameSelect").setValue("");
			ContractResults = [];
			var lableTransportName = this.getOwnerComponent().getModel("i18n").getProperty("transportName");
			this.getView().byId("transportname").setText(lableTransportName);
			oInsCreateDailog.close();
		},

		onListOfDel: function() {
			oInsCreateDailog.open();
			if (!listMilkDialog) {
				listMilkDialog = sap.ui.xmlfragment("fragTrail", "chep.checkin.fragments.ListOfDeliveries", this);
				this.getView().addDependent(listMilkDialog);
			}
			jQuery.sap.syncStyleClass("sapUiSizeCompact", this.getView(), this.listDelvDialog);
			var milkRunListData = jQuery.sap.storage(jQuery.sap.storage.Type.local).get("milkRunList");
			var tipMilkList1 = jQuery.sap.storage(jQuery.sap.storage.Type.local).get("tipReloadList");

			if (milkRunListData !== undefined) {
				if (milkRunListData.length > 0) {
					sap.ui.getCore().byId("fragTrail--DetailTable_ID").setVisible(true);
					var milkoModel = new sap.ui.model.json.JSONModel({
						"results": milkRunListData
					});
					sap.ui.getCore().byId("fragTrail--DetailTable_ID").setModel(milkoModel, "deliveryMod");
				} else {
					sap.ui.getCore().byId("fragTrail--DetailTable_ID").setVisible(false);
					sap.ui.getCore().byId("fragTrail--tipTableId").setVisible(true);
				}

			}
			if (tipMilkList1 !== undefined) {
				if (tipMilkList1.length > 0) {
					sap.ui.getCore().byId("fragTrail--tipTableId").setVisible(true);
					var tipoModel = new sap.ui.model.json.JSONModel({
						"results": tipMilkList1
					});
					sap.ui.getCore().byId("fragTrail--tipTableId").setModel(tipoModel, "tipListMod");
				} else {
					sap.ui.getCore().byId("fragTrail--tipTableId").setVisible(false);
					sap.ui.getCore().byId("fragTrail--DetailTable_ID").setVisible(true);

				}

			}
			oInsCreateDailog.close();
			listMilkDialog.open();
		},
		onItemDeleteTip: function(e) {
			oInsCreateDailog.open();
			if (e.getSource().getParent().getParent().getItems().length > 0) {
				var path1 = e.getSource().oPropagatedProperties.oBindingContexts.tipListMod.sPath;
				var index = parseInt(path1.substring(path1.lastIndexOf('/') + 1));
				var m = e.getSource().getModel("tipListMod");
				var d = m.getData().results;
				d.splice(index, 1);
				m.setProperty("/results", d);
				tipMilkList = e.getSource().getModel("tipListMod").getData().results;
				jQuery.sap.storage(jQuery.sap.storage.Type.local).put("tipReloadList", tipMilkList);
				oInsCreateDailog.close();
			}
		},
		onItemDelete: function(e) {
			oInsCreateDailog.open();
			if (e.getSource().getParent().getParent().getItems().length > 0) {
				var path1 = e.getSource().oPropagatedProperties.oBindingContexts.deliveryMod.sPath;
				var index = parseInt(path1.substring(path1.lastIndexOf('/') + 1));
				var m = e.getSource().getModel("deliveryMod");
				var d = m.getData().results;
				d.splice(index, 1);
				m.setProperty("/results", d);
				storeTraMilk = e.getSource().getModel("deliveryMod").getData().results;
				jQuery.sap.storage(jQuery.sap.storage.Type.local).put("milkRunList", storeTraMilk);
				oInsCreateDailog.close();
			}
		},

		onListDeliveriesOK: function() {
			listMilkDialog.close();
		},

		//--------Function for Hiding the Remove Icon from the List of deliveries Table--------//

		TipForAddDelivery: function(oEvent) {
			if (sDelType === "I") {
				if (oEvent.getSource().getItems()[0] !== undefined) {
					if (sap.ui.getCore().byId(oEvent.getSource().getItems()[0].getAggregation("cells")[1].getId()) !== undefined) {
						sap.ui.getCore().byId(oEvent.getSource().getItems()[0].getAggregation("cells")[1].getId()).setVisible(false);
					}
				}
			} else {
				if (oEvent.getSource().getItems()[0] !== undefined) {
					if (sap.ui.getCore().byId(oEvent.getSource().getItems()[0].getAggregation("cells")[1].getId()) !== undefined) {
						sap.ui.getCore().byId(oEvent.getSource().getItems()[0].getAggregation("cells")[1].getId()).setVisible(true);
					}
				}
			}

		},

		onUpdateFinishForAddDelivery: function(oEvent) {
			if (sDelType === "R") {
				if (oEvent.getSource().getItems()[0] !== undefined) {
					if (sap.ui.getCore().byId(oEvent.getSource().getItems()[0].getAggregation("cells")[1].getId()) !== undefined) {
						sap.ui.getCore().byId(oEvent.getSource().getItems()[0].getAggregation("cells")[1].getId()).setVisible(false);
					}
				}
			} else {
				if (oEvent.getSource().getItems()[0] !== undefined) {
					if (sap.ui.getCore().byId(oEvent.getSource().getItems()[0].getAggregation("cells")[1].getId()) !== undefined) {
						sap.ui.getCore().byId(oEvent.getSource().getItems()[0].getAggregation("cells")[1].getId()).setVisible(true);
					}
				}
			}

		},

		//----------------------------------------------------------------------------------
		//Function to create Busy Dialog
		//----------------------------------------------------------------------------------
		fnCreateBusyDialog: function(sImage) {
			var that = this;
			oInsCreateDailog = new sap.m.Dialog({
				showHeader: false
			}).addStyleClass("busyDialog sapUiTinyMargin");
			var sComponentName = that.getOwnerComponent().getMetadata().getComponentName();
			var imgUrl = $.sap.getModulePath(sComponentName, "/images/");
			var oImage = new sap.m.Image().addStyleClass("sapUiMediumMargin");
			oImage.setSrc(imgUrl + sImage);
			oInsCreateDailog.addContent(oImage);
			oInsCreateDailog.open();
		},

		//----------------------------------------------------------------------------------
		//Function to set logged in User Date pattern
		//----------------------------------------------------------------------------------
		fnSetUserDateFormat: function(rDate, sInsDateFormat) {
			if (rDate !== "") {
				var dFormDate;
				switch (sInsDateFormat) {
					case "1":
						dFormDate = rDate.slice(6, 8) + "." + rDate.slice(4, 6) + "." + rDate.slice(0, 4);
						break;
					case "2":
						dFormDate = rDate.slice(4, 6) + "/" + rDate.slice(6, 8) + "/" + rDate.slice(0, 4);
						break;
					case "3":
						dFormDate = rDate.slice(4, 6) + "-" + rDate.slice(6, 8) + "-" + rDate.slice(0, 4);
						break;
					case "4":
						dFormDate = rDate.slice(0, 4) + "." + rDate.slice(4, 6) + "." + rDate.slice(6, 8);
						break;
					case "5":
						dFormDate = rDate.slice(0, 4) + "/" + rDate.slice(4, 6) + "/" + rDate.slice(6, 8);
						break;
					case "6":
						dFormDate = rDate.slice(0, 4) + "-" + rDate.slice(4, 6) + "-" + rDate.slice(6, 8);
						break;
					case "A":
						dFormDate = rDate.slice(0, 4) + "/" + rDate.slice(4, 6) + "/" + rDate.slice(6, 8);
						break;
					case "B":
						dFormDate = rDate.slice(0, 4) + "/" + rDate.slice(4, 6) + "/" + rDate.slice(6, 8);
						break;
					case "C":
						dFormDate = rDate.slice(0, 4) + "/" + rDate.slice(4, 6) + "/" + rDate.slice(6, 8);
						break;
				}
			} else {
				var dFormDate = "";
			}
			return dFormDate;
		},

		//----------------------------------------------------------------------------------
		//Back button functionality
		//----------------------------------------------------------------------------------
		onNavBack: function() {
			jQuery.sap.storage(jQuery.sap.storage.Type.local).put("PageType", "");
			// jQuery.sap.storage(jQuery.sap.storage.Type.local).put("sLiveBtnPress", "");
			jQuery.sap.storage(jQuery.sap.storage.Type.local).put("sDandHBtnPress", "");
			jQuery.sap.storage(jQuery.sap.storage.Type.local).put("DeliveryNumber", "");
			oInsCreateDailog.open();
			var oRouter = sap.ui.core.UIComponent.getRouterFor(this);
			oRouter.navTo("CheckIn");
			// this.byId("orderNum").setText("");
			if (sap.ui.getCore().byId("chepOrderNo") !== undefined) {
				sap.ui.getCore().byId("chepOrderNo").setText("");
			}
			this.byId("reg_Id").setValue("");
			this.byId("Trailer_Id").setValue("");
			this.byId("size").setSelectedKey("");
			this.byId("driver_Name").setValue("");
			this.byId("companyScacode").setValue("");
			this.byId("sizecompany").setSelectedKey("");
			this.byId("Mobile_Num").setValue("");
			this.byId("countryCode").setSelectedKey("");
			this.byId("companyScacode").setVisible(false);
			this.byId("transportname").setVisible(false);
			this.byId("transportNameSelect").setVisible(false);

			// this.byId("transportNameSelect").setSelectedKey("");
			this.byId("transportNameSelect").setValue("");
			ContractResults = [];
			var lableTransportName = this.getOwnerComponent().getModel("i18n").getProperty("transportName");
			this.getView().byId("transportname").setText(lableTransportName);
			this.CustomerFlag = "";
			oInsCreateDailog.close();
			// this.byId("trailertype").setValue("");
			// this.getView().byId("addDelv").setVisible(false);
			// this.getView().byId("DetailTable_ID").setVisible(false);
		},

		//For TrailerID info Button
		onTrailerInfoPress: function(oEvent) {
			var that = this;
			var lableTransportName = that.getOwnerComponent().getModel("i18n").getProperty("trailerInfo");
			var trailerinfo = that.getView().getModel("i18n").getProperty('trailerIDInfo');
			var oMessage = trailerinfo;
			MessageBox.show(
				oMessage, {
					icon: sap.m.MessageBox.Icon.INFORMATION,
					title: lableTransportName //"Error during submitting!"
				});
		},
		onHaulierDeleveryPress: function() {
			var that = this;
			that.fnCreateBusyDialog("pallet.svg");
			// sDelnum = jQuery.sap.storage(jQuery.sap.storage.Type.local).get("DeliveryNumber");

			if (!this.addDeleveryDilogue) {
				this.addDeleveryDilogue = sap.ui.xmlfragment("chep.checkin.fragments.adddeleveryDetails", this);
				this.getView().addDependent(this.addDeleveryDilogue);
			}
			jQuery.sap.syncStyleClass("sapUiSizeCompact", this.getView(), this.addDeleveryDilogue);
			this.addDeleveryDilogue.open();
		},
		/* Multiple Glid submission*/
		onHaulierSubmit: function() {
			var that = this;
			var NewHolierData = that.getView().getModel("HolierModeldata").getData();
			that.fnCreateBusyDialog("pallet.svg");
			NewHolierData.forEach(function(item) {
				item.Werks = vLoadPlant;
				item.Glid = item.Lifnr;
				item.Signi = zSigni;
				item.Lfimg = item.quantity.toString();
				item.Zcintime = ztimestamp;
				item.PCODE = item.productCode;
				delete item.GlidEditable;
				delete item.noGlid;
				delete item.glidempty;
				delete item.Lifnr;
				delete item.quantity;
				delete item.newGlid;
				delete item.glidRegion;
				delete item.parentId;
				delete item.nodeid;
				delete item.productCode;
			});
			var oEntry = {
				Werks: vLoadPlant,
				UAMutliGlid_Navig: NewHolierData
			};
			var oModelHoulier = that.getOwnerComponent().getModel("createMod");
			oModelHoulier.create("/UAMultiGlidsSet", oEntry, {
				success: function() {
					oInsCreateDailog.close();
				},
				error: function(err) {
					MessageBox.show(err);
					oInsCreateDailog.close();
				}
			});

		},
		/*Open Haulier Fragment for GLIDs*/
		HaulierDetailsHelp: function(oEvent) {
			var that = this;
			that.oSelcteedInput = oEvent.getSource().getBindingContext("NewrowModel");
			// that.getView().getModel("CustmerModel").setProperty("/CustmerButon", false);
			if (!that.HaulierDilog) {
				that.HaulierDilog = sap.ui.xmlfragment("chep.checkin.fragments.HaulierGlid", that);
				that.getView().addDependent(that.HaulierDilog);
			}
			that.HaulierDilog.open();
			if (sRegion === "US") {
				var sServiceUrl = "/sap/opu/odata/sap/ZGW_CHECKIN_SRV";
				var oModel = new sap.ui.model.odata.ODataModel(sServiceUrl);
				oModel.read("/CupuTrpsSet?$filter=Scacgrp eq '" + vLoadPlant + "' and Scac eq '" + "CUPU" + "' ", null, null, false,
					function(oData) {
						var oODataJSONModel2 = new sap.ui.model.json.JSONModel();
						oODataJSONModel2.setData(oData.results);
						that.getView().setModel(oODataJSONModel2, "GlidHaulierModel");
					},
					function(error) {
						MessageBox.show(error);
						that.HaulierDilog.close();
					});
			} else if (sRegion === "EU") {
				var oModelDetails = that.getOwnerComponent().getModel("createMod");
				var sProductCodeFilter = [];
				sProductCodeFilter.push(new sap.ui.model.Filter("Plant", sap.ui.model.FilterOperator.EQ, vLoadPlant));
				sProductCodeFilter.push(new sap.ui.model.Filter("OrdType", sap.ui.model.FilterOperator.EQ, 'SNRAR'));
				sProductCodeFilter.push(new sap.ui.model.Filter("OrderType", sap.ui.model.FilterOperator.EQ, 'ASTREC'));
				sProductCodeFilter.push(new sap.ui.model.Filter("Spras", sap.ui.model.FilterOperator.EQ, sLanguage));
				oModelDetails.read("/ProductsSet", {
					filters: sProductCodeFilter,
					success: function(oData) {
						oInsCreateDailog.close();
						var ProductObj = [{
							"Lifnr": oData.Prodcode,
							"Name1": oData.Glidname
						}];
						var ProductCodeObj = new sap.ui.model.json.JSONModel(ProductObj);
						that.getView().setModel(ProductCodeObj, "GlidHaulierModel");
						that.getView().getModel("GlidHaulierModel").refresh(true);
					},
					error: function(oError) {
						MessageBox.show(oError);
					}
				});
			}
		},
		// selected item bind to the Input
		onHaulierChange: function(oEvent) {
			var that = this;
			var oSelectedItem = oEvent.getParameter("listItem");
			var sPath = oSelectedItem.getBindingContextPath();
			var oEntry = oSelectedItem.getBindingContext("GlidHaulierModel").getProperty(sPath);
			var sGlid = oEntry.Lifnr;
			var GlidModel = that.getView().getModel("NewrowModel");
			var oGlidData = GlidModel.getData();
			var Index = oGlidData.findIndex(function(item) {
				return item.Lifnr === sGlid;
			});
			if (Index === -1) {
				var oObj = that.oSelcteedInput.getObject();
				var aPath = that.oSelcteedInput.getPath();
				oObj.Lifnr = sGlid;
				that.getView().getModel("NewrowModel").setProperty(aPath, oObj, that.oSelcteedInput, true);
			} else {
				var submitError = that.getView().getModel("i18n").getProperty('glidsubmit');
				var submitGlid = that.getView().getModel("i18n").getProperty('glidValidation');
				var oMessage = submitGlid; //"Please Enter Order Number";
				MessageBox.show(
					oMessage, {
						icon: sap.m.MessageBox.Icon.ERROR,
						title: submitError //"Error during submitting!"
					});
			}
			that.HaulierDilog.close();
		},
		onHaulierclose: function() {
			var that = this;
			that.HaulierDilog.destroy();
			that.HaulierDilog = null;
		},
		onGlidCancel: function() {
			var that = this;
			that.HaulierDilog.close();
			that.HaulierDilog.destroy();
			that.HaulierDilog = null;
		},
		onCustmerData: function() {
			var that = this;
			var oTableData = that.getView().byId("TableData");
		},
		/*Live Search search GLID & Customer Name*/
		glidSearchName: function(oEvent) {
			var that = this;
			var aFilters = [];
			var sData = oEvent.getSource().getValue();
			if (sData && sData.length > 0) {
				var filter = new Filter("Lifnr", sap.ui.model.FilterOperator.Contains, sData);
				aFilters.push(filter);
			}
			var list = sap.ui.getCore().byId("TableData");
			var binding = list.getBinding("items");
			binding.filter(aFilters, "Application");
			var oTableData = oEvent.getSource().getParent().getContent()[1];
			var oTableItems = oTableData.getItems();
			var oItems = oEvent.getSource().getValue();

			/*for US region CUstmer Glid Selection if there is no Custmer Found Start*/
			if (sRegion === "US") {
				if (oTableItems.length === 0 && oItems.length === 10) {
					oInsCreateDailog.open();
					var oModelHoulier = that.getOwnerComponent().getModel("createMod");
					oModelHoulier.read("/UAGlidsSet(Werks='" + vLoadPlant + "',Glid='" + sData + "')", {
						success: function(oData) {
							oInsCreateDailog.close();
							var CustObj = [{
								"Lifnr": oData.Glid,
								"Name1": oData.Glidname
							}];
							aFilters = [];
							var CustObjData = new sap.ui.model.json.JSONModel(CustObj);
							CustObj = {};
							that.getView().setModel(CustObjData, "GlidHaulierModel");
							that.getView().getModel("GlidHaulierModel").refresh(true);
						},
						error: function() {
							aFilters = [];
							oInsCreateDailog.close();
							var submitError = that.getView().getModel("i18n").getProperty('glidsubmit');
							var CustErr = that.getView().getModel("i18n").getProperty('noCustmerFound');
							var oMessage = CustErr; //"Please Enter Order Number";
							MessageBox.show(
								oMessage, {
									icon: sap.m.MessageBox.Icon.ERROR,
									title: submitError //"Error during submitting!"
								});
						}
					});
				}
				// 		/*for US region CUstmer Glid Selection if there is no Custmer Found END*/

			}
		},
		/*Add New Haulier GLID*/
		onAddnewGlidDeatil: function(oEvent) {
			var that = this;
			var oParentObj = oEvent.getSource().getBindingContext("NewrowModel").getObject(); // EU changes
			var sObj = {
				Lifnr: "",
				quantity: "",
				Zcintime: "",
				Lfimg: "",
				Werks: "",
				GlidEditable: true,
				glidempty: "",
				noGlid: false,
				newGlid: false,
				glidRegion: false,
				productCode: "",
				parentId: null,
				nodeid: 0
			};
			if (sRegion === "US" || sRegion === "ZA" || sRegion === "LATAM") {
				sObj.newGlid = true;
				sObj.glidRegion = false;
			}
			var oViewData = that.getView().getModel("NewrowModel").getData();
			if (oParentObj.parentId === null) {
				sObj.parentId = oParentObj.nodeid;
			} else {
				sObj.parentId = oParentObj.parentId; // Assigning parent id of child	
			}
			if (sRegion === "EU") {
				sObj.Lifnr = oParentObj.Lifnr;
			}
			sObj.nodeid = oViewData.length;
			oViewData.push(sObj);

			this.getView().getModel("NewrowModel").setData(oViewData);
			this.getView().getModel("NewrowModel").refresh(true);
		},
		/* Delete Glid And Validation for EU region*/
		onDeleteGLIDDeatil: function(oEvent) {
			var that = this;
			var indexData;
			var oModel = that.getView().getModel("NewrowModel");
			var Odata = oModel.getData();
			var oContext = oEvent.getSource().getBindingContext("NewrowModel");
			var oObject = oContext.getObject();
			var arr = [];
			if (Odata.length > 1) {
				if (sRegion === "EU") {
					if (oObject.parentId === null) {
						Odata.forEach(function(item, index) {
							if (item.nodeid === oObject.nodeid || item.parentId === oObject.nodeid) {
								arr.push(index);
							}
						});
						if (arr.length > 0) {
							var reverse = [].concat(arr).reverse();
							reverse.forEach(function(index) {
								if (index !== 0) {
									Odata.splice(index, 1);
								} else {
									var submitError = that.getView().getModel("i18n").getProperty('glidsubmit');
									var submitGlid = that.getView().getModel("i18n").getProperty('deleteGlidValidation');
									var oMessage = submitGlid; //"Please Enter Order Number";
									MessageBox.show(
										oMessage, {
											icon: sap.m.MessageBox.Icon.ERROR,
											title: submitError //"Error during submitting!"
										});

								}
							});
						}
						oModel.setData(Odata);
						oModel.refresh(true);
					} else {
						indexData = oContext.getPath().split("/")[1];
						Odata.splice(indexData, 1);
						that.getView().getModel("NewrowModel").setData(Odata);
						that.getView().getModel("NewrowModel").refresh(true);
					}
				} else {
					indexData = oContext.getPath().split("/")[1];
					Odata.splice(indexData, 1);
					that.getView().getModel("NewrowModel").setData(Odata);
					that.getView().getModel("NewrowModel").refresh(true);
				}
			} else {
				var submitError = that.getView().getModel("i18n").getProperty('glidsubmit');
				var submitGlid = that.getView().getModel("i18n").getProperty('deleteGlidValidation');
				var oMessage = submitGlid; //"Please Enter Order Number";
				MessageBox.show(
					oMessage, {
						icon: sap.m.MessageBox.Icon.ERROR,
						title: submitError //"Error during submitting!"
					});
			}
		},
		/*----Save Haulier GLID Details---*/
		onsaveHaulierGlid: function() {
			var that = this;
			var Odata = this.getView().getModel("NewrowModel").getData();
			var SaveVal = [];
			Odata.forEach(function(item, index) {
				if (sRegion === "EU") {
					if (item.Lifnr === "" && item.noGlid === false && item.parentId === null) {
						SaveVal.push(index);
					} else if (item.quantity === "") {
						SaveVal.push(index);
					} else if (item.productCode === "") {
						SaveVal.push(index);
					}
				} else {
					if (item.Lifnr === "" && item.noGlid === false) {
						SaveVal.push(index);
					} else if (item.quantity === "") {
						SaveVal.push(index);
					}
				}
			});
			if (SaveVal.length === 0) {
				var oHolirModel = new sap.ui.model.json.JSONModel(Odata);
				that.getView().setModel(oHolirModel, "HolierModeldata");
				sap.ui.getCore().byId("errorTextShow").setVisible(false);
				that.getView().byId("holierAcceptd").setVisible(true);
				that.getView().byId("noHoliuerId").setVisible(false);
				oInsCreateDailog.close();
				that.addDeleveryDilogue.close();
			} else {
				sap.ui.getCore().byId("errorTextShow").setVisible(true);
			}
		},
		/*----Check glid Enable/ Desable---*/
		onNoGlidCheck: function(oEvent) {
			var that = this;
			var oGlidCheck = oEvent.getParameter("selected");
			var oContext = oEvent.getSource().getBindingContext("NewrowModel");
			var oPath = oContext.getPath();
			var oObject = oContext.getObject();
			var oGlidCheckVal = oContext.getModel("NewrowModel");
			var GlidData = oGlidCheckVal.getData();

			if (GlidData.length > 1) { // Checks Glid Data Length
				var oIndex = [];
				GlidData.forEach(function(item, index) {
					if (item.noGlid === true) {
						oIndex.push(index);
					}
				});
				if (oIndex.length > 1) { // checks  previous Glid  checked or not 
					oEvent.getSource().setSelected(false);
					var submitError = this.getView().getModel("i18n").getProperty('glidsubmit');
					var submitGlid = this.getView().getModel("i18n").getProperty('glidValidation');
					var oMessage = submitGlid; //"Please Enter Order Number";
					MessageBox.show(
						oMessage, {
							icon: sap.m.MessageBox.Icon.ERROR,
							title: submitError //"Error during submitting!"
						});
				} else { // if check Box length one ingoring error message
					if (oGlidCheck === true) {
						oObject.GlidEditable = false;
						oObject.Lifnr = "";
					} else {
						oObject.GlidEditable = true;
					}

				}
			} else { // if glid data length equal to One
				if (oGlidCheck === true) {
					oObject.GlidEditable = false;
					oObject.Lifnr = "";
					// oEvent.getSource().setValueState(sap.ui.core.ValueState.None);
				} else {
					oObject.GlidEditable = true;
				}
			}
			that.getView().getModel("NewrowModel").setProperty(oPath, oObject, oContext, true);
		},

		/*--- Cancel Haulier Details ---*/
		oncancelHaulierGlid: function() {
			var that = this;
			var oModel = new sap.ui.model.json.JSONModel([{
				Lifnr: "",
				quantity: "",
				Zcintime: "",
				Lfimg: "",
				Werks: "",
				GlidEditable: true,
				glidempty: "",
				noGlid: false
			}]);
			that.getView().setModel(oModel, "NewrowModel");
			that.getView().byId("holierAcceptd").setVisible(false);
			that.getView().byId("noHoliuerId").setVisible(true);

			oInsCreateDailog.close();
			that.addDeleveryDilogue.close();
		},
		/*---Validation for Quantity inout accepts only positive numbers---*/
		QuantityVal: function(oEvent) {
			var QtyInput = oEvent.getSource();
			var val = QtyInput.getValue();
			val = val.replace(/[^\d]/g, '');
			QtyInput.setValue(val);
		},
		/*Add new GLID for Another Customer*/
		onAddAnotherCustmr: function() {
			var that = this;
			var sObj = {
				Lifnr: "",
				quantity: "",
				Zcintime: "",
				Lfimg: "",
				Werks: "",
				GlidEditable: true,
				glidempty: "",
				noGlid: false,
				glidRegion: false,
				newGlid: true,
				productCode: "",
				parentId: null,
				nodeid: 0
			};
			var oViewData = that.getView().getModel("NewrowModel").getData();
			sObj.nodeid = oViewData.length;
			oViewData.push(sObj);
			that.getView().getModel("NewrowModel").setData(oViewData);
			that.getView().getModel("NewrowModel").refresh(true);
		},
		/* On Customer Validation for Non -US Regions(EU,LATAM,ZA)*/
		onCustLiveChange: function(oEvent) {
			var that = this;
			var oModel = that.getView().getModel("NewrowModel");
			var oData = oModel.getData();
			var oContext = oEvent.getSource().getBindingContext("NewrowModel");
			var sObj = oContext.getObject();
			var sData = oEvent.getParameter("value");
			var oInput = oEvent.getSource().getValue().length; // Entered Input Length
			if (oInput === 10 && sRegion !== "US") { // checks custmer length
				var index = oData.findIndex(function(item) {
					return item.Lifnr === sData;
				});
				if (index === -1) {
					oEvent.getSource().setValueState(sap.ui.core.ValueState.None);
					oInsCreateDailog.open();
					var sServiceUrl = "/sap/opu/odata/sap/ZGW_CHECKIN_SRV";
					var sModel = new sap.ui.model.odata.ODataModel(sServiceUrl);
					sModel.read("/UAGlidsSet(Werks='" + vLoadPlant + "',Glid='" + sData + "')", {
						success: function(oData) {
							oInsCreateDailog.close();
						},
						error: function() {
							oInsCreateDailog.close();
							sObj.Lifnr = "";
							var submitError = that.getView().getModel("i18n").getProperty('glidsubmit');
							var CustErr = that.getView().getModel("i18n").getProperty('noCustmerFound'); // checks customer length if err
							var oMessage = CustErr; //"Please Enter Order Number";
							MessageBox.show(
								oMessage, {
									icon: sap.m.MessageBox.Icon.ERROR,
									title: submitError //"Error during submitting!"
								});
							that.getView().getModel("NewrowModel").refresh(true);
						}
					});
				} else {
					sObj.Lifnr = "";
					var i18n = that.getOwnerComponent();
					var pCustCodeErr = i18n.getModel("i18n").getProperty('CustNotSame');
					oEvent.getSource().setValueState("Error");
					oEvent.getSource().setValueStateText(pCustCodeErr);
					oInsCreateDailog.close();
				}
			} else {
				oInsCreateDailog.close();
				var i18nModel = that.getOwnerComponent();
				var CustmerGlid = i18nModel.getModel("i18n").getProperty('CustLength');
				oEvent.getSource().setValueState("Error");
				oEvent.getSource().setValueStateText(CustmerGlid);
			}
		},
		/*Product code dilogue for EU Region*/
		onProductCodeValue: function() {
			var that = this;
			var sUrl1 = "/sap/opu/odata/sap/ZGW_UNAUTHORIZED_SRV";
			var oPrdSetModel = new sap.ui.model.odata.ODataModel(sUrl1);
			var sProductCodeFilter = [];
			sProductCodeFilter.push(new sap.ui.model.Filter("Plant", sap.ui.model.FilterOperator.EQ, vLoadPlant));
			sProductCodeFilter.push(new sap.ui.model.Filter("OrdType", sap.ui.model.FilterOperator.EQ, 'SNRAR'));
			sProductCodeFilter.push(new sap.ui.model.Filter("OrderType", sap.ui.model.FilterOperator.EQ, 'ASTREC'));
			sProductCodeFilter.push(new sap.ui.model.Filter("Spras", sap.ui.model.FilterOperator.EQ, sLanguage));
			oPrdSetModel.read("/ProductsSet", {
				filters: sProductCodeFilter,
				success: function(oData) {
					oInsCreateDailog.close();
					var ProductCodeObj = new sap.ui.model.json.JSONModel(oData.results);
					that.getView().setModel(ProductCodeObj, "ProductModel");
				}
			});

			// var oModel = that.getView().getModel("NewrowModel");
			// var oData = oModel.getData();
			// var oContext = oEvent.getSource().getBindingContext("NewrowModel");
			// var sObj = oContext.getObject();
			// var oInputVal = oEvent.getSource().getValue();
			// if (sObj.parentId !== null && oInputVal !== " " && oInputVal !== "") {
			// 	var index = oData.findIndex(function(item) {
			// 		return (item.parentId === null) && (sObj.parentId === item.nodeid) && (oInputVal === item.productCode);
			// 	});
			// 	if (index === -1) {
			// 		oEvent.getSource().setValueState(sap.ui.core.ValueState.None);
			// 	} else {
			// 		var i18n = that.getOwnerComponent();
			// 		var productCodeErr = i18n.getModel("i18n").getProperty('ErrProductCode');
			// 		oEvent.getSource().setValueState("Error");
			// 		oEvent.getSource().setValueStateText(productCodeErr);
			// 	}
			// }

		},
		/* Product Code Validation for EU region */
		OnProductValidate: function(oEvent) {
			var that = this;
			if (sRegion === "EU") {
				var oModel = that.getView().getModel("NewrowModel");
				var oData = oModel.getData();
				var oContext = oEvent.getSource().getBindingContext("NewrowModel");
				var sObj = oContext.getObject();
				var oInputVal = oEvent.getSource().getValue();
				if (sObj.parentId !== null && oInputVal !== " " && oInputVal !== "") {
					var index = oData.findIndex(function(item) {
						return (item.parentId === null) && (sObj.parentId === item.nodeid) && (oInputVal === item.productCode);
					});
					if (index === -1) {
						oEvent.getSource().setValueState(sap.ui.core.ValueState.None);
					} else {
						var i18n = that.getOwnerComponent();
						var productCodeErr = i18n.getModel("i18n").getProperty('ErrProductCode');
						oEvent.getSource().setValueState("Error");
						oEvent.getSource().setValueStateText(productCodeErr);
					}
				}
			}
		},

		/*------------------- Start of Code - Function call when click on "Add Remito Details" Button -------------*/

		onAddRemitoDetails: function() {

			var that = this;
			var i18n = that.getOwnerComponent();

			if (!that.remitoDialg) {
				that.remitoDialg = sap.ui.xmlfragment("chep.checkin.fragments.addRemitoDetails", that);
				that.getView().addDependent(that.remitoDialg);
			}
			jQuery.sap.syncStyleClass("sapUiSizeCompact", that.getView(), that.remitoDialg);

			that.remitoDialg.open();

			var oTable = sap.ui.getCore().byId("tableId");

			var milkRunListData = jQuery.sap.storage(jQuery.sap.storage.Type.local).get("milkRunList");
			// var tipMilkList1 = jQuery.sap.storage(jQuery.sap.storage.Type.local).get("tipReloadList");
			// var sTipReloadArray = [];
			// if (milkRunListData.length !== 0 && tipMilkList1.length !== 0) {
			// 	sTipReloadArray = milkRunListData.concat(tipMilkList1);
			// } else if (milkRunListData.length !== 0) {
			// 	sTipReloadArray = milkRunListData;
			// }

			var oHeader = {};
			oHeader.WERKS = vLoadPlant;
			oHeader.DOC_ID = delNumberforSO;
			oHeader.QUERY = "R";
			var sRemitoDataArray = [];

			for (var mCount = 0; mCount < milkRunListData.length; mCount++) {
				var sItems = {
					"WERKS": milkRunListData[mCount].Plant,
					"DOC_ID": milkRunListData[mCount].chepdeliverynumber
					// "NFKEY": sTipReloadArray[mCount].NFKEY

				};
				sRemitoDataArray.push(sItems);
			}
			oHeader.HeaderItem_Nav = sRemitoDataArray;
			// 			oHeader.HEADER_ITEM_ASSOCSet = sRemitoDataArray;
			that.fnCreateBusyDialog("pallet.svg");
			that.getOwnerComponent().getModel("remitoDataModel").create("/ETS_HEADER", oHeader, {
				success: function(oData, oResponse) {
					if (oResponse.statusCode === 201 || oResponse.statusCode === "201") {
						oInsCreateDailog.close();
						that.RemitoDataFromService = oData.HeaderItem_Nav.results;
						var oModel1 = new sap.ui.model.json.JSONModel();
						oModel1.setData(oData.HeaderItem_Nav);
						oTable.setModel(oModel1, "RemitoNumDataModel");

					}
				},
				error: function(oError) {
					oInsCreateDailog.close();
					var oMessage;
					if (oMessage === undefined) {
						oMessage = JSON.parse(oError.responseText).error.message.value;
					}
					sap.m.MessageBox.show(
						oMessage, {
							icon: sap.m.MessageBox.Icon.ERROR,
							title: i18n.getModel("i18n").getProperty('error')
						});
				}
			});
		},

		/*------------------- End of Code - Function call when click on "Add Remito Details" Button -------------*/

		/*------------------- Start of Code - Remito Number Live Change in AddRemitoDetails Fragment -------------*/

		RemitoNumLiveChange: function(oEvent) {
			var oCurrentId = oEvent.getParameter("id");
			sap.ui.getCore().byId(oCurrentId).setValueState(sap.ui.core.ValueState.None);
		},

		/*------------------- End of Code - Remito Number Live Change in AddRemitoDetails Fragment -------------*/

		/*------------------- Start of Code - When click on Save Button in AddRemitoDetails Fragment -------------*/

		onSaveRemitoDetails: function() {

			var that = this;
			var otable = sap.ui.getCore().byId("tableId").getId();
			var sRemitoNumId = sap.ui.getCore().byId("RemitoID").getId();
			var sNotaDataModel = sap.ui.getCore().byId("tableId").getModel("RemitoNumDataModel").getData().results;
			var i18n = that.getOwnerComponent();
			var errorUpdateMsg = i18n.getModel("i18n").getProperty('remError');
			var sErrorArray = [];
			var sRemitoNumArray = [];
			for (var i = 0; i < sNotaDataModel.length; i++) {
				var eachRowId = sap.ui.getCore().byId(sRemitoNumId + "-" + otable + "-" + i);
				var sRemitoNumber = sNotaDataModel[i].NFKEY;
				if (sRemitoNumber === "") {
					eachRowId.setValueState(sap.ui.core.ValueState.Error);
					sErrorArray.push(sNotaDataModel[i].DOC_ID);
				} else {
					eachRowId.setValueState(sap.ui.core.ValueState.None);
					sRemitoNumArray.push(sNotaDataModel[i].NFKEY);
				}
			}

			if (sErrorArray.length > 0) {
				var displayErrorMessage = i18n.getModel("i18n").getProperty('enterRemitoNumber');
				sErrorArray.forEach(function(ele, j) {
					if (j === 0) {
						displayErrorMessage = i18n.getModel("i18n").getProperty('enterRemitoNumber') + " " + ele;
					} else {
						displayErrorMessage = displayErrorMessage + " " + " , " + ele;
					}
				});
				displayErrorMessage = displayErrorMessage;
				MessageBox.show(
					displayErrorMessage, {
						icon: sap.m.MessageBox.Icon.ERROR,
						title: errorUpdateMsg
					});
				return;
			} else {
				var sErrorMsgFlagCount = 0;
				var sRemitoNumValidation = i18n.getModel("i18n").getProperty('remitoNumValidationMsg');
				for (var j = 0; j < sRemitoNumArray.length; j++) {
					if (sRemitoNumArray[j].length < 8 || sRemitoNumArray[j].length > 12) {
						var eachRowId1 = sap.ui.getCore().byId(sRemitoNumId + "-" + otable + "-" + j);
						eachRowId1.setValueState(sap.ui.core.ValueState.Error);
						eachRowId1.setValueStateText(sRemitoNumValidation);
						sErrorMsgFlagCount = sErrorMsgFlagCount + 1;
					}
				}

				if (sErrorMsgFlagCount > 0) {
					MessageBox.show(
						sRemitoNumValidation, {
							icon: sap.m.MessageBox.Icon.ERROR,
							title: errorUpdateMsg
						});
				} else {
					var sFinalRemitoDataModel = sap.ui.getCore().byId("tableId").getModel("RemitoNumDataModel").getData().results;
					var aUniqueRemitoNumberArray = [];
					for (var jCount = 0; jCount < sFinalRemitoDataModel.length; jCount++) {
						if (aUniqueRemitoNumberArray.indexOf(sFinalRemitoDataModel[jCount].NFKEY) === -1) {
							aUniqueRemitoNumberArray.push(sFinalRemitoDataModel[jCount].NFKEY);
						}
					}
					if (sFinalRemitoDataModel.length !== aUniqueRemitoNumberArray.length) {
						var sduplicateRemitoMsg = i18n.getModel("i18n").getProperty('dupRemitoNumValidMsg');
						MessageBox.show(
							sduplicateRemitoMsg, {
								icon: sap.m.MessageBox.Icon.ERROR,
								title: errorUpdateMsg

							});
					} else {
						var sDataModel = sap.ui.getCore().byId("tableId").getModel("RemitoNumDataModel").getData().results;
						var oEntry = {};
						oEntry.WERKS = vLoadPlant;
						oEntry.DOC_ID = delNumberforSO;
						oEntry.QUERY = "S";
						// /oEntry.MULTI_DEL = sMulDelNum;
						var sRemitoDataArray = [];

						for (var kCount = 0; kCount < sDataModel.length; kCount++) {
							var sItemsData = {
								"WERKS": sDataModel[kCount].WERKS,
								"DOC_ID": sDataModel[kCount].DOC_ID,
								"NFKEY": sDataModel[kCount].NFKEY
							};
							sRemitoDataArray.push(sItemsData);
						}
						oEntry.HeaderItem_Nav = sRemitoDataArray;
						// 		oEntry.HEADER_ITEM_ASSOCSet = sRemitoDataArray;
						that.fnCreateBusyDialog("pallet.svg");
						that.getOwnerComponent().getModel("remitoDataModel").create("/ETS_HEADER", oEntry, {
							success: function(oData, oResponse) {
								if (oResponse.statusCode === 201 || oResponse.statusCode === "201") {
									oInsCreateDailog.close();
									that.RemitoDataFromService = oData.HeaderItem_Nav.results;
									var sRemitoDetailsAdded = i18n.getModel("i18n").getProperty('remitoDetailsAdded');
									that.getView().getModel("oPlantModel").setProperty("/remitoDetailsState", "Success");
									that.getView().getModel("oPlantModel").setProperty("/remitoDetailsText", sRemitoDetailsAdded);
									that.getView().getModel("oPlantModel").setProperty("/remitoIcon", "sap-icon://sys-enter-2");
									that.remitoDialg.close();
								}
							},
							error: function(oError) {
								oInsCreateDailog.close();
								var oMessage;
								if (oMessage === undefined) {
									oMessage = JSON.parse(oError.responseText).error.message.value;
								}
								sap.m.MessageBox.show(
									oMessage, {
										icon: sap.m.MessageBox.Icon.ERROR,
										title: i18n.getModel("i18n").getProperty('error')
									});
							}
						});
					}
				}
			}
		},

		/*------------------- End of Code - When click on Save Button in AddRemitoDetails Fragment -------------*/

		/*------------------- Start of Code - When click on Cancel Button in AddRemitoDetails Fragment -------------*/

		onCancelRemitoDetails: function() {
			var that = this;
			var i18n = that.getOwnerComponent();
			var sNoRemitoDetailsText = i18n.getModel("i18n").getProperty('remitoDetailsNotAdded');
			var sRemitoDetailsAdded = i18n.getModel("i18n").getProperty('remitoDetailsAdded');
			var sRemitoData = that.RemitoDataFromService;
			var sRemitoNumData = $.grep(sRemitoData, function(e) {
				return e.NFKEY !== "";
			});

			if (sRemitoNumData.length > 0) {
				that.getView().getModel("oPlantModel").setProperty("/remitoDetailsState", "Success");
				that.getView().getModel("oPlantModel").setProperty("/remitoDetailsText", sRemitoDetailsAdded);
				that.getView().getModel("oPlantModel").setProperty("/remitoIcon", "sap-icon://sys-enter-2");
			} else {
				that.getView().getModel("oPlantModel").setProperty("/remitoDetailsState", "Error");
				that.getView().getModel("oPlantModel").setProperty("/remitoDetailsText", sNoRemitoDetailsText);
				that.getView().getModel("oPlantModel").setProperty("/remitoIcon", "sap-icon://sys-cancel-2");
			}
			that.remitoDialg.close();
		},

		/*------------------- End of Code - When click on Cancel Button in AddRemitoDetails Fragment -------------*/

		/*------------------- Start of Code - Function call after AddRemitoDetails Fragment Close -------------*/

		onAfterRemitoDialogClose: function() {
			var that = this;

			if (sap.ui.getCore().byId("remitoDailogId") !== undefined) {
				sap.ui.getCore().byId("remitoDailogId").destroy();
			}
			if (sap.ui.getCore().byId("RemitoID") !== undefined) {
				sap.ui.getCore().byId("RemitoID").destroy();
			}
			if (that.remitoDialg) {
				that.remitoDialg = null;
			}
		}

		/*------------------- End of Code - Function call after AddRemitoDetails Fragment Close -------------*/

	});
});