var loggedUser;
var empNameID;
var vLoadPlant;
var oInsCreateDailog;
var snoticecheck;
var sdanbrocheck;
var sysLang;
var kioskId;
var sCheDateFormat;
var sRegion;
var agreementData;
var sLanguage;
var sapLanguage;
var pgmodel;
var sParentPlant;
var sLangConfgFlg;

sap.ui.define([
	"sap/ui/core/mvc/Controller",
	"sap/m/MessageBox",
	"sap/ui/model/json/JSONModel",
	"chep/checkin/model/formatter"

], function(Controller, MessageBox, JSONModel, formatter) {
	"use strict";
	return Controller.extend("chep.checkin.controller.Agreement", {

		formatter: formatter,

		onInit: function() {
			jQuery.sap.require("jquery.sap.storage");

			this.getView().byId("navBack").setVisible(false);
			var oRouter = sap.ui.core.UIComponent.getRouterFor(this);
			oRouter.getRoute("Agreement").attachPatternMatched(this._onObjectMatched, this);
			var that = this;
			var model = new JSONModel({ // start - model used for displaying the page numbers
				"gridVisible": true,
				"noRecordsInfoLabel": false,
				"continueBtn": true,
				"languageHeaderBar": true,
				"cacheButtonVis": false
			});
			that.getView().setModel(model, "fragmentViewModel");

			pgmodel = new JSONModel({ // start - model used for displaying the page numbers
				"pgStart": "0",
				"pgEnd": "0"
			});
			that.getView().setModel(pgmodel, "pgmodel");
			that.fnCreateBusyDialog("pallet.svg");
			var y = "/sap/bc/ui2/start_up";
			var xmlHttp = null;
			xmlHttp = new XMLHttpRequest();
			xmlHttp.onreadystatechange = function() {
				if (xmlHttp.readyState === 4 && xmlHttp.status === 200) {
					var oUserData = JSON.parse(xmlHttp.responseText);
					loggedUser = oUserData.id;
					empNameID = oUserData.fullName;
					sCheDateFormat = oUserData.dateFormat;
					jQuery.sap.storage(jQuery.sap.storage.Type.local).put("EmpName", empNameID);
					that.getView().byId("empNameID").setText(empNameID);
					//	that.getView().byId("pageNo").setText("1 of 5");
					that.getView().getModel("pgmodel").setProperty("/pgStart", "1");
					that.getView().getModel("pgmodel").setProperty("/pgEnd", "5");
					// id of subheader
					that.byId("Header_Desktop_Bar_ID").setVisible(true);
				}
			};
			xmlHttp.open("GET", y, false);
			xmlHttp.send(null);

			//--------------------------------------
			// To get URL parameters
			//--------------------------------------
			$.urlParam = function(name) {
				var results = new RegExp('[\?&]' + name + '=([^&#]*)').exec(window.location.href);
				if (results == null) {
					return null;
				} else {
					return decodeURI(results[1]) || 0;
				}
			};
			//commented for language selection change
			sapLanguage = $.urlParam("sap-language");
			if (sapLanguage) {
				sapLanguage = sapLanguage.toUpperCase();
				sysLang = sapLanguage;
				sLanguage = sapLanguage;
				that.initialLanguage = sLanguage;
				// oModelLan = new sap.ui.model.resource.ResourceModel({
				// 	bundleName: "chep.checkin.i18n.i18n",
				// 	bundleLocale: sapLanguage
				// });
				// sap.ui.getCore().getConfiguration().setLanguage(sapLanguage);
			} else if (sap.ui.Device.system.tablet && !sap.ui.Device.system.desktop) {
				if (sapLanguage === null) {
					sapLanguage = sap.ui.getCore().getConfiguration().getLanguage();
					sLanguage = sapLanguage.toUpperCase();
					that.initialLanguage = sLanguage;
				} else {
					sapLanguage = "EN";
					sLanguage = sapLanguage;
					that.initialLanguage = sLanguage;
				}
				sysLang = sapLanguage;
				// oModelLan = new sap.ui.model.resource.ResourceModel({
				// 	bundleName: "chep.checkin.i18n.i18n",
				// 	bundleLocale: sapLanguage
				// });

			} else if (sap.ui.Device.system.desktop === true) {
				if (sapLanguage === null) {
					sapLanguage = sap.ui.getCore().getConfiguration().getLanguage();
					sLanguage = sapLanguage.toUpperCase();
					that.initialLanguage = sLanguage;
				} else {
					sapLanguage = "EN";
					sLanguage = sapLanguage;
					that.initialLanguage = sLanguage;
				}
				//	var vlanguage1 = sap.ui.getCore().getConfiguration().getLanguage();
				sysLang = sapLanguage;
				// oModelLan = new sap.ui.model.resource.ResourceModel({
				// 	bundleName: "chep.checkin.i18n.i18n",
				// 	bundleLocale: sapLanguage
				// });
			}

			//---------------------------------------------------------------------------------------------------------------------------------------------	
			// kioskId changes                                                                
			//----------------------------------------------------------------------------------------------------------------------------------------------	
			kioskId = $.urlParam("KIOSK_ID");

			//-----------------------------------------------------------------------------------------------------------------------------------------------	
			// Read the header data for bar
			//-----------------------------------------------------------------------------------------------------------------------------------------------
			var url = "/sap/opu/odata/sap/ZGW_DELIVERY_AP_SRV";
			var oModel = new sap.ui.model.odata.ODataModel(url);
			that.getOwnerComponent().getModel("flagsModel").setData({});
			oModel.read("/HeaderDetailsSet('" + loggedUser + "')", null, null, false,
				function success(oData, response) {
					if (response.statusCode === 200) {

						/* -------- Config base of Safety Message Text Visible---------*/
						var SafetyTxtDetails = new sap.ui.model.json.JSONModel();
						that.getView().setModel(SafetyTxtDetails, "SafetyTxtDetails");

						var safTxt = oData.SafetyTxt;
						// var safTxt = "false";
						if (safTxt === "false" || safTxt === false) {
							safTxt = false;
						} else if (safTxt === "true" || safTxt === true) {
							safTxt = true;
						}

						that.getView().getModel("SafetyTxtDetails").setProperty("/SafetyTxt", safTxt);

						/* -------- Config base of Safety Message Text Visible---------*/

						var oODataJSONModel2 = new sap.ui.model.json.JSONModel();
						oODataJSONModel2.setData(oData);
						that.getView().setModel(oODataJSONModel2, "HeaderDetails");

						sLangConfgFlg = oData.LangFlags;

						//---------Start of Multi Plant Changes----------// 

						sParentPlant = oData.ParentPlant;

						if (sParentPlant !== "") { // If MultiPlant config is true then we are sending parent plant otherwise sending login plant
							vLoadPlant = sParentPlant;
						} else {
							vLoadPlant = oData.Plant;
						}

						jQuery.sap.storage(jQuery.sap.storage.Type.local).put("ParentPlant", sParentPlant);

						//---------End of Multi Plant Changes----------// 

						jQuery.sap.storage(jQuery.sap.storage.Type.local).put("Plant", vLoadPlant);
						jQuery.sap.storage(jQuery.sap.storage.Type.local).put("Name", oData.Name1);
						jQuery.sap.storage(jQuery.sap.storage.Type.local).put("RemitoFlag", oData.RemitoFlag);
						oInsCreateDailog.close();
						// that.languageChangeService();

						//---------Start of Local Storage Code for Language Selection Dailogue----------// 

						if (sLangConfgFlg === "true" || sLangConfgFlg === true) {

							var sLangModelData = jQuery.sap.storage(jQuery.sap.storage.Type.local).get("langModelDataSelec");
							var sLocStorPlant = "";
							if (sLangModelData !== null && sLangModelData.length !== 0) {
								sLocStorPlant = sLangModelData[0].Werks;
							}
							if (sLangModelData !== null && sLocStorPlant === vLoadPlant) {
								that.onBindLanguageData(sLangModelData);
							} else {
								that.languageChangeService();
							}

						} else {
							that.languageChangeService();
						}

						//---------End of Local Storage Code for Language Selection Dailogue----------//

					}
				},
				function() {
					MessageBox.show("Error");
					oInsCreateDailog.close();
				});
			//commented for language selection change
			this.byId("accept").setEnabled(false);

			//---------Start of Local Storage Code for Safety Images----------//

			// var oSafetyImgData = jQuery.sap.storage(jQuery.sap.storage.Type.local).get("safetyImagesData");
			// var sLocStorPlantImg = "";
			// if (oSafetyImgData !== null && oSafetyImgData.length !== 0) {
			// 	sLocStorPlantImg = oSafetyImgData.results[0].Werks;
			// }

			// if (oSafetyImgData !== null && sLocStorPlantImg === vLoadPlant) {
			// 	that.getView().byId("safetyNoteTextPanel").setVisible(true);
			// 	var driverModel = new JSONModel(oSafetyImgData);
			// 	that.getView().setModel(driverModel, "driverModel");
			// } else {
			// 	that.onBindSafetyImages();
			// }

			//---------End of Local Storage Code for Safety Images----------//

			that.onBindSafetyImages();

			that.FlagPress = "";
			that.onDisSafetyMsg();

			that.langHeaderClickCount = 0;

		},

		onBindSafetyImages: function() {
			var that = this;
			// jQuery.sap.storage(jQuery.sap.storage.Type.local).put("safetyImagesData", "");
			var werksFilter = new sap.ui.model.Filter("Werks", sap.ui.model.FilterOperator.EQ, vLoadPlant);
			var configFilter = new sap.ui.model.Filter("Configured", sap.ui.model.FilterOperator.EQ, true);
			var mFilter = [];
			mFilter.push(werksFilter, configFilter);
			that.fnCreateBusyDialog("pallet.svg");
			that.getOwnerComponent().getModel("driverImagesModel").setUseBatch(false);
			that.getOwnerComponent().getModel("driverImagesModel").read("/SecImgConfigSet", {
				filters: mFilter,
				success: function(oData) {
					if (oData.results.length !== 0) {
						that.getView().byId("safetyNoteTextPanel").setVisible(true);
						var driverModel = new JSONModel(oData);
						that.getView().setModel(driverModel, "driverModel");
						
						if (oData.results.length === 1) {
							that.getView().byId("imgGrid").setDefaultSpan("L12 M12 S12");
						} else if (oData.results.length === 2) {
							that.getView().byId("imgGrid").setDefaultSpan("L6 M6 S12");
						} else if (oData.results.length === 3) {
							that.getView().byId("imgGrid").setDefaultSpan("L4 M4 S12");
						} else if (oData.results.length > 3 && oData.results.length < 6) {
							that.getView().byId("imgGrid").setDefaultSpan("L3 M3 S12");

						} else if (oData.results.length > 6) {
							that.getView().byId("imgGrid").setDefaultSpan("L2 M3 S12");
						}

						

						// jQuery.sap.storage(jQuery.sap.storage.Type.local).put("safetyImagesData", oData);

					}
					oInsCreateDailog.close();
				},
				error: function(oData) {
					oInsCreateDailog.close();
				}
			});
		},

		onDisSafetyMsg: function() {
			// For Displaying safety message text
			var that = this;
			var safteytestMod = that.getOwnerComponent().getModel("driverImagesModel");
			// safteytestMod.setUseBatch(false);
			var safteytest = [];
			safteytest.push(new sap.ui.model.Filter("Werks", sap.ui.model.FilterOperator.EQ, vLoadPlant));
			safteytest.push(new sap.ui.model.Filter("Zlangu", sap.ui.model.FilterOperator.EQ, sLanguage));
			safteytestMod.read("/safetymessageSet", {
				filters: safteytest,
				success: function(oData, oResponse) {
					if (oResponse.statusCode === "200" || oResponse.statusCode === 200) {
						var oSefetyTextModel = new JSONModel(oData);
						that.getView().setModel(oSefetyTextModel, "oSefetyTextModel");
						oInsCreateDailog.close();
					}
				},
				error: function(oError) {
					oInsCreateDailog.close();
				}
			});
		},

		// Function to change the time based on timezone

		realDateTimeClockBrowser: function() {
			var that = this;
			var sCurrDate = new Date();
			var dd = sCurrDate.getDate();
			var mm = sCurrDate.getMonth() + 1; //January is 0!
			var yyyy = sCurrDate.getFullYear();
			if (dd < 10) {
				dd = '0' + dd;
			}
			if (mm < 10) {
				mm = '0' + mm;
			}
			var sDate = yyyy.toString() + mm.toString() + dd.toString();
			var dFormDate = that.fnSetUserDateFormat(sDate, sCheDateFormat);
			//	var sDate = sCurrDate.toLocaleDateString();
			var sCurrTime = sCurrDate.toLocaleTimeString();
			var result = dFormDate + " " + sCurrTime;
			return result;
		},

		realDateTimeClock: function(TimeZone, DayLightSaving) {
			var that = this;

			/*	var sData = that.getView().getModel("HeaderDetailsPlant").getData();
			var TimeZone = sData.UTC_DIFF;
			var DayLightSaving = sData.DST_DIFF;*/

			var timeZoneOutput = [TimeZone.slice(0, 3), ":", TimeZone.slice(3, 5)].join('');

			if (DayLightSaving === "") {
				DayLightSaving = "0";
			}

			// var DayLightSavingOutput = [DayLightSaving.slice(0, 2), ":", DayLightSaving.slice(2, 4)].join('');

			if (timeZoneOutput.startsWith("-")) {
				var concatTimeZoneDayLight = parseInt(TimeZone.slice(1, 3)) - parseInt(DayLightSaving.slice(0, 2));
			} else if (timeZoneOutput.startsWith("+")) {
				var concatTimeZoneDayLight = parseInt(TimeZone.slice(1, 3)) + parseInt(DayLightSaving.slice(0, 2));
			}

			var finalOffset = [TimeZone.slice(0, 1), concatTimeZoneDayLight, ":", TimeZone.slice(3, 5)].join('');

			var _now = new Date();

			//var timeZoneOutput = "+11:00";
			var date = that.timezoneShifter(_now, finalOffset);

			var resultDate = that.formatTimeClock(date);
			return resultDate;
		},
		timezoneShifter: function(date, timezone) {

			var isBehindGTM = false;
			if (timezone.startsWith("-")) {
				timezone = timezone.substr(1);
				isBehindGTM = true;
			}

			var hDiff = timezone.split(":").map(myFunction);

			function myFunction(t) {
				return parseInt(t);
			}

			var value = isBehindGTM ? 1 : -1;
			var diff = (hDiff[0] * 60 + hDiff[1]) * value;
			var currentDiff = new Date().getTimezoneOffset();

			return new Date(date.valueOf() + (currentDiff - diff) * 60 * 1000);
		},

		// Function to format date

		formatTimeClock: function(_now) {
			var that = this;
			var sCurrDate = _now;
			var dd = sCurrDate.getDate();
			var mm = sCurrDate.getMonth() + 1; //January is 0!
			var yyyy = sCurrDate.getFullYear();
			if (dd < 10) {
				dd = '0' + dd;
			}
			if (mm < 10) {
				mm = '0' + mm;
			}
			var sDate = yyyy.toString() + mm.toString() + dd.toString();
			var dFormDate = that.fnSetUserDateFormat(sDate, sCheDateFormat);
			//	var sDate = sCurrDate.toLocaleDateString();
			var sCurrTime = sCurrDate.toLocaleTimeString();
			var result = dFormDate + " " + sCurrTime;
			return result;
		},

		// set french or spanish or other languages
		setLanguage: function() {
			var that = this;
			var vBundleName;
			var oModelLan;

			if (sLanguage === "FR" || sLanguage === "fr") {
				var browserLang = navigator.language;
				// var vBundleName;
				// var oModelLan;
				if (browserLang === "fr-CA") {
					vBundleName = "chep.checkin.i18n.i18n_fr_ca";
				} else {
					vBundleName = "chep.checkin.i18n.i18n_fr";
				}
				oModelLan = new sap.ui.model.resource.ResourceModel({
					bundleName: vBundleName
				});
			} else if ((sLanguage !== "FR" || sLanguage !== "fr") && (sRegion === "LATAM")) {
				if (sRegion === "LATAM") {
					vBundleName = "chep.checkin.i18n.i18n_mx_es";
				} else {
					vBundleName = "chep.checkin.i18n.i18n_es";
				}
				oModelLan = new sap.ui.model.resource.ResourceModel({
					bundleName: vBundleName
				});
			} else if (sLanguage === "Z1" || sLanguage === "z1") {
				vBundleName = "chep.checkin.i18n.i18n_sq";
				oModelLan = new sap.ui.model.resource.ResourceModel({
					bundleName: vBundleName
				});
			} else if (sLanguage === "HI" || sLanguage === "hi") {
				vBundleName = "chep.checkin.i18n.i18n_mt";
				oModelLan = new sap.ui.model.resource.ResourceModel({
					bundleName: vBundleName
				});
			} else if (sLanguage === "KK" || sLanguage === "kk") {
				vBundleName = "chep.checkin.i18n.i18n_bs";
				oModelLan = new sap.ui.model.resource.ResourceModel({
					bundleName: vBundleName
				});
			} else {
				oModelLan = new sap.ui.model.resource.ResourceModel({
					bundleName: "chep.checkin.i18n.i18n",
					bundleLocale: sLanguage
				});
			}
			that.getOwnerComponent().setModel(oModelLan, "i18n");
		},
		//---------- language selection service call ---------------//
		languageChangeService: function() {
			var that = this;
			// var oView = that.getView();
			// if (!that.changeLangDialog) {
			// 	that.changeLangDialog = sap.ui.xmlfragment("chep.checkin.fragments.changeLanguage", that);
			// 	oView.addDependent(that.changeLangDialog);
			// }

			jQuery.sap.storage(jQuery.sap.storage.Type.local).put("langModelDataSelec", "");
			var langModel = that.getOwnerComponent().getModel("langSelectionModel");
			that.fnCreateBusyDialog("pallet.svg");
			var aFilter = [];
			aFilter.push(new sap.ui.model.Filter("Werks", sap.ui.model.FilterOperator.EQ, vLoadPlant));
			langModel.read("/LanguageSet", {
				filters: aFilter,
				success: function(oData, response) {
					if (response.statusCode === 200) {
						oInsCreateDailog.close();
						var serviceArray = oData.results;
						jQuery.sap.storage(jQuery.sap.storage.Type.local).put("langModelDataSelec", serviceArray);
						that.onBindLanguageData(serviceArray);
					}

				},
				error: function() {
					oInsCreateDailog.close();
				}
			});
		},

		onBindLanguageData: function(serviceArray) {
			var that = this;
			jQuery.sap.delayedCall(0, null, function() {
				var oView = that.getView();
				if (!that.changeLangDialog) {
					that.changeLangDialog = sap.ui.xmlfragment("chep.checkin.fragments.changeLanguage", that);
					oView.addDependent(that.changeLangDialog);
				}
				if (serviceArray.length === 0) {
					that.getView().getModel("fragmentViewModel").setProperty("/noRecordsInfoLabel", true);
					that.getView().getModel("fragmentViewModel").setProperty("/gridLabel", false);
					that.getView().getModel("fragmentViewModel").setProperty("/continueBtn", false);
					that.getView().getModel("fragmentViewModel").setProperty("/languageHeaderBar", false);
					that.setLanguage();
					that.changeLangDialog.open();
					that.onSaveLanguage(sLanguage);
					that.safetyLangChange(sLanguage);
				} else if (serviceArray.length === 1) {
					if (serviceArray[0].FlagLang === "HI" || serviceArray[0].FlagLang === "hi") {
						sLanguage = "MT";
					} else if (serviceArray[0].FlagLang === "KK" || serviceArray[0].FlagLang === "kk") {
						sLanguage = "BS";
					} else if (serviceArray[0].FlagLang === "Z1" || serviceArray[0].FlagLang === "z1") {
						sLanguage = "SQ";
					}
					sLanguage = serviceArray[0].FlagLang;
					that.initialLanguage = sLanguage;
					that.onSaveLanguage(sLanguage);
					// set language by default
					that.setLanguage();
					that.safetyLangChange(sLanguage);
					//to bind language and image to Language Bar
					var defaultLangModel = new JSONModel({
						"langImg": "data:image/bmp;base64," + serviceArray[0].FlagBitmap,
						"langName": serviceArray[0].FlagLangName
					});
					that.getView().setModel(defaultLangModel, "defaultLangModel");
					var languageModel = new JSONModel();
					for (var i = 0; i < serviceArray.length; i++) {
						serviceArray[i].FlagBitmap = "data:image/bmp;base64," + serviceArray[i].FlagBitmap;
					}
					languageModel.setData(serviceArray);
					languageModel.setSizeLimit(serviceArray.length);
					that.getView().setModel(languageModel, "slctLanguageModel");
					that.changeLangDialog.close();
				} else {
					for (var j = 0; j < serviceArray.length; j++) {
						if (serviceArray[j].FlagLang === "HI" || serviceArray[j].FlagLang === "hi") {
							serviceArray[j].FlagLang = "MT";
						} else if (serviceArray[j].FlagLang === "KK" || serviceArray[j].FlagLang === "kk") {
							serviceArray[j].FlagLang = "BS";
						} else if (serviceArray[j].FlagLang === "Z1" || serviceArray[j].FlagLang === "z1") {
							serviceArray[j].FlagLang = "SQ";
						} else {
							serviceArray[j].FlagLang = serviceArray[j].FlagLang;
						}
					}
					var array = serviceArray;
					var defaultLang = array.filter(function(item) {
						return item.defaultLang === "X";
					});
					if (defaultLang.length > 0) {
						//Set to default language on header bar
						sLanguage = defaultLang[0].FlagLang;
						that.initialLanguage = sLanguage;
						var defaultLangModel = new JSONModel({
							"langImg": "data:image/bmp;base64," + defaultLang[0].FlagBitmap,
							"langName": defaultLang[0].FlagLangName
						});
						that.getView().setModel(defaultLangModel, "defaultLangModel");
						//set language with flag X from Service 
						that.setLanguage();
						var languageModel = new JSONModel();
						for (var i = 0; i < serviceArray.length; i++) {
							serviceArray[i].FlagBitmap = "data:image/bmp;base64," + serviceArray[i].FlagBitmap;
						}
						languageModel.setData(serviceArray);
						languageModel.setSizeLimit(serviceArray.length);
						that.getView().setModel(languageModel, "slctLanguageModel");
						that.changeLangDialog.open();
					} else {
						var defaultLangModel = new JSONModel({
							"langImg": "",
							"langName": ""
						});
						that.getView().setModel(defaultLangModel, "defaultLangModel");
						that.setLanguage();
					}
					that.onSaveLanguage(sLanguage);
					that.safetyLangChange(sLanguage);
				}
			});
		},

		onSaveLanguage: function(sapLanguage) {
			var that = this;
			jQuery.sap.storage(jQuery.sap.storage.Type.local).put("sysLang", sLanguage.toUpperCase());
			MessageBox._rb = sap.ui.getCore().getLibraryResourceBundle("sap.m", sLanguage);
			if (that.getView().byId("langId") !== undefined) {
				that.getView().byId("langId").setText(sLanguage.toUpperCase());
			}
		},
		_onObjectMatched: function() {
			this.byId("danbrocheck").setSelected(false);
			this.byId("noticecheck").setSelected(false);
			this.byId("accept").setEnabled(false);
			// this.getView().byId("navBack").setVisible(false);
		},

		onAfterRendering: function() {
			/*hiding header bar*/

			if (sap.ui.getCore().byId("shell-header") !== undefined) {
				if (sap.ui.Device.system.tablet && !sap.ui.Device.system.desktop) {
					sap.ui.getCore().byId("shell-header").setVisible(true);

				} else {
					if (sap.ui.getCore().byId("shell-header") !== undefined) {
						sap.ui.getCore().byId("shell-header").setVisible(false);
					}
				}
			}
			if (sRegion !== "US") {
				if ((kioskId === null) || (kioskId === 0)) {
					jQuery.sap.storage(jQuery.sap.storage.Type.local).put("KioskId", "");
					var submitError = this.getView().getModel("i18n").getProperty('submitError');
					var kioskMessage = this.getView().getModel("i18n").getProperty('kioskMessage');
					var oMessage = kioskMessage; //"KIOSK_ID is missing";
					MessageBox.show(
						oMessage, {
							icon: MessageBox.Icon.ERROR,
							title: submitError
						});

				} else {
					jQuery.sap.storage(jQuery.sap.storage.Type.local).put("KioskId", kioskId);
				}
			} else {
				if ((kioskId === null) || (kioskId === 0)) {
					jQuery.sap.storage(jQuery.sap.storage.Type.local).put("KioskId", "");
				} else {
					jQuery.sap.storage(jQuery.sap.storage.Type.local).put("KioskId", kioskId);
				}
			}
		},

		onAgreementSelect: function() {
			sdanbrocheck = this.byId("danbrocheck").getSelected();
			snoticecheck = this.byId("noticecheck").getSelected();
			if (agreementData !== "") {
				if (sdanbrocheck === true && snoticecheck === true) {
					this.byId("accept").setEnabled(true);
				} else {
					this.byId("accept").setEnabled(false);
				}

			} else {
				if (snoticecheck === true) {
					this.byId("accept").setEnabled(true);
				} else {
					this.byId("accept").setEnabled(false);
				}
			}
		},

		//----------------------------------------------------------------------------------
		//Function to create Busy Dialog
		//----------------------------------------------------------------------------------
		fnCreateBusyDialog: function(sImage) {
			var that = this;
			oInsCreateDailog = new sap.m.Dialog({
				showHeader: false
			}).addStyleClass("busyDialog sapUiTinyMargin");
			var sComponentName = that.getOwnerComponent().getMetadata().getComponentName();
			var imgUrl = $.sap.getModulePath(sComponentName, "/images/");
			var oImage = new sap.m.Image().addStyleClass("sapUiMediumMargin");
			oImage.setSrc(imgUrl + sImage);
			oInsCreateDailog.addContent(oImage);
			oInsCreateDailog.open();
		},

		//----------------------------------------------------------------------------------
		//Function for Accept Button
		//----------------------------------------------------------------------------------
		onAccept: function() {
			var oRouter = sap.ui.core.UIComponent.getRouterFor(this);
			oRouter.navTo("CheckIn");
		},

		//----------------------------------------------------------------------------------
		//Function to set logged in User Date pattern
		//----------------------------------------------------------------------------------
		fnSetUserDateFormat: function(rDate, sInsDateFormat) {
			if (rDate !== "") {
				var dFormDate;
				switch (sInsDateFormat) {
					case "1":
						dFormDate = rDate.slice(6, 8) + "." + rDate.slice(4, 6) + "." + rDate.slice(0, 4);
						break;
					case "2":
						dFormDate = rDate.slice(4, 6) + "/" + rDate.slice(6, 8) + "/" + rDate.slice(0, 4);
						break;
					case "3":
						dFormDate = rDate.slice(4, 6) + "-" + rDate.slice(6, 8) + "-" + rDate.slice(0, 4);
						break;
					case "4":
						dFormDate = rDate.slice(0, 4) + "." + rDate.slice(4, 6) + "." + rDate.slice(6, 8);
						break;
					case "5":
						dFormDate = rDate.slice(0, 4) + "/" + rDate.slice(4, 6) + "/" + rDate.slice(6, 8);
						break;
					case "6":
						dFormDate = rDate.slice(0, 4) + "-" + rDate.slice(4, 6) + "-" + rDate.slice(6, 8);
						break;
					case "A":
						dFormDate = rDate.slice(0, 4) + "/" + rDate.slice(4, 6) + "/" + rDate.slice(6, 8);
						break;
					case "B":
						dFormDate = rDate.slice(0, 4) + "/" + rDate.slice(4, 6) + "/" + rDate.slice(6, 8);
						break;
					case "C":
						dFormDate = rDate.slice(0, 4) + "/" + rDate.slice(4, 6) + "/" + rDate.slice(6, 8);
						break;
				}
			} else {
				var dFormDate = "";
			}
			return dFormDate;
		},
		//  #ZESP_CHECKIN-display?sap-language=EN&KIOSK_ID=1001
		onDecline: function() {
			if (sap.ui.Device.system.tablet && !sap.ui.Device.system.desktop) {
				var oCrossAppNavigatorTab = sap.ushell.Container.getService("CrossApplicationNavigation");
				oCrossAppNavigatorTab.toExternal({
					target: {
						semanticObject: "#Shell-home"

					}
				});
			} else {
				if (kioskId !== "XXXXXXXXXX") {
					var oCrossAppNavigator = sap.ushell.Container.getService("CrossApplicationNavigation");
					var hash = "ZESP_CHECKIN-display?sap-language=" + sysLang + "&KIOSK_ID=" + kioskId + "&/EULADeclined";
					oCrossAppNavigator.toExternal({
						target: {
							shellHash: hash
						}
					});
				} else {
					var oCrossAppNavigatorTab3 = sap.ushell.Container.getService("CrossApplicationNavigation");
					oCrossAppNavigatorTab3.toExternal({
						target: {
							semanticObject: "#Shell-home"
						}
					});
				}
			}
		},
		// Language selection dialog start//
		changeLangBtnPress: function() {
			var that = this;
			var oView = that.getView();
			if (!that.changeLangDialog) {
				that.changeLangDialog = sap.ui.xmlfragment("chep.checkin.fragments.changeLanguage", that);
				oView.addDependent(that.changeLangDialog);
			}
			that.changeLangDialog.open();

		},
		langContinueBtnPress: function(oEvent) {
			var that = this;

			that.onDisSafetyMsg();
			var selectedObject;
			var languageModel = oEvent.getSource().getParent().getModel("slctLanguageModel");
			var arrayData = languageModel.getData();
			if (that.countryPath !== undefined && that.countryPath !== "") {
				selectedObject = languageModel.getProperty(that.countryPath);
			} else {

				var index = arrayData.findIndex(function(e) {
					return e.defaultLang === "X";
				});
				that.countryPath = "/" + index;
				selectedObject = languageModel.getProperty(that.countryPath);
			}
			if (selectedObject !== undefined) {
				var slctdImage = selectedObject.FlagBitmap;
				var slctdLang = selectedObject.FlagLangName;
				that.getView().getModel("defaultLangModel").setProperty("/langImg", slctdImage);
				that.getView().getModel("defaultLangModel").setProperty("/langName", slctdLang);
				that.initialLanguage = sLanguage;
				that.changeLangDialog.close();
				that.safetyLangChange(sLanguage);
				that.onSaveLanguage(sLanguage);
			}

			that.getView().getModel("fragmentViewModel").setProperty("/cacheButtonVis", false);
			that.langHeaderClickCount = 0;

		},

		radioBtnSelect: function(oEvent) {
			var that = this;
			if (oEvent.getParameter("selected")) {
				var slectedRadioBtnPath = oEvent.getSource().getParent().getBindingContext("slctLanguageModel").getPath();
				that.countryPath = slectedRadioBtnPath;
				var slctdObject = oEvent.getSource().getParent().getBindingContext("slctLanguageModel").getObject();
				sLanguage = slctdObject.FlagLang;
				var oModelLan = new sap.ui.model.resource.ResourceModel({
					bundleName: "chep.checkin.i18n.i18n",
					bundleLocale: sLanguage
				});
				that.getOwnerComponent().setModel(oModelLan, "i18n");
			}

		},
		langCancelBtnPress: function() {
			var that = this;
			var oView = that.getView();
			if (!that.changeLangDialog) {
				that.changeLangDialog = sap.ui.xmlfragment("chep.checkin.fragments.changeLanguage", that);
				oView.addDependent(this.changeLangDialog);
			}
			that.changeLangDialog.close();
			var oModelLan = new sap.ui.model.resource.ResourceModel({
				bundleName: "chep.checkin.i18n.i18n",
				bundleLocale: that.initialLanguage
			});
			that.getOwnerComponent().setModel(oModelLan, "i18n");

			that.getView().getModel("fragmentViewModel").setProperty("/cacheButtonVis", false);
			that.langHeaderClickCount = 0;
		},

		flagImgPressBar: function() {
			var that = this;
			var oView = that.getView();
			if (!that.changeLangDialog) {
				that.changeLangDialog = sap.ui.xmlfragment("chep.checkin.fragments.changeLanguage", that);
				oView.addDependent(that.changeLangDialog);
			}
			that.changeLangDialog.open();

		},
		flagImgPressDialog: function(oEvent) {
			var radioId = oEvent.getSource().getParent().getItems()[0].getId();
			sap.ui.getCore().byId(radioId).setSelected(true);
			sap.ui.getCore().byId(radioId).fireSelect({
				"selected": true
			});
		},
		safetyLangChange: function(sapLanguage) {
			var that = this;
			// var sapLanguage = selectedObject.FlagLang;
			var sService = "/sap/opu/odata/sap/ZGW_CHECKIN_SRV";
			// that.fnCreateBusyDialog("pallet.svg");
			var oGlobalBusyDialog = new sap.m.BusyDialog();
			oGlobalBusyDialog.open();
			var oModel1 = new sap.ui.model.odata.ODataModel(sService);
			oModel1.read("/SafetyAgreementSet(Werks='" + vLoadPlant + "_SAFETY" + "',Spras='" + sapLanguage + "')", null, null, false,
				function(oData1, oResponse) {
					if (oResponse.statusCode === 200) {
						agreementData = oData1.Tdline;
						if (agreementData === "") {
							that.getView().byId("safetyAgreementHBoxID").setVisible(false);
							that.getView().byId("noticeConsentHBoxID").setWidth("100%");
						} else {
							that.getView().byId("safetyAgreementHBoxID").setVisible(true);
							that.getView().byId("noticeConsentHBoxID").setWidth("50%");
							that.getView().byId("safetyagreement").setValue(oData1.Tdline);
						}
						var sServiceUrl = "/sap/opu/odata/sap/ZGW_CHECKIN_SRV";
						var oModelHeader = new sap.ui.model.odata.ODataModel(sServiceUrl);
						var flagModel = that.getOwnerComponent().getModel("flagsModel");
						oModelHeader.read("/HeaderDetailsSet(Plant='" + vLoadPlant + "')", null, null, false,
							function(oData, oResponse) {
								if (oResponse.statusCode === 200) {
									oGlobalBusyDialog.close();
									sRegion = oData.Region;
									flagModel.setProperty("/covidFlag", oData.CovidFlag);

									var TimeZone = oData.UTC_DIFF;
									var DayLightSaving = oData.DST_DIFF;
									var PullTimeFalg = oData.Pull_time_active;

									jQuery.sap.storage(jQuery.sap.storage.Type.local).put("sTimeZone", TimeZone);
									jQuery.sap.storage(jQuery.sap.storage.Type.local).put("sDayLightSaving", DayLightSaving);
									jQuery.sap.storage(jQuery.sap.storage.Type.local).put("sFlag", PullTimeFalg);

									setInterval(function() {

										var oTimeZone = jQuery.sap.storage(jQuery.sap.storage.Type.local).get("sTimeZone");
										var oDayLightSaving = jQuery.sap.storage(jQuery.sap.storage.Type.local).get("sDayLightSaving");
										var oFlag = jQuery.sap.storage(jQuery.sap.storage.Type.local).get("sFlag");
										// var oFlag = "true";

										if (oFlag === false || oFlag === "false" || oFlag === null || oFlag === undefined) {
											var resultBrowser = that.realDateTimeClockBrowser();

											if (that.getView().byId("oDateID") !== undefined) {
												that.getView().byId("oDateID").setText(resultBrowser);
											}
											if (that.getView().byId("oDateID1") !== undefined) {
												that.getView().byId("oDateID1").setText(resultBrowser);
											}

										} else if (oFlag === true || oFlag === "true") {
											var result = that.realDateTimeClock(oTimeZone, oDayLightSaving);

											if (that.getView().byId("oDateID") !== undefined) {
												that.getView().byId("oDateID").setText(result);
											}
											if (that.getView().byId("oDateID1") !== undefined) {
												that.getView().byId("oDateID1").setText(result);
											}

										}

									}, 1000);

								}
							},
							function() {
								oGlobalBusyDialog.close();
								MessageBox.show("Error");
							});
					}
				},
				function() {
					oGlobalBusyDialog.close();
					MessageBox.show("Error");
				});

			var noticeConsentModel = new sap.ui.model.odata.ODataModel(sService);
			noticeConsentModel.read("/SafetyAgreementSet(Werks='" + vLoadPlant + "_DRIVER" + "',Spras='" + sapLanguage + "')", null, null,
				false,
				function(oData1) {
					that.getView().byId("noticeConsent").setValue(oData1.Tdline);
				},
				function(error) {
					MessageBox.show("Error");
				});
		},
		// Language selection dialog for kiosk device end//

		onCacheSettings: function() {
			var that = this;
			var oView = that.getView();
			if (!that.clearCacheDialog) {
				that.clearCacheDialog = sap.ui.xmlfragment("chep.checkin.fragments.StorageClear", that);
				oView.addDependent(that.clearCacheDialog);
			}
			that.clearCacheDialog.open();
		},

		onCacheYes: function() {
			var that = this;
			jQuery.sap.storage(jQuery.sap.storage.Type.local).clear();
			that.getView().getModel("fragmentViewModel").setProperty("/cacheButtonVis", false);
			that.langHeaderClickCount = 0;
			that.clearCacheDialog.close();
			that.changeLangDialog.close();
			that.onDecline();
		},

		onCacheNo: function() {
			var that = this;
			// that.getView().getModel("fragmentViewModel").setProperty("/cacheButtonVis", false);
			// that.langHeaderClickCount = 0;
			that.clearCacheDialog.close();
		},

		onLangHeaderTextPress: function() {
			var that = this;
			// var langHeaderClickCount = 0;
			// var sFinalHeadCount = langHeaderClickCount + 1;
			// langHeaderClickCount++;
			// var langHeaderClickCount = 0;
			// var sFinalHeadCount = that.langHeaderClickCount;
			that.langHeaderClickCount += 1;

			if (sLangConfgFlg === "true" || sLangConfgFlg === true) {
				if (that.langHeaderClickCount > 4) {
					that.getView().getModel("fragmentViewModel").setProperty("/cacheButtonVis", true);
				}
			} else {
				that.getView().getModel("fragmentViewModel").setProperty("/cacheButtonVis", false);
			}
		}

	});
});