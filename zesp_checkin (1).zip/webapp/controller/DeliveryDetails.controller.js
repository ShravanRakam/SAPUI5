var loggedUser;
var empNameID;
var vLoadPlant;
var oInsCreateDailog;
var listDelvDialog;
var storeMilkList;
var sChckDateFormat;
var sOrdertype;
var tipMilkList;
var sDelType;
var dropNpickFlag;
var pgmodel;
var sParentPlant;
var trailerLive;
sap.ui.define([
	"sap/ui/core/mvc/Controller",
	"sap/m/MessageBox",
	"sap/ui/model/json/JSONModel",
	"chep/checkin/model/formatter"
], function(Controller, MessageBox, JSONModel, formatter) {
	"use strict";

	return Controller.extend("chep.checkin.controller.DeliveryDetails", {

		formatter: formatter,

		onInit: function() {
			jQuery.sap.require("jquery.sap.storage");
			var oRouter = sap.ui.core.UIComponent.getRouterFor(this);
			oRouter.getRoute("DeliveryDetails").attachPatternMatched(this._onObjectMatched, this);
			var that = this;
			pgmodel = new JSONModel({ // start - model used for displaying the page numbers
				"pgStart": "0",
				"pgEnd": "0"
			});
			that.getView().setModel(pgmodel, "pgmodel");
			that.fnCreateBusyDialog("pallet.svg");
			var y = "/sap/bc/ui2/start_up";
			var xmlHttp = null;
			xmlHttp = new XMLHttpRequest();
			xmlHttp.onreadystatechange = function() {
				if (xmlHttp.readyState === 4 && xmlHttp.status === 200) {
					var oUserData = JSON.parse(xmlHttp.responseText);
					loggedUser = oUserData.id;
					empNameID = oUserData.fullName;
					sChckDateFormat = oUserData.dateFormat;
					that.getView().byId("empNameID").setText(empNameID);
					//	that.getView().byId("pageNo").setText("3 of 5");
					that.getView().getModel("pgmodel").setProperty("/pgStart", "3");
					that.getView().getModel("pgmodel").setProperty("/pgEnd", "5");
					that.byId("Header_Desktop_Bar_ID").setVisible(true);
				}
			};
			var sLanguage = jQuery.sap.storage(jQuery.sap.storage.Type.local).get("sysLang");
			that.getView().byId("langId").setText(sLanguage);
			xmlHttp.open("GET", y, false);
			xmlHttp.send(null);

			//------------------------------------------------------------------------------------------------------------------------
			// Read the header data for bar
			//------------------------------------------------------------------------------------------------------------------------

			var url = "/sap/opu/odata/sap/ZGW_DELIVERY_AP_SRV";
			var oModel = new sap.ui.model.odata.ODataModel(url);

			oModel.read("/HeaderDetailsSet('" + loggedUser + "')", null, null, true, function(oData) {
					var oODataJSONModel2 = new sap.ui.model.json.JSONModel();
					oODataJSONModel2.setData(oData);
					that.getView().setModel(oODataJSONModel2, "HeaderDetails");
					vLoadPlant = oData.Plant;
					oInsCreateDailog.close();
				},
				function(error) {
					oInsCreateDailog.close();
					MessageBox.show("Error");
				});

			//-----------------------------------------------------------------------------------------------------------------------
			// Setting the clock and date
			//-----------------------------------------------------------------------------------------------------------------------
			/*	setInterval(function() {
				var sCurrDate = new Date();
				var dd = sCurrDate.getDate();
				var mm = sCurrDate.getMonth() + 1; //January is 0!
				var yyyy = sCurrDate.getFullYear();
				if (dd < 10) {
					dd = '0' + dd;
				}
				if (mm < 10) {
					mm = '0' + mm;
				}
				var sDate = yyyy.toString() + mm.toString() + dd.toString();
				var dFormDate = that.fnSetUserDateFormat(sDate, sChckDateFormat);
				var sCurrTime = sCurrDate.toLocaleTimeString();
				var result = dFormDate + " " + sCurrTime;

				if (that.getView().byId("oDateID") !== undefined) {
					that.getView().byId("oDateID").setText(result);
				}
				if (that.getView().byId("oDateID1") !== undefined) {
					that.getView().byId("oDateID1").setText(result);
				}
			}, 1000);*/

			/*setInterval(function() {

				var result = that.realDateTimeClock();

				if (that.getView().byId("oDateID") !== undefined) {
					that.getView().byId("oDateID").setText(result);
				}
				if (that.getView().byId("oDateID1") !== undefined) {
					that.getView().byId("oDateID1").setText(result);
				}
			}, 1000);*/

			setInterval(function() {

				var oTimeZone = jQuery.sap.storage(jQuery.sap.storage.Type.local).get("sTimeZone");
				var oDayLightSaving = jQuery.sap.storage(jQuery.sap.storage.Type.local).get("sDayLightSaving");
				var oFlag = jQuery.sap.storage(jQuery.sap.storage.Type.local).get("sFlag");

				if (oFlag === false || oFlag === "false" || oFlag === null || oFlag === undefined) {
					var resultBrowser = that.realDateTimeClockBrowser();

					if (that.getView().byId("oDateID") !== undefined) {
						that.getView().byId("oDateID").setText(resultBrowser);
					}
					if (that.getView().byId("oDateID1") !== undefined) {
						that.getView().byId("oDateID1").setText(resultBrowser);
					}

				} else if (oFlag === true || oFlag === "true") {
					var result = that.realDateTimeClock(oTimeZone, oDayLightSaving);

					if (that.getView().byId("oDateID") !== undefined) {
						that.getView().byId("oDateID").setText(result);
					}
					if (that.getView().byId("oDateID1") !== undefined) {
						that.getView().byId("oDateID1").setText(result);
					}

				}

			}, 1000);

		},

		// Function to change the time based on timezone

		realDateTimeClockBrowser: function() {
			var that = this;
			var sCurrDate = new Date();
			var dd = sCurrDate.getDate();
			var mm = sCurrDate.getMonth() + 1; //January is 0!
			var yyyy = sCurrDate.getFullYear();
			if (dd < 10) {
				dd = '0' + dd;
			}
			if (mm < 10) {
				mm = '0' + mm;
			}
			var sDate = yyyy.toString() + mm.toString() + dd.toString();
			var dFormDate = that.fnSetUserDateFormat(sDate, sChckDateFormat);
			//	var sDate = sCurrDate.toLocaleDateString();
			var sCurrTime = sCurrDate.toLocaleTimeString();
			var result = dFormDate + " " + sCurrTime;
			return result;
		},

		realDateTimeClock: function(TimeZone, DayLightSaving) {
			var that = this;

			/*	var sData = that.getView().getModel("HeaderDetailsPlant").getData();
			var TimeZone = sData.UTC_DIFF;
			var DayLightSaving = sData.DST_DIFF;*/

			var timeZoneOutput = [TimeZone.slice(0, 3), ":", TimeZone.slice(3, 5)].join('');

			if (DayLightSaving === "") {
				DayLightSaving = "0";
			}

			// var DayLightSavingOutput = [DayLightSaving.slice(0, 2), ":", DayLightSaving.slice(2, 4)].join('');

			if (timeZoneOutput.startsWith("-")) {
				var concatTimeZoneDayLight = parseInt(TimeZone.slice(1, 3)) - parseInt(DayLightSaving.slice(0, 2));
			} else if (timeZoneOutput.startsWith("+")) {
				var concatTimeZoneDayLight = parseInt(TimeZone.slice(1, 3)) + parseInt(DayLightSaving.slice(0, 2));
			}

			var finalOffset = [TimeZone.slice(0, 1), concatTimeZoneDayLight, ":", TimeZone.slice(3, 5)].join('');

			var _now = new Date();

			//var timeZoneOutput = "+11:00";
			var date = that.timezoneShifter(_now, finalOffset);

			var resultDate = that.formatTimeClock(date);
			return resultDate;
		},
		timezoneShifter: function(date, timezone) {

			var isBehindGTM = false;
			if (timezone.startsWith("-")) {
				timezone = timezone.substr(1);
				isBehindGTM = true;
			}

			var hDiff = timezone.split(":").map(myFunction);

			function myFunction(t) {
				return parseInt(t);
			}

			var value = isBehindGTM ? 1 : -1;
			var diff = (hDiff[0] * 60 + hDiff[1]) * value;
			var currentDiff = new Date().getTimezoneOffset();

			return new Date(date.valueOf() + (currentDiff - diff) * 60 * 1000);
		},

		formatTimeClock: function(_now) {
			var that = this;
			var sCurrDate = _now;
			var dd = sCurrDate.getDate();
			var mm = sCurrDate.getMonth() + 1; //January is 0!
			var yyyy = sCurrDate.getFullYear();
			if (dd < 10) {
				dd = '0' + dd;
			}
			if (mm < 10) {
				mm = '0' + mm;
			}
			var sDate = yyyy.toString() + mm.toString() + dd.toString();
			var dFormDate = that.fnSetUserDateFormat(sDate, sChckDateFormat);
			//	var sDate = sCurrDate.toLocaleDateString();
			var sCurrTime = sCurrDate.toLocaleTimeString();
			var result = dFormDate + " " + sCurrTime;
			return result;
		},

		_onObjectMatched: function(oEvent) {
			var that = this;
			trailerLive = jQuery.sap.storage(jQuery.sap.storage.Type.local).get("trailerLive");
			storeMilkList = jQuery.sap.storage(jQuery.sap.storage.Type.local).get("milkRunList");
			tipMilkList = jQuery.sap.storage(jQuery.sap.storage.Type.local).get("tipReloadList");
			sDelType = jQuery.sap.storage(jQuery.sap.storage.Type.local).get("sDeliveryType");
			if ((storeMilkList !== undefined) || (tipMilkList !== undefined)) {
				if (((storeMilkList.length > 1) || (storeMilkList.length > 0 && tipMilkList.length > 0)) || ((tipMilkList.length > 1) || (
					tipMilkList.length > 0 && storeMilkList.length > 0))) {
					that.byId("milkRunDelBtId").setVisible(true);
				} else {
					that.byId("milkRunDelBtId").setVisible(false);
				}
			}
			//-----------------For getting Chep Order Number-----------------------------//

			var DeliveryNumber = jQuery.sap.storage(jQuery.sap.storage.Type.local).get("DeliveryNumber");
			var Ordertype = jQuery.sap.storage(jQuery.sap.storage.Type.local).get("Ordertype");
			var Location = jQuery.sap.storage(jQuery.sap.storage.Type.local).get("Location");

			// sParentPlant = jQuery.sap.storage(jQuery.sap.storage.Type.local).get("ParentPlant");
			// if (sParentPlant !== "" || sParentPlant !== " ") {
			// 	vLoadPlant = sParentPlant;
			// } else {
			// 	vLoadPlant = vLoadPlant;
			// }

			var i18nModel = that.getOwnerComponent();
			var sourceLbl = i18nModel.getModel("i18n").getProperty('sourceLocation');
			var destLbl = i18nModel.getModel("i18n").getProperty('destLocation');

			that.getView().byId("orderId").setText(DeliveryNumber);

			if ((Ordertype === "Collect") || (Ordertype === "collect") || ((Ordertype === "Raw Materials")) || (Ordertype === "STO Receipt")) {
				this.getView().byId("location").setText(sourceLbl);
			} else if ((Ordertype === "Issue") || (Ordertype === "issue") || (Ordertype === "STO Issue")) {
				this.getView().byId("location").setText(destLbl);
			}
			// var sOrdertype;

			switch (Ordertype) {
				case "Collect":
					sOrdertype = i18nModel.getModel("i18n").getProperty('collectText');
					break;
				case "Issue":
					sOrdertype = i18nModel.getModel("i18n").getProperty('issueText');
					break;
				case "STO Receipt":
					sOrdertype = i18nModel.getModel("i18n").getProperty('stoReceiptText');
					break;
				case "STO Issue":
					sOrdertype = i18nModel.getModel("i18n").getProperty('stoIssueText');
					break;
				case "Raw Materials":
					sOrdertype = i18nModel.getModel("i18n").getProperty('rawMaterial');
					break;
			}
			that.getView().byId("deliverytype").setText(sOrdertype);
			that.getView().byId("ds_location").setText(Location);
		},

		//--------Function for Hiding the Remove Icon from the List of deliveries Table--------//

		//----------------------------------------------------------------------------------
		//Function to create Busy Dialog
		//----------------------------------------------------------------------------------

		fnCreateBusyDialog: function(sImage) {
			var that = this;
			oInsCreateDailog = new sap.m.Dialog({
				showHeader: false
			}).addStyleClass("busyDialog sapUiTinyMargin");
			var sComponentName = that.getOwnerComponent().getMetadata().getComponentName();
			var imgUrl = $.sap.getModulePath(sComponentName, "/images/");
			var oImage = new sap.m.Image().addStyleClass("sapUiMediumMargin");
			oImage.setSrc(imgUrl + sImage);
			oInsCreateDailog.addContent(oImage);
			oInsCreateDailog.open();
		},

		//----------------------------------------------------------------------------------
		//Function to set logged in User Date pattern
		//----------------------------------------------------------------------------------
		fnSetUserDateFormat: function(rDate, sInsDateFormat) {
			if (rDate !== "") {
				var dFormDate;
				switch (sInsDateFormat) {
					case "1":
						dFormDate = rDate.slice(6, 8) + "." + rDate.slice(4, 6) + "." + rDate.slice(0, 4);
						break;
					case "2":
						dFormDate = rDate.slice(4, 6) + "/" + rDate.slice(6, 8) + "/" + rDate.slice(0, 4);
						break;
					case "3":
						dFormDate = rDate.slice(4, 6) + "-" + rDate.slice(6, 8) + "-" + rDate.slice(0, 4);
						break;
					case "4":
						dFormDate = rDate.slice(0, 4) + "." + rDate.slice(4, 6) + "." + rDate.slice(6, 8);
						break;
					case "5":
						dFormDate = rDate.slice(0, 4) + "/" + rDate.slice(4, 6) + "/" + rDate.slice(6, 8);
						break;
					case "6":
						dFormDate = rDate.slice(0, 4) + "-" + rDate.slice(4, 6) + "-" + rDate.slice(6, 8);
						break;
					case "A":
						dFormDate = rDate.slice(0, 4) + "/" + rDate.slice(4, 6) + "/" + rDate.slice(6, 8);
						break;
					case "B":
						dFormDate = rDate.slice(0, 4) + "/" + rDate.slice(4, 6) + "/" + rDate.slice(6, 8);
						break;
					case "C":
						dFormDate = rDate.slice(0, 4) + "/" + rDate.slice(4, 6) + "/" + rDate.slice(6, 8);
						break;
				}
			} else {
				var dFormDate = "";
			}
			return dFormDate;
		},

		//--------Function for setting location as source or destination based on Deliverytype/Ordertype--------//

		//--------------------------Open DropandHook fragment for Issue------------------------//
		openDropHookFragment: function() {
			if (!this._DopandHookDialog) {
				this._DopandHookDialog = sap.ui.xmlfragment("chep.checkin.fragments.DropHook", this);
				this.getView().addDependent(this._DopandHookDialog);
			}
			jQuery.sap.syncStyleClass("sapUiSizeCompact", this.getView(), this._DopandHookDialog);
			this._DopandHookDialog.open();

		},

		//----Function for Opening th Drop and PickUp Dialog-----//
		openDropPickUpFragment: function() {
			if (!this._DropandPickDialog) {
				this._DropandPickDialog = sap.ui.xmlfragment("chep.checkin.fragments.DropPickup", this);
				this.getView().addDependent(this._DropandPickDialog);
			}
			jQuery.sap.syncStyleClass("sapUiSizeCompact", this.getView(), this._DropandPickDialog);
			this._DropandPickDialog.open();
			this.getOwnerComponent().getModel("UAunknwnModel").setProperty("/onUacontinueBtn", false);
		},

		//--------Function for Continue button----------//
		onDetailContinue: function() {
			var that = this;
			jQuery.sap.storage(jQuery.sap.storage.Type.local).put("PageType", "DD");
			//	var ordertype = that.byId("deliverytype").getText();
			var Ordertype = jQuery.sap.storage(jQuery.sap.storage.Type.local).get("Ordertype");
			var vDropservice = jQuery.sap.storage(jQuery.sap.storage.Type.local).get("vDropservice");
			jQuery.sap.storage(jQuery.sap.storage.Type.local).put("OrderType", Ordertype);
			dropNpickFlag = jQuery.sap.storage(jQuery.sap.storage.Type.local).get("dropNpickup");
			var DandHservice = jQuery.sap.storage(jQuery.sap.storage.Type.local).get("vDhservice"); // live phase drop2 chnages -D&H 

			if (((Ordertype === "Issue") || (Ordertype === "STO Issue")) && (vDropservice === "true")) {
				jQuery.sap.storage(jQuery.sap.storage.Type.local).put("returnDrop", "");
				if (DandHservice === "true") { // check D&H ON/OFF
					if (dropNpickFlag === "X") { // check SCAC and GLID in D&H
						that.onYesPress();
					} else {

						/*Commented For D&H Issue Start*/
						/*	var locationDH = that.byId("ds_location").getText();
							jQuery.sap.storage(jQuery.sap.storage.Type.local).put("Location", locationDH);
							jQuery.sap.storage(jQuery.sap.storage.Type.local).put("returnDrop", "");
							jQuery.sap.storage(jQuery.sap.storage.Type.local).put("issueDrop", "");
							var oRouterDH = sap.ui.core.UIComponent.getRouterFor(this);
							var vDocDH = "F";
							oRouterDH.navTo("TrailerInformation", {
								objectId: vDocDH
							});*/
						/*Commented For D&H Issue End*/

						/*New Chnages END for D&H By Vinod*/
						var sDelNumber = jQuery.sap.storage(jQuery.sap.storage.Type.local).get("DeliveryNumber");
						var sScacCode = jQuery.sap.storage(jQuery.sap.storage.Type.local).get("Scac");
						
						//---------Start of Multi Plant Changes----------// 
						sParentPlant = jQuery.sap.storage(jQuery.sap.storage.Type.local).get("ParentPlant");
						if (sParentPlant !== "") {
							vLoadPlant = sParentPlant;
						} else {
							vLoadPlant = vLoadPlant;
						}
						//---------End of Multi Plant Changes----------// 
						var i18nModel = that.getOwnerComponent();
						var url = "/sap/opu/odata/sap/ZGW_CHECKIN_SRV/";
						var oModelCheck = new sap.ui.model.odata.v2.ODataModel(url);
						oModelCheck.setHeaders({
							"X-Requested-With": "XMLHttpRequest",
							"Content-Type": "application/atom+xml",
							"slug": "image.jpg",
							"DataServiceVersion": "2.0",
							"X-CSRF-Token": "Fetch"
						});
						oModelCheck.useBatch = true;
						oModelCheck.read("/ValidateDelSet(Werks='" + vLoadPlant + "',DocId='" + sDelNumber + "',Carrier='" + sScacCode +
							"',Action='" + "N" + "')", {
								success: function(oData, oResponse) {

									if ((oResponse.statusCode === 200) || (oResponse.statusCode === "200")) {
										oInsCreateDailog.close();
										var sHeaderMsg = oResponse.headers.message; //CheckedIn message
										if (sHeaderMsg !== undefined) { // for Valid and Submitted number
											if (sHeaderMsg !== "") {
												if (sHeaderMsg === "Success") {
													var locationDH = that.byId("ds_location").getText();
													jQuery.sap.storage(jQuery.sap.storage.Type.local).put("Location", locationDH);
													jQuery.sap.storage(jQuery.sap.storage.Type.local).put("returnDrop", "");
													jQuery.sap.storage(jQuery.sap.storage.Type.local).put("issueDrop", "");
													var oRouter = sap.ui.core.UIComponent.getRouterFor(that);
													var vDoc = "F";
													oRouter.navTo("TrailerInformation", {
														objectId: vDoc
													});
												} else if (sHeaderMsg === "Completed") {
													var oMessage = i18nModel.getModel("i18n").getProperty('orderCompleted');
													var submitError = i18nModel.getModel("i18n").getProperty('submitError');
													MessageBox.show(
														oMessage, {
															icon: MessageBox.Icon.ERROR,
															title: submitError, //"Error during submitting!"
															actions: [sap.m.MessageBox.Action.OK],
															onClose: function(oAction) {
																if (oAction == "OK") {
																	var oRouter = sap.ui.core.UIComponent.getRouterFor(that);
																	oRouter.navTo("CheckIn");
																}
															}.bind(that)
														});

												}
											}
										} else {
											var oMessage = i18nModel.getModel("i18n").getProperty('enterValOrderNum');
											var submitError = i18nModel.getModel("i18n").getProperty('submitError');
											MessageBox.show(
												oMessage, {
													icon: MessageBox.Icon.ERROR,
													title: submitError, //"Error during submitting!"
													actions: [sap.m.MessageBox.Action.OK],
													onClose: function(oAction) {
														if (oAction == "OK") {
															var oRouter = sap.ui.core.UIComponent.getRouterFor(that);
															oRouter.navTo("CheckIn");
														}
													}.bind(that)
												});
										}

									} else {
										oInsCreateDailog.close();
										var oMessage = i18nModel.getModel("i18n").getProperty('enterValOrderNum');
										var submitError = i18nModel.getModel("i18n").getProperty('submitError');
										MessageBox.show(
											oMessage, {
												icon: MessageBox.Icon.ERROR,
												title: submitError, //"Error during submitting!"
												actions: [sap.m.MessageBox.Action.OK],
												onClose: function(oAction) {
													if (oAction == "OK") {
														var oRouter = sap.ui.core.UIComponent.getRouterFor(that);
														oRouter.navTo("CheckIn");
													}
												}.bind(that)
											});
									}

								},
								error: function() {
									oInsCreateDailog.close();
									var oMessage = i18nModel.getModel("i18n").getProperty('enterValOrderNum');
									var submitError = i18nModel.getModel("i18n").getProperty('submitError');
									MessageBox.show(
										oMessage, {
											icon: MessageBox.Icon.ERROR,
											title: submitError, //"Error during submitting!"
											actions: [sap.m.MessageBox.Action.OK],
											onClose: function(oAction) {
												if (oAction == "OK") {
													var oRouter = sap.ui.core.UIComponent.getRouterFor(that);
													oRouter.navTo("CheckIn");
												}
											}.bind(that)
										});
								}
							});
						/*New Chnages END for D&H*/
						// that.openDropHookFragment();
						// that.openDropPickUpFragment();

					}
				} else {
					that.openDropPickUpFragment();
				}
			} else {
				var location = that.byId("ds_location").getText();
				jQuery.sap.storage(jQuery.sap.storage.Type.local).put("Location", location);
				if (dropNpickFlag === "") {
					jQuery.sap.storage(jQuery.sap.storage.Type.local).put("returnDrop", "X");
				}
				jQuery.sap.storage(jQuery.sap.storage.Type.local).put("returnDrop", "");
				jQuery.sap.storage(jQuery.sap.storage.Type.local).put("issueDrop", "");
				var oRouter = sap.ui.core.UIComponent.getRouterFor(this);
				var vDoc = "F";
				oRouter.navTo("TrailerInformation", {
					objectId: vDoc
				});
			}
		},

		//------------YesPressFunction for Dropandhook Dialog------------//
		onYesPress: function() {
			jQuery.sap.storage(jQuery.sap.storage.Type.local).put("trailerLive", "");
			if (!this._CurrentlyHookedDialog) {
				this._CurrentlyHookedDialog = sap.ui.xmlfragment("chep.checkin.fragments.HookedTrailer", this);
				this.getView().addDependent(this._CurrentlyHookedDialog);
			}
			// toggle compact style
			/*	jQuery.sap.syncStyleClass("sapUiSizeCompact", this.getView(), this._CurrentlyHookedDialog);
			this._DopandHookDialog.close();
			this._CurrentlyHookedDialog.open();*/

			var that = this;
			// that._DopandHookDialog.close();
			if (dropNpickFlag !== "X") {
				that._DropandPickDialog.close();
			}
			var sDelNumber = jQuery.sap.storage(jQuery.sap.storage.Type.local).get("DeliveryNumber");
			var sScacCode = jQuery.sap.storage(jQuery.sap.storage.Type.local).get("Scac");
			//---------Start of Multi Plant Changes----------// 
			sParentPlant = jQuery.sap.storage(jQuery.sap.storage.Type.local).get("ParentPlant");
			if (sParentPlant !== "") {
				vLoadPlant = sParentPlant;
			} else {
				vLoadPlant = vLoadPlant;
			}
			//---------End of Multi Plant Changes----------// 
			var i18nModel = that.getOwnerComponent();
			var url = "/sap/opu/odata/sap/ZGW_CHECKIN_SRV/";
			var oModelCheck = new sap.ui.model.odata.v2.ODataModel(url);
			oModelCheck.setHeaders({
				"X-Requested-With": "XMLHttpRequest",
				"Content-Type": "application/atom+xml",
				"slug": "image.jpg",
				"DataServiceVersion": "2.0",
				"X-CSRF-Token": "Fetch"
			});
			oModelCheck.useBatch = true;
			oModelCheck.read("/ValidateDelSet(Werks='" + vLoadPlant + "',DocId='" + sDelNumber + "',Carrier='" + sScacCode +
				"',Action='" + "S" + "')", {
					success: function(oData, oResponse) {
						if ((oResponse.statusCode === 200) || (oResponse.statusCode === "200")) {
							oInsCreateDailog.close();
							var sHeaderMsg = oResponse.headers.message; //CheckedIn message
							if (sHeaderMsg !== undefined) { // for Valid and Submitted number
								if (sHeaderMsg !== "") {
									if (sHeaderMsg === "Success") {
										jQuery.sap.syncStyleClass("sapUiSizeCompact", that.getView(), that._CurrentlyHookedDialog);
										that._CurrentlyHookedDialog.open();
									} else if (sHeaderMsg === "Completed") {
										var oMessage = i18nModel.getModel("i18n").getProperty('orderCompleted');
										var submitError = i18nModel.getModel("i18n").getProperty('submitError');
										MessageBox.show(
											oMessage, {
												icon: MessageBox.Icon.ERROR,
												title: submitError, //"Error during submitting!"
												actions: [sap.m.MessageBox.Action.OK],
												onClose: function(oAction) {
													if (oAction == "OK") {
														var oRouter = sap.ui.core.UIComponent.getRouterFor(that);
														oRouter.navTo("CheckIn");
													}
												}.bind(that)
											});
									}
								}
							} else {
								var oMessage = i18nModel.getModel("i18n").getProperty('enterValOrderNum');
								var submitError = i18nModel.getModel("i18n").getProperty('submitError');
								MessageBox.show(
									oMessage, {
										icon: MessageBox.Icon.ERROR,
										title: submitError, //"Error during submitting!"
										actions: [sap.m.MessageBox.Action.OK],
										onClose: function(oAction) {
											if (oAction == "OK") {
												var oRouter = sap.ui.core.UIComponent.getRouterFor(that);
												oRouter.navTo("CheckIn");
											}
										}.bind(that)
									});
							}

						} else {
							oInsCreateDailog.close();
							var oMessage = i18nModel.getModel("i18n").getProperty('enterValOrderNum');
							var submitError = i18nModel.getModel("i18n").getProperty('submitError');
							MessageBox.show(
								oMessage, {
									icon: MessageBox.Icon.ERROR,
									title: submitError, //"Error during submitting!"
									actions: [sap.m.MessageBox.Action.OK],
									onClose: function(oAction) {
										if (oAction == "OK") {
											var oRouter = sap.ui.core.UIComponent.getRouterFor(that);
											oRouter.navTo("CheckIn");
										}
									}.bind(that)
								});
						}
					},
					error: function() {
						oInsCreateDailog.close();
						var oMessage = i18nModel.getModel("i18n").getProperty('enterValOrderNum');
						var submitError = i18nModel.getModel("i18n").getProperty('submitError');
						MessageBox.show(
							oMessage, {
								icon: MessageBox.Icon.ERROR,
								title: submitError, //"Error during submitting!"
								actions: [sap.m.MessageBox.Action.OK],
								onClose: function(oAction) {
									if (oAction == "OK") {
										var oRouter = sap.ui.core.UIComponent.getRouterFor(that);
										oRouter.navTo("CheckIn");
									}
								}.bind(that)
							});
					}
				});
		},

		//------------NoPressFunction for Dropandhook Dialog------------//
		onNoPress: function() {
			// this._DopandHookDialog.close();
			this._DropandPickDialog.close();
			var that = this;
			jQuery.sap.storage(jQuery.sap.storage.Type.local).put("trailerLive", "X");
			jQuery.sap.storage(jQuery.sap.storage.Type.local).put("issueDrop", "X");
			jQuery.sap.storage(jQuery.sap.storage.Type.local).put("returnDrop", "");
			jQuery.sap.storage(jQuery.sap.storage.Type.local).put("trailerTypeFV", "");
			var sDelNumber = jQuery.sap.storage(jQuery.sap.storage.Type.local).get("DeliveryNumber");
			var sScacCode = jQuery.sap.storage(jQuery.sap.storage.Type.local).get("Scac");
			//---------Start of Multi Plant Changes----------// 
			sParentPlant = jQuery.sap.storage(jQuery.sap.storage.Type.local).get("ParentPlant");
			if (sParentPlant !== "") {
				vLoadPlant = sParentPlant;
			} else {
				vLoadPlant = vLoadPlant;
			}
			//---------End of Multi Plant Changes----------// 
			var i18nModel = that.getOwnerComponent();
			var url = "/sap/opu/odata/sap/ZGW_CHECKIN_SRV/";
			var oModelCheck = new sap.ui.model.odata.v2.ODataModel(url);
			oModelCheck.setHeaders({
				"X-Requested-With": "XMLHttpRequest",
				"Content-Type": "application/atom+xml",
				"slug": "image.jpg",
				"DataServiceVersion": "2.0",
				"X-CSRF-Token": "Fetch"
			});
			oModelCheck.useBatch = true;
			oModelCheck.read("/ValidateDelSet(Werks='" + vLoadPlant + "',DocId='" + sDelNumber + "',Carrier='" + sScacCode +
				"',Action='" +
				"N" + "')", {
					success: function(oData, oResponse) {
						if ((oResponse.statusCode === 200) || (oResponse.statusCode === "200")) {
							oInsCreateDailog.close();
							var sHeaderMsg = oResponse.headers.message; //CheckedIn message
							if (sHeaderMsg !== undefined) { // for Valid and Submitted number
								if (sHeaderMsg !== "") {
									if (sHeaderMsg === "Success") {
										var oRouter = sap.ui.core.UIComponent.getRouterFor(that);
										var vDoc = "F";
										oRouter.navTo("TrailerInformation", {
											objectId: vDoc
										});
									} else if (sHeaderMsg === "Completed") {
										var oMessage = i18nModel.getModel("i18n").getProperty('orderCompleted');
										var submitError = i18nModel.getModel("i18n").getProperty('submitError');
										MessageBox.show(
											oMessage, {
												icon: MessageBox.Icon.ERROR,
												title: submitError, //"Error during submitting!"
												actions: [sap.m.MessageBox.Action.OK],
												onClose: function(oAction) {
													if (oAction == "OK") {
														var oRouter = sap.ui.core.UIComponent.getRouterFor(that);
														oRouter.navTo("CheckIn");
													}
												}.bind(that)
											});

									}
								}
							} else {
								var oMessage = i18nModel.getModel("i18n").getProperty('enterValOrderNum');
								var submitError = i18nModel.getModel("i18n").getProperty('submitError');
								MessageBox.show(
									oMessage, {
										icon: MessageBox.Icon.ERROR,
										title: submitError, //"Error during submitting!"
										actions: [sap.m.MessageBox.Action.OK],
										onClose: function(oAction) {
											if (oAction == "OK") {
												var oRouter = sap.ui.core.UIComponent.getRouterFor(that);
												oRouter.navTo("CheckIn");
											}
										}.bind(that)
									});
							}

						} else {
							oInsCreateDailog.close();
							var oMessage = i18nModel.getModel("i18n").getProperty('enterValOrderNum');
							var submitError = i18nModel.getModel("i18n").getProperty('submitError');
							MessageBox.show(
								oMessage, {
									icon: MessageBox.Icon.ERROR,
									title: submitError, //"Error during submitting!"
									actions: [sap.m.MessageBox.Action.OK],
									onClose: function(oAction) {
										if (oAction == "OK") {
											var oRouter = sap.ui.core.UIComponent.getRouterFor(that);
											oRouter.navTo("CheckIn");
										}
									}.bind(that)
								});
						}
					},
					error: function() {
						oInsCreateDailog.close();
						var oMessage = i18nModel.getModel("i18n").getProperty('enterValOrderNum');
						var submitError = i18nModel.getModel("i18n").getProperty('submitError');
						MessageBox.show(
							oMessage, {
								icon: MessageBox.Icon.ERROR,
								title: submitError, //"Error during submitting!"
								actions: [sap.m.MessageBox.Action.OK],
								onClose: function(oAction) {
									if (oAction == "OK") {
										var oRouter = sap.ui.core.UIComponent.getRouterFor(that);
										oRouter.navTo("CheckIn");
									}
								}.bind(that)
							});
					}
				});

		},

		//--------------onEmptyTrailerPress in the Hooked Trailer Dialog--------------------//
		onIssueEmptyTrailerPress: function() {
			jQuery.sap.storage(jQuery.sap.storage.Type.local).put("issueDrop", "E");
			jQuery.sap.storage(jQuery.sap.storage.Type.local).put("returnDrop", "");
			jQuery.sap.storage(jQuery.sap.storage.Type.local).put("trailerTypeFV", "");
			var oRouter = sap.ui.core.UIComponent.getRouterFor(this);
			var vDoc = "F";
			oRouter.navTo("TrailerInformation", {
				objectId: vDoc
			});
			this._CurrentlyHookedDialog.close();
			//	this.ontrailerType();
		},

		//--------------onLoadedTrailerPress in the Hooked Trailer Dialog--------------------//
		onIssueLoadedTrailerPress: function() {
			jQuery.sap.storage(jQuery.sap.storage.Type.local).put("issueDrop", "L");
			jQuery.sap.storage(jQuery.sap.storage.Type.local).put("returnDrop", "");
			jQuery.sap.storage(jQuery.sap.storage.Type.local).put("trailerTypeFV", "");
			if (!this._inBoundDialog) {
				this._inBoundDialog = sap.ui.xmlfragment("chep.checkin.fragments.InBoundReference", this);
				this.getView().addDependent(this._inBoundDialog);
			}
			// toggle compact style
			jQuery.sap.syncStyleClass("sapUiSizeCompact", this.getView(), this._inBoundDialog);
			this._CurrentlyHookedDialog.close();
			this._inBoundDialog.open();
		},

		//--------------BobTailPress in the Hooked Trailer Dialog--------------------//
		onIssueBobtailPress: function() {
			jQuery.sap.storage(jQuery.sap.storage.Type.local).put("issueDrop", "B");
			jQuery.sap.storage(jQuery.sap.storage.Type.local).put("returnDrop", "");
			jQuery.sap.storage(jQuery.sap.storage.Type.local).put("trailerTypeFV", "");
			this._CurrentlyHookedDialog.close();
			var oRouter = sap.ui.core.UIComponent.getRouterFor(this);
			var vDoc = "F";
			oRouter.navTo("TrailerInformation", {
				objectId: vDoc
			});
		},

		//--------------OK Press function in the InBound Dialog--------------------//
		onOKPress: function() {
			this._inBoundDialog.close();
			var oRouter = sap.ui.core.UIComponent.getRouterFor(this);
			oRouter.navTo("CheckIn");
		},

		//--------Function for Cancel button----------//
		onDetailCancel: function() {
			jQuery.sap.storage(jQuery.sap.storage.Type.local).put("PageType", "");
			var oRouter = sap.ui.core.UIComponent.getRouterFor(this);
			oRouter.navTo("CheckIn");
			this.byId("orderId").setText("");
			this.byId("deliverytype").setText("");
			this.byId("ds_location").setText("");
		},

		//--------Function for Back button----------//
		onNavBack: function() {
			jQuery.sap.storage(jQuery.sap.storage.Type.local).put("PageType", "");
			oInsCreateDailog.open();
			var oRouter = sap.ui.core.UIComponent.getRouterFor(this);
			oRouter.navTo("CheckIn");
			this.byId("orderId").setText("");
			this.byId("deliverytype").setText("");
			this.byId("ds_location").setText("");
			oInsCreateDailog.close();
		},

		onListOfDel: function() {
			oInsCreateDailog.open();
			if (!listDelvDialog) {
				listDelvDialog = sap.ui.xmlfragment("fragDelv", "chep.checkin.fragments.ListOfDeliveries", this);
				this.getView().addDependent(listDelvDialog);
			}
			jQuery.sap.syncStyleClass("sapUiSizeCompact", this.getView(), this.listDelvDialog);

			if (storeMilkList !== undefined) {
				if (storeMilkList.length > 0) {
					sap.ui.getCore().byId("fragDelv--DetailTable_ID").setVisible(true);
					var milkoModel = new sap.ui.model.json.JSONModel({
						"results": storeMilkList
					});
					sap.ui.getCore().byId("fragDelv--DetailTable_ID").setModel(milkoModel, "deliveryMod");
				} else {
					sap.ui.getCore().byId("fragDelv--DetailTable_ID").setVisible(false);
					sap.ui.getCore().byId("fragDelv--tipTableId").setVisible(true);
				}

			}

			if (tipMilkList !== undefined) {
				if (tipMilkList.length > 0) {
					sap.ui.getCore().byId("fragDelv--tipTableId").setVisible(true);
					var tipoModel = new sap.ui.model.json.JSONModel({
						"results": tipMilkList
					});
					sap.ui.getCore().byId("fragDelv--tipTableId").setModel(tipoModel, "tipListMod");
				} else {
					sap.ui.getCore().byId("fragDelv--tipTableId").setVisible(false);
					sap.ui.getCore().byId("fragDelv--DetailTable_ID").setVisible(true);
				}

			}
			oInsCreateDailog.close();
			listDelvDialog.open();
		},

		onListDeliveriesOK: function() {
			listDelvDialog.close();
		},

		onItemDelete: function(e) {
			oInsCreateDailog.open();
			if (e.getSource().getParent().getParent().getItems().length > 0) {
				var path1 = e.getSource().oPropagatedProperties.oBindingContexts.deliveryMod.sPath;
				var index = parseInt(path1.substring(path1.lastIndexOf('/') + 1));
				var m = e.getSource().getModel("deliveryMod");
				var d = m.getData().results;
				d.splice(index, 1);
				m.setProperty("/results", d);
				storeMilkList = e.getSource().getModel("deliveryMod").getData().results;
				jQuery.sap.storage(jQuery.sap.storage.Type.local).put("milkRunList", storeMilkList);
				oInsCreateDailog.close();
			}
		},
		onItemDeleteTip: function(e) {
			oInsCreateDailog.open();
			if (e.getSource().getParent().getParent().getItems().length > 0) {
				var path1 = e.getSource().oPropagatedProperties.oBindingContexts.tipListMod.sPath;
				var index = parseInt(path1.substring(path1.lastIndexOf('/') + 1));
				var m = e.getSource().getModel("tipListMod");
				var d = m.getData().results;
				d.splice(index, 1);
				m.setProperty("/results", d);
				tipMilkList = e.getSource().getModel("tipListMod").getData().results;
				jQuery.sap.storage(jQuery.sap.storage.Type.local).put("tipReloadList", tipMilkList);
				oInsCreateDailog.close();
			}
		},

		TipForAddDelivery: function(oEvent) {
			if (sDelType === "I") {
				if (oEvent.getSource().getItems()[0] !== undefined) {
					if (sap.ui.getCore().byId(oEvent.getSource().getItems()[0].getAggregation("cells")[1].getId()) !== undefined) {
						sap.ui.getCore().byId(oEvent.getSource().getItems()[0].getAggregation("cells")[1].getId()).setVisible(false);
					}
				}
			} else {
				if (oEvent.getSource().getItems()[0] !== undefined) {
					if (sap.ui.getCore().byId(oEvent.getSource().getItems()[0].getAggregation("cells")[1].getId()) !== undefined) {
						sap.ui.getCore().byId(oEvent.getSource().getItems()[0].getAggregation("cells")[1].getId()).setVisible(true);
					}
				}
			}

		},

		onUpdateFinishForAddDelivery: function(oEvent) {
			if (sDelType === "R") {
				if (oEvent.getSource().getItems()[0] !== undefined) {
					if (sap.ui.getCore().byId(oEvent.getSource().getItems()[0].getAggregation("cells")[1].getId()) !== undefined) {
						sap.ui.getCore().byId(oEvent.getSource().getItems()[0].getAggregation("cells")[1].getId()).setVisible(false);
					}
				}
			} else {
				if (oEvent.getSource().getItems()[0] !== undefined) {
					if (sap.ui.getCore().byId(oEvent.getSource().getItems()[0].getAggregation("cells")[1].getId()) !== undefined) {
						sap.ui.getCore().byId(oEvent.getSource().getItems()[0].getAggregation("cells")[1].getId()).setVisible(true);
					}
				}
			}

		}
	});
});