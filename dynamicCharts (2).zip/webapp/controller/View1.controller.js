sap.ui.define([
	"sap/ui/core/mvc/Controller",
	"sap/ui/model/json/JSONModel",
	"sap/m/MessageBox"
], function(Controller, JSONModel, MessageBox) {
	"use strict";

	return Controller.extend("com.dynamicChartsdynamicCharts.controller.View1", {

		onInit: function() {
			var that = this;
			var oModel = new JSONModel(jQuery.sap.getModulePath("com.dynamicChartsdynamicCharts", "/model/comboModel.json"));
			that.getView().setModel(oModel, "comboModel");
			var value = new JSONModel({
				input: "",
				comboBox: "",
				visibleChart: false
			});
			that.getView().setModel(value, "valueModel");
		},
		onSubmitInput: function() {
			var that = this;
			var url = that.getView().getModel("valueModel").getData().input;
			that.handlingInput(url);
		},
		handlingInput: function(url) {
			var that = this;
			var input = that.getView().getModel("valueModel").getData().input;
			var vizType = that.getView().getModel("valueModel").getData().comboBox;
			var array = input.split("/", "7");
			var entity = array.slice(-1).toString();
			var uri = input.replace(entity, "");
			that.getData(uri, entity, vizType);
		},
		getData: function(url, entity, vizType) {
			var that = this;
			var oModel1 = new sap.ui.model.odata.ODataModel(url, true);
			var busyDialog = new sap.m.BusyDialog({
				text: "Data loading please wait..."
			});
			busyDialog.open();
			oModel1.read("/" + entity, {
				success: function(oData) {
					busyDialog.close();
					var oModel = new JSONModel(oData);
					if (oData !== "") {
						that.getView().getModel("valueModel").setProperty("/visibleChart", true);
						that.handlingVizTypes(oData, vizType);
						that.getView().setModel(oModel, "employeeData");
					} else {
						oModel.setData({
							results: []
						});
					}
				},
				error: function(err) {
					busyDialog.close();
					var error = JSON.parse(err.response.body).error.message.value;
					sap.m.MessageBox.error(error);
				}
			});
		},
		handlingVizTypes: function(oData, vizType) {
			var that = this;
			if (vizType === "pie") {
				oData.vizType = "pie";
				oData.measureUid = "size";
				oData.dimensionUid = "color";
				// getting vizProperties as string from i18n and assigning to the key of the object(oData) in object format.
				oData.properties = JSON.parse(that.getView().getModel("i18n").getResourceBundle().getText("vizPropertiesPie"));
			} else if (vizType === "donut") {
				oData.vizType = "donut";
				oData.measureUid = "size";
				oData.dimensionUid = "color";
				// getting vizProperties as string from i18n and assigning to the key of the object(oData) in object format.
				oData.properties = JSON.parse(that.getView().getModel("i18n").getResourceBundle().getText("vizPropertiesDonut"));
			} else if (vizType === "bar") {
				oData.vizType = "bar";
				oData.measureUid = "valueAxis";
				oData.dimensionUid = "categoryAxis";
				// getting vizProperties as string from i18n and assigning to the key of the object(oData) in object format.
				oData.properties = JSON.parse(that.getView().getModel("i18n").getResourceBundle().getText("vizPropertiesBar"));
			} else if (vizType === "column") {
				oData.vizType = "column";
				oData.measureUid = "valueAxis";
				oData.dimensionUid = "categoryAxis";
				// getting vizProperties as string from i18n and assigning to the key of the object(oData) in object format.
				oData.properties = JSON.parse(that.getView().getModel("i18n").getResourceBundle().getText("vizPropertiesColumn"));
			}
		}
	});
});