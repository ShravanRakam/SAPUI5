/*global QUnit*/

jQuery.sap.require("sap.ui.qunit.qunit-css");
jQuery.sap.require("sap.ui.thirdparty.qunit");
jQuery.sap.require("sap.ui.qunit.qunit-junit");
QUnit.config.autostart = false;

sap.ui.require([
	"sap/ui/test/Opa5",
	"com/kkvd/ZZKKViewsDispute/test/integration/pages/Common",
	"sap/ui/test/opaQunit",
	"com/kkvd/ZZKKViewsDispute/test/integration/pages/Worklist",
	"com/kkvd/ZZKKViewsDispute/test/integration/pages/Object",
	"com/kkvd/ZZKKViewsDispute/test/integration/pages/NotFound",
	"com/kkvd/ZZKKViewsDispute/test/integration/pages/Browser",
	"com/kkvd/ZZKKViewsDispute/test/integration/pages/App"
], function (Opa5, Common) {
	"use strict";
	Opa5.extendConfig({
		arrangements: new Common(),
		viewNamespace: "com.kkvd.ZZKKViewsDispute.view."
	});

	sap.ui.require([
		"com/kkvd/ZZKKViewsDispute/test/integration/WorklistJourney",
		"com/kkvd/ZZKKViewsDispute/test/integration/ObjectJourney",
		"com/kkvd/ZZKKViewsDispute/test/integration/NavigationJourney",
		"com/kkvd/ZZKKViewsDispute/test/integration/NotFoundJourney",
		"com/kkvd/ZZKKViewsDispute/test/integration/FLPIntegrationJourney"
	], function () {
		QUnit.start();
	});
});