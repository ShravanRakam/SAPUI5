sap.ui.define([
	"sap/ui/core/mvc/Controller",
	"sap/m/MessageBox",
	"sap/ndc/BarcodeScanner",
	"sap/ui/model/json/JSONModel",
	"sap/ui/model/Filter",
	"sap/ui/model/FilterOperator"
], function(Controller, MessageBox, BarcodeScanner, JSONModel, Filter, FilterOperator) {
	"use strict";

	return Controller.extend("Navigation1.controller.Search", {
		onInit: function() {
			var that = this;
			var oRouter = this.getOwnerComponent().getRouter();
			oRouter.getRoute("search").attachMatched(function(oEvent) {
				this._onObjectMathced();
			}, this);
				
		
			// that.onClearFunction();

		},
		_onObjectMathced: function() {
			var that = this;
			var data = {
				results: [{
					PurchasingGroup: "001",
					Amount: "1000",
					PoNumber: "0001000001",
					PODescription: "PO Number1",
					// EntryDate: "PC",
					CreatedOn: "07.02.2020",
					Createdby: "SANGAVAA"
				}, {
					PurchasingGroup: "002",
					Amount: "1000",
					PoNumber: "0001000002",
					PODescription: "PO Number2",
					// EntryDate: "PC",
					CreatedOn: "07.02.2020",
					Createdby: "SANGAVAA"
				}, {
					PurchasingGroup: "003",
					Amount: "1000",
					PoNumber: "0001000003",
					PODescription: "PO Number3",
					// EntryDate: "PC",
					CreatedOn: "07.02.2020",
					Createdby: "SANGAVAA"

				}, {
					PurchasingGroup: "HG1",
					Amount: "1000",
					PoNumber: "0001000004",
					PODescription: "PO Number4",
					// EntryDate: "PC",
					CreatedOn: "07.02.2020",
					Createdby: "SANGAVAA"
				}, {
					PurchasingGroup: "HG2",
					Amount: "1000",
					PoNumber: "0001000005",
					PODescription: "PO Number5",
					// EntryDate: "PC",
					CreatedOn: "06.02.2020",
					Createdby: "SANGAVAA"
				}, {
					PurchasingGroup: "HG3",
					Amount: "1000",
					PoNumber: "0001000006",
					PODescription: "PO Number6",
					// EntryDate: "PC",
					CreatedOn: "05.02.2020",
					Createdby: "SANGAVAA"
				}]
			};

			that.data = new JSONModel(data);
			that.getView().setModel(that.data, "barcodes");

			var viewModel = new JSONModel({
				PoNumber: "",
				vendorNo: "",
				userName: "",
				poTable: false
			});
			that.getView().setModel(viewModel, "viewModel");
			that.getView().getModel("viewModel").setProperty("/PoNumber", "");
			that.getView().getModel("viewModel").setProperty("/vendorNo", "");
			that.getView().getModel("viewModel").setProperty("/userName", "");
			
		},
	
		onNavBack: function() {
			// history.go(-1);
			var route = sap.ui.core.UIComponent.getRouterFor(this);
			route.navTo("Navigation1");
		},
		
		onPress: function() {
			var that = this;
			var route = sap.ui.core.UIComponent.getRouterFor(this);
			var pono = that.getView().getModel("viewModel").getData().PoNumber;
			var vendorNo = that.getView().getModel("viewModel").getData().vendorNo;
			var userName = that.getView().getModel("viewModel").getData().userName;

			if (pono === "" && vendorNo === "" && userName === "") {
				MessageBox.error("Please enter any value");
				that.getView().getModel("viewModel").setProperty("/poTable", false);
				return;
			}
			if (pono !== "") {
				route.navTo("page2", {
					PoNumber: pono
				});
			} else {
				that.getView().getModel("viewModel").setProperty("/poTable", true);
				var model = new JSONModel(that.data.oData);
				that.getView().setModel(model, "barcodes");
			}
		},
		onItempress: function(oEvent) {
			var that = this;
			var route = sap.ui.core.UIComponent.getRouterFor(this);
			// var pono = that.getView().getModel("viewModel").getData().PoNumber;
			var obj = oEvent.getSource().getBindingContext("barcodes").getObject();
			route.navTo("page2", {
				PoNumber: obj.PoNumber
			});
			// that.getRouter().navTo("page2", {
			// objectId: pono
			// });

		},
		onPosearch: function(oEvent) {
			var that = this;
			var oval = oEvent.getSource().getValue();
			if (oval !== "") {
				that.getView().getModel("viewModel").setProperty("/vendorNo", "");
				that.getView().getModel("viewModel").setProperty("/userName", "");
			}
		},

		onVendorsearch: function(oEvent) {
			var that = this;
			var oval = oEvent.getSource().getValue();
			if (oval !== "") {
				that.getView().getModel("viewModel").setProperty("/PoNumber", "");
			}
		},
		onUsersearch: function(oEvent) {
			var that = this;
			var oval = oEvent.getSource().getValue();
			if (oval !== "") {
				that.getView().getModel("viewModel").setProperty("/PoNumber", "");
			}
		}

	});
});