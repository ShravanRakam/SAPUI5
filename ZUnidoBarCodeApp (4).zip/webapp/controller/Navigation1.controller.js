var newArray = [];
sap.ui.define([
	"sap/ui/core/mvc/Controller",
	"sap/m/MessageBox",
	"sap/ndc/BarcodeScanner",
	"Navigation1/utils/JsBarcode.all.min",
	"Navigation1/utils/jquery.scannerdetection.min",
	"Navigation1/utils/quagga.min"
], function(Controller, MessageBox, BarcodeScanner, Barcode, scannerDetection, quagga) {
	"use strict";

	return Controller.extend("Navigation1.controller.Navigation1", {
		onInit: function() {},
		onPress: function(oEvent) {
			var oRouter = sap.ui.core.UIComponent.getRouterFor(this);
			oRouter.navTo("page2");
		},

		//----------------------------------------------------------------------------------
		//Function to Busy Dialog(Pallet)
		//----------------------------------------------------------------------------------
		_getBusyDialog: function() {
			var oView = this.getView();
			if (!this.dialog) {
				this.dialog = sap.ui.xmlfragment("BarCode.fragments.BusyIndicator", this);
				oView.addDependent(this.dialog);
			}
			return this.dialog;
		},
		onScanPress: function() {
			var that = this;
			//	that._getBusyDialog.open();
			jQuery.sap.require("sap.ndc.BarcodeScanner");
			sap.ndc.BarcodeScanner.scan(
				function(mResult) {
					var oTable = that.byId("itemsId");
					var serialNumber = oTable.getItems().length + 1;
					var sObject = {};

					sObject.code = mResult.text;
					//alert(sObject.code);
					sObject.format = mResult.format;
					sObject.number = serialNumber;
					var i18nModel = that.getOwnerComponent();
					var error = i18nModel.getModel("i18n").getProperty('submiterror');
					var inputMsg = i18nModel.getModel("i18n").getProperty('code');
					if (sObject.code === "") {
						sap.m.MessageBox.show(
							inputMsg, {
								icon: sap.m.MessageBox.Icon.ERROR,
								title: error //"Error during submitting!"
							});

					} else if (sObject.format === "") {
						sap.m.MessageBox.show(
							inputMsg, {
								icon: sap.m.MessageBox.Icon.ERROR,
								title: error //"Error during submitting!"
							});

					} else {
						newArray.push(sObject);
						var oModel = new sap.ui.model.json.JSONModel(newArray);
						oTable.setModel(oModel, "barcodes");
					}

				},
				function(Error) {
					var i18nModel = that.getOwnerComponent();
					var error = i18nModel.getModel("i18n").getProperty('submiterror');
					var inputMsg = i18nModel.getModel("i18n").getProperty('code');
					sap.m.MessageBox.show(
						inputMsg, {
							icon: sap.m.MessageBox.Icon.ERROR,
							title: error //"Error during submitting!"
						});
				}

			);

		},
		onItemDelete: function(e) {
			if (e.getSource().getItems().length > 0) {
				var path = e.getParameter('listItem').getBindingContext("barcodes").getPath();
				var idx = parseInt(path.substring(path.lastIndexOf('/') + 1));
				var m = e.getSource().getModel("barcodes");

				var d = m.getData();
				d.splice(idx, 1);
				for (var i = 0; i < d.length; i++) {
					d[i].number = i + 1;
				}
				m.setData(d);

			}
		},
		onScanPress1: function() {
			if (!this._oScanDialog) {
				this._oScanDialog = new sap.m.Dialog({
					title: "Scan barcode",
					contentWidth: "640px",
					contentHeight: "480px",
					horizontalScrolling: false,
					verticalScrolling: false,
					stretchOnPhone: true,
					content: [new sap.ui.core.HTML({
						id: this.createId("scanContainer"),
						content: "<div />"
					})],
					endButton: new sap.m.Button({
						text: "Manual Purchase Order Entry",
						press: function(oEvent) {
							// this._oScanDialog.close();
							this.onCancelPress();
						}.bind(this)
					}),
					afterOpen: function() {
						// this.onScanPress();
						this._initQuagga(this.getView().byId("scanContainer").getDomRef()).done(function() {
							// Initialisation done, start Quagga
							Quagga.start();
						}).fail(function(oError) {
							// Failed to initialise, show message and close dialog...this should not happen as we have
							// already checked for camera device ni /model/models.js and hidden the scan button if none detected
							sap.m.MessageBox.error(oError.message.length ? oError.message : ("Failed to initialise Quagga with reason code " + oError.name), {
								onClose: function() {
									this._oScanDialog.close();
								}.bind(this)
							});
						}.bind(this));
					}.bind(this),
					afterClose: function() {
						// Dialog closed, stop Quagga
						Quagga.stop();
					}
				});

				this.getView().addDependent(this._oScanDialog);
			}

			this._oScanDialog.open();

			// var scanner = barcodeScanner.createInstance();
			// scanner.onFrameRead = function(results){
			//     if(results.length >0){
			//         console.log(results);
			//     }
			// };
			// scanner.onUniqueRead = function (txt, result) {
			//     this.getView().byId("idSearchField").setValue(txt);
			//     alert(txt);                    
			// };
			// scanner.show();
		},

		onCancelPress: function() {
			// this._oScanDialog.close();
			var oRouter = sap.ui.core.UIComponent.getRouterFor(this);
			// oRouter.navTo("page2");
			oRouter.navTo("search");
		},
		_initQuagga: function(oTarget) {
			var oDeferred = jQuery.Deferred();

			// Initialise Quagga plugin - see https://serratus.github.io/quaggaJS/#configobject for details
			Quagga.init({
				inputStream: {
					type: "LiveStream",
					target: oTarget,
					constraints: {
						width: {
							min: 640
						},
						height: {
							min: 480
						},
						facingMode: "environment"
					}
				},
				locator: {
					patchSize: "medium",
					halfSample: true
				},
				numOfWorkers: 2,
				frequency: 10,
				decoder: {
					readers: [{
						format: "code_128_reader",
						config: {}
					}]
				},
				locate: true
			}, function(error) {
				if (error) {
					oDeferred.reject(error);
				} else {
					oDeferred.resolve();
				}
			});

			if (!this._oQuaggaEventHandlersAttached) {
				// Attach event handlers...

				Quagga.onProcessed(function(result) {
					var drawingCtx = Quagga.canvas.ctx.overlay,
						drawingCanvas = Quagga.canvas.dom.overlay;

					if (result) {
						// The following will attempt to draw boxes around detected barcodes
						if (result.boxes) {
							drawingCtx.clearRect(0, 0, parseInt(drawingCanvas.getAttribute("width")), parseInt(drawingCanvas.getAttribute("height")));
							result.boxes.filter(function(box) {
								return box !== result.box;
							}).forEach(function(box) {
								Quagga.ImageDebug.drawPath(box, {
									x: 0,
									y: 1
								}, drawingCtx, {
									color: "green",
									lineWidth: 2
								});
							});
						}

						if (result.box) {
							Quagga.ImageDebug.drawPath(result.box, {
								x: 0,
								y: 1
							}, drawingCtx, {
								color: "#00F",
								lineWidth: 2
							});
						}

						if (result.codeResult && result.codeResult.code) {
							Quagga.ImageDebug.drawPath(result.line, {
								x: 'x',
								y: 'y'
							}, drawingCtx, {
								color: 'red',
								lineWidth: 3
							});
						}
					}
				}.bind(this));

				Quagga.onDetected(function(result) {
					// Barcode has been detected, value will be in result.codeResult.code. If requierd, validations can be done 
					// on result.codeResult.code to ensure the correct format/type of barcode value has been picked up

					// Set barcode value in input field
					this.getView().byId("idSearchField").setValue(result.codeResult.code);

					// Close dialog
					this._oScanDialog.close();
				}.bind(this));

				// Set flag so that event handlers are only attached once...
				this._oQuaggaEventHandlersAttached = true;
			}

			return oDeferred.promise();
		},

		onItempress: function(oEvent) {
				var that = this;
			var route = sap.ui.core.UIComponent.getRouterFor(this);
			// var pono = that.getView().getModel("viewModel").getData().PoNumber;
			var obj = oEvent.getSource().getBindingContext("barcodes").getObject();
			route.navTo("page2", {
				PoNumber: obj.code
	
			}); }
	});

});