sap.ui.define([
	"sap/ui/core/mvc/Controller",
	"sap/ui/model/json/JSONModel"
], function(Controller, JSONModel) {
	"use strict";

	return Controller.extend("skip_and_topskip_and_top.controller.View1", {
		onInit: function() {
			var that = this;
			var oModel = new JSONModel();
			oModel.setData({
				skip: 0,
				top: 5
			});
			that.getView().setModel(oModel, "oModel");
			// var oDataModel = that.getOwnerComponent().getModel();

			that.readTable();
		},
		readTable: function() {
			var that = this;
			var oModel = that.getView().getModel("oModel");
			var skip = oModel.getProperty("/skip");
			var top = oModel.getProperty("/top");
			var url = "/sap/opu/odata/sap/ZHR_EMPDETAILS_SRV/";
			var oDataModel = new sap.ui.model.odata.ODataModel(url, true);
			oDataModel.read("/EmpdataSet", {
				urlParameters: {
					"$top": top,
					"$skip": skip
				},
				success: function(data, res) {
					if (res.statusCode === "200" || res.statusCode === 200) {
						var oJsonModel = new sap.ui.model.json.JSONModel(data);
						that.getView().setModel(oJsonModel, "oJsonModel");
					}
				},
				error: function(error) {

				}
			});
		},
		onPrev: function() {
			var that = this;
			var oModel = that.getView().getModel("oModel");
			var skip = oModel.getProperty("/skip");
			var top = oModel.getProperty("/top");
			oModel.setProperty("/skip", skip - top);
			that.readTable();

		},
		onNext: function() {
				var that = this;
				var oModel = that.getView().getModel("oModel");
				var skip = oModel.getProperty("/skip");
				var top = oModel.getProperty("/top");
				// if (skip < top) {
				oModel.setProperty("/skip", skip + top);
				// this._updateTableItems();
				// }
				that.readTable();
			}
			// bindTable: function() {
			// 	var that = this;
			// 	var oModel = this.getView().getModel("oModel");
			// 	var skip = oModel.getProperty("/skip");
			// 	var top = oModel.getProperty("/top");
			// 	// var url = "/sap/opu/odata/sap/ZHR_EMPDETAILS_SRV/";
			// 	// var oDataModel = new sap.ui.model.odata.ODataModel(url, true);

		// 	// var sServiceUrl = "/sap/opu/odata/sap/ZHR_EMPDETAILS_SRV/";
		// 	// var oDatamodel = new sap.ui.model.odata.ODataModel(sServiceUrl,true);
		// 	// var sPath = "/EmpdataSet";
		// 	// oDatamodel.read(sPath, {
		// 	// 	// urlParameters: {
		// 	// 	// 	"$top": 5,
		// 	// 	// 	"$skip": 0
		// 	// 	// },
		// 	// 	success: function(oData,res) {
		// 	// 	if(res === "200" || res === 200){
		// 	// 		// if (top !== 0) {
		// 	// 			var oJsonModel = new sap.ui.model.json.JSONModel(oData);

		// 	// 			that.getView().setModel(oJsonModel,"oJsonModel");
		// 	// 		// } else {
		// 	// 		// 	that.initialCount = oData.results.length;
		// 	// 		// }
		// 	// 	}
		// 	// 	},
		// 	// 	error: function() {}
		// 	// });
		// }

	});
});