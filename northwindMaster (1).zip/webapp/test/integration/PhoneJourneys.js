/*global QUnit*/

jQuery.sap.require("sap.ui.qunit.qunit-css");
jQuery.sap.require("sap.ui.thirdparty.qunit");
jQuery.sap.require("sap.ui.qunit.qunit-junit");
QUnit.config.autostart = false;

sap.ui.require([
	"sap/ui/test/Opa5",
	"com/northwindMaster/northwindMaster/test/integration/pages/Common",
	"sap/ui/test/opaQunit",
	"com/northwindMaster/northwindMaster/test/integration/pages/App",
	"com/northwindMaster/northwindMaster/test/integration/pages/Browser",
	"com/northwindMaster/northwindMaster/test/integration/pages/Master",
	"com/northwindMaster/northwindMaster/test/integration/pages/Detail",
	"com/northwindMaster/northwindMaster/test/integration/pages/NotFound"
], function (Opa5, Common) {
	"use strict";
	Opa5.extendConfig({
		arrangements: new Common(),
		viewNamespace: "com.northwindMaster.northwindMaster.view."
	});

	sap.ui.require([
		"com/northwindMaster/northwindMaster/test/integration/NavigationJourneyPhone",
		"com/northwindMaster/northwindMaster/test/integration/NotFoundJourneyPhone",
		"com/northwindMaster/northwindMaster/test/integration/BusyJourneyPhone"
	], function () {
		QUnit.start();
	});
});