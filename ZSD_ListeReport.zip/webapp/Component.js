jQuery.sap.declare("com.appzsd_listereport.Component");
sap.ui.getCore().loadLibrary("sap.ui.generic.app");
jQuery.sap.require("sap.ui.generic.app.AppComponent");

sap.ui.generic.app.AppComponent.extend("com.appzsd_listereport.Component", {
	metadata: {
		"manifest": "json"
	}
});