var inlineTable;
var titleError;
var close;
// var stateComboBox;
sap.ui.define([
	"./BaseController",
	"sap/ui/model/json/JSONModel",
	"sap/ui/core/routing/History",
	"../model/formatter",
	"sap/m/DatePicker"
], function (BaseController, JSONModel, History, formatter, DatePicker) {
	"use strict";
	var fileDataArr = [];

	return BaseController.extend("com.empqualassignment.Employee_Qual_Assignment.controller.Object", {

		formatter: formatter,

		/* =========================================================== */
		/* lifecycle methods                                           */
		/* =========================================================== */

		/**
		 * Called when the worklist controller is instantiated.
		 * @public
		 */
		onInit: function () {
			var that = this;
			// var oController = that.getView().getController();
			that.getRouter().getRoute("object").attachPatternMatched(that._onObjectMatched, that);
			that.stateDataFun();
			/*stateComboBox = new sap.m.ComboBox({
				width: "45%",
				change: [oController.onAdditionalInfoChange, oController]
			}).addStyleClass("comboBgCls");
			var oStateTemp = new sap.ui.core.ListItem({
				key: "{stateData>State}",
				text: "{stateData>State}"
			});

			stateComboBox.bindItems({
				path: "stateData>/results",
				template: oStateTemp
			});*/

			/*var emptyArr = [];
			var oEmptyModel = new sap.ui.model.json.JSONModel(emptyArr);

			inlineTable = new sap.m.Table({
				id: "uploadAttachmentsTable",
				columns: [new sap.m.Column({
						header: new sap.m.Label({
							text: "Attachment",
							design: "Bold"
						})
					}),
					new sap.m.Column({
						visible: false,
						header: new sap.m.Label({
							text: "Data"
						})
					}),
					new sap.m.Column({
						header: new sap.m.Label({
							text: ""
						})
					})
				]
			}).addStyleClass("clsTableHeader clsColumnHeader clsTableRows");
			inlineTable.bindItems("oAttachData>/", new sap.m.ColumnListItem({
				cells: [
					new sap.m.Text({
						text: "{oAttachData>FileName}"
					}),
					new sap.m.Input({
						value: "{oAttachData>FileData}"
					}),
					new sap.m.Button({
						icon: "sap-icon://delete",
						press: [oController.onFileDelete, oController]
					}).addStyleClass("clsBtnColorYellowRed")
				]
			}));

			sap.ui.getCore().byId("uploadAttachmentsTable").setModel(oEmptyModel, "oAttachData");*/
		},

		_onObjectMatched: function (oEvent) {
			var that = this;

			that.srvResp = "Yes";

			var emptyArr = [];
			var oEmptyModel = new sap.ui.model.json.JSONModel(emptyArr);
			var attachmentsTable = that.byId("createUploadAttachmentsTable");
			attachmentsTable.setModel(oEmptyModel, "oAttachData");

			var empNo = oEvent.getParameter("arguments").empNo;
			var craft = oEvent.getParameter("arguments").craft;

			if (craft === "Engineering") {
				that.craftType = "TRACS - Engineering";
			}
			if (craft === "Mechanical") {
				that.craftType = "TRACS - Mechanica";
			}
			if (craft === "TCU") {
				that.craftType = "TRACS - TCU";
			}
			var endDate = oEvent.getParameter("arguments").endDate;
			var oEndDate = endDate.substring(4, 6) + "/" + endDate.substring(6, 8) + "/" + endDate.substring(0, 4);
			var qualID = oEvent.getParameter("arguments").qualID;
			that.qualId = qualID;
			that.qualifications = decodeURIComponent(oEvent.getParameter("arguments").qualifications);
			var qualproficiency = oEvent.getParameter("arguments").qualproficiency;
			var startDate = oEvent.getParameter("arguments").startDate;
			var oStartDate = startDate.substring(4, 6) + "/" + startDate.substring(6, 8) + "/" + startDate.substring(0, 4);
			var effDate = oEvent.getParameter("arguments").effDate;

			that.byId("objEmpNo").setText(empNo);
			that.byId("objEnDate").setText(oEndDate);
			that.byId("objQualInp").setText(that.qualifications);
			that.byId("objEffDate").setValue(effDate);
			that.byId("objProfScale").setText(qualproficiency);
			that.byId("objStDate").setText(oStartDate);
			that.byId("objCraftType").setText(craft);

			var qualModel = that.getOwnerComponent().getModel();
			qualModel.read("/QualiSearchHelpSet(QualId='" + qualID + "')", {
				success: function (oData, Response) {
					var columnsArr = [];
					var columnObj = {};
					that.columnsArray = [];
					var Document;
					var columnsObj = {};
					if (oData.Document !== "") {
						Document = oData.Document;
						columnsObj.Document = oData.Document;
					} else {
						Document = "";
					}

					var AddField1;
					if (oData.AddField1 !== "") {
						AddField1 = oData.AddField1;
						columnsObj.AddField1 = oData.AddField1;
					} else {
						AddField1 = oData.AddField1;
					}
					var AddField2;
					if (oData.AddField2 !== "") {
						AddField2 = oData.AddField2;
						columnsObj.AddField2 = oData.AddField2;
					} else {
						AddField2 = oData.AddField2;
					}
					var AddField3;
					if (oData.AddField3 !== "") {
						AddField3 = oData.AddField3;
						columnsObj.AddField3 = oData.AddField3;
					} else {
						AddField3 = oData.AddField3;
					}
					var AddField4;
					if (oData.AddField4 !== "") {
						AddField4 = oData.AddField4;
						columnsObj.AddField4 = oData.AddField4;
					} else {
						AddField4 = oData.AddField4;
					}
					var AddField5;
					if (oData.AddField5 !== "") {
						AddField5 = oData.AddField5;
						columnsObj.AddField5 = oData.AddField5;
					} else {
						AddField5 = oData.AddField5;
					}
					var AddField6;
					if (oData.AddField6 !== "") {
						AddField6 = oData.AddField6;
						columnsObj.AddField6 = oData.AddField6;
					} else {
						AddField6 = oData.AddField6;
					}
					var AddField7;
					if (oData.AddField7 !== "") {
						AddField7 = oData.AddField7;
						columnsObj.AddField7 = oData.AddField7;
					} else {
						AddField7 = oData.AddField7;
					}
					var AddField8;
					if (oData.AddField8 !== "") {
						AddField8 = oData.AddField8;
						columnsObj.AddField8 = oData.AddField8;
					} else {
						AddField8 = oData.AddField8;
					}
					var AddField9;
					if (oData.AddField9 !== "") {
						AddField9 = oData.AddField9;
						columnsObj.AddField9 = oData.AddField9;
					} else {
						AddField9 = oData.AddField9;
					}
					var AddField10;
					if (oData.AddField10 !== "") {
						AddField10 = oData.AddField10;
						columnsObj.AddField10 = oData.AddField10;
					} else {
						AddField10 = oData.AddField10;
					}

					that.columnsArray.push(columnsObj);

					if (Document !== "") {
						columnsArr.push(Document);
					}
					if (AddField1 !== "") {
						columnsArr.push(AddField1);
					}
					if (AddField2 !== "") {
						columnsArr.push(AddField2);
					}
					if (AddField3 !== "") {
						columnsArr.push(AddField3);
					}
					if (AddField4 !== "") {
						columnsArr.push(AddField4);
					}
					if (AddField5 !== "") {
						columnsArr.push(AddField5);
					}
					if (AddField6 !== "") {
						columnsArr.push(AddField6);
					}
					if (AddField7 !== "") {
						columnsArr.push(AddField7);
					}
					if (AddField8 !== "") {
						columnsArr.push(AddField8);
					}
					if (AddField9 !== "") {
						columnsArr.push(AddField9);
					}
					if (AddField10 !== "") {
						columnsArr.push(AddField10);
					}

					var oJsonModel = new JSONModel();
					oJsonModel.setData(columnsArr);
					that.getView().setModel(oJsonModel, "oJsonModel");
					// }

					if (AddField1 !== "" || AddField2 !== "" || AddField3 !== "" || AddField4 !== "" || AddField5 !== "" || AddField6 !== "" ||
						AddField7 !== "" || AddField8 !== "" || AddField9 !== "" || AddField10 !== "" || Document !== "") {

						that.byId("qualAddSaveBtn").setEnabled(false);

						var oController = that.getView().getController();
						// var allColsArray = that.columnsArray;
						var additionalInfo = that.getView().getModel("oJsonModel");
						var oAdditionalForm = that.getView().byId("additionalInfoForm");

						for (var i = 0; i < additionalInfo.oData.length; i++) {
							var oFieldVal = additionalInfo.oData[i];
							if (oFieldVal !== "Yes" && oFieldVal !== "No" && oFieldVal !== "YES" && oFieldVal !== "NO" && oFieldVal !== "") {
								oAdditionalForm.addContent(new sap.m.Label({
									text: oFieldVal,
									design: "Bold"
								}).addStyleClass("clsLabelColor"));

								if (oFieldVal === "State" || oFieldVal === "STATE") {
									var stateComboBox = that.byId("stateComboBox");
									that.byId("stateComboBox").setVisible(true);
									oAdditionalForm.addContent(stateComboBox);
								} else if (oFieldVal.includes("Date") || oFieldVal.includes("DATE")) {
									oAdditionalForm.addContent(new sap.m.DatePicker({
										displayFormat: "MM/dd/yyyy",
										valueFormat: "yyyyMMdd",
										width: "100%",
										change: [oController.onAdditionalInfoChange, oController]
									}).addStyleClass("inpBaseBg inpIconColor"));
								} else {
									oAdditionalForm.addContent(new sap.m.Input({
										value: "",
										width: "100%",
										change: [oController.onAdditionalInfoChange, oController]
									}));
								}
							}
						}

						oAdditionalForm.addContent(new sap.m.Label({
							text: "Upload Documents",
							design: "Bold"
						}).addStyleClass("clsLabelColor"));
						// if (additionalInfo.oData[0] === "Yes" || additionalInfo.oData[0] === "YES") {
						if (additionalInfo.oData[0] === "Yes" || additionalInfo.oData[0] === "YES") {
							that.byId("createUploaderHbox").setVisible(true);
							that.byId("createUploadAttachmentsTable").setVisible(true);
							// oAdditionalForm.addContent(new sap.ui.unified.FileUploader({
							// 	id: "fileUploader",
							// 	change: [oController.onFileUpload, oController],
							// 	enabled: true
							// }));
							// /*	oAdditionalForm.addContent(new sap.m.Button({
							// 		enabled: true,
							// 		text: "Upload",
							// 		press: [oController.onFileUpload, oController]
							// 	}));*/
							// oAdditionalForm.addContent(new sap.m.Label({
							// 	text: ""
							// }));
							// oAdditionalForm.addContent(
							// 	inlineTable
							// 	/*inlineTable = new sap.m.Table({
							// 		id: "uploadAttachmentsTable",
							// 		columns: [new sap.m.Column({
							// 				header: new sap.m.Text({
							// 					text: "Attachment"
							// 				})
							// 			}),
							// 			new sap.m.Column({
							// 				header: new sap.m.Text({
							// 					text: "Data"
							// 				})
							// 			})
							// 		]
							// 	}),
							// 	inlineTable.bindItems("oAttachData>/results", new sap.m.ColumnListItem({
							// 		cells: [
							// 			new sap.m.Text({
							// 				text: "{oAttachData>FileName}"
							// 			}),
							// 			new sap.m.Input({
							// 				value: "{oAttachData>FileData}"
							// 			})
							// 		]
							// 	}))*/
							// );
						} else {
							that.byId("createUploaderHbox").setVisible(false);
							that.byId("createUploadAttachmentsTable").setVisible(false);
							// oAdditionalForm.addContent(new sap.ui.unified.FileUploader({
							// 	enabled: false
							// }));
						}

					} else {
						that.byId("qualAddSaveBtn").setEnabled(true);
					}
				},
				error: function (oResponse) {

					//-----------------------------------------------------------------------	
					// Displaying response body message.
					//-----------------------------------------------------------------------

					var oMessage = $(oResponse.response.body).find('message').first().text();
					var errmsg;
					if (oMessage === "") {
						errmsg = oResponse.response.body;
					} else {
						errmsg = oMessage;
					}
					
					sap.m.MessageBox.show(errmsg, {
						icon: sap.m.MessageBox.Icon.ERROR,
						title: titleError
					});

					/*var oCreateDialog = new sap.m.Dialog();
					oCreateDialog.setTitle(titleError);
					oCreateDialog.setIcon("sap-icon://message-error");
					oCreateDialog.addStyleClass(
						"dialogHdrBgCls dialogTitleCls dialogTextShadowCls dialogBoxShadowCls dialogIconCls dialogFooterBgCls");
					var oSimpleForm = new sap.ui.layout.form.SimpleForm({
						content: [
							new sap.m.Text({
								text: errmsg
							})
						]
					});
					oCreateDialog.addContent(oSimpleForm);

					oCreateDialog.addButton(
						new sap.m.Button({
							text: close,
							press: function () {
								oCreateDialog.close();
							}
						}).addStyleClass("sapUiSizeCompact clsBtnColorYellowRed")
					);
					oCreateDialog.open();*/

				}
			});

		},

		onAdditionalInfoChange: function () {
			var that = this;
			var oFormContent = that.byId("additionalInfoForm").getContent();
			var emptyArr = [];
			var flag = "Yes";
			if (oFormContent.length > 0) {
				for (var i = 0; i < oFormContent.length; i++) {
					if (oFormContent[i].getMetadata().getElementName() === "sap.m.Input") {
						if (oFormContent[i].getProperty("value") !== "") {
							emptyArr.push(flag);
						}
					} else if (oFormContent[i].getMetadata().getElementName() === "sap.m.ComboBox") {
						if (oFormContent[i].getProperty("value") !== "") {
							emptyArr.push(flag);
						}
					} else if (oFormContent[i].getMetadata().getElementName() === "sap.m.DatePicker") {
						if (oFormContent[i].getProperty("value") !== "") {
							emptyArr.push(flag);
						}
					}
				}

			}

			if (that.byId("createUploadAttachmentsTable").getVisible() === true) {
				var oDocsTable = that.byId("createUploadAttachmentsTable").getItems();
				if (oDocsTable.length !== 0) {
					emptyArr.push(flag);
				}
			}
			if (emptyArr.length !== 0) {
				that.byId("qualAddSaveBtn").setEnabled(true);
			} else {
				that.byId("qualAddSaveBtn").setEnabled(false);
			}
		},

		onAfterRendering: function () {
			var that = this;
			titleError = that.getView().getModel("i18n").getProperty("titleError");
			close = that.getView().getModel("i18n").getProperty("close");
		},

		// ---------------------------------------- State Dropdown binding --------------------------------------

		stateDataFun: function () {
			var that = this;

			var oModel = that.getOwnerComponent().getModel();
			oModel.read("/StateSearchHelpSet", {
				success: function (oData, Response) {
					var oStateModel = new sap.ui.model.json.JSONModel(oData);
					that.getView().setModel(oStateModel, "stateData");
				},
				error: function (oResponse) {

					//-----------------------------------------------------------------------	
					// Displaying response body message.
					//-----------------------------------------------------------------------

					var errmsg = JSON.parse(oResponse.responseText).error.message.value;
					
					sap.m.MessageBox.show(errmsg, {
						icon: sap.m.MessageBox.Icon.ERROR,
						title: titleError
					});

					/*var oCreateDialog = new sap.m.Dialog();
					oCreateDialog.setTitle(titleError);
					oCreateDialog.setIcon("sap-icon://message-error");
					oCreateDialog.addStyleClass(
						"dialogHdrBgCls dialogTitleCls dialogTextShadowCls dialogBoxShadowCls dialogIconCls dialogFooterBgCls");
					var oSimpleForm = new sap.ui.layout.form.SimpleForm({
						content: [
							new sap.m.Text({
								text: errmsg
							})
						]
					});
					oCreateDialog.addContent(oSimpleForm);

					oCreateDialog.addButton(
						new sap.m.Button({
							text: close,
							press: function () {
								oCreateDialog.close();
							}
						}).addStyleClass("sapUiSizeCompact clsBtnColorYellowRed")
					);
					oCreateDialog.open();*/

				}
			});
		},

		onFileUpload: function () {
			var that = this;

			var fileupload = that.byId("createFileUploader");
			var filename = fileupload.getValue();

			if (filename === "") {
				sap.m.MessageToast.show("Please Select File");
			} else {

				// ============================================================================
				/*Getting Multiple Records From Table*/
				// ============================================================================

				var filedata;
				var file = jQuery.sap.domById(fileupload.getId() + "-fu").files[0];
				var reader = new FileReader();
				reader.readAsDataURL(file);
				reader.onload = function () {
					var result = reader.result;
					var res = result.split(";base64,");
					filedata = res[1];

					// var fileDataArr = [];
					var fileDataObj = {};
					fileDataObj.FileName = filename;
					fileDataObj.FileData = filedata;
					fileDataArr.push(fileDataObj);

					// var fileDataModel = new JSONModel();
					// fileDataModel.setData(fileDataArr);
					// sap.ui.getCore().byId("uploadAttachmentsTable").getModel("oAttachData").setData(fileDataModel);
					that.byId("createUploadAttachmentsTable").getModel("oAttachData").setData(fileDataArr);
					that.byId("createUploadAttachmentsTable").getModel("oAttachData").refresh();
					that.onAdditionalInfoChange();

					// var columnListItem = new sap.m.ColumnListItem({
					// 	cells: [
					// 		new sap.m.Text({
					// 			text: filename
					// 		}),
					// 		new sap.m.Text({
					// 			text: filedata,
					// 			visible: true
					// 		})
					// 	]
					// });

					// sap.ui.getCore().byId("uploadAttachmentsTable").addItem(columnListItem);
				};
				reader.onerror = function (error) {
					console.log('Error: ', error);
				};
				that.byId("createFileUploader").setValue("");
			}

		},

		onFileDelete: function (oEvent) {

			var that = this;

			var oModelres = that.byId("createUploadAttachmentsTable").getModel("oAttachData").getData();
			var path = parseInt(oEvent.getSource().getId().split("createUploadAttachmentsTable-")[1]);
			oModelres.splice(path, "1");
			that.byId("createUploadAttachmentsTable").getModel("oAttachData").refresh();
			that.byId("createUploadAttachmentsTable").removeSelections(true);

			var data = that.byId("createUploadAttachmentsTable").getItems();
			if (data.length === 0) {
				that.byId("qualAddSaveBtn").setEnabled(false);
			} else {
				that.onAdditionalInfoChange();
			}
		},

		onCancel: function () {
			var that = this;
			var yes = that.getView().getModel("i18n").getProperty("yes");
			var no = that.getView().getModel("i18n").getProperty("no");
			var titleConfirm = that.getView().getModel("i18n").getProperty("titleConfirm");
			
			sap.m.MessageBox.confirm("Unsaved data will be lost, are you sure you want to cancel?", {
				title: titleConfirm,
				actions: [sap.m.MessageBox.Action.YES, sap.m.MessageBox.Action.NO],
				onClose: function (oAction) {
					if (oAction === sap.m.MessageBox.Action.YES) {

						var emptyArr = [];
						var oFormData = that.getView().byId("additionalInfoForm");
						// oFormData.destroyContent();
						oFormData.removeAllContent();
						that.byId("createUploadAttachmentsTable").getModel("oAttachData").setData(emptyArr);
						that.byId("createFileUploader").setVisible(false);
						that.byId("createUploadAttachmentsTable").setVisible(false);

						var oRouter = sap.ui.core.UIComponent.getRouterFor(that);
						oRouter.navTo("worklist");

					}
				}
			});

			/*var oCreateDialog = new sap.m.Dialog();
			oCreateDialog.setTitle(titleConfirm);
			oCreateDialog.setIcon("sap-icon://question-mark");
			oCreateDialog.addStyleClass("dialogHdrBgCls dialogTitleCls dialogTextShadowCls dialogBoxShadowCls dialogIconCls dialogFooterBgCls");
			var oSimpleForm = new sap.ui.layout.form.SimpleForm({
				content: [
					new sap.m.Text({
						text: "Unsaved data will be lost, are you sure you want to cancel?"
					})
				]
			});
			oCreateDialog.addContent(oSimpleForm);
			oCreateDialog.addButton(
				new sap.m.Button({
					text: yes,
					press: function () {
						var emptyArr = [];
						var oFormData = that.getView().byId("additionalInfoForm");
						// oFormData.destroyContent();
						oFormData.removeAllContent();
						that.byId("createUploadAttachmentsTable").getModel("oAttachData").setData(emptyArr);
						that.byId("createFileUploader").setVisible(false);
						that.byId("createUploadAttachmentsTable").setVisible(false);

						var oRouter = sap.ui.core.UIComponent.getRouterFor(that);
						oRouter.navTo("worklist");
						oCreateDialog.close();
					}
				}).addStyleClass("sapUiSizeCompact clsBtnColorYellowGreen")

			);

			oCreateDialog.addButton(
				new sap.m.Button({
					text: no,
					press: function () {
						oCreateDialog.close();
					}
				}).addStyleClass("sapUiSizeCompact clsBtnColorYellowRed")
			);
			oCreateDialog.open();*/

		},

		onSave: function () {

			var that = this;

			var titleSuccess = that.getView().getModel("i18n").getProperty("titleSuccess");
			var titleInfo = that.getView().getModel("i18n").getProperty("titleInfo");
			var ok = that.getView().getModel("i18n").getProperty("ok");

			var sDate = that.byId("objStDate").getText();
			if (sDate !== "") {
				var oSDate = sDate.split("/");
				var startDate = oSDate[2] + "" + oSDate[0] + "" + oSDate[1];
			} else {
				startDate = "";
			}
			var eDate = that.byId("objEnDate").getText();
			if (eDate !== "") {
				var oEDate = eDate.split("/");
				var endDate = oEDate[2] + "" + oEDate[0] + "" + oEDate[1];
			} else {
				endDate = "";
			}

			var cols = that.columnsArray;
			var oAdditionalInfoData = that.byId("additionalInfoForm").getContent();
			// var additionalInfoArr = [];
			var additionalInfoObj = {};
			if (oAdditionalInfoData.length > 0) {
				for (var i = 0; i < oAdditionalInfoData.length; i++) {
					if (oAdditionalInfoData[i].getMetadata().getElementName() === "sap.m.Label") {
						var oFieldName = oAdditionalInfoData[i].getProperty("text");
						if (oFieldName !== "Upload Documents") {
							if (cols[0].AddField1 !== undefined) {
								var columnName1 = cols[0].AddField1;
								var oField1 = columnName1.split(":")[0];
								if (oField1 === oFieldName) {
									additionalInfoObj.AddField1 = oAdditionalInfoData[i + 1].getProperty("value");
								}
							}
							if (cols[0].AddField2 !== undefined) {
								var columnName2 = cols[0].AddField2;
								var oField2 = columnName2.split(":")[0];
								if (oField2 === oFieldName) {
									additionalInfoObj.AddField2 = oAdditionalInfoData[i + 1].getProperty("value");
									// additionalInfoArr.push(additionalInfoObj);
								}
							}
							if (cols[0].AddField3 !== undefined) {
								var columnName3 = cols[0].AddField3;
								var oField3 = columnName3.split(":")[0];
								if (oField3 === oFieldName) {
									additionalInfoObj.AddField3 = oAdditionalInfoData[i + 1].getProperty("value");
									// additionalInfoArr.push(additionalInfoObj);
								}
							}
							if (cols[0].AddField4 !== undefined) {
								var columnName4 = cols[0].AddField4;
								var oField4 = columnName4.split(":")[0];
								if (oField4 === oFieldName) {
									additionalInfoObj.AddField4 = oAdditionalInfoData[i + 1].getProperty("value");
									// additionalInfoArr.push(additionalInfoObj);
								}
							}
							if (cols[0].AddField5 !== undefined) {
								var columnName5 = cols[0].AddField5;
								var oField5 = columnName5.split(":")[0];
								if (oField5 === oFieldName) {
									additionalInfoObj.AddField5 = oAdditionalInfoData[i + 1].getProperty("value");
									// additionalInfoArr.push(additionalInfoObj);
								}
							}
							if (cols[0].AddField6 !== undefined) {
								var columnName6 = cols[0].AddField6;
								var oField6 = columnName6.split(":")[0];
								if (oField6 === oFieldName) {
									additionalInfoObj.AddField6 = oAdditionalInfoData[i + 1].getProperty("value");
									// additionalInfoArr.push(additionalInfoObj);
								}
							}
							if (cols[0].AddField7 !== undefined) {
								var columnName7 = cols[0].AddField7;
								var oField7 = columnName7.split(":")[0];
								if (oField7 === oFieldName) {
									additionalInfoObj.AddField7 = oAdditionalInfoData[i + 1].getProperty("value");
									// additionalInfoArr.push(additionalInfoObj);
								}
							}
							if (cols[0].AddField8 !== undefined) {
								var columnName8 = cols[0].AddField8;
								var oField8 = columnName8.split(":")[0];
								if (oField8 === oFieldName) {
									additionalInfoObj.AddField8 = oAdditionalInfoData[i + 1].getProperty("value");
									// additionalInfoArr.push(additionalInfoObj);
								}
							}
							if (cols[0].AddField9 !== undefined) {
								var columnName9 = cols[0].AddField9;
								var oField9 = columnName9.split(":")[0];
								if (oField9 === oFieldName) {
									additionalInfoObj.AddField9 = oAdditionalInfoData[i + 1].getProperty("value");
									// additionalInfoArr.push(additionalInfoObj);
								}
							}
							if (cols[0].AddField10 !== undefined) {
								var columnName10 = cols[0].AddField10;
								var oField10 = columnName10.split(":")[0];
								if (oField10 === oFieldName) {
									additionalInfoObj.AddField10 = oAdditionalInfoData[i + 1].getProperty("value");
									// additionalInfoArr.push(additionalInfoObj);
								}
							}

							// additionalInfoArr.push(additionalInfoObj);

						}

					}

					// if (oFieldName === "") {
					// var oDocsData = that.byId("createUploadAttachmentsTable").getItems();
					// var attachmentsArr = [];
					// var itemsObject = {};
					additionalInfoObj.QualGroup = that.craftType;
					additionalInfoObj.QualDesc = that.byId("objQualInp").getText();
					additionalInfoObj.Qualification = that.qualId;
					additionalInfoObj.Pscale = that.byId("objProfScale").getText();
					additionalInfoObj.Begda = startDate;
					additionalInfoObj.Endda = endDate;
					additionalInfoObj.Pernr = that.byId("objEmpNo").getText();
					additionalInfoObj.Key = "D";
					// var additionalInfoArr = [];
					// for (var j = 0; j < oDocsData.length; j++) {
					// 	var attachmentsObj = {};

					// 	// additionalInfoObj.FileName = oDocsData[j].getAggregation("cells")[0].getText();
					// 	// additionalInfoObj.FileData = oDocsData[j].getAggregation("cells")[1].getValue();

					// 	attachmentsObj.DocName = oDocsData[j].getAggregation("cells")[0].getText();
					// 	attachmentsObj.Document = oDocsData[j].getAggregation("cells")[1].getValue();
					// 	itemsObject = Object.assign(attachmentsObj, additionalInfoObj);
					// 	attachmentsArr.push(itemsObject);
					// 	// additionalInfoArr.push(additionalInfoObj);
					// }
					// }

					// additionalInfoObj.CreateQualificationSet = attachmentsArr;
					// additionalInfoArr.push(additionalInfoObj);

					// }

				}

				var attachmentsArr = [];
				var itemsObject = {};
				if (that.byId("createUploadAttachmentsTable").getVisible() === true) {
					var oDocsData = that.byId("createUploadAttachmentsTable").getItems();

					// itemsObject.Key = "D";
					// var additionalInfoArr = [];
					for (var j = 0; j < oDocsData.length; j++) {
						var attachmentsObj = {};
						// attachmentsObj.Key = "D";
						attachmentsObj.DocName = oDocsData[j].getAggregation("cells")[0].getText();
						attachmentsObj.Document = oDocsData[j].getAggregation("cells")[1].getValue();
						itemsObject = Object.assign(attachmentsObj, additionalInfoObj);
						attachmentsArr.push(itemsObject);
						// additionalInfoArr.push(additionalInfoObj);
					}

				} else {
					attachmentsArr.push(additionalInfoObj);
				}

			} else {

				var oDocsData1 = that.byId("createUploadAttachmentsTable").getItems();

				for (var o = 0; o < oDocsData1.length; o++) {
					var attachmentsObj1 = {};

					attachmentsObj1.QualGroup = that.craftType;
					attachmentsObj1.QualDesc = that.byId("objQualInp").getText();
					attachmentsObj1.Qualification = that.qualId;
					attachmentsObj1.Pscale = that.byId("objProfScale").getText();
					attachmentsObj1.Begda = startDate;
					attachmentsObj1.Endda = endDate;
					attachmentsObj1.Pernr = that.byId("objEmpNo").getText();
					attachmentsObj1.Key = "D";

					// additionalInfoObj.FileName = oDocsData[j].getAggregation("cells")[0].getText();
					// additionalInfoObj.FileData = oDocsData[j].getAggregation("cells")[1].getValue();

					attachmentsObj1.DocName = oDocsData1[o].getAggregation("cells")[0].getText();
					attachmentsObj1.Document = oDocsData1[o].getAggregation("cells")[1].getValue();
					attachmentsArr.push(attachmentsObj1);
					// additionalInfoArr.push(additionalInfoObj);
				}

			}

			// var sDate = that.byId("objStDate").getText();
			// if (sDate !== "") {
			// 	var oSDate = sDate.split("/");
			// 	var startDate = oSDate[2] + "" + oSDate[0] + "" + oSDate[1];
			// } else {
			// 	startDate = "";
			// }
			// var eDate = that.byId("objEnDate").getText();
			// if (eDate !== "") {
			// 	var oEDate = eDate.split("/");
			// 	var endDate = oEDate[2] + "" + oEDate[0] + "" + oEDate[1];
			// } else {
			// 	endDate = "";
			// }

			var oEntry = {};
			// oEntry.QualGroup = that.craftType;
			// oEntry.QualDesc = that.byId("objQualInp").getText();
			oEntry.Qualification = that.qualId;
			// oEntry.Pscale = that.byId("objProfScale").getText();
			// oEntry.Begda = startDate;
			// oEntry.Endda = endDate;
			oEntry.Pernr = that.byId("objEmpNo").getText();

			oEntry.CreateQualificationSet = attachmentsArr;

			var oComponentData = that.getOwnerComponent().getComponentData().startupParameters;

			var oModel = that.getOwnerComponent().getModel();
			oModel.create("/QualHeaderSet", oEntry, {
				success: function (oData, oResponse) {
					
					sap.m.MessageBox.show(
						"Created Successfully", {
							icon: sap.m.MessageBox.Icon.INFORMATION,
							title: "Information",
							onClose: function (sAction) {
								if (sAction === "OK") {
									that._onObjectMatched();
								}
							}
						});
						
					/*var oCreateDialog = new sap.m.Dialog();
					oCreateDialog.setTitle(titleSuccess);
					oCreateDialog.setIcon("sap-icon://message-success");
					oCreateDialog.addStyleClass(
						"dialogHdrBgCls dialogTitleCls dialogTextShadowCls dialogBoxShadowCls dialogIconCls dialogFooterBgCls");
					var oSimpleForm = new sap.ui.layout.form.SimpleForm({
						content: [
							new sap.m.Text({
								text: "Created Successfully"
							})
						]
					});
					oCreateDialog.addContent(oSimpleForm);
					oCreateDialog.addButton(
						new sap.m.Button({
							text: ok,
							press: function () {
								oCreateDialog.close();
							}
						}).addStyleClass("sapUiSizeCompact clsBtnColorYellowRed")
					);
					oCreateDialog.open();*/
				},
				error: function (oResponse) {
					that.srvResp = "Yes";
					//-----------------------------------------------------------------------	
					// Displaying response header message.
					//-----------------------------------------------------------------------
					var oMessage = JSON.parse(oResponse.responseText).error.innererror.errordetails[0].message;
					
					sap.m.MessageBox.show(
						oMessage, {
							icon: sap.m.MessageBox.Icon.INFORMATION,
							title: titleInfo,
							onClose: function (sAction) {
								if (sAction === "OK") {

									var srvCal;
									if (this.srvResp === "Yes") {
										srvCal = "Yes";
									} else {
										srvCal = "No";
									}
									oComponentData.srvCal = [srvCal];
									sap.ui.core.UIComponent.getRouterFor(that).navTo("worklist");

								}
							}
						});
					
					/*var oCreateDialog = new sap.m.Dialog();
					oCreateDialog.setTitle(titleInfo);
					oCreateDialog.setIcon("sap-icon://message-information");
					oCreateDialog.addStyleClass(
						"dialogHdrBgCls dialogTitleCls dialogTextShadowCls dialogBoxShadowCls dialogIconCls dialogFooterBgCls");
					var oSimpleForm = new sap.ui.layout.form.SimpleForm({
						content: [
							new sap.m.Text({
								text: oMessage
							})
						]
					});
					oCreateDialog.addContent(oSimpleForm);
					oCreateDialog.addButton(
						new sap.m.Button({
							text: ok,
							press: function () {

								var srvCal;
								if (this.srvResp === "Yes") {
									srvCal = "Yes";
								} else {
									srvCal = "No";
								}
								oComponentData.srvCal = [srvCal];
								sap.ui.core.UIComponent.getRouterFor(that).navTo("worklist");

								oCreateDialog.close();
							}
						}).addStyleClass("sapUiSizeCompact clsBtnColorYellowRed")
					);
					oCreateDialog.open();*/

				}
			});

		}

	});

});