var currentDate;
var error;
var close;
var inlineTable;
var stateComboBox;
this.sFinalArray = [];
this.employeeIDN = "";
this.empName = "";
this.empStatus = "";
this.prevTab = "";
sap.ui.define([
	"./BaseController",
	"sap/ui/model/json/JSONModel",
	"com/empqualassignment/Employee_Qual_Assignment/model/formatter",
	"sap/ui/model/Filter",
	"sap/ui/model/FilterOperator",
	"sap/ui/unified/FileUploader",
	"sap/ui/export/Spreadsheet"
], function (BaseController, JSONModel, formatter, Filter, FilterOperator, FileUploader, Spreadsheet) {
	"use strict";

	return BaseController.extend("com.empqualassignment.Employee_Qual_Assignment.controller.Worklist", {

		formatter: formatter,

		/* =========================================================== */
		/* lifecycle methods                                           */
		/* =========================================================== */

		/**
		 * Called when the worklist controller is instantiated.
		 * @public
		 */
		onInit: function () {
			var that = this;
			that.getRouter().getRoute("worklist").attachPatternMatched(this._onObjectMatched, this);
			//------ Defaulting current date to the effective date field ------
			var newDate = new Date();
			var currDay = newDate.getDate();
			var currMonth = newDate.getMonth() + 1;
			var currYear = newDate.getFullYear();
			if (currDay < 10) {
				currDay = "0" + currDay;
			} else {
				currDay = currDay;
			}
			if (currMonth < 10) {
				currMonth = "0" + currMonth;
			} else {
				currMonth = currMonth;
			}
			currentDate = currMonth + "/" + currDay + "/" + currYear;
			that.byId("empDataEffDate").setValue(currentDate);
			that.byId("rosterSenDateId").setValue(currentDate);
			//INLPAT
			var oEmpSenMaintModel = new sap.ui.model.json.JSONModel({});
			var oTable = that.getView().byId("empSenMaintTable");
			oTable.setModel(oEmpSenMaintModel, "oEmpSenMaintModel");
			//Craft Type
			that.byId("senCraftTpeId").setText("TCU");
			that.craftUnion = "";
			var oLoggedinUser;
			var y = "/sap/bc/ui2/start_up";
			var xmlHttp = null;
			xmlHttp = new XMLHttpRequest();
			xmlHttp.onreadystatechange = function () {
				if (xmlHttp.readyState === 4 && xmlHttp.status === 200) {
					var oUserData = JSON.parse(xmlHttp.responseText);
					oLoggedinUser = oUserData.id;
					jQuery.sap.require("jquery.sap.storage");
					jQuery.sap.storage(jQuery.sap.storage.Type.local).put("UserName", oLoggedinUser);
					//------ Calling the oData service for Craft -------
					// ---------------Qualifications------------------
					var listFil = [];
					var loginUser = new sap.ui.model.Filter("Uname", "EQ", oLoggedinUser);
					listFil.push(loginUser);
					var oModel = that.getOwnerComponent().getModel();
					var intlDialog = new sap.m.BusyDialog({
						text: "Data loading please wait..."
					});
					intlDialog.open();
					oModel.read("/UserDetailsSet", {
						filters: listFil,
						success: function (oData) {
							intlDialog.close();
							var viewModel = new sap.ui.model.json.JSONModel({
								Department: oData.results[0].Department
							});
							that.getView().setModel(viewModel, "viewModel");

							var roleResults = oData.results;
							that.wholeData = roleResults;
							var roleArray = roleResults.slice();
							var roleFinalArray = that.uniqueRoleDropDownValFun(roleArray, "Role");
							var roleSelectedKey = roleFinalArray[0].Unions;

							var oRoleArray = {
								results: roleFinalArray
							};
							var oRoleModel = new sap.ui.model.json.JSONModel(oRoleArray);
							var oRoleDropDown = that.byId("roleId");
							oRoleDropDown.setModel(oRoleModel, "roleData");
							that.byId("roleId").setSelectedKey(roleSelectedKey);

							var oSelRole = that.byId("roleId").getSelectedItem().getProperty("text");
							if (oSelRole === "Supervisor") {
								that.getView().byId("qualQualsInput").setEnabled(false);
								that.getView().byId("qualStDate").setEnabled(false);
								that.getView().byId("addBtn").setEnabled(false);
								that.getView().byId("qualproficiency").setEnabled(false);
								that.getView().byId("qualEndDate").setEnabled(false);
							}
							var deptArray = [];
							for (var i = 0; i < that.wholeData.length; i++) {
								var deptObj = {};
								if (oSelRole === that.wholeData[i].Role) {
									deptObj.Department = that.wholeData[i].Department;
									deptObj.Unions = that.wholeData[i].Unions;
									deptArray.push(deptObj);
								}
							}

							// var deptResults = oData.results;
							// var deptArray = deptResults.slice();
							// var deptFinalArray = that.uniqueDeptDropDownValFun(deptArray, "Department");
							var deptSelectedKey = deptArray[0].Unions;
							var oDeptArray = {
								results: deptArray
							};
							var oDeptModel = new sap.ui.model.json.JSONModel(oDeptArray);
							var oDeptDropDown = that.byId("deptId");
							oDeptDropDown.setModel(oDeptModel, "deptData");
							that.byId("deptId").setSelectedKey(deptSelectedKey);
							that.deptSelectedKey = deptArray[0].Unions;
							var roleGetSelectedKey = that.byId("roleId").getSelectedKey();
							var deptGetSelectedKey = that.byId("deptId").getSelectedKey();
							that.deptGetSelectedKey = deptGetSelectedKey;
							// if (roleGetSelectedKey === "LR") {
							// 	that.byId("deptId").setEnabled(true);
							// } else {
							// 	that.byId("deptId").setEnabled(false);
							// }
							if (that.deptSelectedKey !== "CH") {
								var oModel1 = that.getOwnerComponent().getModel("oDataSrv");

								var union = oData.results[0].Unions;
								if (union === "CG") {
									union = "E";
								}
								// oModel1.read("/QualiSearchHelpSet?$filter=Craft eq '" + union + "'", {
								// 	async: false,
								// 	success: function (oData1) {
								// 		that.QualArray = oData1;
								// 		// var oReqDetailsModel = new sap.ui.model.json.JSONModel(oData1);
								// 		// var oTable1 = that.byId("qualReqDetailsTableId1");
								// 		// oTable1.setModel(oReqDetailsModel, "qualReqDetailsModel");
								// 	}
								// });
							}
							that.byId("empSenDeptInp").setVisible(false);
							var selectedTab = that.byId("IconTabbarId").getSelectedKey();
							that.prevTab = selectedTab;
							if (selectedTab === "empQualAssign") {
								that.byId("editBtn").setVisible(false);
								that.byId("saveBtn").setVisible(false);
								// that.onCancel();
							} else
							if (selectedTab === "empSenMaint") {
								that.byId("editBtn").setVisible(true);
								that.byId("saveBtn").setVisible(true);
								// that.onCancel();
							}

							if (oSelRole === "LR Admin") {
								/*that.byId("deptId").setEnabled(true);
								that.byId("deptId").setValue();
								that.byId("editBtn").setVisible(false);
								that.byId("saveBtn").setVisible(false);
								that.byId("cancelBtn").setVisible(false);*/

								if (selectedTab === "empQualAssign") {
									that.byId("deptId").setEnabled(true);
									that.byId("deptId").setValue();
									that.byId("editBtn").setVisible(false);
									that.byId("saveBtn").setVisible(false);
									that.byId("cancelBtn").setVisible(false);
								} else
								if (selectedTab === "empSenMaint") {
									that.byId("deptId").setEnabled(true);
									that.byId("deptId").setValue();
									that.byId("editBtn").setVisible(false);
									that.byId("saveBtn").setVisible(false);
									that.byId("cancelBtn").setVisible(false);
								} else
								if (selectedTab === "empHomeZone") {
									that.byId("deptId").setEnabled(true);
									that.byId("deptId").setValue();
									that.byId("editBtn").setVisible(false);
									that.byId("saveBtn").setVisible(false);
									that.byId("cancelBtn").setVisible(false);
								} else
								if (selectedTab === "additionalSenInfo") {
									that.byId("deptId").setEnabled(true);
									that.byId("deptId").setValue();
									that.byId("editBtn").setVisible(false);
									that.byId("saveBtn").setVisible(false);
									that.byId("cancelBtn").setVisible(false);
								}

							} else {
								/*that.byId("deptId").setEnabled(false);
								that.byId("deptId").setSelectedKey(roleGetSelectedKey);
								that.byId("editBtn").setVisible(true);
								that.byId("saveBtn").setVisible(true);
								that.byId("cancelBtn").setVisible(true);*/

								if (selectedTab === "empQualAssign") {
									that.byId("deptId").setEnabled(true);
									that.byId("deptId").setSelectedKey(roleGetSelectedKey);
									that.byId("editBtn").setVisible(false);
									that.byId("saveBtn").setVisible(false);
									that.byId("cancelBtn").setVisible(true);
								} else
								if (selectedTab === "empSenMaint") {
									that.byId("deptId").setEnabled(true);
									that.byId("deptId").setSelectedKey(roleGetSelectedKey);
									that.byId("editBtn").setVisible(true);
									that.byId("saveBtn").setVisible(false).setEnabled(false);
									that.byId("cancelBtn").setVisible(true);
								} else
								if (selectedTab === "empHomeZone") {
									that.byId("deptId").setEnabled(true);
									that.byId("deptId").setSelectedKey(roleGetSelectedKey);
									that.byId("editBtn").setVisible(true);
									that.byId("saveBtn").setVisible(false);
									that.byId("cancelBtn").setVisible(true);
								} else
								if (selectedTab === "additionalSenInfo") {
									that.byId("deptId").setEnabled(true);
									that.byId("deptId").setSelectedKey(roleGetSelectedKey);
									that.byId("editBtn").setVisible(true);
									that.byId("saveBtn").setVisible(false);
									that.byId("cancelBtn").setVisible(true);
								}

							}

							if (deptGetSelectedKey === "E" || deptGetSelectedKey === "SE") {
								that.craftUnion = "Engineering";
							}
							if (deptGetSelectedKey === "M" || deptGetSelectedKey === "SM") {
								that.craftUnion = "Mechanical";
							}
							if (deptGetSelectedKey === "T" || deptGetSelectedKey === "ST") {
								that.craftUnion = "TCU";
							}
							if (deptGetSelectedKey === "D" || deptGetSelectedKey === "SD") {
								that.craftUnion = "ATDA";
							}
							if (deptGetSelectedKey === "L" || deptGetSelectedKey === "SL") {
								that.craftUnion = "ILA";
							}
							if (deptGetSelectedKey === "C" || deptGetSelectedKey === "SC") {
								that.craftUnion = "Conrail";
							}
							if (deptGetSelectedKey === "I" || deptGetSelectedKey === "SI") {
								that.craftUnion = "IHB";
							}
							if (deptGetSelectedKey === "N" || deptGetSelectedKey === "SN") {
								that.craftUnion = "NAHR";
							}
							if (deptGetSelectedKey === "P" || deptGetSelectedKey === "SP") {
								that.craftUnion = "Payroll";
							}
							if (deptGetSelectedKey === "CH") {
								that.craftUnion = "Supervisor";
							}
							if (deptGetSelectedKey === "CG") {
								that.craftUnion = "Certificate Group";
							}
							that.byId("craftType").setText(that.craftUnion);

							//------ Employee Seniority Maintenance header and table fields displaying based on craft -------

							var empSenTable = that.byId("empSenMaintTable");
							var oColumns = empSenTable.getColumns();

							var empSenHeaderTable = that.byId("empSenMaintTableCols");
							//var oHeaderColumns = empSenHeaderTable.getColumns();

							if (that.craftUnion === "Engineering") {

								if (oSelRole === "PM Admin") {
									that.byId("empQualAssignTab").setVisible(true);
									that.byId("empSenMaintTab").setVisible(true);
									that.byId("empApprQualTab").setVisible(true);
									that.byId("empHomeZoneTab").setVisible(true);
									that.byId("empAdditionalSenInfoTab").setVisible(true);
								} else if (oSelRole === "Super PM Admin") {
									that.byId("empQualAssignTab").setVisible(true);
									that.byId("empSenMaintTab").setVisible(true);
									that.byId("empApprQualTab").setVisible(true);
									that.byId("empHomeZoneTab").setVisible(true);
									that.byId("empAdditionalSenInfoTab").setVisible(true);
								} else if (oSelRole === "Chief Supervisor") {
									that.byId("empQualAssignTab").setVisible(true);
									that.byId("empSenMaintTab").setVisible(true);
									that.byId("empApprQualTab").setVisible(true);
									that.byId("empHomeZoneTab").setVisible(false);
									that.byId("empAdditionalSenInfoTab").setVisible(true);
								}

								/*else if (oSelRole === "Super PM Admin") {
									that.byId("empQualAssignTab").setVisible(true);
									that.byId("empSenMaintTab").setVisible(true);
									that.byId("empApprQualTab").setVisible(true);
									that.byId("empHomeZoneTab").setVisible(false);
									that.byId("empAdditionalSenInfoTab").setVisible(false);
								}*/

								that.byId("rosterNoInp").setVisible(true);
								that.byId("rosterSenDateId").setVisible(true);
								that.byId("rosterOverrideSenDateId").setVisible(true);
								that.byId("rosterFrozenSenDateId").setVisible(true);
								that.byId("empRemarksId").setVisible(true);
								that.byId("empSenCraftInp").setVisible(false);
								that.byId("empSenDivisionInp").setVisible(true);
								that.byId("empSenRrCodeInp").setVisible(true);
								that.byId("empSenDistrictInp").setVisible(true);
								that.byId("empSenDpgZoneInp").setVisible(true);
							} else if (that.craftUnion === "Mechanical") {
								if (oSelRole === "PM Admin") {
									that.byId("empQualAssignTab").setVisible(true);
									that.byId("empSenMaintTab").setVisible(true);
									that.byId("empApprQualTab").setVisible(true);
									that.byId("empHomeZoneTab").setVisible(false);
									that.byId("empAdditionalSenInfoTab").setVisible(false);
								} else if (oSelRole === "Super PM Admin") {
									that.byId("empQualAssignTab").setVisible(true);
									that.byId("empSenMaintTab").setVisible(true);
									that.byId("empApprQualTab").setVisible(true);
									that.byId("empHomeZoneTab").setVisible(false);
									that.byId("empAdditionalSenInfoTab").setVisible(false);
								} else if (oSelRole === "Chief Supervisor") {
									that.byId("empQualAssignTab").setVisible(true);
									that.byId("empSenMaintTab").setVisible(false);
									that.byId("empApprQualTab").setVisible(true);
									that.byId("empHomeZoneTab").setVisible(false);
									that.byId("empAdditionalSenInfoTab").setVisible(false);
								}
								that.byId("rosterNoInp").setVisible(true);
								that.byId("rosterSenDateId").setVisible(true);
								that.byId("rosterOverrideSenDateId").setVisible(true);
								that.byId("rosterFrozenSenDateId").setVisible(true);
								that.byId("empRemarksId").setVisible(true);
								that.byId("empSenCraftInp").setVisible(true);
								that.byId("empSenDivisionInp").setVisible(false);
								that.byId("empSenRrCodeInp").setVisible(false);
								that.byId("empSenDistrictInp").setVisible(false);
								that.byId("empSenDpgZoneInp").setVisible(false);
							} else if (that.craftUnion === "TCU") {

								if (oSelRole === "PM Admin") {
									that.byId("empQualAssignTab").setVisible(true);
									that.byId("empSenMaintTab").setVisible(true);
									that.byId("empApprQualTab").setVisible(true);
									that.byId("empHomeZoneTab").setVisible(false);
									that.byId("empAdditionalSenInfoTab").setVisible(false);
								} else if (oSelRole === "Super PM Admin") {
									that.byId("empQualAssignTab").setVisible(true);
									that.byId("empSenMaintTab").setVisible(true);
									that.byId("empApprQualTab").setVisible(true);
									that.byId("empHomeZoneTab").setVisible(false);
									that.byId("empAdditionalSenInfoTab").setVisible(false);
								} else if (oSelRole === "Chief Supervisor") {
									that.byId("empQualAssignTab").setVisible(true);
									that.byId("empSenMaintTab").setVisible(true);
									that.byId("empApprQualTab").setVisible(true);
									that.byId("empHomeZoneTab").setVisible(false);
									that.byId("empAdditionalSenInfoTab").setVisible(false);
								}
								that.byId("empSenDeptInp").setVisible(true);
								that.byId("rosterNoInp").setVisible(true);
								that.byId("rosterSenDateId").setVisible(true);
								that.byId("rosterOverrideSenDateId").setVisible(true);
								that.byId("rosterFrozenSenDateId").setVisible(true);
								that.byId("empRemarksId").setVisible(true);
								that.byId("empSenCraftInp").setVisible(false);
								that.byId("empSenDivisionInp").setVisible(false);
								that.byId("empSenRrCodeInp").setVisible(false);
								that.byId("empSenDistrictInp").setVisible(false);
								that.byId("empSenDpgZoneInp").setVisible(false);
							} else if (that.craftUnion === "ATDA") {

								if (oSelRole === "PM Admin") {
									that.byId("empQualAssignTab").setVisible(true);
									that.byId("empSenMaintTab").setVisible(true);
									that.byId("empApprQualTab").setVisible(true);
									that.byId("empHomeZoneTab").setVisible(false);
									that.byId("empAdditionalSenInfoTab").setVisible(false);
								} else if (oSelRole === "Super PM Admin") {
									that.byId("empQualAssignTab").setVisible(true);
									that.byId("empSenMaintTab").setVisible(true);
									that.byId("empApprQualTab").setVisible(true);
									that.byId("empHomeZoneTab").setVisible(false);
									that.byId("empAdditionalSenInfoTab").setVisible(false);
								} else if (oSelRole === "Chief Supervisor") {
									that.byId("empQualAssignTab").setVisible(true);
									that.byId("empSenMaintTab").setVisible(true);
									that.byId("empApprQualTab").setVisible(true);
									that.byId("empHomeZoneTab").setVisible(false);
									that.byId("empAdditionalSenInfoTab").setVisible(false);
								}
								that.byId("rosterNoInp").setVisible(true);
								that.byId("rosterSenDateId").setVisible(true);
								that.byId("rosterOverrideSenDateId").setVisible(true);
								that.byId("rosterFrozenSenDateId").setVisible(true);
								that.byId("empRemarksId").setVisible(true);
								that.byId("empSenCraftInp").setVisible(false);
								that.byId("empSenDivisionInp").setVisible(false);
								that.byId("empSenRrCodeInp").setVisible(false);
								that.byId("empSenDistrictInp").setVisible(false);
								that.byId("empSenDpgZoneInp").setVisible(false);
							} else if (that.craftUnion === "ILA") {

								if (oSelRole === "PM Admin") {
									that.byId("empQualAssignTab").setVisible(true);
									that.byId("empSenMaintTab").setVisible(true);
									that.byId("empApprQualTab").setVisible(true);
									that.byId("empHomeZoneTab").setVisible(false);
									that.byId("empAdditionalSenInfoTab").setVisible(false);
								} else if (oSelRole === "Super PM Admin") {
									that.byId("empQualAssignTab").setVisible(true);
									that.byId("empSenMaintTab").setVisible(true);
									that.byId("empApprQualTab").setVisible(true);
									that.byId("empHomeZoneTab").setVisible(false);
									that.byId("empAdditionalSenInfoTab").setVisible(false);
								} else if (oSelRole === "Chief Supervisor") {
									that.byId("empQualAssignTab").setVisible(true);
									that.byId("empSenMaintTab").setVisible(true);
									that.byId("empApprQualTab").setVisible(true);
									that.byId("empHomeZoneTab").setVisible(false);
									that.byId("empAdditionalSenInfoTab").setVisible(false);
								}
								that.byId("rosterNoInp").setVisible(true);
								that.byId("rosterSenDateId").setVisible(true);
								that.byId("rosterOverrideSenDateId").setVisible(true);
								that.byId("rosterFrozenSenDateId").setVisible(true);
								that.byId("empRemarksId").setVisible(true);
								that.byId("empSenCraftInp").setVisible(false);
								that.byId("empSenDivisionInp").setVisible(false);
								that.byId("empSenRrCodeInp").setVisible(false);
								that.byId("empSenDistrictInp").setVisible(false);
								that.byId("empSenDpgZoneInp").setVisible(false);
							}

							// ------------- Eng, Mech and Tcu details service call -----------------------------
							// var filters = [];
							// // var vCraft = new sap.ui.model.Filter("Craft", "EQ", that.Union);
							// var vCraft = new sap.ui.model.Filter("Craft", "EQ", that.deptGetSelectedKey);
							// filters.push(vCraft);
							// var qualModel = that.getOwnerComponent().getModel();
							// qualModel.read("/QualiSearchHelpSet", {
							// 	filters: filters,
							// 	success: function (oData, Response) {
							// 		if (oData.results.length > 0) {

							// 			var qualEntryArray = [];
							// 			var engQualEntryArray = [];
							// 			var mechQualEntryArray = [];
							// 			var tcuQualEntryArray = [];
							// 			that.QualArray = oData;
							// 			for (var j = 0; j < oData.results.length; j++) {
							// 				var qualEntryObj = {};
							// 				qualEntryObj.QualDesc = oData.results[j].QualDesc;
							// 				qualEntryObj.Qualification = oData.results[j].Qualification;
							// 				qualEntryArray.push(qualEntryObj);
							// 				if (oData.results[j].Craft === "ENG") {
							// 					var engQualEntryObj = {};
							// 					engQualEntryObj.QualDesc = oData.results[j].QualDesc;
							// 					engQualEntryObj.Qualification = oData.results[j].Qualification;
							// 					engQualEntryObj.QualId = oData.results[j].QualId;
							// 					engQualEntryArray.push(engQualEntryObj);
							// 					var engQualSModel = new sap.ui.model.json.JSONModel({
							// 						"results": engQualEntryArray
							// 					});
							// 					that.getView().setModel(engQualSModel, "engQualSModel");
							// 				} else if (oData.results[j].Craft === "MECH") {
							// 					var mechQualEntryObj = {};
							// 					mechQualEntryObj.QualDesc = oData.results[j].QualDesc;
							// 					mechQualEntryObj.Qualification = oData.results[j].Qualification;
							// 					mechQualEntryObj.QualId = oData.results[j].QualId;
							// 					mechQualEntryArray.push(mechQualEntryObj);
							// 					var mechQualSModel = new sap.ui.model.json.JSONModel({
							// 						"results": mechQualEntryArray
							// 					});
							// 					that.getView().setModel(mechQualSModel, "mechQualSModel");
							// 				} else if (oData.results[j].Craft === "TCU") {
							// 					var tcuQualEntryObj = {};
							// 					tcuQualEntryObj.QualDesc = oData.results[j].QualDesc;
							// 					tcuQualEntryObj.Qualification = oData.results[j].Qualification;
							// 					tcuQualEntryObj.QualId = oData.results[j].QualId;
							// 					tcuQualEntryArray.push(tcuQualEntryObj);
							// 					var tcuQualSModel = new sap.ui.model.json.JSONModel({
							// 						"results": tcuQualEntryArray
							// 					});
							// 					that.getView().setModel(tcuQualSModel, "tcuQualSModel");
							// 				}
							// 			}
							// 			var qualSModel = new sap.ui.model.json.JSONModel({
							// 				results: qualEntryArray
							// 			});
							// 			that.getView().setModel(qualSModel, "qualSModel");
							// 		}

							// 	},
							// 	error: function (oResponse) {

							// 		//-----------------------------------------------------------------------	
							// 		// Displaying response body message.
							// 		//-----------------------------------------------------------------------

							// 		var oMessage = $(oResponse.response.body).find('message').first().text();
							// 		var errmsg;
							// 		if (oMessage === "") {

							// 			errmsg = oResponse.response.body;
							// 		} else {
							// 			errmsg = oMessage;

							// 		}

							// 		sap.m.MessageBox.show(errmsg, {
							// 			icon: sap.m.MessageBox.Icon.ERROR,
							// 			title: error,
							// 			actions: [sap.m.MessageBox.Action.OK],
							// 			onClose: function (oAction) {
							// 				if (oAction === sap.m.MessageBox.Action.OK) {}
							// 			}
							// 		});

							// 	}
							// });
							// if (that.deptSelectedKey !== "CH") {
							// 	var oModel1 = that.getOwnerComponent().getModel("oDataSrv");
							// 	oModel1.read("/QualReqDetailsSet", {
							// 		async: true,
							// 		success: function (oData1) {
							// 			// that.getView().setBusy(false);
							// 			var oReqDetailsModel = new sap.ui.model.json.JSONModel(oData1);
							// 			var oTable1 = that.byId("qualReqDetailsTableId1");
							// 			oTable1.setModel(oReqDetailsModel, "qualReqDetailsModel");
							// 		}
							// 	});
							// }
							if (deptSelectedKey === "CG") {
								that.byId("IconTabbarId").setSelectedKey("empQualAssignTab");
								// that.byId("empQualAssignTab").setVisible(false);
								that.byId("empAdditionalSenInfoTab").setVisible(false);
								that.byId("empHomeZoneTab").setVisible(false);
								that.byId("empSenMaintTab").setVisible(false);
								that.byId("empApprQualTab").setVisible(false);
								that.byId("editBtn").setVisible(false);
								that.byId("cancelBtn").setVisible(false);
							}
							if (deptSelectedKey === "CH") {
								that.byId("IconTabbarId").setSelectedKey("empQualAssignTab");
								// that.byId("empQualAssignTab").setVisible(false);
								that.byId("empAdditionalSenInfoTab").setVisible(false);
								that.byId("empHomeZoneTab").setVisible(false);
								that.byId("empSenMaintTab").setVisible(false);
								that.byId("editBtn").setVisible(false);
								that.byId("cancelBtn").setVisible(false);
							}

						},
						error: function (oResponse) {
							intlDialog.close();
							that.initialErrorMsgFun(oResponse);
						}
					});

				}
			};
			xmlHttp.open("GET", y, false);
			xmlHttp.send(null);

			// -------------------- Employee Qualification Assignment empty model -------------------------

			var oEmpQualAssignModel = new sap.ui.model.json.JSONModel({
				results: []
			});
			that.byId("qualTable").setModel(oEmpQualAssignModel, "oModelData");

			var oEmpSenMaintModel1 = new sap.ui.model.json.JSONModel({
				results: []
			});
			that.byId("empSenMaintTable").setModel(oEmpSenMaintModel1, "empSenMaintModel");

			var oEmpHomeZoneModel = new sap.ui.model.json.JSONModel({
				results: []
			});
			that.byId("empHomeZoneTable").setModel(oEmpHomeZoneModel, "empHomeZoneModel");

			var oEmpAdditionalSenInfoModel = new sap.ui.model.json.JSONModel({
				results: []
			});
			that.byId("empAdditionalSenInfoTable").setModel(oEmpAdditionalSenInfoModel, "empAdditionalSenInfoModel");

			//
			that.sFinalArray = [];
			that.changeFlag = false;
			that.EditFlag = false;
			that.confirm = false;

			var oEmpItemModel = new sap.ui.model.json.JSONModel({});
			that.getView().setModel(oEmpItemModel, "oEmpItemModel");
			that.stateDataFun();
			var oController = that.getView().getController();
			stateComboBox = new sap.m.ComboBox({
				// liveChange: function (oEvt) {
				// 	oEvt.getSource().setValue("");
				// },
				change: [oController.onStateDropDown, oController]
			});
			var oStateTemp = new sap.ui.core.ListItem({
				key: "{stateData>State}",
				text: "{stateData>State}"
			});

			stateComboBox.bindItems({
				path: "stateData>/results",
				template: oStateTemp
			});

		},
		//-----------------------------------------------------------------------	
		// Method for gettting uniq drop down values.
		//-----------------------------------------------------------------------
		curAtcEmp: function (sValue) {
			if (sValue === "18") {
				return "Success";
			} else {
				return "Error";
			}
		},
		uniqueRoleDropDownValFun: function (roleArray, Role) {
			var oArray = [];
			var checkArray = [];
			for (var i = 0; i < roleArray.length; i++) {
				if (oArray.indexOf(roleArray[i]["" + Role + ""]) === -1 && roleArray[i]["" + Role + ""].trim() !== "") {
					oArray.push(roleArray[i]["" + Role + ""]);
					var uObj = Object.assign({}, roleArray[i]);
					checkArray.push(uObj);
				}
			}
			return checkArray;
		},

		uniqueDeptDropDownValFun: function (deptArray, Department) {
			var oArray = [];
			var checkArray = [];
			for (var i = 0; i < deptArray.length; i++) {
				if (oArray.indexOf(deptArray[i]["" + Department + ""]) === -1 && deptArray[i]["" + Department + ""].trim() !== "") {
					oArray.push(deptArray[i]["" + Department + ""]);
					var uObj = Object.assign({}, deptArray[i]);
					checkArray.push(uObj);
				}
			}
			return checkArray;
		},

		onRoleChange: function (oEvent) {
			var that = this;
			var oRole = oEvent.getParameter("selectedItem").getProperty("key");
			var oSelRole = oEvent.getParameter("selectedItem").getProperty("text");
			that.oSelRole = oEvent.getParameter("selectedItem").getProperty("text");
			if (oSelRole === "Supervisor") {
				that.getView().byId("qualQualsInput").setEnabled(false);
				that.getView().byId("qualStDate").setEnabled(false);
				that.getView().byId("addBtn").setEnabled(false);
				that.getView().byId("qualproficiency").setEnabled(false);
				that.getView().byId("qualEndDate").setEnabled(false);
				that.getView().byId("apprQualMaint").setVisible(false);
			}
			var deptArr = [];
			for (var i = 0; i < that.wholeData.length; i++) {
				var departmentObj = {};
				if (oSelRole === that.wholeData[i].Role) {
					departmentObj.Department = that.wholeData[i].Department;
					departmentObj.Unions = that.wholeData[i].Unions;
					deptArr.push(departmentObj);
				}
			}

			//var deptFinalArr = that.uniqueDeptDropDownValFun(deptArr, "Department");	
			var deptSelectedKey = deptArr[0].Unions;
			var oDeptArray = {
				results: deptArr
			};
			var oDeptModel = new sap.ui.model.json.JSONModel(oDeptArray);
			var oDeptDropDown = that.byId("deptId");
			oDeptDropDown.setModel(oDeptModel, "deptData");
			that.byId("deptId").setSelectedKey(deptSelectedKey);

			var oSelDept = that.byId("deptId").getSelectedItem().getProperty("text");
			that.onCancel();
			that.craftUnion = oSelDept;
			if (oSelDept === "E" || oSelDept === "SE") {
				that.craftUnion = "Engineering";
			}
			if (oSelDept === "M" || oSelDept === "SM") {
				that.craftUnion = "Mechanical";
			}
			if (oSelDept === "T" || oSelDept === "ST") {
				that.craftUnion = "TCU";
			}
			if (oSelDept === "D" || oSelDept === "SD") {
				that.craftUnion = "ATDA";
			}
			if (oSelDept === "L" || oSelDept === "SL") {
				that.craftUnion = "ILA";
			}
			if (oSelDept === "C" || oSelDept === "SC") {
				that.craftUnion = "Conrail";
			}
			if (oSelDept === "I" || oSelDept === "I") {
				that.craftUnion = "IHB";
			}
			if (oSelDept === "N" || oSelDept === "SN") {
				that.craftUnion = "NAHR";
			}
			if (oSelDept === "LR") {
				that.craftUnion = "LR";
			}
			if (oSelDept === "CH") {
				that.craftUnion = "Supervisor";
			}
			that.byId("craftType").setText(that.craftUnion);
			var empSenTable = that.byId("empSenMaintTable");
			var oColumns = empSenTable.getColumns();

			var empSenHeaderTable = that.byId("empSenMaintTableCols");
			// var oHeaderColumns = empSenHeaderTable.getColumns();
			// Insert Begin - D5OW5 - Dt 08/22/2021 
			that.getModel("viewModel").getData().Department = that.craftUnion;
			that.getModel("viewModel").refresh(true);
			// empSenHeaderTable.refreshItems();    //--D5OW5 -Dt 08/24/2021
			// empSenTable.refreshItems();         //--D5OW5 -Dt 08/24/2021
			// Insert End - D5OW5 - Dt 08/22/2021            
			if (that.craftUnion === "Engineering") {
				if (oSelRole === "PM Admin") {
					that.byId("empQualAssignTab").setVisible(true);
					that.byId("empSenMaintTab").setVisible(true);
					that.byId("empApprQualTab").setVisible(true);
					that.byId("empHomeZoneTab").setVisible(false);
					that.byId("empAdditionalSenInfoTab").setVisible(false);
				} else if (oSelRole === "Super PM Admin") {
					that.byId("empQualAssignTab").setVisible(true);
					that.byId("empSenMaintTab").setVisible(true);
					that.byId("empApprQualTab").setVisible(true);
					that.byId("empHomeZoneTab").setVisible(true);
					that.byId("empAdditionalSenInfoTab").setVisible(true);
				} else if (oSelRole === "Chief Supervisor") {
					that.byId("empQualAssignTab").setVisible(true);
					that.byId("empSenMaintTab").setVisible(true);
					that.byId("empApprQualTab").setVisible(true);
					that.byId("empHomeZoneTab").setVisible(false);
					that.byId("empAdditionalSenInfoTab").setVisible(false);
				}

				that.byId("rosterNoInp").setVisible(true);
				that.byId("rosterSenDateId").setVisible(true);
				that.byId("rosterOverrideSenDateId").setVisible(true);
				that.byId("rosterFrozenSenDateId").setVisible(true);
				that.byId("empRemarksId").setVisible(true);
				that.byId("empSenCraftInp").setVisible(false);
				that.byId("empSenDivisionInp").setVisible(true);
				that.byId("empSenRrCodeInp").setVisible(true);
				that.byId("empSenDistrictInp").setVisible(true);
				that.byId("empSenDpgZoneInp").setVisible(true);
			} else if (that.craftUnion === "Mechanical") {
				if (oSelRole === "PM Admin") {
					that.byId("empQualAssignTab").setVisible(true);
					that.byId("empSenMaintTab").setVisible(true);
					that.byId("empApprQualTab").setVisible(true);
					that.byId("empApprQualTab").setVisible(false);
					that.byId("empAdditionalSenInfoTab").setVisible(false);
				} else if (oSelRole === "Super PM Admin") {
					that.byId("empQualAssignTab").setVisible(true);
					that.byId("empSenMaintTab").setVisible(true);
					that.byId("empApprQualTab").setVisible(true);
					that.byId("empHomeZoneTab").setVisible(false);
					that.byId("empAdditionalSenInfoTab").setVisible(false);
				} else if (oSelRole === "Chief Supervisor") {
					that.byId("empQualAssignTab").setVisible(true);
					that.byId("empSenMaintTab").setVisible(true);
					that.byId("empApprQualTab").setVisible(true);
					that.byId("empHomeZoneTab").setVisible(false);
					that.byId("empAdditionalSenInfoTab").setVisible(false);
				}

				that.byId("rosterNoInp").setVisible(true);
				that.byId("rosterSenDateId").setVisible(true);
				that.byId("rosterOverrideSenDateId").setVisible(true);
				that.byId("rosterFrozenSenDateId").setVisible(true);
				that.byId("empRemarksId").setVisible(true);
				that.byId("empSenCraftInp").setVisible(true);
				that.byId("empSenDivisionInp").setVisible(false);
				that.byId("empSenRrCodeInp").setVisible(false);
				that.byId("empSenDistrictInp").setVisible(false);
				that.byId("empSenDpgZoneInp").setVisible(false);
			} else if (that.craftUnion === "TCU") {
				if (oSelRole === "PM Admin") {
					that.byId("empQualAssignTab").setVisible(true);
					that.byId("empSenMaintTab").setVisible(true);
					that.byId("empApprQualTab").setVisible(true);
					that.byId("empHomeZoneTab").setVisible(false);
					that.byId("empAdditionalSenInfoTab").setVisible(false);
				} else if (oSelRole === "Super PM Admin") {
					that.byId("empQualAssignTab").setVisible(true);
					that.byId("empSenMaintTab").setVisible(true);
					that.byId("empApprQualTab").setVisible(true);
					that.byId("empHomeZoneTab").setVisible(false);
					that.byId("empAdditionalSenInfoTab").setVisible(false);
				} else if (oSelRole === "Chief Supervisor") {
					that.byId("empQualAssignTab").setVisible(true);
					that.byId("empSenMaintTab").setVisible(true);
					that.byId("empApprQualTab").setVisible(true);
					that.byId("empHomeZoneTab").setVisible(false);
					that.byId("empAdditionalSenInfoTab").setVisible(false);
				}
				that.byId("rosterNoInp").setVisible(true);
				that.byId("rosterSenDateId").setVisible(true);
				that.byId("rosterOverrideSenDateId").setVisible(true);
				that.byId("rosterFrozenSenDateId").setVisible(true);
				that.byId("empRemarksId").setVisible(true);
				that.byId("empSenCraftInp").setVisible(false);
				that.byId("empSenDivisionInp").setVisible(false);
				that.byId("empSenRrCodeInp").setVisible(false);
				that.byId("empSenDistrictInp").setVisible(false);
				that.byId("empSenDpgZoneInp").setVisible(false);
			} else if (that.craftUnion === "ATDA") {
				if (oSelRole === "PM Admin") {
					that.byId("empQualAssignTab").setVisible(true);
					that.byId("empSenMaintTab").setVisible(true);
					that.byId("empApprQualTab").setVisible(true);
					that.byId("empHomeZoneTab").setVisible(false);
					that.byId("empAdditionalSenInfoTab").setVisible(false);
				} else if (oSelRole === "Super PM Admin") {
					that.byId("empQualAssignTab").setVisible(true);
					that.byId("empSenMaintTab").setVisible(true);
					that.byId("empApprQualTab").setVisible(true);
					that.byId("empHomeZoneTab").setVisible(false);
					that.byId("empAdditionalSenInfoTab").setVisible(false);
				} else if (oSelRole === "Chief Supervisor") {
					that.byId("empQualAssignTab").setVisible(true);
					that.byId("empSenMaintTab").setVisible(true);
					that.byId("empApprQualTab").setVisible(true);
					that.byId("empHomeZoneTab").setVisible(false);
					that.byId("empAdditionalSenInfoTab").setVisible(false);
				}
				that.byId("rosterNoInp").setVisible(true);
				that.byId("rosterSenDateId").setVisible(true);
				that.byId("rosterOverrideSenDateId").setVisible(true);
				that.byId("rosterFrozenSenDateId").setVisible(true);
				that.byId("empRemarksId").setVisible(true);
				that.byId("empSenCraftInp").setVisible(false);
				that.byId("empSenDivisionInp").setVisible(false);
				that.byId("empSenRrCodeInp").setVisible(false);
				that.byId("empSenDistrictInp").setVisible(false);
				that.byId("empSenDpgZoneInp").setVisible(false);
			} else if (that.craftUnion === "ILA") {
				if (oSelRole === "PM Admin") {
					that.byId("empQualAssignTab").setVisible(true);
					that.byId("empSenMaintTab").setVisible(true);
					that.byId("empApprQualTab").setVisible(true);
					that.byId("empHomeZoneTab").setVisible(false);
					that.byId("empAdditionalSenInfoTab").setVisible(false);
				} else if (oSelRole === "Super PM Admin") {
					that.byId("empQualAssignTab").setVisible(true);
					that.byId("empSenMaintTab").setVisible(true);
					that.byId("empApprQualTab").setVisible(true);
					that.byId("empHomeZoneTab").setVisible(false);
					that.byId("empAdditionalSenInfoTab").setVisible(false);
				} else if (oSelRole === "Chief Supervisor") {
					that.byId("empQualAssignTab").setVisible(true);
					that.byId("empSenMaintTab").setVisible(true);
					that.byId("empApprQualTab").setVisible(true);
					that.byId("empHomeZoneTab").setVisible(false);
					that.byId("empAdditionalSenInfoTab").setVisible(false);
				}
				that.byId("rosterNoInp").setVisible(true);
				that.byId("rosterSenDateId").setVisible(true);
				that.byId("rosterOverrideSenDateId").setVisible(true);
				that.byId("rosterFrozenSenDateId").setVisible(true);
				that.byId("empRemarksId").setVisible(true);
				that.byId("empSenCraftInp").setVisible(false);
				that.byId("empSenDivisionInp").setVisible(false);
				that.byId("empSenRrCodeInp").setVisible(false);
				that.byId("empSenDistrictInp").setVisible(false);
				that.byId("empSenDpgZoneInp").setVisible(false);
			} else if (that.craftUnion === "LR") {
				if (oSelRole === "PM Admin") {
					that.byId("empQualAssignTab").setVisible(true);
					that.byId("empSenMaintTab").setVisible(true);
					that.byId("empApprQualTab").setVisible(true);
					that.byId("empHomeZoneTab").setVisible(false);
					that.byId("empAdditionalSenInfoTab").setVisible(false);
				} else if (oSelRole === "Super PM Admin") {
					that.byId("empQualAssignTab").setVisible(true);
					that.byId("empSenMaintTab").setVisible(true);
					that.byId("empApprQualTab").setVisible(true);
					that.byId("empHomeZoneTab").setVisible(true);
					that.byId("empAdditionalSenInfoTab").setVisible(true);
				} else if (oSelRole === "Chief Supervisor") {
					that.byId("empQualAssignTab").setVisible(true);
					that.byId("empSenMaintTab").setVisible(true);
					that.byId("empApprQualTab").setVisible(true);
					that.byId("empHomeZoneTab").setVisible(false);
					that.byId("empAdditionalSenInfoTab").setVisible(false);
				}
				that.byId("rosterNoInp").setVisible(true);
				that.byId("rosterSenDateId").setVisible(true);
				that.byId("rosterOverrideSenDateId").setVisible(true);
				that.byId("rosterFrozenSenDateId").setVisible(true);
				that.byId("empRemarksId").setVisible(true);
				that.byId("empSenCraftInp").setVisible(false);
				that.byId("empSenDivisionInp").setVisible(false);
				that.byId("empSenRrCodeInp").setVisible(false);
				that.byId("empSenDistrictInp").setVisible(false);
				that.byId("empSenDpgZoneInp").setVisible(false);
			}
			var selectedTab = that.byId("IconTabbarId").getSelectedKey();
			if (oSelRole === "LR Admin") {
				if (selectedTab === "empQualAssign") {
					that.byId("deptId").setEnabled(true);
					that.byId("deptId").setValue();
					that.byId("editBtn").setVisible(false);
					that.byId("saveBtn").setVisible(false);
					that.byId("cancelBtn").setVisible(false);
				} else
				if (selectedTab === "empSenMaint") {
					that.byId("deptId").setEnabled(true);
					that.byId("deptId").setValue();
					that.byId("editBtn").setVisible(false);
					that.byId("saveBtn").setVisible(false);
					that.byId("cancelBtn").setVisible(false);
				} else
				if (selectedTab === "empHomeZone") {
					that.byId("deptId").setEnabled(true);
					that.byId("deptId").setValue();
					that.byId("editBtn").setVisible(false);
					that.byId("saveBtn").setVisible(false);
					that.byId("cancelBtn").setVisible(false);
				} else
				if (selectedTab === "additionalSenInfo") {
					that.byId("deptId").setEnabled(true);
					that.byId("deptId").setValue();
					that.byId("editBtn").setVisible(false);
					that.byId("saveBtn").setVisible(false);
					that.byId("cancelBtn").setVisible(false);
				}

			} else {
				if (selectedTab === "empQualAssign") {
					that.byId("deptId").setEnabled(true);
					that.byId("deptId").setSelectedKey(oRole);
					that.byId("editBtn").setVisible(false);
					that.byId("saveBtn").setVisible(false);
					that.byId("cancelBtn").setVisible(true);
				} else
				if (selectedTab === "empSenMaint") {
					that.byId("deptId").setEnabled(true);
					that.byId("deptId").setSelectedKey(oRole);
					that.byId("editBtn").setVisible(true);
					that.byId("saveBtn").setVisible(false).setEnabled(false);
					that.byId("cancelBtn").setVisible(true);
				} else
				if (selectedTab === "empHomeZone") {
					that.byId("deptId").setEnabled(true);
					that.byId("deptId").setSelectedKey(oRole);
					that.byId("editBtn").setVisible(true);
					that.byId("saveBtn").setVisible(false);
					that.byId("cancelBtn").setVisible(true);
				} else
				if (selectedTab === "additionalSenInfo") {
					that.byId("deptId").setEnabled(true);
					that.byId("deptId").setSelectedKey(oRole);
					that.byId("editBtn").setVisible(true);
					that.byId("saveBtn").setVisible(false);
					that.byId("cancelBtn").setVisible(true);
				}
			}
		},
		onDeptChange: function (oEvent) {
			var that = this;
			var dialog1 = new sap.m.BusyDialog({});
			dialog1.open();
			var oDept = oEvent.getParameter("selectedItem").getProperty("key");
			var oSelRole = that.byId("roleId").getSelectedItem().getProperty("text");
			that.onCancel();
			if (oDept === "E" || oDept === "SE") {
				that.craftUnion = "Engineering";
			}
			if (oDept === "M" || oDept === "SM") {
				that.craftUnion = "Mechanical";
			}
			if (oDept === "T" || oDept === "ST") {
				that.craftUnion = "TCU";
			}
			if (oDept === "D" || oDept === "SD") {
				that.craftUnion = "ATDA";
			}
			if (oDept === "L" || oDept === "SL") {
				that.craftUnion = "ILA";
			}
			if (oDept === "C" || oDept === "SC") {
				that.craftUnion = "Conrail";
			}
			if (oDept === "I" || oDept === "SI") {
				that.craftUnion = "IHB";
			}
			if (oDept === "N" || oDept === "SN") {
				that.craftUnion = "NAHR";
			}

			var empSenTable = that.byId("empSenMaintTable");
			var oColumns = empSenTable.getColumns();

			var empSenHeaderTable = that.byId("empSenMaintTableCols");
			// Insert Begin - D5OW5 - Dt 08/22/2021 
			that.byId("deptId").setSelectedKey(that.craftUnion);
			that.byId("roleId").setSelectedKey(oDept);
			that.getModel("viewModel").getData().Department = that.craftUnion;
			that.getModel("viewModel").refresh(true);
			// empSenHeaderTable.refreshItems;   //--D5OW5 -Dt 08/24/2021
			// empSenTable.refreshItems;         //--D5OW5 -Dt 08/24/2021
			// Insert End - D5OW5 - Dt 08/22/2021      
			if (that.craftUnion === "Engineering") {

				if (oSelRole === "PM Admin") {
					that.byId("empQualAssignTab").setVisible(true);
					that.byId("empSenMaintTab").setVisible(true);
					that.byId("empApprQualTab").setVisible(true);
					that.byId("empHomeZoneTab").setVisible(false);
					that.byId("empAdditionalSenInfoTab").setVisible(false);
				} else if (oSelRole === "Super PM Admin") {
					that.byId("empQualAssignTab").setVisible(true);
					that.byId("empSenMaintTab").setVisible(true);
					that.byId("empApprQualTab").setVisible(true);
					that.byId("empHomeZoneTab").setVisible(true);
					that.byId("empAdditionalSenInfoTab").setVisible(true);
				}
				that.byId("rosterNoInp").setVisible(true);
				that.byId("rosterSenDateId").setVisible(true);
				that.byId("rosterOverrideSenDateId").setVisible(true);
				that.byId("rosterFrozenSenDateId").setVisible(true);
				that.byId("empRemarksId").setVisible(true);
				that.byId("empSenCraftInp").setVisible(false);
				that.byId("empSenDivisionInp").setVisible(true);
				that.byId("empSenRrCodeInp").setVisible(true);
				that.byId("empSenDistrictInp").setVisible(true);
				that.byId("empSenDpgZoneInp").setVisible(true);
			} else if (that.craftUnion === "Mechanical") {

				if (oSelRole === "PM Admin") {
					that.byId("empQualAssignTab").setVisible(true);
					that.byId("empSenMaintTab").setVisible(true);
					that.byId("empApprQualTab").setVisible(true);
					that.byId("empHomeZoneTab").setVisible(false);
					that.byId("empAdditionalSenInfoTab").setVisible(false);
				} else if (oSelRole === "Super PM Admin") {
					that.byId("empQualAssignTab").setVisible(true);
					that.byId("empSenMaintTab").setVisible(true);
					that.byId("empApprQualTab").setVisible(true);
					that.byId("empHomeZoneTab").setVisible(false);
					that.byId("empAdditionalSenInfoTab").setVisible(false);
				}

				that.byId("rosterNoInp").setVisible(true);
				that.byId("rosterSenDateId").setVisible(true);
				that.byId("rosterOverrideSenDateId").setVisible(true);
				that.byId("rosterFrozenSenDateId").setVisible(true);
				that.byId("empRemarksId").setVisible(true);
				that.byId("empSenCraftInp").setVisible(true);
				that.byId("empSenDivisionInp").setVisible(false);
				that.byId("empSenRrCodeInp").setVisible(false);
				that.byId("empSenDistrictInp").setVisible(false);
				that.byId("empSenDpgZoneInp").setVisible(false);
			} else if (that.craftUnion === "TCU") {
				if (oSelRole === "PM Admin") {
					that.byId("empQualAssignTab").setVisible(true);
					that.byId("empSenMaintTab").setVisible(true);
					that.byId("empApprQualTab").setVisible(true);
					that.byId("empHomeZoneTab").setVisible(false);
					that.byId("empAdditionalSenInfoTab").setVisible(false);
				} else if (oSelRole === "Super PM Admin") {
					that.byId("empQualAssignTab").setVisible(true);
					that.byId("empSenMaintTab").setVisible(true);
					that.byId("empApprQualTab").setVisible(true);
					that.byId("empHomeZoneTab").setVisible(false);
					that.byId("empAdditionalSenInfoTab").setVisible(false);
				}
				that.byId("rosterNoInp").setVisible(true);
				that.byId("rosterSenDateId").setVisible(true);
				that.byId("rosterOverrideSenDateId").setVisible(true);
				that.byId("rosterFrozenSenDateId").setVisible(true);
				that.byId("empRemarksId").setVisible(true);
				that.byId("empSenCraftInp").setVisible(false);
				that.byId("empSenDivisionInp").setVisible(false);
				that.byId("empSenRrCodeInp").setVisible(false);
				that.byId("empSenDistrictInp").setVisible(false);
				that.byId("empSenDpgZoneInp").setVisible(false);
			} else if (that.craftUnion === "ATDA") {
				if (oSelRole === "PM Admin") {
					that.byId("empQualAssignTab").setVisible(true);
					that.byId("empSenMaintTab").setVisible(true);
					that.byId("empApprQualTab").setVisible(true);
					that.byId("empHomeZoneTab").setVisible(false);
					that.byId("empAdditionalSenInfoTab").setVisible(false);
				} else if (oSelRole === "Super PM Admin") {
					that.byId("empQualAssignTab").setVisible(true);
					that.byId("empSenMaintTab").setVisible(true);
					that.byId("empApprQualTab").setVisible(true);
					that.byId("empHomeZoneTab").setVisible(false);
					that.byId("empAdditionalSenInfoTab").setVisible(false);
				}
				that.byId("rosterNoInp").setVisible(true);
				that.byId("rosterSenDateId").setVisible(true);
				that.byId("rosterOverrideSenDateId").setVisible(true);
				that.byId("rosterFrozenSenDateId").setVisible(true);
				that.byId("empRemarksId").setVisible(true);
				that.byId("empSenCraftInp").setVisible(false);
				that.byId("empSenDivisionInp").setVisible(false);
				that.byId("empSenRrCodeInp").setVisible(false);
				that.byId("empSenDistrictInp").setVisible(false);
				that.byId("empSenDpgZoneInp").setVisible(false);
			} else if (that.craftUnion === "ILA") {

				if (oSelRole === "PM Admin") {
					that.byId("empQualAssignTab").setVisible(true);
					that.byId("empSenMaintTab").setVisible(true);
					that.byId("empApprQualTab").setVisible(true);
					that.byId("empHomeZoneTab").setVisible(false);
					that.byId("empAdditionalSenInfoTab").setVisible(false);
				} else if (oSelRole === "Super PM Admin") {
					that.byId("empQualAssignTab").setVisible(true);
					that.byId("empSenMaintTab").setVisible(true);
					that.byId("empApprQualTab").setVisible(true);
					that.byId("empHomeZoneTab").setVisible(false);
					that.byId("empAdditionalSenInfoTab").setVisible(false);
				}
				that.byId("rosterNoInp").setVisible(true);
				that.byId("rosterSenDateId").setVisible(true);
				that.byId("rosterOverrideSenDateId").setVisible(true);
				that.byId("rosterFrozenSenDateId").setVisible(true);
				that.byId("empRemarksId").setVisible(true);
				that.byId("empSenCraftInp").setVisible(false);
				that.byId("empSenDivisionInp").setVisible(false);
				that.byId("empSenRrCodeInp").setVisible(false);
				that.byId("empSenDistrictInp").setVisible(false);
				that.byId("empSenDpgZoneInp").setVisible(false);
			} else if (that.craftUnion === "LR") {
				if (oSelRole === "PM Admin") {
					that.byId("empQualAssignTab").setVisible(true);
					that.byId("empSenMaintTab").setVisible(true);
					that.byId("empApprQualTab").setVisible(true);
					that.byId("empHomeZoneTab").setVisible(false);
					that.byId("empAdditionalSenInfoTab").setVisible(false);
				} else if (oSelRole === "Super PM Admin") {
					that.byId("empQualAssignTab").setVisible(true);
					that.byId("empSenMaintTab").setVisible(true);
					that.byId("empApprQualTab").setVisible(true);
					that.byId("empHomeZoneTab").setVisible(false);
					that.byId("empAdditionalSenInfoTab").setVisible(false);
				}

				that.byId("rosterNoInp").setVisible(true);
				that.byId("rosterSenDateId").setVisible(true);
				that.byId("rosterOverrideSenDateId").setVisible(true);
				that.byId("rosterFrozenSenDateId").setVisible(true);
				that.byId("empRemarksId").setVisible(true);
				that.byId("empSenCraftInp").setVisible(false);
				that.byId("empSenDivisionInp").setVisible(false);
				that.byId("empSenRrCodeInp").setVisible(false);
				that.byId("empSenDistrictInp").setVisible(false);
				that.byId("empSenDpgZoneInp").setVisible(false);
			}
			dialog1.close();
			// that.getQualsList(dialog1); //++D5OW5 - Dt 02/06/2022
		},
		//begin - insert -  //++D5OW5 - Dt 02/06/2022
		getQualsList: function (oDialog) {
			var that = this;

			that.QualArray = [];
			var oModel1 = that.getOwnerComponent().getModel("oDataSrv");
			var union = that.byId("roleId").getSelectedKey();
			oModel1.read("/QualiSearchHelpSet?$filter=Craft eq '" + union + "'", {
				async: false,
				success: function (oData1) {
					that.QualArray = oData1;
					oDialog.close();
				}
			});
		},
		// end -insert -  //++D5OW5 - Dt 02/06/2022
		initialErrorMsgFun: function (oResponse) {

			var that = this;

			//-----------------------------------------------------------------------	
			// Displaying response body message.
			//-----------------------------------------------------------------------

			var errMsg = JSON.parse(oResponse.responseText).error.message.value;

			var oSplitMsg = errMsg.split(":");
			var oMsgFlag = oSplitMsg[0];

			sap.m.MessageBox.show(errMsg, {
				icon: sap.m.MessageBox.Icon.ERROR,
				title: error,
				actions: [sap.m.MessageBox.Action.OK],
				onClose: function (oAction) {
					if (oAction === sap.m.MessageBox.Action.OK) {

					}
				}
			});

			/*var oCreateDialog = new sap.m.Dialog();
			oCreateDialog.setTitle(error);
			oCreateDialog.setIcon("sap-icon://message-error");
			oCreateDialog.addStyleClass(
				"dialogHdrBgCls dialogTitleCls dialogTextShadowCls dialogBoxShadowCls dialogIconCls dialogFooterBgCls");
			var oSimpleForm = new sap.ui.layout.form.SimpleForm({
				content: [
					new sap.m.Text({
						text: errMsg
					})
				]
			});
			oCreateDialog.addContent(oSimpleForm);

			oCreateDialog.addButton(
				new sap.m.Button({
					text: close,
					press: function () {
						if (oMsgFlag === "User") {
							that.byId("positonIdInp").setEnabled(false);
							that.byId("tempEmpNoInp").setEnabled(false);
							that.byId("reasonHeaderCombo").setEnabled(false);
							that.byId("tempStDate").setEnabled(false);
							that.byId("tempEndDate").setEnabled(false);
						} else {
							that.byId("positonIdInp").setEnabled(true);
							that.byId("tempEmpNoInp").setEnabled(true);
							that.byId("reasonHeaderCombo").setEnabled(true);
							that.byId("tempStDate").setEnabled(true);
							that.byId("tempEndDate").setEnabled(false);
						}
						oCreateDialog.close();
					}
				}).addStyleClass("sapUiSizeCompact clsBtnColorYellowRed")
			);
			oCreateDialog.open();*/

		},

		_onObjectMatched: function (oEvent) {
			var that = this;
			var startupParameter = that.getOwnerComponent().getComponentData().startupParameters.srvCal;
			if (startupParameter !== undefined) {
				var srvCal = that.getOwnerComponent().getComponentData().startupParameters.srvCal[0];
			}
			if (that.byId("IconTabbarId").getSelectedKey() === "empQualAssign") {
				that.onEmpNoEnter();
			} else if (that.byId("IconTabbarId").getSelectedKey() === "apprQualMaint") {
				var oModel1 = that.getOwnerComponent().getModel("oDataSrv");
				var union;
				if (that.craftUnion === "Engineering") {
					union = "E";
				} else if (that.craftUnion === "Mechanical") {
					union = "M";
				} else if (that.craftUnion === "TCU") {
					union = "T";
				} else if (that.craftUnion === "ATDA") {
					union = "A";
				} else if (that.craftUnion === "ILA") {
					union = "L";
				} else if (that.craftUnion === "Conrail") {
					union = "C";
				} else if (that.craftUnion === "IHB") {
					union = "I";
				} else if (that.craftUnion === "NAHR") {
					union = "N";
				} else if (that.craftUnion === "Payroll") {
					union = "P";
				}
				oModel1.read("/QualReqDetailsSet?$filter=Craft eq '" + union + "'", {
					async: false,
					success: function (oData1) {
						var oReqDetailsModel = new sap.ui.model.json.JSONModel(oData1);
						var oTable1 = that.byId("qualReqDetailsTableId1");
						oTable1.setModel(oReqDetailsModel, "qualReqDetailsModel");
					}
				});

			}
			that.handleIconTabBarSelect();
			if (srvCal === "Yes") {
				that.onEmpNoEnter();
			}

		},

		onAfterRendering: function () {
			var that = this;
			error = that.getView().getModel("i18n").getProperty("titleError");
			close = that.getView().getModel("i18n").getProperty("close");
		},

		onSelectionChange: function (oEvent) {
			var that = this;
			var craftType = oEvent.getParameter("selectedItem").getProperty("text");

			// --------------------Filters-----------

			if (craftType !== "Engineering" && craftType !== "Mechanical" && craftType !== "TCU") {
				this.byId("qualQualsInput").setEnabled(false);
				this.byId("qualCraftTypeCombo").setValueState("Error");
				sap.m.MessageToast.show("Please enter valid value");
			} else {
				that.craftSuggFun();
			}

		},
		onSelectEffDateChange: function (oEvent) {
			var dateFormat = this.getView().getModel("i18n").getProperty("dateFormat");
			var endDateGreaterStartDate = this.getView().getModel("i18n").getProperty("endDateGreaterStartDate");
			var startDate = this.byId("qualStDate").getValue();
			var endDate = this.byId("qualEndDate").getValue();
			var oDP = oEvent.getSource();
			var bValid = oEvent.getParameter("valid");

			if (startDate !== "") {
				var sDate = startDate.substring(0, 4) + "/" + startDate.substring(4, 6) + "/" + startDate.substring(6, 8);
			}
			if (endDate !== "") {
				var eDate = endDate.substring(0, 4) + "/" + endDate.substring(4, 6) + "/" + endDate.substring(6, 8);
			}

			var effDateSplit = sDate.split("/");
			startDate = effDateSplit[2] + "" + effDateSplit[0] + "" + effDateSplit[1];
			if (bValid) {
				oDP.setValueState(sap.ui.core.ValueState.None);
				if (new Date(eDate) < new Date(sDate)) {
					this.byId("qualEndDate").setValueState("Error");
					sap.m.MessageToast.show(endDateGreaterStartDate);
				} else {
					if (bValid) {
						oDP.setValueState(sap.ui.core.ValueState.None);
						this.byId("qualEndDate").setValueState("None");
						var that = this;
						var QualId = this.byId("qualQualsInputDesc").getText();
						var oModel1 = that.getOwnerComponent().getModel("oDataSrv");
						oModel1.read("/QualiSearchHelpSet?$filter=QualId eq '" + QualId + "' and Begindate eq '" + this.byId("qualStDate").getValue() +
							"'", {
								async: true,
								success: function (oData1) {
									if (oData1.results[0].Enddate !== "") {
										that.byId("qualEndDate").setValue(oData1.results[0].Enddate);
									}
								}
							});
					} else {
						oDP.setValueState(sap.ui.core.ValueState.Error);
						sap.m.MessageToast.show(dateFormat);
					}
				}
			} else {
				oDP.setValue("");
				oDP.setValueState(sap.ui.core.ValueState.Error);
				sap.m.MessageToast.show(dateFormat);
			}
		},

		onCraftChange: function () {

			var enterValidCraft = this.getView().getModel("i18n").getProperty("enterValidCraft");

			var craftType = this.byId("qualCraftTypeCombo").getValue();

			this.byId("qualQualsInput").setEnabled(true);

			if (craftType !== "Engineering" && craftType !== "Mechanical" && craftType !== "TCU") {
				this.byId("qualCraftTypeCombo").setValueState("Error");
				sap.m.MessageToast.show(enterValidCraft);
				this.byId("qualQualsInput").setEnabled(false);
			} else {
				this.byId("qualCraftTypeCombo").setValueState("None");
				this.byId("qualQualsInput").setEnabled(true);
				// this.byId("qualQualsInput").setWidth("85%");
				this.byId("qualEndDate").setWidth("85%");
			}

		},

		onSelectStDateChange: function (oEvent) {

			var dateFormat = this.getView().getModel("i18n").getProperty("dateFormat");
			var endDateGreaterStartDate = this.getView().getModel("i18n").getProperty("endDateGreaterStartDate");

			var startDate = this.byId("qualStDate").getValue();
			var endDate = this.byId("qualEndDate").getValue();

			var oDP = oEvent.getSource();
			var bValid = oEvent.getParameter("valid");

			if (bValid) {
				oDP.setValueState(sap.ui.core.ValueState.None);
			} else {
				oDP.setValue("");
				oDP.setValueState(sap.ui.core.ValueState.Error);
				sap.m.MessageToast.show(dateFormat);
			}

			if (startDate !== "") {
				var sDate = startDate.substring(0, 4) + "/" + startDate.substring(4, 6) + "/" + startDate.substring(6, 8);
			}

			if (endDate !== "") {
				var eDate = endDate.substring(0, 4) + "/" + endDate.substring(4, 6) + "/" + endDate.substring(6, 8);
			}

			if (new Date(eDate) < new Date(sDate)) {
				this.byId("qualEndDate").setValueState("Error");
				sap.m.MessageToast.show(endDateGreaterStartDate);

			} else {

				if (bValid) {
					oDP.setValueState(sap.ui.core.ValueState.None);
					this.byId("qualEndDate").setValueState("None");
				} else {
					oDP.setValueState(sap.ui.core.ValueState.Error);
					sap.m.MessageToast.show(dateFormat);
				}
			}

		},

		onAddRow: function () {
			var that = this;
			var enterEmpNo = this.getView().getModel("i18n").getProperty("enterEmpNo");
			var enterAggrEmpNo = this.getView().getModel("i18n").getProperty("enterAggrEmpNo");
			var selCraftType = this.getView().getModel("i18n").getProperty("selCraftType");
			var enterQuals = this.getView().getModel("i18n").getProperty("enterQuals");
			var enterStartDate = this.getView().getModel("i18n").getProperty("enterStartDate");
			var enterEndDate = this.getView().getModel("i18n").getProperty("enterEndDate");
			var endDateGreaterStartDate = this.getView().getModel("i18n").getProperty("endDateGreaterStartDate");
			var dupQualRecord = this.getView().getModel("i18n").getProperty("dupQualRecord");
			var qualAssignedAlready = this.getView().getModel("i18n").getProperty("qualAssignedAlready");
			var titleInfo = this.getView().getModel("i18n").getProperty("titleInfo");
			var ok = that.getView().getModel("i18n").getProperty("ok");
			var empNo = that.byId("empDataEmpNoInp").getTokens()[0].getKey(),
				craft = that.byId("craftType").getText(),
				craftType = that.byId("craftType").getText(),
				qualifications = that.byId("qualQualsInput").getTokens()[0].getKey(),
				qualID = that.QualId,
				startDate = that.byId("qualStDate").getValue(),
				endDate = that.byId("qualEndDate").getValue(),
				effectiveDate = that.byId("empDataEffDate").getValue(),
				qualproficiency = that.byId("qualproficiency").getSelectedKey();

			var effDateSplit = effectiveDate.split("/");
			var effDate = effDateSplit[2] + "" + effDateSplit[0] + "" + effDateSplit[1];

			if (craftType === "Engineering") {
				craftType = "TRACS - Engineering";
			}
			if (craftType === "Mechanical") {
				craftType = "TRACS - Mechanica";
			}
			if (craftType === "TCU") {
				craftType = "TRACS - TCU";
			}
			if (craftType === "") {
				craftType = "No Craft";
			}
			that.craftType = craftType;
			var stDate;
			if (startDate !== "") {
				if (startDate.includes("/")) {
					var startDateSplit = startDate.split("/");
					stDate = startDateSplit[2] + "" + startDateSplit[0] + "" + startDateSplit[1];
				} else {
					stDate = startDate;
				}
				// stDate = startDate;
			} else {
				stDate = "";
			}
			var enDate;
			if (endDate !== "") {
				if (endDate.includes("/")) {
					var endDateSplit = endDate.split("/");
					enDate = endDateSplit[2] + "" + endDateSplit[0] + "" + endDateSplit[1];
				} else {
					enDate = endDate;
				}
				// enDate = endDate;
			} else {
				enDate = "";
			}
			if (that.byId("qualQualsInput").getTokens().length === 0) {
				sap.m.MessageToast.show("Qualification can't be empty");
				return;
			}
			var sdate = new Date(new Date(stDate.slice(0, 4) + "-" + stDate.slice(4, 6) + "-" + stDate.slice(6, 8)).getUTCFullYear(), new Date(
				stDate.slice(0, 4) + "-" + stDate.slice(4, 6) + "-" + stDate.slice(6, 8)).getUTCMonth(), new Date(stDate.slice(0, 4) + "-" +
				stDate.slice(4, 6) + "-" + stDate.slice(6, 8)).getUTCDate()).setHours(0, 0, 0, 0);
			var cDate = new Date(new Date().getUTCFullYear(), new Date().getUTCMonth(), new Date().getUTCDate()).setHours(0, 0, 0, 0);
			if (stDate === "") {
				sap.m.MessageToast.show("Effective date can't be empty");
				return;
			}
			// } else if (sdate < cDate) {
			// 	sap.m.MessageToast.show("Start date can't be less then today");
			// 	return;
			// }
			var eDate = new Date(new Date(enDate.slice(0, 4) + "-" + enDate.slice(4, 6) + "-" + enDate.slice(6, 8)).getUTCFullYear(), new Date(
				enDate.slice(0, 4) + "-" + enDate.slice(4, 6) + "-" + enDate.slice(6, 8)).getUTCMonth(), new Date(enDate.slice(0, 4) + "-" +
				enDate.slice(4, 6) + "-" + enDate.slice(6, 8)).getUTCDate()).setHours(0, 0, 0, 0);
			if (enDate === "") {
				sap.m.MessageToast.show("End date can't be empty");
				return;
			} else if (sdate > eDate) {
				sap.m.MessageToast.show("Effective date can't be less then end date");
				return;
			}

			if (empNo === "") {
				sap.m.MessageToast.show(enterEmpNo);
				that.byId("empDataEmpNoInp").setValueState("Error");
			} else if (that.byId("empDataEmpNoInp").getValueState() === "Error") {
				sap.m.MessageToast.show(enterAggrEmpNo);
			} else if (craftType === "") {
				sap.m.MessageToast.show(selCraftType);
				// } else if (qualifications === "") {
				// 	sap.m.MessageToast.show(enterQuals);
			} else if (startDate === "") {
				sap.m.MessageToast.show(enterStartDate);
			} else if (endDate === "") {
				sap.m.MessageToast.show(enterEndDate);
			} else if (this.byId("qualEndDate").getValueState() === "Error") {
				sap.m.MessageToast.show(endDateGreaterStartDate);
			} else {

				that.byId("empDataEmpNoInp").setValueState("None");
				that.byId("qualEndDate").setValueState("None");

				var oResults = that.getView().byId("qualTable").getModel("oModelData");

				var queryFil = [];
				var qual = new sap.ui.model.Filter("Qualification", "EQ", qualID);
				var StartDate = new sap.ui.model.Filter("Begda", "EQ", stDate);
				var EndDate = new sap.ui.model.Filter("Endda", "EQ", enDate);
				var empId = new sap.ui.model.Filter("Pernr", "EQ", empNo);
				var EffDate = new sap.ui.model.Filter("EffDate", "EQ", effDate);
				queryFil.push(qual);
				queryFil.push(StartDate);
				queryFil.push(EndDate);
				queryFil.push(empId);
				queryFil.push(EffDate);

				var oModel = that.getOwnerComponent().getModel();
				if (oResults.oData.results.length > 0) {

					oResults = that.getView().byId("qualTable").getModel("oModelData").getData();

					oModel.read("/CreateQualificationSet", {
						filters: queryFil,
						success: function (oData) {

							that.byId("qualStDate").setValueState("None");

							// var beforeDatesArray = [];
							var betweenDatesArray = [];
							var extendDatesArray = [];
							var newDatesArray = [];
							var existQualArray = [];
							var check = "X";

							that.additionalInfoCheckArr[0] = false;
							if (oData.results[0].Document === "Yes") {
								that.additionalInfoCheckArr[0] = true;
							}
							if (oData.results[0].AddField1 !== "") {
								that.additionalInfoCheckArr[0] = true;
							}
							if (oData.results[0].AddField2 !== "") {
								that.additionalInfoCheckArr[0] = true;
							}
							if (oData.results[0].AddField3 !== "") {
								that.additionalInfoCheckArr[0] = true;
							}
							if (oData.results[0].AddField4 !== "") {
								that.additionalInfoCheckArr[0] = true;
							}
							if (oData.results[0].AddField5 !== "") {
								that.additionalInfoCheckArr[0] = true;
							}
							if (oData.results[0].AddField6 !== "") {
								that.additionalInfoCheckArr[0] = true;
							}
							if (oData.results[0].AddField7 !== "") {
								that.additionalInfoCheckArr[0] = true;
							}
							if (oData.results[0].AddField8 !== "") {
								that.additionalInfoCheckArr[0] = true;
							}
							if (oData.results[0].AddField9 !== "") {
								that.additionalInfoCheckArr[0] = true;
							}
							if (oData.results[0].AddField10 !== "") {
								that.additionalInfoCheckArr[0] = true;
							}

							for (var h = 0; h < oResults.results.length; h++) {

								var existStDate = oResults.results[h].stDate;
								var existEnDate = oResults.results[h].enDate;

								var existStDateVal = new Date(new Date(existStDate.slice(0, 4) + "-" + existStDate.slice(4, 6) + "-" + existStDate.slice(6,
									8)).getUTCFullYear(), new Date(
									existStDate.slice(0, 4) + "-" + existStDate.slice(4, 6) + "-" + existStDate.slice(6, 8)).getUTCMonth(), new Date(
									existStDate.slice(0, 4) + "-" +
									existStDate.slice(4, 6) + "-" + existStDate.slice(6, 8)).getUTCDate()).setHours(0, 0, 0, 0);

								var existEnDateVal = new Date(new Date(existEnDate.slice(0, 4) + "-" + existEnDate.slice(4, 6) + "-" + existEnDate.slice(6,
									8)).getUTCFullYear(), new Date(
									existEnDate.slice(0, 4) + "-" + existEnDate.slice(4, 6) + "-" + existEnDate.slice(6, 8)).getUTCMonth(), new Date(
									existEnDate.slice(0, 4) + "-" +
									existEnDate.slice(4, 6) + "-" + existEnDate.slice(6, 8)).getUTCDate()).setHours(0, 0, 0, 0);

								var existQual = oResults.results[h].qualID;

								if (qualID === existQual) {
									if (sdate >= existStDateVal && eDate <= existEnDateVal) {
										betweenDatesArray.push(check);
									}
									// else if (sdate >= existStDateVal && eDate > existEnDateVal && sdate <= existEnDateVal) {
									// 	extendDatesArray.push(check);
									// } 
									else if (sdate > existEnDateVal && eDate > sdate) {
										newDatesArray.push(check);
									}

								} else {
									existQualArray.push();
								}

							}

							if (betweenDatesArray.length > 0) {
								sap.m.MessageToast.show(dupQualRecord);
							} else if (extendDatesArray.length > 0) {
								sap.m.MessageToast.show(qualAssignedAlready);
							} else if (newDatesArray.length > 0) {

								if (that.additionalInfoCheckArr[0] === true) {
									if (empNo === "") {
										empNo = " ";
									} else {
										empNo = empNo;
									}
									if (craft === "") {
										craft = " ";
									} else {
										craft = craft;
									}
									if (qualifications === "") {
										qualifications = " ";
									} else {
										qualifications = qualifications;
									}
									if (qualID === "") {
										qualID = " ";
									} else {
										qualID = qualID;
									}
									if (stDate === "") {
										stDate = " ";
									} else {
										stDate = stDate;
									}
									if (enDate === "") {
										enDate = " ";
									} else {
										enDate = enDate;
									}
									if (qualproficiency === "") {
										qualproficiency = " ";
									} else {
										qualproficiency = qualproficiency;
									}
									if (effDate === "") {
										effDate = " ";
									} else {
										effDate = effDate;
									}

									// sap.ui.core.UIComponent.getRouterFor(that).navTo("object", {
									// 	empNo: empNo,
									// 	craft: craft,
									// 	qualifications: encodeURIComponent(qualifications),
									// 	qualID: qualID,
									// 	startDate: stDate,
									// 	endDate: enDate,
									// 	qualproficiency: qualproficiency,
									// 	effDate: effDate
									// });
									var prof = that.byId("qualproficiency").getSelectedKey();
									if (prof === "") {
										prof = " ";
									}
									sap.ui.core.UIComponent.getRouterFor(that).navTo("QualDispEdit", {
										empNo: empNo,
										craft: craft,
										qualId: qualID,
										effDate: effDate,
										type: "Edit",
										startDate: stDate,
										endDate: enDate,
										qualDesc: encodeURIComponent(qualifications),
										profScale: prof
									});

									that.byId("qualQualsInput").removeAllTokens();
									// that.byId("qualQualsInput").setWidth("60%");
									// that.byId("qualQualsInput").setDescription("");
									that.byId("qualQualsInputDesc").setText("");
									that.byId("qualStDate").setValue("");
									that.byId("qualEndDate").setValue("");
									that.byId("qualEndDate").setWidth("60%");
									// that.byId("qualproficiency").setValue("");
									// that.byId("qualproficiency").setSelectedKey("");
								} else {
									that.onSave();
								}

							} else if (existQualArray.length === 0) {

								// var createExstTableObj = {};
								// createExstTableObj.qualGroup = craftType;
								// createExstTableObj.quals = qualifications;
								// createExstTableObj.qualID = qualID;
								// createExstTableObj.stDate = stDate;
								// createExstTableObj.enDate = enDate;
								// createExstTableObj.profScale = "Yes";
								// createExstTableObj.Pernr = empNo;
								// createExstTableObj.rowKey = "F";
								// oResults.results.push(createExstTableObj);
								// that.getView().byId("qualTable").getModel("oModelData").setData(oResults);
								// that.byId("qualTable").getModel("oModelData").refresh();
								that.additionalInfoCheckArr[0] = false;
								if (oData.results[0].Document === "Yes") {
									that.additionalInfoCheckArr[0] = true;
								}
								if (oData.results[0].AddField1 !== "") {
									that.additionalInfoCheckArr[0] = true;
								}
								if (oData.results[0].AddField2 !== "") {
									that.additionalInfoCheckArr[0] = true;
								}
								if (oData.results[0].AddField3 !== "") {
									that.additionalInfoCheckArr[0] = true;
								}
								if (oData.results[0].AddField4 !== "") {
									that.additionalInfoCheckArr[0] = true;
								}
								if (oData.results[0].AddField5 !== "") {
									that.additionalInfoCheckArr[0] = true;
								}
								if (oData.results[0].AddField6 !== "") {
									that.additionalInfoCheckArr[0] = true;
								}
								if (oData.results[0].AddField7 !== "") {
									that.additionalInfoCheckArr[0] = true;
								}
								if (oData.results[0].AddField8 !== "") {
									that.additionalInfoCheckArr[0] = true;
								}
								if (oData.results[0].AddField9 !== "") {
									that.additionalInfoCheckArr[0] = true;
								}
								if (oData.results[0].AddField10 !== "") {
									that.additionalInfoCheckArr[0] = true;
								}
								if (that.additionalInfoCheckArr[0] === true) {
									if (empNo === "") {
										empNo = " ";
									} else {
										empNo = empNo;
									}
									if (craft === "") {
										craft = " ";
									} else {
										craft = craft;
									}
									if (qualifications === "") {
										qualifications = " ";
									} else {
										qualifications = qualifications;
									}
									if (qualID === "") {
										qualID = " ";
									} else {
										qualID = qualID;
									}
									if (stDate === "") {
										stDate = " ";
									} else {
										stDate = stDate;
									}
									if (enDate === "") {
										enDate = " ";
									} else {
										enDate = enDate;
									}
									if (qualproficiency === "") {
										qualproficiency = " ";
									} else {
										qualproficiency = qualproficiency;
									}
									if (effDate === "") {
										effDate = " ";
									} else {
										effDate = effDate;
									}

									// sap.ui.core.UIComponent.getRouterFor(that).navTo("object", {
									// 	empNo: empNo,
									// 	craft: craft,
									// 	qualifications: encodeURIComponent(qualifications),
									// 	qualID: qualID,
									// 	startDate: stDate,
									// 	endDate: enDate,
									// 	qualproficiency: qualproficiency,
									// 	effDate: effDate
									// });
									var prof = that.byId("qualproficiency").getSelectedKey();
									if (prof === "") {
										prof = " ";
									}
									sap.ui.core.UIComponent.getRouterFor(that).navTo("QualDispEdit", {
										empNo: empNo,
										craft: craft,
										qualId: qualID,
										effDate: effDate,
										type: "Edit",
										startDate: stDate,
										endDate: enDate,
										qualDesc: encodeURIComponent(qualifications),
										profScale: prof
									});

									that.byId("qualQualsInput").removeAllTokens();
									// that.byId("qualQualsInput").setWidth("60%");
									// that.byId("qualQualsInput").setDescription("");
									that.byId("qualQualsInputDesc").setText("");
									that.byId("qualStDate").setValue("");
									that.byId("qualEndDate").setValue("");
									that.byId("qualEndDate").setWidth("60%");
									// that.byId("qualproficiency").setValue("");
									// that.byId("qualproficiency").setSelectedKey("");
								} else {
									that.onSave();
								}

								// that.byId("saveBtn").setEnabled(true);

								/*	that.byId("qualQualsInput").setValue("");
									that.byId("qualQualsInput").setWidth("60%");
									that.byId("qualQualsInput").setDescription("");
									that.byId("qualStDate").setValue("");
									that.byId("qualEndDate").setValue("");
									that.byId("qualEndDate").setWidth("60%");
									that.byId("qualproficiency").setValue("");
									that.byId("qualproficiency").setSelectedKey("");*/

							}

						},
						error: function (oResponse) {

							//-----------------------------------------------------------------------	
							// Displaying response body message.
							//-----------------------------------------------------------------------

							// var oMessage = $(oResponse.response.body).find('message').first().text();
							var oMessage = JSON.parse(oResponse.responseText).error.innererror.errordetails[0].message;

							var msg = oMessage;
							var splitMsg = msg.split(":");
							var msgCode = splitMsg[0];
							var message = splitMsg[1];

							var errmsg;
							if (oMessage === "") {
								errmsg = oResponse.response.body;
							} else {
								// errmsg = oMessage;
								errmsg = message;
							}

							sap.m.MessageBox.information(errmsg, {
								icon: sap.m.MessageBox.Icon.INFORMATION,
								title: "Information",
								actions: ["OK"],
								onClose: function (oAction) {
									if (oAction === "OK") {
										if (msgCode === "S") {
											that.byId("qualStDate").setValueState("Error");
										} else if (msgCode === "E") {
											that.byId("qualEndDate").setValueState("Error");
										}
									}
								}
							});

							/*var oCreateDialog = new sap.m.Dialog();
							oCreateDialog.setTitle(titleInfo);
							oCreateDialog.setIcon("sap-icon://message-information");
							oCreateDialog.addStyleClass(
								"dialogHdrBgCls dialogTitleCls dialogTextShadowCls dialogBoxShadowCls dialogIconCls dialogFooterBgCls");
							var oSimpleForm = new sap.ui.layout.form.SimpleForm({
								content: [
									new sap.m.Text({
										text: errmsg
									})
								]
							});
							oCreateDialog.addContent(oSimpleForm);
							oCreateDialog.addButton(
								new sap.m.Button({
									text: ok,
									press: function () {

										if (msgCode === "S") {
											that.byId("qualStDate").setValueState("Error");
										} else if (msgCode === "E") {
											that.byId("qualEndDate").setValueState("Error");
										}

										oCreateDialog.close();
									}
								}).addStyleClass("sapUiSizeCompact clsBtnColorYellowRed")
							);
							oCreateDialog.open();*/

						}
					});

				} else {

					oModel.read("/CreateQualificationSet", {
						filters: queryFil,
						success: function (oData) {

							that.byId("qualStDate").setValueState("None");

							that.additionalInfoCheckArr[0] = false;
							if (oData.results[0].Document === "Yes") {
								that.additionalInfoCheckArr[0] = true;
							}
							if (oData.results[0].AddField1 !== "") {
								that.additionalInfoCheckArr[0] = true;
							}
							if (oData.results[0].AddField2 !== "") {
								that.additionalInfoCheckArr[0] = true;
							}
							if (oData.results[0].AddField3 !== "") {
								that.additionalInfoCheckArr[0] = true;
							}
							if (oData.results[0].AddField4 !== "") {
								that.additionalInfoCheckArr[0] = true;
							}
							if (oData.results[0].AddField5 !== "") {
								that.additionalInfoCheckArr[0] = true;
							}
							if (oData.results[0].AddField6 !== "") {
								that.additionalInfoCheckArr[0] = true;
							}
							if (oData.results[0].AddField7 !== "") {
								that.additionalInfoCheckArr[0] = true;
							}
							if (oData.results[0].AddField8 !== "") {
								that.additionalInfoCheckArr[0] = true;
							}
							if (oData.results[0].AddField9 !== "") {
								that.additionalInfoCheckArr[0] = true;
							}
							if (oData.results[0].AddField10 !== "") {
								that.additionalInfoCheckArr[0] = true;
							}

							if (that.additionalInfoCheckArr[0] === true) {
								if (empNo === "") {
									empNo = " ";
								} else {
									empNo = empNo;
								}
								if (craft === "") {
									craft = " ";
								} else {
									craft = craft;
								}
								if (qualifications === "") {
									qualifications = " ";
								} else {
									qualifications = qualifications;
								}
								if (qualID === "") {
									qualID = " ";
								} else {
									qualID = qualID;
								}
								if (stDate === "") {
									stDate = " ";
								} else {
									stDate = stDate;
								}
								if (enDate === "") {
									enDate = " ";
								} else {
									enDate = enDate;
								}
								if (qualproficiency === "") {
									qualproficiency = " ";
								} else {
									qualproficiency = qualproficiency;
								}
								if (effDate === "") {
									effDate = " ";
								} else {
									effDate = effDate;
								}

								// sap.ui.core.UIComponent.getRouterFor(that).navTo("object", {
								// 	empNo: empNo,
								// 	craft: craft,
								// 	qualifications: encodeURIComponent(qualifications),
								// 	qualID: qualID,
								// 	startDate: stDate,
								// 	endDate: enDate,
								// 	qualproficiency: qualproficiency,
								// 	effDate: effDate
								// });
								var prof = that.byId("qualproficiency").getSelectedKey();
								if (prof === "") {
									prof = " ";
								}
								sap.ui.core.UIComponent.getRouterFor(that).navTo("QualDispEdit", {
									empNo: empNo,
									craft: craft,
									qualId: qualID,
									effDate: effDate,
									type: "Edit",
									startDate: stDate,
									endDate: enDate,
									qualDesc: encodeURIComponent(qualifications),
									profScale: prof
								});

								that.byId("qualQualsInput").removeAllTokens();
								// that.byId("qualQualsInput").setWidth("60%");
								// that.byId("qualQualsInput").setDescription("");
								that.byId("qualQualsInputDesc").setText("");
								that.byId("qualStDate").setValue("");
								that.byId("qualEndDate").setValue("");
								that.byId("qualEndDate").setWidth("60%");
								// that.byId("qualproficiency").setValue("");
								// that.byId("qualproficiency").setSelectedKey("");
							} else {
								that.onSave();
							}

							/*var createTableArray = [];
							var createTableObj = {};

							createTableObj.qualGroup = craftType;
							createTableObj.quals = qualifications;
							createTableObj.qualID = qualID;
							createTableObj.stDate = stDate;
							createTableObj.enDate = enDate;
							createTableObj.profScale = "Yes";
							createTableObj.rowKey = "F";

							createTableArray.push(createTableObj);

							var addRowUniqQualArr1 = that.addRownique1(createTableArray);
							var oQualTableModel = new sap.ui.model.json.JSONModel({
								"results": addRowUniqQualArr1
							});

							var oQalTable = that.getView().byId("qualTable");
							oQalTable.setModel(oQualTableModel, "oModelData");
							that.byId("qualTable").getModel("oModelData").refresh();

							that.byId("saveBtn").setEnabled(true);

							that.byId("qualCraftTypeCombo").setValue("");
							that.byId("qualQualsInput").setValue("");
							that.byId("qualQualsInput").setWidth("60%");
							that.byId("qualQualsInput").setDescription("");
							that.byId("qualQualsInput").setEnabled(false);
							that.byId("qualStDate").setValue("");
							that.byId("qualEndDate").setValue("");
							that.byId("qualEndDate").setWidth("60%");
							that.byId("qualproficiency").setValue("");
							that.byId("qualproficiency").setSelectedKey("");*/

						},
						error: function (oResponse) {

							//-----------------------------------------------------------------------	
							// Displaying response body message.
							//-----------------------------------------------------------------------

							// var oMessage = $(oResponse.response.body).find('message').first().text();
							var errmsg = JSON.parse(oResponse.responseText).error.innererror.errordetails[0].message;
							/*var errmsg;
							if (oMessage === "") {
								errmsg = oResponse.response.body;
							} else {
								errmsg = oMessage;
							}*/

							sap.m.MessageBox.information(errmsg, {
								icon: sap.m.MessageBox.Icon.INFORMATION,
								title: titleInfo,
								actions: ["OK"],
								onClose: function (oAction) {
									if (oAction === "OK") {
										that.byId("qualStDate").setValueState("Error");
									}
								}
							});

							/*var oCreateDialog = new sap.m.Dialog();
							oCreateDialog.setTitle(titleInfo);
							oCreateDialog.setIcon("sap-icon://message-information");
							oCreateDialog.addStyleClass(
								"dialogHdrBgCls dialogTitleCls dialogTextShadowCls dialogBoxShadowCls dialogIconCls dialogFooterBgCls");
							var oSimpleForm = new sap.ui.layout.form.SimpleForm({
								content: [
									new sap.m.Text({
										text: errmsg
									})
								]
							});
							oCreateDialog.addContent(oSimpleForm);
							oCreateDialog.addButton(
								new sap.m.Button({
									text: ok,
									press: function () {
										that.byId("qualStDate").setValueState("Error");
										oCreateDialog.close();
									}
								}).addStyleClass("sapUiSizeCompact clsBtnColorYellowRed")
							);
							oCreateDialog.open();*/

						}
					});

				}

			}

		},

		onInlineDelimit: function (oEvent) {
			var that = this;
			that.index = parseInt(oEvent.getSource().getId().split("qualTable-")[1]);
			var context = oEvent.getSource().getBindingContext("oModelData");
			that.QualdataObject = context.getModel().getProperty(context.getPath());
			if (!that._qualValueDelimit) {
				that._qualValueDelimit = sap.ui.xmlfragment("com.empqualassignment.Employee_Qual_Assignment.fragment.Delimit", that.getView()
					.getController());
				that.getView().addDependent(that._qualValueDelimit);
			}
			that._qualValueDelimit.open();

			that._qualValueDelimit.setEscapeHandler(function (o) {
				o.reject();
			});

			sap.ui.getCore().byId("delimitQual").setValue(that.QualdataObject.quals);
			sap.ui.getCore().byId("qualDelimtDateChange").setValue("");

		},

		onDelimiDateChange: function () {

			var that = this;
			var stDate = that.QualdataObject.stDate;
			if (stDate !== "") {
				var oStartDate = stDate.substring(4, 6) + "/" + stDate.substring(6, 8) + "/" + stDate.substring(0, 4);
			}
			var enDate = that.QualdataObject.enDate;
			if (enDate !== "") {
				var oEndDate = enDate.substring(4, 6) + "/" + enDate.substring(6, 8) + "/" + enDate.substring(0, 4);
			}
			var delimitDate = sap.ui.getCore().byId("qualDelimtDateChange").getValue();
			if (delimitDate !== "") {
				var oDelimitDate = delimitDate.substring(4, 6) + "/" + delimitDate.substring(6, 8) + "/" + delimitDate.substring(0, 4);
			}
			if ((new Date(oStartDate) <= new Date(oDelimitDate)) && (new Date(oEndDate) >= new Date(oDelimitDate))) {
				sap.ui.getCore().byId("qualDelimtDateChange").setValue(delimitDate);

			} else {
				sap.ui.getCore().byId("qualDelimtDateChange").setValue();
				sap.m.MessageToast.show("Please select the Delimit Date between" + oStartDate + " " + "and" + " " + oEndDate);
			}

		},

		onDelimitCancel: function () {
			var that = this;
			that._qualValueDelimit.close();
		},
		onEndDateCancel: function () {
			this._qualValueEnd.close();
		},
		onUpdateEndDate: function () {
			var that = this;
			var titleSuccess = that.getView().getModel("i18n").getProperty("titleSuccess");
			var titleInfo = that.getView().getModel("i18n").getProperty("titleInfo");
			var ok = that.getView().getModel("i18n").getProperty("ok");

			var oDelimit = sap.ui.getCore().byId("qualEndDate").getValue();
			var itemArr = [];
			if (oDelimit !== "") {
				var itemObj = {};
				itemObj.Qualification = that.QualdataObject.qualID;
				itemObj.Begda = that.QualdataObject.stDate;
				// itemObj.Endda = endDate;
				itemObj.Endda = oDelimit;
				itemObj.Pernr = that.byId("empDataEmpNoInp").getTokens()[0].getKey();
				itemObj.Key = "E";
				itemArr.push(itemObj);

				var oEntry = {};
				oEntry.Pernr = that.byId("empDataEmpNoInp").getTokens()[0].getKey();
				oEntry.Qualification = that.QualdataObject.qualID;
				// oEntry.Key = "E";
				oEntry.CreateQualificationSet = itemArr;

				var oModel = that.getOwnerComponent().getModel();
				oModel.create("/QualHeaderSet", oEntry, {
					success: function (oData, oResponse) {

						sap.m.MessageBox.information("Updated Successfully", {
							icon: sap.m.MessageBox.Icon.INFORMATION,
							title: "Information",
							actions: ["OK"],
							onClose: function (oAction) {
								if (oAction === "OK") {
									that._qualValueEnd.close();
									var pernr = that.byId("empDataEmpNoInp").getTokens()[0].getKey();
									var effDate = that.byId("empDataEffDate").getValue();

									var EffDate = effDate.split("/");
									var effectiveDate = EffDate[2] + "" + EffDate[0] + "" + EffDate[1];

									that.byId("empDataEffDate").setValueState("None");
									that.qualDataFun(pernr, effectiveDate, "D");
								}
							}
						});

						/*var oCreateDialog = new sap.m.Dialog();
						oCreateDialog.setTitle(titleSuccess);
						oCreateDialog.setIcon("sap-icon://message-success");
						oCreateDialog.addStyleClass(
							"dialogHdrBgCls dialogTitleCls dialogTextShadowCls dialogBoxShadowCls dialogIconCls dialogFooterBgCls");
						var oSimpleForm = new sap.ui.layout.form.SimpleForm({
							content: [
								new sap.m.Text({
									text: "Created Successfully"
								})
							]
						});
						oCreateDialog.addContent(oSimpleForm);

						oCreateDialog.addButton(
							new sap.m.Button({
								text: ok,
								press: function () {
									oCreateDialog.close();
									that._qualValueDelimit.close();
									var pernr = that.byId("empDataEmpNoInp").getTokens()[0].getKey();
									var effDate = that.byId("empDataEffDate").getValue();

									var EffDate = effDate.split("/");
									var effectiveDate = EffDate[2] + "" + EffDate[0] + "" + EffDate[1];

									that.byId("empDataEffDate").setValueState("None");
									that.qualDataFun(pernr, effectiveDate, "D");
								}
							}).addStyleClass("sapUiSizeCompact clsBtnColorYellowRed")
						);
						oCreateDialog.open();*/

					},
					error: function (oResponse) {

						//-----------------------------------------------------------------------	
						// Displaying response header message.
						//-----------------------------------------------------------------------

						var oMessage = JSON.parse(oResponse.responseText).error.innererror.errordetails[0].message;

						sap.m.MessageBox.information(oMessage, {
							icon: sap.m.MessageBox.Icon.INFORMATION,
							title: "Information",
							actions: ["OK"],
							onClose: function (oAction) {
								if (oAction === "OK") {

									that._qualValueEnd.close();
									var pernr = that.byId("empDataEmpNoInp").getTokens()[0].getKey();
									var effDate = that.byId("empDataEffDate").getValue();

									var EffDate = effDate.split("/");
									var effectiveDate = EffDate[2] + "" + EffDate[0] + "" + EffDate[1];
									var emptyJson = new sap.ui.model.json.JSONModel([]);
									that.getView().byId("qualTable").setModel(emptyJson, "oModelData");
									that.byId("empDataEffDate").setValueState("None");
									that.qualDataFun(pernr, effectiveDate, "D");

								}
							}
						});

						/*var oCreateDialog = new sap.m.Dialog();
						oCreateDialog.setTitle(titleInfo);
						oCreateDialog.setIcon("sap-icon://message-information");
						oCreateDialog.addStyleClass(
							"dialogHdrBgCls dialogTitleCls dialogTextShadowCls dialogBoxShadowCls dialogIconCls dialogFooterBgCls");
						var oSimpleForm = new sap.ui.layout.form.SimpleForm({
							content: [
								new sap.m.Text({
									text: oMessage
								})
							]
						});
						oCreateDialog.addContent(oSimpleForm);
						oCreateDialog.addButton(
							new sap.m.Button({
								text: ok,
								press: function () {
									oCreateDialog.close();
									that._qualValueDelimit.close();
									var pernr = that.byId("empDataEmpNoInp").getTokens()[0].getKey();
									var effDate = that.byId("empDataEffDate").getValue();

									var EffDate = effDate.split("/");
									var effectiveDate = EffDate[2] + "" + EffDate[0] + "" + EffDate[1];
									var emptyJson = new sap.ui.model.json.JSONModel([]);
									that.getView().byId("qualTable").setModel(emptyJson, "oModelData");
									that.byId("empDataEffDate").setValueState("None");
									that.qualDataFun(pernr, effectiveDate, "D");
								}
							}).addStyleClass("sapUiSizeCompact clsBtnColorYellowRed")
						);
						oCreateDialog.open();*/

					}
				});

				// that._qualValueDelimit.close();
			} else {
				sap.m.MessageToast.show("Please select End Date");
			}
		},
		onUpdateDelimit: function () {
			var that = this;
			var titleSuccess = that.getView().getModel("i18n").getProperty("titleSuccess");
			var titleInfo = that.getView().getModel("i18n").getProperty("titleInfo");
			var ok = that.getView().getModel("i18n").getProperty("ok");

			var oDelimit = sap.ui.getCore().byId("qualDelimtDateChange").getValue();
			var itemArr = [];
			if (oDelimit !== "") {
				var itemObj = {};
				itemObj.Qualification = that.QualdataObject.qualID;
				itemObj.Begda = that.QualdataObject.stDate;
				// itemObj.Endda = endDate;
				itemObj.Endda = oDelimit;
				itemObj.Pernr = that.byId("empDataEmpNoInp").getTokens()[0].getKey();
				itemObj.Key = "E";
				itemArr.push(itemObj);

				var oEntry = {};
				oEntry.Pernr = that.byId("empDataEmpNoInp").getTokens()[0].getKey();
				oEntry.Qualification = that.QualdataObject.qualID;
				// oEntry.Key = "E";
				oEntry.CreateQualificationSet = itemArr;

				var oModel = that.getOwnerComponent().getModel();
				oModel.create("/QualHeaderSet", oEntry, {
					success: function (oData, oResponse) {

						sap.m.MessageBox.information("Created Successfully", {
							icon: sap.m.MessageBox.Icon.INFORMATION,
							title: "Information",
							actions: ["OK"],
							onClose: function (oAction) {
								if (oAction === "OK") {
									that._qualValueDelimit.close();
									var pernr = that.byId("empDataEmpNoInp").getTokens()[0].getKey();
									var effDate = that.byId("empDataEffDate").getValue();

									var EffDate = effDate.split("/");
									var effectiveDate = EffDate[2] + "" + EffDate[0] + "" + EffDate[1];

									that.byId("empDataEffDate").setValueState("None");
									that.qualDataFun(pernr, effectiveDate, "D");
								}
							}
						});

						/*var oCreateDialog = new sap.m.Dialog();
						oCreateDialog.setTitle(titleSuccess);
						oCreateDialog.setIcon("sap-icon://message-success");
						oCreateDialog.addStyleClass(
							"dialogHdrBgCls dialogTitleCls dialogTextShadowCls dialogBoxShadowCls dialogIconCls dialogFooterBgCls");
						var oSimpleForm = new sap.ui.layout.form.SimpleForm({
							content: [
								new sap.m.Text({
									text: "Created Successfully"
								})
							]
						});
						oCreateDialog.addContent(oSimpleForm);

						oCreateDialog.addButton(
							new sap.m.Button({
								text: ok,
								press: function () {
									oCreateDialog.close();
									that._qualValueDelimit.close();
									var pernr = that.byId("empDataEmpNoInp").getTokens()[0].getKey();
									var effDate = that.byId("empDataEffDate").getValue();

									var EffDate = effDate.split("/");
									var effectiveDate = EffDate[2] + "" + EffDate[0] + "" + EffDate[1];

									that.byId("empDataEffDate").setValueState("None");
									that.qualDataFun(pernr, effectiveDate, "D");
								}
							}).addStyleClass("sapUiSizeCompact clsBtnColorYellowRed")
						);
						oCreateDialog.open();*/

					},
					error: function (oResponse) {

						//-----------------------------------------------------------------------	
						// Displaying response header message.
						//-----------------------------------------------------------------------

						var oMessage = JSON.parse(oResponse.responseText).error.innererror.errordetails[0].message;

						sap.m.MessageBox.information(oMessage, {
							icon: sap.m.MessageBox.Icon.INFORMATION,
							title: "Information",
							actions: ["OK"],
							onClose: function (oAction) {
								if (oAction === "OK") {

									that._qualValueDelimit.close();
									var pernr = that.byId("empDataEmpNoInp").getTokens()[0].getKey();
									var effDate = that.byId("empDataEffDate").getValue();

									var EffDate = effDate.split("/");
									var effectiveDate = EffDate[2] + "" + EffDate[0] + "" + EffDate[1];
									var emptyJson = new sap.ui.model.json.JSONModel([]);
									that.getView().byId("qualTable").setModel(emptyJson, "oModelData");
									that.byId("empDataEffDate").setValueState("None");
									that.qualDataFun(pernr, effectiveDate, "D");

								}
							}
						});

						/*var oCreateDialog = new sap.m.Dialog();
						oCreateDialog.setTitle(titleInfo);
						oCreateDialog.setIcon("sap-icon://message-information");
						oCreateDialog.addStyleClass(
							"dialogHdrBgCls dialogTitleCls dialogTextShadowCls dialogBoxShadowCls dialogIconCls dialogFooterBgCls");
						var oSimpleForm = new sap.ui.layout.form.SimpleForm({
							content: [
								new sap.m.Text({
									text: oMessage
								})
							]
						});
						oCreateDialog.addContent(oSimpleForm);
						oCreateDialog.addButton(
							new sap.m.Button({
								text: ok,
								press: function () {
									oCreateDialog.close();
									that._qualValueDelimit.close();
									var pernr = that.byId("empDataEmpNoInp").getTokens()[0].getKey();
									var effDate = that.byId("empDataEffDate").getValue();

									var EffDate = effDate.split("/");
									var effectiveDate = EffDate[2] + "" + EffDate[0] + "" + EffDate[1];
									var emptyJson = new sap.ui.model.json.JSONModel([]);
									that.getView().byId("qualTable").setModel(emptyJson, "oModelData");
									that.byId("empDataEffDate").setValueState("None");
									that.qualDataFun(pernr, effectiveDate, "D");
								}
							}).addStyleClass("sapUiSizeCompact clsBtnColorYellowRed")
						);
						oCreateDialog.open();*/

					}
				});

				// that._qualValueDelimit.close();
			} else {
				sap.m.MessageToast.show("Please select Delimit Date");
			}
		},
		/*-----Fragment to open for Qulaification search Help-------*/
		qualValueHelpReq: function (oEvt) {
			var that = this;
			var union;
			var sFilters = [];
			var titleError = this.getView().getModel("i18n").getProperty("titleError");
			var Close = this.getView().getModel("i18n").getProperty("close");
			var oSelRole = this.byId("roleId").getSelectedItem().getProperty("text");
			var deptVal = that.byId("deptId").getSelectedKey();
			if (!that._qualValueDialog) {
				that._qualValueDialog = sap.ui.xmlfragment("com.empqualassignment.Employee_Qual_Assignment.fragment.Qualification", that.getView()
					.getController());
				that.getView().addDependent(that._qualValueDialog);
			}
			that._qualValueDialog.open();
			// that._qualValueDialog.setEscapeHandler(function (o) {
			// 	o.reject();
			// });
			//-----------------------------------------------------------------------	
			//Busy Indicator.
			//-----------------------------------------------------------------------
			var dialog = new sap.m.BusyDialog({});
			dialog.open();
			if (oSelRole === "Super PM Admin") {
				if (deptVal === "E" || deptVal === "SE" || deptVal === "Engineering" || deptVal === "SE") {
					union = "SE";
				} else if (deptVal === "M" || deptVal === "SM" || deptVal === "Mechanical" || deptVal === "SM") {
					union = "SM";
				} else if (deptVal === "T" || deptVal === "ST" || deptVal === "TCU" || deptVal === "ST") {
					union = "ST";
				} else if (deptVal === "A" || deptVal === "SA" || deptVal === "ATDA" || deptVal === "SD") {
					union = "SA";
				} else if (deptVal === "L" || deptVal === "SL" || deptVal === "ILA" || deptVal === "SL") {
					union = "SL";
				} else if (deptVal === "IHB" || deptVal === "CG") {
					union = "CG";
				}
			} else
			if (oSelRole === "Supervisor" || oSelRole === "CH" || oSelRole === "Chief Supervisor") {
				union = "CH";
			} else {
				if (deptVal === "E" || deptVal === "SE" || deptVal === "Engineering") {
					union = "E";
				} else if (deptVal === "M" || deptVal === "SM" || deptVal === "Mechanical") {
					union = "M";
				} else if (deptVal === "T" || deptVal === "ST" || deptVal === "TCU") {
					union = "T";
				} else if (deptVal === "A" || deptVal === "SA" || deptVal === "ATDA") {
					union = "A";
				} else if (deptVal === "L" || deptVal === "SL" || deptVal === "ILA") {
					union = "L";
				} else if (deptVal === "CG") {
					union = "CG";
				}
			}
			sFilters.push(new sap.ui.model.Filter("Craft", sap.ui.model.FilterOperator.EQ, union));
			var qualModel = that.getOwnerComponent().getModel();
			qualModel.setUseBatch(false);
			qualModel.read("/QualiSearchHelpSet", {
				filters: sFilters,
				success: function (oData, Response) {
					dialog.close();
					if (oData.results.length > 0) {
						var qualJsonModel1 = new sap.ui.model.json.JSONModel(oData);
						var qualTable1 = sap.ui.getCore().byId("qualMaintenanceTable1");
						qualTable1.setModel(qualJsonModel1, "oQualData");
					}
				},
				error: function (oResponse) {
					dialog.close();
					//-----------------------------------------------------------------------	
					// Displaying response body message.
					//-----------------------------------------------------------------------
					var oMessage = $(oResponse.response.body).find('message').first().text();
					var errmsg;
					if (oMessage === "") {
						errmsg = oResponse.response.body;
					} else {
						errmsg = oMessage;
					}
					var oCreateDialog = new sap.m.Dialog();
					oCreateDialog.setTitle(titleError);
					oCreateDialog.setIcon("sap-icon://message-error");
					oCreateDialog.addStyleClass(
						"dialogHdrBgCls dialogTitleCls dialogTextShadowCls dialogBoxShadowCls dialogIconCls dialogFooterBgCls");
					var oSimpleForm = new sap.ui.layout.form.SimpleForm({
						content: [
							new sap.m.Text({
								text: errmsg
							})
						]
					});
					oCreateDialog.addContent(oSimpleForm);

					oCreateDialog.addButton(
						new sap.m.Button({
							text: Close,
							press: function () {
								oCreateDialog.close();
							}
						}).addStyleClass("sapUiSizeCompact clsBtnColorYellowRed")
					);
					// oCreateDialog.open();
				}
			});
		},

		onQualTableFilter: function () {
			var aFilters = [];
			var sQuery = sap.ui.getCore().byId("qualSearch").getValue();

			aFilters = [
				new sap.ui.model.Filter([
					new sap.ui.model.Filter("Qualification", sap.ui.model.FilterOperator.Contains, sQuery),
					new sap.ui.model.Filter("QualDesc", sap.ui.model.FilterOperator.Contains, sQuery),
					new sap.ui.model.Filter("QualId", sap.ui.model.FilterOperator.Contains, sQuery)
				], false)
			];

			// update list binding
			var list = sap.ui.getCore().byId("qualMaintenanceTable1");
			var binding = list.getBinding("items");
			binding.filter(aFilters);
		},

		onQualSubmit: function (oEvent) {
			var that = this;
			var titleError = this.getView().getModel("i18n").getProperty("titleError");
			var Close = this.getView().getModel("i18n").getProperty("close");
			var selAtleastOneRecord = this.getView().getModel("i18n").getProperty("selAtleastOneRecord");
			//-----------------------------------------------------------------------	
			// Busy Indicator.
			//-----------------------------------------------------------------------
			var dialog = new sap.m.BusyDialog({

			});
			dialog.open();
			// var oRosterPath = oEvent.getSource().getBindingContextPath();
			// var oContext = oEvent.getSource().getParent().getModel("aModelData").getProperty(oEvent.getSource().getBindingContextPath());
			// var qualSContexts = sap.ui.getCore().byId("qualMaintenanceTable").getSelectedContexts();
			var qualSItems = oEvent.getSource().getModel("oQualData").getProperty(oEvent.getSource().getBindingContextPath()).Qualification;

			if (qualSItems.length === 0) {
				sap.m.MessageToast.show(selAtleastOneRecord);
				dialog.close();
			} else {
				dialog.close();

				var qualName = oEvent.getSource().getModel("oQualData").getProperty(oEvent.getSource().getBindingContextPath()).Qualification;
				var qualDesc = oEvent.getSource().getModel("oQualData").getProperty(oEvent.getSource().getBindingContextPath()).QualDesc;
				that.QualId = oEvent.getSource().getModel("oQualData").getProperty(oEvent.getSource().getBindingContextPath()).QualId;
				var qualEndDate = oEvent.getSource().getModel("oQualData").getProperty(oEvent.getSource().getBindingContextPath()).Enddate;
				if (qualEndDate !== "") {
					that.byId("qualEndDate").setValue(qualEndDate);
				}
				that.byId("qualQualsInput").setTokens([new sap.m.Token({
					text: qualName,
					key: qualName
				})]); //.setValue(qualName);
				// that.byId("qualQualsInput").setDescription(that.QualId);
				that.byId("qualQualsInputDesc").setText(that.QualId);
				if (qualDesc !== "") {
					// that.byId("qualQualsInput").setWidth("122%");
				}

				that.additionalInfoCheckArr = [];
				var check;
				var qualModel = that.getOwnerComponent().getModel();
				qualModel.read("/QualiSearchHelpSet(QualId='" + that.QualId + "')", {
					success: function (oData, Response) {
						if (oData.AddField1 !== "" || oData.AddField2 !== "" || oData.AddField3 !== "" || oData.AddField4 !== "" || oData.AddField5 !==
							"" ||
							oData.AddField6 !== "" || oData.AddField7 !== "" || oData.AddField8 !== "" || oData.AddField9 !== "" || oData.AddField10 !==
							"" ||
							oData.Documents !== "") {
							check = true;
							that.additionalInfoCheckArr.push(check);
						} else {
							check = false;
							that.additionalInfoCheckArr.push(check);
						}
					},
					error: function (oResponse) {

						//-----------------------------------------------------------------------	
						// Displaying response body message.
						//-----------------------------------------------------------------------

						var oMessage = $(oResponse.response.body).find('message').first().text();
						var errmsg;
						if (oMessage === "") {
							errmsg = oResponse.response.body;
						} else {
							errmsg = oMessage;
						}

						sap.m.MessageBox.information(errmsg, {
							icon: sap.m.MessageBox.Icon.INFORMATION,
							title: titleError,
							actions: ["OK"],
							onClose: function (oAction) {
								if (oAction === "OK") {

								}
							}
						});

						/*var oCreateDialog = new sap.m.Dialog();
						oCreateDialog.setTitle(titleError);
						oCreateDialog.setIcon("sap-icon://message-error");
						oCreateDialog.addStyleClass(
							"dialogHdrBgCls dialogTitleCls dialogTextShadowCls dialogBoxShadowCls dialogIconCls dialogFooterBgCls");
						var oSimpleForm = new sap.ui.layout.form.SimpleForm({
							content: [
								new sap.m.Text({
									text: errmsg
								})
							]
						});
						oCreateDialog.addContent(oSimpleForm);

						oCreateDialog.addButton(
							new sap.m.Button({
								text: close,
								press: function () {
									oCreateDialog.close();
								}
							}).addStyleClass("sapUiSizeCompact clsBtnColorYellowRed")
						);
						oCreateDialog.open();*/
					}
				});
				// that._qualValueDialog.close();
				// }
				sap.ui.getCore().byId("qualSearch").setValue("");
				that._qualValueDialog.close();
				that._qualValueDialog.destroy();
				that._qualValueDialog = null;
			}
			var startDate = that.byId("qualStDate").getValue();
			if (startDate) {
				// var that = this;	
				var effDateSplit = startDate.split("/");
				startDate = effDateSplit[2] + "" + effDateSplit[0] + "" + effDateSplit[1];
				var QualId = this.byId("qualQualsInputDesc").getText();
				var oModel1 = that.getOwnerComponent().getModel("oDataSrv");
				oModel1.read("/QualiSearchHelpSet?$filter=QualId eq '" + QualId + "' and Begindate eq '" + startDate + "'", {
					async: true,
					success: function (oData1) {
						if (oData1.results[0].Enddate !== "") {
							that.byId("qualEndDate").setValue(oData1.results[0].Enddate);
						}
					}
				});
			}

		},

		onQualCancel: function () {
			var that = this;
			sap.ui.getCore().byId("qualSearch").setValue("");
			that._qualValueDialog.close();
			that._qualValueDialog.destroy();
			that._qualValueDialog = null;
		},

		empNoValueHelpReq: function () {

			var that = this;

			if (!that._pernrValueDialog) {
				that._pernrValueDialog = sap.ui.xmlfragment("com.empqualassignment.Employee_Qual_Assignment.fragment.Pernr", that.getView()
					.getController());
				that.getView().addDependent(that._pernrValueDialog);
			}
			that._pernrValueDialog.open();

			that._pernrValueDialog.setEscapeHandler(function (o) {
				o.reject();
			});

			sap.ui.getCore().byId("pernrSearch").setValue("");
			var model = new JSONModel({
				results: []
			});
			sap.ui.getCore().byId("pernrTable").setModel(model, "oPernrData");

		},

		onPernrSearch: function () {

			var that = this;

			var titleInfo = this.getView().getModel("i18n").getProperty("titleInfo");
			var ok = this.getView().getModel("i18n").getProperty("ok");

			var pernr = sap.ui.getCore().byId("pernrSearch").getValue();
			var effDate = that.byId("empDataEffDate").getValue();

			var EffDate = effDate.split("/");
			var effectiveDate = EffDate[2] + "" + EffDate[0] + "" + EffDate[1];

			//-----------------------------------------------------------------------	
			//Busy Indicator.
			//-----------------------------------------------------------------------

			var dialog = new sap.m.BusyDialog({

			});

			dialog.open();

			var deptVal = that.byId("deptId").getSelectedKey();
			var oSelRole = that.byId("roleId").getSelectedItem().getProperty("text");
			var union;

			if (oSelRole === "Super PM Admin") {
				if (deptVal === "E" || deptVal === "SE" || deptVal === "Engineering") {
					union = "SE";
				} else if (deptVal === "M" || deptVal === "SM" || deptVal === "Mechanical") {
					union = "SM";
				} else if (deptVal === "T" || deptVal === "ST" || deptVal === "TCU") {
					union = "ST";
				} else if (deptVal === "A" || deptVal === "SA" || deptVal === "ATDA") {
					union = "SA";
				} else if (deptVal === "L" || deptVal === "SL" || deptVal === "ILA") {
					union = "SL";
				} else if (deptVal === "IHB") {
					union = "CG";
				}
			} else if (oSelRole === "Supervisor") {
				union = "CH";
			} else {
				if (deptVal === "E" || deptVal === "SE") {
					union = "E";
				} else if (deptVal === "M" || deptVal === "SM") {
					union = "M";
				} else if (deptVal === "T" || deptVal === "ST") {
					union = "T";
				} else if (deptVal === "A" || deptVal === "SA") {
					union = "A";
				} else if (deptVal === "L" || deptVal === "SL") {
					union = "L";
				} else if (deptVal === "CG") {
					union = "CG";
				}
			}
			var queryFil = [];
			var empNo = new sap.ui.model.Filter("Pernr", "EQ", pernr);
			var EffectiveDate = new sap.ui.model.Filter("EffDate", "EQ", effectiveDate);
			var key = new sap.ui.model.Filter("Key", "EQ", "S");
			var craftType = new sap.ui.model.Filter("CraftType", "EQ", union);
			queryFil.push(empNo);
			queryFil.push(EffectiveDate);
			queryFil.push(key);
			queryFil.push(craftType);

			var oModel = that.getOwnerComponent().getModel();
			oModel.read("/EmpQualificationSet", {
				filters: queryFil,
				success: function (oData) {

					dialog.close();

					that.byId("empDataEmpNoInp").setValueState("None");

					// if (oData.results.length > 0) {
					var pernrJsonModel = new sap.ui.model.json.JSONModel(oData);
					var pernrTable = sap.ui.getCore().byId("pernrTable");
					pernrTable.setModel(pernrJsonModel, "oPernrData");
					// }

				},
				error: function (oResponse) {

					dialog.close();

					//-----------------------------------------------------------------------	
					// Displaying response body message.
					//-----------------------------------------------------------------------

					var oMessage = $(oResponse.response.body).find('message').first().text();
					var errmsg;
					if (oMessage === "") {
						errmsg = oResponse.response.body;
					} else {
						errmsg = oMessage;
					}

					sap.m.MessageBox.information(errmsg, {
						icon: sap.m.MessageBox.Icon.INFORMATION,
						title: titleInfo,
						actions: ["OK"],
						onClose: function (oAction) {
							if (oAction === "OK") {

								that._pernrValueDialog.close();
								var pernrVal = sap.ui.getCore().byId("pernrSearch").getValue();
								that.byId("empDataEmpNoInp").setTokens([new sap.m.Token({
									text: pernrVal,
									key: pernrVal
								})]);
								that.byId("empDataEmpNoInp").setValueState("Error");
								// that.byId("empDataEmpNoInp").setWidth("60%");
								// that.byId("empDataEmpNoInp").setDescription("");
								that.byId("empDataEmpNoInpDesc").setText("");

							}
						}
					});

					/*var oCreateDialog = new sap.m.Dialog();
					oCreateDialog.setTitle(titleInfo);
					oCreateDialog.setIcon("sap-icon://message-information");
					oCreateDialog.addStyleClass(
						"dialogHdrBgCls dialogTitleCls dialogTextShadowCls dialogBoxShadowCls dialogIconCls dialogFooterBgCls");
					var oSimpleForm = new sap.ui.layout.form.SimpleForm({
						content: [
							new sap.m.Text({
								text: errmsg
							})
						]
					});
					oCreateDialog.addContent(oSimpleForm);
					oCreateDialog.addButton(
						new sap.m.Button({
							text: ok,
							press: function () {

								that._pernrValueDialog.close();
								var pernrVal = sap.ui.getCore().byId("pernrSearch").getValue();
								that.byId("empDataEmpNoInp").setTokens([new sap.m.Token({
									text: pernrVal,
									key: pernrVal
								})]);
								that.byId("empDataEmpNoInp").setValueState("Error");
								that.byId("empDataEmpNoInp").setWidth("60%");
								that.byId("empDataEmpNoInp").setDescription("");

								oCreateDialog.close();
							}
						}).addStyleClass("sapUiSizeCompact clsBtnColorYellowRed")
					);
					oCreateDialog.open();*/

				}
			});

		},

		onPernrLiveChange: function () {
			var that = this;
			//	var pernr = that.byId("empDataEmpNoInp").getValue();
			// if (pernr === "") {
			// that.byId("empDataEmpNoInp").setDescription();
			that.byId("empDataEmpNoInpDesc").setText("");
			// that.byId("empDataEmpNoInp").setWidth("50%");

			// that.byId("empDataEmpNoInp").setDescription("");
			that.byId("empDataEmpNoInpDesc").setText("");
			// that.byId("empDataEmpNoInp").setWidth("60%");
			that.byId("empDataPosInp").setValue("");
			that.byId("empDataPosInp").setDescription("");
			that.byId("empDataPosInp").setWidth("60%");
			that.byId("empDataUnionInp").setValue("");
			that.byId("empDataAgrInp").setValue("");
			that.byId("empDataAgrInp").setWidth("60%");
			that.byId("empDataUnionInp").setWidth("60%");
			that.byId("empDataEffDate").setValue(currentDate);
			that.byId("qualCraftTypeCombo").setValue("");
			that.byId("qualStDate").setValue("");
			that.byId("qualStDate").setValueState("None");
			that.byId("qualStDate").setEnabled(false);
			that.byId("qualQualsInput").removeAllTokens();
			that.byId("qualQualsInput").setValueState("None");
			// that.byId("qualQualsInput").setDescription("");
			that.byId("qualQualsInputDesc").setText("");
			// that.byId("qualQualsInput").setWidth("61%");
			that.byId("qualQualsInput").setEnabled(false);
			that.byId("qualEndDate").setValue("");
			that.byId("qualEndDate").setWidth("61%");
			that.byId("qualEndDate").setEnabled(false);
			that.byId("qualEndDate").setValueState("None");
			that.byId("qualproficiency").setEnabled(false);
			// that.byId("qualproficiency").setSelectedKey("");

			var oAdditionalForm = sap.ui.getCore().byId("additionalInfoForm");
			if (oAdditionalForm !== undefined) {
				oAdditionalForm.destroyContent();
			}
			that.employeeIDN = "";
			that.empName = "";
			that.empStatus = "";
			// -------Clear table data------- 

			var itemsArray = [];
			var qualCModel = new sap.ui.model.json.JSONModel({
				"results": itemsArray
			});

			var itemsTable = that.byId("qualTable");
			itemsTable.setModel(qualCModel, "oModelData");

			that.byId("saveBtn").setEnabled(false);
			// that.byId("additionalInfoBtn").setEnabled(false);
			that.byId("addBtn").setEnabled(false);

			//that.emptyDataFun();
			// }

		},

		empNoChange: function () {

			var that = this;

			var enterEmpNum = this.getView().getModel("i18n").getProperty("enterEmpNum");

			var pernr = that.byId("empDataEmpNoInp").getTokens()[0].getKey();
			var effDate = that.byId("empDataEffDate").getValue();

			var EffDate = effDate.split("/");
			var effectiveDate = EffDate[2] + "" + EffDate[0] + "" + EffDate[1];

			if (pernr === "") {
				sap.m.MessageToast.show(enterEmpNum);
				that.byId("empDataEmpNoInp").setValueState("Error");
			} else {
				that.byId("empDataEmpNoInp").setValueState("None");
				//clear data before making new call 
				that.getView().byId("qualTable").getModel("oModelData").setData([]); //++D5OW5 -- Dt 02/06/2022
				// new service call
				that.qualDataFun(pernr, effectiveDate, "D");
			}

		},

		onEmpNoEnter: function () {

			var that = this;
			that.defaultDate();

			var enterEmpNum = this.getView().getModel("i18n").getProperty("enterEmpNum");

			var pernr = that.byId("empDataEmpNoInp").getTokens()[0].getKey();
			var effDate = that.byId("empDataEffDate").getValue();
			that.employeeIDN = pernr;
			var EffDate = effDate.split("/");
			var effectiveDate = EffDate[2] + "" + EffDate[0] + "" + EffDate[1];

			var roleGetSelectedKey = that.byId("roleId").getSelectedKey();
			var selectedTab = that.byId("IconTabbarId").getSelectedKey();

			if (pernr === "") {
				sap.m.MessageToast.show(enterEmpNum);
				that.byId("empDataEmpNoInp").setValueState("Error");
			} else {

				// that.confirm = true;
				that.byId("empDataEmpNoInp").setValueState("None");
				that.qualDataFun(pernr, effectiveDate, "D");

			}

		},

		onPernrSubmit: function (oEvent) {

			var that = this;

			var selAtleastOneRecord = this.getView().getModel("i18n").getProperty("selAtleastOneRecord");

			//-----------------------------------------------------------------------	
			// Busy Indicator.
			//----------------------------------------------------------------------- 
			var dialog = new sap.m.BusyDialog({});
			dialog.open();
			// var pernrSContexts = sap.ui.getCore().byId("pernrTable").getSelectedContexts();
			var pernrSItems = oEvent.getSource().getModel("oPernrData").getProperty(oEvent.getSource().getBindingContextPath()).Pernr;
			if (pernrSItems.length === 0) {
				sap.m.MessageToast.show(selAtleastOneRecord);
				dialog.close();
			} else {
				dialog.close();
				that.confirm = true;
				var pernr = oEvent.getSource().getModel("oPernrData").getProperty(oEvent.getSource().getBindingContextPath()).Pernr;
				var name = oEvent.getSource().getModel("oPernrData").getProperty(oEvent.getSource().getBindingContextPath()).PernrDesc;
				var effDate = that.byId("empDataEffDate").getValue();
				that.byId("empDataEmpNoInpDesc").setText(pernrSItems[0].PernrDesc);
				that.employeeIDN = pernr;
				that.empName = name;
				that.empStatus = "Active";
				var EffDate = effDate.split("/");
				var effectiveDate = EffDate[2] + "" + EffDate[0] + "" + EffDate[1];

				that.qualDataFun(pernr, effectiveDate, "D");

				that._pernrValueDialog.close();

			}

		},

		onPernrCancel: function () {
			var that = this;
			that._pernrValueDialog.close();
		},

		onInlineDelete: function (oEvent) {

			var that = this;

			var index = parseInt(oEvent.getSource().getId().split("qualTable-")[1]);
			var tableId = that.byId("qualTable").getId();

			if (that.byId("cellRowKeyTxt-" + tableId + "-" + index).getText() === "F") {
				var oModelres = this.byId("qualTable").getModel("oModelData").getData().results;
				var path = oEvent.getSource().getParent().getParent().getBindingContextPath().split("/")[2];
				oModelres.splice(path, "1");
				this.byId("qualTable").getModel("oModelData").refresh();
				this.byId("qualTable").removeSelections(true);

				var data = that.byId("qualTable").getItems();
				if (data.length === 0) {
					that.byId("saveBtn").setEnabled(false);
				} else {
					that.byId("saveBtn").setEnabled(true);
				}
			} else if (that.byId("cellRowKeyTxt-" + tableId + "-" + index).getText() === "B") {
				var valueString = oEvent.getSource().getBindingContext("oModelData").sPath;
				this.getView().byId("qualTable").getModel("oModelData").setProperty(valueString + "/Key", "D");
			}

		},

		onSave: function () {

			var that = this;

			var titleSuccess = this.getView().getModel("i18n").getProperty("titleSuccess");
			var titleInfo = this.getView().getModel("i18n").getProperty("titleInfo");
			var ok = this.getView().getModel("i18n").getProperty("ok");

			var selectedTab = that.byId("IconTabbarId").getSelectedKey();
			if (selectedTab === "empQualAssign") {

				var itemData = [];
				var itemObj = {};
				itemObj.Key = "I";
				itemData.push(itemObj);

				var sDate = that.byId("qualStDate").getValue();
				var startDate;
				if (sDate !== "") {
					if (sDate.includes("/")) {
						var oSDate = sDate.split("/");
						startDate = oSDate[2] + "" + oSDate[0] + "" + oSDate[1];
					} else {
						startDate = sDate;
					}
				} else {
					startDate = "";
				}
				var eDate = that.byId("qualEndDate").getValue();
				var endDate;
				if (eDate !== "") {
					if (eDate.includes("/")) {
						var oEDate = eDate.split("/");
						endDate = oEDate[2] + "" + oEDate[0] + "" + oEDate[1];
					} else {
						endDate = eDate;
					}
				} else {
					endDate = "";
				}

				var qualDesc = that.byId("qualQualsInput").getTokens()[0].getKey();
				if (qualDesc === undefined || qualDesc === "") {
					qualDesc = " ";
				} else {
					qualDesc = qualDesc;
				}

				var oEntry = {};
				oEntry.Qualification = that.QualId;
				oEntry.Pernr = that.byId("empDataEmpNoInp").getTokens()[0].getKey();
				for (var i = 0; i < itemData.length; i++) {
					itemData[i].QualGroup = that.craftType;
					itemData[i].QualDesc = qualDesc;
					itemData[i].Pscale = that.byId("qualproficiency").getSelectedKey();
					itemData[i].Begda = startDate;
					itemData[i].Endda = endDate;
				}

				if (itemData.length === 0) {
					var vItemData = {};
					vItemData.QualGroup = that.craftType;
					vItemData.QualDesc = qualDesc;
					vItemData.Pscale = that.byId("qualproficiency").getSelectedKey();
					vItemData.Begda = startDate;
					vItemData.Qualification = that.QualId;
					vItemData.Pernr = that.byId("empDataEmpNoInp").getTokens()[0].getKey();
					vItemData.Endda = endDate;
					itemData.push(vItemData);
				}
				oEntry.CreateQualificationSet = itemData;
				var oModel = that.getOwnerComponent().getModel();
				oModel.create("/QualHeaderSet", oEntry, {
					success: function (oData, oResponse) {

						sap.m.MessageBox.information("Created Successfully", {
							icon: sap.m.MessageBox.Icon.INFORMATION,
							title: titleInfo,
							actions: ["OK"],
							onClose: function (oAction) {
								if (oAction === "OK") {

								}
							}
						});

						/*var oCreateDialog = new sap.m.Dialog();
						oCreateDialog.setTitle(titleSuccess);
						oCreateDialog.setIcon("sap-icon://message-success");
						oCreateDialog.addStyleClass(
							"dialogHdrBgCls dialogTitleCls dialogTextShadowCls dialogBoxShadowCls dialogIconCls dialogFooterBgCls");
						var oSimpleForm = new sap.ui.layout.form.SimpleForm({
							content: [
								new sap.m.Text({
									text: "Created Successfully"
								})
							]
						});
						oCreateDialog.addContent(oSimpleForm);

						oCreateDialog.addButton(
							new sap.m.Button({
								text: ok,
								press: function () {
									oCreateDialog.close();
								}
							}).addStyleClass("sapUiSizeCompact clsBtnColorYellowRed")
						);
						oCreateDialog.open();*/

					},
					error: function (oResponse) {

						//-----------------------------------------------------------------------	
						// Displaying response header message.
						//-----------------------------------------------------------------------

						var oMessage = JSON.parse(oResponse.responseText).error.innererror.errordetails[0].message;

						sap.m.MessageBox.information(oMessage, {
							icon: sap.m.MessageBox.Icon.INFORMATION,
							title: titleInfo,
							actions: ["OK"],
							onClose: function (oAction) {
								if (oAction === "OK") {

									that.confirm = false;
									that.qualChangeFlag = false;

									that.byId("empDataPosInp").setValue("");
									that.byId("empDataPosInp").setDescription("");
									that.byId("empDataPosInp").setWidth("75%");
									that.byId("empDataUnionInp").setValue("");
									that.byId("empDataAgrInp").setValue("");
									that.byId("empDataEffDate").setValue(currentDate);
									that.byId("qualCraftTypeCombo").setValue("");
									// that.byId("qualStDate").setValue("");
									that.byId("qualQualsInput").setValue("");
									// that.byId("qualQualsInput").setDescription();
									that.byId("qualQualsInputDesc").setText("");
									// that.byId("qualEndDate").setValue("");
									that.defaultDate();

									// -------Clear table data------- 

									var itemsArray = [];

									var qualCModel = new sap.ui.model.json.JSONModel({
										"results": itemsArray
									});

									var itemsTable = that.byId("qualTable");
									itemsTable.setModel(qualCModel, "oModelData");

									var pernr = that.byId("empDataEmpNoInp").getTokens()[0].getKey();
									var effDate = that.byId("empDataEffDate").getValue();

									var EffDate = effDate.split("/");
									var effectiveDate = EffDate[2] + "" + EffDate[0] + "" + EffDate[1];

									that.byId("empDataEffDate").setValueState("None");
									that.qualDataFun(pernr, effectiveDate, "D");
									that.byId("saveBtn").setEnabled(false);

								}
							}
						});

						/*var oCreateDialog = new sap.m.Dialog();
						oCreateDialog.setTitle(titleInfo);
						oCreateDialog.setIcon("sap-icon://message-information");
						oCreateDialog.addStyleClass(
							"dialogHdrBgCls dialogTitleCls dialogTextShadowCls dialogBoxShadowCls dialogIconCls dialogFooterBgCls");
						var oSimpleForm = new sap.ui.layout.form.SimpleForm({
							content: [
								new sap.m.Text({
									text: oMessage
								})
							]
						});
						oCreateDialog.addContent(oSimpleForm);
						oCreateDialog.addButton(
							new sap.m.Button({
								text: ok,
								press: function () {

									that.confirm = false;
									that.qualChangeFlag = false;

									that.byId("empDataPosInp").setValue("");
									that.byId("empDataPosInp").setDescription("");
									that.byId("empDataPosInp").setWidth("75%");
									that.byId("empDataUnionInp").setValue("");
									that.byId("empDataAgrInp").setValue("");
									that.byId("empDataEffDate").setValue(currentDate);
									that.byId("qualCraftTypeCombo").setValue("");
									// that.byId("qualStDate").setValue("");
									that.byId("qualQualsInput").removeAllTokens();
									that.byId("qualQualsInput").setDescription();
									// that.byId("qualEndDate").setValue("");
									that.defaultDate();

									// -------Clear table data------- 

									var itemsArray = [];

									var qualCModel = new sap.ui.model.json.JSONModel({
										"results": itemsArray
									});

									var itemsTable = that.byId("qualTable");
									itemsTable.setModel(qualCModel, "oModelData");

									var pernr = that.byId("empDataEmpNoInp").getTokens()[0].getKey();
									var effDate = that.byId("empDataEffDate").getValue();

									var EffDate = effDate.split("/");
									var effectiveDate = EffDate[2] + "" + EffDate[0] + "" + EffDate[1];

									that.byId("empDataEffDate").setValueState("None");
									that.qualDataFun(pernr, effectiveDate, "D");
									that.byId("saveBtn").setEnabled(false);

									oCreateDialog.close();
								}
							}).addStyleClass("sapUiSizeCompact clsBtnColorYellowRed")
						);
						oCreateDialog.open();*/

					}
				});

			} else if (selectedTab === "empSenMaint") {
				that.onEmpDataSaveFunc();
			} else if (selectedTab === "empHomeZone") {
				that.onEmpHomeZoneAdditionalSenInfoSaveFunc();
			} else if (selectedTab === "additionalSenInfo") {
				that.onEmpHomeZoneAdditionalSenInfoSaveFunc();
			}
		},

		onEmpDataSaveFunc: function () {
			var that = this;
			var titleInfo = this.getView().getModel("i18n").getProperty("titleInfo");
			var ok = this.getView().getModel("i18n").getProperty("ok");
			var oModel = that.getOwnerComponent().getModel();
			// var empVal = that.byId("empSenMaintenanceSearch").getTokens()[0].getKey();
			var empVal = "";
			if (that.byId("empSenMaintenanceSearch").getTokens().length > 0) {
				empVal = that.byId("empSenMaintenanceSearch").getTokens()[0].getKey();
			}
			var union;
			if (that.craftUnion === "Engineering") {
				union = "E";
			} else if (that.craftUnion === "Mechanical") {
				union = "M";
			} else if (that.craftUnion === "TCU") {
				union = "T";
			} else if (that.craftUnion === "ATDA") {
				union = "A";
			} else if (that.craftUnion === "ILA") {
				union = "L";
			} else if (that.craftUnion === "Conrail") {
				union = "C";
			} else if (that.craftUnion === "IHB") {
				union = "I";
			} else if (that.craftUnion === "NAHR") {
				union = "N";
			} else if (that.craftUnion === "Payroll") {
				union = "P";
			}

			var oItems = that.byId("empSenMaintTable").getModel("empSenMaintModel").getData().results;
			// var userRequestBody1 = {
			// 	"EmpNo": empVal,
			// 	"Operation": "P", 
			// 	"Craft": union
			// };

			// var items = [];

			// for (var i = 0; i < oItems.length; i++) {
			// 	var oItemContext = oItems[i];
			// 	// oItemContext[i].EmpNo = empVal;
			// 	var oSenDate = oItemContext.SenDate;
			// 	var senDate;
			// 	if (oSenDate.includes("/") === true) {
			// 		senDate = oSenDate.split("/")[2] + oSenDate.split("/")[0] + oSenDate.split("/")[1];
			// 	} else {
			// 		senDate = oSenDate;
			// 	}
			// 	// delete oItemContext[i].Region;
			// 	delete oItemContext.__metadata;
			// oItemContext[i].SenDate = senDate;
			// delete oItemContext[i].District;
			// delete oItemContext[i].SenDate;
			// delete oItemContext[i].Division;
			// // delete oItemContext[i].EmpNo;
			// delete oItemContext[i].RRCode;
			// delete oItemContext[i].RostDesc;
			// // delete oItemContext[i].RostNo;
			// delete oItemContext[i].SenDate;
			// delete oItemContext[i].UnionCode;
			// delete oItemContext[i].Action;
			// delete oItemContext[i].City;
			// delete oItemContext[i].Craft;
			// delete oItemContext[i].DPGZone;
			// delete oItemContext[i].DRostNo;
			// delete oItemContext[i].Department;
			// delete oItemContext[i].EndDate;
			// delete oItemContext[i].EngPopup;
			// delete oItemContext[i].FrozenDate;
			// delete oItemContext[i].Location;
			// delete oItemContext[i].OverrideDate;
			// delete oItemContext[i].OverrideSeq;
			// delete oItemContext[i].Rank;
			// delete oItemContext[i].Remarks;
			// delete oItemContext[i].SuspEdate;
			// delete oItemContext[i].SuspSdate;
			// delete oItemContext[i].Territory;
			// 	var dataItems = {
			// 		Action: oItemContext.Action,
			// 		EmpNo: empVal,
			// 		City: oItemContext.City,
			// 		Craft: oItemContext.Craft,
			// 		DPGZone: oItemContext.DPGZone,
			// 		DRostNo: oItemContext.DRostNo,
			// 		District: oItemContext.District,
			// 		Division: oItemContext.Division,
			// 		FrozenDate: oItemContext.FrozenDate,
			// 		OverrideDate: oItemContext.OverrideDate,
			// 		OverrideSeq: oItemContext.OverrideSeq,
			// 		RRCode: oItemContext.RRCode,
			// 		Region: oItemContext.Region,
			// 		Remarks: oItemContext.Remarks,
			// 		RostDesc: oItemContext.RostDesc,
			// 		RostNo: oItemContext.RostNo,
			// 		SenDate: senDate,
			// 		Territory: oItemContext.Territory,
			// 		UnionCode: oItemContext.UnionCode
			// 	};
			// 	items.push(dataItems);

			// }

			// var item1 = [{
			// 	Action: "A",
			// 	City: "",
			// 	EmpNo: empVal,
			// 	Craft: "",
			// 	DPGZone: "",
			// 	DRostNo: "",
			// 	District: "Cleveland",
			// 	Division: "No Division",
			// 	FrozenDate: "",
			// 	OverrideDate: "",
			// 	OverrideSeq: "",
			// 	RRCode: "NKP",
			// 	Region: "Eastern",
			// 	Remarks: "",
			// 	RostDesc: "SYSTEM RAIL GANG FOREMEN",
			// 	RostNo: "N08100",
			// 	SenDate: "20200515",
			// 	Territory: "",
			// 	UnionCode: "BMWE"
			// }];
			var data = {
				Craft: union,
				EmpNo: empVal,
				Operation: "P",
				EmpSen: oItems
			};
			// var oResults1 = {
			// 	"results": item1
			// };
			//userRequestBody1.EmpSen = that.sFinalArray[0];
			that.byId("empQualAssignmentPage").setBusy(true);
			that.byId("empQualAssignmentPage").setBusyIndicatorDelay(0);
			oModel.create("/EmpSenHDataSet", data, {
				async: true,
				success: function (oData, oResponse) {
					that.byId("empQualAssignmentPage").setBusy(false);
				},
				error: function (err, oResponse) {
					// var data2 = oResponse;
					that.byId("empQualAssignmentPage").setBusy(false);
					var errMsg = JSON.parse(err.responseText).error.message.value;
					sap.m.MessageBox.information(errMsg, {
						icon: sap.m.MessageBox.Icon.INFORMATION,
						title: titleInfo,
						actions: ["OK"],
						onClose: function (oAction) {
							if (oAction === "OK") {
								// that.onReset();
								// that.sFinalArray = [];
								that.onEmpSenGetFunc(empVal);
								var oTable = that.byId("empSenMaintTable");
								var oTableItems = oTable.getItems();
								for (var k = 0; k < oTableItems.length; k++) {
									oTableItems[k].getAggregation("cells")[2].getItems()[1].setEnabled(false);
									oTableItems[k].getAggregation("cells")[2].getItems()[3].setEnabled(false);
									oTableItems[k].getAggregation("cells")[3].getItems()[1].setEnabled(false);
									oTableItems[k].getAggregation("cells")[3].getItems()[3].setEnabled(false);
									oTableItems[k].getAggregation("cells")[4].setEnabled(false);
									oTableItems[k].getAggregation("cells")[13].getItems()[1].setEnabled(false);
									oTableItems[k].getAggregation("cells")[13].getItems()[3].setEnabled(false);
								}
								that.byId("editBtn").setVisible(true);
								that.byId("saveBtn").setVisible(false).setEnabled(true);
								that.byId("rosterNoInp").setEnabled(false);
								that.byId("empRemarksId").setEnabled(false);
								that.byId("rosterSenDateId").setEnabled(false);
								that.byId("rosterOverrideSenDateId").setEnabled(false);
								that.byId("rosterFrozenSenDateId").setEnabled(false);
								that.byId("empSenCraftInp").setEnabled(false);
								that.byId("empSenDivisionInp").setEnabled(false);
								that.byId("empSenRrCodeInp").setEnabled(false);
								that.byId("empSenDistrictInp").setEnabled(false);
								that.byId("empSenDpgZoneInp").setEnabled(false);
								that.byId("rosterOverrideNo").setEnabled(false);
								//that.byId("editBtn").setVisible(false);
								//that.byId("saveBtn").setVisible(false);
								that.byId("empSenMaintAdd").setEnabled(false);
							}
						}
					});
					/*var oCreateDialog = new sap.m.Dialog();
					oCreateDialog.setTitle(titleInfo);
					oCreateDialog.setIcon("sap-icon://message-information");
					oCreateDialog.addStyleClass(
						"dialogHdrBgCls dialogTitleCls dialogTextShadowCls dialogBoxShadowCls dialogIconCls dialogFooterBgCls");
					var oSimpleForm = new sap.ui.layout.form.SimpleForm({
						content: [
							new sap.m.Text({
								text: errMsg
							})
						]
					});
					oCreateDialog.addContent(oSimpleForm);
					oCreateDialog.addButton(
						new sap.m.Button({
							text: ok,
							press: function () {
								that.onReset();
								that.sFinalArray = [];
								oCreateDialog.close();
							}
						}).addStyleClass("sapUiSizeCompact clsBtnColorYellowRed")
					);
					oCreateDialog.open();*/
				}
			});
		},
		onMaxLen: function (oEvt) {
			if (Number(oEvt.getSource().getValue())) {
				return;
			} else {
				oEvt.getSource().setValue("");
				sap.m.MessageToast.show("Group will be Number");
			}
		},
		onInlineHomeZoneEDateChange: function (oEvent) {
			var valueString = oEvent.getSource().getBindingContext("empHomeZoneModel").sPath;
			this.getView().byId("empHomeZoneTable").getModel("empHomeZoneModel").setProperty(valueString + "/Action", "C");
			this.byId("saveBtn").setEnabled(true);
		},
		onInlineAdditionalSenInfoEDateChange: function (oEvent) {
			var valueString = oEvent.getSource().getBindingContext("empAdditionalSenInfoModel").sPath;
			this.getView().byId("empAdditionalSenInfoTable").getModel("empAdditionalSenInfoModel").setProperty(valueString + "/Action", "C");
			this.byId("saveBtn").setEnabled(true);
		},
		onEmpHomeZoneAdditionalSenInfoSaveFunc: function () {
			var that = this;
			var itemObj = {};
			var itemData = [];
			var titleSuccess = this.getView().getModel("i18n").getProperty("titleSuccess");
			var titleInfo = this.getView().getModel("i18n").getProperty("titleInfo");
			var ok = this.getView().getModel("i18n").getProperty("ok");
			var selectedTab = that.byId("IconTabbarId").getSelectedKey();
			var empId;
			var operation;
			var oItems;
			if (selectedTab === "empHomeZone") {
				empId = that.byId("empHomeZoneSearch").getTokens()[0].getKey();
				operation = "H";
				oItems = that.byId("empHomeZoneTable").getItems();

				// if (that.byId("empHomeZoneDropDown").getValue() === "") {
				// 	sap.m.MessageToast.show("Home Zone can't be empty");
				// 	return;
				// }
				if (that.byId("empDataEffDateHZ").getValue() === "") {
					sap.m.MessageToast.show("RR Hired can't be empty");
					return;
				}
				if (that.byId("empRrHiredDropDown").getSelectedKey() === "") {
					sap.m.MessageToast.show("Effective date can't be empty");
					return;
				}

				// if (oItems[i].getAggregation("cells")[4].getText() === "F" || oItems[i].getAggregation("cells")[5].getText() === "C") {

				var eDate = that.byId("empDataEffDateHZ").getValue();
				var oEndDate;
				if (eDate !== "") {
					if (eDate.includes("/")) {
						var oEDate = eDate.split("/");
						oEndDate = oEDate[2] + "" + oEDate[0] + "" + oEDate[1];
					} else {
						oEndDate = eDate;
					}
				} else {
					oEndDate = "";
				}

				itemObj.EmpNo = empId;
				itemObj.HomeZone = that.byId("empHomeZoneDropDown").getSelectedKey();
				itemObj.RRHired = that.byId("empRrHiredDropDown").getSelectedKey();
				itemObj.EndDate = "";
				itemObj.RRCode = "";
				// itemObj.Division = "";            //--D5OW5 - Dt 03/03/2022
				itemObj.Division = that.byId("divDropDownHZ").getSelectedKey(); //++D5OW5 - Dt 03/03/2022
				itemObj.Group = "";
				// itemObj.District = "";            //--D5OW5 - Dt 03/03/2022
				itemObj.District = that.byId("districtDropDownHZ").getSelectedKey(); //++D5OW5 - Dt 03/03/2022				
				itemObj.PRRegion = that.byId("PriorRights").getValue(); //++D5OW5 - Dt 03/03/2022				
				itemObj.Classification = that.byId("Classification").getValue(); //++D5OW5 - Dt 03/03/2022				
				itemObj.RMD_Date = "";
				itemObj.AsstFDate = "";
				itemObj.FDate = "";
				itemObj.TCDate = "";
				itemObj.BeginDate = oEndDate;
				// if (oItems[i].getAggregation("cells")[4].getText() === "F") {
				// 	itemObj.Key = "I";
				// } else if (oItems[i].getAggregation("cells")[4].getText() === "B") {
				// 	itemObj.Key = "E";
				// }
				itemData.push(itemObj);

			} else if (selectedTab === "additionalSenInfo") {
				empId = that.byId("empAdditionalSenInfoSearch").getTokens()[0].getKey();
				operation = "A";
				oItems = that.byId("empAdditionalSenInfoTable").getItems();
			}

			var oEntry = {};
			oEntry.EmpNo = empId;
			oEntry.Operation = operation;
			for (var i = 0; i < oItems.length; i++) {
				itemObj = {};
				// if (selectedTab === "empHomeZone") {
				// 	if (oItems[i].getAggregation("cells")[4].getText() === "F" || oItems[i].getAggregation("cells")[5].getText() === "C") {

				// 		var eDate = oItems[i].getAggregation("cells")[2].getValue();
				// 		var oEndDate;
				// 		if (eDate !== "") {
				// 			if (eDate.includes("/")) {
				// 				var oEDate = eDate.split("/");
				// 				oEndDate = oEDate[2] + "" + oEDate[0] + "" + oEDate[1];
				// 			} else {
				// 				oEndDate = eDate;
				// 			}
				// 		} else {
				// 			oEndDate = "";
				// 		}

				// 		itemObj.EmpNo = empId;
				// 		itemObj.HomeZone = oItems[i].getAggregation("cells")[0].getText();
				// 		itemObj.RRHired = oItems[i].getAggregation("cells")[1].getText();
				// 		itemObj.EndDate = oEndDate;
				// 		itemObj.RRCode = "";
				// 		itemObj.Division = "";
				// 		itemObj.Group = "";
				// 		itemObj.District = "";
				// 		itemObj.RMD_Date = "";
				// 		itemObj.AsstFDate = "";
				// 		itemObj.FDate = "";
				// 		itemObj.TCDate = "";
				// 		itemObj.BeginDate = "";
				// 		if (oItems[i].getAggregation("cells")[4].getText() === "F") {
				// 			itemObj.Key = "I";
				// 		} else if (oItems[i].getAggregation("cells")[4].getText() === "B") {
				// 			itemObj.Key = "E";
				// 		}
				// 		itemData.push(itemObj);
				// 	}

				// } else
				if (selectedTab === "additionalSenInfo") {
					if (oItems[i].getAggregation("cells")[10].getText() === "F" || oItems[i].getAggregation("cells")[11].getText() === "C") {

						var rmDate = oItems[i].getAggregation("cells")[4].getText();
						var oRmDate;
						if (rmDate !== "") {
							if (rmDate.includes("/")) {
								var oRm_Date = rmDate.split("/");
								oRmDate = oRm_Date[2] + "" + oRm_Date[0] + "" + oRm_Date[1];
							} else {
								oRmDate = rmDate;
							}
						} else {
							oRmDate = "";
						}

						var asstFDate = oItems[i].getAggregation("cells")[5].getText();
						var oAFMDate;
						if (asstFDate !== "") {
							if (asstFDate.includes("/")) {
								var asstF_Date = asstFDate.split("/");
								oAFMDate = asstF_Date[2] + "" + asstF_Date[0] + "" + asstF_Date[1];
							} else {
								oAFMDate = asstFDate;
							}
						} else {
							oAFMDate = "";
						}

						var fDate = oItems[i].getAggregation("cells")[6].getText();
						var oFMDate;
						if (fDate !== "") {
							if (fDate.includes("/")) {
								var f_Date = fDate.split("/");
								oFMDate = f_Date[2] + "" + f_Date[0] + "" + f_Date[1];
							} else {
								oFMDate = fDate;
							}
						} else {
							oFMDate = "";
						}

						var tcDate = oItems[i].getAggregation("cells")[7].getText();
						var oTCDate;
						if (tcDate !== "") {
							if (tcDate.includes("/")) {
								var tc_Date = tcDate.split("/");
								oTCDate = tc_Date[2] + "" + tc_Date[0] + "" + tc_Date[1];
							} else {
								oTCDate = tcDate;
							}
						} else {
							oTCDate = "";
						}

						itemObj.EmpNo = empId;
						itemObj.HomeZone = "";
						itemObj.RRHired = "";
						itemObj.EndDate = oItems[i].getAggregation("cells")[8].getValue();
						itemObj.RRCode = oItems[i].getAggregation("cells")[0].getText();
						itemObj.Division = oItems[i].getAggregation("cells")[1].getText();
						itemObj.Group = oItems[i].getAggregation("cells")[2].getText();
						itemObj.District = oItems[i].getAggregation("cells")[3].getText();
						itemObj.RMD_Date = oRmDate;
						itemObj.AsstFDate = oAFMDate;
						itemObj.FDate = oFMDate;
						itemObj.TCDate = oTCDate;
						if (oItems[i].getAggregation("cells")[10].getText() === "F") {
							itemObj.Key = "I";
						} else if (oItems[i].getAggregation("cells")[10].getText() === "B") {
							itemObj.Key = "E";
						}
						itemData.push(itemObj);
					}

				}

			}

			oEntry.HomeZoneAddInfo = itemData;
			var oModel = that.getOwnerComponent().getModel();
			oModel.create("/EmpSenHDataSet()", oEntry, {
				success: function (oData, oResponse) {

					sap.m.MessageBox.information("Created Successfully", {
						icon: sap.m.MessageBox.Icon.INFORMATION,
						title: "Information",
						actions: ["OK"],
						onClose: function (oAction) {
							if (oAction === "OK") {

							}
						}
					});

					/*	var oCreateDialog = new sap.m.Dialog();
						oCreateDialog.setTitle(titleSuccess);
						oCreateDialog.setIcon("sap-icon://message-success");
						oCreateDialog.addStyleClass(
							"dialogHdrBgCls dialogTitleCls dialogTextShadowCls dialogBoxShadowCls dialogIconCls dialogFooterBgCls");
						var oSimpleForm = new sap.ui.layout.form.SimpleForm({
							content: [
								new sap.m.Text({
									text: "Created Successfully"
								})
							]
						});
						oCreateDialog.addContent(oSimpleForm);

						oCreateDialog.addButton(
							new sap.m.Button({
								text: ok,
								press: function () {
									oCreateDialog.close();
								}
							}).addStyleClass("sapUiSizeCompact clsBtnColorYellowRed")
						);
						oCreateDialog.open();*/

				},
				error: function (oResponse) {

					//-----------------------------------------------------------------------	
					// Displaying response header message.
					//-----------------------------------------------------------------------

					var oMessage = JSON.parse(oResponse.responseText).error.innererror.errordetails[0].message;

					sap.m.MessageBox.information(oMessage, {
						icon: sap.m.MessageBox.Icon.INFORMATION,
						title: titleInfo,
						actions: ["OK"],
						onClose: function (oAction) {
							if (oAction === "OK") {

								that.confirm = false;
								// that.onEmpHomeZoneAdditionalSenInfoGetFunc(empId);
								that.onHomeZoneClrFun();
								that.onCancel();
								// that.onEmpHomeZoneAdditionalSenInfoGetFunc(empId);
								that.onAdditionalSenInfoClrFun(); //++D5OW5 - Dt 01/31/2022
								that.onEmpHomeZoneAdditionalSenInfoGetFunc(that.employeeIDN); //++D5OW5 - Dt 01/31/2022
								that.byId("saveBtn").setVisible(false);
								that.byId("editBtn").setVisible(true);

							}
						}
					});

					/*var oCreateDialog = new sap.m.Dialog();
					oCreateDialog.setTitle(titleInfo);
					oCreateDialog.setIcon("sap-icon://message-information");
					oCreateDialog.addStyleClass(
						"dialogHdrBgCls dialogTitleCls dialogTextShadowCls dialogBoxShadowCls dialogIconCls dialogFooterBgCls");
					var oSimpleForm = new sap.ui.layout.form.SimpleForm({
						content: [
							new sap.m.Text({
								text: oMessage
							})
						]
					});
					oCreateDialog.addContent(oSimpleForm);
					oCreateDialog.addButton(
						new sap.m.Button({
							text: ok,
							press: function () {

								that.confirm = false;
								// that.onEmpHomeZoneAdditionalSenInfoGetFunc(empId);
								that.onHomeZoneClrFun();
								that.onCancel();
								oCreateDialog.close();
							}
						}).addStyleClass("sapUiSizeCompact clsBtnColorYellowRed")
					);
					oCreateDialog.open();*/

				}
			});

		},

		emptyDataFun: function () {

			var that = this;

			that.qualChangeFlag = false;

			that.byId("empDataEmpNoInp").setTokens([]);
			that.byId("empDataEmpNoInp").setValueState("None");
			// that.byId("empDataEmpNoInp").setDescription("");
			that.byId("empDataEmpNoInpDesc").setText("");
			that.byId("empSenMaintenanceSearch").removeAllTokens();
			that.byId("empSenMaintDescId").setText("");
			that.byId("empHomeZoneSearch").removeAllTokens();
			that.byId("empHomeZoneDescId").setText("");

			// that.byId("empDataEmpNoInp").setWidth("60%");
			that.byId("empDataPosInp").setValue("");

			that.byId("empDataPosInp").setDescription("");
			that.byId("empDataPosInp").setWidth("60%");
			that.byId("empDataUnionInp").setValue("");
			that.byId("empDataAgrInp").setValue("");
			that.byId("empAdditionalSenInfoSearch").removeAllTokens();
			that.byId("empAdditionalSenInfoDescId").setText("");
			that.byId("empDataAgrInp").setWidth("60%");
			that.byId("empDataUnionInp").setWidth("60%");
			that.byId("empDataEffDate").setValue(currentDate);
			that.byId("qualCraftTypeCombo").setValue("");
			that.byId("qualStDate").setValue("");
			that.byId("qualStDate").setValueState("None");
			that.byId("qualStDate").setEnabled(false);
			that.byId("qualQualsInput").removeAllTokens();
			that.byId("qualQualsInput").setValueState("None");
			// that.byId("qualQualsInput").setDescription("");
			that.byId("qualQualsInputDesc").setText("");
			// that.byId("qualQualsInput").setWidth("61%");
			that.byId("qualQualsInput").setEnabled(false);
			that.byId("qualEndDate").setValue("");
			that.byId("qualEndDate").setWidth("61%");
			that.byId("qualEndDate").setEnabled(false);
			that.byId("qualEndDate").setValueState("None");
			that.byId("qualproficiency").setEnabled(false);
			// that.byId("qualproficiency").setSelectedKey("");

			var oAdditionalForm = sap.ui.getCore().byId("additionalInfoForm");
			if (oAdditionalForm !== undefined) {
				oAdditionalForm.destroyContent();
			}

			// -------Clear table data------- 

			var itemsArray = [];
			var qualCModel = new sap.ui.model.json.JSONModel({
				"results": itemsArray
			});

			var itemsTable = that.byId("qualTable");
			itemsTable.setModel(qualCModel, "oModelData");

			that.byId("saveBtn").setEnabled(false);
			// that.byId("additionalInfoBtn").setEnabled(false);
			that.byId("addBtn").setEnabled(false);
			that.changeFlag = false;
			that.EditFlag = false;
			that.confirm = false;
			that.senEmpChangeFlag = false;
			that.editBtnPress = false;

		},

		onCancel: function () {

			var that = this;
			that._cancelTab(that.byId("IconTabbarId").getSelectedKey());
		},

		_cancelTab: function (seltdTab, sFlag) {
			var that = this;

			var doYouCancel = this.getView().getModel("i18n").getProperty("doYouCancel");
			var titleConfirm = this.getView().getModel("i18n").getProperty("titleConfirm");
			var yes = this.getView().getModel("i18n").getProperty("yes");
			var no = this.getView().getModel("i18n").getProperty("no");
			// var	selectedTab = that.byId("IconTabbarId").getSelectedKey();
			var selectedTab = seltdTab;
			if (selectedTab === "empQualAssign") {
				that.emptyDataFun();
			}
			if (that.confirm === true || that.EditFlag === true) {
				if (sFlag === "X") {
					that.sFinalArray = [];
					that.changeFlag = false;
					that.EditFlag = false;
					that.confirm = false;
					if (selectedTab === "empQualAssign") {
						that.emptyDataFun();
					} else if (selectedTab === "empSenMaint") {
						that.onReset();
					} else if (selectedTab === "empHomeZone") {
						that.onHomeZoneClrFun();
					} else if (selectedTab === "additionalSenInfo") {
						that.onAdditionalSenInfoClrFun();
					}
				} else {
					sap.m.MessageBox.confirm(doYouCancel, {
						title: titleConfirm,
						actions: [sap.m.MessageBox.Action.YES, sap.m.MessageBox.Action.NO],
						onClose: function (oAction) {
							if (oAction === sap.m.MessageBox.Action.YES) {
								that.sFinalArray = [];
								that.changeFlag = false;
								that.EditFlag = false;
								that.confirm = false;
								if (selectedTab === "empQualAssign") {
									that.emptyDataFun();
								} else if (selectedTab === "empSenMaint") {
									that.onReset();
								} else if (selectedTab === "empHomeZone") {
									that.onHomeZoneClrFun();
								} else if (selectedTab === "additionalSenInfo") {
									that.onAdditionalSenInfoClrFun();
								}

							}
						}
					});
				}

				/*var oCreateDialog = new sap.m.Dialog();
				oCreateDialog.setTitle(titleConfirm);
				oCreateDialog.setIcon("sap-icon://question-mark");
				oCreateDialog.addStyleClass(
					"dialogHdrBgCls dialogTitleCls dialogTextShadowCls dialogBoxShadowCls dialogIconCls dialogFooterBgCls");
				var oSimpleForm = new sap.ui.layout.form.SimpleForm({
					content: [
						new sap.m.Text({
							text: doYouCancel
						})
					]
				});
				oCreateDialog.addContent(oSimpleForm);
				oCreateDialog.addButton(
					new sap.m.Button({
						text: yes,
						press: function () {
							that.sFinalArray = [];
							that.changeFlag = false;
							that.EditFlag = false;
							that.confirm = false;
							if (selectedTab === "empQualAssign") {
								that.emptyDataFun();
							} else if (selectedTab === "empSenMaint") {
								that.onReset();
							} else if (selectedTab === "empHomeZone") {
								that.onHomeZoneClrFun();
							} else if (selectedTab === "additionalSenInfo") {
								that.onAdditionalSenInfoClrFun();
							}
							oCreateDialog.close();
						}
					}).addStyleClass("sapUiSizeCompact clsBtnColorYellowGreen")

				);

				oCreateDialog.addButton(
					new sap.m.Button({
						text: no,
						press: function () {
							oCreateDialog.close();
						}
					}).addStyleClass("sapUiSizeCompact clsBtnColorYellowRed")
				);
				oCreateDialog.open();*/

			} else {
				that.sFinalArray = [];
				that.changeFlag = false;
				that.EditFlag = false;
				that.confirm = false;
				if (selectedTab === "empSenMaint") {
					that.onReset();
				} else if (selectedTab === "empHomeZone") {
					that.onHomeZoneClrFun();
				} else if (selectedTab === "additionalSenInfo") {
					that.onAdditionalSenInfoClrFun();
				}
			}
			var newDate = new Date();
			var currDay = newDate.getDate();
			var currMonth = newDate.getMonth() + 1;
			var currYear = newDate.getFullYear();
			if (currDay < 10) {
				currDay = "0" + currDay;
			} else {
				currDay = currDay;
			}
			if (currMonth < 10) {
				currMonth = "0" + currMonth;
			} else {
				currMonth = currMonth;
			}
			currentDate = currMonth + "/" + currDay + "/" + currYear;
			that.byId("empDataEffDate").setValue(currentDate);
			that.byId("rosterSenDateId").setValue(currentDate);

		},

		onReset: function () {
			var that = this;

			var oTable = that.byId("empSenMaintTable");
			var oTableItems = oTable.getItems();
			for (var k = 0; k < oTableItems.length; k++) {
				/*oTableItems[k].getAggregation("cells")[7].getItems()[0].setEnabled(false).setVisible(true);
				oTableItems[k].getAggregation("cells")[7].getItems()[1].setVisible(false);
				oTableItems[k].getAggregation("cells")[3].setEnabled(false);*/
				oTableItems[k].getAggregation("cells")[13].getItems()[1].setEnabled(false);
				oTableItems[k].getAggregation("cells")[13].getItems()[3].setEnabled(false);
				// oTableItems[k].getAggregation("cells")[19].getItems()[0].setEnabled(false).setVisible(true);
				oTableItems[k].getAggregation("cells")[16].setVisible(false);
				// oTableItems[k].getAggregation("cells")[5].setEnabled(false);
			}
			// <!--editBtn saveBtn-->
			if (that.employeeIDN === "") {
				that.byId("empSenMaintenanceSearch").removeAllTokens();
				that.byId("empSenMaintDescId").setText("");
				that.byId("empHomeZoneSearch").removeAllTokens();
				that.byId("empHomeZoneDescId").setText("");
				that.byId("empSenMaintStatusId").setText("");
			}
			if (that.craftUnion === "Engineering") {
				that.byId("rosterNoInp").setValue().setEnabled(false);
				that.byId("empRemarksId").setValue().setEnabled(false);
				that.byId("rosterSenDateId").setEnabled(false);
				that.byId("rosterSenDateId").setValueState("None");
				that.byId("rosterOverrideSenDateId").setValue().setEnabled(false);
				that.byId("rosterOverrideSenDateId").setValueState("None");
				that.byId("rosterFrozenSenDateId").setValue().setEnabled(false);
				that.byId("rosterFrozenSenDateId").setValueState("None");
				that.byId("empSenDivisionInp").setValue().setEnabled(false);
				that.byId("empSenDivisionInp").setValueState("None");
				that.byId("empSenRrCodeInp").setValue().setEnabled(false);
				that.byId("empSenRrCodeInp").setValueState("None");
				that.byId("empSenDistrictInp").setValue().setEnabled(false);
				that.byId("empSenDistrictInp").setValueState("None");
				that.byId("empSenDpgZoneInp").setValue().setEnabled(false);
				that.byId("empSenDpgZoneInp").setValueState("None");
				that.byId("rosterOverrideNo").setEnabled(false);
			} else if (that.craftUnion === "Mechanical") {

				that.byId("rosterNoInp").setValue().setEnabled(false);
				that.byId("empRemarksId").setValue().setEnabled(false);
				that.byId("rosterSenDateId").setEnabled(false);
				that.byId("rosterOverrideSenDateId").setValue().setEnabled(false);
				that.byId("rosterOverrideSenDateId").setValueState("None");
				that.byId("rosterFrozenSenDateId").setValue().setEnabled(false);
				that.byId("rosterFrozenSenDateId").setValueState("None");
				that.byId("empSenCraftInp").setValue().setEnabled(false);
				that.byId("empSenCraftInp").setValueState("None");
				that.byId("rosterOverrideNo").setEnabled(false);

			} else if (that.craftUnion === "TCU") {
				that.byId("empSenDeptInp").setValue().setEnabled(false);
				that.byId("rosterNoInp").setValue().setEnabled(false);
				that.byId("empRemarksId").setValue().setEnabled(false);
				that.byId("rosterSenDateId").setEnabled(false);
				that.byId("rosterSenDateId").setValueState("None");
				that.byId("rosterOverrideSenDateId").setValue().setEnabled(false);
				that.byId("rosterOverrideSenDateId").setValueState("None");
				that.byId("rosterFrozenSenDateId").setValue().setEnabled(false);
				that.byId("rosterFrozenSenDateId").setValueState("None");
				that.byId("rosterOverrideNo").setEnabled(false);

			} else if (that.craftUnion === "ATDA") {

				that.byId("rosterNoInp").setValue().setEnabled(false);
				that.byId("empRemarksId").setValue().setEnabled(false);
				that.byId("rosterSenDateId").setEnabled(false);
				that.byId("rosterSenDateId").setValueState("None");
				that.byId("rosterOverrideSenDateId").setValue().setEnabled(false);
				that.byId("rosterOverrideSenDateId").setValueState("None");
				that.byId("rosterFrozenSenDateId").setValue().setEnabled(false);
				that.byId("rosterFrozenSenDateId").setValueState("None");
				that.byId("rosterOverrideNo").setEnabled(false);

			} else if (that.craftUnion === "ILA") {

				that.byId("rosterNoInp").setValue().setEnabled(false);
				that.byId("empRemarksId").setValue().setEnabled(false);
				that.byId("rosterSenDateId").setEnabled(false);
				that.byId("rosterSenDateId").setValueState("None");
				that.byId("rosterOverrideSenDateId").setValue().setEnabled(false);
				that.byId("rosterOverrideSenDateId").setValueState("None");
				that.byId("rosterFrozenSenDateId").setValue().setEnabled(false);
				that.byId("rosterFrozenSenDateId").setValueState("None");
				that.byId("rosterOverrideNo").setEnabled(false);

			}
			that.byId("editBtn").setVisible(true);
			that.byId("saveBtn").setVisible(false);
			that.byId("empSenMaintAdd").setEnabled(false);
			var empVal = "";
			// if (that.byId("empSenMaintenanceSearch").getTokens().length > 0) {
			// 	empVal = that.byId("empSenMaintenanceSearch").getTokens()[0].getKey();
			// }
			that.onEmpSenGetFunc(empVal);
			that.sFinalArray = [];
			that.changeFlag = false;
			that.EditFlag = false;
			that.confirm = false;
			that.senEmpChangeFlag = false;
		},

		onResetOK: function () {

			var that = this;

			var oTable = that.byId("empSenMaintTable");
			var oTableItems = oTable.getItems();
			for (var k = 0; k < oTableItems.length; k++) {
				/*oTableItems[k].getAggregation("cells")[7].getItems()[0].setEnabled(false).setVisible(true);
				oTableItems[k].getAggregation("cells")[7].getItems()[1].setVisible(false);
				oTableItems[k].getAggregation("cells")[3].setEnabled(false);*/
				oTableItems[k].getAggregation("cells")[13].getItems()[1].setEnabled(false);
				oTableItems[k].getAggregation("cells")[13].getItems()[3].setEnabled(false);
				// oTableItems[k].getAggregation("cells")[19].getItems()[0].setEnabled(false).setVisible(true);
				oTableItems[k].getAggregation("cells")[16].setVisible(false);
				// oTableItems[k].getAggregation("cells")[5].setEnabled(false);
			}
			// <!--editBtn saveBtn-->

			/*that.byId("rosterNoInp").setValue().setEnabled(false);
			that.byId("empRemarksId").setValue().setEnabled(false);
			that.byId("rosterSenDateId").setEnabled(false);
			that.byId("editBtn").setVisible(true);
			that.byId("saveBtn").setVisible(false);
			that.byId("empSenMaintAdd").setEnabled(false);*/
			var empVal = "";
			if (that.byId("empSenMaintenanceSearch").getTokens().length > 0) {
				empVal = that.byId("empSenMaintenanceSearch").getTokens()[0].getKey();
			}
			that.onEmpSenGetFunc(empVal);
			/*	that.sFinalArray = [];
				that.changeFlag = false;
				that.EditFlag = false;
				that.confirm = false;*/

		},

		onHomeZoneClrFun: function () {
			var that = this;

			var oTable = that.byId("empHomeZoneTable");
			var oTableItems = oTable.getItems();
			for (var k = 0; k < oTableItems.length; k++) {
				oTableItems[k].getAggregation("cells")[3].getItems()[0].setEnabled(false).setVisible(false);
				oTableItems[k].getAggregation("cells")[3].getItems()[1].setVisible(false);
				oTableItems[k].getAggregation("cells")[2].setEnabled(false);
			}
			// <!--editBtn saveBtn-->
			if (that.employeeIDN === "") {
				that.byId("empSenMaintenanceSearch").removeAllTokens();
				that.byId("empSenMaintDescId").setText("");
				that.byId("empHomeZoneSearch").removeAllTokens();
				that.byId("empHomeZoneDescId").setText("");
			}
			that.byId("empDataEffDateHZ").setValue().setEnabled(false);
			that.byId("empDataEffDateHZ").setValueState("None");
			that.byId("empHomeZoneDropDown").setValue().setEnabled(false);
			that.byId("empHomeZoneDropDown").setValueState("None");
			that.byId("empRrHiredDropDown").setValue().setEnabled(false);
			that.byId("empRrHiredDropDown").setValueState("None");
			// that.byId("empHomeZoneStatusId").setText("");
			// begin of insert - D5OW5 - Dt 03/03/2022 
			that.byId("divDropDownHZ").setValue().setEnabled(false);
			that.byId("districtDropDownHZ").setValue().setEnabled(false);
			that.byId("PriorRights").setValue().setEnabled(false);
			that.byId("Classification").setValue().setEnabled(false);
			// end of insert - D5OW5 - Dt 03/03/2022 			

			that.byId("editBtn").setVisible(true);
			that.byId("saveBtn").setVisible(false);
			that.byId("empHomeZoneAdd").setEnabled(false);
			var empVal = "";
			// if (that.byId("empHomeZoneSearch").getTokens().length > 0) {
			// 	empVal = that.byId("empHomeZoneSearch").getTokens()[0].getKey();
			// }
			that.onEmpHomeZoneAdditionalSenInfoGetFunc(empVal);
			that.sFinalArray = [];
			that.changeFlag = false;
			that.EditFlag = false;
			that.confirm = false;
			that.senEmpChangeFlag = false;
			that.editBtnPress = false;
		},

		onAdditionalSenInfoClrFun: function () {
			var that = this;

			var oTable = that.byId("empAdditionalSenInfoTable");
			var oTableItems = oTable.getItems();
			for (var k = 0; k < oTableItems.length; k++) {
				oTableItems[k].getAggregation("cells")[9].getItems()[0].setEnabled(false).setVisible(true);
				oTableItems[k].getAggregation("cells")[9].getItems()[1].setVisible(false);
				oTableItems[k].getAggregation("cells")[8].setEnabled(false);
			}
			// <!--editBtn saveBtn-->
			if (that.employeeIDN === "") {
				that.byId("empSenMaintenanceSearch").removeAllTokens();
				that.byId("empAdditionalSenInfoSearch").removeAllTokens();
				that.byId("empAdditionalSenInfoDescId").setText("");
				that.byId("empAdditionalSenInfoStatusId").setText("");
				that.byId("empSenMaintDescId").setText("");
				that.byId("empHomeZoneSearch").removeAllTokens();
				that.byId("empHomeZoneDescId").setText("");
			}
			that.byId("additionalSenInfoRrCodeDropDown").setValue().setEnabled(false);
			that.byId("additionalSenInfoRrCodeDropDown").setValueState("None");
			that.byId("additionalSenInfoDivDropDown").setValue().setEnabled(false);
			that.byId("additionalSenInfoDivDropDown").setValueState("None");
			that.byId("additionalSenInfoGroupInp").setValue().setEnabled(false);
			that.byId("additionalSenInfoGroupInp").setValueState("None");
			that.byId("additionalSenInfoDistDropDown").setValue().setEnabled(false);
			that.byId("additionalSenInfoDistDropDown").setValueState("None");
			that.byId("additionalSenInfoRmdDate").setValue().setEnabled(false);
			that.byId("additionalSenInfoRmdDate").setValueState("None");
			that.byId("additionalSenInfoAFMDate").setValue().setEnabled(false);
			that.byId("additionalSenInfoAFMDate").setValueState("None");
			that.byId("additionalSenInfoFMDate").setValue().setEnabled(false);
			that.byId("additionalSenInfoFMDate").setValueState("None");
			that.byId("additionalSenInfoTcDate").setValue().setEnabled(false);
			that.byId("additionalSenInfoTcDate").setValueState("None");
			// that.byId("empAdditionalSenInfoStatusId").setText("");

			that.byId("editBtn").setVisible(true);
			that.byId("saveBtn").setVisible(false);
			that.byId("empAdditionalSenInfoAdd").setEnabled(false);
			var empVal = "";
			// if (that.byId("empAdditionalSenInfoSearch").getTokens().length > 0) {
			// 	empVal = that.byId("empAdditionalSenInfoSearch").getTokens()[0].getKey();
			// }
			that.onEmpHomeZoneAdditionalSenInfoGetFunc(empVal);
			that.sFinalArray = [];
			that.changeFlag = false;
			that.EditFlag = false;
			that.confirm = false;
			that.senEmpChangeFlag = false;
			that.editBtnPress = false;
		},

		onQualSuggChage: function () {
			var that = this;
			// if (that.byId("qualQualsInput").getValue() === "") {
			// that.byId("qualQualsInput").setDescription();
			that.byId("qualQualsInputDesc").setText();
			// that.byId("qualQualsInput").setWidth("60%");
			// }
		},

		onQualSChange: function (oEvent) {

			var that = this;

			var noRecordsFound = this.getView().getModel("i18n").getProperty("noRecordsFound");

			if (that.byId("qualQualsInput").getTokens().length === 0) {

				// that.byId("qualQualsInput").setDescription();
				that.byId("qualQualsInputDesc").setText();
				// that.byId("qualQualsInput").setWidth("80%");
				that.byId("qualQualsInput").setValueState("None");

			} else {

				var oSearchParam = that.byId("qualQualsInput").getTokens()[0].getKey();

				var qualSuggModel = that.getView().getModel("qualSModel");

				var validationATrue = [];
				var validationAFalse = [];
				var validation = "X";

				for (var k = 0; k < qualSuggModel.oData.results.length; k++) {
					if (qualSuggModel.oData.results[k].QualDesc !== oSearchParam && qualSuggModel.oData.results[k].Qualification !==
						oSearchParam) {
						validationATrue.push(validation);
					} else {
						validationAFalse.push(validation);
					}
				}

				if (validationAFalse.length > 0) {

					var oSelectedRow = that.byId("qualQualsInput").getSelectedRow();
					var suggessionText = sap.ui.getCore().byId(oSelectedRow);

					that.byId("qualQualsInput").setValueState("None");

					var suggessionTxt = suggessionText.getCells()[0].getText();
					var suggessionDesc = suggessionText.getCells()[1].getText();
					that.QualId = suggessionText.getCells()[2].getText();

					// that.byId("qualQualsInput").setValue(suggessionTxt);

					that.byId("tempEmpNoInp").setTokens([new sap.m.Token({
						text: suggessionTxt,
						key: suggessionTxt
					})]);

					// that.byId("qualQualsInput").setDescription(suggessionDesc);
					that.byId("qualQualsInputDesc").setText(suggessionDesc);
					// that.byId("qualQualsInput").setWidth("122%");
					that.byId("qualEndDate").setWidth("60%");

				} else {
					if (that.byId("qualQualsInput").getTokens().length !== 0) {
						that.byId("qualQualsInput").setValueState("Error");
						sap.m.MessageToast.show(noRecordsFound);
					}
				}

			}

		},

		onEffDateChange: function (oEvent) {

			var that = this;

			var enterEmpNum = this.getView().getModel("i18n").getProperty("enterEmpNum");
			var dateFormat = this.getView().getModel("i18n").getProperty("dateFormat");
			var pernr = "";
			if (that.byId("empSenMaintenanceSearch").getTokens().length > 0) {
				pernr = that.byId("empSenMaintenanceSearch").getTokens()[0].getKey();
				// ++ Insert Begin - D5OW5 on 07/27/2021 - Effective Date change is not working on all tabs except Qual. asg tab				
			} else if (that.byId("empHomeZoneSearch").getTokens().length > 0) {
				pernr = that.byId("empHomeZoneSearch").getTokens()[0].getKey();
			} else if (that.byId("empAdditionalSenInfoSearch").getTokens().length > 0) {
				pernr = that.byId("empAdditionalSenInfoSearch").getTokens()[0].getKey();
			}
			// ++ Insert End - D5OW5 on 07/27/2021 - Effective Date change is not working on all tabs except Qual. asg tab			
			var effDate = that.byId("empDataEffDate").getValue();
			var EffDate = effDate.split("/");
			var effectiveDate = EffDate[2] + "" + EffDate[0] + "" + EffDate[1];
			var oDP = oEvent.getSource();
			var bValid = oEvent.getParameter("valid");

			//-----------------------------------------------------------------------	
			//Busy Indicator.
			//-----------------------------------------------------------------------

			var dialog = new sap.m.BusyDialog({});
			dialog.open();

			if (pernr === "") {
				// that.byId("empSenMaintenanceSearch").setValueState("Error");
				// sap.m.MessageToast.show(enterEmpNum);
				dialog.close();
			} else if (bValid) {
				that.confirm = true;
				// that.byId("empSenMaintenanceSearch").setValueState("None");
				that.byId("empDataEffDate").setValueState("None");
				// ++ Insert Begin - D5OW5 on 07/27/2021 - Effective Date change is not working on all tabs except Qual. asg tab
				var selectedTab = that.byId("IconTabbarId").getSelectedKey();
				if (selectedTab === "empSenMaint") {
					that.onEmpSenGetFunc(pernr);
				} else if (selectedTab === "empHomeZone") {
					that.onEmpHomeZoneAdditionalSenInfoGetFunc(pernr, effectiveDate);
				} else if (selectedTab === "additionalSenInfo") {
					that.onEmpHomeZoneAdditionalSenInfoGetFunc(pernr, effectiveDate);
				} else {
					that.qualDataFun(pernr, effectiveDate, "D");
				}
				// ++ Insert End - D5OW5 on 07/27/2021 - Effective Date change is not working on all tabs except Qual. asg tab
				// that.qualDataFun(pernr, effectiveDate, "D");   //-- by D5OW5 on 07/27/2021 as part of above change.
				dialog.close();
			} else {
				dialog.close();
				oDP.setValueState(sap.ui.core.ValueState.Error);
				sap.m.MessageToast.show(dateFormat);
			}

		},

		unique: function (qualTableArray) {
			for (var i = 1; i < qualTableArray.length;) {
				if (qualTableArray[i - 1].quals === qualTableArray[i].quals) {
					qualTableArray.splice(i, 1);
				} else {
					i++;
				}
			}
			return qualTableArray;
		},

		effDateUnique: function (oResults) {
			for (var i = 1; i < oResults.results.length;) {
				if (oResults.results[i - 1].qualID === oResults.results[i].qualID) {
					oResults.results.splice(i, 1);
				} else {
					i++;
				}
			}
			return oResults;
		},

		pernrUnique: function (oResults) {
			for (var i = 1; i < oResults.results.length;) {
				if (oResults.results[i - 1].qualID === oResults.results[i].qualID) {
					oResults.results.splice(i, 1);
				} else {
					i++;
				}
			}
			return oResults;
		},

		pernrUnique1: function (qualTableArray) {
			for (var i = 1; i < qualTableArray.length;) {
				if (qualTableArray[i - 1].qualID === qualTableArray[i].qualID) {
					qualTableArray.splice(i, 1);
				} else {
					i++;
				}
			}
			return qualTableArray;

		},

		addRownique: function (oResults) {
			for (var i = 1; i < oResults.results.length;) {
				if (oResults.results[i - 1].qualID === oResults.results[i].qualID) {
					oResults.results.splice(i, 1);
				} else {
					i++;
				}
			}
			return oResults;
		},

		addRownique1: function (createTableArray) {
			for (var i = 1; i < createTableArray.length;) {
				if (createTableArray[i - 1].qualID === createTableArray[i].qualID) {
					createTableArray.splice(i, 1);
				} else {
					i++;
				}
			}
			return createTableArray;

		},
		onUpdateFinished: function () {
			var that = this;
			var roleGetSelectedKey = that.byId("roleId").getSelectedKey();
			var oSelRole = that.byId("roleId").getSelectedItem();
			if (oSelRole !== null) {
				oSelRole = that.byId("roleId").getSelectedItem().getProperty("text");
			}
			// var selectedTab = that.byId("IconTabbarId").getSelectedKey();

			var oModelData = that.getView().getModel("oModelTotalData");
			var oTableData = that.byId("qualTable").getItems();
			if (oModelData !== undefined) {
				for (var i = 0; i < oTableData.length; i++) {
					var oQual = oTableData[i].getAggregation("cells")[6].getProperty("text");

					for (var j = 0; j < oModelData.oData.results.length; j++) {
						var oModelQual = oModelData.oData.results[j].Qualif;
						if (oQual === oModelQual) {
							if (oModelData.oData.results[j].AddField1 !== "" || oModelData.oData.results[j].AddField2 !== "" || oModelData.oData.results[
									j]
								.AddField3 !==
								"" || oModelData.oData.results[j].AddField4 !== "" || oModelData.oData.results[j].AddField5 !== "" || oModelData.oData.results[
									j].AddField6 !== "" || oModelData.oData.results[j].AddField7 !== "" || oModelData.oData.results[j].AddField8 !== "" ||
								oModelData.oData.results[j].AddField9 !== "" || oModelData.oData.results[j].AddField10 !== "" || oModelData.oData.results[
									j].DocData !==
								"" || oModelData.oData.results[j].DocName !== "") {
								if (roleGetSelectedKey === "LR") {

									oTableData[i].getAggregation("cells")[11].getItems()[0].setEnabled(false);
									//oTableData[i].getAggregation("cells")[11].getItems()[1].setEnabled(false);
									oTableData[i].getAggregation("cells")[11].getItems()[2].setEnabled(false);

								} else {
									oTableData[i].getAggregation("cells")[11].getItems()[0].setEnabled(true);
									//oTableData[i].getAggregation("cells")[11].getItems()[1].setEnabled(true);
									oTableData[i].getAggregation("cells")[11].getItems()[2].setEnabled(true);
								}

							} else {
								// oTableData[i].getAggregation("cells")[11].getItems()[0].setEnabled(false);
								// oTableData[i].getAggregation("cells")[11].getItems()[1].setEnabled(false);

								if (roleGetSelectedKey === "LR") {

									oTableData[i].getAggregation("cells")[11].getItems()[0].setEnabled(false);
									//oTableData[i].getAggregation("cells")[11].getItems()[1].setEnabled(false);
									oTableData[i].getAggregation("cells")[11].getItems()[2].setEnabled(false);

								} else {
									oTableData[i].getAggregation("cells")[11].getItems()[0].setEnabled(false);
									//oTableData[i].getAggregation("cells")[11].getItems()[1].setEnabled(false);
									oTableData[i].getAggregation("cells")[11].getItems()[2].setEnabled(true);
								}

							}
						}
						if (oSelRole === "Supervisor") {
							oTableData[i].getAggregation("cells")[11].getItems()[3].setEnabled(false);
							oTableData[i].getAggregation("cells")[11].getItems()[1].setEnabled(false);
						}
					}
				}
			}

			/*	var data = this.byId("qualTable").getItems();
				for (var i = 0; i < data.length; i++) {
					if (data[i].getAggregation("cells")[5].getText() === "B") {
						data[i].getAggregation("cells")[11].getItems()[0].setVisible(false);
						data[i].getAggregation("cells")[11].getItems()[1].setVisible(true);
					} else if (data[i].getAggregation("cells")[5].getText() === "F") {
						data[i].getAggregation("cells")[11].getItems()[0].setVisible(true);
						data[i].getAggregation("cells")[11].getItems()[1].setVisible(true);
					}
				}*/

		},

		//-----------------------------------------------------------------------	
		// Editing table row based on index.
		//-----------------------------------------------------------------------

		onInlineEdit: function (oEvent) {

			var that = this;

			if (!oEvent.getSource().getParent().getAggregation("items")[0].getEnabled()) {
				that.index = parseInt(oEvent.getSource().getId().split("qualTable-")[1]);
				var context = oEvent.getSource().getBindingContext("oModelData");
				that.QualdataObject = context.getModel().getProperty(context.getPath());
				if (!that._qualValueEnd) {
					that._qualValueEnd = sap.ui.xmlfragment("com.empqualassignment.Employee_Qual_Assignment.fragment.UpdateEndDate", that.getView()
						.getController());
					that.getView().addDependent(that._qualValueEnd);
				}
				that._qualValueEnd.open();
				that._qualValueEnd.setEscapeHandler(function (o) {
					o.reject();
				});
				sap.ui.getCore().byId("endQual").setValue(that.QualdataObject.quals);
				sap.ui.getCore().byId("qualEndDate").setValue("");
			} else {

				var oPath = oEvent.getSource().getBindingContext("oModelData").sPath;
				var oData = that.getView().byId("qualTable").getModel("oModelData").getProperty(oPath);

				var empNo = that.byId("empDataEmpNoInp").getTokens()[0].getKey(),
					craft = that.byId("craftType").getText(),
					effectiveDate = that.byId("empDataEffDate").getValue(),
					qualId = oData.qualID,
					startDate = oData.stDate,
					endDate = oData.enDate,
					qualDesc = oData.quals,
					profScale = oData.profScale;

				var effDateSplit = effectiveDate.split("/");
				var effDate = effDateSplit[2] + "" + effDateSplit[0] + "" + effDateSplit[1];
				var type = "Edit";

				if (empNo === "") {
					empNo = " ";
				} else {
					empNo = empNo;
				}
				if (craft === "") {
					craft = " ";
				} else {
					craft = craft;
				}
				if (qualId === "") {
					qualId = " ";
				} else {
					qualId = qualId;
				}
				if (effDate === "") {
					effDate = " ";
				} else {
					effDate = effDate;
				}
				if (startDate === "") {
					startDate = " ";
				} else {
					startDate = startDate;
				}
				if (endDate === "") {
					endDate = " ";
				} else {
					endDate = endDate;
				}
				if (qualDesc === "") {
					qualDesc = " ";
				} else {
					qualDesc = qualDesc;
				}
				if (profScale === "") {
					profScale = " ";
				} else {
					profScale = profScale;
				}

				sap.ui.core.UIComponent.getRouterFor(that).navTo("QualDispEdit", {
					empNo: empNo,
					craft: craft,
					qualId: qualId,
					effDate: effDate,
					type: type,
					startDate: startDate,
					endDate: endDate,
					qualDesc: encodeURIComponent(qualDesc),
					profScale: profScale
				});
			}
			/*	var valueString = oEvent.getSource().getBindingContext("oModelData").sPath;
				this.getView().byId("qualTable").getModel("oModelData").setProperty(valueString + "/Key", "E");

				//-----------------------------------------------------------------------	
				// Enabling particular row based on index.
				//-----------------------------------------------------------------------

				oEvent.getSource().getParent().getParent().getCells()[4].setEnabled(true);

				that.byId("saveBtn").setEnabled(true);*/

		},

		onInlineDisplay: function (oEvent) {

			var that = this;

			var oPath = oEvent.getSource().getBindingContext("oModelData").sPath;
			var oData = that.getView().byId("qualTable").getModel("oModelData").getProperty(oPath);

			var empNo = that.byId("empDataEmpNoInp").getTokens()[0].getKey(),
				craft = that.byId("craftType").getText(),
				effectiveDate = that.byId("empDataEffDate").getValue(),
				qualId = oData.qualID,
				startDate = oData.stDate,
				endDate = oData.enDate,
				qualDesc = oData.quals,
				profScale = oData.profScale;

			var effDateSplit = effectiveDate.split("/");
			var effDate = effDateSplit[2] + "" + effDateSplit[0] + "" + effDateSplit[1];
			var type = "Display";

			if (empNo === "") {
				empNo = " ";
			} else {
				empNo = empNo;
			}
			if (craft === "") {
				craft = " ";
			} else {
				craft = craft;
			}
			if (qualId === "") {
				qualId = " ";
			} else {
				qualId = qualId;
			}
			if (effDate === "") {
				effDate = " ";
			} else {
				effDate = effDate;
			}
			if (startDate === "") {
				startDate = " ";
			} else {
				startDate = startDate;
			}
			if (endDate === "") {
				endDate = " ";
			} else {
				endDate = endDate;
			}
			if (qualDesc === "") {
				qualDesc = " ";
			} else {
				qualDesc = qualDesc;
			}
			if (profScale === "") {
				profScale = " ";
			} else {
				profScale = profScale;
			}

			sap.ui.core.UIComponent.getRouterFor(that).navTo("QualDispEdit", {
				empNo: empNo,
				craft: craft,
				qualId: qualId,
				effDate: effDate,
				type: type,
				startDate: startDate,
				endDate: endDate,
				qualDesc: encodeURIComponent(qualDesc),
				profScale: profScale
			});

		},

		/*	onInlineDelimit: function (oEvent) {

				var that = this;

				var oPath = oEvent.getSource().getBindingContext("oModelData").sPath;
				var oData = that.getView().byId("qualTable").getModel("oModelData").getProperty(oPath);

				var empNo = that.byId("empDataEmpNoInp").getValue(),
					craft = that.byId("craftType").getText(),
					effectiveDate = that.byId("empDataEffDate").getValue(),
					qualId = oData.qualID,
					startDate = oData.stDate,
					endDate = oData.enDate,
					qualDesc = oData.quals,
					profScale = oData.profScale;

				var effDateSplit = effectiveDate.split("/");
				var effDate = effDateSplit[2] + "" + effDateSplit[0] + "" + effDateSplit[1];
				var type = "Delimit";

				if (empNo === "") {
					empNo = " ";
				} else {
					empNo = empNo;
				}
				if (craft === "") {
					craft = " ";
				} else {
					craft = craft;
				}
				if (qualId === "") {
					qualId = " ";
				} else {
					qualId = qualId;
				}
				if (effDate === "") {
					effDate = " ";
				} else {
					effDate = effDate;
				}
				if (startDate === "") {
					startDate = " ";
				} else {
					startDate = startDate;
				}
				if (endDate === "") {
					endDate = " ";
				} else {
					endDate = endDate;
				}
				if (qualDesc === "") {
					qualDesc = " ";
				} else {
					qualDesc = qualDesc;
				}
				if (profScale === "") {
					profScale = " ";
				} else {
					profScale = profScale;
				}

				sap.ui.core.UIComponent.getRouterFor(that).navTo("QualDispEdit", {
					empNo: empNo,
					craft: craft,
					qualId: qualId,
					effDate: effDate,
					type: type,
					startDate: startDate,
					endDate: endDate,
					qualDesc: qualDesc,
					profScale: profScale
				});

			},*/

		onEndDateCellChange: function (oEvent) {

			var dateFormat = this.getView().getModel("i18n").getProperty("dateFormat");
			var endDateGreaterStartDate = this.getView().getModel("i18n").getProperty("endDateGreaterStartDate");

			var index = parseInt(oEvent.getSource().getId().split("qualTable-")[1]);
			var tableId = this.byId("qualTable").getId();

			var startDate = this.byId("stDateCell-" + tableId + "-" + index).getText();
			var endDate = this.byId("endDateCellInp-" + tableId + "-" + index).getValue();
			var oDP = oEvent.getSource();
			var bValid = oEvent.getParameter("valid");

			if (bValid) {
				oDP.setValueState(sap.ui.core.ValueState.None);
			} else {
				oDP.setValueState(sap.ui.core.ValueState.Error);
				sap.m.MessageToast.show(dateFormat);
			}

			if (new Date(endDate) < new Date(startDate)) {
				this.byId("endDateCellInp-" + tableId + "-" + index).setValueState("Error");
				sap.m.MessageToast.show(endDateGreaterStartDate);

			} else {

				if (bValid) {
					oDP.setValueState(sap.ui.core.ValueState.None);
					this.byId("endDateCellInp-" + tableId + "-" + index).setValueState("None");
				} else {
					oDP.setValueState(sap.ui.core.ValueState.Error);
					this.byId("endDateCellInp-" + tableId + "-" + index).setValueState("Error");
					sap.m.MessageToast.show(dateFormat);

					this.byId("saveBtn").setEnabled(false);
				}

			}

			var data = this.byId("qualTable").getItems();

			var valueStateArray = [];
			var visible = "X";

			for (var i = 0; i < data.length; i++) {
				if (data[i].getAggregation("cells")[4].getValueState() === "Error") {
					valueStateArray.push(visible);
				} else {
					valueStateArray.push();
				}
			}

			if (valueStateArray.length > 0) {
				this.byId("saveBtn").setEnabled(false);
			} else {
				this.byId("saveBtn").setEnabled(true);
			}

		},

		handleIconTabBarSelect: function (oEvent) {
			var that = this;
			// var roleGetSelectedKey = that.byId("roleId").getSelectedKey();
			var selectedTab = this.byId("IconTabbarId").getSelectedKey();
			if (this.EditFlag) {
				that.byId("IconTabbarId").setSelectedKey(that.prevTab);
				sap.m.MessageBox.confirm("Unsaved Data will be lost, Do you want to proceed?", {
					actions: [sap.m.MessageBox.Action.YES, sap.m.MessageBox.Action.NO],
					onClose: function (oAction) {
						if (oAction === "YES") {
							that._cancelTab(that.prevTab, "X");
							that.byId("IconTabbarId").setSelectedKey(selectedTab);
							that._handleIconTabbarSelect(selectedTab);
						} else {
							that.byId("IconTabbarId").setSelectedKey(that.prevTab);
						}
					}
				});
			} else {
				that._handleIconTabbarSelect(selectedTab);
			}

		},
		_handleIconTabbarSelect: function (seltdTab) {
			var that = this;
			var union;
			var selectedTab = seltdTab;
			// if (that.prevTab === "empQualAssign") {
			// 	that.employeeIDN = "";
			// }
			if (selectedTab === "empQualAssign") {
				// that.emptyDataFun();
				// if (that.employeeIDN !== "") {                                //--D5OW5 - Dt 02/01/2022
				if (that.employeeIDN !== undefined && that.employeeIDN !== "") { //++D5OW5 - Dt 02/01/2022
					that.byId("empDataEmpNoInp").setTokens([new sap.m.Token({
						text: that.employeeIDN,
						key: that.employeeIDN
					})]);
					// that.byId("empDataEmpNoInpDesc").setText(that.empName);
					this.empNoChange();
				}
			} else if (selectedTab === "empSenMaint") {
				// if (that.employeeIDN !== "") {                                //--D5OW5 - Dt 02/01/2022
				if (that.employeeIDN !== undefined && that.employeeIDN !== "") { //++D5OW5 - Dt 02/01/2022
					that.byId("empSenMaintenanceSearch").setTokens([new sap.m.Token({
						key: that.employeeIDN,
						text: that.employeeIDN
					})]);
					that.onEmpSenGetFunc(that.employeeIDN);
					that.byId("empSenMaintDescId").setText(that.empName);
					that.byId("empSenMaintStatusId").setText(that.empStatus);
					that.byId("editBtn").setVisible(true);
				} else {
					that.employeeIDN = "";
					that.onReset();
				}
			} else if (selectedTab === "empHomeZone") {
				// if (that.employeeIDN !== "") {                                 //--D5OW5 - Dt 02/01/2022
				if (that.employeeIDN !== undefined && that.employeeIDN !== "") { //++D5OW5 - Dt 02/01/2022
					that.byId("empHomeZoneSearch").setTokens([new sap.m.Token({
						key: that.employeeIDN,
						text: that.employeeIDN
					})]);
					that.onEmpHomeZoneAdditionalSenInfoGetFunc(that.employeeIDN);
					that.byId("empHomeZoneDescId").setText(that.empName);
					that.byId("empHomeZoneStatusId").setText(that.empStatus);
					that.byId("editBtn").setVisible(true);
				} else {
					that.employeeIDN = "";
					that.onHomeZoneClrFun();
				}
			} else if (selectedTab === "additionalSenInfo") {
				// if (that.employeeIDN !== "") {                                 //--D5OW5 - Dt 02/01/2022
				if (that.employeeIDN !== undefined && that.employeeIDN !== "") { //++D5OW5 - Dt 02/01/2022
					//	that.byId("empAdditionalSenInfoSearch").setValue(that.employeeID);
					that.byId("empAdditionalSenInfoSearch").setTokens([new sap.m.Token({
						key: that.employeeIDN,
						text: that.employeeIDN
					})]);
					that.onEmpHomeZoneAdditionalSenInfoGetFunc(that.employeeIDN);
					that.byId("empAdditionalSenInfoDescId").setText(that.empName);
					that.byId("empAdditionalSenInfoStatusId").setText(that.empStatus);
					that.byId("editBtn").setVisible(true);
				} else {
					that.employeeIDN = "";
					that.onAdditionalSenInfoClrFun();
				}
			}
			// if (selectedTab === "empQualAssign") {
			// 	that.byId("editBtn").setVisible(false);
			// 	that.byId("saveBtn").setVisible(false);
			// 	that.byId("cancelBtn").setVisible(false);
			// 	that.employeeIDN = "";
			// 	if (that.employeeIDN !== "") {
			// 		var currDateTmp = currentDate.split("/");
			// 		var currDateStr = currDateTmp[2] + currDateTmp[0] + currDateTmp[1];
			// 		that.qualDataFun(that.employeeIDN, currDateStr, "D");
			// 	}
			// }
			// return;
			// var roleGetSelectedKey = that.byId("roleId").getSelectableItems()[0].getText();
			if (that.byId("roleId").getSelectableItems()[0] !== undefined) {
				var roleGetSelectedKey = that.byId("roleId").getSelectableItems()[0].getText();
			}
			if (that.qualChangeFlag === true || that.senEmpChangeFlag === true) {
				// that.emptyDataFun();
				// sap.m.MessageToast.show("Please save/cancel the unsaved data");
				//that.byId("IconTabbarId").setSelectedKey(that.selTab);
			} else {
				// var selectedTab = oEvent.getParameter("key");
				if (selectedTab === "empQualAssign") {
					that.byId("editBtn").setVisible(false);
					that.byId("saveBtn").setVisible(false);
					that.byId("cancelBtn").setVisible(false);
					that.onCancel();

					if (roleGetSelectedKey === "LR Admin") {

						that.byId("editBtn").setVisible(false);
						that.byId("saveBtn").setVisible(false);
						that.byId("cancelBtn").setVisible(false);

					} else {
						that.byId("editBtn").setVisible(false);
						that.byId("saveBtn").setVisible(false);
						that.byId("cancelBtn").setVisible(true);
					}

				} else
				if (selectedTab === "empSenMaint") {
					this.byId("editBtn").setVisible(true);
					that.byId("saveBtn").setVisible(true);
					// that.onCancel();

					var empSenTable = that.byId("empSenMaintTable");
					var oColumns = empSenTable.getColumns();

					var empSenHeaderTable = that.byId("empSenMaintTableCols");
					// var oHeaderColumns = empSenHeaderTable.getColumns();

					if (that.craftUnion === "Engineering") {

						that.byId("rosterNoInp").setVisible(true);
						that.byId("rosterSenDateId").setVisible(true);
						that.byId("rosterOverrideSenDateId").setVisible(true);
						that.byId("rosterFrozenSenDateId").setVisible(true);
						that.byId("empRemarksId").setVisible(true);
						that.byId("empSenCraftInp").setVisible(false);
						that.byId("empSenDivisionInp").setVisible(true);
						that.byId("empSenRrCodeInp").setVisible(true);
						that.byId("empSenDistrictInp").setVisible(true);
						that.byId("empSenDpgZoneInp").setVisible(true);
					} else if (that.craftUnion === "Mechanical") {

						that.byId("rosterNoInp").setVisible(true);
						that.byId("rosterSenDateId").setVisible(true);
						that.byId("rosterOverrideSenDateId").setVisible(true);
						that.byId("rosterFrozenSenDateId").setVisible(true);
						that.byId("empRemarksId").setVisible(true);
						that.byId("empSenCraftInp").setVisible(true);
						that.byId("empSenDivisionInp").setVisible(false);
						that.byId("empSenRrCodeInp").setVisible(false);
						that.byId("empSenDistrictInp").setVisible(false);
						that.byId("empSenDpgZoneInp").setVisible(false);
					} else if (that.craftUnion === "TCU") {

						that.byId("rosterNoInp").setVisible(true);
						that.byId("rosterSenDateId").setVisible(true);
						that.byId("rosterOverrideSenDateId").setVisible(true);
						that.byId("rosterFrozenSenDateId").setVisible(true);
						that.byId("empRemarksId").setVisible(true);
						that.byId("empSenCraftInp").setVisible(false);
						that.byId("empSenDivisionInp").setVisible(false);
						that.byId("empSenRrCodeInp").setVisible(false);
						that.byId("empSenDistrictInp").setVisible(false);
						that.byId("empSenDpgZoneInp").setVisible(false);
					} else if (that.craftUnion === "ATDA") {

						that.byId("rosterNoInp").setVisible(true);
						that.byId("rosterSenDateId").setVisible(true);
						that.byId("rosterOverrideSenDateId").setVisible(true);
						that.byId("rosterFrozenSenDateId").setVisible(true);
						that.byId("empRemarksId").setVisible(true);
						that.byId("empSenCraftInp").setVisible(false);
						that.byId("empSenDivisionInp").setVisible(false);
						that.byId("empSenRrCodeInp").setVisible(false);
						that.byId("empSenDistrictInp").setVisible(false);
						that.byId("empSenDpgZoneInp").setVisible(false);
					} else if (that.craftUnion === "ILA") {

						that.byId("rosterNoInp").setVisible(true);
						that.byId("rosterSenDateId").setVisible(true);
						that.byId("rosterOverrideSenDateId").setVisible(true);
						that.byId("rosterFrozenSenDateId").setVisible(true);
						that.byId("empRemarksId").setVisible(true);
						that.byId("empSenCraftInp").setVisible(false);
						that.byId("empSenDivisionInp").setVisible(false);
						that.byId("empSenRrCodeInp").setVisible(false);
						that.byId("empSenDistrictInp").setVisible(false);
						that.byId("empSenDpgZoneInp").setVisible(false);
					}

					if (roleGetSelectedKey === "LR Admin") {

						that.byId("editBtn").setVisible(false);
						that.byId("saveBtn").setVisible(false);
						that.byId("cancelBtn").setVisible(false);

					} else {
						that.byId("editBtn").setVisible(true);
						that.byId("saveBtn").setVisible(false);
						that.byId("cancelBtn").setVisible(true);
					}

				} else if (selectedTab === "empHomeZone") {
					if (roleGetSelectedKey === "LR Admin") {

						that.byId("editBtn").setVisible(false);
						that.byId("saveBtn").setVisible(false);
						that.byId("cancelBtn").setVisible(false);

					} else {
						that.byId("editBtn").setVisible(true);
						that.byId("saveBtn").setVisible(false);
						that.byId("cancelBtn").setVisible(true);
					}
				} else if (selectedTab === "additionalSenInfo") {
					if (roleGetSelectedKey === "LR Admin") {

						that.byId("editBtn").setVisible(false);
						that.byId("saveBtn").setVisible(false);
						that.byId("cancelBtn").setVisible(false);

					} else {
						that.byId("editBtn").setVisible(true);
						that.byId("saveBtn").setVisible(false);
						that.byId("cancelBtn").setVisible(true);
					}
				} else if (selectedTab === "apprQualMaint") {
					//that.onCancel();
					if (roleGetSelectedKey === "LR Admin") {

						that.byId("editBtn").setVisible(false);
						that.byId("saveBtn").setVisible(false);
						that.byId("cancelBtn").setVisible(false);

					} else {
						that.byId("editBtn").setVisible(false);
						that.byId("saveBtn").setVisible(false);
						that.byId("cancelBtn").setVisible(false);
					}
					if (that.deptSelectedKey !== "CH") {
						var oSelRole = this.byId("roleId").getSelectedItem().getProperty("text");
						var deptVal = that.byId("deptId").getSelectedKey();
						if (oSelRole === "Super PM Admin") {
							if (deptVal === "E" || deptVal === "SE" || deptVal === "Engineering" || deptVal === "SE") {
								union = "SE";
							} else if (deptVal === "M" || deptVal === "SM" || deptVal === "Mechanical" || deptVal === "SM") {
								union = "SM";
							} else if (deptVal === "T" || deptVal === "ST" || deptVal === "TCU" || deptVal === "ST") {
								union = "ST";
							} else if (deptVal === "A" || deptVal === "SA" || deptVal === "ATDA" || deptVal === "SD") {
								union = "SA";
							} else if (deptVal === "L" || deptVal === "SL" || deptVal === "ILA" || deptVal === "SL") {
								union = "SL";
							} else if (deptVal === "IHB" || deptVal === "CG") {
								union = "CG";
							}
						} else
						if (oSelRole === "Supervisor" || oSelRole === "CH" || oSelRole === "Chief Supervisor") {
							union = "CH";
						} else {
							if (deptVal === "E" || deptVal === "SE" || deptVal === "Engineering") {
								union = "E";
							} else if (deptVal === "M" || deptVal === "SM" || deptVal === "Mechanical") {
								union = "M";
							} else if (deptVal === "T" || deptVal === "ST" || deptVal === "TCU") {
								union = "T";
							} else if (deptVal === "A" || deptVal === "SA" || deptVal === "ATDA") {
								union = "A";
							} else if (deptVal === "L" || deptVal === "SL" || deptVal === "ILA") {
								union = "L";
							} else if (deptVal === "CG") {
								union = "CG";
							}
						}
						var sFilters = [];
						sFilters.push(new sap.ui.model.Filter("Craft", sap.ui.model.FilterOperator.EQ, union));
						var qualModel = that.getOwnerComponent().getModel();
						qualModel.setUseBatch(false);
						var oModel1 = that.getOwnerComponent().getModel("oDataSrv");
						oModel1.read("/QualReqDetailsSet?$filter=Craft eq '" + union + "'", {
							filters: sFilters,
							success: function (oData, Response) {
								// dialog.close();
								if (oData.results.length > 0) {
									var oReqDetailsModel = new sap.ui.model.json.JSONModel(oData);
									var oTable1 = that.getView().byId("qualReqDetailsTableId1");
									oTable1.setModel(oReqDetailsModel, "qualReqDetailsModel");
								}
							},
							error: function (oResponse) {
								// dialog.close();
							}
						});
					}

				}
				if (selectedTab === "empQualAssign") {
					that.byId("cancelBtn").setVisible(false);
				}
			}
			that.prevTab = selectedTab;
		},
		//INLPAT
		onRosterSubmit: function () {

		},

		onRosterNoRequest: function (oEvent) {
			var that = this;

			var enterRostNo = this.getView().getModel("i18n").getProperty("enterRostNo");

			var oRosterValue = oEvent.getSource().getValue().trim();
			// var craft = that.byId("senCraftTpeId").getText();
			var oCraft = "";
			if (that.craftUnion === "Mechanical") {
				oCraft = "M";
			} else if (that.craftUnion === "TCU") {
				oCraft = "T";
			} else if (that.craftUnion === "Engineering") {
				oCraft = "E";
			}
			/*if (craft === "Mechanical") {
				oCraft = "M";
			} else if (craft === "TCU") {
				oCraft = "T";
			} else if (craft === "Engineering") {
				oCraft = "E";
			}*/

			if (oCraft === "T") {
				if (!that.rosterDialog) {
					that.rosterDialog = sap.ui.xmlfragment("com.empqualassignment.Employee_Qual_Assignment.fragment.RosterNo", that.getView()
						.getController());
					that.getView().addDependent(that.rosterDialog);
				}
				that.onRosterCancel();
				sap.ui.getCore().byId("rosterNumId").setValue(oEvent.getSource().getValue());
				sap.ui.getCore().byId("rosterNumId").fireSubmit();

				that.rosterDialog.open();

				that.rosterDialog.setEscapeHandler(function (o) {
					o.reject();
				});

				if (oRosterValue.length < 1) {
					sap.m.MessageToast.show(enterRostNo, {
						my: "center center",
						at: "center center",
						of: window
					});
				}
			} else if (oCraft === "M") {
				that.onMechDialogOpenFunc(oRosterValue);
			} else if (oCraft === "E") {
				that.onEngDialogOpenFunc(oRosterValue);
			}
		},

		onMechDialogOpenFunc: function (oRosterValue) {
			var that = this;

			var enterRostNo = this.getView().getModel("i18n").getProperty("enterRostNo");

			if (!that.rosterDialog1) {
				that.rosterDialog1 = sap.ui.xmlfragment("com.empqualassignment.Employee_Qual_Assignment.fragment.MechRoster", that.getView()
					.getController());
				that.getView().addDependent(that.rosterDialog1);
			}
			that.onRosterCancel();
			sap.ui.getCore().byId("mechRosterNumId").setValue(oRosterValue);
			// sap.ui.getCore().byId("rosterNumId").fireSubmit();

			that.rosterDialog1.open();

			that.rosterDialog1.setEscapeHandler(function (o) {
				o.reject();
			});

			if (oRosterValue.length < 1) {
				sap.m.MessageToast.show(enterRostNo, {
					my: "center center",
					at: "center center",
					of: window
				});
			}
		},

		onEngDialogOpenFunc: function (oRosterValue) {
			var that = this;

			var enterRostNo = this.getView().getModel("i18n").getProperty("enterRostNo");

			if (!that.rosterDialog2) {
				that.rosterDialog2 = sap.ui.xmlfragment("com.empqualassignment.Employee_Qual_Assignment.fragment.EngRoster", that.getView()
					.getController());
				that.getView().addDependent(that.rosterDialog2);
			}
			that.onRosterCancel();
			sap.ui.getCore().byId("engRosterNumId").setValue(oRosterValue);
			// sap.ui.getCore().byId("rosterNumId").fireSubmit();

			that.rosterDialog2.open();

			that.rosterDialog2.setEscapeHandler(function (o) {
				o.reject();
			});

			if (oRosterValue.length < 1) {
				sap.m.MessageToast.show(enterRostNo, {
					my: "center center",
					at: "center center",
					of: window
				});
			}
		},

		onRosterMultiSubmit: function () {
			var that = this;

			var enterRostNo = this.getView().getModel("i18n").getProperty("enterRostNo");
			var enterDept = this.getView().getModel("i18n").getProperty("enterDept");
			var enterEmpId = this.getView().getModel("i18n").getProperty("enterEmpId");

			var oTabbar = sap.ui.getCore().byId("rosterMultiSearchId");
			var tabSelectedKey = sap.ui.getCore().byId("rosterMultiSearchId").getSelectedKey();

			// var oContainer = sap.m.ScrollContainer();
			var oTable = new sap.m.Table({
				alternateRowColors: true,
				columns: [new sap.m.Column({

						/*
												header: [
													new sap.m.Label({
														text: "Gang ID"
													})
												]
											*/
					}),
					new sap.m.Column({

						/*
												header: [
													new sap.m.Label({
														text: "Description"
													})
												]
											*/
					}),
					new sap.m.Column({

						/*
												header: [
													new sap.m.Label({
														text: "Assigned Supervisor"
													})
												]
											*/
					}),
					new sap.m.Column({

						/*
												header: [
													new sap.m.Label({
														text: "City"
													})
												]
											*/
					})
				]
			}).addStyleClass("clsColumnHeader clsTableHeader sapUiSizeCompact");
			// oContainer.addContent(oTable1);

			var rosterModel = new sap.ui.model.json.JSONModel();
			oTable.setModel(rosterModel, "aModelData");
			/*oTabbar.getItems()[0].addContent(oTable);
			oTabbar.getItems()[1].addContent(oTable);
			oTabbar.getItems()[2].addContent(oTable);
			oTabbar.getItems()[3].addContent(oTable);
			oTabbar.getItems()[4].addContent(oTable);
			oTabbar.getItems()[5].addContent(oTable);
			oTabbar.getItems()[5].addContent(oTable);*/
			if (tabSelectedKey === "Roster Number") {
				var rosterId;
				if (oTabbar.getItems()[0].getContent()[2].getContent()[0] === undefined) {
					oTabbar.getItems()[0].getContent()[2].addContent(oTable);
					rosterId = sap.ui.getCore().byId("rosterNumId").getValue();
					if (rosterId.trim().length > 0) {
						that.getGlobalSearchFunc(oTable, rosterId, "RosterNo");
					} else {
						sap.m.MessageToast.show(enterRostNo, {
							my: "center center",
							at: "center center",
							of: window
						});
					}
				} else {
					oTabbar.getItems()[0].getContent()[2].removeContent(0);
					oTabbar.getItems()[0].getContent()[2].addContent(oTable);
					rosterId = sap.ui.getCore().byId("rosterNumId").getValue();
					// that.getGlobalSearchFunc(oTable, gangId, "GangId");
					if (rosterId.trim().length > 0) {
						that.getGlobalSearchFunc(oTable, rosterId, "RosterNo");
					} else {
						sap.m.MessageToast.show(enterRostNo, {
							my: "center center",
							at: "center center",
							of: window
						});
					}
				}
			} else if (tabSelectedKey === "Department") {
				var Dept;
				if (oTabbar.getItems()[1].getContent()[2].getContent()[0] == undefined) {
					oTabbar.getItems()[1].getContent()[2].addContent(oTable);
					Dept = sap.ui.getCore().byId("departmentId").getValue();
					// that.getGlobalSearchFunc(oTable, gangDesc, "GangDesc");
					if (Dept.trim().length > 0) {
						that.getGlobalSearchFunc(oTable, Dept, "Department");
					} else {
						sap.m.MessageToast.show(enterDept, {
							my: "center center",
							at: "center center",
							of: window
						});
					}
				} else {
					oTabbar.getItems()[1].getContent()[2].removeContent(0);
					oTabbar.getItems()[1].getContent()[2].addContent(oTable);
					Dept = sap.ui.getCore().byId("departmentId").getValue();
					if (Dept.trim().length > 0) {
						that.getGlobalSearchFunc(oTable, Dept, "Department");
					} else {
						sap.m.MessageToast.show(enterDept, {
							my: "center center",
							at: "center center",
							of: window
						});
					}
				}
			} else if (tabSelectedKey === "Employee ID") {
				var empId;
				if (oTabbar.getItems()[2].getContent()[2].getContent()[0] === undefined) {
					oTabbar.getItems()[2].getContent()[2].addContent(oTable);
					empId = sap.ui.getCore().byId("employeeId").getValue();
					// that.getGlobalSearchFunc(oTable, gangAssSup, "AssSup");
					if (empId.trim().length > 0) {
						that.getGlobalSearchFunc(oTable, empId, "Employee");
					} else {
						sap.m.MessageToast.show(enterEmpId, {
							my: "center center",
							at: "center center",
							of: window
						});
					}
				} else {
					oTabbar.getItems()[2].getContent()[2].removeContent(0);
					oTabbar.getItems()[2].getContent()[2].addContent(oTable);
					empId = sap.ui.getCore().byId("employeeId").getValue();
					// that.getGlobalSearchFunc(oTable, gangAssSup, "AssSup");
					if (empId.trim().length > 0) {
						that.getGlobalSearchFunc(oTable, empId, "Employee");
					} else {
						sap.m.MessageToast.show(enterEmpId, {
							my: "center center",
							at: "center center",
							of: window
						});
					}
				}
			}

		},

		getGlobalSearchFunc: function (oTable, searchVal, searchField) {
			var that = this;

			var titleWaring = this.getView().getModel("i18n").getProperty("titleWaring");
			var ok = this.getView().getModel("i18n").getProperty("ok");

			var oModel = that.getOwnerComponent().getModel();
			// var oEffDate = that.byId("dateRangeId").getValue();
			var oController = that.getView().getController();
			var rosterModel = oTable.getModel("aModelData");
			var oFilterFinal = [];
			// oTable.unbindItems();
			// oTable.destroyItems();
			var oFilter1 = new sap.ui.model.Filter(searchField, "EQ", searchVal);
			oFilterFinal.push(oFilter1);
			var oFilterKey = new sap.ui.model.Filter("Key", "EQ", "T");
			oFilterFinal.push(oFilterKey);
			/*var oFilter2 = new sap.ui.model.Filter("EffectDate", "EQ", oEffDate);
			oFilterFinal.push(oFilter2);*/
			oTable.setBusy(true);
			oTable.setBusyIndicatorDelay(0);
			oModel.read("/RosterSearchhelpSet", {
				filters: oFilterFinal,
				async: true,
				success: function (oData, oResponse) {
					// that.byId("page").setBusy(false);
					// jQuery.sap.delayedCall(3000, this, function () {
					oTable.setBusy(false);
					// });
					var oTemplate = new sap.m.ColumnListItem({
						press: [oController.onRosterIdSubmit, oController],
						type: "Active",
						cells: [
							new sap.m.Text({
								text: "{aModelData>RosterNo}"
							}),
							new sap.m.Text({
								text: "{aModelData>RostDesc}"
							}),
							new sap.m.Text({
								text: "{aModelData>Union}"
							}),
							new sap.m.Text({
								text: "{aModelData>Department}"
							})
							/*,
														new sap.m.Text({
															text: "{aModelData>Status}"
														})*/
						]
					});
					rosterModel.setData(oData);
					var rosterTable = oTable;

					rosterTable.bindItems("aModelData>/results", oTemplate);

				},
				error: function (err) {
					oTable.setBusy(false);
					var errmsg = JSON.parse(err.responseText).error.message.value;

					sap.m.MessageBox.show(errmsg, {
						icon: sap.m.MessageBox.Icon.ERROR,
						title: "Error"
					});

					/*var oCreateDialog = new sap.m.Dialog();
					oCreateDialog.setTitle(titleWaring);
					oCreateDialog.setIcon("sap-icon://message-warning");
					oCreateDialog.addStyleClass(
						"dialogHdrBgCls dialogTitleCls dialogTextShadowCls dialogBoxShadowCls dialogIconCls dialogFooterBgCls");
					var oSimpleForm = new sap.ui.layout.form.SimpleForm({
						content: [
							new sap.m.Text({
								text: errmsg
							})
						]
					});
					oCreateDialog.addContent(oSimpleForm);

					oCreateDialog.addButton(
						new sap.m.Button({
							text: ok,
							press: function () {
								oCreateDialog.close();
							}
						}).addStyleClass("sapUiSizeCompact clsBtnColorYellowRed")
					);
					oCreateDialog.open();*/

				}
			});

		},

		onRosterIdSubmit: function (oEvent) {
			var that = this;
			// var oController = that.getView().getController();
			// that.resFlags = false;
			var oRosterPath = oEvent.getSource().getBindingContextPath();
			var oContext = oEvent.getSource().getParent().getModel("aModelData").getProperty(oRosterPath);
			var rosterValue = oContext.RosterNo;
			that.byId("rosterNoInp").setValue(rosterValue);
			that.sBackArray = [];
			that.rosterDialog.close();
		},

		onRosterCancel: function () {
			var that = this;
			var oTable = undefined;
			var RosterVal = that.byId("rosterNoInp").setValue();
			// var craft = that.byId("senCraftTpeId").getText();
			if (that.craftUnion === "Mechanical") {
				that.rosterDialog1.close();
			} else if (that.craftUnion === "TCU") {
				var oTabbar = sap.ui.getCore().byId("rosterMultiSearchId");
				oTabbar.setSelectedKey();
				var tab1 = oTabbar.getItems()[0].getContent()[2].getContent()[0];
				var tab2 = oTabbar.getItems()[1].getContent()[2].getContent()[0];
				var tab3 = oTabbar.getItems()[2].getContent()[2].getContent()[0];

				if (tab1 !== undefined) {
					sap.ui.getCore().byId("rosterNumId").setValue();
					oTable = oTabbar.getItems()[0].getContent()[2].removeContent(0);
				} else {
					sap.ui.getCore().byId("rosterNumId").setValue();
				}

				if (tab2 !== undefined) {
					sap.ui.getCore().byId("departmentId").setValue();
					oTable = oTabbar.getItems()[1].getContent()[2].removeContent(0);
				} else {
					sap.ui.getCore().byId("departmentId").setValue();
				}

				if (tab3 !== undefined) {
					sap.ui.getCore().byId("employeeId").setValue();
					oTable = oTabbar.getItems()[2].getContent()[2].removeContent(0);
				} else {
					sap.ui.getCore().byId("employeeId").setValue();
				}

				that.rosterDialog.close();
			} else if (that.craftUnion === "Engineering") {
				that.rosterDialog2.close();
			}

		},

		//EmpSen
		onEmpSenMaintSearch: function (oEvent) {
			if (this.byId("saveBtn").getVisible() && this.byId("saveBtn").getEnabled()) {
				sap.m.MessageToast.show("Please save/cancel the unsaved data");
				return;
			}
			var that = this;
			var oEmpSenVal = oEvent.getSource().getValue();
			var oRosterSearchTable;
			if (!that.onEmpSenDialog) {

				that.onEmpSenDialog = sap.ui.xmlfragment("com.empqualassignment.Employee_Qual_Assignment.fragment.EmployeeId", that.getView()
					.getController());
				that.getView().addDependent(that.onEmpSenDialog);

			}
			// that._gangMaintenanceValueDialog.getAggregation("content")[0].getAggregation("content")[0].setValue(oGangId);
			var oRosterSearchModel = new sap.ui.model.json.JSONModel({
				results: []
			});
			oRosterSearchTable = sap.ui.getCore().byId("empTableId");
			oRosterSearchTable.setModel(oRosterSearchModel, "oEmpData");
			that.onEmpSenDialog.open();

			that.onEmpSenDialog.setEscapeHandler(function (o) {
				o.reject();
			});

			if (oEmpSenVal.length < 1) {
				sap.ui.getCore().byId("empSearchId").setValue();
				that.byId("empSenMaintTable").getModel("empSenMaintModel").setData({});
				oRosterSearchTable.getModel("oEmpData").setData({});
				oRosterSearchTable.getModel("oEmpData").refresh();
				that.byId("empSenMaintDescId").setText();
				that.byId("empSenMaintStatusId").setText();

			} else {
				sap.ui.getCore().byId("empSearchId").setValue(oEmpSenVal);
				sap.ui.getCore().byId("empSearchId").fireSearch();

				that.byId("empSenMaintDescId").setText();
				that.byId("empSenMaintStatusId").setText();
			}

		},

		onEmpLive: function (oEvent) {
			var that = this;
			var oEmpSen = oEvent.getSource();
			var oEmpVal = oEmpSen.getValue();
			if (oEmpVal.length < 1) {
				sap.ui.getCore().byId("empSearchId").setValue();
				var oTable = sap.ui.getCore().byId("empTableId");
				oTable.getModel("oEmpData").setData({});
				oTable.getModel("oEmpData").refresh();
				that.byId("empSenMaintTable").getModel("empSenMaintModel").setData({});
				that.byId("empSenMaintTable").getModel("empSenMaintModel").refresh();
				that.byId("empSenMaintDescId").setText();
				that.byId("empSenMaintStatusId").setText();
				that.employeeIDN = "";
				that.empStatus = "";
				that.empName = "";
				that.onReset();
			}

		},

		onHomeZoneLive: function (oEvent) {
			var that = this;
			var oEmpHomeZone = oEvent.getSource();
			var oEmpVal = oEmpHomeZone.getValue();
			if (oEmpVal.length < 1) {
				//sap.ui.getCore().byId("empHomeZoneSearch").setValue();
				var oTable = sap.ui.getCore().byId("empTableId");
				oTable.getModel("oEmpData").setData({});
				oTable.getModel("oEmpData").refresh();
				that.byId("empRrHiredDropDown").setSelectedKey("");
				that.byId("empDataEffDateHZ").setValue();
				that.byId("empHomeZoneDropDown").setSelectedKey("");
				that.byId("empHomeZoneTable").getModel("empHomeZoneModel").setData({});
				that.byId("empHomeZoneTable").getModel("empHomeZoneModel").refresh();
				that.byId("empHomeZoneDescId").setText();
				that.byId("empHomeZoneStatusId").setText();
				that.employeeIDN = "";
				that.empStatus = "";
				that.empName = "";
			}

		},

		onAdditionalSenInfoLive: function (oEvent) {
			var that = this;
			var oEmpAddSenInfo = oEvent.getSource();
			var oEmpVal = oEmpAddSenInfo.getValue();
			if (oEmpVal.length < 1) {
				// sap.ui.getCore().byId("empAdditionalSenInfoSearch").setValue();
				var oTable = sap.ui.getCore().byId("empTableId");
				oTable.getModel("oEmpData").setData({});
				oTable.getModel("oEmpData").refresh();
				that.byId("empAdditionalSenInfoTable").getModel("empAdditionalSenInfoModel").setData({});
				that.byId("empAdditionalSenInfoTable").getModel("empAdditionalSenInfoModel").refresh();
				that.byId("empAdditionalSenInfoDescId").setText();
				that.byId("empAdditionalSenInfoStatusId").setText();
				that.employeeIDN = "";
				that.empStatus = "";
				that.empName = "";
			}

		},

		onEmpCancel: function () {
			var that = this;
			// var oEmpSenVal = that.byId("empSenMaintenanceSearch").getTokens()[0].getKey();
			var oEmpSenVal = "";
			if (that.byId("empSenMaintenanceSearch").getTokens().length > 0) {
				oEmpSenVal = that.byId("empSenMaintenanceSearch").getTokens()[0].getKey();
			}
			if (oEmpSenVal.length < 1) {
				sap.ui.getCore().byId("empSearchId").setValue();
				var oTable = sap.ui.getCore().byId("empTableId");
				oTable.getModel("oEmpData").setData({});
				oTable.getModel("oEmpData").refresh();
				that.byId("empSenMaintDescId").setText();
				that.byId("empSenMaintStatusId").setText();
			}
			that.onEmpSenDialog.close();
		},

		onEmpSearch: function (oEvent) {
			var that = this;
			var union;
			var oSelRole = that.byId("roleId").getSelectedItem().getProperty("text");
			if (oSelRole === "Super PM Admin") {
				if (that.craftUnion === "Engineering") {
					union = "SE";
				} else if (that.craftUnion === "Mechanical") {
					union = "SM";
				} else if (that.craftUnion === "TCU") {
					union = "ST";
				} else if (that.craftUnion === "ATDA") {
					union = "SD";
				} else if (that.craftUnion === "ILA") {
					union = "SL";
				} else if (that.craftUnion === "Conrail") {
					union = "SC";
				} else if (that.craftUnion === "IHB") {
					union = "SI";
				} else if (that.craftUnion === "NAHR") {
					union = "SN";
				} else if (that.craftUnion === "Payroll") {
					union = "P";
				}
			} else if (oSelRole === "Supervisor") {
				union = "CH";
			} else {
				if (that.craftUnion === "Engineering") {
					union = "E";
				} else if (that.craftUnion === "Mechanical") {
					union = "M";
				} else if (that.craftUnion === "TCU") {
					union = "T";
				} else if (that.craftUnion === "ATDA") {
					union = "D";
				} else if (that.craftUnion === "ILA") {
					union = "L";
				} else if (that.craftUnion === "Conrail") {
					union = "C";
				} else if (that.craftUnion === "IHB") {
					union = "I";
				} else if (that.craftUnion === "NAHR") {
					union = "N";
				} else if (that.craftUnion === "Payroll") {
					union = "P";
				}
			}
			var oEmpVal = oEvent.getSource().getValue();
			var oModel = that.getOwnerComponent().getModel();
			var oFilterFinal = [];
			var oEmpFil = new sap.ui.model.Filter("EmpNo", "EQ", oEmpVal);
			oFilterFinal.push(oEmpFil);
			var operFil = new sap.ui.model.Filter("Operation", "EQ", "F");
			oFilterFinal.push(operFil);
			var craftFil = new sap.ui.model.Filter("Craft", "EQ", union);
			oFilterFinal.push(craftFil);
			var oJSONModel = new sap.ui.model.json.JSONModel();
			var oTable = sap.ui.getCore().byId("empTableId");
			oTable.setBusy(true);
			oTable.setBusyIndicatorDelay(0);
			oModel.read("/EmpSenHDataSet", {
				filters: oFilterFinal,
				async: true,
				success: function (oData) {
					oTable.setBusy(false);
					if (oData.results.length > 0) {
						oJSONModel.setData(oData);
					} else {
						oJSONModel.setData({});
					}
				},
				error: function (err) {
					oTable.setBusy(false);
				}
			});

			oTable.setModel(oJSONModel, "oEmpData");
			oTable.getModel("oEmpData").refresh();
		},

		onEmpSubmit: function (oEvent) {
			var that = this;
			var selTab = that.byId("IconTabbarId").getSelectedKey();
			var roleGetSelectedKey = that.byId("roleId").getSelectedKey();
			var oRosterPath = oEvent.getSource().getBindingContextPath();
			var oContext = oEvent.getSource().getParent().getModel("oEmpData").getProperty(oRosterPath);
			// var rosterValue = oContext.RosterNo;
			var oEmpval = oContext.EmpNo;
			var oEmpDesc = oContext.EmpName;
			var oStatus = oContext.Status;

			// setting employee value to global to have it across all tabs			
			this.employeeIDN = oEmpval;
			this.empStatus = oStatus;
			this.empName = oEmpDesc;
			if (selTab === "empSenMaint") {
				that.onEmpSenGetFunc(oEmpval);
				// that.byId("empSenMaintenanceSearch").setValue(oEmpval);
				that.byId("empSenMaintenanceSearch").setTokens([new sap.m.Token({
					text: oEmpval,
					key: oEmpval
				})]);
				that.byId("empSenMaintDescId").setText(oEmpDesc + " | " + oContext.PosID);
				that.byId("empSenMaintStatusId").setText(oStatus);
			} else if (selTab === "empHomeZone") {
				// that.byId("empHomeZoneSearch").setValue(oEmpval);
				that.byId("empHomeZoneSearch").setTokens([new sap.m.Token({
					text: oEmpval,
					key: oEmpval
				})]);
				that.onEmpHomeZoneAdditionalSenInfoGetFunc(oEmpval);
				that.byId("empHomeZoneDescId").setText(oEmpDesc + " | " + oContext.PosID);
				that.byId("empHomeZoneStatusId").setText(oStatus);
			} else if (selTab === "additionalSenInfo") {
				that.onEmpHomeZoneAdditionalSenInfoGetFunc(oEmpval);
				// that.byId("empAdditionalSenInfoSearch").setValue(oEmpval);
				that.byId("empAdditionalSenInfoSearch").setTokens([new sap.m.Token({
					text: oEmpval,
					key: oEmpval
				})]);
				that.byId("empAdditionalSenInfoDescId").setText(oEmpDesc + " | " + oContext.PosID);
				that.byId("empAdditionalSenInfoStatusId").setText(oStatus);
			} else if (selTab === "empQualAssign") {
				// that.byId("empDataEmpNoInp").setDescription(oEmpDesc);
				that.byId("empDataEmpNoInpDesc").setText(oEmpDesc);
			}

			var oModel1 = that.getOwnerComponent().getModel("oDataSrv");
			oModel1.read("/QualReqDetailsSet?$filter=EmpId eq '" + oEmpval + "'", {
				async: true,
				success: function (oData1) {
					// that.getView().setBusy(false);
					// that.QualArray = oData1;
					var oReqDetailsModel = new sap.ui.model.json.JSONModel(oData1);
					var oTable1 = that.byId("qualTable");
					oTable1.setModel(oReqDetailsModel, "oModelData");
				}
			});

			// that.senEmpChangeFlag = true;
			if (that.deptSelectedKey === "CH") {
				var oModel1 = that.getOwnerComponent().getModel("oDataSrv");
				oModel1.read("/QualiSearchHelpSet?$filter=EmpNo eq '" + oEmpval + "'", {
					async: true,
					success: function (oData1) {
						// that.getView().setBusy(false);
						that.QualArray = oData1;
						// var oReqDetailsModel = new sap.ui.model.json.JSONModel(oData1);
						// var oTable1 = that.byId("qualReqDetailsTableId1");
						// oTable1.setModel(oReqDetailsModel, "qualReqDetailsModel");
					}
				});
			}
			if (roleGetSelectedKey !== "LR") {
				that.senEmpChangeFlag = true;
			}

			that.selTab = that.byId("IconTabbarId").getSelectedKey();
			that.onEmpSenDialog.close();
		},

		onEmpSenGetFunc: function (oEmpval) {
			var that = this;

			var union;
			if (that.craftUnion === "Engineering") {
				union = "E";
			} else if (that.craftUnion === "Mechanical") {
				union = "M";
			} else if (that.craftUnion === "TCU") {
				union = "T";
			} else if (that.craftUnion === "ATDA") {
				union = "A";
			} else if (that.craftUnion === "ILA") {
				union = "L";
			} else if (that.craftUnion === "Conrail") {
				union = "C";
			} else if (that.craftUnion === "IHB") {
				union = "I";
			} else if (that.craftUnion === "NAHR") {
				union = "N";
			} else if (that.craftUnion === "Payroll") {
				union = "P";
			}
			var effdate = that.byId("empDataEffDate").getValue();
			var effdateValue = effdate.split("/")[2] + effdate.split("/")[0] + effdate.split("/")[1];
			var oModel = that.getOwnerComponent().getModel();
			var oTable = that.byId("empSenMaintTable");
			var userRequestBody1 = {
				"EmpNo": oEmpval,
				"Operation": "F",
				"Craft": union,
				"Effdate": effdateValue
			};

			var items = [];

			var oResults1 = {

				"results": items
			};
			userRequestBody1.EmpSen = oResults1;
			// var bDialog = new sap.m.BusyDialog({});
			// bDialog.open();<!--submitBtn autoPopulateId-->
			that.byId("empQualAssignmentPage").setBusy(true);
			that.byId("empQualAssignmentPage").setBusyIndicatorDelay(0);
			oModel.create("/EmpSenHDataSet()", userRequestBody1, {
				async: true,
				success: function (oData, oResponse) {
					that.byId("empQualAssignmentPage").setBusy(false);
					var returnData = oResponse.data.EmpSen;
					oTable.getModel("empSenMaintModel").setData(returnData);
					oTable.getModel("empSenMaintModel").refresh();
					/*	var oEmpItems = returnData.results.slice();
						that.getView().getModel("oEmpItemModel").setData({
							results: oEmpItems
						});*/

					// that.DPGPosDataChange = true;
					/*	that.byId("submitBtn").setVisible(true);
						that.byId("submitBtn").setEnabled(true);
						that.byId("autoPopulateId").setVisible(false);*/

				},
				error: function (oResponse) {
					// var data2 = oResponse;
					that.byId("empQualAssignmentPage").setBusy(false);
				}
			});
		},
		//-----------------------------------------------------------------------	
		// Table data download.
		//-----------------------------------------------------------------------

		createColumnConfig: function () {
			if (this.craftUnion === "Engineering") {
				return [ //added below logic Employee on 07/19/2021 - D5OW5 - NewReq
					{
						label: "Employee",
						property: "EmpNo",
						type: "string"
					}, {
						label: "Roster Number",
						property: "RostNo",
						type: "string",
						scale: 0
					}, {
						label: "Roster Description",
						property: "RostDesc",
						type: "string",
						width: '25'
					}, {
						label: "Seniority Date",
						property: "SenDate",
						type: "string",
						width: "25"
					},

					{
						label: "Seniority Effective Date",
						property: "SenDate",
						type: "string"
					}, {
						label: "Seniority End Date",
						property: "EndDate",
						type: "string"
					},

					{
						label: "Frozen Date",
						property: "FrozenDate",
						type: "string"
					}, {
						label: "Union",
						property: "UnionCode",
						type: "string"
					}, {
						label: "Region",
						property: "Region",
						type: "string"
					}, {
						label: "Seniority Suspension Start Date",
						property: "SuspSdate",
						type: "string"
					}, {
						label: "Seniority Suspension End Date",
						property: "SuspEdate",
						type: "string"
					}, {
						label: "RR Code",
						property: "RRCode",
						type: "string"
					},

					{
						label: "District",
						property: "District",
						type: "string"
					}, {
						label: "Division",
						property: "Division",
						type: "string"
					}, {
						label: "Override Date",
						property: "OverrideDate",
						type: "string",
						width: "18"
					}, {
						label: "Override Number",
						property: "OverrideSeq",
						type: "string",
						width: "18"
					}, {
						label: "DPG Zone",
						property: "DPGZone",
						type: "string"
					}, {
						label: "Remarks",
						property: "Remarks",
						type: "string"
					}
				];
			} else if (this.craftUnion === "Mechanical") {
				return [ //added below logic Employee on 07/19/2021 - D5OW5 - NewReq
					{
						label: "Employee",
						property: "EmpNo",
						type: "string"
					}, {
						label: "Roster Number",
						property: "RostNo",
						type: "string",
						scale: 0
					}, {
						label: "Roster Description",
						property: "RostDesc",
						type: "string",
						width: '25'
					}, {
						label: "Seniority Effective Date",
						property: "SenDate",
						type: "string"
					}, {
						label: "Seniority End Date",
						property: "EndDate",
						type: "string"
					}, {
						label: "Override Date",
						property: "OverrideDate",
						type: "string",
						width: "18"
					}, {
						label: "Override Number",
						property: "OverrideSeq",
						type: "string",
						width: "18"
					}, {
						label: "Frozen Date",
						property: "FrozenDate",
						type: "string"
					}, {
						label: "Union",
						property: "UnionCode",
						type: "string"
					}, {
						label: "Territory",
						property: "Territory",
						type: "string"
					}, {
						label: "Seniority Suspension Start Date",
						property: "SuspSdate",
						type: "string"
					}, {
						label: "Seniority Suspension End Date",
						property: "SuspEdate",
						type: "string"
					}, {
						label: "Remarks",
						property: "Remarks",
						type: "string"
					}
				];
			} else {
				return [ //added below logic Employee on 07/19/2021 - D5OW5 - NewReq
					{
						label: "Employee",
						property: "EmpNo",
						type: "string"
					}, {
						label: "Roster Number",
						property: "RostNo",
						type: "string",
						scale: 0
					}, {
						label: "Roster Description",
						property: "RostDesc",
						type: "string",
						width: '25'
					}, {
						label: "Seniority Effective Date",
						property: "SenDate",
						type: "string"
					}, {
						label: "Seniority End Date",
						property: "EndDate",
						type: "string"
					}, {
						label: "Override Date",
						property: "OverrideDate",
						type: "string",
						width: "18"
					}, {
						label: "Override Number",
						property: "OverrideSeq",
						type: "string",
						width: "18"
					}, {
						label: "Frozen Date",
						property: "FrozenDate",
						type: "string"
					}, {
						label: "Location/Department",
						property: "Location",
						type: "string"
					}, {
						label: "Seniority Suspension Start Date",
						property: "SuspSdate",
						type: "string"
					}, {
						label: "Seniority Suspension End Date",
						property: "SuspEdate",
						type: "string"
					}, {
						label: "Remarks",
						property: "Remarks",
						type: "string"
					}
				];
			}
		},

		onExport: function () {
			var that = this;
			// var exportSuccessMsg = this.getView().getModel("i18n").getProperty("spreadSheetExpSucMsg");
			// var noRecords = this.getView().getModel("i18n").getProperty("noRecords");

			var tableItems = this.byId("empSenMaintTable").getItems();
			if (tableItems.length > 0) {
				var aCols, aQuals, oSettings, oSheet;
				aCols = this.createColumnConfig();
				aQuals = this.getView().byId("empSenMaintTable").getModel("empSenMaintModel").getData().results;

				for (var i = 0; i < aQuals.length; i++) {
					var senDate = aQuals[i].SenDate;
					var senYear = senDate.slice("0", "4");
					var senMonth = senDate.slice("4").slice("0", "2");
					var senDay = senDate.slice("6");
					var senFormatedDate = senMonth + "/" + senDay + "/" + senYear;
					if (senFormatedDate === "//") {
						senFormatedDate = "";
					}
					aQuals[i].SenDate = senFormatedDate;
					var bDate = aQuals[i].EndDate;
					var bYear = bDate.slice("0", "4");
					var bMonth = bDate.slice("4").slice("0", "2");
					var bDay = bDate.slice("6");
					var bFormatedDate = bMonth + "/" + bDay + "/" + bYear;
					if (bFormatedDate === "//") {
						bFormatedDate = "";
					}
					aQuals[i].EndDate = bFormatedDate;
					var senDate = aQuals[i].FrozenDate;
					var senYear = senDate.slice("0", "4");
					var senMonth = senDate.slice("4").slice("0", "2");
					var senDay = senDate.slice("6");
					var senFormatedDate = senMonth + "/" + senDay + "/" + senYear;
					if (senFormatedDate === "//") {
						senFormatedDate = "";
					}
					aQuals[i].FrozenDate = senFormatedDate;
					var bDate = aQuals[i].OverrideDate;
					var bYear = bDate.slice("0", "4");
					var bMonth = bDate.slice("4").slice("0", "2");
					var bDay = bDate.slice("6");
					var bFormatedDate = bMonth + "/" + bDay + "/" + bYear;
					if (bFormatedDate === "//") {
						bFormatedDate = "";
					}
					aQuals[i].OverrideDate = bFormatedDate;
					var senDate = aQuals[i].SuspSdate;
					var senYear = senDate.slice("0", "4");
					var senMonth = senDate.slice("4").slice("0", "2");
					var senDay = senDate.slice("6");
					var senFormatedDate = senMonth + "/" + senDay + "/" + senYear;
					if (senFormatedDate === "//") {
						senFormatedDate = "";
					}
					aQuals[i].SuspSdate = senFormatedDate;
					var bDate = aQuals[i].SuspEdate;
					var bYear = bDate.slice("0", "4");
					var bMonth = bDate.slice("4").slice("0", "2");
					var bDay = bDate.slice("6");
					var bFormatedDate = bMonth + "/" + bDay + "/" + bYear;
					if (bFormatedDate === "//") {
						bFormatedDate = "";
					}
					aQuals[i].SuspEdate = bFormatedDate;

					// Insert Begin - on 07/19/2021 - D5OW5 - NewReq					
					var empNo = aQuals[i].EmpNo;
					var empName = that.getView().byId("empSenMaintDescId").getText();
					aQuals[i].EmpNo = empNo + " - " + empName.split("|")[0];
					// Insert End - on 07/19/2021 - D5OW5 - NewReq						
				}

				oSettings = {
					workbook: {
						columns: aCols
					},
					dataSource: aQuals
				};
				oSheet = new Spreadsheet(oSettings);
				oSheet.build()
					.then(function () {
						sap.m.MessageToast.show("Exported Successfuly");
					})
					.finally(function () {
						oSheet.destroy();
					});
			} else {
				sap.m.MessageToast.show("No Records");
			}

		},
		onEmpHomeZoneAdditionalSenInfoGetFunc: function (oEmpval, oEffDate) {
			var that = this;

			var selTab = that.byId("IconTabbarId").getSelectedKey();

			var oTable;
			var model;
			var key;
			if (selTab === "empHomeZone") {
				oTable = that.byId("empHomeZoneTable");
				model = "empHomeZoneModel";
				key = "H";
			} else if (selTab === "additionalSenInfo") {
				oTable = that.byId("empAdditionalSenInfoTable");
				model = "empAdditionalSenInfoModel";
				key = "A";
			}

			var listFil = [];
			var empNo = new sap.ui.model.Filter("EmpNo", "EQ", oEmpval);
			var tabKey = new sap.ui.model.Filter("Key", "EQ", key);
			listFil.push(empNo);
			listFil.push(tabKey);
			// ++ Insert Begin - D5OW5 on 07/27/2021 - Effective Date change is not working on all tabs except Qual. asg tab		
			if (oEffDate !== undefined) {
				var effDate = new sap.ui.model.Filter("Effdate", "EQ", oEffDate);
				listFil.push(effDate);
			}
			// ++ Insert End - D5OW5 on 07/27/2021 - Effective Date change is not working on all tabs except Qual. asg tab

			that.byId("empQualAssignmentPage").setBusy(true);
			that.byId("empQualAssignmentPage").setBusyIndicatorDelay(0);
			var oModel = that.getOwnerComponent().getModel();
			oModel.read("/EmpHomeSenSet", {
				filters: listFil,
				success: function (oData, oResponse) {
					that.byId("empQualAssignmentPage").setBusy(false);
					for (var i = 0; i < oData.results.length; i++) {
						oData.results[i].Key = "B";
						that.byId("empHomeZoneDropDown").setSelectedKey(oData.results[i].HomeZone);
						that.byId("empRrHiredDropDown").setSelectedKey(oData.results[i].RRHired);
						that.byId("empHomeZoneDropDown").setValue(oData.results[i].HomeZone);
						that.byId("empRrHiredDropDown").setValue(oData.results[i].RRHired);
						that.byId("empDataEffDateHZ").setValue(oData.results[i].BeginDate);
						that.byId("divDropDownHZ").setValue(oData.results[i].Division); //++D5OW5 - Dt 03/10/2022
						that.byId("districtDropDownHZ").setValue(oData.results[i].District); //++D5OW5 - Dt 03/10/2022
						that.byId("PriorRights").setValue(oData.results[i].PRRegion); //++D5OW5 - Dt 03/10/2022
						that.byId("Classification").setValue(oData.results[i].Classification); //++D5OW5 - Dt 03/10/2022
					}
					oTable.getModel(model).setData(oData);
					oTable.getModel(model).refresh();
				},
				error: function (oResponse) {
					that.byId("empQualAssignmentPage").setBusy(false);
				}
			});
		},

		onEmpSenMaintAdd: function (oEvent) {
			var that = this;

			var selEmpId = this.getView().getModel("i18n").getProperty("selEmpId");
			var rostNoAlreadyExists = this.getView().getModel("i18n").getProperty("rostNoAlreadyExists");

			// that.sFinalArray = [];

			var oModel = that.getOwnerComponent().getModel();
			var oTable = that.byId("empSenMaintTable");
			// var empVal = that.byId("empSenMaintenanceSearch").getTokens()[0].getKey();
			var empVal = "";
			if (that.byId("empSenMaintenanceSearch").getTokens().length > 0) {
				empVal = that.byId("empSenMaintenanceSearch").getTokens()[0].getKey();
			}
			var oResults = oTable.getModel("empSenMaintModel").getData().results; /*.getProperty("/results");*/
			var oRosterNo = that.byId("rosterNoInp").getValue();
			var oSenDate = that.byId("rosterSenDateId").getValue().trim();
			var oOverrideDate = that.byId("rosterOverrideSenDateId").getValue().trim();
			var oFrozenDate = that.byId("rosterFrozenSenDateId").getValue().trim();
			var oCraft = that.byId("empSenCraftInp").getSelectedKey().trim();
			var oDivision = that.byId("empSenDivisionInp").getValue().trim();
			var oRrCode = that.byId("empSenRrCodeInp").getValue().trim();
			var oDistrict = that.byId("empSenDistrictInp").getValue().trim();
			var oDpgZone = that.byId("empSenDpgZoneInp").getValue().trim();
			var oOverrideNo = that.byId("rosterOverrideNo").getValue().trim();
			var deptValue = that.byId("empSenDeptInp").getSelectedKey().trim();
			// var senDate = oSenDate.split("/")[2] + oSenDate.split("/")[0] + oSenDate.split("/")[1];
			var oRemarks = that.byId("empRemarksId").getValue().trim();
			var oFlag = true;

			if (that.craftUnion === "Engineering") {

				if (oRosterNo.length < 1) {
					oFlag = false;
					// that.byId("rosterNoInp").setValueState("Error");
				} else {
					// that.byId("rosterNoInp").setValueState("None");
				}
				if (empVal.length < 1) {
					oFlag = false;
					sap.m.MessageToast.show(selEmpId);
				}
				if ((oSenDate.length < 8) && (that.byId("rosterSenDateId").getValueFormat !== "yyyyMMdd")) {
					oFlag = false;
					that.byId("rosterSenDateId").setValueState("Error");
				} else {
					that.byId("rosterSenDateId").setValueState("None");
				}
				// if ((oOverrideDate.length < 8) && (that.byId("rosterOverrideSenDateId").getValueFormat !== "yyyyMMdd")) {
				// 	oFlag = false;
				// 	that.byId("rosterOverrideSenDateId").setValueState("Error");
				// } else {
				// 	that.byId("rosterOverrideSenDateId").setValueState("None");
				// }
				// if ((oFrozenDate.length < 8) && (that.byId("rosterFrozenSenDateId").getValueFormat !== "yyyyMMdd")) {
				// 	oFlag = false;
				// 	that.byId("rosterFrozenSenDateId").setValueState("Error");
				// } else {
				// 	that.byId("rosterFrozenSenDateId").setValueState("None");
				// }
				if (oDivision.length < 1) {
					oFlag = false;
					that.byId("empSenDivisionInp").setValueState("Error");
				} else {
					that.byId("empSenDivisionInp").setValueState("None");
				}
				if (oRrCode.length < 1) {
					oFlag = false;
					that.byId("empSenRrCodeInp").setValueState("Error");
				} else {
					that.byId("empSenRrCodeInp").setValueState("None");
				}
				if (oDistrict.length < 1) {
					oFlag = false;
					that.byId("empSenDistrictInp").setValueState("Error");
				} else {
					that.byId("empSenDistrictInp").setValueState("None");
				}
				// if (oDpgZone.length < 1) {
				// 	oFlag = false;
				// 	that.byId("empSenDpgZoneInp").setValueState("Error");
				// } else {
				// 	that.byId("empSenDpgZoneInp").setValueState("None");
				// }
				// if (oOverrideNo.length < 1) {
				// 	oFlag = false;
				// 	that.byId("rosterOverrideNo").setValueState("Error");
				// } else {
				// 	that.byId("rosterOverrideNo").setValueState("None");
				// }

			} else if (that.craftUnion === "Mechanical") {

				if (oRosterNo.length < 1) {
					oFlag = false;
					// that.byId("rosterNoInp").setValueState("Error");
				} else {
					// that.byId("rosterNoInp").setValueState("None");
				}
				if (empVal.length < 1) {
					oFlag = false;
					sap.m.MessageToast.show(selEmpId);
				}
				if ((oSenDate.length < 8) && (that.byId("rosterSenDateId").getValueFormat !== "yyyyMMdd")) {
					oFlag = false;
					that.byId("rosterSenDateId").setValueState("Error");
				} else {
					that.byId("rosterSenDateId").setValueState("None");
				}
				// if ((oOverrideDate.length < 8) && (that.byId("rosterOverrideSenDateId").getValueFormat !== "yyyyMMdd")) {
				// 	oFlag = false;
				// 	that.byId("rosterOverrideSenDateId").setValueState("Error");
				// } else {
				// 	that.byId("rosterOverrideSenDateId").setValueState("None");
				// }
				// if ((oFrozenDate.length < 8) && (that.byId("rosterFrozenSenDateId").getValueFormat !== "yyyyMMdd")) {
				// 	oFlag = false;
				// 	that.byId("rosterFrozenSenDateId").setValueState("Error");
				// } else {
				// 	that.byId("rosterFrozenSenDateId").setValueState("None");
				// }
				if (oCraft.length < 1) {
					oFlag = false;
					that.byId("empSenCraftInp").setValueState("Error");
				} else {
					that.byId("empSenCraftInp").setValueState("None");
				}
				// if (oOverrideNo.length < 1) {
				// 	oFlag = false;
				// 	that.byId("rosterOverrideNo").setValueState("Error");
				// } else {
				// 	that.byId("rosterOverrideNo").setValueState("None");
				// }

			} else if (that.craftUnion === "TCU" || that.craftUnion === "ATDA" || that.craftUnion === "ILA") {

				if (oRosterNo.length < 1) {
					oFlag = false;
					// that.byId("rosterNoInp").setValueState("Error");
				} else {
					// that.byId("rosterNoInp").setValueState("None");
				}
				if (empVal.length < 1) {
					oFlag = false;
					sap.m.MessageToast.show(selEmpId);
				}
				if ((oSenDate.length < 8) && (that.byId("rosterSenDateId").getValueFormat !== "yyyyMMdd")) {
					oFlag = false;
					that.byId("rosterSenDateId").setValueState("Error");
				} else {
					that.byId("rosterSenDateId").setValueState("None");
				}
				// if ((oOverrideDate.length < 8) && (that.byId("rosterOverrideSenDateId").getValueFormat !== "yyyyMMdd")) {
				// 	oFlag = false;
				// 	that.byId("rosterOverrideSenDateId").setValueState("Error");
				// } else {
				// 	that.byId("rosterOverrideSenDateId").setValueState("None");
				// }
				// if ((oFrozenDate.length < 8) && (that.byId("rosterFrozenSenDateId").getValueFormat !== "yyyyMMdd")) {
				// 	oFlag = false;
				// 	that.byId("rosterFrozenSenDateId").setValueState("Error");
				// } else {
				// 	that.byId("rosterFrozenSenDateId").setValueState("None");
				// }
				// Begin of comment - D5OW5 - 08/19/2021
				// if (oOverrideNo.length < 1) {
				// 	oFlag = false;
				// 	that.byId("rosterOverrideNo").setValueState("Error");
				// } else {
				// 	that.byId("rosterOverrideNo").setValueState("None");
				// }
				// End of Comment -D5OW5 - 08/19/2021

			}

			if (oFlag) {

				var union;
				if (that.craftUnion === "Engineering") {
					union = "E";
				} else if (that.craftUnion === "Mechanical") {
					union = "M";
				} else if (that.craftUnion === "TCU") {
					union = "T";
				} else if (that.craftUnion === "ATDA") {
					union = "A";
				} else if (that.craftUnion === "ILA") {
					union = "L";
				} else if (that.craftUnion === "Conrail") {
					union = "C";
				} else if (that.craftUnion === "IHB") {
					union = "I";
				} else if (that.craftUnion === "NAHR") {
					union = "N";
				} else if (that.craftUnion === "Payroll") {
					union = "P";
				}

				var oFilter = [];
				var oRostFil = new sap.ui.model.Filter("RostNo", "EQ", oRosterNo);
				oFilter.push(oRostFil);
				var oCraftFil = new sap.ui.model.Filter("Craft", "EQ", union);
				oFilter.push(oCraftFil);
				var oEmpFil = new sap.ui.model.Filter("EmpNo", "EQ", empVal);
				oFilter.push(oEmpFil);
				var oModel = that.getOwnerComponent().getModel();
				var oTable = that.byId("empSenMaintTable");
				var userRequestBody1 = {
					"EmpNo": empVal,
					"Operation": "S",
					"Craft": union
				};

				// if ()
				// var SenDate = oSenDate;
				if (oSenDate.includes("/") === true) {
					var oSenDate1 = oSenDate.split("/");
					oSenDate = oSenDate1[2] + "" + oSenDate1[0] + "" + oSenDate1[1];
				}
				// if (FrozenDate.includes("/") === true) {
				// 	var FrozenDate1 = FrozenDate.split("/");
				// 	FrozenDate = FrozenDate1[2] + "" + FrozenDate1[0] + "" + FrozenDate1[1];
				// }
				var items = [];
				var oObject = {};
				oObject.Action = "A";
				oObject.SenDate = oSenDate;
				oObject.RostNo = that.rosterNo;
				oObject.RostDesc = that.rosterDesc;
				oObject.Remarks = oRemarks;
				oObject.OverrideDate = oOverrideDate;
				oObject.OverrideSeq = oOverrideNo;
				oObject.FrozenDate = oFrozenDate;
				oObject.Craft = oCraft;
				oObject.Division = oDivision;
				oObject.RRCode = oRrCode;
				oObject.District = oDistrict;
				oObject.DPGZone = oDpgZone;
				oObject.Department = deptValue;
				oObject.City = that.city;
				oObject.Territory = that.territory;
				oObject.UnionCode = that.union;
				oObject.Region = that.region;
				oObject.DRostNo = that.addilRoster;
				items.push(oObject);
				var oResults1 = {
					"results": items
				};
				userRequestBody1.EmpSen = oResults1;
				// var bDialog = new sap.m.BusyDialog({});
				// bDialog.open();<!--submitBtn autoPopulateId-->
				that.byId("empQualAssignmentPage").setBusy(true);
				that.byId("empQualAssignmentPage").setBusyIndicatorDelay(0);
				oModel.create("/EmpSenHDataSet", userRequestBody1, {
					async: true,
					success: function (oData, Response) {
						that.byId("empQualAssignmentPage").setBusy(false);
						if (oData.EmpSen.results.length > 0) {
							var noDupFlag = true;
							for (var y = 0; y < oResults.length; y++) {
								var selectedRost = oResults[y].RostNo;
								var senDateValue = oResults[y].SenDate.substring(0, 4) + "/" + oResults[y].SenDate.substring(4, 6) + "/" + oResults[y].SenDate
									.substring(6, 8);
								/*for (var z = 0; z < that.assinedArray.length; z++) {*/
								if (oData.EmpSen.results[0].RostNo === selectedRost) {
									var bCompact2 = !!that.getView().$().closest(".sapUiSizeCompact").length;
									sap.m.MessageBox.error(
										"Seniority for this Roster already exists with effective date " + senDateValue, {
											styleClass: bCompact2 ? "sapUiSizeCompact" : ""
										}
									);
									y = oResults.length;
									noDupFlag = false;
								}
							}
							if (that.addilRoster === "" && oData.EmpSen.results[0].EngPopup === "X") {
								var data = [{
									Name: "H07911"
								}, {
									Name: "H07912"
								}, {
									Name: "H07913"
								}];
								var oModelTotalData = new sap.ui.model.json.JSONModel(data);
								that.getView().setModel(oModelTotalData, "oModelExtRos");
								if (!that.pressDialog) {
									that.pressDialog = new sap.m.Dialog({
										title: "Please select one of the following Rosters",
										content: new sap.m.List({
											items: {
												path: "oModelExtRos>/",
												template: new sap.m.ActionListItem({
													text: "{oModelExtRos>Name}",
													press: function (oEvt) {
														that.pressDialog.close();
														that.addilRoster = oEvt.getSource().getText();
														that.onEmpSenMaintAdd();
													}
												})
											}
										}),
										endButton: new sap.m.Button({
											text: "Close",
											press: function () {
												that.pressDialog.close();
											}.bind(that)
										})
									});
									that.getView().addDependent(that.pressDialog);
								}
								that.pressDialog.open();

								that.pressDialog.setEscapeHandler(function (o) {
									o.reject();
								});

								return;
							}
							if (noDupFlag) {
								var oObject = oData.EmpSen.results;
								// var oFinalObj = Object.assign({}, oObject);
								for (var k = 0; k < oObject.length; k++) {
									that.sFinalArray.push(oObject[k]);
								}
								var oldData = [];
								if (oTable) {
									oldData = oTable.getModel("empSenMaintModel").getData().results;
								}
								if (!oldData) {
									oldData = [];
								}
								for (var i = 0; i < oData.EmpSen.results.length; i++) {
									oldData.push(oData.EmpSen.results[i]);
								}
								var dataOfAssign = {
									results: oldData
								};
								oTable.getModel("empSenMaintModel").setData(dataOfAssign);
								oTable.getModel("empSenMaintModel").refresh();
								that.onTableFinished();
								that.confirm = true;
								that.byId("saveBtn").setEnabled(true);
								that.byId("rosterNoInp").setValue();
								that.byId("empRemarksId").setValue().setValueState("None");
								that.byId("rosterOverrideSenDateId").setValue().setValueState("None");
								that.byId("rosterFrozenSenDateId").setValue().setValueState("None");
								that.byId("empSenCraftInp").setValue().setValueState("None");
								that.byId("empSenDivisionInp").setValue().setValueState("None");
								that.byId("empSenRrCodeInp").setValue().setValueState("None");
								that.byId("empSenDistrictInp").setValue().setValueState("None");
								that.byId("empSenDpgZoneInp").setValue().setValueState("None");
								that.byId("rosterOverrideNo").setValue().setValueState("None");
								that.changeFlag = false;
								oTable.setBusy(false);
							} else {
								that.changeFlag = false;
								oTable.setBusy(false);
							}
						}
						// } else {
						// 	that.changeFlag = false;
						// 	oTable.setBusy(false);

						// 	// var oObject = {};
						// 	var oObject = {};
						// 	oObject.Action = "A";
						// 	oObject.SenDate = oSenDate;
						// 	oObject.RostNo = that.rosterNo;
						// 	oObject.RostDesc = that.rosterDesc;
						// 	oObject.Remarks = oRemarks;
						// 	oObject.OverrideDate = oOverrideDate;
						// 	oObject.OverrideSeq = oOverrideNo;
						// 	oObject.FrozenDate = oFrozenDate;
						// 	oObject.Craft = oCraft;
						// 	oObject.Division = oDivision;
						// 	oObject.RRCode = oRrCode;
						// 	oObject.District = oDistrict;
						// 	oObject.DPGZone = oDpgZone;
						// 	oObject.City = that.city;
						// 	oObject.Territory = that.territory;
						// 	oObject.UnionCode = that.union;
						// 	oObject.Region = that.region;
						// 	oResults.unshift(oObject);
						// 	oData.results = oResults;

						// 	// that.assinedArray.push(oObject);
						// 	var oFinalObj = Object.assign({}, oObject);
						// 	that.sFinalArray.push(oFinalObj);
						// 	var dataOfAssign = {
						// 		results: oResults
						// 	};
						// 	// that.getView().getModel("assignFinalModel").setData(dataOfAssign);
						// 	oTable.getModel("empSenMaintModel").setData(oData);
						// 	oTable.getModel("empSenMaintModel").refresh();
						// 	that.onTableFinished();
						// 	that.confirm = true;
						// 	that.byId("saveBtn").setEnabled(true);

						// 	//
						// 	// that.getView().byId("posTitieId").setValue();
						// 	// that.byId("rosterNoInp").setValue().setValueState("None");
						// 	that.byId("rosterNoInp").setValue();
						// 	that.byId("empRemarksId").setValue().setValueState("None");
						// 	that.byId("rosterOverrideSenDateId").setValue().setValueState("None");
						// 	that.byId("rosterFrozenSenDateId").setValue().setValueState("None");
						// 	that.byId("empSenCraftInp").setValue().setValueState("None");
						// 	that.byId("empSenDivisionInp").setValue().setValueState("None");
						// 	that.byId("empSenRrCodeInp").setValue().setValueState("None");
						// 	that.byId("empSenDistrictInp").setValue().setValueState("None");
						// 	that.byId("empSenDpgZoneInp").setValue().setValueState("None");
						// 	that.byId("rosterOverrideNo").setValue().setValueState("None");
						// 	that.changeFlag = false;
						// 	oTable.setBusy(false);

						// }
					},
					error: function (err) {

					}
				});

			}

		},
		onTableFinishedCss: function () {
			var that = this;
			var oTable = that.byId("empSenMaintTable");
			var oTableItems = oTable.getItems();
			for (var k = 0; k < oTableItems.length; k++) {
				var aPath = oTableItems[k].getBindingContextPath();
				var oContext = oTable.getModel("empSenMaintModel").getProperty(aPath);
				var dStatus = oContext.Action;
				if (oTableItems[k].getAggregation("cells")[0].getAggregation("items")[0].getState() === "Success") {
					oTableItems[k].addStyleClass("cCurrentAct");
				}
				if (dStatus === "") {
					oTableItems[k].getAggregation("cells")[16].setVisible(false);
				}
				if (dStatus === "X") {
					oTableItems[k].getAggregation("cells")[3].getItems()[1].setEnabled(true);
					oTableItems[k].getAggregation("cells")[3].getItems()[3].setEnabled(true);
					oTableItems[k].getAggregation("cells")[16].setVisible(false);
				}
				if (dStatus === "A") {
					oTableItems[k].getAggregation("cells")[4].setEnabled(false);
					oTableItems[k].getAggregation("cells")[16].setVisible(true);
				}
			}
		},
		onTableFinished: function () {
			var that = this;
			var oTable = that.byId("empSenMaintTable");
			var oTableItems = oTable.getItems();
			for (var k = 0; k < oTableItems.length; k++) {
				var aPath = oTableItems[k].getBindingContextPath();
				var oContext = oTable.getModel("empSenMaintModel").getProperty(aPath);
				var dStatus = oContext.Action;
				if (dStatus === "") {
					oTableItems[k].getAggregation("cells")[16].setVisible(false);
				}

				if (dStatus === "X") {
					oTableItems[k].getAggregation("cells")[3].getItems()[1].setEnabled(true);
					oTableItems[k].getAggregation("cells")[3].getItems()[3].setEnabled(true);
					oTableItems[k].getAggregation("cells")[16].setVisible(false);
				}
				if (dStatus === "A") {
					oTableItems[k].getAggregation("cells")[4].setEnabled(false);
					oTableItems[k].getAggregation("cells")[16].setVisible(true);
				}
			}
		},

		onEdit: function () {
			var that = this;

			var selTab = that.byId("IconTabbarId").getSelectedKey();

			var roleGetSelectedKey = that.byId("roleId").getSelectedKey();
			// var selectedTab = that.byId("IconTabbarId").getSelectedKey();

			if (selTab === "empSenMaint") {
				if (that.byId("empSenMaintDescId").getText() === "") {
					sap.m.MessageToast.show("Please enter Employee ID");
					return;
				}
				var oTable = that.byId("empSenMaintTable");
				var oTableItems = oTable.getItems();
				for (var k = 0; k < oTableItems.length; k++) {
					// oTableItems[k].getAggregation("cells")[17].getItems()[0].setEnabled(true).setVisible(true);
					if (roleGetSelectedKey === "LR") {
						oTableItems[k].getAggregation("cells")[2].getItems()[1].setEnabled(false);
						oTableItems[k].getAggregation("cells")[2].getItems()[3].setEnabled(false);
						oTableItems[k].getAggregation("cells")[3].getItems()[1].setEnabled(false);
						oTableItems[k].getAggregation("cells")[3].getItems()[3].setEnabled(false);
						oTableItems[k].getAggregation("cells")[4].setEnabled(false);
						oTableItems[k].getAggregation("cells")[13].getItems()[1].setEnabled(false);
						oTableItems[k].getAggregation("cells")[13].getItems()[3].setEnabled(false);
						// oTableItems[k].getAggregation("cells")[19].getItems()[0].setEnabled(false).setVisible(true);
					} else {
						oTableItems[k].getAggregation("cells")[2].getItems()[1].setEnabled(true);
						oTableItems[k].getAggregation("cells")[2].getItems()[3].setEnabled(true);
						oTableItems[k].getAggregation("cells")[3].getItems()[1].setEnabled(true);
						oTableItems[k].getAggregation("cells")[3].getItems()[3].setEnabled(true);
						oTableItems[k].getAggregation("cells")[4].setEnabled(true);
						oTableItems[k].getAggregation("cells")[13].getItems()[1].setEnabled(true);
						oTableItems[k].getAggregation("cells")[13].getItems()[3].setEnabled(true);
						// oTableItems[k].getAggregation("cells")[19].getItems()[0].setEnabled(true).setVisible(true);
					}
				}
				// <!--editBtn saveBtn-->

				if (that.craftUnion === "Engineering") {

					/*that.byId("rosterNoInp").setEnabled(true);
					that.byId("empRemarksId").setEnabled(true);
					that.byId("rosterSenDateId").setEnabled(true);
					that.byId("rosterOverrideSenDateId").setEnabled(true);
					that.byId("rosterFrozenSenDateId").setEnabled(true);
					that.byId("empSenCraftInp").setEnabled(false);
					that.byId("empSenDivisionInp").setEnabled(true);
					that.byId("empSenRrCodeInp").setEnabled(true);
					that.byId("empSenDistrictInp").setEnabled(true);
					that.byId("empSenDpgZoneInp").setEnabled(true);*/

					if (roleGetSelectedKey === "LR") {

						that.byId("rosterNoInp").setEnabled(false);
						that.byId("empRemarksId").setEnabled(false);
						that.byId("rosterSenDateId").setEnabled(false);
						that.byId("rosterOverrideSenDateId").setEnabled(false);
						that.byId("rosterFrozenSenDateId").setEnabled(false);
						that.byId("empSenCraftInp").setEnabled(false);
						that.byId("empSenDivisionInp").setEnabled(false);
						that.byId("empSenRrCodeInp").setEnabled(false);
						that.byId("empSenDistrictInp").setEnabled(false);
						that.byId("empSenDpgZoneInp").setEnabled(false);
						that.byId("rosterOverrideNo").setEnabled(false);
						that.byId("editBtn").setVisible(false);
						that.byId("saveBtn").setVisible(false);
						that.byId("empSenMaintAdd").setEnabled(false);

					} else {

						that.byId("rosterNoInp").setEnabled(true);
						that.byId("empRemarksId").setEnabled(true);
						that.byId("rosterSenDateId").setEnabled(true);
						that.byId("rosterOverrideSenDateId").setEnabled(true);
						that.byId("rosterFrozenSenDateId").setEnabled(true);
						that.byId("empSenCraftInp").setEnabled(false);
						that.byId("empSenDivisionInp").setEnabled(true);
						that.byId("empSenRrCodeInp").setEnabled(true);
						that.byId("empSenDistrictInp").setEnabled(true);
						that.byId("empSenDpgZoneInp").setEnabled(true);
						that.byId("rosterOverrideNo").setEnabled(true);

						that.byId("editBtn").setVisible(false);
						that.byId("saveBtn").setVisible(true).setEnabled(true);
						that.byId("empSenMaintAdd").setEnabled(true);
						that.EditFlag = true;

					}

				} else if (that.craftUnion === "Mechanical") {

					/*that.byId("rosterNoInp").setEnabled(true);
					that.byId("empRemarksId").setEnabled(true);
					that.byId("rosterSenDateId").setEnabled(true);
					that.byId("rosterOverrideSenDateId").setEnabled(true);
					that.byId("rosterFrozenSenDateId").setEnabled(true);
					that.byId("empSenCraftInp").setEnabled(true);
					that.byId("empSenDivisionInp").setEnabled(false);
					that.byId("empSenRrCodeInp").setEnabled(false);
					that.byId("empSenDistrictInp").setEnabled(false);
					that.byId("empSenDpgZoneInp").setEnabled(false);*/

					if (roleGetSelectedKey === "LR") {

						that.byId("rosterNoInp").setEnabled(false);
						that.byId("empRemarksId").setEnabled(false);
						that.byId("rosterSenDateId").setEnabled(false);
						that.byId("rosterOverrideSenDateId").setEnabled(false);
						that.byId("rosterFrozenSenDateId").setEnabled(false);
						that.byId("empSenCraftInp").setEnabled(false);
						that.byId("empSenDivisionInp").setEnabled(false);
						that.byId("empSenRrCodeInp").setEnabled(false);
						that.byId("empSenDistrictInp").setEnabled(false);
						that.byId("empSenDpgZoneInp").setEnabled(false);
						that.byId("rosterOverrideNo").setEnabled(false);

						that.byId("editBtn").setVisible(false);
						that.byId("saveBtn").setVisible(false);
						that.byId("empSenMaintAdd").setEnabled(false);

					} else {

						that.byId("rosterNoInp").setEnabled(true);
						that.byId("empRemarksId").setEnabled(true);
						that.byId("rosterSenDateId").setEnabled(true);
						that.byId("rosterOverrideSenDateId").setEnabled(true);
						that.byId("rosterFrozenSenDateId").setEnabled(true);
						that.byId("empSenCraftInp").setEnabled(true);
						that.byId("empSenDivisionInp").setEnabled(false);
						that.byId("empSenRrCodeInp").setEnabled(false);
						that.byId("empSenDistrictInp").setEnabled(false);
						that.byId("empSenDpgZoneInp").setEnabled(false);
						that.byId("rosterOverrideNo").setEnabled(true);

						that.byId("editBtn").setVisible(false);
						that.byId("saveBtn").setVisible(true).setEnabled(true);
						that.byId("empSenMaintAdd").setEnabled(true);
						that.EditFlag = true;

					}

				} else if (that.craftUnion === "TCU") {

					/*that.byId("rosterNoInp").setEnabled(true);
					that.byId("empRemarksId").setEnabled(true);
					that.byId("rosterSenDateId").setEnabled(true);
					that.byId("rosterOverrideSenDateId").setEnabled(true);
					that.byId("rosterFrozenSenDateId").setEnabled(true);
					that.byId("empSenCraftInp").setEnabled(false);
					that.byId("empSenDivisionInp").setEnabled(false);
					that.byId("empSenRrCodeInp").setEnabled(false);
					that.byId("empSenDistrictInp").setEnabled(false);
					that.byId("empSenDpgZoneInp").setEnabled(false);*/

					if (roleGetSelectedKey === "LR") {
						that.byId("empSenDeptInp").setEnabled(false);
						that.byId("rosterNoInp").setEnabled(false);
						that.byId("empRemarksId").setEnabled(false);
						that.byId("rosterSenDateId").setEnabled(false);
						that.byId("rosterOverrideSenDateId").setEnabled(false);
						that.byId("rosterFrozenSenDateId").setEnabled(false);
						that.byId("empSenCraftInp").setEnabled(false);
						that.byId("empSenDivisionInp").setEnabled(false);
						that.byId("empSenRrCodeInp").setEnabled(false);
						that.byId("empSenDistrictInp").setEnabled(false);
						that.byId("empSenDpgZoneInp").setEnabled(false);
						that.byId("rosterOverrideNo").setEnabled(false);

						that.byId("editBtn").setVisible(false);
						that.byId("saveBtn").setVisible(false);
						that.byId("empSenMaintAdd").setEnabled(false);

					} else {
						that.byId("empSenDeptInp").setEnabled(true);
						that.byId("rosterNoInp").setEnabled(true);
						that.byId("empRemarksId").setEnabled(true);
						that.byId("rosterSenDateId").setEnabled(true);
						that.byId("rosterOverrideSenDateId").setEnabled(true);
						that.byId("rosterFrozenSenDateId").setEnabled(true);
						that.byId("empSenCraftInp").setEnabled(false);
						that.byId("empSenDivisionInp").setEnabled(false);
						that.byId("empSenRrCodeInp").setEnabled(false);
						that.byId("empSenDistrictInp").setEnabled(false);
						that.byId("empSenDpgZoneInp").setEnabled(false);
						that.byId("rosterOverrideNo").setEnabled(true);
						that.byId("editBtn").setVisible(false);
						that.byId("saveBtn").setVisible(true).setEnabled(true);
						that.byId("empSenMaintAdd").setEnabled(true);
						that.EditFlag = true;
					}
				} else if (that.craftUnion === "ATDA") {
					/*that.byId("rosterNoInp").setEnabled(true);
					that.byId("empRemarksId").setEnabled(true);
					that.byId("rosterSenDateId").setEnabled(true);
					that.byId("rosterOverrideSenDateId").setEnabled(true);
					that.byId("rosterFrozenSenDateId").setEnabled(true);
					that.byId("empSenCraftInp").setEnabled(false);
					that.byId("empSenDivisionInp").setEnabled(false);
					that.byId("empSenRrCodeInp").setEnabled(false);
					that.byId("empSenDistrictInp").setEnabled(false);
					that.byId("empSenDpgZoneInp").setEnabled(false);*/
					if (roleGetSelectedKey === "LR") {
						that.byId("rosterNoInp").setEnabled(false);
						that.byId("empRemarksId").setEnabled(false);
						that.byId("rosterSenDateId").setEnabled(false);
						that.byId("rosterOverrideSenDateId").setEnabled(false);
						that.byId("rosterFrozenSenDateId").setEnabled(false);
						that.byId("empSenCraftInp").setEnabled(false);
						that.byId("empSenDivisionInp").setEnabled(false);
						that.byId("empSenRrCodeInp").setEnabled(false);
						that.byId("empSenDistrictInp").setEnabled(false);
						that.byId("empSenDpgZoneInp").setEnabled(false);
						that.byId("rosterOverrideNo").setEnabled(false);
						that.byId("editBtn").setVisible(false);
						that.byId("saveBtn").setVisible(false);
						that.byId("empSenMaintAdd").setEnabled(false);
					} else {
						that.byId("rosterNoInp").setEnabled(true);
						that.byId("empRemarksId").setEnabled(true);
						that.byId("rosterSenDateId").setEnabled(true);
						that.byId("rosterOverrideSenDateId").setEnabled(true);
						that.byId("rosterFrozenSenDateId").setEnabled(true);
						that.byId("empSenCraftInp").setEnabled(false);
						that.byId("empSenDivisionInp").setEnabled(false);
						that.byId("empSenRrCodeInp").setEnabled(false);
						that.byId("empSenDistrictInp").setEnabled(false);
						that.byId("empSenDpgZoneInp").setEnabled(false);
						that.byId("rosterOverrideNo").setEnabled(true);
						that.byId("editBtn").setVisible(false);
						that.byId("saveBtn").setVisible(true).setEnabled(true);
						that.byId("empSenMaintAdd").setEnabled(true);
						that.EditFlag = true;
					}
				} else if (that.craftUnion === "ILA") {
					/*that.byId("rosterNoInp").setEnabled(true);
					that.byId("empRemarksId").setEnabled(true);
					that.byId("rosterSenDateId").setEnabled(true);
					that.byId("rosterOverrideSenDateId").setEnabled(true);
					that.byId("rosterFrozenSenDateId").setEnabled(true);
					that.byId("empSenCraftInp").setEnabled(false);
					that.byId("empSenDivisionInp").setEnabled(false);
					that.byId("empSenRrCodeInp").setEnabled(false);
					that.byId("empSenDistrictInp").setEnabled(false);
					that.byId("empSenDpgZoneInp").setEnabled(false);*/
					if (roleGetSelectedKey === "LR") {
						that.byId("rosterNoInp").setEnabled(false);
						that.byId("empRemarksId").setEnabled(false);
						that.byId("rosterSenDateId").setEnabled(false);
						that.byId("rosterOverrideSenDateId").setEnabled(false);
						that.byId("rosterFrozenSenDateId").setEnabled(false);
						that.byId("empSenCraftInp").setEnabled(false);
						that.byId("empSenDivisionInp").setEnabled(false);
						that.byId("empSenRrCodeInp").setEnabled(false);
						that.byId("empSenDistrictInp").setEnabled(false);
						that.byId("empSenDpgZoneInp").setEnabled(false);
						that.byId("rosterOverrideNo").setEnabled(false);
						that.byId("editBtn").setVisible(false);
						that.byId("saveBtn").setVisible(false);
						that.byId("empSenMaintAdd").setEnabled(false);
					} else {
						that.byId("rosterNoInp").setEnabled(true);
						that.byId("empRemarksId").setEnabled(true);
						that.byId("rosterSenDateId").setEnabled(true);
						that.byId("rosterOverrideSenDateId").setEnabled(true);
						that.byId("rosterFrozenSenDateId").setEnabled(true);
						that.byId("empSenCraftInp").setEnabled(false);
						that.byId("empSenDivisionInp").setEnabled(false);
						that.byId("empSenRrCodeInp").setEnabled(false);
						that.byId("empSenDistrictInp").setEnabled(false);
						that.byId("empSenDpgZoneInp").setEnabled(false);
						that.byId("rosterOverrideNo").setEnabled(true);
						that.byId("editBtn").setVisible(false);
						that.byId("saveBtn").setVisible(true).setEnabled(true);
						that.byId("empSenMaintAdd").setEnabled(true);
						that.EditFlag = true;
					}
				}
			} else if (selTab === "empHomeZone") {

				if (that.byId("empHomeZoneSearch").getTokens().length !== 0) {
					// that.byId("empHomeZoneSearch").setValueState("None");

					var oHomeZoneTable = that.byId("empHomeZoneTable");
					var oHomeZoneTableItems = oHomeZoneTable.getItems();
					for (var l = 0; l < oHomeZoneTableItems.length; l++) {
						if (roleGetSelectedKey === "LR") {
							oHomeZoneTableItems[l].getAggregation("cells")[3].getItems()[0].setEnabled(false).setVisible(false);
						} else {
							oHomeZoneTableItems[l].getAggregation("cells")[3].getItems()[0].setEnabled(true).setVisible(false);
						}
					}

					if (roleGetSelectedKey === "LR") {

						that.byId("empHomeZoneDropDown").setEnabled(false);
						that.byId("empRrHiredDropDown").setEnabled(false);
						that.byId("empDataEffDateHZ").setEnabled(false);
						// begin of insert - D5OW5 - Dt 03/03/2022
						that.byId("divDropDownHZ").setEnabled(false);
						that.byId("districtDropDownHZ").setEnabled(false);
						that.byId("PriorRights").setEnabled(false);
						that.byId("Classification").setEnabled(false);
						// end of insert - D5OW5 - Dt 03/03/2022
						that.byId("editBtn").setVisible(false);
						that.byId("saveBtn").setVisible(false);
						that.byId("empHomeZoneAdd").setEnabled(false);

					} else {

						that.byId("empHomeZoneDropDown").setEnabled(true);
						that.byId("empRrHiredDropDown").setEnabled(true);
						that.byId("empDataEffDateHZ").setEnabled(true);
						// begin of insert - D5OW5 - Dt 03/03/2022
						that.byId("divDropDownHZ").setEnabled(true);
						that.byId("districtDropDownHZ").setEnabled(true);
						that.byId("PriorRights").setEnabled(true);
						that.byId("Classification").setEnabled(true);
						// end of insert - D5OW5 - Dt 03/03/2022
						that.byId("editBtn").setVisible(false);
						that.byId("saveBtn").setVisible(true).setEnabled(true);
						that.byId("empHomeZoneAdd").setEnabled(true);
						that.EditFlag = true;
						that.editBtnPress = true;

					}

				} else {
					// that.byId("empHomeZoneSearch").setValueState("Error");
					sap.m.MessageToast.show("Please enter Employee ID");
				}

			} else if (selTab === "additionalSenInfo") {

				if (that.byId("empAdditionalSenInfoSearch").getTokens().length !== 0) {
					// that.byId("empAdditionalSenInfoSearch").setValueState("None");

					var oAdditionalSenInfoTable = that.byId("empAdditionalSenInfoTable");
					var oAdditionalSenInfoTableItems = oAdditionalSenInfoTable.getItems();
					for (var m = 0; m < oAdditionalSenInfoTableItems.length; m++) {
						if (roleGetSelectedKey === "LR") {
							oAdditionalSenInfoTableItems[m].getAggregation("cells")[9].getItems()[0].setEnabled(false).setVisible(true);
						} else {
							oAdditionalSenInfoTableItems[m].getAggregation("cells")[9].getItems()[0].setEnabled(true).setVisible(true);
						}
					}

					if (roleGetSelectedKey === "LR") {

						that.byId("additionalSenInfoRrCodeDropDown").setEnabled(false);
						that.byId("additionalSenInfoDivDropDown").setEnabled(false);
						that.byId("additionalSenInfoGroupInp").setEnabled(false);
						that.byId("additionalSenInfoDistDropDown").setEnabled(false);
						that.byId("additionalSenInfoRmdDate").setEnabled(false);
						that.byId("additionalSenInfoAFMDate").setEnabled(false);
						that.byId("additionalSenInfoFMDate").setEnabled(false);
						that.byId("additionalSenInfoTcDate").setEnabled(false);

						that.byId("editBtn").setVisible(false);
						that.byId("saveBtn").setVisible(false);
						that.byId("empAdditionalSenInfoAdd").setEnabled(false);

					} else {

						that.byId("additionalSenInfoRrCodeDropDown").setEnabled(true);
						that.byId("additionalSenInfoDivDropDown").setEnabled(true);
						that.byId("additionalSenInfoGroupInp").setEnabled(true);
						that.byId("additionalSenInfoDistDropDown").setEnabled(true);
						that.byId("additionalSenInfoRmdDate").setEnabled(true);
						that.byId("additionalSenInfoAFMDate").setEnabled(true);
						that.byId("additionalSenInfoFMDate").setEnabled(true);
						that.byId("additionalSenInfoTcDate").setEnabled(true);

						that.byId("editBtn").setVisible(false);
						that.byId("saveBtn").setVisible(true).setEnabled(false);
						that.byId("empAdditionalSenInfoAdd").setEnabled(true);
						that.EditFlag = true;
						that.editBtnPress = true;

					}

				} else {
					sap.m.MessageToast.show("Please enter Employee ID");
				}

			}

		},

		onInlineRosterEdit: function (oEvent) {
			var that = this;
			var oTable = that.byId("empSenMaintTable");
			oEvent.getSource().getParent().getParent().getAggregation("cells")[6].setEnabled(true);
			var aPath = oEvent.getSource().getParent().getParent().getBindingContextPath();
			var oContext = oTable.getModel("empSenMaintModel").getProperty(aPath);
			oContext.Action = "X";
		},
		onInlineRosterMoreFields: function (oEvent) {
			var that = this;
			var oTable = that.byId("empSenMaintTable");
			var aPath = oEvent.getSource().getParent().getParent().getBindingContextPath();
			that.moreFieldsoContext = oTable.getModel("empSenMaintModel").getProperty(aPath);
			if (!that._moreFieldsDialog) {
				that._moreFieldsDialog = sap.ui.xmlfragment(
					"com.empqualassignment.Employee_Qual_Assignment.fragment.MoreFields", that.getView()
					.getController());
				that.getView().addDependent(that._moreFieldsDialog);
			}
			that._moreFieldsDialog.open();
			that._moreFieldsDialog.setEscapeHandler(function (o) {
				o.reject();
			});
			var falseFlag = false;
			sap.ui.getCore().byId("moreEndBut").setVisible(false);
			if (that.byId("saveBtn").getVisible()) {
				falseFlag = true;
				sap.ui.getCore().byId("moreEndBut").setVisible(true);
			}
			sap.ui.getCore().byId("empSenMoreFrozenDateInp").setValue(that.moreFieldsoContext.FrozenDate).setEnabled(falseFlag);
			sap.ui.getCore().byId("empSenMoreDivisionInp").setValue(that.moreFieldsoContext.Division).setEnabled(falseFlag);
			sap.ui.getCore().byId("empSenMoreDistrictInp").setValue(that.moreFieldsoContext.District).setEnabled(falseFlag);
			sap.ui.getCore().byId("empSenRrMoreCodeInp").setValue(that.moreFieldsoContext.RRCode).setEnabled(falseFlag);
			sap.ui.getCore().byId("qualDelimtDate").setValue(that.moreFieldsoContext.OverrideDate).setEnabled(falseFlag);
			sap.ui.getCore().byId("overRideSeqNum").setValue(that.moreFieldsoContext.OverrideSeq).setEnabled(falseFlag);
			sap.ui.getCore().byId("empSenDpgZoneInp").setValue(that.moreFieldsoContext.DPGZone).setEnabled(falseFlag);
			sap.ui.getCore().byId("rmoreFieldsRemarks").setValue(that.moreFieldsoContext.Remarks).setEnabled(falseFlag);
			sap.ui.getCore().byId("rmoreFieldsRemarks").setValue(that.moreFieldsoContext.Remarks).setEnabled(falseFlag);
		},
		onUpdateMoreFields: function () {
			this.moreFieldsoContext.FrozenDate = sap.ui.getCore().byId("empSenMoreFrozenDateInp").getValue();
			this.moreFieldsoContext.Division = sap.ui.getCore().byId("empSenMoreDivisionInp").getValue();
			this.moreFieldsoContext.District = sap.ui.getCore().byId("empSenMoreDistrictInp").getValue();
			this.moreFieldsoContext.RRCode = sap.ui.getCore().byId("empSenRrMoreCodeInp").getValue();
			this.moreFieldsoContext.OverrideDate = sap.ui.getCore().byId("qualDelimtDate").getValue();
			this.moreFieldsoContext.OverrideSeq = sap.ui.getCore().byId("overRideSeqNum").getValue();
			this.moreFieldsoContext.DPGZone = sap.ui.getCore().byId("empSenDpgZoneInp").getValue();
			this.moreFieldsoContext.Remarks = sap.ui.getCore().byId("rmoreFieldsRemarks").getValue();
			this._moreFieldsDialog.close();
		},
		onMoreFieldsCancel: function () {
			this._moreFieldsDialog.close();
		},
		onInlineRosterRemarks: function (oEvent) {
			var that = this;
			var oTable = that.byId("empSenMaintTable");
			var aPath = oEvent.getSource().getParent().getParent().getBindingContextPath();
			var oContext = oTable.getModel("empSenMaintModel").getProperty(aPath);
			var enable = false;
			if (this.byId("saveBtn").getVisible()) {
				enable = true;
			}
			var tArea = new sap.m.TextArea({
				width: "100%",
				editable: enable,
				rows: 6,
				value: oContext.Remarks
			});
			var oCreateDialog = new sap.m.Dialog({
				content: tArea
			});
			oCreateDialog.setTitle("Remarks");
			oCreateDialog.setIcon("sap-icon://question-mark");
			oCreateDialog.addStyleClass(
				"dialogHdrBgCls dialogTitleCls dialogTextShadowCls dialogBoxShadowCls dialogIconCls dialogFooterBgCls");
			oCreateDialog.addButton(
				new sap.m.Button({
					text: "OK",
					press: function () {
						oContext.Remarks = tArea.getValue();
						oCreateDialog.close();
					}
				}).addStyleClass("sapUiSizeCompact clsBtnColorYellowRed")
			);
			oCreateDialog.addButton(
				new sap.m.Button({
					text: "Cancel",
					press: function () {
						oCreateDialog.close();
					}
				}).addStyleClass("sapUiSizeCompact clsBtnColorYellowRed")
			);
			oCreateDialog.open();
		},
		onInlineHomeZoneEdit: function (oEvent) {
			var that = this;
			var oTable = that.byId("empHomeZoneTable");
			oEvent.getSource().getParent().getParent().getAggregation("cells")[2].setEnabled(false);
			var aPath = oEvent.getSource().getParent().getParent().getBindingContextPath();
			var oContext = oTable.getModel("empHomeZoneModel").getProperty(aPath);
			oContext.Action = "X";
		},
		onInlineAdditionalSenInfoEdit: function (oEvent) {
			var that = this;
			var oTable = that.byId("empAdditionalSenInfoTable");
			oEvent.getSource().getParent().getParent().getAggregation("cells")[8].setEnabled(true);
			var aPath = oEvent.getSource().getParent().getParent().getBindingContextPath();
			var oContext = oTable.getModel("empAdditionalSenInfoModel").getProperty(aPath);
			oContext.Action = "X";
		},
		onPosDelete: function (oEvent) {
			var that = this;
			var wantToDelRecord = this.getView().getModel("i18n").getProperty("wantToDelRecord");
			var titleConfirm = this.getView().getModel("i18n").getProperty("titleConfirm");
			var yes = this.getView().getModel("i18n").getProperty("yes");
			var no = this.getView().getModel("i18n").getProperty("no");
			var evt = oEvent;
			that.aTabPath = evt.getSource().getParent().getParent().getBindingContextPath();
			sap.m.MessageBox.confirm(wantToDelRecord, {
				title: titleConfirm,
				actions: [sap.m.MessageBox.Action.YES, sap.m.MessageBox.Action.NO],
				onClose: function (oAction) {
					if (oAction === sap.m.MessageBox.Action.YES) {
						var oModel = that.byId("empSenMaintTable").getModel("empSenMaintModel");
						var aRows = oModel.getProperty("/results");
						var aTable = that.byId("empSenMaintTable");
						var aContexts = that.byId("empSenMaintTable").getModel("empSenMaintModel").getProperty(that.aTabPath);
						if (aContexts.Action === "A") {
							for (var i = 0; i < that.sFinalArray.length; i++) {
								if (that.sFinalArray[i].Action === aContexts.Action) {
									that.sFinalArray.splice(i, 1);
								}
							}
						}
						var index = $.map(aRows, function (obj, index) {
							if (obj === aContexts) {
								return index;
							}
						});
						aRows.splice(index, 1);
						oModel.setProperty("/results", aRows);
						aTable.getModel("empSenMaintModel").refresh();
					} else if (oAction === sap.m.MessageBox.Action.NO) {
						that.byId("empSenMaintTable").removeSelections(true);
					}
				}
			});
		},
		onHomeZoneDelete: function (oEvent) {
			var that = this;
			var wantToDelRecord = this.getView().getModel("i18n").getProperty("wantToDelRecord");
			var titleConfirm = this.getView().getModel("i18n").getProperty("titleConfirm");
			var yes = this.getView().getModel("i18n").getProperty("yes");
			var no = this.getView().getModel("i18n").getProperty("no");
			var path = oEvent.getSource().getParent().getParent().getBindingContextPath().split("/")[2];
			sap.m.MessageBox.confirm(wantToDelRecord, {
				title: titleConfirm,
				actions: [sap.m.MessageBox.Action.YES, sap.m.MessageBox.Action.NO],
				onClose: function (oAction) {
					if (oAction === sap.m.MessageBox.Action.YES) {
						var oModelres = that.byId("empHomeZoneTable").getModel("empHomeZoneModel").getData().results;
						oModelres.splice(path, "1");
						that.byId("empHomeZoneTable").getModel("empHomeZoneModel").refresh();
						that.byId("empHomeZoneTable").removeSelections(true);
					} else if (oAction === sap.m.MessageBox.Action.NO) {
						that.byId("empHomeZoneTable").removeSelections(true);
					}
				}
			});
		},
		onInlineAdditionalSenInfoDel: function (oEvent) {
			var that = this;
			var wantToDelRecord = this.getView().getModel("i18n").getProperty("wantToDelRecord");
			var titleConfirm = this.getView().getModel("i18n").getProperty("titleConfirm");
			var yes = this.getView().getModel("i18n").getProperty("yes");
			var no = this.getView().getModel("i18n").getProperty("no");
			var path = oEvent.getSource().getParent().getParent().getBindingContextPath().split("/")[2];
			sap.m.MessageBox.confirm(wantToDelRecord, {
				title: titleConfirm,
				actions: [sap.m.MessageBox.Action.YES, sap.m.MessageBox.Action.NO],
				onClose: function (oAction) {
					if (oAction === sap.m.MessageBox.Action.YES) {
						var oModelres = that.byId("empAdditionalSenInfoTable").getModel("empAdditionalSenInfoModel").getData().results;
						oModelres.splice(path, "1");
						that.byId("empAdditionalSenInfoTable").getModel("empAdditionalSenInfoModel").refresh();
						that.byId("empAdditionalSenInfoTable").removeSelections(true);
					} else if (oAction === sap.m.MessageBox.Action.NO) {
						that.byId("empAdditionalSenInfoTable").removeSelections(true);
					}
				}
			});
		},
		onEndDateEmpData: function (oEvent) {
			var that = this;
			var sValue = oEvent.getParameter("value");
			var bValid = oEvent.getParameter("valid");
			var oTable = that.byId("empSenMaintTable");
			if (bValid) {
				oEvent.getSource().setValueState("None");
				if (sValue.length === 8) {
					that.confirm = true;
					var oPath = oEvent.getSource().getParent().getBindingContextPath();
					var oContext = oTable.getModel("empSenMaintModel").getProperty(oPath);
					oContext.Action = "E";
					var copyObject = Object.assign({}, oContext);
					that.sFinalArray.push(copyObject);
					that.byId("saveBtn").setEnabled(true);
				} else if (sValue.length === 0) {
					oEvent.getSource().setValue("99991231");
				}
			} else {
				oEvent.getSource().setValueState("Error");
			}
		},
		defaultDate: function () {
			var that = this;
			var newDate = new Date();
			var currDay = newDate.getDate();
			var currMonth = newDate.getMonth() + 1;
			var currYear = newDate.getFullYear();
			if (currDay < 10) {
				currDay = "0" + currDay;
			} else {
				currDay = currDay;
			}
			if (currMonth < 10) {
				currMonth = "0" + currMonth;
			} else {
				currMonth = currMonth;
			}
			var currentDate = currMonth + "/" + currDay + "/" + currYear;
			that.byId("qualStDate").setValue(currentDate);
			var highDate = "12/31/9999";
			that.highDate = highDate;
			that.byId("qualEndDate").setValue(highDate);
		},
		qualDataFun: function (pernr, effectiveDate, key) {
			var that = this;
			var oSelRole = that.byId("roleId").getSelectedItem().getProperty("text");
			var roleGetSelectedKey = that.byId("roleId").getSelectedKey();
			var titleInfo = this.getView().getModel("i18n").getProperty("titleInfo");
			var ok = this.getView().getModel("i18n").getProperty("ok");
			that.selTab = that.byId("IconTabbarId").getSelectedKey();
			//clear old data before making new call - refresh 
			that.getView().byId("qualTable").getModel("oModelData").setData([]); //++D5OW5 -- Dt 02/06/2022	
			//-----------------------------------------------------------------------	
			//Busy Indicator.
			//-----------------------------------------------------------------------
			var dialog = new sap.m.BusyDialog({});
			dialog.open();
			that.defaultDate();
			var queryFil = [];
			var empNo = new sap.ui.model.Filter("Pernr", "EQ", pernr);
			var EffDate = new sap.ui.model.Filter("EffDate", "EQ", effectiveDate);
			var Key = new sap.ui.model.Filter("Key", "EQ", key);
			//var craftType = new sap.ui.model.Filter("CraftType", "EQ", union);
			queryFil.push(empNo);
			queryFil.push(EffDate);
			queryFil.push(Key);
			//queryFil.push(craftType);
			var oModel = that.getOwnerComponent().getModel();
			oModel.read("/EmpQualificationSet", {
				filters: queryFil,
				success: function (oData) {
					dialog.close();
					that.defaultDate();
					if (oData.results.length > 0) {
						if (roleGetSelectedKey !== "LR") {
							that.qualChangeFlag = true;
						}
						var oModelTotalData = new sap.ui.model.json.JSONModel(oData);
						that.getView().setModel(oModelTotalData, "oModelTotalData");
						that.byId("empDataEmpNoInp").setValueState("None");
						that.byId("qualQualsInput").setEnabled(true);
						that.byId("qualQualsInput").removeAllTokens();
						that.byId("qualQualsInputDesc").setText();
						that.byId("qualStDate").setEnabled(true);
						that.byId("qualStDate").setValue();
						that.byId("qualEndDate").setEnabled(true);
						that.byId("addBtn").setEnabled(true);
						that.byId("qualproficiency").setEnabled(false);
						that.craftType = oData.results[0].CraftType;
						that.craftSuggFun();
						var qualTableArray = [];
						if (oData.results.length > 0) {
							for (var i = 0; i < oData.results.length; i++) {
								var empID = oData.results[0].Pernr;
								var pernrDesc = oData.results[0].PernrDesc;
								var position = oData.results[0].PosId;
								var posDesc = oData.results[0].PosDesc;
								var union = oData.results[0].Union;
								var agreement = oData.results[0].AggrDesc;
								var begda = oData.results[i].Begda;
								var endda = oData.results[i].Endda;
								var qualGroup = oData.results[i].QualGroup;
								var quals = oData.results[i].Qualif;
								var qualif = oData.results[i].Qualif;
								var qualID = oData.results[i].QualDesc;
								var profScale = oData.results[i].profScale;
								var changedDate = oData.results[i].ChangedOn;
								var changedBy = oData.results[i].ChangedBy;
								var addData = "";
								var asTr = "";
								if (oData.results[i].AddField1 !== "") {
									if (oData.results[i].AddField1.split(":")[3] === "X") {
										asTr = "*";
									} else {
										asTr = "";
									}
									addData = addData + asTr + oData.results[i].AddField1.split(":")[0] + "|";
								}
								if (oData.results[i].AddField2 !== "") {
									if (oData.results[i].AddField2.split(":")[3] === "X") {
										asTr = "*";
									} else {
										asTr = "";
									}
									addData = addData + asTr + oData.results[i].AddField2.split(":")[0] + "|";
								}
								if (oData.results[i].AddField3 !== "") {
									if (oData.results[i].AddField3.split(":")[3] === "X") {
										asTr = "*";
									} else {
										asTr = "";
									}
									addData = addData + asTr + oData.results[i].AddField3.split(":")[0] + "|";
								}
								if (oData.results[i].AddField4 !== "") {
									if (oData.results[i].AddField4.split(":")[3] === "X") {
										asTr = "*";
									} else {
										asTr = "";
									}
									addData = addData + asTr + oData.results[i].AddField4.split(":")[0] + "|";
								}
								if (oData.results[i].AddField5 !== "") {
									if (oData.results[i].AddField5.split(":")[3] === "X") {
										asTr = "*";
									} else {
										asTr = "";
									}
									addData = addData + asTr + oData.results[i].AddField5.split(":")[0] + "|";
								}
								if (oData.results[i].AddField6 !== "") {
									if (oData.results[i].AddField6.split(":")[3] === "X") {
										asTr = "*";
									} else {
										asTr = "";
									}
									addData = addData + asTr + oData.results[i].AddField6.split(":")[0] + "|";
								}
								if (oData.results[i].AddField7 !== "") {
									if (oData.results[i].AddField7.split(":")[3] === "X") {
										asTr = "*";
									} else {
										asTr = "";
									}
									addData = addData + asTr + oData.results[i].AddField7.split(":")[0] + "|";
								}
								if (oData.results[i].AddField8 !== "") {
									if (oData.results[i].AddField8.split(":")[3] === "X") {
										asTr = "*";
									} else {
										asTr = "";
									}
									addData = addData + asTr + oData.results[i].AddField8.split(":")[0] + "|";
								}
								if (oData.results[i].AddField9 !== "") {
									if (oData.results[i].AddField9.split(":")[3] === "X") {
										asTr = "*";
									} else {
										asTr = "";
									}
									addData = addData + asTr + oData.results[i].AddField9.split(":")[0] + "|";
								}
								if (oData.results[i].AddField10 !== "") {
									if (oData.results[i].AddField10.split(":")[3] === "X") {
										asTr = "*";
									} else {
										asTr = "";
									}
									addData = addData + asTr + oData.results[i].AddField10.split(":")[0] + "|";
								}
								that.byId("empDataEmpNoInp").setTokens([new sap.m.Token({
									text: empID,
									key: empID
								})]);
								that.byId("empDataEmpNoInpDesc").setText(pernrDesc);
								that.byId("empDataPosInp").setValue(position);
								that.byId("empDataPosInp").setDescription(posDesc);
								var selectedTab = that.byId("IconTabbarId").getSelectedKey();
								if (roleGetSelectedKey === "LR") {
									if (selectedTab === "empQualAssign") {
										that.byId("deptId").setEnabled(true);
										that.byId("deptId").setValue();
										that.byId("qualQualsInput").setEnabled(false);
										that.byId("qualStDate").setEnabled(false);
										that.byId("qualEndDate").setEnabled(false);
										that.byId("qualproficiency").setEnabled(false);
										that.byId("addBtn").setEnabled(false);
										that.byId("editBtn").setVisible(false);
										that.byId("saveBtn").setVisible(false);
										that.byId("cancelBtn").setVisible(false);
									} else
									if (selectedTab === "empSenMaint") {
										that.byId("deptId").setEnabled(true);
										that.byId("deptId").setValue();
										that.byId("editBtn").setVisible(false);
										that.byId("saveBtn").setVisible(false);
										that.byId("cancelBtn").setVisible(false);
									}
								} else {
									if (selectedTab === "empQualAssign") {
										that.byId("deptId").setEnabled(false);
										//that.byId("deptId").setSelectedKey(roleGetSelectedKey);
										that.byId("qualQualsInput").setEnabled(true);
										that.byId("qualStDate").setEnabled(true);
										that.byId("qualEndDate").setEnabled(true);
										that.byId("qualproficiency").setEnabled(false);
										that.byId("addBtn").setEnabled(true);
										that.byId("editBtn").setVisible(false);
										that.byId("saveBtn").setVisible(false);
										that.byId("cancelBtn").setVisible(true);
									} else
									if (selectedTab === "empSenMaint") {
										that.byId("deptId").setEnabled(false);
										//	that.byId("deptId").setSelectedKey(roleGetSelectedKey);
										that.byId("editBtn").setVisible(true);
										that.byId("saveBtn").setVisible(true).setEnabled(false);
										that.byId("cancelBtn").setVisible(true);
									}
								}
								if (posDesc !== "") {
									that.byId("empDataPosInp").setWidth("118%");
								}
								that.byId("empDataUnionInp").setValue(union);
								that.byId("empDataUnionInp").setWidth("60%");
								that.byId("empDataAgrInp").setValue(agreement);
								that.byId("empDataAgrInp").setWidth("60%");
								var stDate;
								if (begda === "00000000" || begda === "") {
									stDate = "";
								} else {
									stDate = begda;
								}
								var enDate;
								if (endda === "00000000" || endda === "") {
									enDate = "";
								} else {
									enDate = endda;
								}
								if (qualGroup === "00000000" || qualGroup === "") {
									qualGroup = "";
								} else {
									qualGroup = qualGroup;
								}
								if (quals === "00000000" || quals === "") {
									quals = "";
								} else {
									quals = quals;
								}
								if (profScale === "") {
									profScale = "";
								} else {
									profScale = profScale;
								}
								var changedOn;
								if (changedDate === "00000000" || changedDate === "") {
									changedOn = "";
								} else {
									changedOn = changedDate;
								}
								if (stDate !== "" || enDate !== "" || qualGroup !== "" || qualID !== "" || quals !== "" || profScale !== "" ||
									changedOn !==
									"" || changedBy !== "") {
									var qualTableObj = {};
									qualTableObj.stDate = stDate;
									qualTableObj.enDate = enDate;
									qualTableObj.qualGroup = qualGroup;
									qualTableObj.quals = qualID;
									qualTableObj.qualID = quals;
									qualTableObj.qualif = qualif;
									qualTableObj.profScale = profScale;
									qualTableObj.ChangedOn = changedOn;
									qualTableObj.ChangedBy = changedBy;
									qualTableObj.Pernr = oData.results[i].Pernr;
									qualTableObj.rowKey = "B";
									qualTableObj.AddData = addData;
									qualTableArray.push(qualTableObj);
								} else {
									qualTableArray.push();
								}
							}
							var Pernr = parseInt(oData.results[0].Pernr);
							var oResults = that.getView().byId("qualTable").getModel("oModelData");
							if (oResults !== undefined) {
								var data = oResults.getData().results;
								if (data) {
									for (var m = 0; m < data.length; m++) {
										if (parseInt(data[m].Pernr) === Pernr) {
											qualTableArray.push(data[m]);
										}
									}
								}
							}
							if (that.qualSetCall) {
								var dialog1 = new sap.m.BusyDialog({});
								dialog1.open();
								var filters = [];
								var cf = that.deptGetSelectedKey;
								if (that.deptGetSelectedKey === "CG") {
									cf = "E";
								}
								// var vCraft = new sap.ui.model.Filter("Craft", "EQ", that.Union);	
								var vCraft = new sap.ui.model.Filter("Craft", "EQ", cf);
								var vEmp = new sap.ui.model.Filter("EmpNo", "EQ", Pernr);
								filters.push(vCraft);
								filters.push(vEmp);
								var qualModel = that.getOwnerComponent().getModel();
								qualModel.read("/QualiSearchHelpSet", {
									filters: filters,
									success: function (oData, Response) {
										dialog1.close();
										if (oData.results.length > 0) {
											var qualEntryArray = [];
											var engQualEntryArray = [];
											var mechQualEntryArray = [];
											var tcuQualEntryArray = [];
											that.QualArray = oData;
											for (var j = 0; j < oData.results.length; j++) {
												var qualEntryObj = {};
												qualEntryObj.QualDesc = oData.results[j].QualDesc;
												qualEntryObj.Qualification = oData.results[j].Qualification;
												qualEntryArray.push(qualEntryObj);
												if (oData.results[j].Craft === "ENG") {
													var engQualEntryObj = {};
													engQualEntryObj.QualDesc = oData.results[j].QualDesc;
													engQualEntryObj.Qualification = oData.results[j].Qualification;
													engQualEntryObj.QualId = oData.results[j].QualId;
													engQualEntryArray.push(engQualEntryObj);
													var engQualSModel = new sap.ui.model.json.JSONModel({
														"results": engQualEntryArray
													});
													that.getView().setModel(engQualSModel, "engQualSModel");
												} else if (oData.results[j].Craft === "MECH") {
													var mechQualEntryObj = {};
													mechQualEntryObj.QualDesc = oData.results[j].QualDesc;
													mechQualEntryObj.Qualification = oData.results[j].Qualification;
													mechQualEntryObj.QualId = oData.results[j].QualId;
													mechQualEntryArray.push(mechQualEntryObj);
													var mechQualSModel = new sap.ui.model.json.JSONModel({
														"results": mechQualEntryArray
													});
													that.getView().setModel(mechQualSModel, "mechQualSModel");
												} else if (oData.results[j].Craft === "TCU") {
													var tcuQualEntryObj = {};
													tcuQualEntryObj.QualDesc = oData.results[j].QualDesc;
													tcuQualEntryObj.Qualification = oData.results[j].Qualification;
													tcuQualEntryObj.QualId = oData.results[j].QualId;
													tcuQualEntryArray.push(tcuQualEntryObj);
													var tcuQualSModel = new sap.ui.model.json.JSONModel({
														"results": tcuQualEntryArray
													});
													that.getView().setModel(tcuQualSModel, "tcuQualSModel");
												}
											}
											var qualSModel = new sap.ui.model.json.JSONModel({
												results: qualEntryArray
											});
											that.getView().setModel(qualSModel, "qualSModel");
										}
										if (that.deptSelectedKey === "CH") {
											that.qualSetCall = true;
										} else {
											that.qualSetCall = false;
										}
									},
									error: function (oResponse) {
										//-----------------------------------------------------------------------		
										// Displaying response body message.	
										//-----------------------------------------------------------------------	
										dialog1.close();
										var oMessage = $(oResponse.response.body).find('message').first().text();
										var errmsg;
										if (oMessage === "") {
											errmsg = oResponse.response.body;
										} else {
											errmsg = oMessage;
										}
										sap.m.MessageBox.show(errmsg, {
											icon: sap.m.MessageBox.Icon.ERROR,
											title: error,
											actions: [sap.m.MessageBox.Action.OK],
											onClose: function (oAction) {
												if (oAction === sap.m.MessageBox.Action.OK) {}
											}
										});
									}
								});
							}
						}
						var uniqueArr = that.uniqueValFun(qualTableArray, "qualID");
						var oUniqueDataArray = {
							results: uniqueArr
						};
						var oQualModel = new sap.ui.model.json.JSONModel(oUniqueDataArray);
						var oQalTable = that.getView().byId("qualTable");
						oQalTable.setModel(oQualModel, "oModelData");
						var oQualTableModel = new sap.ui.model.json.JSONModel({
							"results": qualTableArray
						});
						that.getView().setModel(oQualTableModel, "oQualTableModel");
						// var oQalTable = that.getView().byId("qualTable");    //--D5OW5 - Dt 02/06/2022
						// oQalTable.setModel(oQualTableModel, "oModelData");   //--D5OW5 - Dt 02/06/2022
						that.defaultDate();
					}
					if (oSelRole === "Supervisor") {
						that.getView().byId("qualQualsInput").setEnabled(false);
						that.getView().byId("qualStDate").setEnabled(false);
						that.getView().byId("addBtn").setEnabled(false);
						that.getView().byId("qualproficiency").setEnabled(false);
						that.getView().byId("qualEndDate").setEnabled(false);
						that.getView().byId("inlineEditBtn").setEnabled(false);
						that.getView().byId("inlineDelButtn").setEnabled(false);
					}
				},
				error: function (oResponse) {
					dialog.close();
					//-----------------------------------------------------------------------	
					// Displaying response body message.
					//-----------------------------------------------------------------------
					var errmsg;
					errmsg = JSON.parse(oResponse.responseText).error.message.value;
					sap.m.MessageBox.show(
						errmsg, {
							icon: sap.m.MessageBox.Icon.INFORMATION,
							title: titleInfo,
							onClose: function (sAction) {
								if (sAction === "OK") {
									that.byId("empDataEmpNoInp").setValueState("Error");
									that.byId("empDataPosInp").setValue("");
									that.byId("empDataPosInp").setDescription("");
									that.byId("empDataPosInp").setWidth("60%");
									that.byId("empDataPosInp").setWidth("60%");
									that.byId("empDataUnionInp").setValue("");
									that.byId("empDataAgrInp").setValue("");
									that.byId("empDataEffDate").setValue(currentDate);
									that.byId("qualCraftTypeCombo").setValue("");
									that.byId("qualStDate").setEnabled(false);
									that.byId("qualQualsInput").setValue("");
									that.byId("qualQualsInputDesc").setText();
									that.byId("qualQualsInput").setEnabled(false);
									that.byId("qualEndDate").setValue("");
									that.byId("qualEndDate").setEnabled(false);
									that.byId("addBtn").setEnabled(false);
									that.defaultDate();
									var itemsArray = [];
									var qualCModel = new sap.ui.model.json.JSONModel({
										"results": itemsArray
									});
									var itemsTable = that.byId("qualTable");
									itemsTable.setModel(qualCModel, "oModelData");
								}
							}
						});
				}
			});
		},
		onAddFields: function (oEvt) {
			var socBut = oEvt.getSource();
			var adddata = this.getView().byId("qualTable").getModel("oModelData").getProperty(oEvt.getSource().getParent().getParent().getBindingContextPath() +
				"/AddData").split("|").join("\n");
			var oPopover = new sap.m.Popover({
				placement: "Left",
				title: "Additional Fields",
				content: [new sap.m.Text({
					"text": adddata
				}).addStyleClass("sapUiTinyMarginBegin")]
			});
			oPopover.openBy(socBut);
		},
		//-----------------------------------------------------------------------	
		// Method for gettting uniq values.
		//-----------------------------------------------------------------------
		uniqueValFun: function (qualTableArray, qualID) {
			var oArray = [];
			var checkArray = [];
			for (var i = 0; i < qualTableArray.length; i++) {
				if (oArray.indexOf(qualTableArray[i]["" + qualID + ""]) === -1 && qualTableArray[i]["" + qualID + ""].trim() !== "") {
					oArray.push(qualTableArray[i]["" + qualID + ""]);
					var uObj = Object.assign({}, qualTableArray[i]);
					checkArray.push(uObj);
				}
			}
			return checkArray;
		},
		craftSuggFun: function () {
			var that = this;
			var emptyModel = [];
			var craftType;
			if (that.craftType === "E") {
				craftType = "Engineering";
				that.byId("qualCraftTypeCombo").setValue(craftType);
				var engSuggModel = that.getView().getModel("engQualSModel");
				if (engSuggModel !== undefined) {
					engSuggModel = engSuggModel;
				} else {
					engSuggModel = new sap.ui.model.json.JSONModel({
						results: emptyModel
					});
				}
				var engQualSugg = that.getView().byId("qualQualsInput");
				engQualSugg.setModel(engSuggModel, "suggModel");
			} else if (that.craftType === "M") {
				craftType = "Mechanical";
				that.byId("qualCraftTypeCombo").setValue(craftType);
				var mechSuggModel = that.getView().getModel("mechQualSModel");
				if (mechSuggModel !== undefined) {
					mechSuggModel = mechSuggModel;
				} else {
					mechSuggModel = new sap.ui.model.json.JSONModel({
						results: emptyModel
					});
				}
				var mechQualSugg = that.getView().byId("qualQualsInput");
				mechQualSugg.setModel(mechSuggModel, "suggModel");
			} else if (that.craftType === "T") {
				craftType = "TCU";
				that.byId("qualCraftTypeCombo").setValue(craftType);
				var tcuSuggModel = that.getView().getModel("tcuQualSModel");
				if (tcuSuggModel !== undefined) {
					tcuSuggModel = tcuSuggModel;
				} else {
					tcuSuggModel = new sap.ui.model.json.JSONModel({
						results: emptyModel
					});
				}
				var tcuQualSugg = that.getView().byId("qualQualsInput");
				tcuQualSugg.setModel(tcuSuggModel, "suggModel");
			}
		},
		onAdditionalInfo: function () {
			var that = this;
			var oController = that.getView().getController();
			var additionalInfo = that.getView().getModel("oJsonModel");
			if (!that._qualAdditionalInfoDialog) {
				that._qualAdditionalInfoDialog = sap.ui.xmlfragment(
					"com.empqualassignment.Employee_Qual_Assignment.fragment.AdditionalInformation", that.getView()
					.getController());
				that.getView().addDependent(that._qualAdditionalInfoDialog);
			}
			that._qualAdditionalInfoDialog.open();
			that._qualAdditionalInfoDialog.setEscapeHandler(function (o) {
				o.reject();
			});
			var oAdditionalForm = sap.ui.getCore().byId("additionalInfoForm");
			for (var i = 0; i < additionalInfo.oData.length; i++) {
				var oFieldVal = additionalInfo.oData[i];
				if (oFieldVal !== "YES" && oFieldVal !== "NO" && oFieldVal !== "") {
					oAdditionalForm.addContent(new sap.m.Label({
						text: oFieldVal,
						design: "Bold"
					}));
					if (oFieldVal === "STATE") {
						oAdditionalForm.addContent(stateComboBox);
					} else {
						oAdditionalForm.addContent(new sap.m.Input({
							value: ""
						}));
					}
				}
			}
			oAdditionalForm.addContent(new sap.m.Label({
				text: "Upload Documents",
				design: "Bold"
			}));
			if (additionalInfo.oData[0] === "YES") {
				oAdditionalForm.addContent(new sap.ui.unified.FileUploader({
					id: "fileUploader",
					enabled: true
				}));
				oAdditionalForm.addContent(new sap.m.Button({
					enabled: true,
					text: "Upload",
					press: [oController.onFileUpload, oController]
				}));
				oAdditionalForm.addContent(new sap.m.Label({
					text: ""
				}));
				oAdditionalForm.addContent(
					inlineTable = new sap.m.Table({
						id: "uploadAttachmentsTable",
						columns: [new sap.m.Column({
							header: new sap.m.Text({
								text: "Attachment"
							})
						})]
					}),
					inlineTable.bindItems("/", new sap.m.ColumnListItem({
						cells: [
							new sap.m.Input({
								value: "{FileValue}"
							})
						]
					}))
				);
			} else {
				oAdditionalForm.addContent(new sap.ui.unified.FileUploader({
					enabled: false
				}));
			}
		},
		// ---------------------------------------- State Dropdown binding --------------------------------------
		stateDataFun: function () {
			var that = this;
			var oModel = that.getOwnerComponent().getModel();
			oModel.read("/StateSearchHelpSet", {
				success: function (oData, Response) {
					var oStateModel = new sap.ui.model.json.JSONModel(oData);
					that.getView().setModel(oStateModel, "stateData");
				},
				error: function (oResponse) {
					//-----------------------------------------------------------------------	
					// Displaying response body message.
					//-----------------------------------------------------------------------
					var errmsg = JSON.parse(oResponse.responseText).error.message.value;
					sap.m.MessageBox.show(errmsg, {
						icon: sap.m.MessageBox.Icon.ERROR,
						title: error
					});
				}
			});
		},
		onFileUpload: function () {
			var fileupload = sap.ui.getCore().byId("fileUploader");
			var filename = fileupload.getValue();
			if (filename === "") {
				sap.m.MessageToast.show("Please Select File");
			} else {
				// ============================================================================
				/*Getting Multiple Records From Table*/
				// ============================================================================
				var filedata;
				var file = jQuery.sap.domById(fileupload.getId() + "-fu").files[0];
				var reader = new FileReader();
				reader.readAsDataURL(file);
				reader.onload = function () {
					var result = reader.result;
					var res = result.split(";base64,");
					filedata = res[1];
					var columnListItem = new sap.m.ColumnListItem({
						cells: [
							new sap.m.Text({
								text: filename
							}),
							new sap.m.Text({
								text: filedata,
								visible: true
							})
						]
					});
					sap.ui.getCore().byId("uploadAttachmentsTable").addItem(columnListItem);
				};
				reader.onerror = function (error) {};
				sap.ui.getCore().byId("fileUploader").setValue("");
			}
		},
		onUploadAdditionalData: function () {
			var that = this;
			var oAdditionalForm = sap.ui.getCore().byId("additionalInfoForm");
			var oContent = oAdditionalForm.getContent();
			var contentArray = [];
			for (var i = 0; i < oContent.length; i++) {
				var contentObj = {};
				if (oContent[i].getMetadata().getElementName() === "sap.m.Label") {
					contentObj.oField = oContent[i].getProperty("text") + "col";
				} else if (oContent[i].getMetadata().getElementName() === "sap.m.Input") {
					contentObj.oField = oContent[1].getProperty("value");
				} else if (oContent[i].getMetadata().getElementName() === "sap.m.ComboBox") {
					contentObj.oField.oFieldValue = oContent[i].getProperty("value");
				} else if (oContent[i].getMetadata().getElementName() === "sap.m.Table") {}
				contentArray.push(contentObj);
			}
		},
		onAdditionalDataCancel: function () {
			var that = this;
			var oAdditionalForm = sap.ui.getCore().byId("additionalInfoForm");
			oAdditionalForm.destroyContent();
			that._qualAdditionalInfoDialog.close();
		},
		onDivDropDownValues: function () {
			var that = this;
			var selTab = that.byId("IconTabbarId").getSelectedKey();
			var oModel = that.getOwnerComponent().getModel();
			var queryFil = [];
			var oPage;
			var divTable;
			var divJsonPos = new sap.ui.model.json.JSONModel({});
			if (selTab === "empSenMaint") {
				oPage = that.byId("empSenDivisionInp");
				divTable = that.byId("empSenDivisionInp");
				divTable.setModel(divJsonPos, "divModelData");
			} else if (selTab === "additionalSenInfo") {
				oPage = that.byId("additionalSenInfoDivDropDown");
				divTable = that.byId("additionalSenInfoDivDropDown");
				divTable.setModel(divJsonPos, "divModelData");
				// begin of insert - D5OW5 - Dt 03/03/2022	
			} else if (selTab === "empHomeZone") {
				oPage = that.byId("divDropDownHZ");
				divTable = that.byId("divDropDownHZ");
				divTable.setModel(divJsonPos, "divModelData");
			}
			// end of insert - D5OW5 - Dt 03/03/2022
			oPage.setBusy(true);
			oPage.setBusyIndicatorDelay(0);
			var key = new sap.ui.model.Filter("Key", "EQ", "D");
			queryFil.push(key);
			oModel.read("/QualDropDownsSet", {
				filters: queryFil,
				success: function (oData) {
					oPage.setBusy(false);
					if (oData.results.length > 0) {
						if (sap.ui.getCore().byId("empSenMoreDivisionInp")) {
							divJsonPos.setData(oData);
							sap.ui.getCore().byId("empSenMoreDivisionInp").setModel(divJsonPos, "divModelData");
						}
						// begin of insert - D5OW5 - Dt 03/03/2022
						if (that.byId("divDropDownHZ")) {
							divJsonPos.setData(oData);
							that.byId("divDropDownHZ").setModel(divJsonPos, "divModelData");
						}
						// end of insert - D5OW5 - Dt 03/03/2022						
						divTable.getModel("divModelData").setData(oData);
						divTable.getModel("divModelData").refresh();
					}
				},
				error: function (oResponse) {
					oPage.setBusy(false);
					that.errorMessageFun(oResponse);
				}
			});
		},
		onDptDropDownValues: function () {
			var that = this;
			var selTab = that.byId("IconTabbarId").getSelectedKey();
			var oModel = that.getOwnerComponent().getModel();
			var dptJsonPos = new sap.ui.model.json.JSONModel({});
			oModel.read("/DeptSearchHelpSet", {
				success: function (oData) {
					// oPage.setBusy(false);
					if (oData.results.length > 0) {
						dptJsonPos.setData(oData);
						that.byId("empSenDeptInp").setModel(dptJsonPos, "depModelData");
						that.byId("empSenDeptInp").getModel("depModelData").refresh();
					}
				},
				error: function (oResponse) {
					that.errorMessageFun(oResponse);
				}
			});
		},
		onCraftDropDownValues: function () {
			var that = this;
			var oModel = that.getOwnerComponent().getModel();
			var queryFil = [];
			var oPage = that.byId("empSenCraftInp");
			var craftJsonPos = new sap.ui.model.json.JSONModel({});
			var craftTable = that.byId("empSenCraftInp");
			craftTable.setModel(craftJsonPos, "craftModelData");
			oPage.setBusy(true);
			oPage.setBusyIndicatorDelay(0);
			var key = new sap.ui.model.Filter("Key", "EQ", "C");
			queryFil.push(key);
			oModel.read("/QualDropDownsSet", {
				filters: queryFil,
				success: function (oData) {
					oPage.setBusy(false);
					if (oData.results.length > 0) {
						craftTable.getModel("craftModelData").setData(oData);
						craftTable.getModel("craftModelData").refresh();
					}
				},
				error: function (oResponse) {
					oPage.setBusy(false);
					that.errorMessageFun(oResponse);
				}
			});
		},
		onHomeZoneDropDownValues: function () {
			var that = this;
			var oModel = that.getOwnerComponent().getModel();
			var queryFil = [];
			var oPage = that.byId("empHomeZoneDropDown");
			var homeZoneJsonPos = new sap.ui.model.json.JSONModel({});
			var homeZoneDropDownTable = that.byId("empHomeZoneDropDown");
			homeZoneDropDownTable.setModel(homeZoneJsonPos, "homeZoneDropDownModelData");
			oPage.setBusy(true);
			oPage.setBusyIndicatorDelay(0);
			var key = new sap.ui.model.Filter("Key", "EQ", "Z");
			queryFil.push(key);
			oModel.read("/QualDropDownsSet", {
				filters: queryFil,
				success: function (oData) {
					oPage.setBusy(false);
					if (oData.results.length > 0) {
						homeZoneDropDownTable.getModel("homeZoneDropDownModelData").setData(oData);
						homeZoneDropDownTable.getModel("homeZoneDropDownModelData").refresh();
					}
				},
				error: function (oResponse) {
					oPage.setBusy(false);
					that.errorMessageFun(oResponse);
				}
			});
		},
		onRrCodeDropDownValues: function () {
			var that = this;
			var selTab = that.byId("IconTabbarId").getSelectedKey();
			var oModel = that.getOwnerComponent().getModel();
			var queryFil = [];
			var oPage;
			var rrCodeTable;
			var rrCodeJsonPos = new sap.ui.model.json.JSONModel({});
			if (selTab === "empSenMaint") {
				oPage = that.byId("empSenRrCodeInp");
				rrCodeTable = that.byId("empSenRrCodeInp");
				rrCodeTable.setModel(rrCodeJsonPos, "rrCodeModelData");
			} else if (selTab === "empHomeZone") {
				oPage = that.byId("empRrHiredDropDown");
				rrCodeTable = that.byId("empRrHiredDropDown");
				rrCodeTable.setModel(rrCodeJsonPos, "rrCodeModelData");
			} else if (selTab === "additionalSenInfo") {
				oPage = that.byId("additionalSenInfoRrCodeDropDown");
				rrCodeTable = that.byId("additionalSenInfoRrCodeDropDown");
				rrCodeTable.setModel(rrCodeJsonPos, "rrCodeModelData");
			}
			oPage.setBusy(true);
			oPage.setBusyIndicatorDelay(0);
			var key = new sap.ui.model.Filter("Key", "EQ", "RR");
			queryFil.push(key);
			oModel.read("/QualDropDownsSet", {
				filters: queryFil,
				success: function (oData) {
					oPage.setBusy(false);
					if (oData.results.length > 0) {
						if (sap.ui.getCore().byId("empSenRrMoreCodeInp")) {
							rrCodeJsonPos.setData(oData);
							sap.ui.getCore().byId("empSenRrMoreCodeInp").setModel(rrCodeJsonPos, "rrCodeModelData");
						}
						rrCodeTable.getModel("rrCodeModelData").setData(oData);
						rrCodeTable.getModel("rrCodeModelData").refresh();
					}
				},
				error: function (oResponse) {
					oPage.setBusy(false);
					that.errorMessageFun(oResponse);
				}
			});
		},
		onDistDropDownValues: function () {
			var that = this;
			var selTab = that.byId("IconTabbarId").getSelectedKey();
			var oModel = that.getOwnerComponent().getModel();
			var queryFil = [];
			var oPage;
			var distTable;
			var distJsonPos = new sap.ui.model.json.JSONModel({});
			if (selTab === "empSenMaint") {
				oPage = that.byId("empSenDistrictInp");
				distTable = that.byId("empSenDistrictInp");
				distTable.setModel(distJsonPos, "distModelData");
			} else if (selTab === "additionalSenInfo") {
				oPage = that.byId("additionalSenInfoDistDropDown");
				distTable = that.byId("additionalSenInfoDistDropDown");
				distTable.setModel(distJsonPos, "distModelData");
				// begin of insert - D5OW5 - Dt 03/03/2022	
			} else if (selTab === "empHomeZone") {
				oPage = that.byId("districtDropDownHZ");
				distTable = that.byId("districtDropDownHZ");
				distTable.setModel(distJsonPos, "distModelData");
			}
			// end of insert - D5OW5 - Dt 03/03/2022
			oPage.setBusy(true);
			oPage.setBusyIndicatorDelay(0);
			var key = new sap.ui.model.Filter("Key", "EQ", "DI");
			queryFil.push(key);
			oModel.read("/QualDropDownsSet", {
				filters: queryFil,
				success: function (oData) {
					oPage.setBusy(false);
					if (oData.results.length > 0) {
						if (sap.ui.getCore().byId("empSenMoreDistrictInp")) {
							distJsonPos.setData(oData);
							sap.ui.getCore().byId("empSenMoreDistrictInp").setModel(distJsonPos, "distModelData");
						}
						// begin of insert - D5OW5 - Dt 03/03/2022
						if (that.byId("districtDropDownHZ")) {
							distJsonPos.setData(oData);
							that.byId("districtDropDownHZ").setModel(distJsonPos, "distModelData");
						}
						// end of insert - D5OW5 - Dt 03/03/2022						
						distTable.getModel("distModelData").setData(oData);
						distTable.getModel("distModelData").refresh();
					}
				},
				error: function (oResponse) {
					oPage.setBusy(false);
					that.errorMessageFun(oResponse);
				}
			});
		},
		onDpgZoneDropDownValues: function () {
			var that = this;
			var oModel = that.getOwnerComponent().getModel();
			var queryFil = [];
			var oPage = that.byId("empSenDpgZoneInp");
			var dpgZoneJsonPos = new sap.ui.model.json.JSONModel({});
			var dpgZoneTable = that.byId("empSenDpgZoneInp");
			dpgZoneTable.setModel(dpgZoneJsonPos, "dpgZoneModelData");
			oPage.setBusy(true);
			oPage.setBusyIndicatorDelay(0);
			var key = new sap.ui.model.Filter("Key", "EQ", "Z");
			queryFil.push(key);
			oModel.read("/QualDropDownsSet", {
				filters: queryFil,
				success: function (oData) {
					oPage.setBusy(false);
					if (oData.results.length > 0) {
						if (sap.ui.getCore().byId("empSenDpgZoneInp")) {
							dpgZoneJsonPos.setData(oData);
							sap.ui.getCore().byId("empSenDpgZoneInp").setModel(dpgZoneJsonPos, "dpgZoneModelData");
						}
						dpgZoneTable.getModel("dpgZoneModelData").setData(oData);
						dpgZoneTable.getModel("dpgZoneModelData").refresh();
					}
				},
				error: function (oResponse) {
					oPage.setBusy(false);
					that.errorMessageFun(oResponse);
				}
			});
		},
		errorMessageFun: function (oResponse) {
			var that = this;
			var titleInfo = that.getView().getModel("i18n").getProperty("titleInfo");
			var ok = that.getView().getModel("i18n").getProperty("ok");
			//-----------------------------------------------------------------------	
			// Displaying response body message.
			//-----------------------------------------------------------------------
			var oMessage;
			if (oResponse.statusCode === 400 || oResponse.statusCode === "400") {
				oMessage = JSON.parse(oResponse.responseText).error.message.value;
			} else if (oResponse.statusCode === 500) {
				oMessage = $(oResponse.responseText).find("message").first().text();
			}
			sap.m.MessageBox.show(
				oMessage, {
					icon: sap.m.MessageBox.Icon.INFORMATION,
					title: titleInfo,
					onClose: function (sAction) {
						if (sAction === "OK") {}
					}
				});
		},
		//-----------------------------------------------------------------------	
		// ---------- Roster Multi tab functionality --------------
		//-----------------------------------------------------------------------
		onSearch: function (oEvent) {
			var that = this;
			var empId = "";
			if (that.byId("empSenMaintenanceSearch").getTokens().length > 0) {
				empId = that.byId("empSenMaintenanceSearch").getTokens()[0].getKey();
			}
			var oFlag = true;
			if (empId === "") {
				sap.m.MessageToast.show("Please enter Employee ID");
				oFlag = false;
			}
			if (oFlag) {
				if (that.craftUnion === "Engineering") {
					var engRoster = oEvent.getSource().getValue().trim();
					if (!that._engRosterDialog) {
						that._engRosterDialog = sap.ui.xmlfragment("com.empqualassignment.Employee_Qual_Assignment.fragment.EngRoster", that.getView()
							.getController());
						that.getView().addDependent(that._engRosterDialog);
					}
					that._engRosterDialog.open();
					that._engRosterDialog.setEscapeHandler(function (o) {
						o.reject();
					});
					sap.ui.getCore().byId("idEngRosterIconTabBar").setSelectedKey("Roster Number Or Description");
					sap.ui.getCore().byId("dialoguEngRosterNoDescSearch").setValue(engRoster);
					sap.ui.getCore().byId("dialoguEngRosterNoDescSearch").fireSearch();
				} else if (that.craftUnion === "Mechanical") {
					var mechRoster = oEvent.getSource().getValue().trim();
					if (!that._mechRosterDialog) {
						that._mechRosterDialog = sap.ui.xmlfragment("com.empqualassignment.Employee_Qual_Assignment.fragment.MechRoster", that.getView()
							.getController());
						that.getView().addDependent(that._mechRosterDialog);
					}
					that._mechRosterDialog.open();
					that._mechRosterDialog.setEscapeHandler(function (o) {
						o.reject();
					});
					sap.ui.getCore().byId("idMechRosterIconTabBar").setSelectedKey("Roster Number Or Description");
					sap.ui.getCore().byId("dialoguMechRosterNoDescSearch").setValue(mechRoster);
					sap.ui.getCore().byId("dialoguMechRosterNoDescSearch").fireSearch();
				} else if (that.craftUnion === "TCU") {
					var tcuRoster = oEvent.getSource().getValue().trim();
					if (!that._tcuRosterDialog) {
						that._tcuRosterDialog = sap.ui.xmlfragment("com.empqualassignment.Employee_Qual_Assignment.fragment.TcuAtdaRoster", that.getView()
							.getController());
						that.getView().addDependent(that._tcuRosterDialog);
					}
					that._tcuRosterDialog.open();
					that._tcuRosterDialog.setEscapeHandler(function (o) {
						o.reject();
					});
					sap.ui.getCore().byId("idTcuRosterIconTabBar").setSelectedKey("Roster Number Or Description");
					sap.ui.getCore().byId("dialoguTcuRosterNoDescSearch").setValue(tcuRoster);
					sap.ui.getCore().byId("dialoguTcuRosterNoDescSearch").fireSearch();
				} else if (that.craftUnion === "ATDA") {
					var atdaRoster = oEvent.getSource().getValue().trim();
					if (!that._atdaRosterDialog) {
						that._atdaRosterDialog = sap.ui.xmlfragment("com.empqualassignment.Employee_Qual_Assignment.fragment.ATDARoster", that.getView()
							.getController());
						that.getView().addDependent(that._atdaRosterDialog);
					}
					that._atdaRosterDialog.open();
					that._atdaRosterDialog.setEscapeHandler(function (o) {
						o.reject();
					});
					sap.ui.getCore().byId("idAtdaRosterIconTabBar").setSelectedKey("Roster Number Or Description");
					sap.ui.getCore().byId("dialoguAtdaRosterNoDescSearch").setValue(atdaRoster);
					sap.ui.getCore().byId("dialoguAtdaRosterNoDescSearch").fireSearch();
				} else if (that.craftUnion === "ILA") {
					var ilaRoster = oEvent.getSource().getValue().trim();
					if (!that._ilaRosterDialog) {
						that._ilaRosterDialog = sap.ui.xmlfragment("com.empqualassignment.Employee_Qual_Assignment.fragment.IlaRoster", that.getView()
							.getController());
						that.getView().addDependent(that._ilaRosterDialog);
					}
					that._ilaRosterDialog.open();
					that._ilaRosterDialog.setEscapeHandler(function (o) {
						o.reject();
					});
					sap.ui.getCore().byId("idIlaRosterIconTabBar").setSelectedKey("Roster Number Or Description");
					sap.ui.getCore().byId("dialogueIlaRosterNoDescSearch").setValue(ilaRoster);
					sap.ui.getCore().byId("dialogueIlaRosterNoDescSearch").fireSearch();
				}
			}
		},
		onEngRosterSearch: function (oEvent) {
			var that = this;
			var selIconTab = sap.ui.getCore().byId("idEngRosterIconTabBar").getSelectedKey();
			var oRosterModel = that.getOwnerComponent().getModel();
			var engQueryFil = [];
			var engKey = new sap.ui.model.Filter("Key", "EQ", "E");
			var empIDValue = "";
			if (that.byId("empSenMaintenanceSearch").getTokens().length > 0) {
				empIDValue = that.byId("empSenMaintenanceSearch").getTokens()[0].getKey();
			}
			var empKey = new sap.ui.model.Filter("Employee", "EQ", empIDValue);
			engQueryFil.push(empKey);
			if (selIconTab === "Roster Number Or Description") {
				var rosterNoDesc = sap.ui.getCore().byId("dialoguEngRosterNoDescSearch").getValue();
				var rosterNoDescJsonModel = new sap.ui.model.json.JSONModel({});
				var rosterNoDescTable = sap.ui.getCore().byId("engRosterNoDescTabTable");
				rosterNoDescTable.setModel(rosterNoDescJsonModel, "engRosterNoDescModelData");
				if (rosterNoDesc.length > 0) {
					var numericReg = /[^0-9]/;
					var stringReg = /[^a-z]/;
					var engRosterNo;
					if (!rosterNoDesc.match(numericReg)) {
						engRosterNo = new sap.ui.model.Filter("RosterNo", "EQ", rosterNoDesc);
					} else if (!rosterNoDesc.match(stringReg)) {
						engRosterNo = new sap.ui.model.Filter("Employee", "EQ", rosterNoDesc);
					} else {
						engRosterNo = new sap.ui.model.Filter("RosterNo", "EQ", rosterNoDesc);
					}
					engQueryFil.push(engRosterNo);
					engQueryFil.push(engKey);
					oRosterModel.read("/RosterSearchhelpSet", {
						filters: engQueryFil,
						success: function (oData) {
							if (oData.results.length > 0) {
								rosterNoDescTable.getModel("engRosterNoDescModelData").setData(oData);
								rosterNoDescTable.getModel("engRosterNoDescModelData").refresh();
								sap.ui.getCore().byId("engRosterNoDescTabTable").setVisible(true);
							} else {
								sap.ui.getCore().byId("engRosterNoDescTabTable").setVisible(false);
							}
						},
						error: function (oResponse) {
							that.errorMessageDisp(oResponse);
						}
					});
				} else {
					rosterNoDescTable.getModel("engRosterNoDescModelData").setData({});
					rosterNoDescTable.getModel("engRosterNoDescModelData").refresh();
				}
			} else if (selIconTab === "District") {
				var rosterDist = sap.ui.getCore().byId("dialoguDistSearch").getValue();
				var rosterDistJsonModel = new sap.ui.model.json.JSONModel({});
				var rosterDistTable = sap.ui.getCore().byId("engDistTabTable");
				rosterDistTable.setModel(rosterDistJsonModel, "engDistModelData");
				if (rosterDist.length > 1) {
					var engDist = new sap.ui.model.Filter("District", "EQ", rosterDist);
					engQueryFil.push(engDist);
					engQueryFil.push(engKey);
					oRosterModel.read("/RosterSearchhelpSet", {
						filters: engQueryFil,
						success: function (oData) {
							if (oData.results.length > 0) {
								rosterDistTable.getModel("engDistModelData").setData(oData);
								rosterDistTable.getModel("engDistModelData").refresh();
								sap.ui.getCore().byId("engDistTabTable").setVisible(true);
							} else {
								sap.ui.getCore().byId("engDistTabTable").setVisible(false);
							}
						},
						error: function (oResponse) {
							that.errorMessageDisp(oResponse);
						}
					});
				} else {
					rosterDistTable.getModel("engDistModelData").setData({});
					rosterDistTable.getModel("engDistModelData").refresh();
				}
			} else if (selIconTab === "Employee ID/Name") {
				var rosterEmpIdName = sap.ui.getCore().byId("dialoguEngEmpIdNameSearch").getValue();
				var rosterEmpIdNameJsonModel = new sap.ui.model.json.JSONModel({});
				var rosterEmpIdNameTable = sap.ui.getCore().byId("engEmpIdNameTabTable");
				rosterEmpIdNameTable.setModel(rosterEmpIdNameJsonModel, "engEmpIdNameModelData");
				if (rosterEmpIdName.length > 1) {
					var engEmpIdName = new sap.ui.model.Filter("Employee", "EQ", rosterEmpIdName);
					engQueryFil.push(engEmpIdName);
					engQueryFil.push(engKey);
					oRosterModel.read("/RosterSearchhelpSet", {
						filters: engQueryFil,
						success: function (oData) {
							if (oData.results.length > 0) {
								rosterEmpIdNameTable.getModel("engEmpIdNameModelData").setData(oData);
								rosterEmpIdNameTable.getModel("engEmpIdNameModelData").refresh();
								sap.ui.getCore().byId("engEmpIdNameTabTable").setVisible(true);
							} else {
								sap.ui.getCore().byId("engEmpIdNameTabTable").setVisible(false);
							}
						},
						error: function (oResponse) {
							that.errorMessageDisp(oResponse);
						}
					});
				} else {
					rosterEmpIdNameTable.getModel("engEmpIdNameModelData").setData({});
					rosterEmpIdNameTable.getModel("engEmpIdNameModelData").refresh();
				}
			}
		},
		onMechRosterSearch: function (oEvent) {
			var that = this;
			var selIconTab = sap.ui.getCore().byId("idMechRosterIconTabBar").getSelectedKey();
			var oRosterModel = that.getOwnerComponent().getModel();
			var mechQueryFil = [];
			var mechKey = new sap.ui.model.Filter("Key", "EQ", "M");
			var empIDValue = "";
			if (that.byId("empSenMaintenanceSearch").getTokens().length > 0) {
				empIDValue = that.byId("empSenMaintenanceSearch").getTokens()[0].getKey();
			}
			var empKey = new sap.ui.model.Filter("Employee", "EQ", empIDValue);
			mechQueryFil.push(empKey);
			if (selIconTab === "Roster Number Or Description") {
				var mechRosterNoDesc = sap.ui.getCore().byId("dialoguMechRosterNoDescSearch").getValue();
				var mechRosterNoDescJsonModel = new sap.ui.model.json.JSONModel({});
				var mechRosterNoDescTable = sap.ui.getCore().byId("mechRosterNoDescTabTable");
				mechRosterNoDescTable.setModel(mechRosterNoDescJsonModel, "mechRosterNoDescModelData");
				if (mechRosterNoDesc.length > 1) {
					var numericReg = /[^0-9]/;
					var stringReg = /[^a-z]/;
					var mechRosterNo;
					if (!mechRosterNoDesc.match(numericReg)) {
						mechRosterNo = new sap.ui.model.Filter("RosterNo", "EQ", mechRosterNoDesc);
					} else if (!mechRosterNoDesc.match(stringReg)) {
						mechRosterNo = new sap.ui.model.Filter("Employee", "EQ", mechRosterNoDesc);
					} else {
						mechRosterNo = new sap.ui.model.Filter("RosterNo", "EQ", mechRosterNoDesc);
					}
					mechQueryFil.push(mechRosterNo);
					mechQueryFil.push(mechKey);
					oRosterModel.read("/RosterSearchhelpSet", {
						filters: mechQueryFil,
						success: function (oData) {
							if (oData.results.length > 0) {
								mechRosterNoDescTable.getModel("mechRosterNoDescModelData").setData(oData);
								mechRosterNoDescTable.getModel("mechRosterNoDescModelData").refresh();
								sap.ui.getCore().byId("mechRosterNoDescTabTable").setVisible(true);
							} else {
								sap.ui.getCore().byId("mechRosterNoDescTabTable").setVisible(false);
							}
						},
						error: function (oResponse) {
							that.errorMessageDisp(oResponse);
						}
					});
				} else {
					mechRosterNoDescTable.getModel("mechRosterNoDescModelData").setData({});
					mechRosterNoDescTable.getModel("mechRosterNoDescModelData").refresh();
				}
			} else if (selIconTab === "City") {
				var mechCityVal = sap.ui.getCore().byId("dialoguMechCitySearch").getValue();
				var mechCityJsonModel = new sap.ui.model.json.JSONModel({});
				var mechCityTable = sap.ui.getCore().byId("mechCityTabTable");
				mechCityTable.setModel(mechCityJsonModel, "mechRosterCityModelData");
				if (mechCityVal.length > 1) {
					var mechCity = new sap.ui.model.Filter("City", "EQ", mechCityVal);
					mechQueryFil.push(mechCity);
					mechQueryFil.push(mechKey);
					oRosterModel.read("/RosterSearchhelpSet", {
						filters: mechQueryFil,
						success: function (oData) {
							if (oData.results.length > 0) {
								mechCityTable.getModel("mechRosterCityModelData").setData(oData);
								mechCityTable.getModel("mechRosterCityModelData").refresh();
								sap.ui.getCore().byId("mechCityTabTable").setVisible(true);
							} else {
								sap.ui.getCore().byId("mechCityTabTable").setVisible(false);
							}
						},
						error: function (oResponse) {
							that.errorMessageDisp(oResponse);
						}
					});
				} else {
					mechCityTable.getModel("mechRosterCityModelData").setData({});
					mechCityTable.getModel("mechRosterCityModelData").refresh();
				}
			} else if (selIconTab === "Employee ID/Name") {
				var mechEmpIdNameVal = sap.ui.getCore().byId("dialoguMechEmpIdNameSearch").getValue();
				var mechEmpIdNameJsonModel = new sap.ui.model.json.JSONModel({});
				var mechEmpIdNameTable = sap.ui.getCore().byId("mechEmpIdNameTabTable");
				mechEmpIdNameTable.setModel(mechEmpIdNameJsonModel, "mechRosterEmpIdNameModelData");
				if (mechEmpIdNameVal.length > 1) {
					var mechEmpIdName = new sap.ui.model.Filter("Employee", "EQ", mechEmpIdNameVal);
					mechQueryFil.push(mechEmpIdName);
					mechQueryFil.push(mechKey);
					oRosterModel.read("/RosterSearchhelpSet", {
						filters: mechQueryFil,
						success: function (oData) {
							if (oData.results.length > 0) {
								mechEmpIdNameTable.getModel("mechRosterEmpIdNameModelData").setData(oData);
								mechEmpIdNameTable.getModel("mechRosterEmpIdNameModelData").refresh();
								sap.ui.getCore().byId("mechEmpIdNameTabTable").setVisible(true);
							} else {
								sap.ui.getCore().byId("mechEmpIdNameTabTable").setVisible(false);
							}

						},
						error: function (oResponse) {
							that.errorMessageDisp(oResponse);
						}
					});

				} else {
					mechEmpIdNameTable.getModel("mechRosterEmpIdNameModelData").setData({});
					mechEmpIdNameTable.getModel("mechRosterEmpIdNameModelData").refresh();
				}

			}

		},

		onTcuRosterSearch: function (oEvent) {
			var that = this;
			var selIconTab = sap.ui.getCore().byId("idTcuRosterIconTabBar").getSelectedKey();
			var oRosterModel = that.getOwnerComponent().getModel();
			var tcuQueryFil = [];
			var tcuKey = new sap.ui.model.Filter("Key", "EQ", "T");
			var empIDValue = "";
			if (that.byId("empSenMaintenanceSearch").getTokens().length > 0) {
				empIDValue = that.byId("empSenMaintenanceSearch").getTokens()[0].getKey();
			}
			var empKey = new sap.ui.model.Filter("Employee", "EQ", empIDValue);
			tcuQueryFil.push(empKey);
			if (selIconTab === "Roster Number Or Description") {
				var tcuRosterNoDesc = sap.ui.getCore().byId("dialoguTcuRosterNoDescSearch").getValue();
				var tcuJsonModel = new sap.ui.model.json.JSONModel({});
				var tcuRosterNoDescTable = sap.ui.getCore().byId("tcuRosterNoDescTabTable");
				tcuRosterNoDescTable.setModel(tcuJsonModel, "tcuRosterNoDescModelData");
				if (tcuRosterNoDesc.length > 1) {
					var numericReg = /[^0-9]/;
					var stringReg = /[^a-z]/;
					var tcuRosterNo;
					if (!tcuRosterNoDesc.match(numericReg)) {
						tcuRosterNo = new sap.ui.model.Filter("RosterNo", "EQ", tcuRosterNoDesc);
					} else if (!tcuRosterNoDesc.match(stringReg)) {
						tcuRosterNo = new sap.ui.model.Filter("Employee", "EQ", tcuRosterNoDesc);
					} else {
						tcuRosterNo = new sap.ui.model.Filter("RosterNo", "EQ", tcuRosterNoDesc);
					}
					tcuQueryFil.push(tcuRosterNo);
					tcuQueryFil.push(tcuKey);
					oRosterModel.read("/RosterSearchhelpSet", {
						filters: tcuQueryFil,
						success: function (oData) {
							if (oData.results.length > 0) {
								tcuRosterNoDescTable.getModel("tcuRosterNoDescModelData").setData(oData);
								tcuRosterNoDescTable.getModel("tcuRosterNoDescModelData").refresh();
								sap.ui.getCore().byId("tcuRosterNoDescTabTable").setVisible(true);
							} else {
								sap.ui.getCore().byId("tcuRosterNoDescTabTable").setVisible(false);
							}
						},
						error: function (oResponse) {
							that.errorMessageDisp(oResponse);
						}
					});

				} else {
					tcuRosterNoDescTable.getModel("tcuRosterNoDescModelData").setData({});
					tcuRosterNoDescTable.getModel("tcuRosterNoDescModelData").refresh();
				}

			} else if (selIconTab === "Department") {

				var tcuDeptVal = sap.ui.getCore().byId("dialoguTcuDeptSearch").getValue();
				var tcuDeptJsonModel = new sap.ui.model.json.JSONModel({});
				var tcuDeptTable = sap.ui.getCore().byId("tcuDeptTabTable");
				tcuDeptTable.setModel(tcuDeptJsonModel, "tcuDeptModelData");
				if (tcuDeptVal.length > 1) {
					var tcuDept = new sap.ui.model.Filter("Department", "EQ", tcuDeptVal);
					tcuQueryFil.push(tcuDept);
					tcuQueryFil.push(tcuKey);

					oRosterModel.read("/RosterSearchhelpSet", {
						filters: tcuQueryFil,
						success: function (oData) {

							if (oData.results.length > 0) {
								tcuDeptTable.getModel("tcuDeptModelData").setData(oData);
								tcuDeptTable.getModel("tcuDeptModelData").refresh();
								sap.ui.getCore().byId("tcuDeptTabTable").setVisible(true);
							} else {
								sap.ui.getCore().byId("tcuDeptTabTable").setVisible(false);
							}

						},
						error: function (oResponse) {
							that.errorMessageDisp(oResponse);
						}
					});

				} else {
					tcuDeptTable.getModel("tcuDeptModelData").setData({});
					tcuDeptTable.getModel("tcuDeptModelData").refresh();
				}

			} else if (selIconTab === "Employee ID/Name") {

				var tcuEmpIdNameVal = sap.ui.getCore().byId("dialoguTcuEmpIdNameSearch").getValue();
				var tcuEmpIdNameJsonModel = new sap.ui.model.json.JSONModel({});
				var tcuEmpIdNameTable = sap.ui.getCore().byId("tcuEmpIdNameTabTable");
				tcuEmpIdNameTable.setModel(tcuEmpIdNameJsonModel, "tcuEmpIdNameModelData");
				if (tcuEmpIdNameVal.length > 1) {
					var tcuEmpIdName = new sap.ui.model.Filter("Employee", "EQ", tcuEmpIdNameVal);
					tcuQueryFil.push(tcuEmpIdName);
					tcuQueryFil.push(tcuKey);

					oRosterModel.read("/RosterSearchhelpSet", {
						filters: tcuQueryFil,
						success: function (oData) {

							if (oData.results.length > 0) {
								tcuEmpIdNameTable.getModel("tcuEmpIdNameModelData").setData(oData);
								tcuEmpIdNameTable.getModel("tcuEmpIdNameModelData").refresh();
								sap.ui.getCore().byId("tcuEmpIdNameTabTable").setVisible(true);

							} else {
								sap.ui.getCore().byId("tcuEmpIdNameTabTable").setVisible(false);
							}

						},
						error: function (oResponse) {
							that.errorMessageDisp(oResponse);
						}
					});

				} else {
					tcuEmpIdNameTable.getModel("tcuEmpIdNameModelData").setData({});
					tcuEmpIdNameTable.getModel("tcuEmpIdNameModelData").refresh();
				}

			}

		},

		onAtdaRosterSearch: function (oEvent) {

			var that = this;
			var selIconTab = sap.ui.getCore().byId("idAtdaRosterIconTabBar").getSelectedKey();
			var oRosterModel = that.getOwnerComponent().getModel();

			var atdaQueryFil = [];
			var atdaKey = new sap.ui.model.Filter("Key", "EQ", "A");
			var empIDValue = "";
			if (that.byId("empSenMaintenanceSearch").getTokens().length > 0) {
				empIDValue = that.byId("empSenMaintenanceSearch").getTokens()[0].getKey();
			}
			var empKey = new sap.ui.model.Filter("Employee", "EQ", empIDValue);
			atdaQueryFil.push(empKey);
			if (selIconTab === "Roster Number Or Description") {

				var atdaRosterNoDesc = sap.ui.getCore().byId("dialoguAtdaRosterNoDescSearch").getValue();
				var atdaJsonModel = new sap.ui.model.json.JSONModel({});
				var atdaRosterNoDescTable = sap.ui.getCore().byId("atdaRosterNoDescTabTable");
				atdaRosterNoDescTable.setModel(atdaJsonModel, "atdaRosterNoDescModelData");
				if (atdaRosterNoDesc.length > 1) {
					var atdaRosterNo = new sap.ui.model.Filter("RosterNo", "EQ", atdaRosterNoDesc);
					atdaQueryFil.push(atdaRosterNo);
					atdaQueryFil.push(atdaKey);

					oRosterModel.read("/RosterSearchhelpSet", {
						filters: atdaQueryFil,
						success: function (oData) {

							if (oData.results.length > 0) {
								atdaRosterNoDescTable.getModel("atdaRosterNoDescModelData").setData(oData);
								atdaRosterNoDescTable.getModel("atdaRosterNoDescModelData").refresh();
								sap.ui.getCore().byId("atdaRosterNoDescTabTable").setVisible(true);
							} else {
								sap.ui.getCore().byId("atdaRosterNoDescTabTable").setVisible(false);
							}

						},
						error: function (oResponse) {
							that.errorMessageDisp(oResponse);
						}
					});

				} else {
					atdaRosterNoDescTable.getModel("atdaRosterNoDescModelData").setData({});
					atdaRosterNoDescTable.getModel("atdaRosterNoDescModelData").refresh();
				}

			} else if (selIconTab === "Department") {

				var atdaDeptVal = sap.ui.getCore().byId("dialoguAtdaDeptSearch").getValue();
				var atdaDeptJsonModel = new sap.ui.model.json.JSONModel({});
				var atdaDeptTable = sap.ui.getCore().byId("atdaDeptTabTable");
				atdaDeptTable.setModel(atdaDeptJsonModel, "atdaDeptModelData");
				if (atdaDeptVal.length > 1) {
					var atdaDept = new sap.ui.model.Filter("Department", "EQ", atdaDeptVal);
					atdaQueryFil.push(atdaDept);
					atdaQueryFil.push(atdaKey);

					oRosterModel.read("/RosterSearchhelpSet", {
						filters: atdaQueryFil,
						success: function (oData) {

							if (oData.results.length > 0) {
								atdaDeptTable.getModel("atdaDeptModelData").setData(oData);
								atdaDeptTable.getModel("atdaDeptModelData").refresh();
								sap.ui.getCore().byId("atdaDeptTabTable").setVisible(true);
							} else {
								sap.ui.getCore().byId("atdaDeptTabTable").setVisible(false);
							}

						},
						error: function (oResponse) {
							that.errorMessageDisp(oResponse);
						}
					});

				} else {
					atdaDeptTable.getModel("atdaDeptModelData").setData({});
					atdaDeptTable.getModel("atdaDeptModelData").refresh();
				}

			} else if (selIconTab === "Employee ID/Name") {

				var atdaEmpIdNameVal = sap.ui.getCore().byId("dialoguAtdaEmpIdNameSearch").getValue();
				var atdaEmpIdNameJsonModel = new sap.ui.model.json.JSONModel({});
				var atdaEmpIdNameTable = sap.ui.getCore().byId("atdaEmpIdNameTabTable");
				atdaEmpIdNameTable.setModel(atdaEmpIdNameJsonModel, "atdaEmpIdNameModelData");
				if (atdaEmpIdNameVal.length > 1) {
					var atdaEmpIdName = new sap.ui.model.Filter("Employee", "EQ", atdaEmpIdNameVal);
					atdaQueryFil.push(atdaEmpIdName);
					atdaQueryFil.push(atdaKey);

					oRosterModel.read("/RosterSearchhelpSet", {
						filters: atdaQueryFil,
						success: function (oData) {

							if (oData.results.length > 0) {
								atdaEmpIdNameTable.setModel("atdaEmpIdNameModelData").setData(oData);
								atdaEmpIdNameTable.setModel("atdaEmpIdNameModelData").refresh();
								sap.ui.getCore().byId("atdaEmpIdNameTabTable").setVisible(true);
							} else {
								sap.ui.getCore().byId("atdaEmpIdNameTabTable").setVisible(false);
							}

						},
						error: function (oResponse) {
							that.errorMessageDisp(oResponse);
						}
					});

				} else {
					atdaEmpIdNameTable.setModel("atdaEmpIdNameModelData").setData({});
					atdaEmpIdNameTable.setModel("atdaEmpIdNameModelData").refresh();
				}

			}

		},

		onIlaRosterSearch: function (oEvent) {

			var that = this;
			var selIconTab = sap.ui.getCore().byId("idIlaRosterIconTabBar").getSelectedKey();
			var oRosterModel = that.getOwnerComponent().getModel();

			var ilaRosterNoDescQueryFil = [];
			var ilaKey = new sap.ui.model.Filter("Key", "EQ", "I");
			var empIDValue = "";
			if (that.byId("empSenMaintenanceSearch").getTokens().length > 0) {
				empIDValue = that.byId("empSenMaintenanceSearch").getTokens()[0].getKey();
			}
			var empKey = new sap.ui.model.Filter("Employee", "EQ", empIDValue);
			ilaRosterNoDescQueryFil.push(empKey);
			if (selIconTab === "Roster Number Or Description") {

				var ilaRosterNoDescVal = sap.ui.getCore().byId("dialogueIlaRosterNoDescSearch").getValue();
				var ilaRosterNoDescJsonModel = new sap.ui.model.json.JSONModel({});
				var ilaRosterNoDescTable = sap.ui.getCore().byId("ilaRosterNoDescTable");
				ilaRosterNoDescTable.setModel(ilaRosterNoDescJsonModel, "ilaRosterNoDescModelData");
				if (ilaRosterNoDescVal.length > 1) {
					var ilaRosterNoDesc = new sap.ui.model.Filter("RosterNo", "EQ", ilaRosterNoDescVal);
					ilaRosterNoDescQueryFil.push(ilaRosterNoDesc);
					ilaRosterNoDescQueryFil.push(ilaKey);

					oRosterModel.read("/RosterSearchhelpSet", {
						filters: ilaRosterNoDescQueryFil,
						success: function (oData) {

							if (oData.results.length > 0) {
								ilaRosterNoDescTable.getModel("ilaRosterNoDescModelData").setData(oData);
								ilaRosterNoDescTable.getModel("ilaRosterNoDescModelData").refresh();
								sap.ui.getCore().byId("ilaRosterNoDescTable").setVisible(true);
							} else {
								sap.ui.getCore().byId("ilaRosterNoDescTable").setVisible(false);
							}

						},
						error: function (oResponse) {
							that.errorMessageDisp(oResponse);
						}
					});

				} else {
					ilaRosterNoDescTable.getModel("ilaRosterNoDescModelData").setData({});
					ilaRosterNoDescTable.getModel("ilaRosterNoDescModelData").refresh();
				}

			} else if (selIconTab === "Employee ID/Name") {

				var ilaEmpIdNameVal = sap.ui.getCore().byId("dialoguIlaEmpIdNameSearch").getValue();
				var ilaEmpIdNameJsonModel = new sap.ui.model.json.JSONModel();
				var ilaEmpIdNameTable = sap.ui.getCore().byId("ilaEmpIdNameTabTable");
				ilaEmpIdNameTable.setModel(ilaEmpIdNameJsonModel, "ilaEmpIdNameModelData");
				if (ilaEmpIdNameVal.length > 1) {
					var ilaEmpIdName = new sap.ui.model.Filter("Employee", "EQ", ilaEmpIdNameVal);
					ilaRosterNoDescQueryFil.push(ilaEmpIdName);
					ilaRosterNoDescQueryFil.push(ilaKey);

					oRosterModel.read("/RosterSearchhelpSet", {
						filters: ilaRosterNoDescQueryFil,
						success: function (oData) {

							if (oData.results.length > 0) {
								ilaEmpIdNameTable.getModel("ilaEmpIdNameModelData").setData(oData);
								ilaEmpIdNameTable.getModel("ilaEmpIdNameModelData").refresh();
								sap.ui.getCore().byId("ilaEmpIdNameTabTable").setVisible(true);
							} else {
								sap.ui.getCore().byId("ilaEmpIdNameTabTable").setVisible(false);
							}

						},
						error: function (oResponse) {
							that.errorMessageDisp(oResponse);
						}
					});

				} else {
					ilaEmpIdNameTable.getModel("ilaEmpIdNameModelData").setData({});
					ilaEmpIdNameTable.getModel("ilaEmpIdNameModelData").refresh();
				}

			}

		},

		onEngRosterDialogCancel: function () {
			var that = this;
			that.engTableClear();
			that._engRosterDialog.close();
		},

		onMechRosterDialogueCancel: function () {
			var that = this;
			that.mechTableClear();
			that._mechRosterDialog.close();
		},

		onTcuRosterDialogCancel: function () {
			var that = this;
			that.tcuTableClear();
			that._tcuRosterDialog.close();
		},

		onAtdaRosterDialogCancel: function () {
			var that = this;
			that.atdaTableClear();
			that._atdaRosterDialog.close();
		},

		onIlaRosterDialogueCancel: function () {
			var that = this;
			that.ilaTableClear();
			that._ilaRosterDialog.close();
		},

		errorMessageDisp: function (oResponse) {

			var that = this;
			var titleInfo = that.getView().getModel("i18n").getProperty("titleInfo");

			//-----------------------------------------------------------------------	
			// Displaying response body message.
			//----------------------------------------------------------------------- 
			var oMessage;
			if (that.byId("rosterNoInp").getValue() !== "") {;
				oMessage = JSON.parse(oResponse.responseText).error.message.value;
			} else {
				oMessage = JSON.parse(oResponse.responseText).error.message.value;
			}
			var errmsg;
			if (oMessage === "") {
				errmsg = oResponse.responseText;
			} else {
				errmsg = oMessage;
			}
			sap.m.MessageBox.show(oMessage, {
				icon: sap.m.MessageBox.Icon.INFORMATION,
				title: titleInfo,
				actions: [sap.m.MessageBox.Action.OK],
				onClose: function (oAction) {
					if (that.craftUnion === "Engineering") {
						var selIconTab = sap.ui.getCore().byId("idEngRosterIconTabBar").getSelectedKey();
						if (selIconTab === "Roster Number Or Description") {
							var rosterNoDescEmptyArr = [];
							var rosterNoDescJSONModel = new JSONModel({
								"results": rosterNoDescEmptyArr
							});
							sap.ui.getCore().byId("engRosterNoDescTabTable").setModel(rosterNoDescJSONModel, "engRosterNoDescModelData");
						} else if (selIconTab === "Union") {
							var engUnionEmptyArr = [];
							var engUnionJSONModel = new JSONModel({
								"results": engUnionEmptyArr
							});
							sap.ui.getCore().byId("engUnionTabTable").setModel(engUnionJSONModel, "engUnionModelData");
						} else if (selIconTab === "RR Code") {
							var rrCodeEmptyArr = [];
							var rrCodeJSONModel = new JSONModel({
								"results": rrCodeEmptyArr
							});
							sap.ui.getCore().byId("engRrCodeTabTable").setModel(rrCodeJSONModel, "engRrCodeModelData");
						} else if (selIconTab === "Region") {
							var regionEmptyArr = [];
							var regionJSONModel = new JSONModel({
								"results": regionEmptyArr
							});
							sap.ui.getCore().byId("engRegionTabTable").setModel(regionJSONModel, "engRegionModelData");
						} else if (selIconTab === "Division") {
							var divEmptyArr = [];
							var divJSONModel = new JSONModel({
								"results": divEmptyArr
							});
							sap.ui.getCore().byId("engDivTabTable").setModel(divJSONModel, "engDivModelData");
						} else if (selIconTab === "District") {
							var distEmptyArr = [];
							var distJSONModel = new JSONModel({
								"results": distEmptyArr
							});
							sap.ui.getCore().byId("engDistTabTable").setModel(distJSONModel, "engDistModelData");
						}
					} else if (that.craftUnion === "Mechanical") {
						var mechSelIconTab = sap.ui.getCore().byId("idMechRosterIconTabBar").getSelectedKey();
						if (mechSelIconTab === "Roster Number Or Description") {
							var rostNoDescEmptyArr = [];
							var rostNoDescJSONModel = new JSONModel({
								"results": rostNoDescEmptyArr
							});
							sap.ui.getCore().byId("mechRosterNoDescTabTable").setModel(rostNoDescJSONModel, "mechRosterNoDescModelData");
						} else if (mechSelIconTab === "Union") {
							var mechUnionEmptyArr = [];
							var mechUnionJSONModel = new JSONModel({
								"results": mechUnionEmptyArr
							});
							sap.ui.getCore().byId("mechUnionTabTable").setModel(mechUnionJSONModel, "mechUnionModelData");

						} else if (mechSelIconTab === "Craft") {

							var craftEmptyArr = [];
							var craftJSONModel = new JSONModel({
								"results": craftEmptyArr
							});
							sap.ui.getCore().byId("mechCraftTabTable").setModel(craftJSONModel, "mechCraftModelData");

						} else if (mechSelIconTab === "Territory") {

							var territoryEmptyArr = [];
							var territoryJSONModel = new JSONModel({
								"results": territoryEmptyArr
							});
							sap.ui.getCore().byId("mechTerritoryTabTable").setModel(territoryJSONModel, "mechTerritoryModelData");

						} else if (mechSelIconTab === "City") {

							var cityEmptyArr = [];
							var cityJSONModel = new JSONModel({
								"results": cityEmptyArr
							});
							sap.ui.getCore().byId("mechCityTabTable").setModel(cityJSONModel, "mechRosterCityModelData");

						} else if (mechSelIconTab === "State") {

							var stateEmptyArr = [];
							var stateJSONModel = new JSONModel({
								"results": stateEmptyArr
							});
							sap.ui.getCore().byId("mechStateTabTable").setModel(stateJSONModel, "mechStateModelData");

						}

					} else if (that.craftUnion === "TCU") {
						var tcuSelIconTab = sap.ui.getCore().byId("idTcuRosterIconTabBar").getSelectedKey();

						if (tcuSelIconTab === "Roster Number Or Description") {

							var tcuRostNoDescEmptyArr = [];
							var tcuRostNoDescJSONModel = new JSONModel({
								"results": tcuRostNoDescEmptyArr
							});
							sap.ui.getCore().byId("tcuRosterNoDescTabTable").setModel(tcuRostNoDescJSONModel, "tcuRosterNoDescModelData");
							sap.ui.getCore().byId("tcuRosterNoDescTabTable").setVisible(false);

						} else if (tcuSelIconTab === "Department") {

							var deptEmptyArr = [];
							var deptJSONModel = new JSONModel({
								"results": deptEmptyArr
							});
							sap.ui.getCore().byId("tcuDeptTabTable").setModel(deptJSONModel, "tcuDeptModelData");
							sap.ui.getCore().byId("tcuDeptTabTable").setVisible(false);

						} else if (tcuSelIconTab === "Employee ID/Name") {

							var empIdNameEmptyArr = [];
							var empIdNameJSONModel = new JSONModel({
								"results": empIdNameEmptyArr
							});
							sap.ui.getCore().byId("tcuEmpIdNameTabTable").setModel(empIdNameJSONModel, "tcuEmpIdNameModelData");
							sap.ui.getCore().byId("tcuEmpIdNameTabTable").setVisible(false);

						}

					} else if (that.craftUnion === "ATDA") {

						var atdaSelIconTab = sap.ui.getCore().byId("atdaRosterDialogue").getSelectedKey();

						if (atdaSelIconTab === "Roster Number Or Description") {

							var atdaRostNoDescEmptyArr = [];
							var atdaRostNoDescJSONModel = new JSONModel({
								"results": atdaRostNoDescEmptyArr
							});
							sap.ui.getCore().byId("atdaRosterNoDescTabTable").setModel(atdaRostNoDescJSONModel, "atdaRosterNoDescModelData");
							sap.ui.getCore().byId("atdaRosterNoDescTabTable").setVisible(false);

						} else if (atdaSelIconTab === "Department") {

							var atdaDeptEmptyArr = [];
							var atdaDeptJSONModel = new JSONModel({
								"results": atdaDeptEmptyArr
							});
							sap.ui.getCore().byId("atdaDeptTabTable").setModel(atdaDeptJSONModel, "atdaDeptModelData");
							sap.ui.getCore().byId("atdaDeptTabTable").setVisible(false);

						}

					} else if (that.craftUnion === "ILA") {

						var ilaRostNoDescEmptyArr = [];
						var ilaRostNoDescJSONModel = new JSONModel({
							"results": ilaRostNoDescEmptyArr
						});
						sap.ui.getCore().byId("ilaRosterNoDescTable").setModel(ilaRostNoDescJSONModel, "ilaRosterNoDescModelData");

					}

				}

			});

		},

		onUnionDropDown: function () {

			var that = this;
			var oRosterModel = that.getOwnerComponent().getModel();

			var craftUnion;
			if (that.craftUnion === "Engineering") {
				craftUnion = "E";
			} else if (that.craftUnion === "Mechanical") {
				craftUnion = "M";
			}

			var unionQueryFil = [];
			var union = new sap.ui.model.Filter("Value", "EQ", craftUnion);
			var unionKey = new sap.ui.model.Filter("Key", "EQ", "U");
			unionQueryFil.push(union);
			unionQueryFil.push(unionKey);

			var unionJsonModel = new sap.ui.model.json.JSONModel();
			oRosterModel.read("/QualDropDownsSet", {
				filters: unionQueryFil,
				success: function (oData) {

					if (oData.results.length > 0) {

						unionJsonModel.setData(oData);

						if (that.craftUnion === "Engineering") {

							var engUnionDropDown = sap.ui.getCore().byId("engUnionDropDown");
							engUnionDropDown.setModel(unionJsonModel, "engUnionDropDownData");

						} else if (that.craftUnion === "Mechanical") {

							var mechUnionDropDown = sap.ui.getCore().byId("mechUnionDropDown");
							mechUnionDropDown.setModel(unionJsonModel, "mechUnionDropDownData");

						}

					}

				},
				error: function (oResponse) {

					that.errorMessageDisp(oResponse);

				}
			});

		},

		onMechUnionSelectionChange: function (oEvent) {
			var that = this;
			var oRosterModel = that.getOwnerComponent().getModel();
			var union = oEvent.getParameter("value");
			var len = oEvent.getSource().getItems().length;
			var enteredText = oEvent.getSource().getValue();
			var bExists = false;
			for (var k = 0; k < len; k++) {
				var itemText = oEvent.getSource().getItems()[k].getProperty("text");
				if (itemText === enteredText || itemText.startsWith(enteredText)) {
					bExists = true;
					break;
				}
			}
			if (bExists) {
				oEvent.getSource().setValueState("None");
				var unionQueryFil = [];
				var craft = new sap.ui.model.Filter("Union", "EQ", union);
				var unionKey = new sap.ui.model.Filter("Key", "EQ", "M");
				unionQueryFil.push(craft);
				unionQueryFil.push(unionKey);

				var unionJsonModel = new sap.ui.model.json.JSONModel();
				oRosterModel.read("/RosterSearchhelpSet", {
					filters: unionQueryFil,
					success: function (oData) {

						if (oData.results.length > 0) {

							unionJsonModel.setData(oData);
							var mechUnionTable = sap.ui.getCore().byId("mechUnionTabTable");
							mechUnionTable.setModel(unionJsonModel, "mechUnionModelData");

							sap.ui.getCore().byId("mechUnionTabTable").setVisible(true);

						} else {

							sap.ui.getCore().byId("mechUnionTabTable").setVisible(false);

						}

					},
					error: function (oResponse) {

						that.errorMessageDisp(oResponse);

					}
				});
			} else {
				oEvent.getSource().setValueState(sap.ui.core.ValueState.Error);
				oEvent.getSource().setValue();
				oEvent.getSource().setValueStateText("Please enter valid Union");
				sap.m.MessageToast.show("Please enter valid Union");
			}

		},

		onEngUnionSelectionChange: function (oEvent) {

			var that = this;
			var oRosterModel = that.getOwnerComponent().getModel();
			var union = oEvent.getParameter("value");
			var len = oEvent.getSource().getItems().length;
			var enteredText = oEvent.getSource().getValue();
			var bExists = false;
			for (var k = 0; k < len; k++) {
				var itemText = oEvent.getSource().getItems()[k].getProperty("text");
				if (itemText === enteredText || itemText.startsWith(enteredText)) {
					bExists = true;
					break;
				}
			}
			if (bExists) {
				oEvent.getSource().setValueState("None");
				var unionQueryFil = [];
				var craft = new sap.ui.model.Filter("Union", "EQ", union);
				var unionKey = new sap.ui.model.Filter("Key", "EQ", "E");
				unionQueryFil.push(craft);
				unionQueryFil.push(unionKey);

				var unionJsonModel = new sap.ui.model.json.JSONModel();
				oRosterModel.read("/RosterSearchhelpSet", {
					filters: unionQueryFil,
					success: function (oData) {

						if (oData.results.length > 0) {

							unionJsonModel.setData(oData);
							var engUnionTable = sap.ui.getCore().byId("engUnionTabTable");
							engUnionTable.setModel(unionJsonModel, "engUnionModelData");

							sap.ui.getCore().byId("engUnionTabTable").setVisible(true);

						} else {

							sap.ui.getCore().byId("engUnionTabTable").setVisible(false);

						}

					},
					error: function (oResponse) {

						that.errorMessageDisp(oResponse);

					}
				});
			} else {
				oEvent.getSource().setValueState(sap.ui.core.ValueState.Error);
				oEvent.getSource().setValue();
				oEvent.getSource().setValueStateText("Please enter valid Union");
				sap.m.MessageToast.show("Please enter valid Union");
			}

		},

		onCraftDropDown: function () {

			var that = this;
			var oRosterModel = that.getOwnerComponent().getModel();

			var craftQueryFil = [];
			var craftVal = new sap.ui.model.Filter("Value", "EQ", "");
			var craftKey = new sap.ui.model.Filter("Key", "EQ", "C");
			craftQueryFil.push(craftVal);
			craftQueryFil.push(craftKey);

			var craftJsonModel = new sap.ui.model.json.JSONModel();
			oRosterModel.read("/QualDropDownsSet", {
				filters: craftQueryFil,
				success: function (oData) {

					if (oData.results.length > 0) {

						craftJsonModel.setData(oData);

						var craftDropDown = sap.ui.getCore().byId("mechCraftDropDown");
						craftDropDown.setModel(craftJsonModel, "mechCraftDropDownData");

					}

				},
				error: function (oResponse) {
					that.errorMessageDisp(oResponse);
				}
			});

		},

		onCraftSelectionChange: function (oEvent) {

			var that = this;
			var oRosterModel = that.getOwnerComponent().getModel();
			var craft = oEvent.getParameter("value");

			var len = oEvent.getSource().getItems().length;
			var enteredText = oEvent.getSource().getValue();
			var bExists = false;
			for (var k = 0; k < len; k++) {
				var itemText = oEvent.getSource().getItems()[k].getProperty("text");
				if (itemText === enteredText || itemText.startsWith(enteredText)) {
					bExists = true;
					break;
				}
			}
			if (bExists) {
				oEvent.getSource().setValueState("None");
				var craftQueryFil = [];
				var craftVal = new sap.ui.model.Filter("CraftType", "EQ", craft);
				var craftKey = new sap.ui.model.Filter("Key", "EQ", "M");
				craftQueryFil.push(craftVal);
				craftQueryFil.push(craftKey);

				var craftJsonModel = new sap.ui.model.json.JSONModel();
				oRosterModel.read("/RosterSearchhelpSet", {
					filters: craftQueryFil,
					success: function (oData) {

						if (oData.results.length > 0) {

							craftJsonModel.setData(oData);
							var mechCraftTable = sap.ui.getCore().byId("mechCraftTabTable");
							mechCraftTable.setModel(craftJsonModel, "mechCraftModelData");

							sap.ui.getCore().byId("mechCraftTabTable").setVisible(true);

						} else {
							sap.ui.getCore().byId("mechCraftTabTable").setVisible(false);
						}

					},
					error: function (oResponse) {
						that.errorMessageDisp(oResponse);
					}
				});
			} else {
				oEvent.getSource().setValueState(sap.ui.core.ValueState.Error);
				oEvent.getSource().setValue();
				oEvent.getSource().setValueStateText("Please enter valid Craft");
				sap.m.MessageToast.show("Please enter valid Craft");
			}

		},

		onTerritoryDropDown: function () {

			var that = this;
			var oRosterModel = that.getOwnerComponent().getModel();

			var territoryQueryFil = [];
			var territoryVal = new sap.ui.model.Filter("Value", "EQ", "");
			var territoryKey = new sap.ui.model.Filter("Key", "EQ", "T");
			territoryQueryFil.push(territoryVal);
			territoryQueryFil.push(territoryKey);

			var territoryJsonModel = new sap.ui.model.json.JSONModel();
			oRosterModel.read("/QualDropDownsSet", {
				filters: territoryQueryFil,
				success: function (oData) {

					if (oData.results.length > 0) {

						territoryJsonModel.setData(oData);

						var territoryDropDown = sap.ui.getCore().byId("mechTerritoryDropDown");
						territoryDropDown.setModel(territoryJsonModel, "mechTerritoryDropDownData");

					}

				},
				error: function (oResponse) {
					that.errorMessageDisp(oResponse);
				}
			});

		},

		onMechTerritorySelectionChange: function (oEvent) {

			var that = this;
			var oRosterModel = that.getOwnerComponent().getModel();
			var territory = oEvent.getParameter("value");

			var len = oEvent.getSource().getItems().length;
			var enteredText = oEvent.getSource().getValue();
			var bExists = false;
			for (var k = 0; k < len; k++) {
				var itemText = oEvent.getSource().getItems()[k].getProperty("text");
				if (itemText === enteredText || itemText.startsWith(enteredText)) {
					bExists = true;
					break;
				}
			}
			if (bExists) {
				oEvent.getSource().setValueState("None");
				var territoryQueryFil = [];
				var territoryVal = new sap.ui.model.Filter("Territory", "EQ", territory);
				var territoryKey = new sap.ui.model.Filter("Key", "EQ", "M");
				territoryQueryFil.push(territoryVal);
				territoryQueryFil.push(territoryKey);

				var territoryJsonModel = new sap.ui.model.json.JSONModel();
				oRosterModel.read("/RosterSearchhelpSet", {
					filters: territoryQueryFil,
					success: function (oData) {

						if (oData.results.length > 0) {

							territoryJsonModel.setData(oData);
							var mechTerritoryTable = sap.ui.getCore().byId("mechTerritoryTabTable");
							mechTerritoryTable.setModel(territoryJsonModel, "mechTerritoryModelData");

							sap.ui.getCore().byId("mechTerritoryTabTable").setVisible(true);

						} else {

							sap.ui.getCore().byId("mechTerritoryTabTable").setVisible(false);

						}

					},
					error: function (oResponse) {
						that.errorMessageDisp(oResponse);
					}
				});
			} else {
				oEvent.getSource().setValueState(sap.ui.core.ValueState.Error);
				oEvent.getSource().setValue();
				oEvent.getSource().setValueStateText("Please enter valid Territory");
				sap.m.MessageToast.show("Please enter valid Territory");
			}

		},

		onStateDropDown: function (oEvt) {

			var that = this;
			var oRosterModel = that.getOwnerComponent().getModel();
			var stateQueryFil = [];
			var stateVal = new sap.ui.model.Filter("Value", "EQ", "");
			var stateKey = new sap.ui.model.Filter("Key", "EQ", "S");
			stateQueryFil.push(stateVal);
			stateQueryFil.push(stateKey);

			var stateJsonModel = new sap.ui.model.json.JSONModel();
			oRosterModel.read("/QualDropDownsSet", {
				filters: stateQueryFil,
				success: function (oData) {

					if (oData.results.length > 0) {

						stateJsonModel.setData(oData);

						var stateDropDown = sap.ui.getCore().byId("mechStateDropDown");
						stateDropDown.setModel(stateJsonModel, "mechStateDropDownData");

					}

				},
				error: function (oResponse) {
					that.errorMessageDisp(oResponse);
				}
			});
			if (oEvt.getSource().getSelectedKey() === "") {
				oEvt.getSource().setValue("");
			}

		},

		onMechStateSelectionChange: function (oEvent) {

			var that = this;
			var oRosterModel = that.getOwnerComponent().getModel();
			var state = oEvent.getParameter("value");

			var len = oEvent.getSource().getItems().length;
			var enteredText = oEvent.getSource().getValue();
			var bExists = false;
			for (var k = 0; k < len; k++) {
				var itemText = oEvent.getSource().getItems()[k].getProperty("text");
				if (itemText === enteredText || itemText.startsWith(enteredText)) {
					bExists = true;
					break;
				}
			}
			if (bExists) {
				oEvent.getSource().setValueState("None");
				var stateQueryFil = [];
				var stateVal = new sap.ui.model.Filter("State", "EQ", state);
				var stateKey = new sap.ui.model.Filter("Key", "EQ", "M");
				stateQueryFil.push(stateVal);
				stateQueryFil.push(stateKey);

				var stateJsonModel = new sap.ui.model.json.JSONModel();
				oRosterModel.read("/RosterSearchhelpSet", {
					filters: stateQueryFil,
					success: function (oData) {

						if (oData.results.length > 0) {

							stateJsonModel.setData(oData);
							var mechStateTable = sap.ui.getCore().byId("mechStateTabTable");
							mechStateTable.setModel(stateJsonModel, "mechStateModelData");

							sap.ui.getCore().byId("mechStateTabTable").setVisible(true);

						} else {

							sap.ui.getCore().byId("mechStateTabTable").setVisible(false);

						}

					},
					error: function (oResponse) {
						that.errorMessageDisp(oResponse);
					}
				});
			} else {
				oEvent.getSource().setValueState(sap.ui.core.ValueState.Error);
				oEvent.getSource().setValue();
				oEvent.getSource().setValueStateText("Please enter valid State");
				sap.m.MessageToast.show("Please enter valid State");
			}

		},

		onRrCodeDropDown: function () {

			var that = this;
			var oRosterModel = that.getOwnerComponent().getModel();

			var rrCodeQueryFil = [];
			var rrCodeVal = new sap.ui.model.Filter("Value", "EQ", "");
			var rrCodeKey = new sap.ui.model.Filter("Key", "EQ", "RR");
			rrCodeQueryFil.push(rrCodeVal);
			rrCodeQueryFil.push(rrCodeKey);

			var rrCodeJsonModel = new sap.ui.model.json.JSONModel();
			oRosterModel.read("/QualDropDownsSet", {
				filters: rrCodeQueryFil,
				success: function (oData) {

					if (oData.results.length > 0) {

						rrCodeJsonModel.setData(oData);

						var rrCodeDropDown = sap.ui.getCore().byId("engRrCodeDropDown");
						rrCodeDropDown.setModel(rrCodeJsonModel, "mechRrCodeDropDownData");

					}

				},
				error: function (oResponse) {
					that.errorMessageDisp(oResponse);
				}
			});

		},

		onRrCodeSelectionChange: function (oEvent) {

			var that = this;
			var oRosterModel = that.getOwnerComponent().getModel();
			var rrCode = oEvent.getParameter("value");

			var len = oEvent.getSource().getItems().length;
			var enteredText = oEvent.getSource().getValue();
			var bExists = false;
			for (var k = 0; k < len; k++) {
				var itemText = oEvent.getSource().getItems()[k].getProperty("text");
				if (itemText === enteredText || itemText.startsWith(enteredText)) {
					bExists = true;
					break;
				}
			}
			if (bExists) {
				oEvent.getSource().setValueState("None");
				var rrCodeQueryFil = [];
				var rrCodeVal = new sap.ui.model.Filter("RRCode", "EQ", rrCode);
				var rrCodeKey = new sap.ui.model.Filter("Key", "EQ", "E");
				rrCodeQueryFil.push(rrCodeVal);
				rrCodeQueryFil.push(rrCodeKey);

				var rrCodeJsonModel = new sap.ui.model.json.JSONModel();
				oRosterModel.read("/RosterSearchhelpSet", {
					filters: rrCodeQueryFil,
					success: function (oData) {

						if (oData.results.length > 0) {

							rrCodeJsonModel.setData(oData);
							var engRrCodeTable = sap.ui.getCore().byId("engRrCodeTabTable");
							engRrCodeTable.setModel(rrCodeJsonModel, "engRrCodeModelData");

							sap.ui.getCore().byId("engRrCodeTabTable").setVisible(true);

						} else {

							sap.ui.getCore().byId("engRrCodeTabTable").setVisible(false);

						}

					},
					error: function (oResponse) {
						that.errorMessageDisp(oResponse);
					}
				});
			} else {
				oEvent.getSource().setValueState(sap.ui.core.ValueState.Error);
				oEvent.getSource().setValue();
				oEvent.getSource().setValueStateText("Please enter valid RR Code");
				sap.m.MessageToast.show("Please enter valid RR Code");
			}

		},

		onRegionDropDown: function () {

			var that = this;
			var oRosterModel = that.getOwnerComponent().getModel();

			var regionQueryFil = [];
			var regionVal = new sap.ui.model.Filter("Value", "EQ", "");
			var regionKey = new sap.ui.model.Filter("Key", "EQ", "RE");
			regionQueryFil.push(regionVal);
			regionQueryFil.push(regionKey);

			var regionJsonModel = new sap.ui.model.json.JSONModel();
			oRosterModel.read("/QualDropDownsSet", {
				filters: regionQueryFil,
				success: function (oData) {

					if (oData.results.length > 0) {

						regionJsonModel.setData(oData);

						var regionDropDown = sap.ui.getCore().byId("engRegionDropDown");
						regionDropDown.setModel(regionJsonModel, "engRegionDropDownModelData");

					}

				},
				error: function (oResponse) {
					that.errorMessageDisp(oResponse);
				}
			});

		},

		onRegionSelectionChange: function (oEvent) {

			var that = this;
			var oRosterModel = that.getOwnerComponent().getModel();
			var region = oEvent.getParameter("value");

			var len = oEvent.getSource().getItems().length;
			var enteredText = oEvent.getSource().getValue();
			var bExists = false;
			for (var k = 0; k < len; k++) {
				var itemText = oEvent.getSource().getItems()[k].getProperty("text");
				if (itemText === enteredText || itemText.startsWith(enteredText)) {
					bExists = true;
					break;
				}
			}
			if (bExists) {
				oEvent.getSource().setValueState("None");
				var regionQueryFil = [];
				var regionVal = new sap.ui.model.Filter("Region", "EQ", region);
				var regionKey = new sap.ui.model.Filter("Key", "EQ", "E");
				regionQueryFil.push(regionVal);
				regionQueryFil.push(regionKey);

				var regionJsonModel = new sap.ui.model.json.JSONModel();
				oRosterModel.read("/RosterSearchhelpSet", {
					filters: regionQueryFil,
					success: function (oData) {

						if (oData.results.length > 0) {

							regionJsonModel.setData(oData);
							var engRegionTable = sap.ui.getCore().byId("engRegionTabTable");
							engRegionTable.setModel(regionJsonModel, "engRegionModelData");

							sap.ui.getCore().byId("engRegionTabTable").setVisible(true);

						} else {

							sap.ui.getCore().byId("engRegionTabTable").setVisible(false);

						}

					},
					error: function (oResponse) {
						that.errorMessageDisp(oResponse);
					}
				});
			} else {
				oEvent.getSource().setValueState(sap.ui.core.ValueState.Error);
				oEvent.getSource().setValue();
				oEvent.getSource().setValueStateText("Please enter valid Region");
				sap.m.MessageToast.show("Please enter valid Region");
			}

		},

		onDivDropDown: function () {

			var that = this;
			var oRosterModel = that.getOwnerComponent().getModel();

			var divQueryFil = [];
			var divVal = new sap.ui.model.Filter("Value", "EQ", "");
			var divKey = new sap.ui.model.Filter("Key", "EQ", "D");
			divQueryFil.push(divVal);
			divQueryFil.push(divKey);

			var divJsonModel = new sap.ui.model.json.JSONModel();
			oRosterModel.read("/QualDropDownsSet", {
				filters: divQueryFil,
				success: function (oData) {

					if (oData.results.length > 0) {

						divJsonModel.setData(oData);

						var divDropDown = sap.ui.getCore().byId("engDivDropDown");
						divDropDown.setModel(divJsonModel, "engDivDropDownData");

					}

				},
				error: function (oResponse) {
					that.errorMessageDisp(oResponse);
				}
			});

		},

		onDivSelectionChange: function (oEvent) {

			var that = this;
			var oRosterModel = that.getOwnerComponent().getModel();
			var division = oEvent.getParameter("value");

			var len = oEvent.getSource().getItems().length;
			var enteredText = oEvent.getSource().getValue();
			var bExists = false;
			for (var k = 0; k < len; k++) {
				var itemText = oEvent.getSource().getItems()[k].getProperty("text");
				if (itemText === enteredText || itemText.startsWith(enteredText)) {
					bExists = true;
					break;
				}
			}
			if (bExists) {
				oEvent.getSource().setValueState("None");
				var divQueryFil = [];
				var divVal = new sap.ui.model.Filter("Division", "EQ", division);
				var divKey = new sap.ui.model.Filter("Key", "EQ", "E");
				divQueryFil.push(divVal);
				divQueryFil.push(divKey);

				var divJsonModel = new sap.ui.model.json.JSONModel();
				oRosterModel.read("/RosterSearchhelpSet", {
					filters: divQueryFil,
					success: function (oData) {

						if (oData.results.length > 0) {

							divJsonModel.setData(oData);
							var engDivTable = sap.ui.getCore().byId("engDivTabTable");
							engDivTable.setModel(divJsonModel, "engDivModelData");

							sap.ui.getCore().byId("engDivTabTable").setVisible(true);

						} else {

							sap.ui.getCore().byId("engDivTabTable").setVisible(false);

						}

					},
					error: function (oResponse) {
						that.errorMessageDisp(oResponse);
					}
				});
			} else {
				oEvent.getSource().setValueState(sap.ui.core.ValueState.Error);
				oEvent.getSource().setValue();
				oEvent.getSource().setValueStateText("Please enter valid Division");
				sap.m.MessageToast.show("Please enter valid Division");
			}

		},

		onEngRosterDataSubmit: function (oEvent) {
			var that = this;

			var oPath = oEvent.getSource().getBindingContextPath();
			var oTable = oEvent.getSource().getParent();
			var tableId = oEvent.getSource().getParent().getId();

			var oModel;
			if (tableId === "engRosterNoDescTabTable") {
				oModel = "engRosterNoDescModelData";
			} else if (tableId === "engUnionTabTable") {
				oModel = "engUnionModelData";
			} else if (tableId === "engRrCodeTabTable") {
				oModel = "engRrCodeModelData";
			} else if (tableId === "engRegionTabTable") {
				oModel = "engRegionModelData";
			} else if (tableId === "engDivTabTable") {
				oModel = "engDivModelData";
			} else if (tableId === "engDistTabTable") {
				oModel = "engDistModelData";
			} else if (tableId === "engEmpIdNameTabTable") {
				oModel = "engEmpIdNameModelData";
			}

			var oContext = oTable.getModel(oModel).getProperty(oPath);

			that.rosterNo = oContext.RosterNo;
			that.rosterDesc = oContext.RostDesc;
			that.union = oContext.Union;
			that.region = oContext.Region;
			that.District = oContext.District;
			that.Division = oContext.Division;
			that.RRCode = oContext.RRCode;
			that.territory = oContext.Territory;
			that.city = oContext.City;
			that.state = oContext.State;
			that.EngPopup = oContext.EngPopup;
			that.addilRoster = "";
			that.byId("empSenDistrictInp").setValue(that.District);
			that.byId("empSenDivisionInp").setValue(that.Division);
			that.byId("empSenRrCodeInp").setValue(that.RRCode);

			that.byId("rosterNoInp").setValue(oContext.RosterNo);
			that.oOldRosterNo = oContext.RosterNo;
			that.onEngRosterDialogCancel();
			that.changeFlag = true;
			that.selTab = that.byId("IconTabbarId").getSelectedKey();

		},

		onMechRosterDataSubmit: function (oEvent) {
			var that = this;

			var oPath = oEvent.getSource().getBindingContextPath();
			var oTable = oEvent.getSource().getParent();
			var tableId = oEvent.getSource().getParent().getId();

			var oModel;
			if (tableId === "mechRosterNoDescTabTable") {
				oModel = "mechRosterNoDescModelData";
			} else if (tableId === "mechUnionTabTable") {
				oModel = "mechUnionModelData";
			} else if (tableId === "mechCraftTabTable") {
				oModel = "mechCraftModelData";
			} else if (tableId === "mechTerritoryTabTable") {
				oModel = "mechTerritoryModelData";
			} else if (tableId === "mechCityTabTable") {
				oModel = "mechRosterCityModelData";
			} else if (tableId === "mechStateTabTable") {
				oModel = "mechStateModelData";
			} else if (tableId === "mechEmpIdNameTabTable") {
				oModel = "mechRosterEmpIdNameModelData";
			}

			var oContext = oTable.getModel(oModel).getProperty(oPath);
			that.byId("rosterNoInp").setValue(oContext.RosterNo);

			that.rosterNo = oContext.RosterNo;
			that.rosterDesc = oContext.RostDesc;
			that.union = oContext.Union;
			that.region = oContext.Region;
			that.District = oContext.District;
			that.Division = oContext.Division;
			that.RRCode = oContext.RRCode;
			that.territory = oContext.Territory;
			that.city = oContext.City;
			that.state = oContext.State;
			that.EngPopup = oContext.EngPopup;
			that.addilRoster = "";
			that.oOldRosterNo = oContext.RosterNo;
			that.onMechRosterDialogueCancel();
			that.changeFlag = true;
			that.byId("empSenDistrictInp").setValue(that.District);
			that.byId("empSenDivisionInp").setValue(that.Division);
			that.byId("empSenRrCodeInp").setValue(that.RRCode);
			that.selTab = that.byId("IconTabbarId").getSelectedKey();

		},

		onTcuRosterDataSubmit: function (oEvent) {
			var that = this;

			var oPath = oEvent.getSource().getBindingContextPath();
			var oTable = oEvent.getSource().getParent();
			var tableId = oEvent.getSource().getParent().getId();

			var oModel;
			if (tableId === "tcuRosterNoDescTabTable") {
				oModel = "tcuRosterNoDescModelData";
			} else if (tableId === "tcuDeptTabTable") {
				oModel = "tcuDeptModelData";
			} else if (tableId === "tcuEmpIdNameTabTable") {
				oModel = "tcuEmpIdNameModelData";
			}

			var oContext = oTable.getModel(oModel).getProperty(oPath);

			that.rosterNo = oContext.RosterNo;
			that.rosterDesc = oContext.RostDesc;
			that.union = oContext.Union;
			that.region = oContext.Region;
			that.District = oContext.District;
			that.Division = oContext.Division;
			that.RRCode = oContext.RRCode;
			that.territory = oContext.Territory;
			that.city = oContext.City;
			that.state = oContext.State;
			that.EngPopup = oContext.EngPopup;
			that.addilRoster = "";
			that.byId("rosterNoInp").setValue(oContext.RosterNo);
			that.oOldRosterNo = oContext.RosterNo;
			that.onTcuRosterDialogCancel();
			that.changeFlag = true;
			that.byId("empSenDistrictInp").setValue(that.District);
			that.byId("empSenDivisionInp").setValue(that.Division);
			that.byId("empSenRrCodeInp").setValue(that.RRCode);
			that.selTab = that.byId("IconTabbarId").getSelectedKey();

		},

		onAtdaRosterDataSubmit: function (oEvent) {
			var that = this;

			var oPath = oEvent.getSource().getBindingContextPath();
			var oTable = oEvent.getSource().getParent();
			var tableId = oEvent.getSource().getParent().getId();

			var oModel;
			if (tableId === "atdaRosterNoDescTabTable") {
				oModel = "atdaRosterNoDescModelData";
			} else if (tableId === "atdaDeptTabTable") {
				oModel = "atdaDeptModelData";
			} else if (tableId === "atdaEmpIdNameTabTable") {
				oModel = "atdaEmpIdNameModelData";
			}

			var oContext = oTable.getModel(oModel).getProperty(oPath);

			that.rosterNo = oContext.RosterNo;
			that.rosterDesc = oContext.RostDesc;
			that.union = oContext.Union;
			that.region = oContext.Region;
			that.District = oContext.District;
			that.Division = oContext.Division;
			that.RRCode = oContext.RRCode;
			that.territory = oContext.Territory;
			that.city = oContext.City;
			that.state = oContext.State;
			that.EngPopup = oContext.EngPopup;
			that.addilRoster = "";
			that.byId("rosterNoInp").setValue(oContext.RosterNo);
			that.oOldRosterNo = oContext.RosterNo;
			that.onAtdaRosterDialogCancel();
			that.changeFlag = true;
			that.byId("empSenDistrictInp").setValue(that.District);
			that.byId("empSenDivisionInp").setValue(that.Division);
			that.byId("empSenRrCodeInp").setValue(that.RRCode);
			that.selTab = that.byId("IconTabbarId").getSelectedKey();

		},

		onIlaRosterDataSubmit: function (oEvent) {
			var that = this;

			var oPath = oEvent.getSource().getBindingContextPath();
			var oTable = oEvent.getSource().getParent();
			var tableId = oEvent.getSource().getParent().getId();

			var oModel;
			if (tableId === "ilaRosterNoDescTable") {
				oModel = "ilaRosterNoDescModelData";
			} else if (tableId === "ilaEmpIdNameTabTable") {
				oModel = "ilaEmpIdNameModelData";
			}

			var oContext = oTable.getModel(oModel).getProperty(oPath);

			that.rosterNo = oContext.RosterNo;
			that.rosterDesc = oContext.RostDesc;
			that.union = oContext.Union;
			that.region = oContext.Region;
			that.District = oContext.District;
			that.Division = oContext.Division;
			that.RRCode = oContext.RRCode;
			that.territory = oContext.Territory;
			that.city = oContext.City;
			that.state = oContext.State;
			that.EngPopup = oContext.EngPopup;
			that.addilRoster = "";
			that.byId("rosterNoInp").setValue(oContext.RosterNo);
			that.oOldRosterNo = oContext.RosterNo;
			that.onIlaRosterDialogueCancel();
			that.changeFlag = true;
			that.byId("empSenDistrictInp").setValue(that.District);
			that.byId("empSenDivisionInp").setValue(that.Division);
			that.byId("empSenRrCodeInp").setValue(that.RRCode);
			that.selTab = that.byId("IconTabbarId").getSelectedKey();

		},
		onEffDateChangeCur: function (oEvt) {
			var oDP = oEvt.getSource();
			var bValid = oEvt.getParameter("valid");
			if (bValid) {
				var oSenDate = oEvt.getSource().getValue();
				var stDate;
				if (oSenDate.includes("/") === true) {
					stDate = oSenDate.split("/")[2] + oSenDate.split("/")[0] + oSenDate.split("/")[1];
				} else {
					stDate = oSenDate;
				}
				var sdate = new Date(new Date(stDate.slice(0, 4) + "-" + stDate.slice(4, 6) + "-" + stDate.slice(6, 8)).getUTCFullYear(), new Date(
					stDate.slice(0, 4) + "-" + stDate.slice(4, 6) + "-" + stDate.slice(6, 8)).getUTCMonth(), new Date(stDate.slice(0, 4) + "-" +
					stDate.slice(4, 6) + "-" + stDate.slice(6, 8)).getUTCDate()).setHours(0, 0, 0, 0);
				var cDate = new Date(new Date().getFullYear(), new Date().getMonth(), new Date().getDate()).setHours(0, 0, 0, 0);
				if (stDate === "") {
					sap.m.MessageToast.show("Effective date can't be empty");
					return;
				}
				if (cDate > sdate) {
					oEvt.getSource().setValue("");
					oDP.setValueState(sap.ui.core.ValueState.Error);
					sap.m.MessageToast.show("Effective date can't be less then today");
					return;
				} else {

				}
				oDP.setValueState(sap.ui.core.ValueState.None);
			} else {
				oEvt.getSource().setValue("");
				oDP.setValueState(sap.ui.core.ValueState.Error);
			}
		},
		onEmpDateChange: function (oEvt) {
			var oDP = oEvt.getSource();
			var bValid = oEvt.getParameter("valid");
			if (bValid) {
				oDP.setValueState(sap.ui.core.ValueState.None);
			} else {
				oEvt.getSource().setValue("");
				oDP.setValueState(sap.ui.core.ValueState.Error);
			}
		},
		//-----------------------------------------------------------------------	
		// Clearing tables in Engineering fragment.
		//-----------------------------------------------------------------------

		engTableClear: function () {

			//-----------------------------------------------------------------------	
			// Engineering Roster Number and Description table.
			//-----------------------------------------------------------------------

			sap.ui.getCore().byId("dialoguEngRosterNoDescSearch").setValue();

			var rosterNoDescEmptyArr = [];
			var rosterNoDescJSONModel = new JSONModel({
				"results": rosterNoDescEmptyArr
			});
			sap.ui.getCore().byId("engRosterNoDescTabTable").setModel(rosterNoDescJSONModel, "engRosterNoDescModelData");
			sap.ui.getCore().byId("engRosterNoDescTabTable").setVisible(false);

			//-----------------------------------------------------------------------	
			// Engineering Union table.
			//-----------------------------------------------------------------------

			sap.ui.getCore().byId("engUnionDropDown").setValue();

			var engUnionEmptyArr = [];
			var engUnionJSONModel = new JSONModel({
				"results": engUnionEmptyArr
			});
			sap.ui.getCore().byId("engUnionTabTable").setModel(engUnionJSONModel, "engUnionModelData");
			sap.ui.getCore().byId("engUnionTabTable").setVisible(false);

			//-----------------------------------------------------------------------	
			// Engineering RR Code table.
			//-----------------------------------------------------------------------

			sap.ui.getCore().byId("engRrCodeDropDown").setValue();

			var rrCodeEmptyArr = [];
			var rrCodeJSONModel = new JSONModel({
				"results": rrCodeEmptyArr
			});
			sap.ui.getCore().byId("engRrCodeTabTable").setModel(rrCodeJSONModel, "engRrCodeModelData");
			sap.ui.getCore().byId("engRrCodeTabTable").setVisible(false);

			//-----------------------------------------------------------------------	
			// Engineering Region table.
			//-----------------------------------------------------------------------

			sap.ui.getCore().byId("engRegionDropDown").setValue();

			var regionEmptyArr = [];
			var regionJSONModel = new JSONModel({
				"results": regionEmptyArr
			});
			sap.ui.getCore().byId("engRegionTabTable").setModel(regionJSONModel, "engRegionModelData");
			sap.ui.getCore().byId("engRegionTabTable").setVisible(false);

			//-----------------------------------------------------------------------	
			// Engineering Division table.
			//-----------------------------------------------------------------------

			sap.ui.getCore().byId("engDivDropDown").setValue();

			var divEmptyArr = [];
			var divJSONModel = new JSONModel({
				"results": divEmptyArr
			});
			sap.ui.getCore().byId("engDivTabTable").setModel(divJSONModel, "engDivModelData");
			sap.ui.getCore().byId("engDivTabTable").setVisible(false);

			//-----------------------------------------------------------------------	
			// Engineering District table.
			//-----------------------------------------------------------------------

			sap.ui.getCore().byId("dialoguDistSearch").setValue();

			var distEmptyArr = [];
			var distJSONModel = new JSONModel({
				"results": distEmptyArr
			});
			sap.ui.getCore().byId("engDistTabTable").setModel(distJSONModel, "engDistModelData");
			sap.ui.getCore().byId("engDistTabTable").setVisible(false);

			//-----------------------------------------------------------------------	
			// Engineering Employee ID Or Name table.
			//-----------------------------------------------------------------------

			sap.ui.getCore().byId("dialoguEngEmpIdNameSearch").setValue();

			var empIdNameEmptyArr = [];
			var empIdNameJSONModel = new JSONModel({
				"results": empIdNameEmptyArr
			});
			sap.ui.getCore().byId("engEmpIdNameTabTable").setModel(empIdNameJSONModel, "engEmpIdNameModelData");
			sap.ui.getCore().byId("engEmpIdNameTabTable").setVisible(false);

		},

		//-----------------------------------------------------------------------	
		// Clearing tables in Mechanical fragment.
		//-----------------------------------------------------------------------

		mechTableClear: function () {

			//-----------------------------------------------------------------------	
			// Mechanical Roster Number and Description table.
			//-----------------------------------------------------------------------

			sap.ui.getCore().byId("dialoguMechRosterNoDescSearch").setValue();

			var rostNoDescEmptyArr = [];
			var rosterNoDescJSONModel = new JSONModel({
				"results": rostNoDescEmptyArr
			});
			sap.ui.getCore().byId("mechRosterNoDescTabTable").setModel(rosterNoDescJSONModel, "mechRosterNoDescModelData");
			sap.ui.getCore().byId("mechRosterNoDescTabTable").setVisible(false);

			//-----------------------------------------------------------------------	
			// Mechanical Union table.
			//-----------------------------------------------------------------------

			sap.ui.getCore().byId("mechUnionDropDown").setValue();

			var mechUnionEmptyArr = [];
			var mechUnionJSONModel = new JSONModel({
				"results": mechUnionEmptyArr
			});
			sap.ui.getCore().byId("mechUnionTabTable").setModel(mechUnionJSONModel, "mechUnionModelData");
			sap.ui.getCore().byId("mechUnionTabTable").setVisible(false);

			//-----------------------------------------------------------------------	
			// Mechanical Craft table.
			//-----------------------------------------------------------------------

			sap.ui.getCore().byId("mechCraftDropDown").setValue();

			var craftEmptyArr = [];
			var craftJSONModel = new JSONModel({
				"results": craftEmptyArr
			});
			sap.ui.getCore().byId("mechCraftTabTable").setModel(craftJSONModel, "mechCraftModelData");
			sap.ui.getCore().byId("mechCraftTabTable").setVisible(false);

			//-----------------------------------------------------------------------	
			// Mechanical Territory table.
			//-----------------------------------------------------------------------

			sap.ui.getCore().byId("mechTerritoryDropDown").setValue();

			var territoryEmptyArr = [];
			var territoryJSONModel = new JSONModel({
				"results": territoryEmptyArr
			});
			sap.ui.getCore().byId("mechTerritoryTabTable").setModel(territoryJSONModel, "mechTerritoryModelData");
			sap.ui.getCore().byId("mechTerritoryTabTable").setVisible(false);

			//-----------------------------------------------------------------------	
			// Mechanical City table.
			//-----------------------------------------------------------------------

			sap.ui.getCore().byId("dialoguMechCitySearch").setValue();

			var cityEmptyArr = [];
			var cityJSONModel = new JSONModel({
				"results": cityEmptyArr
			});
			sap.ui.getCore().byId("mechCityTabTable").setModel(cityJSONModel, "mechRosterCityModelData");
			sap.ui.getCore().byId("mechCityTabTable").setVisible(false);

			//-----------------------------------------------------------------------	
			// Mechanical State table.
			//-----------------------------------------------------------------------

			sap.ui.getCore().byId("mechStateDropDown").setValue();

			var stateEmptyArr = [];
			var stateJSONModel = new JSONModel({
				"results": stateEmptyArr
			});
			sap.ui.getCore().byId("mechStateTabTable").setModel(stateJSONModel, "mechStateModelData");
			sap.ui.getCore().byId("mechStateTabTable").setVisible(false);

			//-----------------------------------------------------------------------	
			// Mechanical Employee ID Or Name table.
			//-----------------------------------------------------------------------

			sap.ui.getCore().byId("dialoguMechEmpIdNameSearch").setValue();

			var mechEmpIdNameEmptyArr = [];
			var mechEmpIdNameJSONModel = new JSONModel({
				"results": mechEmpIdNameEmptyArr
			});
			sap.ui.getCore().byId("mechEmpIdNameTabTable").setModel(mechEmpIdNameJSONModel, "mechRosterEmpIdNameModelData");
			sap.ui.getCore().byId("mechEmpIdNameTabTable").setVisible(false);

		},

		//-----------------------------------------------------------------------	
		// Clearing tables in TCU and ATDA fragment.
		//-----------------------------------------------------------------------

		tcuTableClear: function () {

			//-----------------------------------------------------------------------	
			// TCU Or ATDA Roster Number Or Description table.
			//-----------------------------------------------------------------------

			sap.ui.getCore().byId("dialoguTcuRosterNoDescSearch").setValue();

			var rostNoDescEmptyArr = [];
			var rosterNoDescJSONModel = new JSONModel({
				"results": rostNoDescEmptyArr
			});
			sap.ui.getCore().byId("tcuRosterNoDescTabTable").setModel(rosterNoDescJSONModel, "tcuRosterNoDescModelData");
			sap.ui.getCore().byId("tcuRosterNoDescTabTable").setVisible(false);

			//-----------------------------------------------------------------------	
			// TCU Or ATDA Department table.
			//-----------------------------------------------------------------------

			sap.ui.getCore().byId("dialoguTcuDeptSearch").setValue();

			var deptEmptyArr = [];
			var deptJSONModel = new JSONModel({
				"results": deptEmptyArr
			});
			sap.ui.getCore().byId("tcuDeptTabTable").setModel(deptJSONModel, "tcuDeptModelData");
			sap.ui.getCore().byId("tcuDeptTabTable").setVisible(false);

			//-----------------------------------------------------------------------	
			// TCU Employee ID Or Name table.
			//-----------------------------------------------------------------------

			sap.ui.getCore().byId("dialoguTcuEmpIdNameSearch").setValue();

			var tcuEmpIdNameEmptyArr = [];
			var tcuEmpIdNameJSONModel = new JSONModel({
				"results": tcuEmpIdNameEmptyArr
			});
			sap.ui.getCore().byId("tcuEmpIdNameTabTable").setModel(tcuEmpIdNameJSONModel, "tcuEmpIdNameModelData");
			sap.ui.getCore().byId("tcuEmpIdNameTabTable").setVisible(false);

		},

		//-----------------------------------------------------------------------	
		// Clearing tables in ATDA fragment.
		//-----------------------------------------------------------------------

		atdaTableClear: function () {

			//-----------------------------------------------------------------------	
			// ATDA Roster Number Or Description table.
			//-----------------------------------------------------------------------

			sap.ui.getCore().byId("dialoguAtdaRosterNoDescSearch").setValue();

			var rostNoDescEmptyArr = [];
			var rosterNoDescJSONModel = new JSONModel({
				"results": rostNoDescEmptyArr
			});
			sap.ui.getCore().byId("atdaRosterNoDescTabTable").setModel(rosterNoDescJSONModel, "atdaRosterNoDescModelData");
			sap.ui.getCore().byId("atdaRosterNoDescTabTable").setVisible(false);

			//-----------------------------------------------------------------------	
			// ATDA Department table.
			//-----------------------------------------------------------------------

			sap.ui.getCore().byId("dialoguAtdaDeptSearch").setValue();

			var deptEmptyArr = [];
			var deptJSONModel = new JSONModel({
				"results": deptEmptyArr
			});
			sap.ui.getCore().byId("atdaDeptTabTable").setModel(deptJSONModel, "atdaDeptModelData");
			sap.ui.getCore().byId("atdaDeptTabTable").setVisible(false);

			//-----------------------------------------------------------------------	
			// ATDA Employee ID Or Name table.
			//-----------------------------------------------------------------------

			sap.ui.getCore().byId("dialoguAtdaEmpIdNameSearch").setValue();

			var atdaEmpIdNameEmptyArr = [];
			var atdaEmpIdNameJSONModel = new JSONModel({
				"results": atdaEmpIdNameEmptyArr
			});
			sap.ui.getCore().byId("atdaEmpIdNameTabTable").setModel(atdaEmpIdNameJSONModel, "atdaEmpIdNameModelData");
			sap.ui.getCore().byId("atdaEmpIdNameTabTable").setVisible(false);

		},

		//-----------------------------------------------------------------------	
		// Clearing tables in ILA fragment.
		//-----------------------------------------------------------------------

		ilaTableClear: function () {

			//-----------------------------------------------------------------------	
			// ILA Roster Number and Description table.
			//-----------------------------------------------------------------------

			sap.ui.getCore().byId("dialogueIlaRosterNoDescSearch").setValue();

			var rostNoDescEmptyArr = [];
			var rostNoDescJSONModel = new JSONModel({
				"results": rostNoDescEmptyArr
			});
			sap.ui.getCore().byId("ilaRosterNoDescTable").setModel(rostNoDescJSONModel, "ilaRosterNoDescModelData");
			sap.ui.getCore().byId("ilaRosterNoDescTable").setVisible(false);

			//-----------------------------------------------------------------------	
			// ILA Employee ID Or Name table.
			//-----------------------------------------------------------------------

			sap.ui.getCore().byId("dialoguIlaEmpIdNameSearch").setValue();

			var ilaEmpIdNameEmptyArr = [];
			var ilaEmpIdNameJSONModel = new JSONModel({
				"results": ilaEmpIdNameEmptyArr
			});
			sap.ui.getCore().byId("ilaEmpIdNameTabTable").setModel(ilaEmpIdNameJSONModel, "ilaEmpIdNameModelData");
			sap.ui.getCore().byId("ilaEmpIdNameTabTable").setVisible(false);

		},

		onSenCraftChange: function (oEvent) {

			var len = oEvent.getSource().getItems().length;
			var enteredText = oEvent.getSource().getValue();
			var bExists = false;

			for (var k = 0; k < len; k++) {
				var itemText = oEvent.getSource().getItems()[k].getProperty("text");
				if (itemText === enteredText || itemText.startsWith(enteredText)) {
					bExists = true;
					break;
				}
			}
			if (bExists) {
				if (enteredText.length > 0) {
					oEvent.getSource().setValueState("None");
				}
			} else {
				oEvent.getSource().setValueState(sap.ui.core.ValueState.Error);
				oEvent.getSource().setValue();
				oEvent.getSource().setValueStateText("Please enter valid " + oEvent.getSource().getParent().getAggregation("label").getText());
				sap.m.MessageToast.show("Please enter valid Craft");
			}

		},

		onSenDivChange: function (oEvent) {

			var len = oEvent.getSource().getItems().length;
			var enteredText = oEvent.getSource().getValue();
			var bExists = false;

			for (var k = 0; k < len; k++) {
				var itemText = oEvent.getSource().getItems()[k].getProperty("text");
				if (itemText === enteredText || itemText.startsWith(enteredText)) {
					bExists = true;
					break;
				}
			}
			if (bExists) {
				if (enteredText.length > 0) {
					oEvent.getSource().setValueState("None");
				}
			} else {
				oEvent.getSource().setValueState(sap.ui.core.ValueState.Error);
				oEvent.getSource().setValue();
				oEvent.getSource().setValueStateText("Please enter valid " + oEvent.getSource().getParent().getAggregation("label").getText());
				sap.m.MessageToast.show("Please enter valid Division");
			}

		},

		onSenRrCodeChange: function (oEvent) {

			var len = oEvent.getSource().getItems().length;
			var enteredText = oEvent.getSource().getValue();
			var bExists = false;

			for (var k = 0; k < len; k++) {
				var itemText = oEvent.getSource().getItems()[k].getProperty("text");
				if (itemText === enteredText || itemText.startsWith(enteredText)) {
					bExists = true;
					break;
				}
			}
			if (bExists) {
				if (enteredText.length > 0) {
					oEvent.getSource().setValueState("None");
				}
			} else {
				oEvent.getSource().setValueState(sap.ui.core.ValueState.Error);
				oEvent.getSource().setValue();
				oEvent.getSource().setValueStateText("Please enter valid " + oEvent.getSource().getParent().getAggregation("label").getText());
				sap.m.MessageToast.show("Please enter valid RR Code");
			}

		},

		onSenDistChange: function (oEvent) {

			var len = oEvent.getSource().getItems().length;
			var enteredText = oEvent.getSource().getValue();
			var bExists = false;

			for (var k = 0; k < len; k++) {
				var itemText = oEvent.getSource().getItems()[k].getProperty("text");
				if (itemText === enteredText || itemText.startsWith(enteredText)) {
					bExists = true;
					break;
				}
			}
			if (bExists) {
				if (enteredText.length > 0) {
					oEvent.getSource().setValueState("None");
				}
			} else {
				oEvent.getSource().setValueState(sap.ui.core.ValueState.Error);
				oEvent.getSource().setValue();
				oEvent.getSource().setValueStateText("Please enter valid " + oEvent.getSource().getParent().getAggregation("label").getText());
				sap.m.MessageToast.show("Please enter valid District");
			}

		},

		onSenZoneChange: function (oEvent) {

			var len = oEvent.getSource().getItems().length;
			var enteredText = oEvent.getSource().getValue();
			var bExists = false;

			for (var k = 0; k < len; k++) {
				var itemText = oEvent.getSource().getItems()[k].getProperty("text");
				if (itemText === enteredText || itemText.startsWith(enteredText)) {
					bExists = true;
					break;
				}
			}
			if (bExists) {
				if (enteredText.length > 0) {
					oEvent.getSource().setValueState("None");
				}
			} else {
				oEvent.getSource().setValueState(sap.ui.core.ValueState.Error);
				oEvent.getSource().setValue();
				oEvent.getSource().setValueStateText("Please enter valid " + oEvent.getSource().getParent().getAggregation("label").getText());
				sap.m.MessageToast.show("Please enter valid DPG Zone");
			}

		},

		onHomeZoneTableFinished: function () {
			var oTableItems = this.byId("empHomeZoneTable").getItems();
			if (oTableItems.length !== 0) {
				for (var i = 0; i < oTableItems.length; i++) {
					if (oTableItems[i].getAggregation("cells")[4].getText() === "B") {
						if (this.editBtnPress !== true) {
							oTableItems[i].getAggregation("cells")[3].getItems()[0].setVisible(false).setEnabled(false);
						} else {
							oTableItems[i].getAggregation("cells")[3].getItems()[0].setVisible(false).setEnabled(true);
						}
						oTableItems[i].getAggregation("cells")[3].getItems()[1].setVisible(false).setEnabled(true);
					} else if (oTableItems[i].getAggregation("cells")[4].getText() === "F") {
						oTableItems[i].getAggregation("cells")[3].getItems()[0].setVisible(false).setEnabled(false);
						oTableItems[i].getAggregation("cells")[3].getItems()[1].setVisible(false).setEnabled(true);
					}
					oTableItems[i].getAggregation("cells")[2].setEnabled(false);
				}
			} else {
				this.byId("saveBtn").setEnabled(false);
			}
		},

		onExpand: function () {
			var qualPanel = this.byId("qualPanel");
			var itemDataPanel = this.byId("itemDataPanel");
			itemDataPanel.setExpanded(qualPanel.getExpanded());
		},

		onAdditionalSenInfoTableFinished: function () {
			var oTableItems = this.byId("empAdditionalSenInfoTable").getItems();
			if (oTableItems.length !== 0) {
				for (var i = 0; i < oTableItems.length; i++) {
					if (oTableItems[i].getAggregation("cells")[10].getText() === "B") {
						if (this.editBtnPress !== true) {
							oTableItems[i].getAggregation("cells")[9].getItems()[0].setVisible(true).setEnabled(false);
						} else {
							oTableItems[i].getAggregation("cells")[9].getItems()[0].setVisible(true).setEnabled(true);
						}
						oTableItems[i].getAggregation("cells")[9].getItems()[1].setVisible(false).setEnabled(true);
					} else if (oTableItems[i].getAggregation("cells")[10].getText() === "F") {
						oTableItems[i].getAggregation("cells")[9].getItems()[0].setVisible(false).setEnabled(false);
						oTableItems[i].getAggregation("cells")[9].getItems()[1].setVisible(true).setEnabled(true);
					}
					oTableItems[i].getAggregation("cells")[8].setEnabled(false);
				}
			} else {
				this.byId("saveBtn").setEnabled(false);
			}

		},

		onEmpHomeZoneAdd: function () {
			var that = this;

			var homeZone = that.byId("empHomeZoneDropDown").getValue();
			var rrHired = that.byId("empRrHiredDropDown").getValue();

			if (that.byId("empHomeZoneSearch").getTokens().length === 0) {
				// that.byId("empHomeZoneSearch").setValueState("Error");
				sap.m.MessageToast.show("Please enter Employee ID");
			} else if (homeZone === "") {
				// that.byId("empHomeZoneSearch").setValueState("None");
				that.byId("empHomeZoneDropDown").setValueState("Error");
				sap.m.MessageToast.show("Please select Home Zone");
			} else if (rrHired === "") {
				// that.byId("empHomeZoneSearch").setValueState("None");
				that.byId("empHomeZoneDropDown").setValueState("None");
				that.byId("empRrHiredDropDown").setValueState("Error");
				sap.m.MessageToast.show("Please select RR Hired");
			} else {
				// that.byId("empHomeZoneSearch").setValueState("None");
				that.byId("empHomeZoneDropDown").setValueState("None");
				that.byId("empRrHiredDropDown").setValueState("None");

				var oResults = that.byId("empHomeZoneTable").getModel("empHomeZoneModel").getData();
				if (oResults.length > 0) {
					sap.m.MessageToast.show("Employee should only have 1 active home zone and RR Hired at a time");
					return;
				}
				var oObject = {};
				oObject.Action = "A";
				oObject.EmpNo = that.byId("empHomeZoneSearch").getTokens()[0].getKey();
				oObject.HomeZone = homeZone;
				oObject.RRHired = rrHired;
				oObject.RRCode = "";
				oObject.Division = "";
				oObject.Group = "";
				oObject.District = "";
				oObject.RMD_Date = "";
				oObject.AsstFDate = "";
				oObject.FDate = "";
				oObject.TCDate = "";
				oObject.EndDate = "99991231";
				oObject.Key = "F";
				oObject.EndDate = "20200510";
				oResults.results.push(oObject);

				that.byId("empHomeZoneTable").getModel("empHomeZoneModel").setData(oResults);
				that.byId("empHomeZoneTable").getModel("empHomeZoneModel").refresh();

				that.byId("saveBtn").setEnabled(true);

				that.byId("empHomeZoneDropDown").setValue();
				that.byId("empRrHiredDropDown").setValue();

			}

		},

		onAdditionalSenInfoAdd: function () {
			var that = this;

			var rrCode = that.byId("additionalSenInfoRrCodeDropDown").getValue();
			var division = that.byId("additionalSenInfoDivDropDown").getValue();
			var group = that.byId("additionalSenInfoGroupInp").getValue();
			var district = that.byId("additionalSenInfoDistDropDown").getValue();
			var rmdDate = that.byId("additionalSenInfoRmdDate").getValue();
			var afmDate = that.byId("additionalSenInfoAFMDate").getValue();
			var fmDate = that.byId("additionalSenInfoFMDate").getValue();
			var tcDate = that.byId("additionalSenInfoTcDate").getValue();

			if (that.byId("empAdditionalSenInfoSearch").getTokens().length === 0) {
				// that.byId("empAdditionalSenInfoSearch").setValueState("Error");
				sap.m.MessageToast.show("Please enter Employee ID");
			} else if (rrCode === "") {
				// that.byId("empAdditionalSenInfoSearch").setValueState("None");
				that.byId("additionalSenInfoRrCodeDropDown").setValueState("Error");
				sap.m.MessageToast.show("Please select RR Code");
			} else if (division === "") {
				// that.byId("empAdditionalSenInfoSearch").setValueState("None");
				that.byId("additionalSenInfoRrCodeDropDown").setValueState("None");
				that.byId("additionalSenInfoDivDropDown").setValueState("Error");
				sap.m.MessageToast.show("Please select Division");
			} else if (district === "") {
				// that.byId("empAdditionalSenInfoSearch").setValueState("None");
				that.byId("additionalSenInfoRrCodeDropDown").setValueState("None");
				that.byId("additionalSenInfoDivDropDown").setValueState("None");
				that.byId("additionalSenInfoGroupInp").setValueState("None");
				that.byId("additionalSenInfoDistDropDown").setValueState("Error");
				sap.m.MessageToast.show("Please select District");
				// } else if (rmdDate === "") {
				// 	// that.byId("empAdditionalSenInfoSearch").setValueState("None");
				// 	that.byId("additionalSenInfoRrCodeDropDown").setValueState("None");
				// 	that.byId("additionalSenInfoDivDropDown").setValueState("None");
				// 	that.byId("additionalSenInfoGroupInp").setValueState("None");
				// 	that.byId("additionalSenInfoDistDropDown").setValueState("None");
				// 	that.byId("additionalSenInfoRmdDate").setValueState("Error");
				// 	sap.m.MessageToast.show("Please select RM Date");
			} else {
				// that.byId("empAdditionalSenInfoSearch").setValueState("None");
				that.byId("additionalSenInfoRrCodeDropDown").setValueState("None");
				that.byId("additionalSenInfoDivDropDown").setValueState("None");
				that.byId("additionalSenInfoGroupInp").setValueState("None");
				that.byId("additionalSenInfoDistDropDown").setValueState("None");
				that.byId("additionalSenInfoRmdDate").setValueState("None");
				that.byId("additionalSenInfoAFMDate").setValueState("None");
				that.byId("additionalSenInfoFMDate").setValueState("None");
				that.byId("additionalSenInfoTcDate").setValueState("None");

				var oResults = that.byId("empAdditionalSenInfoTable").getModel("empAdditionalSenInfoModel").getData();

				var oObject = {};
				oObject.Action = "A";
				oObject.EmpNo = that.byId("empAdditionalSenInfoSearch").getTokens()[0].getKey();
				oObject.HomeZone = "";
				oObject.RRHired = "";
				oObject.RRCode = rrCode;
				oObject.Division = division;
				oObject.Group = group;
				oObject.District = district;
				oObject.RMD_Date = rmdDate;
				oObject.AsstFDate = afmDate;
				oObject.FDate = fmDate;
				oObject.TCDate = tcDate;
				oObject.EndDate = "99991231";
				oObject.Key = "F";
				oResults.results.push(oObject);

				that.byId("empAdditionalSenInfoTable").getModel("empAdditionalSenInfoModel").setData(oResults);
				that.byId("empAdditionalSenInfoTable").getModel("empAdditionalSenInfoModel").refresh();

				that.byId("saveBtn").setEnabled(true);

				that.byId("additionalSenInfoRrCodeDropDown").setValue();
				that.byId("additionalSenInfoDivDropDown").setValue();
				that.byId("additionalSenInfoGroupInp").setValue();
				that.byId("additionalSenInfoDistDropDown").setValue();
				that.byId("additionalSenInfoRmdDate").setValue();
				that.byId("additionalSenInfoAFMDate").setValue();
				that.byId("additionalSenInfoFMDate").setValue();
				that.byId("additionalSenInfoTcDate").setValue();

			}

		},

		onHomeZoneChange: function (oEvent) {

			var len = oEvent.getSource().getItems().length;
			var enteredText = oEvent.getSource().getValue();
			var bExists = false;
			for (var k = 0; k < len; k++) {
				var itemText = oEvent.getSource().getItems()[k].getProperty("text");
				if (itemText === enteredText || itemText.startsWith(enteredText)) {
					bExists = true;
					break;
				}
			}
			if (bExists) {
				oEvent.getSource().setValueState("None");
			} else {
				oEvent.getSource().setValueState(sap.ui.core.ValueState.Error);
				oEvent.getSource().setValue();
				oEvent.getSource().setValueStateText("Please enter valid Home Zone");
				sap.m.MessageToast.show("Please enter valid Home Zone");
			}

		},

		onRrHiredChange: function (oEvent) {

			var len = oEvent.getSource().getItems().length;
			var enteredText = oEvent.getSource().getValue();
			var bExists = false;
			for (var k = 0; k < len; k++) {
				var itemText = oEvent.getSource().getItems()[k].getProperty("text");
				if (itemText === enteredText || itemText.startsWith(enteredText)) {
					bExists = true;
					break;
				}
			}
			if (bExists) {
				oEvent.getSource().setValueState("None");
			} else {
				oEvent.getSource().setValueState(sap.ui.core.ValueState.Error);
				oEvent.getSource().setValue();
				oEvent.getSource().setValueStateText("Please enter valid RR Hired");
				sap.m.MessageToast.show("Please enter valid RR Hired");
			}

		},

		onAdditionalSenInfoRrCodeChange: function (oEvent) {

			var len = oEvent.getSource().getItems().length;
			var enteredText = oEvent.getSource().getValue();
			var bExists = false;
			for (var k = 0; k < len; k++) {
				var itemText = oEvent.getSource().getItems()[k].getProperty("text");
				if (itemText === enteredText || itemText.startsWith(enteredText)) {
					bExists = true;
					break;
				}
			}
			if (bExists) {
				oEvent.getSource().setValueState("None");
			} else {
				oEvent.getSource().setValueState(sap.ui.core.ValueState.Error);
				oEvent.getSource().setValue();
				oEvent.getSource().setValueStateText("Please enter valid RR Code");
				sap.m.MessageToast.show("Please enter valid RR Code");
			}

		},

		onAdditionalSenInfoDivChange: function (oEvent) {

			var len = oEvent.getSource().getItems().length;
			var enteredText = oEvent.getSource().getValue();
			var bExists = false;
			for (var k = 0; k < len; k++) {
				var itemText = oEvent.getSource().getItems()[k].getProperty("text");
				if (itemText === enteredText || itemText.startsWith(enteredText)) {
					bExists = true;
					break;
				}
			}
			if (bExists) {
				oEvent.getSource().setValueState("None");
			} else {
				oEvent.getSource().setValueState(sap.ui.core.ValueState.Error);
				oEvent.getSource().setValue();
				oEvent.getSource().setValueStateText("Please enter valid Division");
				sap.m.MessageToast.show("Please enter valid RR Division");
			}

		},

		onAdditionalSenInfoDistChange: function (oEvent) {

			var len = oEvent.getSource().getItems().length;
			var enteredText = oEvent.getSource().getValue();
			var bExists = false;
			for (var k = 0; k < len; k++) {
				var itemText = oEvent.getSource().getItems()[k].getProperty("text");
				if (itemText === enteredText || itemText.startsWith(enteredText)) {
					bExists = true;
					break;
				}
			}
			if (bExists) {
				oEvent.getSource().setValueState("None");
			} else {
				oEvent.getSource().setValueState(sap.ui.core.ValueState.Error);
				oEvent.getSource().setValue();
				oEvent.getSource().setValueStateText("Please enter valid District");
				sap.m.MessageToast.show("Please enter valid RR District");
			}

		},

		onQualReqDetailsPress: function (oEvent) {
			var that = this;
			var oItemPath = oEvent.getSource().getBindingContextPath();
			var oContext = oEvent.getSource().getParent().getModel("qualReqDetailsModel").getProperty(oItemPath);
			var qualId = oContext.QualId;
			if (qualId.trim().length < 1) {
				qualId = "0";
			}

			var timestamp = oContext.Timestamp;
			if (timestamp.trim().length < 1) {
				timestamp = "0";
			}

			var qualif = oContext.Qualification;
			if (qualif.trim().length < 1) {
				qualif = "0";
			}

			var empId = oContext.EmpId;
			if (empId.trim().length < 1) {
				empId = "0";
			}
			var empName = oContext.EmpName;
			if (empName.trim().length < 1) {
				empName = "0";
			}
			var subDate = oContext.SubDate;
			if (subDate.trim().length < 1) {
				subDate = "0";
			}
			var qualDesc = oContext.QualDesc;
			if (qualDesc.trim().length < 1) {
				qualDesc = "0";
			}
			sap.ui.core.UIComponent.getRouterFor(that).navTo("ApproveQual", {
				QualId: qualId,
				QualDesc: encodeURIComponent(qualDesc),
				EmpId: empId,
				EmpName: empName,
				SubDate: subDate,
				Timestamp: timestamp,
				Qualification: encodeURIComponent(qualif),
				Status: oContext.Status
			});

		}

	});
});