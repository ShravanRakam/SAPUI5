sap.ui.define(["jquery.sap.global"],
    function(jQuery) {
        "use srtict";
            var DemoPersoService = {
        getPersData: function() {
                var oDeferred = new jQuery.Deferred();
                if (!this._oBundle) {
                    // this._oBundle = this.oData;
                }
                var oBundle = this._oBundle;
                oDeferred.resolve(oBundle);
                return oDeferred.promise();
            },

 

            setPersData: function(oBundle) {
                var oDeferred = new jQuery.Deferred();
                this._oBundle = oBundle;
                oDeferred.resolve();
                return oDeferred.promise();
            }
            };
            return DemoPersoService;

 

    },true

 

);