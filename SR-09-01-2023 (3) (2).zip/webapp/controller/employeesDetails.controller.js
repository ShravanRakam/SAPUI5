sap.ui.define([
	"sap/ui/core/mvc/Controller",
	"sap/ui/model/json/JSONModel",
	"sap/ui/model/Filter",
	"sap/ui/model/FilterOperator",
	"sap/ui/export/Spreadsheet",
	"sap/ui/core/util/Export",
	"sap/ui/core/util/ExportTypeCSV",
	"sap/m/MessageBox",
	"sap/m/TablePersoController",
	"../model/PersoService"
], function(Controller, JSONModel, Filter, FilterOperator, Spreadsheet, Export, ExportTypeCSV, MessageBox, TablePersoController,
	PersoService) {
	"use strict";

	return Controller.extend("com.SRSR-09-01-2023.controller.employeesDetails", {
		onInit: function() {
			var that = this;
			var oModel = new JSONModel({
				"empId": "",
				"empName": "",
				"empDesignation": "",
				"empLocaton": "",
				"empDept": "",
				"DOJ": ""

			});
			that.getView().setModel(oModel, "dummyModel");
			that.getEmployeeDetails();
			// that.getEmployeeSearchSet();
			that.designationData();
			that.locationData();
			that.deptData();

			var createForm = new JSONModel({

				"Firstname": "",
				"Secondname": "",
				"Designation": "",
				"Location": "",
				"Department": "",
				"Reportto": "",
				"Experience": "",
				"Joiningdate": "",
				"Dob": "",
				"Street": "",
				"Village": "",
				"Landmark": "",
				"Mandal": "",
				"District": "",
				"Pincode": "",
				"State": "",
				"Phonenumber": "",
				"Op2022": "",
				"Op2021": "",
				"Op2020": ""

			});
			that.getView().setModel(createForm, "formModel");
			var inputModel = new JSONModel({
				"Op2022": false,
				"Op2021": false,
				"Op2020": false
			});
			that.getView().setModel(inputModel, "yearVisibility");

			var buttonModel = new JSONModel({
				editButton: false,
				createButton: false,
				deleteButton: false,
				cancelButton: false

			});
			that.getView().setModel(buttonModel, "buttonVisible");
			var oModel1 = new JSONModel(jQuery.sap.getModulePath("com.SRSR-09-01-2023", "/model/comboBox.json"));
			that.getView().setModel(oModel1, "comboBoxModel");
			that._oTPC = new TablePersoController({
				table: that.getView().byId("table"),
				//specify the first part of persistence ids e.g. 'demoApp-productsTable-dimensionsCol'
				componentName: "Demo",
				// resetAllMode: this.ResetAllMode.ServiceReset,
				persoService: PersoService

			}).activate();

			// var count = oBinding ;
			// that.getView("itemCount").setValue(count);

		},
		onAfterRendering: function() {
			var that = this;
			var oTable = that.getView().byId("table");
			var count = oTable.getItems().length;
			that.getView().setModel(count, "count");
		},
		onPersoButtonPressed: function(oEvent) {
			var that = this;
			that._oTPC.openDialog();
		},

		getEmployeeDetails: function() {
			var that = this;
			var dataModel = that.getOwnerComponent().getModel("employeeModel");
			dataModel.read("/Employee_DetailsSet", {
				// filters: mFilters,
				success: function(OData, res) {
					if (res.statusCode === "200" || res.statusCode === 200) {
						var employeeDetails = new JSONModel(OData.results);
						that.getView().setModel(employeeDetails, "employeeDetail");

					}
				},
				error: function(err) {

				}
			});
		},
		getEmployeeSearchSet: function() {
			var that = this;
			var dataModel = that.getOwnerComponent().getModel("employeeModel");
			var mFilters = [new Filter("Flag", FilterOperator.EQ, "D")

			];
			dataModel.read("/EmployeeSearchHelpSet", {
				filters: mFilters,
				success: function(OData, res) {
					if (res.statusCode === "200" || res.statusCode === 200) {
						var employeeDetails = new JSONModel(OData.results);
						that.getView().setModel(employeeDetails, "employeeSearchHelpSet");
					}
				},
				error: function(err) {

				}
			});
		},
		onCreate: function() {
			var that = this;
			var dataModelCreate = that.getOwnerComponent().getModel("employeeModel");
			var formData = that.getView().getModel("formModel").getData();
			var firstName = formData.Firstname;
			var lastName = formData.Secondname;
			if (firstName !== "" && lastName !== "") {
				dataModelCreate.create("/Employee_DetailsSet", formData, {
					success: function(OData) {

						that.getEmployeeDetails();
						that.onpressCancel();
						MessageBox.show("Record Created Successfuly");
					}
				});

			} else {
				MessageBox.warning("Please enter Details to Create a record");
			}
		},
		validationOfInput: function(oEvent) {
			var that = this;
			var getNames = oEvent.getSource().getName();
			var getYear = oEvent.getSource().getValue().slice(0, 4);
			if (getNames === "joiningDate") {
				if (getYear === "2022") {
					that.getView().getModel("yearVisibility").setProperty("/Op2022", true);
					that.getView().getModel("yearVisibility").setProperty("/Op2021", false);
					that.getView().getModel("yearVisibility").setProperty("/Op2020", false);
				} else if (getYear === "2021") {
					that.getView().getModel("yearVisibility").setProperty("/Op2022", true);
					that.getView().getModel("yearVisibility").setProperty("/Op2021", true);
					that.getView().getModel("yearVisibility").setProperty("/Op2020", false);
				} else if (getYear === "2020") {
					that.getView().getModel("yearVisibility").setProperty("/Op2022", true);
					that.getView().getModel("yearVisibility").setProperty("/Op2021", true);
					that.getView().getModel("yearVisibility").setProperty("/Op2020", true);
				} else {
					MessageBox.error("Please check the year, the year shpuld be on between 2020 to 2022");
				}
			}
		},
		onpressCancel: function() {
			var that = this;
			that.oDialog.close();
			that.oDialog.destroy();
			that.oDialog = null;
		},
		designationData: function() {
			var that = this,
				oFilters = [],
				dataModel = that.getOwnerComponent().getModel("employeeModel");
			oFilters.push(new Filter("Flag", FilterOperator.EQ, "D"));
			dataModel.read("/EmployeeSearchHelpSet", {
				filters: oFilters,
				success: function(OData, res) {
					if (res.statusCode === "200" || res.statusCode === 200) {
						var employeeDetails = new JSONModel(OData.results);
						that.getView().setModel(employeeDetails, "designModel");

					}
				},
				error: function(err) {

				}
			});
		},
		locationData: function() {
			var that = this,
				oFilters = [],
				dataModel = that.getOwnerComponent().getModel("employeeModel");
			oFilters.push(new Filter("Flag", FilterOperator.EQ, "L"));
			dataModel.read("/EmployeeSearchHelpSet", {
				filters: oFilters,
				success: function(OData, res) {
					if (res.statusCode === "200" || res.statusCode === 200) {
						var employeeDetails = new JSONModel(OData.results);
						that.getView().setModel(employeeDetails, "locModel");

					}
				},
				error: function(err) {

				}
			});
		},
		deptData: function() {
			var that = this,
				oFilters = [],
				dataModel = that.getOwnerComponent().getModel("employeeModel");
			oFilters.push(new Filter("Flag", FilterOperator.EQ, "DP"));
			dataModel.read("/EmployeeSearchHelpSet", {
				filters: oFilters,
				success: function(OData, res) {
					if (res.statusCode === "200" || res.statusCode === 200) {
						var employeeDetails = new JSONModel(OData.results);
						that.getView().setModel(employeeDetails, "deptModel");

					}
				},
				error: function(err) {

				}
			});
		},
		onDelete: function(oEvent) {
			var that = this,

				selectedItem = that.getView().byId("table").getSelectedContexts()[0];
			if (selectedItem !== undefined) {
				var selectedObject = selectedItem + "getObject().EmpId";
				var dataModel = that.getOwnerComponent().getModel("employeeModel");
				dataModel.remove("/Employee_DetailsSet('" + selectedObject + "')", {
					success: function(oData) {
						MessageBox.show("Deleted Successfully");
						that.getEmployeeDetails();
					}
				});

			} else {
				MessageBox.warning("Please select any Record to Delete");
			}

		},

		onCancelPress: function() {
			var that = this;
			that.oDialog.close();
			that.oDialog.destroy();
			that.oDialog = null;
		},
		onPressRefresh: function() {
			var that = this;
			var oTable = that.getView().byId("table");
			var oBinding = oTable.getBinding("items");
			oBinding.sort(null);
			oBinding.filter(null);
		},
		onPressButtons: function(oEvent) {
			var that = this;

			var oModel = that.getView().getModel("buttonVisible");
			// var inputModel = that.getView().getModel("inputVisible");
			oModel.setProperty("/editButton", false);
			oModel.setProperty("/createButton", true);
			if (!that.oDialog) {
				that.oDialog = sap.ui.xmlfragment("com.SRSR-09-01-2023.fragments.createForm", that);
				that.getView().addDependent(that.oDialog);
			}

			that.oDialog.open();

		},
		onSubmitPress: function(oEvent) {
			var that = this;
			// // var getName = oEvent.getSource.getName();
			var filter = [];
			var selectedEmpName = oEvent.getSource().getModel("dummyModel").getProperty("/empName");
			if (selectedEmpName) {
				filter.push(new Filter("Firstname", FilterOperator.Contains, selectedEmpName));
			}
			var selectedDesignation = oEvent.getSource().getModel("dummyModel").getProperty("/empDesignation");
			if (selectedDesignation) {
				filter.push(new Filter("Designation", FilterOperator.Contains, selectedDesignation));
			}
			var selectedLocation = oEvent.getSource().getModel("dummyModel").getProperty("/empLocaton");
			if (selectedLocation) {
				filter.push(new Filter("Location", FilterOperator.Contains, selectedLocation));
			}
			var selectedDept = oEvent.getSource().getModel("dummyModel").getProperty("/empDept");
			if (selectedDept) {
				filter.push(new Filter("Department", FilterOperator.Contains, selectedDept));
			}
			var selectedDOJ = oEvent.getSource().getModel("dummyModel").getProperty("/DOJ");
			if (selectedDOJ) {
				filter.push(new Filter("Joiningdate", FilterOperator.Contains, selectedDOJ));
			}

			var oNewFilter = new Filter({
				filters: filter,
				and: false
			});
			var oTab = that.getView().byId("table");
			oTab.getBinding("items").filter(oNewFilter);

		},
		onAcceptPressInput: function(oControlEvent) {

			var that = this;
			var oSelectedItem = oControlEvent.getParameters("listItems").selectedContexts[0].getObject().Description;

			that.getView().getModel("dummyModel").setProperty("/empDept", oSelectedItem);
			that.getView().getModel("formModel").setProperty("/Department", oSelectedItem);

		},
		setHeaderContext: function() {
			var oView = this.getView();
			oView.byId("SalesOrdersTitle").setBindingContext(
				oView.byId("SalesOrders").getBinding("items").getHeaderContext());
		},
		onSearchData: function(oEvent) {
			var that = this;
			//build filter array

			var sQuery = oEvent.getParameter("query");

			if (!sQuery) {
				sQuery = oEvent.getParameter("newValue");
			}
			var filter1 = new Filter("EmpId", FilterOperator.Contains, sQuery);
			var filter2 = new Filter("Firstname", FilterOperator.Contains, sQuery);
			var filter3 = new Filter("Designation", FilterOperator.Contains, sQuery);
			var filter4 = new Filter("Location", FilterOperator.Contains, sQuery);
			var filter5 = new Filter("Department", FilterOperator.Contains, sQuery);
			var filter6 = new Filter("Reportto", FilterOperator.Contains, sQuery);
			var filter7 = new Filter("Joiningdate", FilterOperator.Contains, sQuery);
			var filter8 = new Filter("Experience", FilterOperator.Contains, sQuery);
			var filter9 = new Filter("Secondname", FilterOperator.Contains, sQuery);
			var filterData = [filter1, filter2, filter3, filter4, filter5, filter6, filter7, filter8, filter9];

			var oNewFilter = new Filter({
				filters: filterData,
				and: false
			});
			// filter binding
			var oTab = that.getView().byId("table");
			var oBinding = oTab.getBinding("items");
			oBinding.filter(oNewFilter);
		},
		onValueHelpRequested: function() {
			var that = this;
			if (!that.deptDialog) {
				that.deptDialog = sap.ui.xmlfragment("com.SRSR-09-01-2023.fragments.departmentList", that);
				that.getView().addDependent(that.deptDialog);
			}

			that.deptDialog.open();
		},
		onPressAdd: function() {
			var that = this;
			if (!that.createDialog) {
				that.createDialog = sap.ui.xmlfragment("com.SRSR-09-01-2023.fragments.createForm", that);
				that.getView().addDependent(that.createDialog);
			}

			that.createDialog.open();

		},
		onPressColumn: function(oEvent) {
			var sObject = oEvent.getSource().getBindingContext("employeeDetail").getObject().EmpId;
			// var sIndex = sPath.split("/")[sPath.split("/").length - 1];
			var oRouter = sap.ui.core.UIComponent.getRouterFor(this);

			oRouter.navTo("view2", {
				"Details": sObject
			});
		},
		createColumnConfig: function() {
			var aColumns = [];

			aColumns.push({
				label: 'EMPLOYEE ID',
				property: 'EmpId'
			});
			aColumns.push({
				label: 'EMPLOYEE NAME',
				property: 'FirstName'
			});
			aColumns.push({
				label: 'DESIGNATION',
				property: 'Designation'
			});

			aColumns.push({
				label: ' LOCATION',
				property: 'Location'
			});
			aColumns.push({
				label: 'DEPARTMENT',
				property: 'Department'
			});
			aColumns.push({
				label: 'REPORTING TO',
				property: 'Reportto'
			});
			aColumns.push({
				label: 'EXPERIENCE',
				property: 'Experience'
			});
			aColumns.push({
				label: 'JOINING DATE',
				property: 'DOJ'
			});
			return aColumns;
		},
		onPressExport: function() {
			var that = this;
			var oTable, tableItems;
			oTable = that.getView().byId("table");
			tableItems = oTable.getItems();
			if (tableItems.length > 0) {
				//varibles related to spreedsheet
				var aColumns, oSettings, oSheet;
				aColumns = that.createColumnConfig();
				var collectionRecord = that.getView().getModel("employeeDetail").getData();
				//calling columns event in order to get that colums
				// aCols = that.createColumnConfig();
				//geting whole data from model
				oSettings = {
					workbook: {
						columns: aColumns,
						context: {
							sheetName: "employeeDetails"
						}
					},
					dataSource: collectionRecord,
					fileName: "employeeDetails"
				};
				//created spreedsheet
				oSheet = new Spreadsheet(oSettings);
				oSheet.build()
					.then(function() {
						//	MessageToast.show("Spreadsheet export has finished);
					})
					.finally(function() {
						oSheet.destroy();
					});
			}
		},
		onPressDownload: function() {
			var that = this;
			var oExport = new Export({
				exportType: new ExportTypeCSV({
					separatorChar: ";"
				}),
				models: that.getView().getModel("employeeDetail"),
				rows: {
					path: "/Employee_DetailsSet"
				},
				columns: [{
					name: "EMPLOYEE ID",
					template: {
						content: "{EmpId}"
					}
				}, {
					name: "EMPLOYEE FIRSTNAME",
					template: {
						content: "{Firstname}"
					}
				}, {
					name: "EMPLOYEE LASTNAME",
					template: {
						content: "{Lastname}"
					}
				}, {
					name: "DESIGNATION",
					template: {
						content: "{Designation}"
					}
				}, {
					name: "LOCATION",
					template: {
						content: "{Location}"
					}
				}, {
					name: "DEPARTMENT",
					template: {
						content: "{Department}"
					}
				}, {
					name: "REPORTING TO",
					template: {
						content: "{ReportTo}"
					}
				}, {
					name: "EXPERIENCE",
					template: {
						content: "{Experience}"
					}
				}, {
					name: "JOINING DATE",
					template: {
						content: "{DOJ}"
					}
				}]
			});

			// download exported file
			oExport.saveFile().catch(function(oError) {
				MessageBox.error("Error when downloading data. Browser might not be supported!\n\n" + oError);
			}).then(function() {
				oExport.destroy();
			});
		}

	});
});