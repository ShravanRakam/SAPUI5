sap.ui.define([
	"sap/ui/core/mvc/Controller",
	"sap/ui/model/json/JSONModel",
	"sap/ui/model/Filter",
	"sap/ui/model/FilterOperator",
	"sap/ui/core/routing/History",
	"sap/m/MessageBox"

], function(Controller, JSONModel, Filter, FilterOperator, History, MessageBox) {
	"use strict";

	return Controller.extend("com.SRSR-09-01-2023.controller.EmployeeDetails", {
		onInit: function() {
			var that = this;
			var oModel = new JSONModel({
				"editButton": ""
			});
			that.getView().setModel(oModel, "buttonVisibility");
			that.deptData();
			that.locationData();
			that.designationData();
			var oRouter = that.getOwnerComponent().getRouter();
			oRouter.getRoute("view2").attachPatternMatched(that.onObjectMatched, that);
		},
		onObjectMatched: function(oEvent) {
			var that = this;
			var selectedArguments = oEvent.getParameter("arguments").Details;
			var dataModel = that.getOwnerComponent().getModel("employeeModel");
			dataModel.read("/Employee_DetailsSet('" + selectedArguments + "')", {
				success: function(OData, res) {
					if (res.statusCode === "200" || res.statusCode === 200) {
						var employeeDetails = new JSONModel(OData);
						that.getView().setModel(employeeDetails, "employeeData");
					
					}
				},
				error: function(err) {

				}
			});
		},
		getEmployeeDetails: function() {
			var that = this;
			var dataModel = that.getOwnerComponent().getModel("employeeModel");
			dataModel.read("/Employee_DetailsSet", {
				// filters: mFilters,
				success: function(OData, res) {
					if (res.statusCode === "200" || res.statusCode === 200) {
						var employeeDetails = new JSONModel(OData.results);
						that.getView().setModel(employeeDetails, "employeeDetail");

					}
				},
				error: function(err) {

				}
			});
		},
		designationData: function() {
			var that = this,
				oFilters = [],
				dataModel = that.getOwnerComponent().getModel("employeeModel");
			oFilters.push(new Filter("Flag", FilterOperator.EQ, "D"));
			dataModel.read("/EmployeeSearchHelpSet", {
				filters: oFilters,
				success: function(OData, res) {
					if (res.statusCode === "200" || res.statusCode === 200) {
						var employeeDetails = new JSONModel(OData.results);
						that.getView().setModel(employeeDetails, "designModel");

					}
				},
				error: function(err) {

				}
			});
		},
		locationData: function() {
			var that = this,
				oFilters = [],
				dataModel = that.getOwnerComponent().getModel("employeeModel");
			oFilters.push(new Filter("Flag", FilterOperator.EQ, "L"));
			dataModel.read("/EmployeeSearchHelpSet", {
				filters: oFilters,
				success: function(OData, res) {
					if (res.statusCode === "200" || res.statusCode === 200) {
						var employeeDetails = new JSONModel(OData.results);
						that.getView().setModel(employeeDetails, "locModel");

					}
				},
				error: function(err) {

				}
			});
		},
		deptData: function() {
			var that = this,
				oFilters = [],
				dataModel = that.getOwnerComponent().getModel("employeeModel");
			oFilters.push(new Filter("Flag", FilterOperator.EQ, "DP"));
			dataModel.read("/EmployeeSearchHelpSet", {
				filters: oFilters,
				success: function(OData, res) {
					if (res.statusCode === "200" || res.statusCode === 200) {
						var employeeDetails = new JSONModel(OData.results);
						that.getView().setModel(employeeDetails, "deptModel");

					}
				},
				error: function(err) {

				}
			});
		},
		onValueHelpRequested: function() {
			var that = this;
			if (!that.deptDialog) {
				that.deptDialog = sap.ui.xmlfragment("com.SRSR-09-01-2023.fragments.departmentList", that);
				that.getView().addDependent(that.deptDialog);
			}

			that.deptDialog.open();
		},
		onAcceptPressInput: function(oControlEvent) {

			var that = this;
			var oSelectedItem = oControlEvent.getParameters("listItems").selectedContexts[0].getObject().Description;

			// that.getView().getModel("dummyModel").setProperty("/empDept", oSelectedItem);
			that.getView().getModel("employeeData").setProperty("/Department", oSelectedItem);

		},
		onPressEdit: function() {
			var that = this;

			var dataModel = that.getOwnerComponent().getModel("employeeModel");
			var updateData = this.getView().getModel("employeeData").getData();
			dataModel.update("/Employee_DetailsSet('" + updateData.EmpId + "')", updateData, {
				success: function(oData) {
					
					MessageBox.success("Updated successfully Successfully");
					
				}
			});

		},
		onBack: function() {
			var that = this;
			var oHistory, sPreviousHash;
			that.getEmployeeDetails();

			oHistory = History.getInstance();
			sPreviousHash = oHistory.getPreviousHash();

			if (sPreviousHash !== undefined) {
				window.history.go(-1);
			} else {
				this.getRouter().navTo("view1", {}, true /*no history*/ );
			}
		}
	});
});