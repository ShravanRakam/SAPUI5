sap.ui.define([
	"sap/ui/core/mvc/Controller",
	"sap/ui/model/json/JSONModel",
	"sap/ui/model/Filter",
	"sap/ui/model/FilterOperator",
	"sap/m/MessageBox"
], function(Controller, JSONModel, Filter, FilterOperator, MessageBox) {
	"use strict";

	return Controller.extend("RS_10_01_23RS_10_01_23.controller.View2", {
		onInit: function() {
			var Model = new JSONModel();
			this.getView().setModel(Model, "ButtonModel");
			var DPModel = new JSONModel({

				Department: ""

			});
			this.getView().setModel(DPModel, "FilterModel");
			// var FModel = new JSONModel();
			// this.getView().setModel(FModel, "v2Form");
			var oRouter = sap.ui.core.UIComponent.getRouterFor(this);
			oRouter.getRoute("View2").attachPatternMatched(this._objectMatched, this);

		},

		_objectMatched: function(oEvent) {

			var that = this;
			var path = oEvent.getParameter("arguments").Empid;

			var ODataModel = that.getOwnerComponent().getModel();
			var filters2 = new Filter("EmpId", FilterOperator.Contains, path);
			ODataModel.read("/Employee_DetailsSet", {
				filters: [filters2],
				success: function(Data) {

					var oViewModel = new JSONModel(Data.results[0]);
					that.getView().setModel(oViewModel, "form");
				}
			});

			that.getView().getModel("ButtonModel").setProperty("/onUpdateVisible", false);
			that.getView().getModel("ButtonModel").setProperty("/onEditVisible", true);
			that.getView().getModel("ButtonModel").setProperty("/onSaveVisible", false);
			that.getView().getModel("ButtonModel").setProperty("/onCancelVisible", false);
			that.getView().getModel("ButtonModel").setProperty("/onInputVisible", false);
			that.getView().getModel("ButtonModel").setProperty("/onOFTVisible", true);

		},
		/*When clikc on edit button */
		onEditPress: function() {
			var that = this;
			that.getView().getModel("ButtonModel").setProperty("/onEditVisible", false);
			that.getView().getModel("ButtonModel").setProperty("/onUpdateVisible", false);
			that.getView().getModel("ButtonModel").setProperty("/onSaveVisible", true);
			that.getView().getModel("ButtonModel").setProperty("/onCancelVisible", true);
			that.getView().getModel("ButtonModel").setProperty("/onInputVisible", true);
			that.getView().getModel("ButtonModel").setProperty("/onOFTVisible", true);
		},
		/*When click on save button */
		onSavePress: function() {
			var that = this;
			that.getView().getModel("ButtonModel").setProperty("/onEditVisible", false);
			that.getView().getModel("ButtonModel").setProperty("/onUpdateVisible", true);
			that.getView().getModel("ButtonModel").setProperty("/onSaveVisible", false);
			that.getView().getModel("ButtonModel").setProperty("/onCancelVisible", true);
			that.getView().getModel("ButtonModel").setProperty("/onInputVisible", false);
			that.getView().getModel("ButtonModel").setProperty("/onOFTVisible", true);
			// that.updateODataModel();
		},
		/*when click on Update button it makes service call to update data*/
		updateODataModel: function() {
			var that = this;
			var updatedData = that.getView().getModel("form").getData();
			// console.log(updatedData);
			var ODataModel = that.getOwnerComponent().getModel();
			ODataModel.update("/Employee_DetailsSet('" + updatedData.EmpId + "')", updatedData, {
				success: function(oData) {

					MessageBox.success("Record Updated Successfully");

				}

			});

		},
		/*when click on update it moves to last page*/
		onUpdatePress: function() {

			var Router = sap.ui.core.UIComponent.getRouterFor(this);
			Router.navTo("View1");
			this.updateODataModel();
			this.oDataModel();

		},
		/*To refresh the data in 2nd view*/
		onCancelPress: function() {
			this.getView().getModel("form").updateBindings(true);
		},
		/**/
		BackPress: function() {
			history.go(-1);
		},
		onPressAddDetails: function() {
			var that = this;
			that.getView().getModel("ButtonModel").setProperty("/onOFTVisible", false);

		},
		onSelectList: function() {
			var that = this;
			var url = "/sap/opu/odata/sap/ZHR_EMPLOYEE_DETAIL_SRV/";
			var oDataModel = new sap.ui.model.odata.ODataModel(url, true);
			oDataModel.read("/EmployeeSearchHelpSet?$filter=Flag eq 'DP'", {
				success: function(oData) {
					// console.log(oData);
					var tableMoldel = new JSONModel(oData);
					that.getView().setModel(tableMoldel, "DPFilter");

				}
			});
			if (!this.Dialog) {
				this.Dialog = sap.ui.xmlfragment("RS_10_01_23RS_10_01_23.view.fragment", this);
				this.getView().addDependent(this.Dialog);
			}

			this.Dialog.open();

		},
		onPresscancel: function() {
			this.Dialog.close();
		},
		onPressList: function(oEvent) {
			var value = oEvent.getSource().getTitle();

			this.getView().getModel("form").setProperty("/Department", value);

			this.onPresscancel();
		},
	

	});
});