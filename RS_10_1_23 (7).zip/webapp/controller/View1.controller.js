sap.ui.define([
	"sap/ui/core/mvc/Controller",
	"sap/ui/model/json/JSONModel",
	"sap/m/TablePersoController",
	"./personalization",
	"sap/ui/export/Spreadsheet",
	"sap/ui/core/util/Export",
	"sap/ui/core/util/ExportTypeCSV",
	"sap/m/MessageBox"

], function(Controller, JSONModel, TablePersoController, personalization, Spreadsheet, Export, ExportTypeCSV, MessageBox) {
	"use strict";

	return Controller.extend("RS_10_01_23RS_10_01_23.controller.View1", {
		onInit: function() {
			var that = this;
			this.oDataModel();
			this.location();
			this.Desigantion();
			var fModel = new JSONModel();
			this.getView().setModel(fModel, "Form");
			var Model = new JSONModel({
				Firstname: "",
				Designation: "",
				Location: "",
				Department: "",
				Joiningdate: ""
			});
			that.getView().setModel(Model, "FilterModel");

			that.oDialog = new TablePersoController({
				table: that.getView().byId("uTableId"),
				componentName: "Demo",
				persoService: personalization
			}).activate();

		},
		/*service call to get location data to combo box*/
		location: function() {
			var that = this;
			var url = "/sap/opu/odata/sap/ZHR_EMPLOYEE_DETAIL_SRV/";
			var oDataModel = new sap.ui.model.odata.ODataModel(url, true);
		
			oDataModel.read("/EmployeeSearchHelpSet?$filter=Flag eq 'L'", {
				success: function(oData) {
					console.log(oData);
					var tableMoldel = new JSONModel(oData);
					that.getView().setModel(tableMoldel, "LFilter");

				}
			});
		},
		/*service call to get get Desiganation data to combo box*/
		Desigantion: function() {
			var that = this;
			var url = "/sap/opu/odata/sap/ZHR_EMPLOYEE_DETAIL_SRV/";
			var oDataModel = new sap.ui.model.odata.ODataModel(url, true);
			oDataModel.read("/EmployeeSearchHelpSet?$filter=Flag eq 'D'", {
				success: function(oData) {
					console.log(oData);
					var tableMoldel = new JSONModel(oData);
					that.getView().setModel(tableMoldel, "DFilter");

				}
			});
		},
		/*To open the Personalization fragment */
		onPersoPress: function() {
			this.oDialog.openDialog();
		},
		createColumnConfig: function() {
			var aColumns = [];
			aColumns.push({

				label: 'Emp Id',
				property: 'EmpId'
			}, {
				label: 'Emp Name',
				property: 'Firstname'
			}, {
				label: 'Designation',
				property: 'Designation'
			}, {
				label: 'City',
				property: 'Location'
			}, {
				label: 'Department',
				property: 'Department'
			}, {
				label: 'Reportto',
				property: 'Reportto'
			}, {
				label: 'Experience',
				property: 'Experience'
			}, {
				label: 'Pincode',
				property: 'Pincode'
			}, {
				label: 'Joiningdate',
				property: 'Joiningdate'
			}, {
				label: 'Email',
				property: 'Email'
			}, {
				label: 'Phonenumber',
				property: 'Phonenumber'
			}, {
				label: 'Dob',
				property: 'Dob'
			});

			return aColumns;
		},
		/* To download spread sheet */
		onExportSpreadsheet: function() {
			var that = this;
			var oTable, tableItems;
			oTable = that.getView().byId("uTableId");
			tableItems = oTable.getItems();
			if (tableItems.length > 0) {
				// var aColumns, oSettings, oSheet;
				var aColumns = that.createColumnConfig();
				var collectionRecord = that.getView().getModel("uTable").getData().results;

				var oSettings = {
					workbook: {
						columns: aColumns,
						context: {
							sheetName: "Employee Details"
						}
					},
					dataSource: collectionRecord,
					fileName: "Employee Details List"
				};
				var oSheet = new Spreadsheet(oSettings);
				oSheet.build()
					.then(function() {

					})
					.finally(function() {
						oSheet.destroy();
					});
			}

		},
		/*To download table data through CSV type*/
		onDownloadData: function() {
			var oExport = new Export({

				exportType: new ExportTypeCSV({
					separator: "Column"
				}),

				models: this.getView().getModel(),

				rows: {
					path: "/Employee_DetailsSet"
				},

				columns: [{
						name: "EmpId",
						template: {
							content: "{EmpId}"
						}
					}, {
						name: "Firstname",
						template: {
							content: "{Firstname}"
						}
					}, {
						name: "Designation",
						template: {
							content: "{Designation}"
						}
					}, {
						name: "Location",
						template: {
							content: "{Location}"
						}
					}, {
						name: "Department",
						template: {
							content: "{Department}"
						}
					}, {
						name: "Reportto",
						template: {
							content: "{Reportto}"
						}
					}, {
						name: "Experience",
						template: {
							content: "{Experience}"
						}
					}, {
						name: "Joiningdate",
						template: {
							content: "{Joiningdate}"
						}
					}, {
						name: "Email",
						template: {
							content: "{Email}"
						}
					}, {
						name: "Phonenumber",
						template: {
							content: "{Phonenumber}"
						}
					}, {
						name: "Dob",
						template: {
							content: "{Dob}"
						}
					}

				]
			});

			oExport.saveFile().catch(function(oError) {
				MessageBox.error("Error when downloading data. Browser might not be supported!\n\n" + oError);
			}).then(function() {
				oExport.destroy();
			});

		},
		/*To search all fields of table using Search field in 
		overFlowTool bar*/
		onSearch: function(oEvent) {
			var source = oEvent.getSource();
			var items = source.getValue();
			var oTable = this.getView().byId("uTableId");
			var tableItems = oTable.getBinding("items");
			var IdFilter = new sap.ui.model.Filter("EmpId", sap.ui.model.FilterOperator.Contains, items);
			var nameFilter = new sap.ui.model.Filter("Firstname", sap.ui.model.FilterOperator.Contains, items);
			var DPFilter = new sap.ui.model.Filter("Department", sap.ui.model.FilterOperator.Contains, items);
			var DSGFilter = new sap.ui.model.Filter("Designation", sap.ui.model.FilterOperator.Contains, items);
			var LFilter = new sap.ui.model.Filter("Location", sap.ui.model.FilterOperator.Contains, items);
			var RPFilter = new sap.ui.model.Filter("Reportto", sap.ui.model.FilterOperator.Contains, items);

			var filters = new sap.ui.model.Filter([nameFilter,
				IdFilter,
				DPFilter,
				DSGFilter,
				LFilter,
				RPFilter
			], false);
			tableItems.filter(filters);

		},
		/*when click on fresh it restores the table data asusual*/
		onResetPress: function() {

		},
		/*to delete multiple rows of table*/
		onDelteData: function(oEvent) {
			var tabledata = this.getView().byId("uTableId");
			var items = tabledata.getSelectedItems();

			if (items.length > 0) {
				for (var i = items.length - 1; i >= 0; --i) {
					var path = items[i].getBindingContext("uTable").getObject().EmpId;
					var url = "/sap/opu/odata/sap/ZHR_EMPLOYEE_DETAIL_SRV/";
					var oModel = new sap.ui.model.odata.ODataModel(url, true);
					oModel.remove("/Employee_DetailsSet('" + path + "')", {
						success: function(oData) {
							MessageBox.success("Deleted Succesfully");

						}

					});
				}
			} else {
				MessageBox.error(" select Record");
			}
			this.oDataModel();

		},
		/*Read operation for table by Odata service call*/
		oDataModel: function() {
			var that = this;
			var url = "/sap/opu/odata/sap/ZHR_EMPLOYEE_DETAIL_SRV/";
			var oDataModel = new sap.ui.model.odata.ODataModel(url, true);
			oDataModel.read("/Employee_DetailsSet", {
				success: function(swamy) {
					// console.log(swamy);
					var tableMoldel = new JSONModel(swamy);
					that.getView().setModel(tableMoldel, "uTable");

				}
			});
		},
		/*TO navigane to another view from 1st view*/
		onNavTo: function(oEvent) {
			var sPath = oEvent.getSource().getBindingContext("uTable").getObject().EmpId;
			var oRouter = sap.ui.core.UIComponent.getRouterFor(this);
			oRouter.navTo("View2", {
				Empid: sPath
			});

		},
		/*When click on add button it opens a fragment with all the input fields*/
		onAddData: function() {
			if (!this.Form) {
				this.Form = sap.ui.xmlfragment("RS_10_01_23RS_10_01_23.view.crud", this);
				this.getView().addDependent(this.Form);
			}

			this.Form.open();

		},
		/*To close the crud fragment*/
		onClosePress: function() {
			this.Form.close();
		},
		/*saves the record that created by onAddData Button*/
		onCreatePress: function() {
			var that = this;
			var formData = that.getView().getModel("Form").getData();
			var sUrl = "/sap/opu/odata/sap/ZHR_EMPLOYEE_DETAIL_SRV/";
			var oModel = new sap.ui.model.odata.ODataModel(sUrl, true);
			// var formData = that.getView().getModel("Form").getData();
			oModel.create("/Employee_DetailsSet", formData, {
				success: function(Data) {
					MessageBox.success("record Created Successfuly");
					that.onClosePress();
					that.oDataModel();
				}
			});

			var val = that.getView().getModel("Form").getData().Firstname;
			if (val === undefined) {
				MessageBox.warning("name manditory");

			}
		},
		/*when clikc on value help of the department it opens the fragment with all department Data*/
		onSelectList: function() {
			var that = this;
			var url = "/sap/opu/odata/sap/ZHR_EMPLOYEE_DETAIL_SRV/";
			var oDataModel = new sap.ui.model.odata.ODataModel(url, true);
			oDataModel.read("/EmployeeSearchHelpSet?$filter=Flag eq 'DP'", {
				success: function(oData) {
					// console.log(oData);
					var tableMoldel = new JSONModel(oData);
					that.getView().setModel(tableMoldel, "DPFilter");

				}
			});
			if (!this.Dialog) {
				this.Dialog = sap.ui.xmlfragment("RS_10_01_23RS_10_01_23.view.fragment", this);
				this.getView().addDependent(this.Dialog);
			}

			this.Dialog.open();

		},
		/*closees the Department fragment*/
		onPresscancel: function() {
			this.Dialog.close();
		},
		/*when select an item in the department list t shiws in the input field*/
		onPressList: function(oEvent) {
			var value = oEvent.getSource().getTitle();
			this.getView().getModel("FilterModel").setProperty("/Department", value);
			this.getView().getModel("Form").setProperty("/Department", value);

			// 	// var table = this.byId("uTableId").getBinding("items");
			// 	// var filtername = new sap.ui.model.Filter("Department", sap.ui.model.FilterOperator.Contains, value);
			// 	// table.filter(filtername);
			this.onPresscancel();
		},
		/*to search name of employee on filter bar*/
		onEmpSearch: function(oEvent) {
			var source = oEvent.getSource();
			var items = source.getValue();
			this.getView().getModel("FilterModel").setProperty("/Firstname", items);
			// 	// var oTable = this.getView().byId("uTableId");
			// 	// var tableItems = oTable.getBinding("items");
			// 	// var nameFilter = new sap.ui.model.Filter("Firstname", sap.ui.model.FilterOperator.Contains, items);
			// 	// var secondfilter = new sap.ui.model.Filter("Secondname", sap.ui.model.FilterOperator.Contains, items);
			// 	// var filte = [nameFilter, secondfilter];
			// 	// var filters = new sap.ui.model.Filter(filte, false);
			// 	// tableItems.filter(filters);

		},
		/*To select the value of Designation in the combo box*/
		onSelectDesignation: function(oEvent) {
			var value = oEvent.getSource().getSelectedItem().getText();
			this.getView().getModel("FilterModel").setProperty("/Designation", value);

			// 	// var oTable = this.byId("uTableId").getBinding("items");
			// 	// var filterNo = new sap.ui.model.Filter("Designation", sap.ui.model.FilterOperator.Contains, value);
			// 	// oTable.filter(filterNo);
		},
		/* To select the range of date*/
		onDateSearch: function(oEvent) {
			var table = this.byId("uTableId").getBinding("items");
			var fromDate = oEvent.getParameter("from");
			// console.log(fromDate);
			var toDate = oEvent.getParameter("to");
			// console.log(toDate);
			var filterDate = new sap.ui.model.Filter("Joiningdate", sap.ui.model.FilterOperator.BT, fromDate, toDate);
			table.filter(filterDate);
		},
		/* To select the location in combo box*/
		onSelectLocation: function(oEvent) {
			var value = oEvent.getSource().getSelectedItem().getText();
			this.getView().getModel("FilterModel").setProperty("/Location", value);

			// 	// 	// var oTable = this.byId("uTableId").getBinding("items");
			// 	// 	// var filterNo = new sap.ui.model.Filter("Location", sap.ui.model.FilterOperator.Contains, value);
			// 	// 	// oTable.filter(filterNo);

		},
		/*to search all the selected drop downs through table*/
		onPressSearch: function(oEvent) {

			var oTable = this.byId("uTableId").getBinding("items");

			// var getName = oEvent.getSource.getName();
			var filters = [];
			var selectedSalesDocNo = oEvent.getSource().getModel("FilterModel").getProperty("/Location");
			if (selectedSalesDocNo) {
				filters.push(new sap.ui.model.Filter("Location", sap.ui.model.FilterOperator.EQ, selectedSalesDocNo));
			}
			var selectedCreatedBy = oEvent.getSource().getModel("FilterModel").getProperty("/Designation");
			if (selectedCreatedBy) {
				filters.push(new sap.ui.model.Filter("Designation", sap.ui.model.FilterOperator.EQ, selectedCreatedBy));
			}
			var selectedSalesOrg = oEvent.getSource().getModel("FilterModel").getProperty("/Department");
			if (selectedSalesOrg) {
				filters.push(new sap.ui.model.Filter("Department", sap.ui.model.FilterOperator.EQ, selectedSalesOrg));
			}
			var selectedNetwr = oEvent.getSource().getModel("FilterModel").getProperty("/Firstname");
			if (selectedNetwr) {
				filters.push(new sap.ui.model.Filter("Firstname", sap.ui.model.FilterOperator.Contains, selectedNetwr));
			}
			// var selecteddate = oEvent.getSource().getModel("FilterModel").getProperty("/Joiningdate");
			// if (selecteddate) {
			// 	filters.push(new sap.ui.model.Filter("Joiningdate", sap.ui.model.FilterOperator.EQ, selectedNetwr));
			// }
			oTable.filter(filters);

		},
		/*To search a particular department in Department fragment*/
		onSearchDept: function(oEvent) {
			var that = this;
			var value = oEvent.getSource().getValue();
			// console.log(value
			var list = that.getView().byId("List").getBinding("items");
			var FilterDP = new sap.ui.model.Filter("Description", sap.ui.model.FilterOperator.Contains, value);
			list.filter(FilterDP);
		},
		/*TO refresh the Drop down boxes*/
		OnRefresh: function() {
			var Model = new JSONModel({
				Firstname: "",
				Designation: "",
				Location: "",
				Department: "",
				Joiningdate: ""

			});
			this.getView().setModel(Model, "FilterModel");
			this.oDataModel();
		},
		frontPress: function() {
			history.go(+1);
		}

	});
});