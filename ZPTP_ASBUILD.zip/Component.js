jQuery.sap.declare("AsBuildMBOM.Component");
sap.ui.getCore().loadLibrary("sap.ui.generic.app");
jQuery.sap.require("sap.ui.generic.app.AppComponent");

sap.ui.generic.app.AppComponent.extend("AsBuildMBOM.Component", {
	metadata: {
		"manifest": "json"
	}
});