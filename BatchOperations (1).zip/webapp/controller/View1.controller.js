sap.ui.define([
	"sap/ui/core/mvc/Controller",
	"sap/ui/model/json/JSONModel",
	"sap/ui/model/Filter",
	"sap/ui/model/FilterOperator",
	"sap/ui/core/util/Export",
	"sap/ui/core/util/ExportTypeCSV",
	"sap/m/MessageBox"
], function(Controller, JSONModel, Filter, FilterOperator, Export, ExportTypeCSV, MessageBox) {
	"use strict";

	return Controller.extend("BatchOperationsBatchOperations.controller.View1", {
		onInit: function() {
			var that = this;
			var data = {
				"Carriers": [{
					"Employeeid": "",
					"Empfirstname": "",
					"Department": "",
					"Designation": ""
				}]
			};
			var oModel = new sap.ui.model.json.JSONModel();
			oModel.setData(data);
			this.getView().setModel(oModel, "jTabModel");

			var FModel = new JSONModel();
			that.getView().setModel(FModel, "FormModel");
			var uModel = new JSONModel();
			that.getView().setModel(uModel, "updateModel");
			var FilterModel = new JSONModel({
				EmpId: "",
				EmpName: "",
				EmpDept: ""
			});
			that.getView().setModel(FilterModel, "FilterModel");

			 this.tableRead();
			var oModel1 = new JSONModel();
			oModel1.setData({
				skip: 0,
				top: 5
			});
			that.getView().setModel(oModel1, "oModel");
			// that.readTable();
		},
		readTable: function() {
			var that = this;
			var oModel = that.getView().getModel("oModel");
			var skip = oModel.getProperty("/skip");
			var top = oModel.getProperty("/top");
			var url = "/sap/opu/odata/sap/ZHR_EMPDETAILS_SRV/";
			var oDataModel = new sap.ui.model.odata.ODataModel(url, true);
			oDataModel.read("/EmpdataSet", {
				urlParameters: {
					"$top": top,
					"$skip": skip
				},
				success: function(data, res) {
					if (res.statusCode === "200" || res.statusCode === 200) {
						var oJsonModel = new sap.ui.model.json.JSONModel(data);
						that.getView().setModel(oJsonModel, "tableModel");
					}
				},
				error: function(error) {

				}
			});
		},
		onPrev: function() {
			var that = this;
			var oModel = that.getView().getModel("oModel");
			var skip = oModel.getProperty("/skip");
			var top = oModel.getProperty("/top");
			oModel.setProperty("/skip", skip - top);
			that.readTable();

		},
		onNext: function() {
				var that = this;
				var oModel = that.getView().getModel("oModel");
				var skip = oModel.getProperty("/skip");
				var top = oModel.getProperty("/top");
				// if (skip < top) {
				oModel.setProperty("/skip", skip + top);
				// this._updateTableItems();
				// }
				that.readTable();
			},
		onAddRow: function() {
			var oTable = this.getView().byId("batchTable");
			this.oTableModel = oTable.getModel("jTabModel").getProperty("/Carriers");
			var oNewRow = {
				"Employeeid": "",
				"Empfirstname": "",
				"Department": "",
				"Designation": ""
			};
			this.oTableModel.push(oNewRow);
			oTable.getModel("jTabModel").setProperty("/Carriers", this.oTableModel);
		},
		onBatchSave: function() {
			var that = this;
			var addedProdCodeModel = that.getView().getModel("jTabModel").getData();
			var oDataModel = that.getOwnerComponent().getModel();
			// oDataModel.setUseBatch(true);
			oDataModel.setDeferredGroups(["batchCreate"]);
			var mParameters = {
				batchGroupId: "batchCreate"
			};

			for (var i = 0; i < addedProdCodeModel.Carriers.length; i++) {
				var addRow = addedProdCodeModel.Carriers[i];
				oDataModel.create("/EmpdataSet", addRow, mParameters);
			}

			oDataModel.submitChanges({
				batchGroupId: "batchCreate",
				success: function(data, res) {
					if (res.statusCode === "202" || res.statusCode === 202) {
						sap.m.MessageBox.success("Recorde Created Successfully");
						this.tableRead();
					}
				}.bind(this),
				error: function(e) {
					sap.m.MessageBox.success("failed");
				}
			});
		},
		tableRead: function() {
			var that = this;
			var oModel = new JSONModel({
				tabbleItems: ""
			});
			that.getView().setModel(oModel, "tableModel");
			var oDataModel = that.getOwnerComponent().getModel();
			oDataModel.read("/EmpdataSet", {
				success: function(data, res) {
					if (res.statusCode === "200" || res.statusCode === 200) {
						oModel.setData({
							EmpdataSet: data.results
						});
					}
				},
				error: function(error) {
					// var errorMsg = JSON.parse(error.responseText).error.message;
				}
			});
		},
		OpenCreateFrag: function() {
			if (!this.Dialog1) {
				this.Dialog1 = sap.ui.xmlfragment("BatchOperationsBatchOperations.view.create", this);
				this.getView().addDependent(this.Dialog1);
			}
			this.Dialog1.open();
		},
		onCancel: function() {
			this.Dialog1.close();
		},
		openUpdateFrag: function() {
			// var that = this;
			this.array = [];
			if (!this.oDialog) {
				this.oDialog = sap.ui.xmlfragment("BatchOperationsBatchOperations.view.editbatch", this);
				this.getView().addDependent(this.oDialog);
			}
			this.oDialog.open();
			var selectedItem = this.getView().byId("table").getSelectedItems();
			for (var i = 0; i <= selectedItem.length - 1; i++) {
				var item = selectedItem[i];
				this.array.push(item.getBindingContext("tableModel").getObject());
			}
			var updateModel = new JSONModel(this.array);
			this.getView().setModel(updateModel, "updateModel");
		},
		onCancel1: function() {
			this.oDialog.close();
		},
		onSaveMulti: function() {
			var that = this;
			var addedProdCodeModel = that.getView().getModel("updateModel").getData();
			var oDataModel = that.getOwnerComponent().getModel();
			oDataModel.setUseBatch(true);
			// oDataModel
			oDataModel.setDeferredGroups(["batchUpdate"]);
			var mParameters = {
				groupId: "batchUpdate"
			};
			for (var i = 0; i < addedProdCodeModel.length; i++) {
				var addRow = addedProdCodeModel[i];
				var mParameters1 = {
					changeSetId: i
				};
				oDataModel.update("/EmpdataSet('" + addRow.Employeeid + "')", addRow, mParameters, mParameters1);
			}
			oDataModel.submitChanges({
				groupId: "batchUpdate",
				changeSetId: i,
				success: function(data, res) {
					if (res.statusCode === "202" || res.statusCode === 202) {
						sap.m.MessageBox.success("Recorde Updated Successfully");
						that.tableRead();
						// that.getView().byId("table").updateBindings();      
					}
				}.bind(this),
				error: function(e) {
					sap.m.MessageBox.success("failed");
				}
			});

			this.oDialog.close();
		},
		MultiDelete: function() {
			var that = this;
			var oTable = that.getView().byId("batchTable");
			var oModel = that.getOwnerComponent().getModel();
			oModel.setUseBatch(true);
			oModel.setDeferredGroups(["batchDelete"]);
			var mParameters = {
				batchGroupId: "batchDelete"
			};
			var jModel = that.getView().byId("table").getSelectedItems();
			for (var i = 0; i < jModel.length; i++) {
				var oEntry = jModel[i].getBindingContext("tableModel").getObject();
				oModel.remove("/EmpdataSet('" + oEntry.Employeeid + "')", mParameters);
			}
			oModel.submitChanges({
				batchGroupId: "batchDelete",
				success: function(data, res) {
					if (res.statusCode === "202" || res.statusCode === 202) {
						sap.m.MessageBox.success("Recorde Deleted Successfully");
						this.tableRead();
					}
				}.bind(this),
				error: function(e) {
					sap.m.MessageBox.success("failed");
				}
			});

		},
		onCreate: function(oEvent) {
			var that = this;
			that.tableRead();
			var FormData = that.getView().getModel("FormModel").getData();
			var Id = that.getView().getModel("FormModel").getData().Employeeid;
			var empName = that.getView().getModel("FormModel").getData().Empfirstname;
			var empDept = that.getView().getModel("FormModel").getData().Department;
			if (Id === undefined || empName === undefined || empDept === undefined) {
				sap.m.MessageBox.warning("Please Fill The Manfotory Records");
			} else {
				var FormData1 = that.getView().getModel("FormModel").getData();
				var cDataModel = that.getOwnerComponent().getModel();
				cDataModel.create("/EmpdataSet", FormData1, {
					success: function(data, res) {
						if (res.statusCode === "201" || res.statusCode === 201) {
							sap.m.MessageBox.success("Recorde Created Successfully");
							// that.getView().getModel("tableModel").refresh();
							that.Dialog1.close();
							that.tableRead();
							that.getView().getModel("FormModel").refresh();
						}
					},
					error: function(error) {
						var errorMsg = JSON.parse(error.responseText).error.message;
					}
				});
				this.Dialog.close();
				// this.refresh();
			}
		},
		onSave: function() {
			var that = this;
			that.tableRead();
			var oTable = that.getView().byId("table");
			var selectedRow = oTable.getSelectedContexts();
			if (selectedRow === 0) {
				sap.m.MessageBox.warning("Select Please One Record");
			} else {
				var formdata = that.getView().getModel("updateModel").getData();
				var odata = this.getOwnerComponent().getModel();
				odata.update("/EmpdataSet('" + formdata.Employeeid + "')", formdata, {
					success: function(data, res) {
						if (res.statusCode === "204" || res.statusCode === 204) {
							sap.m.MessageBox.success("Recorde Updated Successfully");
						}
					},
					error: function() {}
				});
				this.Dialog1.close();
				// this.refresh();
			}
		},
		SingleDelete: function(oEvent) {
			var that = this;
			var oTable = that.getView().byId("table");
			var selectedRow = oTable.getSelectedContexts();
			if (selectedRow.length >= 2) {
				sap.m.MessageBox.warning("Select Please One Record");
			} else {

				var RecordData = that.getView().byId("table").getSelectedItem().getBindingContext("tableModel").getObject();
				var odata = this.getOwnerComponent().getModel();
				odata.remove("/EmpdataSet('" + RecordData.Employeeid + "')", {
					success: function(data, res) {
						if (res.statusCode === "204" || res.statusCode === 204) {
							sap.m.MessageBox.success("Record deleted successfully");
						}
						that.tableRead();
					},
					error: function() {

					}
				});
			}

		},
		puzysearch: function(oEvent) {
			var that = this;
			var Value = oEvent.getSource().getValue();
			var oTable = that.getView().byId("table").getBinding("items");
			var empId = new sap.ui.model.Filter("Employeeid", FilterOperator.Contains, Value);
			var empName = new sap.ui.model.Filter("Empfirstname", FilterOperator.Contains, Value);
			var middleName = new sap.ui.model.Filter("Empmidname", FilterOperator.Contains, Value);
			var lastName = new sap.ui.model.Filter("Emplastname", FilterOperator.Contains, Value);
			var dept = new sap.ui.model.Filter("Department", FilterOperator.Contains, Value);
			var desig = new sap.ui.model.Filter("Designation", FilterOperator.Contains, Value);
			var grade = new sap.ui.model.Filter("Grade", FilterOperator.Contains, Value);
			var filterArray = [empId, empName, middleName, lastName, dept, desig, grade];
			var tableItems = new sap.ui.model.Filter(filterArray, false);
			oTable.filter(tableItems);
		},
		onUpdateFinished: function() {
			var that = this;
			var tablelength = that.getView().byId("table").getItems().length;
			that.getView().getModel("tableModel").setProperty("/tabbleItems", tablelength);
		},
		EmployeeId: function(oEvent) {
			var idvalue = oEvent.getSource().getValue();
			this.getView().getModel("FilterModel").setProperty("/EmpId", idvalue);
		},
		Firstneme: function(oEvent) {
			var FirstName = oEvent.getSource().getValue();
			this.getView().getModel("FilterModel").setProperty("/EmpName", FirstName);
		},
		Department: function(oEvent) {
			var Dept = oEvent.getSource().getValue();
			this.getView().getModel("FilterModel").setProperty("/EmpDept", Dept);
		},
		GoSearch: function() {
			var that = this;
			var items = that.getView().byId("table").getBinding("items");
			var oFilter = [];
			var Input1 = that.getView().getModel("FilterModel").getProperty("/EmpId");
			var Input2 = that.getView().getModel("FilterModel").getProperty("/EmpName");
			var Input3 = that.getView().getModel("FilterModel").getProperty("/EmpDept");

			if (Input1.length > 0) {
				oFilter.push(new Filter("Employeeid", FilterOperator.EQ, Input1));
			}
			if (Input2.length > 0) {
				oFilter.push(new Filter("Empfirstname", FilterOperator.Contains, Input2));
			}
			if (Input3.length > 0) {
				oFilter.push(new Filter("Department", FilterOperator.EQ, Input3));
			}
			var newfilter = new Filter({
				filters: oFilter,
				and: true
			});
			items.filter(newfilter);
		},
		Refresh: function() {
			var that = this;
			that.tableRead();
		},
		ExportTypeCsv: function() {
			var arr = [];
			// var items = this.getView().byId("table").getBinding("items");
			var data = this.getView().byId("table").getItems();
			data.forEach(function(item) {
				if (item.getVisible()) {
					var context = item.getBindingContext("tableModel");
					var dattss = context.getProperty();
					arr.push(dattss);
				}
			});
			var exportmodel = new JSONModel(
				arr
			);
			this.getView().setModel(exportmodel, "exportmodel");
			// console.log(arr);
			var oExport = new Export({

				// Type that will be used to generate the content. Own ExportType's can be created to support other formats
				exportType: new ExportTypeCSV({
					separator: "Column"
				}),

				// Pass in the model created above
				models: this.getView().getModel("exportmodel"),

				// binding information for the rows aggregation
				rows: {
					path: "/"
				},

				// column definitions with column name and binding info for the content

				columns: [{
					name: "Employee ID",
					template: {
						content: "{Employeeid}"
					}
				}, {
					name: "First Name",
					template: {
						content: "{Empfirstname}"
					}
				}, {
					name: "Middle Name",
					template: {
						content: "{Empmidname}"
					}
				}, {
					name: "Last Name",
					template: {
						content: "{Emplastname}"
					}
				}, {
					name: "Department",
					template: {
						content: "{Department}"
					}
				}, {
					name: "Designation",
					template: {
						content: "{Designation}"
					}
				}, {
					name: "Grade",
					template: {
						content: "{Grade}"
					}

				}]
			});

			// download exported file
			oExport.saveFile("EmployeeDetails").catch(function(oError) {
				// MessageBox.error("Error when downloading data. Browser might not be supported!\n\n" + oError);
			}).then(function() {
				oExport.destroy();
			});
		},
		onExportPDF: function() {
			var that = this;
			if (document.getElementById("signature-pad") !== null) {
				this.getView().byId("signImage").setVisible(true);
				this.getView().byId("signImage").setSrc(document.getElementById("signature-pad").toDataURL());
				document.getElementById("signature-pad").style.display = "none";
			}
			setTimeout(function() {
				that.myprintFunction();
			}, 1000);
		},
		myprintFunction: function() {
			var oDesktopDevice = sap.ui.Device.system.desktop;

			var bodyContent = "";

			var closeContent = "";
			var htmlpage = "";

			if (oDesktopDevice === true) {

				var win = window.open("PrintWindow", "");
				// this.getView().byId("Signature").setVisible(false);
				bodyContent = $(".printClass1").html();
				closeContent = "</body></html>";
				htmlpage = bodyContent + closeContent;
				win.document.write(htmlpage);
				var cssLinks = "";
				$.each(document.styleSheets, function(index, oStyleSheet) {
					if (oStyleSheet.href) {
						var link = document.createElement("link");
						link.type = oStyleSheet.type;
						link.rel = "stylesheet";
						link.href = oStyleSheet.href;
						win.document.head.appendChild(link);
					}
				});
				setTimeout(function() {
					win.print();
					win.stop();
				}, 1000);

			} else {

				cssLinks = "";
				$.each(document.styleSheets, function(index, oStyleSheet) {
					if (oStyleSheet.href) {
						var link = document.createElement("link");
						link.type = oStyleSheet.type;
						link.rel = "stylesheet";
						link.href = oStyleSheet.href;
						cssLinks = cssLinks + "<link rel='stylesheet' type='text/css' href=" + oStyleSheet.href + ">";
					}
				});

				var hContent1 = "<html><head>" + cssLinks + "</head><body class='sapUiSizeCompact'>";
				var bodyContent1 = $(".page").html();
				var closeContent1 = "</body></html>";
				var htmlpage1 = hContent1 + bodyContent1 + closeContent1;

				cordova.plugins.printer.print(htmlpage1, {
					duplex: 'long'
				}, function() {

				});

			}
		}
	});
});