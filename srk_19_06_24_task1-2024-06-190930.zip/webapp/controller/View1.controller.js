sap.ui.define([
    "sap/ui/core/mvc/Controller",
    "sap/ui/model/json/JSONModel",
    'jquery.sap.global',
    'sap/m/TablePersoController',
    '../model/perso',
    "sap/ui/export/Spreadsheet",
],
    function (Controller, JSONModel, jQuery, TablePersoController, perso, Spreadsheet) {
        "use strict";

      

        return Controller.extend("jsoncrudtask.controller.View1", {
            onInit: function () {
                var that = this;
                var oEmpModel = new JSONModel("/model/data.json");

                that.getView().setModel(oEmpModel, "empData");

               

                // $.ajax({
                //     url: "/model/data.json", 
                //     dataType: "json",
                //     success: function(data) {

                //         l = data

                //         var oLengthModel = new JSONModel({
                //             "len" : data.length
                //         })
                //         that.getView().setModel(oLengthModel, "lengthModel")
        


                //         var oEmpModel = new JSONModel(data);
                //         that.getView().setModel(oEmpModel, "empData");
                //     },
                //     error: function(error) {
                //         console.error("Error fetching data", error);
                //     }
                // });

                
            },

            onEdit: function (oEvent) {
                var that = this;
                var oContext = oEvent.getSource().getBindingContext("empData");
                var sPath = oContext.getPath();


                var oModel = that.getView().getModel("empData");
                var oData = oModel.getProperty(sPath);



                if (oData.editButton === "Edit") {
                    oData.text = false;
                    oData.input = true;
                    oData.editButton = "Save";
                    oData.deleteButton = "CANCEL";

                    var empData = that.getView().getModel("empData").getData();
                    var data = []
                    for (var i of empData) {
                        if (i.Id === oData.Id) {
                            data.push(oData)
                        }
                        else {
                            data.push(i)
                        }
                    }
                    that.getView().getModel("empData").setData(data);
                }
                else if (oData.editButton === "Save") {
                    oData.editButton = "Edit"
                    oData.text = true;
                    oData.input = false;
                    oData.deleteButton = "DELETE";

                    var empData = that.getView().getModel("empData").getData();
                    var data = []
                    for (var i of empData) {
                        if (i.Id === oData.Id) {
                            data.push(oData)
                        }
                        else {
                            data.push(i)
                        }

                    }
                    that.getView().getModel("empData").setData(data);
                }

            },



            onDelete: function (oEvent) {

                var that = this;
                var oContext = oEvent.getSource().getBindingContext("empData");
                var sPath = oContext.getPath();
                var oModel = that.getView().getModel("empData");
                var oData = oModel.getProperty(sPath);

                if (oData.deleteButton === "DELETE") {

                    var array = that.getView().getModel("empData").getData();
                    const indexToRemove = array.findIndex(obj => obj.Id === oData.Id);

                    if (indexToRemove !== -1) {
                        array.splice(indexToRemove, 1);
                    }
                    that.getView().getModel("empData").setData(array);

                    // that.getView().getModel("lengthModel").setProperty("/len", array.length);
                }

                else if (oData.deleteButton === "CANCEL"){
                    oData.text = true;
                    oData.input = false;
                    oData.deleteButton = "DELETE";
                    oData.editButton = "Edit"

                    var empData = that.getView().getModel("empData").getData();
                    var data = JSON.parse(JSON.stringify(empData));
                   
                    that.getView().getModel("empData").setData(data)
                }
            },

            onRefresh: function(){
                var that = this;
                var oEmpModel = new JSONModel("/model/data.json");

                that.getView().setModel(oEmpModel, "empData");

             
            },

            onPerso: function(){
                var that = this;
                that._oTPC = new TablePersoController({
                    table: that.getView().byId("tabledata"),
                    componentName: "demoApp",
                    persoService: perso
                }).activate();

                var that = this
                that._oTPC.openDialog();
            },

            createColumnConfig: function () {
                return [
                    { property: 'Id', type: 'string' },
                    { property: 'Name', type: 'string' },
                    { property: 'Location', type: 'string' },
                    { property: 'Designation', type: 'string' },
                    { property: 'JoiningDate', type: 'date' }
                ];
            },
            
            onExport: function () {
                var that = this;
                var TableData = that.getView().byId("tabledata");
                var TableItems = TableData.getItems();
            
                if (TableItems.length > 0) {
                    var aCols = that.createColumnConfig();
                    var Collectionrecord = that.getView().getModel("empData").getData();
                    var csvContent = that.convertToCSV(Collectionrecord, aCols);
                    var blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
                    var link = document.createElement("a");
                    if (link.download !== undefined) { 
                        var url = URL.createObjectURL(blob);
                        link.setAttribute("href", url);
                        link.setAttribute("download", "emp_data.csv");
                        link.style.visibility = 'hidden';
                        document.body.appendChild(link);
                        link.click();
                        document.body.removeChild(link);
                    }
                }
            },
            
            convertToCSV: function (data, columns) {
                var csv = [];
                var headers = columns.map(function(col) {
                    return col.property;
                });
                csv.push(headers.join(","));
            
                data.forEach(function(record) {
                    var row = [];
                    headers.forEach(function(header) {
                        var column = columns.find(col => col.property === header);
                        var value = record[header];
                        if (column.type === 'date') {

                            var date = new Date(value);
                            if (!isNaN(date.getTime())){
                                var formatted = date.toLocaleDateString();
                                var datelist = formatted.split("/")
                                var changedList = [datelist[1], datelist[0], datelist[2]]
                                var convertedDate = changedList.join('/')
                            
                                value = convertedDate
                            }
                            else{
                                value = date
                            }
                            
                        }
                        row.push(value);
                    }, this); 
                    csv.push(row.join(","));
                }, this);
            
                return csv.join("\n");
            },
            
            onExit:function(){
                var that = this;
                that._oTPC.destroy();
            }
            
        });
    });
