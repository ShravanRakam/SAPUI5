sap.ui.define([
	"sap/ui/core/mvc/Controller",
	"sap/ui/model/json/JSONModel",
	"sap/ui/core/format/DateFormat",
	"../model/formatter",
	"sap/ui/model/Filter",
	"sap/ui/model/FilterOperator",
	"sap/ui/model/Sorter",
	"sap/m/TablePersoController",
	"jquery.sap.global",
	"../model/Basicperso",
	"../model/shippingperso",
	"../model/whpersoservice",
	"../model/accountperso",
	"../model/allpersoservice",
	"sap/ui/export/Spreadsheet"
], function(Controller, JSONModel, DateFormat, formatter, Filter, FilterOperator, Sorter,
	TablePersoController, jquery, Basicperso, shippingperso, whpersoservice, accountperso,
	allpersoservice, Spreadsheet) {
	"use strict";

	return Controller.extend("Sreeram_DSreeram_D.controller.View1", {
		formatter: formatter,
		onInit: function() {
			this.buttonRefresh();
			this.tablePersonalization();
			var oModel1 = new JSONModel({
				"ComboResult": [{
					"materialType": "Z01-Std. Stock Materials",
					"materialTypeDesc": "Std. Stock Materials",
					"materialGroup": "Z10304-Therapeutic food",
					"materialGroupDesc": "Therapeutic food"
				}, {
					"materialType": "Z02-Kits",
					"materialTypeDesc": "Kits",
					"materialGroup": "Z0050202-Syringe/Safety",
					"materialGroupDesc": "Syringe/Safety"
				}, {
					"materialType": "Z07-Std Non Stock Materials",
					"materialTypeDesc": "Std Non Stock Materials",
					"materialGroup": "Z0020610-Beta Lactams",
					"materialGroupDesc": "Beta Lactams"
				}, {
					"materialType": "Z12-Miscellaneous Material",
					"materialTypeDesc": "Miscellaneous Material",
					"materialGroup": "Z00210-Antianaemias",
					"materialGroupDesc": "Antianaemias"
				}],
				MatType: [],
				MatGroup: [],
				Matnumber: "",
				matDescrp: ""
			});
			this.getView().setModel(oModel1, "MultiComboModel");

			this.getView().setModel(new sap.ui.model.json.JSONModel({
				dateTime: this._formatDate()
			}));
			setInterval(function() {
				this.getView().getModel().setProperty("/dateTime", this._formatDate());
			}.bind(this), 1000);

		},
		tablePersonalization: function() {
			var that = this;

			that.matTable = new TablePersoController({
				table: that.getView().byId("Table"),

				componentName: "demo",
				persoService: Basicperso
			}).activate();

			that.matTable2 = new TablePersoController({
				table: that.getView().byId("shipTable"),

				componentName: "shippingTableComp",
				persoService: shippingperso
			}).activate();

			that.matTable3 = new TablePersoController({
				table: that.getView().byId("WHTable"),

				componentName: "whTableComp",
				persoService: whpersoservice
			}).activate();
			that.matTable4 = new TablePersoController({
				table: that.getView().byId("AccountTable"),

				componentName: "AcountTableComp",
				persoService: accountperso
			}).activate();
			that.matTable5 = new TablePersoController({
				table: that.getView().byId("AllTable"),

				componentName: "AllTableComp",
				persoService: allpersoservice
			}).activate();

		},
		onPersoButtonPressed: function() {
			var that = this;
			var oSelectedKey = that.byId("iconTab").getSelectedKey();
			if (oSelectedKey === "Basic List") {
				that.matTable.openDialog();
			} else if (oSelectedKey === "Shopping Info") {
				that.matTable2.openDialog();
			} else if (oSelectedKey === "WH_MRP Inf") {
				that.matTable3.openDialog();
			} else if (oSelectedKey === "Accounting") {
				that.matTable4.openDialog();
			} else {
				that.matTable5.openDialog();
			}
		},
		buttonRefresh: function() {
			var oModel = new JSONModel("model/Data.json");
			this.getView().setModel(oModel, "TableModel");
			var sPath = $.sap.getModulePath("Sreeram_DSreeram_D", "/model/Data.json");
		},
		_formatDate: function() {
			var date = new Date();
			var dateFormat = sap.ui.core.format.DateFormat.getDateInstance({
				pattern: "EEEE, MMMM dd, YYYY hh:mm:ss a"
			});
			var dateFormatted = dateFormat.format(date);
			return dateFormatted;
		},
		onTabPress: function(oEvent) {
			var source = oEvent.getParameter("key");
			var col = this.byId("Table").getColumns();
			// if (source === "Shopping Info") {
			// 	this.byId("Column1").setVisible(true);
			// 	this.byId("Column2").setVisible(true);
			// 	this.byId("Column3").setVisible(false);
			// 	this.byId("Column4").setVisible(false);
			// 	this.byId("Column5").setVisible(false);
			// 	this.byId("Column6").setVisible(false);
			// 	this.byId("Column7").setVisible(false);
			// 	this.byId("Column8").setVisible(false);
			// 	this.byId("Column9").setVisible(false);
			// 	this.byId("Column10").setVisible(false);
			// 	this.byId("Column11").setVisible(true);
			// 	this.byId("Column12").setVisible(true);
			// 	this.byId("Column13").setVisible(true);
			// 	this.byId("Column14").setVisible(true);
			// 	this.byId("Column15").setVisible(true);
			// 	this.byId("Column16").setVisible(true);
			// 	this.byId("Column17").setVisible(true);
			// 	this.byId("Column18").setVisible(false);
			// 	this.byId("Column19").setVisible(false);
			// 	this.byId("Column20").setVisible(false);
			// 	this.byId("Column21").setVisible(false);
			// 	this.byId("Column22").setVisible(false);
			// 	this.byId("Column23").setVisible(false);
			// 	this.byId("Column24").setVisible(false);
			// 	this.byId("Column25").setVisible(false);
			// 	this.byId("Column26").setVisible(false);
			// 	this.byId("Column27").setVisible(false);
			// 	this.byId("Column28").setVisible(false);
			// 	this.byId("Column29").setVisible(false);
			// 	this.byId("Column30").setVisible(false);
			// } else if (source === 'Basic List') {

			// 	var oTable = this.getView().byId("Table");
			// 	var aColumns = oTable.getColumns();
			// 	for (var i = 1; i < aColumns.length; i++) {
			// 		aColumns[i].setVisible(true);
			// 	}
			// } else if (source === 'WH_MRP Info') {
			// 	var oTable1 = this.getView().byId("Table");
			// 	var aColumns1 = oTable1.getColumns();
			// 	for (var k = 17; k < 24; k++) {
			// 		for (var j = 2; j < 17; j++) {
			// 			for (var l = 24; l < 30; l++) {
			// 				aColumns1[l].setVisible(false);
			// 			}
			// 			aColumns1[j].setVisible(false);
			// 		}
			// 		aColumns1[k].setVisible(true);
			// 	}
			// } else if (source === 'Accounting') {

			// 	var oTable2 = this.getView().byId("Table");
			// 	var aColumns2 = oTable2.getColumns();
			// 	for (var a = 24; a < 30; a++) {
			// 		for (var b = 2; b < 24; b++) {
			// 			aColumns2[b].setVisible(false);
			// 		}
			// 		aColumns2[a].setVisible(true);
			// 	}
			// 	this.byId("Column6").setVisible(true);
			// 	this.byId("Column7").setVisible(true);
			// } else if (source === 'ALL') {
			// 	var oTable3 = this.getView().byId("Table");
			// 	var aColumns3 = oTable3.getColumns();
			// 	for (var d = 2; d < 11; d++) {
			// 		for (var e = 10; e < 29; e++) {
			// 			aColumns3[e].setVisible(false);
			// 		}
			// 		aColumns3[d].setVisible(true);
			// 	}
			// }
		},
		materialType: function(oEvent) {
			var that = this;
			var source = oEvent.getSource().getSelectedItems();
			that.getView().getModel("MultiComboModel").setProperty("/MatType", source);
		},
		materialGroup: function(oEvent) {
			var that = this;
			var source = oEvent.getSource().getSelectedItems();
			that.getView().getModel("MultiComboModel").setProperty("/MatGroup", source);
		},
		onSubmit: function(oEvent) {
			var that = this;
			var selInp = oEvent.getSource().getValue();
			that.getView().getModel("MultiComboModel").setProperty("/Matnumber", selInp);
		},
		materialDesc: function(oEvent) {
			var that = this;
			var selInput = oEvent.getSource().getValue();
			that.getView().getModel("MultiComboModel").setProperty("/matDescrp", selInput);
		},
		onSearch: function(oEvent) {
			// var that = this;
			var oBinding = this.getView().byId("Table").getBinding("items"),
				oFinalFilter = [],
				aFiltersType = [],
				aFiltersReg = [],
				oInput = [],
				amatDescription = [],
				// typeBox = this.byId("id5").getSelectedItems(),
				typeBox = this.getView().getModel("MultiComboModel").getProperty("/MatType"),
				// comboBoxRegionExp = this.byId("id3").getSelectedItems(),
				comboBoxRegionExp = this.getView().getModel("MultiComboModel").getProperty("/MatGroup"),
				// inp = this.byId("id1").getValue();
				inp = this.getView().getModel("MultiComboModel").getProperty("/Matnumber"),
				inpdec = this.getView().getModel("MultiComboModel").getProperty("/matDescrp");

			if (!typeBox.length > 0 && !comboBoxRegionExp.length > 0 && !inp.length > 0 && !inpdec.length > 0) {
				oBinding.filter([]);
			} else {
				for (var i = 0; i < typeBox.length; i++) {
					aFiltersType.push(new Filter({
						path: "materialType",
						operator: sap.ui.model.FilterOperator.EQ,
						value1: typeBox[i].getText()
							// typeBox[i].getText()
					}));
				}
				for (var j = 0; j < comboBoxRegionExp.length; j++) {
					aFiltersReg.push(new Filter({
						path: "materialGroup",
						operator: sap.ui.model.FilterOperator.EQ,
						value1: comboBoxRegionExp[j].getText()
							// comboBoxRegionExp[j].getText()
					}));
				}
				oInput.push(new Filter({
					path: "materialCode",
					operator: sap.ui.model.FilterOperator.EQ,
					value1: inp
				}));
				amatDescription.push(new Filter({
					path: "materialCodeDesc",
					operator: sap.ui.model.FilterOperator.EQ,
					value1: inpdec
				}));
				oFinalFilter.push(new sap.ui.model.Filter({
					and: false,
					filters: [
						new sap.ui.model.Filter({
							and: false,
							filters: aFiltersType
						}),
						new sap.ui.model.Filter({
							and: false,
							filters: aFiltersReg
						}),
						new sap.ui.model.Filter({
							and: false,
							filters: oInput
						}), new sap.ui.model.Filter({
							and: false,
							filters: amatDescription
						})
					]
				}));
				oBinding.filter(oFinalFilter);
			}

		},
		OnRefresh: function() {
			this.getView().byId("id1").setValue(null);
			this.getView().byId("id4").setValue(null);
			var array = [this.getView().byId("id6"), this.getView().byId("id5"), this.getView().byId("id2"), this.getView().byId("id3")];
			array.forEach(function(item) {
				for (var j = item.getSelectedItems().length; j >= 0; j--) {
					item.removeSelectedItem(item.getSelectedItems()[j]);
				}
			});

		},
		createColumnConfig: function() {
			var that = this;
			var cols;
			var oSelectedKey = that.byId("iconTab").getSelectedKey();
			if (oSelectedKey === "Basic List") {
				cols = that.matTable.aCols;
			} else if (oSelectedKey === "Shopping Info") {
				cols = that.matTable2.aCols;
			} else if (oSelectedKey === "WH_MRP Inf") {
				cols = that.matTable3.aCols;
			} else if (oSelectedKey === "Accounting") {
				cols = that.matTable4.aCols;
			} else {
				cols = that.matTable5.aCols;
			}
			var aCols = [];

			aCols.push({
				label: 'Material No',
				property: ['materialCode']

			});

			aCols.push({
				label: 'Material Description',
				property: 'materialCodeDesc'

			});

			aCols.push({
				label: 'UOM',
				property: 'unitOfMeasure'

			});
			aCols.push({
				label: 'Material Type',
				property: 'materialType'

			});

			aCols.push({
				label: 'Item Categirory Group',
				property: 'itemCategoryGrp'

			});

			aCols.push({
				label: 'standared Price',
				property: 'standardPrice'

			});

			aCols.push({
				label: 'MAP',
				property: 'map'

			});
			aCols.push({
				label: 'Creation Data',
				property: 'creationDate'

			});
			aCols.push({
				label: 'Materisl Status',
				property: ['matStatusXDist','matStatusXDistDesc']

			});
			aCols.push({
				label: 'Material Group',
				property: 'materialGroup'

			});
			aCols.push({
				label: 'Gross Weight',
				property: 'grossWeight'

			});
			aCols.push({
				label: 'Weight Unit',
				property: 'weightUnit'

			});
			aCols.push({
				label: 'Volume',
				property: 'volume'

			});
			aCols.push({
				label: 'Volume Unit',
				property: 'volumeUnit'

			});
			aCols.push({
				label: 'ESL Material',
				property: 'EslMaterial'

			});
			aCols.push({
				label: 'Temp Condition',
				property: ['tempCondition','tempConditionDesc']

			});
			aCols.push({
				label: 'DG Code Desc',
				property: 'Dob'

			});
			aCols.push({
				label: 'Batch',
				property: 'batch'

			});
			aCols.push({
				label: 'FO Batch Requred',
				property: 'foBatch'

			});
			aCols.push({
				label: 'Class',
				property: 'Class'

			});
			aCols.push({
				label: 'MRP Type Description',
				property: 'mrpTypeDesc'

			});
			aCols.push({
				label: 'mrpProfile-mrpProfileDesc',
				property: 'Dob'

			});
			aCols.push({
				label: 'mrpController-mrpControllerDesc',
				property: 'Dob'

			});
			aCols.push({
				label: 'Safety Stock',
				property: 'safetyStock'

			});
			aCols.push({
				label: 'Price Control Ind',
				property: 'Vprsv'

			});
			aCols.push({
				label: 'Commercial Price',
				property: 'commercialPrice'

			});
			aCols.push({
				label: 'Total Stock',
				property: 'totalStock-unitOfMeasure'

			});
			aCols.push({
				label: 'Overhead Group',
				property: 'Kosgr'

			});
			aCols.push({
				label: 'Total Value',
				property: 'totalValue'

			});
			aCols.push({
				label: 'Lead Time',
				property: 'leadTime'

			});

			return aCols;
		},
		OnExcel: function() {
					var that = this;
			var TableData = that.getView().byId("Table");
			var TableItems = TableData.getItems();
			if (TableItems.length > 0) {
				var aCols = that.createColumnConfig();
				var Collectionrecord = that.getView().getModel("TableModel").getData().results;

				var oSettings = {
					workbook: {
						columns: aCols,
						context: {
							sheetName: "Material Details List"
						}
					},
					dataSource: Collectionrecord,
					fileName: "Material Details List"
				};
				var oSheet = new Spreadsheet(oSettings);
				
				oSheet.build()
					.then(function() {

					})
					.finally(function() {
						oSheet.destory();
					});

			}

		}

	});
});