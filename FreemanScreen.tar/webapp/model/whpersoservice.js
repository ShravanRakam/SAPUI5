sap.ui.define(['jquery.sap.global'],
	function (jQuery) {
		"use strict";


		var whPersoService = {
			oData: {
				_persoSchemaVersion: "1.0",
				aColumns: [{
					id: "whTableComp-WHTable-whmatno",
					order: 0,
					text: "Material Number",
					visible: true
				}, {
					id: "whTableComp-WHTable-whmatdec",
					order: 1,
					text: "Material Description",
					visible: true
				}, {
					id: "whTableComp-WHTable-Column18",
					order: 2,
					text: "Batch",
					visible: true
				}, {
					id: "whTableComp-WHTable-Column19",
					order: 3,
					text: "FO Batch Required",
					visible: true
				}, {
					id: "whTableComp-WHTableWHTable-Column20",
					order: 4,
					text: "Class",
					visible: true
				}, {
					id: "whTableComp-WHTable-Column21",
					order: 5,
					text: "MRP Type & Description",
					visible: true
				}, {
					id: "whTableComp-WHTable-Column22",
					order: 6,
					text: "MRP Profile & Description",
					visible: true
				}, {
					id: "whTableComp-WHTable-Column23",
					order: 7,
					text: "MRP Ctrlr & Description",
					visible: true
				}, {
					id: "whTableComp-WHTable-Column24",
					order: 8,
					text: "Safety Stock",
					visible: true
				}]
			},
			getPersData: function () {
				var oDeferred = new jQuery.Deferred();
				if (!this._oBundle) {
					this._oBundle = this.Data;
				}
				var oBundle = this._oBundle;
				oDeferred.resolve(oBundle);
				return oDeferred.promise();
			},

			setPersData: function (oBundle) {
				var oDeferred = new jQuery.Deferred();
				this._oBundle = oBundle;
				oDeferred.resolve();
				return oDeferred.promise();
			},

			delPersData: function () {
				var oDeferred = new jQuery.Deferred();
				oDeferred.resolve();
				return oDeferred.promise();
			}
		};

		return whPersoService;

	}, true);