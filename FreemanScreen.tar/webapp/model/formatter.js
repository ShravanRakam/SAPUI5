sap.ui.define(function() {
	"use strict";

	return {

		dateFarmate: function(dateValue) {
			var FormatedDate;
			var oDay = dateValue.substring(0, 4);
			var oMonth = dateValue.substring(4, 6);
			var oYear = dateValue.substring(6, 8);
			FormatedDate = oDay + "." + oMonth + "." + oYear;
			return FormatedDate;
		}

	};

});