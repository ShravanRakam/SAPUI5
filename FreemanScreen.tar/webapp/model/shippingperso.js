sap.ui.define(['jquery.sap.global'],
	function (jQuery) {
		"use strict";
		
		var shippingPersoService = {
			oData: {
				_persoSchemaVersion: "1.0",
				aColumns: [{
					id: "shippingTableComp-shipTable-Column1",
					order: 0,
					text: "Material Number",
					visible: true
				}, {
					id: "shippingTableComp-shipTable-Column2",
					order: 1,
					text: "Material Description",
					visible: true
				}, {
					id: "shippingTableComp-shipTable-Column11",
					order: 2,
					text: "Gross Weight",
					visible: true
				}, {
					id: "shippingTableComp-shipTable-Column12",
					order: 3,
					text: "Weight Unit",
					visible: true
				}, {
					id: "shippingTableComp-shipTable-Column13",
					order: 4,
					text: "Volume",
					visible: true
				}, {
					id: "shippingTableComp-shipTable-Column14",
					order: 5,
					text: "Volume Unit",
					visible: true
				}, {
					id: "shippingTableComp-shipTable-Column15",
					order: 6,
					text: "ESL Material",
					visible: true
				}, {
					id: "shippingTableComp-shipTable-Column16",
					order: 7,
					text: "Temp Condition",
					visible: true
				}, {
					id: "shippingTableComp-shipTable-Column17",
					order: 8,
					text: "DG Code & Desc",
					visible: true
				}]
			},
			getPersData: function () {
				var oDeferred = new jQuery.Deferred();
				if (!this._oBundle) {
					this._oBundle = this.Data;
				}
				var oBundle = this._oBundle;
				oDeferred.resolve(oBundle);
				return oDeferred.promise();
			},

			setPersData: function (oBundle) {
				var oDeferred = new jQuery.Deferred();
				this._oBundle = oBundle;
				oDeferred.resolve();
				return oDeferred.promise();
			},

			delPersData: function () {
				var oDeferred = new jQuery.Deferred();
				oDeferred.resolve();
				return oDeferred.promise();
			}
		};

		return shippingPersoService;

	},
	true);