sap.ui.define(['jquery.sap.global'],
	function (jQuery) {
		"use strict";


		var accountPersoService = {
			oData: {
				_persoSchemaVersion: "1.0",
				aColumns: [{
					id: "AllTableComp-AllTable-allmat",
					order: 0,
					text: "Material Number",
					visible: true
				}, {
					id: "AllTableComp-AllTable-allmatdec",
					order: 1,
					text: "Material Description",
					visible: true
				}, {
					id: "AllTableComp-AllTable-alluom",
					order: 2,
					text: "Batch",
					visible: true
				}, {
					id: "AllTableComp-AllTable-allmattype",
					order: 3,
					text: "FO Batch Required",
					visible: true
				}, {
					id: "AllTableComp-AllTable-allcatgroup",
					order: 4,
					text: "Class",
					visible: true
				}, {
					id: "AllTableComp-AllTable-allstdprice",
					order: 5,
					text: "MRP Type & Description",
					visible: true
				}, {
					id: "AllTableComp-AllTable-allmap",
					order: 6,
					text: "MRP Profile & Description",
					visible: true
				}, {
					id: "AllTableComp-AllTable-allcreation",
					order: 7,
					text: "MRP Ctrlr & Description",
					visible: true
				}, {
					id: "AllTableComp-AllTable-allmatsts",
					order: 8,
					text: "Safety Stock",
					visible: true
				}]
			},
			getPersData: function () {
				var oDeferred = new jQuery.Deferred();
				if (!this._oBundle) {
					this._oBundle = this.Data;
				}
				var oBundle = this._oBundle;
				oDeferred.resolve(oBundle);
				return oDeferred.promise();
			},

			setPersData: function (oBundle) {
				var oDeferred = new jQuery.Deferred();
				this._oBundle = oBundle;
				oDeferred.resolve();
				return oDeferred.promise();
			},

			delPersData: function () {
				var oDeferred = new jQuery.Deferred();
				oDeferred.resolve();
				return oDeferred.promise();
			}
		};

		return accountPersoService;

	}, true);