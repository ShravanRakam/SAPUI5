sap.ui.define(['jquery.sap.global'],
	function(jQuery) {
		"use strict";
		var persocode = {
			oData: {

				_persoSchemaVersion: "1.0",
				aColumn: [{
					id: "demo-Table-Column1",
					order: "0",
					text: "Material No",
					visible: true
				}, {
					id: "demo-Table-Column2",
					order: "1",
					text: "Material Description",
					visible: false
				}, {
					id: "demo-Table-Column3",
					order: "2",
					text: "Designation",
					visible: true
				}, {
					id: "demo-Table-Column4",
					order: "3",
					text: "UOM",
					visible: true
				}, {
					id: "demo-Table-Column5",
					order: "4",
					text: "Material Type",
					visible: true
				}, {
					id: "demo-Table-Column6",
					order: "5",
					text: "Item Categirory Group",
					visible: true
				}, {
					id: "demo-Table-Column7",
					order: "6",
					text: "standared Price",
					visible: true
				}, {
					id: "demo-Table-Column8",
					order: "7",
					text: "MAP",
					visible: true
				}, {
					id: "demo-Table-Column9",
					order: "8",
					text: "Creation Data",
					visible: true
				}, {
					id: "demo-Table-Column10",
					order: "9",
					text: "Materisl Status",
					visible: true
				 },
				{
					id: "demo-Table-Column11",
					order: "10",
					text: "Material Group",
					visible: true
				}, {
				
					id: "demo-Table-Column12",
					order: "11",
					text: "Weight Unit",
					visible: false
				}, {
				
					id: "demo-Table-Column13",
					order: "12",
					text: "Weight Unit",
					visible: false
				}, {
				
					id: "demo-Table-Column14",
					order: "13",
					text: "Weight Unit",
					visible: false
				}, {
				
					id: "demo-Table-Column15",
					order: "14",
					text: "Weight Unit",
					visible: false
				}, {
				
					id: "demo-Table-Column16",
					order: "15",
					text: "Weight Unit",
					visible: false
				}, {
				
					id: "demo-Table-Column17",
					order: "16",
					text: "Weight Unit",
					visible: false
				}, {
				
					id: "demo-Table-Column18",
					order: "17",
					text: "Weight Unit",
					visible: false
				}, {
				
					id: "demo-Table-Column19",
					order: "18",
					text: "Weight Unit",
					visible: false
				}, {
				
					id: "demo-Table-Column20",
					order: "19",
					text: "Weight Unit",
					visible: false
				}, {
				
					id: "demo-Table-Column21",
					order: "20",
					text: "Weight Unit",
					visible: false
				}, {
				
					id: "demo-Table-Column22",
					order: "21",
					text: "Weight Unit",
					visible: false
				}, {
				
					id: "demo-Table-Column23",
					order: "22",
					text: "Weight Unit",
					visible: false
				}, {
				
					id: "demo-Table-Column24",
					order: "23",
					text: "Weight Unit",
					visible: false
				}, {
				
					id: "demo-Table-Column25",
					order: "24",
					text: "Weight Unit",
					visible: false
				}, {
				
					id: "demo-Table-Column26",
					order: "25",
					text: "Weight Unit",
					visible: false
				}, {
				
					id: "demo-Table-Column27",
					order: "26",
					text: "Weight Unit",
					visible: false
				}, {
				
					id: "demo-Table-Column28",
					order: "27",
					text: "Weight Unit",
					visible: false
				}, {
				
					id: "demo-Table-Column29",
					order: "28",
					text: "Weight Unit",
					visible: false
				},{
				
					id: "demo-Table-Column30",
					order: "29",
					text: "Weight Unit",
					visible: false
				}]
			},
			getPersData: function() {
				var oDeferred = new jQuery.Deferred();
				if (!this._oBundle) {
					this._oBundle = this.Data;
				}
				var oBundle = this._oBundle;
				oDeferred.resolve(oBundle);
				return oDeferred.promise();
			},
			setPersData: function(oBundle) {
				var oDeferred = new jQuery.Deferred();
				this._oBundle = oBundle;
				oDeferred.resolve();
				return oDeferred.promise();
			},
			resetPersData: function() {
				var oDeferred = new jQuery.Deferred();
				var oInitialData = {
					_persoSchemaVersion: "1.0",
					aColumns: [{
						id: "demo-Table-Column1",
						order: 0,
						text: "MaterialNo",
						property: "MaterialNo",
						visible: true
					}, {
						id: "demo-Table-Column2",
						order: 1,
						text: "Material Description",
						visible: false
					}, {
						id: "demo-Table-Column3",
						order: 2,
						text: "UOM",
						visible: true
					}, {

						id: "demo-Table-Column4",
						order: 3,
						text: "MaterialType",
						visible: true
					}, {
						id: "demo-Table-Column5",
						order: 4,
						text: "ItemCategiroryGroup",
						visible: true
					}, {
						id: "demo-Table-Column6",
						order: 4,
						text: "standaredPrice",
						visible: true
					},{
						id: "demo-Table-Column6",
						order: 4,
						text: "MAP",
						visible: true
					},{
						id: "demo-Table-Column6",
						order: 4,
						text: "CreationData",
						visible: true
					},{
						id: "demo-Table-Column6",
						order: 4,
						text: "MaterislStatus",
						visible: true
					// },{
					// 	id: "demo-Table-Column6",
					// 	order: 4,
					// 	text: "MaterialGroup",
					// 	visible: true
					}
					]
				};
				this._oBundle = oInitialData;

				oDeferred.resolve();
				return oDeferred.promise();
			}

		};

		return persocode;
				
	}, /* bExport= */ true);