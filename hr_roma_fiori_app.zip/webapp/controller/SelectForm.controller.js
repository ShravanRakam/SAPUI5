sap.ui.define([
	"sap/ui/core/mvc/Controller",
	"sap/ui/model/json/JSONModel",
	"sap/ui/core/routing/History",
	"sap/ui/core/Fragment",
	"sap/m/MessageBox",
	"sap/ui/model/Filter",
	"sap/ui/model/FilterOperator"
], function(Controller, JSONModel, History, Fragment, MessageBox, Filter, FilterOperator) {
	"use strict";
	return Controller.extend("org.wfpRomaMaintenance.controller.SelectForm", {
		onInit: function() {
			var oRouter = sap.ui.core.UIComponent.getRouterFor(this);
			oRouter.getRoute("SelectForm").attachPatternMatched(this._onpatterntMatched, this);
		},
		_onpatterntMatched: function(oEvent) {
			var that = this;
			var oVisibleModel = new sap.ui.model.json.JSONModel({
				headerText: "",
				valueStateVT: "None",
				valueStateEffDate: "None",
				valueStateNteDate: "None",
				fragmentName: "",
				valueHelpTitle: "",
				formBusy: false,
				effectiveDate: "",
				contractDura: "",
				remarks: "",
				specific: "",
				vacancyType: "",
				toBeAdvertised: false,
				proposedAction: "",
				actionReason: "",
				daily: "",
				monthly: "",
				unPensioner: "",
				TDYNte: "",
				fundingNteNew: "",
				personelArea: "",
				personelSubArea: "",
				internalOrder: "",
				wbs: "",
				iOBusy: false

			});
			that.getView().setModel(oVisibleModel, "visibleModel");
			var selectModel = new JSONModel(jQuery.sap.getModulePath("org.wfpRomaMaintenance", "/model/selectModel.json"));
			that.getView().setModel(selectModel, "selectModel");
			var path = oEvent.getParameter("arguments").path;
			var PositionId = oEvent.getParameter("arguments").PosId;
			var oModel = that.getView().getModel("visibleModel"),
				fragName;
			if (path === "Issue Vacancy") {
				oModel.setProperty("/headerText", "Issue Vacancy");
				oModel.setProperty("/fragmentName", "IssueVacancy");
				fragName = oModel.getProperty("/fragmentName");
				that.loadFragment(oEvent, fragName);
				that.IssueVacancyData(PositionId);
			} else if (path === "Fill Position") {
				oModel.setProperty("/headerText", "Fill Position");
				oModel.setProperty("/fragmentName", "fillPosition");
				fragName = oModel.getProperty("/fragmentName");
				that.loadFragment(oEvent, fragName);
				that.IssueVacancyData(PositionId);
			} else if (path === "Assign or Change Funding") {
				oModel.setProperty("/headerText", "Assign/Change Funding");
				oModel.setProperty("/fragmentName", "assignChangeFunding");
				fragName = oModel.getProperty("/fragmentName");
				that.loadFragment(oEvent, fragName);
				that.IssueVacancyData(PositionId);
			} else if (path === "Change Position Working Time") {
				oModel.setProperty("/headerText", "Change Position Working Time");
				oModel.setProperty("/fragmentName", "changePositionWorkTime");
				fragName = oModel.getProperty("/fragmentName");
				that.loadFragment(oEvent, fragName);
				that.IssueVacancyData(PositionId);
			} else if (path === "Extend Funding") {
				oModel.setProperty("/headerText", "Extend Funding");
				oModel.setProperty("/fragmentName", "ExtendFunding");
				fragName = oModel.getProperty("/fragmentName");
				that.loadFragment(oEvent, fragName);
				that.IssueVacancyData(PositionId);
			} else if (path === "Upgrade or Downgrade Position") {
				oModel.setProperty("/headerText", "Upgrade/Downgrade Funding");
				oModel.setProperty("/fragmentName", "upgradeDowngradePos");
				fragName = oModel.getProperty("/fragmentName");
				that.loadFragment(oEvent, fragName);
				that.IssueVacancyData(PositionId);
			} else if (path === "Change Position Job or Title") {
				oModel.setProperty("/headerText", "Change Position Job or Title");
				oModel.setProperty("/fragmentName", "changePositionJob");
				fragName = oModel.getProperty("/fragmentName");
				that.loadFragment(oEvent, fragName);
				that.IssueVacancyData(PositionId);
			} else if (path === "Transfer Position to another Org. Unit") {
				oModel.setProperty("/headerText", "Transfer Position to another Org. Unit");
				oModel.setProperty("/fragmentName", "TransferPosToAssign");
				fragName = oModel.getProperty("/fragmentName");
				that.loadFragment(oEvent, fragName);
				that.IssueVacancyData(PositionId);
			} else if (path === "Change Position Type") {
				oModel.setProperty("/headerText", "Change Position Type");
				oModel.setProperty("/fragmentName", "ChangePosType");
				fragName = oModel.getProperty("/fragmentName");
				that.loadFragment(oEvent, fragName);
				that.IssueVacancyData(PositionId);
			} else if (path === "Abolish Position") {
				oModel.setProperty("/headerText", "Abolish Position");
				oModel.setProperty("/fragmentName", "AbolishPosition");
				fragName = oModel.getProperty("/fragmentName");
				that.loadFragment(oEvent, fragName);
				that.IssueVacancyData(PositionId);
			} else if (path === "Transfer Employee") {
				oModel.setProperty("/headerText", "Transfer Employee");
				oModel.setProperty("/fragmentName", "transferEmployee");
				fragName = oModel.getProperty("/fragmentName");
				that.loadFragment(oEvent, fragName);
				that.IssueVacancyData(PositionId);
			} else if (path === "Extend Employee") {
				oModel.setProperty("/headerText", "Extend Employee");
				oModel.setProperty("/fragmentName", "extendEmployee");
				fragName = oModel.getProperty("/fragmentName");
				that.loadFragment(oEvent, fragName);
				that.IssueVacancyData(PositionId);
			} else if (path === "Promotion or Demotion") {
				oModel.setProperty("/headerText", "Promotion/Demotion Employee");
				oModel.setProperty("/fragmentName", "promotionDemotion");
				fragName = oModel.getProperty("/fragmentName");
				that.loadFragment(oEvent, fragName);
				that.IssueVacancyData(PositionId);
			} else if (path === "Change Employee Category") {
				oModel.setProperty("/headerText", "Change Employee Category");
				oModel.setProperty("/fragmentName", "changeEmpCat");
				fragName = oModel.getProperty("/fragmentName");
				that.loadFragment(oEvent, fragName);
				that.IssueVacancyData(PositionId);
			} else if (path === "Change Employee Contract Type") {
				oModel.setProperty("/headerText", "Change Employee Contract Type");
				oModel.setProperty("/fragmentName", "changeEmpConType");
				fragName = oModel.getProperty("/fragmentName");
				that.loadFragment(oEvent, fragName);
				that.IssueVacancyData(PositionId);
			} else if (path === "Extend Temporary Duty") {
				oModel.setProperty("/headerText", "Extend Temporary Duty");
				oModel.setProperty("/fragmentName", "extendTempDuty");
				fragName = oModel.getProperty("/fragmentName");
				that.loadFragment(oEvent, fragName);
				that.IssueVacancyData(PositionId);
			} else if (path === "Special Post Allowance") {
				oModel.setProperty("/headerText", "Special Post Allowance");
				oModel.setProperty("/fragmentName", "specialPostAlwnce");
				fragName = oModel.getProperty("/fragmentName");
				that.loadFragment(oEvent, fragName);
				that.IssueVacancyData(PositionId);
			} else if (path === "Create Org. Unit") {
				oModel.setProperty("/headerText", "Create Org. Unit");
				oModel.setProperty("/fragmentName", "CreateOrgUnit");
				fragName = oModel.getProperty("/fragmentName");
				that.loadFragment(oEvent, fragName);
				that.IssueVacancyData(PositionId);
			} else if (path === "Create Org. Unit Title") {
				oModel.setProperty("/headerText", "Create Org. Unit Title");
				oModel.setProperty("/fragmentName", "CreateOrgUnitTitle");
				fragName = oModel.getProperty("/fragmentName");
				that.loadFragment(oEvent, fragName);
				that.IssueVacancyData(PositionId);
			} else if (path === "Abolish Org. Unit") {
				oModel.setProperty("/headerText", "Abolish Org. Unit");
				oModel.setProperty("/fragmentName", "AbolishOrgUnit");
				fragName = oModel.getProperty("/fragmentName");
				that.loadFragment(oEvent, fragName);
				that.IssueVacancyData(PositionId);
			} else if (path === "Create Position") {
				oModel.setProperty("/headerText", "Create Position");
				oModel.setProperty("/fragmentName", "CreatePosition");
				fragName = oModel.getProperty("/fragmentName");
				that.loadFragment(oEvent, fragName);
				that.IssueVacancyData(PositionId);
			} else if (path === "Transfer Org. Unit") {
				oModel.setProperty("/headerText", "Transfer Org. Unit");
				oModel.setProperty("/fragmentName", "TransferOrgUnit");
				fragName = oModel.getProperty("/fragmentName");
				that.loadFragment(oEvent, fragName);
				that.IssueVacancyData(PositionId);
			}

		},
		loadFragment: function(oEvent, fragmentName) {
			var that = this,
				panel = oEvent.getParameters().view.getContent()[0].getContent()[0];
			panel.removeAllContent();
			Fragment.load({
				name: "org.wfpRomaMaintenance.fragments." + fragmentName,
				controller: that
			}).then(function(oFragment) {
				panel.addContent(oFragment);
			});
		},
		onPressBack: function() {
			var that = this;
			var oHistory, sPreviousHash;
			oHistory = History.getInstance();
			sPreviousHash = oHistory.getPreviousHash();
			if (sPreviousHash !== undefined) {
				window.history.go(-1);
				that.getView().getModel("visibleModel").setData({
					items: []
				});
			} else {
				this.getOwnerComponent().getRouter().navTo("RomaMaintenance", {}, true /*no history*/ );
			}
		},
		onLoadPersonalArea: function() {
			var that = this,
				pAreaModel,
				url = "/sap/opu/odata/sap/ZPCR_POSITION_FORM_SRV/",
				oModel = new sap.ui.model.odata.v2.ODataModel(url, false);
			if (!that.pAreaDialog) {
				that.pAreaDialog = sap.ui.xmlfragment("org.wfpRomaMaintenance.fragments.personnelArea", that);
				that.getView().addDependent(that.pAreaDialog);
			}
			that.pAreaDialog.open();
			oModel.setUseBatch(false);
			that.getView().getModel("visibleModel").setProperty("/iOBusy", true);
			oModel.read("/PAREASet", {
				success: function(oData) {
					that.getView().getModel("visibleModel").setProperty("/iOBusy", false);
					pAreaModel = new JSONModel(oData.results);
					pAreaModel.setSizeLimit(oData.results.length);
					that.getView().setModel(pAreaModel, "pAreaModel");
				},
				error: function(error) {
					that.getView().getModel("visibleModel").setProperty("/iOBusy", false);
					MessageBox.error(JSON.parse(error.responseText).error.message.value);
				}
			});

		},
		onLoadPersonalSubArea: function() {
			var that = this,
				pSubAreaModel,
				url = "/sap/opu/odata/sap/ZPCR_POSITION_FORM_SRV/",
				oModel = new sap.ui.model.odata.v2.ODataModel(url, false);
			if (!that.psAreaDialog) {
				that.psAreaDialog = sap.ui.xmlfragment("org.wfpRomaMaintenance.fragments.personalSubArea", that);
				that.getView().addDependent(that.psAreaDialog);
			}
			that.psAreaDialog.open();
			oModel.setUseBatch(false);
			that.getView().getModel("visibleModel").setProperty("/iOBusy", true);
			oModel.read("/PSAREASet", {
				success: function(oData) {
					that.getView().getModel("visibleModel").setProperty("/iOBusy", false);
					pSubAreaModel = new JSONModel(oData.results);
					pSubAreaModel.setSizeLimit(oData.results.length);
					that.getView().setModel(pSubAreaModel, "pSubAreaModel");
				},
				error: function(error) {
					that.getView().getModel("visibleModel").setProperty("/iOBusy", false);
					MessageBox.error(JSON.parse(error.responseText).error.message.value);
				}
			});

		},
		onLoadInternalOrder: function() {
			var that = this,
				internalOrder,
				url = "/sap/opu/odata/sap/ZPCR_POSITION_FORM_SRV/",
				oModel = new sap.ui.model.odata.v2.ODataModel(url, false);
			if (!that.iODialog) {
				that.iODialog = sap.ui.xmlfragment("org.wfpRomaMaintenance.fragments.internalOrder", that);
				that.getView().addDependent(that.iODialog);
			}
			that.iODialog.open();
			oModel.setUseBatch(false);
			that.getView().getModel("visibleModel").setProperty("/iOBusy", true);
			oModel.read("/InternalOrderSet", {
				success: function(oData) {
					that.getView().getModel("visibleModel").setProperty("/iOBusy", false);
					internalOrder = new JSONModel(oData.results);
					internalOrder.setSizeLimit(oData.results.length);
					that.getView().setModel(internalOrder, "internalOrderModel");
				},
				error: function(error) {
					that.getView().getModel("visibleModel").setProperty("/iOBusy", false);
					MessageBox.error(JSON.parse(error.responseText).error.message.value);
				}
			});

		},
		onCancelIO: function() {
			var that = this;
			if (that.iODialog) {
				that.getView().getModel("visibleModel").setProperty("/iOBusy", false);
				that.iODialog.close();
				that.iODialog.destroy();
				that.iODialog = null;
			} else if (that.psAreaDialog) {
				that.getView().getModel("visibleModel").setProperty("/iOBusy", false);
				that.psAreaDialog.close();
				that.psAreaDialog.destroy();
				that.psAreaDialog = null;
			} else if (that.wbsDialog) {
				that.getView().getModel("visibleModel").setProperty("/iOBusy", false);
				that.wbsDialog.close();
				that.wbsDialog.destroy();
				that.wbsDialog = null;
			} else if (that.pAreaDialog) {
				that.getView().getModel("visibleModel").setProperty("/iOBusy", false);
				that.pAreaDialog.close();
				that.pAreaDialog.destroy();
				that.pAreaDialog = null;
			}

		},
		onSelectionInternalOrd: function(oEvent) {
			var that = this,
				dialogTitle = oEvent.getSource().getParent().getTitle(),
				data;
			if (dialogTitle === "Personnel Area") {
				data = oEvent.getParameters("row").rowContext.getObject().Ptext;
				that.getView().getModel("visibleModel").setProperty("/personelArea", data);
			} else if (dialogTitle === "Personnel Sub Area") {
				data = oEvent.getParameters("row").rowContext.getObject().Pstext;
				that.getView().getModel("visibleModel").setProperty("/personelSubArea", data);
			} else if (dialogTitle === "Internal Order") {
				data = oEvent.getParameters("row").rowContext.getObject().Ktext;
				that.getView().getModel("visibleModel").setProperty("/internalOrder", data);
			} else if (dialogTitle === "WBS Element") {
				data = oEvent.getParameters("row").rowContext.getObject().Wbs;
				that.getView().getModel("visibleModel").setProperty("/wbs", data);
			}

			that.onCancelIO();
		},
		onLoadWBS: function() {
			var that = this,
				wbsNo,
				url = "/sap/opu/odata/sap/ZPCR_POSITION_FORM_SRV/",
				oModel = new sap.ui.model.odata.v2.ODataModel(url, false);
			if (!that.wbsDialog) {
				that.wbsDialog = sap.ui.xmlfragment("org.wfpRomaMaintenance.fragments.wbsElement", that);
				that.getView().addDependent(that.wbsDialog);
			}
			that.wbsDialog.open();
			oModel.setUseBatch(false);
			that.getView().getModel("visibleModel").setProperty("/iOBusy", true);
			oModel.read("/WBS_elementSet", {
				success: function(oData) {
					that.getView().getModel("visibleModel").setProperty("/iOBusy", false);
					wbsNo = new JSONModel(oData.results);
					wbsNo.setSizeLimit(oData.results.length);
					that.getView().setModel(wbsNo, "wbsModel");
				},
				error: function(error) {
					that.getView().getModel("visibleModel").setProperty("/iOBusy", false);
					MessageBox.error(JSON.parse(error.responseText).error.message.value);
				}
			});

		},
		onSearchF4Help: function(oEvent) {
			var that = this,
				sQuery = oEvent.getParameter("query");
			if (!sQuery) {
				sQuery = oEvent.getParameter("newValue");
			}
			var filter1 = new Filter("Parea", FilterOperator.Contains, sQuery);
			var filter2 = new Filter("Ptext", FilterOperator.Contains, sQuery);
			var filter3 = new Filter("Subarea", FilterOperator.Contains, sQuery);
			var filter4 = new Filter("Pstext", FilterOperator.Contains, sQuery);
			var filter5 = new Filter("IntOrder", FilterOperator.Contains, sQuery);
			var filter6 = new Filter("Ktext", FilterOperator.Contains, sQuery);
			var filter7 = new Filter("Wbs", FilterOperator.Contains, sQuery);
			var filter8 = new Filter("Wbs", FilterOperator.Contains, sQuery);
			var filterData = [filter1, filter2, filter3, filter4, filter5, filter6, filter7, filter8];
			var oNewFilter = new Filter({
				filters: filterData,
				and: false
			});
			// filter binding
			var oTab = oEvent.getSource().getParent().getParent().getContent()[0];
			var oBinding = oTab.getBinding("rows");
			oBinding.filter(oNewFilter);
		},
		onPressSave: function(oEvent) {
			var that = this,
				visible = that.getView().getModel("visibleModel").getData(),
				headerText = oEvent.getSource().getParent().getParent().getContent()[0].getHeaderText();
			if (headerText === "Issue Vacancy") {
				if (visible.effectiveDate !== "") {
					that.getView().getModel("visibleModel").setProperty("/valueStateEffDate", "None");
					if (visible.vacancyType !== "") {
						that.getView().getModel("visibleModel").setProperty("/valueStateVT", "None");
						MessageBox.confirm("Are you sure, want to Send Form?", {
							title: "Confimation",
							actions: [MessageBox.Action.YES, MessageBox.Action.NO],
							emphasizedAction: MessageBox.Action.YES,
							onClose: function(oAction) {
								if (oAction === "YES") {
									that.updateIssueVacancy();
								}
							}
						});
					} else {
						that.getView().getModel("visibleModel").setProperty("/valueStateVT", "Error");
						MessageBox.warning("Please Select the type of Vacancy..!");
					}
				} else {
					that.getView().getModel("visibleModel").setProperty("/valueStateEffDate", "Error");
					MessageBox.warning("Please Select the appropriate Date..!");
				}
			} else if (headerText === "Assign/Change Funding") {
				if (visible.effectiveDate !== "") {
					if (visible.fundingNteNew !== "") {
						that.getView().getModel("visibleModel").setProperty("/valueStateEffDate", "None");
						that.getView().getModel("visibleModel").setProperty("/valueStateNteDate", "None");
						MessageBox.confirm("Are you sure, want to Send Form?", {
							title: "Confimation",
							actions: [MessageBox.Action.YES, MessageBox.Action.NO],
							emphasizedAction: MessageBox.Action.YES,
							onClose: function(oAction) {
								if (oAction === "YES") {
									that.updateAssignFund();
								}
							}
						});
					} else {
						that.getView().getModel("visibleModel").setProperty("/valueStateEffDate", "Error");
						that.getView().getModel("visibleModel").setProperty("/valueStateNteDate", "Error");
						MessageBox.warning("Please Select the new Position NTE Funding Date..!");
					}

				} else {
					that.getView().getModel("visibleModel").setProperty("/valueStateEffDate", "Error");
					MessageBox.warning("Please Select the appropriate Effective Date..!");
				}
			}
			 else if (headerText === "Extend Funding") {
				if (visible.effectiveDate !== "") {
					if (visible.fundingNteNew !== "") {
						that.getView().getModel("visibleModel").setProperty("/valueStateEffDate", "None");
						that.getView().getModel("visibleModel").setProperty("/valueStateNteDate", "None");
						MessageBox.confirm("Are you sure, want to Send Form?", {
							title: "Confimation",
							actions: [MessageBox.Action.YES, MessageBox.Action.NO],
							emphasizedAction: MessageBox.Action.YES,
							onClose: function(oAction) {
								if (oAction === "YES") {
									that.updateExtendFunding();
								}
							}
						});
					} else {
						that.getView().getModel("visibleModel").setProperty("/valueStateEffDate", "Error");
						that.getView().getModel("visibleModel").setProperty("/valueStateNteDate", "Error");
						MessageBox.warning("Please Select the new Position NTE Funding Date..!");
					}

				} else {
					that.getView().getModel("visibleModel").setProperty("/valueStateEffDate", "Error");
					MessageBox.warning("Please Select the appropriate Effective Date..!");
				}
			}


		},
		updateAssignFund: function() {
			var that = this,
				formData = that.getView().getModel("positionFormModel").getData(),
				visible = that.getView().getModel("visibleModel").getData();
				if(formData.Nte === "0000-00-00" || formData.Nte === null || formData.Nte === undefined ){
					var Nte = null;
				}else{
					Nte = new Date(formData.Nte);
				}
				if(formData.Wbs === "000000000000000000000000"){
				var	wbsOld = "";
				}
				else{
					wbsOld = formData.Wbs;
				}
			var	updateData = {
					PosId: formData.PosId,
					PosText: formData.PosText,
					Job: formData.Job,
					OrgUnit: formData.OrgUnit,
					Eegrp: formData.Eegrp,
					Eesgrp: formData.Eesgrp,
					Nte: Nte,
					NteEnd: new Date(visible.fundingNteNew),
					Workschedule: formData.Workschedule,
					PareaOld: formData.PareaOld,
					PareaNew: visible.PareaNew,
					PsareaOld: formData.PsareaOld,
					PsareNew: visible.PsareNew,
					PosType: formData.PosType,
					PosGrade: formData.PosGrade,
					EffDate: new Date(visible.effectiveDate),
					Remarks: visible.remarks,
					InternalOrderNew: visible.internalOrder,
					InternalOrderOld: formData.InternalOrderOld,
					WbsNew: visible.wbs.split("(", 1)[0],
					WbsOld: wbsOld

				};
			that.getView().getModel("visibleModel").setProperty("/formBusy", true);
			var url = "/sap/opu/odata/sap/ZPCR_POSITION_FORM_SRV/",
				oModel = new sap.ui.model.odata.v2.ODataModel(url, false);
			oModel.setUseBatch(false);
			oModel.update("/Assign_FundingSet('" + updateData.PosId + "')", updateData, {
				success: function(data, oResponse) {
					that.getView().getModel("visibleModel").setProperty("/formBusy", false);
					var message = oResponse.headers;
					if (message["sap-message"] !== undefined) {
						var xml = message["sap-message"];
						var sMessage = JSON.parse(xml).message;
						sap.m.MessageBox.show(sMessage, {
							icon: sap.m.MessageBox.Icon.SUCCESS,
							title: "Success",
							actions: [MessageBox.Action.OK],
							emphasizedAction: MessageBox.Action.OK,
							onClose: function(oAction) {
								if (oAction === "OK") {
									that.onPressBack();
								}
							}
						});
					} else {
						that.getView().getModel("visibleModel").setProperty("/formBusy", false);
						MessageBox.success("Request  sent successfully", {
							title: "Success",
							actions: [MessageBox.Action.OK],
							emphasizedAction: MessageBox.Action.OK,
							onClose: function(oAction) {
								if (oAction === "OK") {
									that.onPressBack();
								}
							}
						});
					}
				},
				error: function(error) {
					that.getView().getModel("visibleModel").setProperty("/formBusy", false);
					MessageBox.error(JSON.parse(error.responseText).error.message.value);
				}
			});

		},
		updateExtendFunding: function() {
			var that = this,
				formData = that.getView().getModel("positionFormModel").getData(),
				visible = that.getView().getModel("visibleModel").getData();
					if(formData.Nte === "0000-00-00" || formData.Nte === null || formData.Nte === undefined ){
					var Nte = null;
				}else{
					Nte = new Date(formData.Nte);
				}
					if(formData.Wbs === "000000000000000000000000"){
				var	wbsOld = "";
				}
				else{
					wbsOld = formData.Wbs;
				}
			var	updateData = {
					PosId: formData.PosId,
					Costcenter:formData.Costcenter,
					InternalOrderNew:formData.InternalOrder,
					PareaOld:formData.Parea,
					PsareaOld:formData.Psarea,
					WbsOld:wbsOld,
					PosText: formData.PosText,
					Job: formData.Job,
					OrgUnit: formData.OrgUnit,
					Eegrp: formData.Eegrp,
					Eesgrp: formData.Eesgrp,
					Nte: Nte,
					NteEnd: new Date(visible.fundingNteNew),
					Workschedule: formData.Workschedule,
					PosType: formData.PosType,
					PosGrade: formData.PosGrade,
					EffDate: new Date(visible.effectiveDate),
					Remarks: visible.remarks
				};
			that.getView().getModel("visibleModel").setProperty("/formBusy", true);
			var url = "/sap/opu/odata/sap/ZPCR_POSITION_FORM_SRV/",
				oModel = new sap.ui.model.odata.v2.ODataModel(url, false);
			oModel.setUseBatch(false);
			oModel.update("/Change_FundingSet('" + updateData.PosId + "')", updateData, {
				success: function(data, oResponse) {
					that.getView().getModel("visibleModel").setProperty("/formBusy", false);
					var message = oResponse.headers;
					if (message["sap-message"] !== undefined) {
						var xml = message["sap-message"];
						var sMessage = JSON.parse(xml).message;
						sap.m.MessageBox.show(sMessage, {
							icon: sap.m.MessageBox.Icon.SUCCESS,
							title: "Success",
							actions: [MessageBox.Action.OK],
							emphasizedAction: MessageBox.Action.OK,
							onClose: function(oAction) {
								if (oAction === "OK") {
									that.onPressBack();
								}
							}
						});
					} else {
						that.getView().getModel("visibleModel").setProperty("/formBusy", false);
						MessageBox.success("Request  sent successfully", {
							title: "Success",
							actions: [MessageBox.Action.OK],
							emphasizedAction: MessageBox.Action.OK,
							onClose: function(oAction) {
								if (oAction === "OK") {
									that.onPressBack();
								}
							}
						});
					}
				},
				error: function(error) {
					that.getView().getModel("visibleModel").setProperty("/formBusy", false);
					MessageBox.error(JSON.parse(error.responseText).error.message.value);
				}
			});

		},
		onPressF4Help: function(oEvent) {
			var that = this,
				oModel = that.getView().getModel("visibleModel"),
				getValueHelp = oEvent.getSource().getName();
			if (getValueHelp === "inpActualDutyStation") {
				oModel.setProperty("/valueHelpTitle", "Actual Duty Station");
			} else if (getValueHelp === "inpOrgUnit") {
				oModel.setProperty("/valueHelpTitle", "Organization Unit");
			} else if (getValueHelp === "inpPosText") {
				oModel.setProperty("/valueHelpTitle", "Position Number");
				var posModel = new JSONModel(jQuery.sap.getModulePath("org.wfpRomaMaintenance", "/model/positionData.json"));
				that.getView().setModel(posModel, "positionModel");

			} else if (getValueHelp === "inpTdyNTE") {
				oModel.setProperty("/valueHelpTitle", "TDY NTE");
			} else if (getValueHelp === "inpWorkSchedule") {
				oModel.setProperty("/valueHelpTitle", "Work Schedule Rule");
			} else if (getValueHelp === "inpApprovePSA") {
				oModel.setProperty("/valueHelpTitle", "Approved PSA Position");
			} else if (getValueHelp === "inpUSG") {
				oModel.setProperty("/valueHelpTitle", "Unique Under Secretary General");
			} else if (getValueHelp === "inpSPAPosText") {
				oModel.setProperty("/valueHelpTitle", "SPA Postion Number/Text");
			}

			if (!that.valueHelpDialog) {
				that.valueHelpDialog = sap.ui.xmlfragment("org.wfpRomaMaintenance.fragments.positionF4Help", that);
				that.getView().addDependent(that.valueHelpDialog);
			}
			that.valueHelpDialog.open();
		},
		onCancelValuehelp: function() {
			var that = this;
			that.valueHelpDialog.close();
			that.valueHelpDialog.destroy();
			that.valueHelpDialog = null;
		},
		onSelectItem: function(oEvent) {
			var that = this,
				oPath = oEvent.getSource().getParent().getContent()[0].getSelectedIndex(),
				selectedRow = that.getView().getModel("positionModel").getProperty("/results/" + oPath);
			var rowModel = new JSONModel(selectedRow);
			that.getView().setModel(rowModel, "oModel");
			that.onCancelValuehelp();
		},
		onChangeProposedAction: function(oEvent) {
			var that = this,
				selectedKey = oEvent.getSource().getSelectedKey(),
				actionReason,
				oModel;
			if (selectedKey === "Reassignment (06)") {
				actionReason = that.getView().getModel("selectModel").getProperty("/actionReasonReassign/");
				oModel = new JSONModel({
					items: actionReason
				});
				that.getView().setModel(oModel, "actionReason");
			} else if (selectedKey === "Temporary Duty(TDY) (22)") {
				actionReason = that.getView().getModel("selectModel").getProperty("/actionReasonTDY");
				oModel = new JSONModel({
					items: actionReason
				});
				that.getView().setModel(oModel, "actionReason");
			} else if (selectedKey === "SPA (18)") {
				actionReason = that.getView().getModel("selectModel").getProperty("/actionReasonSPA");
				oModel = new JSONModel({
					items: actionReason
				});
				that.getView().setModel(oModel, "actionReason");
			} else if (selectedKey === "Change of Category (21)") {
				actionReason = that.getView().getModel("selectModel").getProperty("/actionReasonChangeEmpCat");
				oModel = new JSONModel({
					items: actionReason
				});
				that.getView().setModel(oModel, "actionReason");
			} else if (selectedKey === "Conversion of Contract (04)") {
				actionReason = that.getView().getModel("selectModel").getProperty("/actionReasonChangeEmpConType");
				oModel = new JSONModel({
					items: actionReason
				});
				that.getView().setModel(oModel, "actionReason");
			} else if (selectedKey === "Temporary Duty(TDY)(22)") {
				actionReason = that.getView().getModel("selectModel").getProperty("/actionReasonExtTempDuty");
				oModel = new JSONModel({
					items: actionReason
				});
				that.getView().setModel(oModel, "actionReason");
			} else if (selectedKey === "") {
				oModel = new JSONModel({
					items: []
				});
				that.getView().setModel(oModel, "actionReason");
			}
		},
		// changes made on 12-01-2024 and 16-01-2024 for model name change and formBusy, batch as false

		IssueVacancyData: function(PositionId) {
			var that = this,
				url = "/sap/opu/odata/sap/ZPCR_POSITION_FORM_SRV/",
				oModel = new sap.ui.model.odata.v2.ODataModel(url, false),
				visible = that.getView().getModel("visibleModel");
			oModel.setUseBatch(false);
			visible.setProperty("/formBusy", true);
			oModel.read("/ZPCR_POSITION_FORMSet(PosId='" + PositionId + "')", {
				success: function(OData) {
					visible.setProperty("/formBusy", false);
					var IssueVacancyModel = new JSONModel(OData);
					that.getView().setModel(IssueVacancyModel, "positionFormModel");
				},
				error: function(error) {
					visible.setProperty("/formBusy", false);
					MessageBox.error(JSON.parse(error.responseText).error.message.value);
				}
			});
		},
		updateIssueVacancy: function(oEvent) {
			var that = this,
				// notifNo,
				// oModel = that.getOwnerComponent().getModel("positionFormService"),
				formData = that.getView().getModel("positionFormModel").getData(),
				visible = that.getView().getModel("visibleModel").getData(),
				updateData = {
					PosId: formData.PosId,
					PosText: formData.PosText,
					Job: formData.Job,
					OrgUnit: formData.OrgUnit,
					Eegrp: formData.Eegrp,
					Eesgrp: formData.Eesgrp,
					Nte: formData.Nte,
					Workschedule: formData.Workschedule,
					Duration: visible.contractDura,
					Parea: formData.Parea,
					PosType: formData.PosType,
					PosGrade: formData.PosGrade,
					ToBeAdvertised: formData.ToBeAdvertised,
					EffDate: new Date(visible.effectiveDate),
					// TdyNte: new Date(visible.TDYNte),
					VacancyType: visible.vacancyType,
					Specific: visible.specific,
					Remarks: visible.remarks

				};
			that.getView().getModel("visibleModel").setProperty("/formBusy", true);
			var url = "/sap/opu/odata/sap/ZPCR_POSITION_FORM_SRV/",
				oModel = new sap.ui.model.odata.v2.ODataModel(url, false);
			oModel.setUseBatch(false);
			oModel.update("/Issue_VacancySet('" + updateData.PosId + "')", updateData, {
				success: function(data, oResponse) {
					that.getView().getModel("visibleModel").setProperty("/formBusy", false);
					var message = oResponse.headers;
					if (message !== undefined) {
						var xml = message["sap-message"];
						var sMessage = JSON.parse(xml).message;
						sap.m.MessageBox.show(sMessage, {
							icon: sap.m.MessageBox.Icon.SUCCESS,
							title: "Success",
							actions: [MessageBox.Action.OK],
							emphasizedAction: MessageBox.Action.OK,
							onClose: function(oAction) {
								if (oAction === "OK") {
									that.onPressBack();
								}
							}
						});
					} else {
						that.getView().getModel("visibleModel").setProperty("/formBusy", false);
						MessageBox.success("Request  sent successfully", {
							title: "Success",
							actions: [MessageBox.Action.OK],
							emphasizedAction: MessageBox.Action.OK,
							onClose: function(oAction) {
								if (oAction === "OK") {
									that.onPressBack();
								}
							}
						});
					}
				},
				error: function(error) {
					that.getView().getModel("visibleModel").setProperty("/formBusy", false);
					MessageBox.error(JSON.parse(error.responseText).error.message.value);
				}
			});
		}
	});
});