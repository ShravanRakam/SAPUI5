 sap.ui.define([
	"sap/ui/core.ComponentContainer"
], function(ComponentContainer) {
	"use strict";
	new ComponentContainer({
		name: "com.translatableTexts",
		settings: {
			id: "com.translatableTexts"
		},
		async: true
	}).placeAt("content");
});