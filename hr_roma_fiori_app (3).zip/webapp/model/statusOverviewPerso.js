sap.ui.define(['jquery.sap.global'],
	function(jQuery) {
		"use strict";

		var DemoPersoService = {
			oData: {
				_persoSchemaVersion: "1.0",
				aColumns: [{
					id: "desc",
					order: 0,
					text: "Description",
					visible: true
				}, {
					id: "reqId",
					order: 1,
					text: "Number of Request",
					visible: true
				}, {
					id: "additional1",
					order: 2,
					text: "Additional 1",
					visible: true
				}, {
					id: "additional2",
					order: 3,
					text: "Additional 2",
					visible: true
				}, {
					id: "status",
					order: 4,
					text: "Status",
					visible: true
				}, {
					id: "reqBy",
					order: 5,
					text: "Request By",
					visible: true
				}, {
					id: "sentOn",
					order: 6,
					text: "Sent On",
					visible: true
				}, {
					id: "reqEndProc",
					order: 7,
					text: "Request End Of Processing",
					visible: true
				}, {
					id: "missedDeadDays",
					order: 8,
					text: "Missed Deadline Days",
					visible: true
				}, {
					id: "changedOn",
					order: 9,
					text: "Changed On",
					visible: true
				}, {
					id: "approvalStatus1",
					order: 10,
					text: "I Appoval Status",
					visible: true
				}, {
					id: "approvalDate1",
					order: 11,
					text: "I Approval Date",
					visible: true
				}, {
					id: "approvalDoneBy",
					order: 12,
					text: "I Approval Done By",
					visible: true
				}, {
					id: "approvalStatus2",
					order: 13,
					text: "II Approval Status",
					visible: true
				}, {
					id: "approvalDate2",
					order: 14,
					text: "II Approval Date",
					visible: true
				}, {
					id: "approvalDoneBy2",
					order: 15,
					text: "II Approval Done By",
					visible: true
				}, {
					id: "cancel",
					order: 16,
					text: "Cancellation",
					visible: true
				}]
			},
			getPersData: function () {
				var oDeferred = new jQuery.Deferred();
				if (!this._oBundle) {
					this._oBundle = this.oData;
				}
				var oBundle = this._oBundle;
				oDeferred.resolve(oBundle);
				return oDeferred.promise();
			},

			setPersData: function (oBundle) {
				var oDeferred = new jQuery.Deferred();
				this._oBundle = oBundle;
				oDeferred.resolve();
				return oDeferred.promise();
			},

			delPersData: function () {
				var oDeferred = new jQuery.Deferred();
				oDeferred.resolve();
				return oDeferred.promise();
			}

		};

		return DemoPersoService;

	}, true);