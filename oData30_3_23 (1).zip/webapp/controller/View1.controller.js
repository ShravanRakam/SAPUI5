sap.ui.define([
	"sap/ui/core/mvc/Controller",
	"sap/ui/model/json/JSONModel",
	"sap/m/MessageToast",
	"sap/m/MessageBox",
	"sap/ui/export/library",
	"sap/ui/export/Spreadsheet"
], function(Controller, JSONModel, MessageToast, MessageBox, exportLibrary, Spreadsheet) {
	"use strict";

	return Controller.extend("com.odataoData30_3_23.controller.View1", {
		onInit: function() {
			var that = this;
			that.odataModel();

			// 	var getTable = that.getView().byId("Table");
			// var aSelectedIndices = [0, 1, 2, 3, 4]; // select the first 5 records
			// getTable.setSelectedIndex(aSelectedIndices);
		},
		odataModel: function() {
			var that = this;
			var url = "/sap/opu/odata/sap/ZEMPLOYEE_SRV/";
			var oModel = new sap.ui.model.odata.ODataModel(url, true);
			oModel.read("/zempSet", {
				success: function(oData) {
					var oModel1 = new JSONModel(oData);
					that.getView().setModel(oModel1, "table");
					MessageToast.show("Data Loaded successfully");
				}

			});
		},

		onAdd: function() {
			var that = this;
			var addModel = new JSONModel();

			that.getView().setModel(addModel, "formModel");
			var visibleModel = new JSONModel();
			// var visibleModel = new JSONModel();
			that.getView().setModel(visibleModel, "buttonModel");
			that.getView().getModel("buttonModel").setProperty("/onAddDataVisible", true);
			that.getView().getModel("buttonModel").setProperty("/onUpdateVisible", false);

			if (!that.oDialog) {
				that.oDialog = sap.ui.xmlfragment("com.odataoData30_3_23.view.Fragment", that);
				that.getView().addDependent(this.oDialog);
			}
			that.oDialog.open();

		},

		onAddData: function() {
			var that = this;
			var sUrl = "/sap/opu/odata/sap/ZEMPLOYEE_SRV/";
			var oModel = new sap.ui.model.odata.ODataModel(sUrl, true);
			var formData = that.getView().getModel("formModel").getData();
			oModel.create("/zempSet", formData, {
				success: function(Data) {
					MessageToast.show("record added Successfuly");
				}
			});
			this.onCancel();
			this.odataModel().refresh();

		},
		onCancel: function() {
			this.oDialog.close();
			this.oDialog.destroy();
			this.oDialog = null;
		},
		onDeleteItem: function(oEvent) {
			var source = oEvent.getSource();
			var selecteditem = source.getBindingContext("table").getObject().Empno;
			var url = "/sap/opu/odata/sap/ZEMPLOYEE_SRV/";

			var oDatamodel = new sap.ui.model.odata.ODataModel(url, true);
			oDatamodel.remove("/zempSet('" + selecteditem + "')", {
				success: function(oData) {
					MessageBox.show("item deleted Sucessfully");
				}
			});
			this.odataModel().refresh();
		},

		// var source = oEvent.getSource();
		// var selecteditem = source.getBindingContext("table").getObject().Empno;
		// var url = "/sap/opu/odata/sap/ZEMPLOYEE_SRV/";
		// var oDatamodel = new sap.ui.model.odata.ODataModel(url, true);
		// oDatamodel.remove("/zempSet('" + selecteditem + "')", {
		// 	success: function(oData) {
		// 		MessageBox.show("Deleted Successfully");
		// 	}
		// });
		// this.odatamodel().refresh();
		// }
		onUpdateOpen: function(event) {
			this.onAdd();
			var source = event.getSource();
			var selecteditem = source.getBindingContext("table").getObject();
			var newModel = new JSONModel(selecteditem);
			this.getView().setModel(newModel, "formModel");
			this.getView().getModel("buttonModel").setProperty("/onAddDataVisible", false);
			this.getView().getModel("buttonModel").setProperty("/onUpdateVisible", true);

		},
		onUpdate: function() {
			var url = "/sap/opu/odata/sap/ZEMPLOYEE_SRV/";
			var oDatamodel = new sap.ui.model.odata.ODataModel(url, true);
			var formdata = this.getView().getModel("formModel").getData();
			oDatamodel.update("/zempSet('" + formdata.Empno + "')", formdata, {
				success: function(oData) {
					MessageToast.show("Updated successfully Successfully");
				}
			});
			this.onCancel();
			this.odataModel().refresh();
		},
		// onSelectAll: function(oEvent) {
		// 	var that = this;
		// 	var getTable = that.getView().byId("Table");
		// 	var aSelectedIndices = [];
		// 	for (var i = 0; i < 5; i++) {
		// 		var oItem = getTable.getItems()[i];
		// 		aSelectedIndices.push(oItem);
		// 	}

		// 	getTable.setSelectedItems(aSelectedIndices);

		// }

		onSelectionChange: function(oEvent) {
		
    var aSelectedItems = oEvent.getParameter("listItems");
    if (aSelectedItems.length > 5) {
        // deselect any additional rows
        var iNumDeselections = aSelectedItems.length - 5;
        for (var i = 0; i < 5; i++) {
            aSelectedItems[i + 5].setSelected(false);
        }
    }
}

    

		
	});
});