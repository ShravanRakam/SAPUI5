jQuery.sap.require("com.karma.zsupplierPjctRep.util.Formatter");
sap.ui.define(["./BaseController", "sap/ui/model/json/JSONModel", "../model/formatter", "sap/ui/model/Filter",
	"sap/ui/model/FilterOperator", "sap/ui/core/util/Export", "sap/ui/core/util/ExportTypeCSV"
], function (e, t, i, Filter, FilterOperator, s, o, r, a) {
	"use strict";
	return e.extend("com.karma.zsupplierPjctRep.controller.Worklist", {
		formatter: i,
		onInit: function () {
			var e, i, s = this.byId("table");
			i = s.getBusyIndicatorDelay();
			this._aTableSearchState = [];
			e = new t({
				worklistTableTitle: this.getResourceBundle().getText("worklistTableTitle"),
				shareOnJamTitle: this.getResourceBundle().getText("worklistTitle"),
				shareSendEmailSubject: this.getResourceBundle().getText("shareSendEmailWorklistSubject"),
				shareSendEmailMessage: this.getResourceBundle().getText("shareSendEmailWorklistMessage", [location.href]),
				tableNoDataText: this.getResourceBundle().getText("tableNoDataText"),
				tableBusyDelay: 0
			});
			this.setModel(e, "worklistView");
			this.onShow();
			s.attachEventOnce("updateFinished", function () {
				e.setProperty("/tableBusyDelay", i)
			})
		},
		onShow: function () {
			var e = new sap.ui.model.odata.ODataModel("/sap/opu/odata/sap/Z001_DPR_PROJ_CDS", true);
			this.myJsonModel = new sap.ui.model.json.JSONModel;
			var f, t, i, s;
			e.read("/Z001_DPR_PROJ?$select=Supplier_Number&$filter=not(Supplier_Number+eq+%27%20%27)", null, null, false,
				function (e) {
					f = e.results
				});
			e.read("/Z001_DPR_PROJ?$select=Supplier_Status,Supplier_Status_Txt&$filter=not(Supplier_Status+eq+%27%20%27)", null, null, false,
				function (e, i) {
					t = e.results
				});
			e.read("/Z001_DPR_PROJ?$select=Module_Group_Txt,Module_Group&$filter=not(Module_Group+eq+%27%20%27)", null, null, false, function (
				e, t) {
				i = e.results
			});
			e.read("/Z001_DPR_PROJ?$select=Manuf_Location_Txt,Manuf_Location&$filter=not(Manuf_Location+eq+%27%20%27)", null, null, false,
				function (e, t) {
					s = e.results
				});
			var o = {
					SupplierNumber: [],
					SupplierStat: [],
					moduleGroup: [],
					manLoc: []
				},
				sn = [],
				r = [],
				a = [],
				l = [];
			for (var n = 0; n < f.length; n++) {
				sn[n] = f[n].Supplier_Number
			}
			sn = sn.filter(function (e, f, i) {
				return f == i.indexOf(e)
			});
			for (var n in f) {
				var u = sn[n];
				o.SupplierNumber.push({
					SupplierNumber: u
				})
			}
			for (var n = 0; n < t.length; n++) {
				r[n] = t[n].Supplier_Status_Txt
			}
			r = r.filter(function (e, t, i) {
				return t == i.indexOf(e)
			});
			for (var n in r) {
				var u = r[n];
				o.SupplierStat.push({
					SupplierStat: u
				})
			}
			for (var n = 0; n < i.length; n++) {
				a[n] = i[n].Module_Group_Txt
			}
			a = a.filter(function (e, t, i) {
				return t == i.indexOf(e)
			});
			for (var n in a) {
				var u = a[n];
				o.moduleGroup.push({
					moduleGroup: u
				})
			}
			for (var n = 0; n < s.length; n++) {
				l[n] = s[n].Manuf_Location_Txt
			}
			l = l.filter(function (e, t, i) {
				return t == i.indexOf(e)
			});
			for (var n in l) {
				var u = l[n];
				o.manLoc.push({
					manLoc: u
				})
			}
			var p = new sap.ui.model.json.JSONModel;
			p.setData(o);
			this.byId("supplierNumber").setModel(p);
			this.byId("supplierNumber").bindItems({
				path: "/SupplierNumber",
				template: new sap.ui.core.ListItem({
					key: "{SupplierNumber}",
					text: "{SupplierNumber}"
				})
			});
			this.byId("supplierStatus").setModel(p);
			this.byId("supplierStatus").bindItems({
				path: "/SupplierStat",
				template: new sap.ui.core.ListItem({
					key: "{SupplierStat}",
					text: "{SupplierStat}"
				})
			});
			this.byId("moduleGrp").setModel(p);
			this.byId("moduleGrp").bindItems({
				path: "/moduleGroup",
				template: new sap.ui.core.ListItem({
					key: "{moduleGroup}",
					text: "{moduleGroup}"
				})
			});
			this.byId("manufLoc").setModel(p);
			this.byId("manufLoc").bindItems({
				path: "/manLoc",
				template: new sap.ui.core.ListItem({
					key: "{manLoc}",
					text: "{manLoc}"
				})
			})
		},
		onFilter: function (e) {
			var f = this.byId("supplierNumber").getValue();
			var t = this.byId("supplierStatus").getValue();
			var i = this.byId("moduleGrp").getValue();
			var s = this.byId("manufLoc").getValue();
			this.filters = [];
			if (f !== "") {
				var o = new sap.ui.model.Filter("Supplier_Number", sap.ui.model.FilterOperator.EQ, f);
				this.filters.push(o)
			}
			if (t !== "") {
				var o = new sap.ui.model.Filter("Supplier_Status_Txt", sap.ui.model.FilterOperator.EQ, t);
				this.filters.push(o)
			}
			if (i !== "") {
				var o = new sap.ui.model.Filter("Module_Group_Txt", sap.ui.model.FilterOperator.EQ, i);
				this.filters.push(o)
			}
			if (s !== "") {
				var o = new sap.ui.model.Filter("Manuf_Location_Txt", sap.ui.model.FilterOperator.EQ, s);
				this.filters.push(o)
			}
			var r = this.byId("table");
			var a = r.getBinding("items");
			a.aFilters = null;
			var l = new sap.ui.model.Filter(this.filters, true);
			a.filter(l)
		},
		onReset: function () {
			this.byId("supplierNumber").setValue("");
			this.byId("supplierStatus").setValue("");
			this.byId("moduleGrp").setValue("");
			this.byId("manufLoc").setValue("");
			this.byId("supplierStatus").setSelectedKey("");
			this.byId("moduleGrp").setSelectedKey("");
			this.byId("manufLoc").setSelectedKey("");
			this.filters = [];
			var e = this.byId("table");
			var t = e.getBinding("items");
			t.filter("")
		},
		toggleColumns: function () {
			var e = this;
			e._oDialog = sap.ui.xmlfragment("com.karma.zsupplierPjctRep.view.columns", e.getView().getController());
			var t = new sap.ui.model.json.JSONModel;
			var i = {
				collection: [{
					id: "Supplier_NoC",
					checked: this.getView().byId("Supplier_NoC").getVisible(),
					text: this.getView().getModel("i18n").getResourceBundle().getText("Supplier_No")
				}, {
					id: "Supplier_NameC",
					checked: this.getView().byId("Supplier_NameC").getVisible(),
					text: this.getView().getModel("i18n").getResourceBundle().getText("Supplier_Name")
				}, {
					id: "assessExpC",
					checked: this.getView().byId("assessExpC").getVisible(),
					text: this.getView().getModel("i18n").getResourceBundle().getText("assessExp")
				}, {
					id: "assessScoreC",
					checked: this.getView().byId("assessScoreC").getVisible(),
					text: this.getView().getModel("i18n").getResourceBundle().getText("assessScore")
				}, {
					id: "qaCertExpC",
					checked: this.getView().byId("qaCertExpC").getVisible(),
					text: this.getView().getModel("i18n").getResourceBundle().getText("qaCertExp")
				}, {
					id: "supplierStatusC",
					checked: this.getView().byId("supplierStatusC").getVisible(),
					text: this.getView().getModel("i18n").getResourceBundle().getText("supplierStatus")
				}, {
					id: "moduleGrpC",
					checked: this.getView().byId("moduleGrpC").getVisible(),
					text: this.getView().getModel("i18n").getResourceBundle().getText("moduleGrp")
				}, {
					id: "manufLocC",
					checked: this.getView().byId("manufLocC").getVisible(),
					text: this.getView().getModel("i18n").getResourceBundle().getText("manufLoc")
				}]
			};
			t.setData(i);
			e._oDialog.setModel(e.getView().getModel());
			e._oDialog.setModel(t);
			var s = this.getView().getModel("pathModel").getData().path;
			var o = new sap.ui.model.resource.ResourceModel({
				bundleUrl: s + "/i18n/i18n.properties"
			});
			this._oDialog.setModel(o, "i18n");
			jQuery.sap.syncStyleClass("sapUiSizeCompact", this.getView(), this._oDialog);
			this._oDialog.open()
		},
		handleConfirm: function (e) {
			var t = this;
			var i = sap.ui.getCore().byId("columnTable").getModel().getData().collection;
			for (var s = 0; s < i.length; s++) {
				if (i[s].checked === false) {
					t.getView().byId(i[s].id).setVisible(false)
				} else {
					t.getView().byId(i[s].id).setVisible(true)
				}
			}
			this.handleClose()
		},
		handleClose: function () {
			this._oDialog.destroy()
		},
		onDownload: sap.m.Table.prototype.exportData || function (e) {
			var t = this;
			sap.ui.core.BusyIndicator.show(0);
			setTimeout(function () {
				var e = new sap.ui.core.util.Export({
					exportType: new sap.ui.core.util.ExportTypeCSV({
						separatorChar: ","
					}),
					models: t.getView().getModel(),
					rows: {
						path: "/Z001_DPR_PROJ",
						filters: t.filters
					},
					columns: [{
						name: t.getView().getModel("i18n").getResourceBundle().getText("Supplier_No"),
						template: {
							content: "{Supplier_Number}"
						}
					}, {
						name: t.getView().getModel("i18n").getResourceBundle().getText("Supplier_Name"),
						template: {
							content: "{Supplier_Name}"
						}
					}, {
						name: t.getView().getModel("i18n").getResourceBundle().getText("assessExp"),
						template: {
							content: {
								parts: ["Assessment_Expiry_Date"],
								formatter: function (e) {
									if (e !== "" && e !== null && e !== "00000000" && e !== "0000-00-00" && e !== undefined) {
										var t = sap.ui.core.format.DateFormat.getDateInstance({
											pattern: "MM/dd/yyyy"
										});
										return t.format(e)
									} else {
										return ""
									}
								}
							}
						}
					}, {
						name: t.getView().getModel("i18n").getResourceBundle().getText("assessScore"),
						template: {
							content: "{Assessment_Score}"
						}
					}, {
						name: t.getView().getModel("i18n").getResourceBundle().getText("qaCertExp"),
						template: {
							content: {
								parts: ["QA_Cert_Expiry"],
								formatter: function (e) {
									if (e !== "" && e !== null && e !== "00000000" && e !== "0000-00-00" && e !== undefined) {
										var t = sap.ui.core.format.DateFormat.getDateInstance({
											pattern: "MM/dd/yyyy"
										});
										return t.format(e)
									} else {
										return ""
									}
								}
							}
						}
					}, {
						name: t.getView().getModel("i18n").getResourceBundle().getText("supplierStatus"),
						template: {
							content: "{Supplier_Status_Txt}"
						}
					}, {
						name: t.getView().getModel("i18n").getResourceBundle().getText("moduleGrp"),
						template: {
							content: "{Module_Group_Txt}"
						}
					}, {
						name: t.getView().getModel("i18n").getResourceBundle().getText("manufLoc"),
						template: {
							content: "{Manuf_Location_Txt}"
						}
					}]
				});
				e.saveFile(t.getView().getModel("i18n").getResourceBundle().getText("downloadFileName")).catch(function (e) {
					sap.m.MessageBox.error(t.getView().getModel("i18n").getResourceBundle().getText("errMsgDownload") + e)
				}).then(function () {
					e.destroy()
				});
				sap.ui.core.BusyIndicator.hide()
			}, 100)
		},
		onSearch: function (e) {
			// if (e.getParameters().refreshButtonPressed) {
			// 	this.onRefresh()
			// } else {
			// 	var t = [];
			// 	var i = e.getParameter("query");
			// 	var s = new sap.ui.model.Filter([new r("Supplier_Number", a.Contains, i), new r("Supplier_Name", a.Contains, i), new r(
			// 		"Assessment_Score", a.Contains, i), new r("Supplier_Status_Txt", a.Contains, i), new r("Module_Group_Txt", a.Contains, i), new r(
			// 		"Manuf_Location_Txt", a.Contains, i)], false);
			// 	this._applySearch(t)
			// }
			var sQuery = e.getParameter("query");
			if (!sQuery) {
				sQuery = e.getParameter("newValue");
			}
			var filter1 = new Filter("Supplier_Number", FilterOperator.Contains, sQuery);
			var filter2 = new Filter("Supplier_Name", FilterOperator.Contains, sQuery);
			var filter3 = new Filter("Assessment_Score", FilterOperator.Contains, sQuery);
			var filter4 = new Filter("Supplier_Status_Txt", FilterOperator.Contains, sQuery);
			var filter5 = new Filter("Module_Group_Txt", FilterOperator.Contains, sQuery);
			var filter6 = new Filter("Manuf_Location_Txt", FilterOperator.Contains, sQuery);
			var filterData = [filter1, filter2, filter3, filter4, filter5, filter6];
			var oNewFilter = new Filter({
				filters: filterData,
				and: false
			});
			// filter binding
			var oTab = this.getView().byId("table");
			var oBinding = oTab.getBinding("items");
			oBinding.filter(oNewFilter);
		},
		onUpdateFinished: function (e) {
			var t, i = e.getSource(),
				s = e.getParameter("total");
			if (s && i.getBinding("items").isLengthFinal()) {
				t = this.getResourceBundle().getText("worklistTableTitleCount", [s])
			} else {
				t = this.getResourceBundle().getText("worklistTableTitle")
			}
			this.getModel("worklistView").setProperty("/worklistTableTitle", t)
		},
		onPress: function (e) {
			this._showObject(e.getSource())
		},
		onNavBack: function () {
			history.go(-1)
		},
		// onSearch: function (e) {
		// 	if (e.getParameters().refreshButtonPressed) {
		// 		this.onRefresh()
		// 	} else {
		// 		var t = [];
		// 		var i = e.getParameter("query");
		// 		if (i && i.length > 0) {
		// 			t = [new r("Supplier_Name", a.Contains, i)]
		// 		}
		// 		this._applySearch(t)
		// 	}
		// },
		onRefresh: function () {
			var e = this.byId("table");
			e.getBinding("items").refresh()
		},
		_showObject: function (e) {
			this.getRouter().navTo("object", {
				objectId: e.getBindingContext().getProperty("Supplier_Number")
			})
		},
		_applySearch: function (e) {
			var t = this.byId("table"),
				i = this.getModel("worklistView");
			t.getBinding("items").filter(e, "Application");
			if (e.length !== 0) {
				i.setProperty("/tableNoDataText", this.getResourceBundle().getText("worklistNoDataWithSearchText"))
			}
		}
	})
});