/*eslint linebreak-style: ["error", "windows"]*/

jQuery.sap.declare("com.karma.zsupplierPjctRep.util.Formatter");

com.karma.zsupplierPjctRep.util.Formatter = {

DATEFORMAT: function(r) {
		if (r !== "" && r !== null && r !== "00000000" && r !== "0000-00-00" && r !== undefined) {
																			var e = sap.ui.core.format.DateFormat.getDateInstance({
																				pattern: "MM/dd/yyyy",
																				});
																			return e.format(r)
																		} else {
																			return ""
																		}
																	}
};