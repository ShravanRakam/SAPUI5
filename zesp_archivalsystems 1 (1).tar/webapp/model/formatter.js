sap.ui.define([
    
], function () {
    "use strict";

    return {
        getDownloadAllBtnEnable: function(sData){
            if(sData.length > 0){
                return true;
            }else{
                return false;
            }
        },

        getInvoiceType: function (sDescription, oInvoiceTypeData) {
            // debugger;
            // oInvoiceTypeData.forEach(function (data) {
            //     var sTypes = data.outputType.split(",");
            //     if(sTypes.includes(sOutputType)){
            //         return data.fileGroup;
                    
            //     }
            // });
            var sFileGroup,
            sTypes,
            index;

            // var flag = false;

            // oInvoiceTypeData.forEach(function (data) {
            //     var sTypes = data.outputDescription.split(",");
            //     sTypes.forEach(function (desc){
            //         if(desc === sDescription){
            //             return data.fileGroup;                        
            //         }
            //     })
                
            // });

            for (var i =0; i < oInvoiceTypeData.length; i++){
                sTypes = oInvoiceTypeData[i].outputDescription.split(",");

                 index = sTypes.findIndex( desc => desc === sDescription);
                 if(index >= 0){
                    sFileGroup = oInvoiceTypeData[i].fileGroup;

                    break;
                 }

             }

             return sFileGroup;
            

            // for (var i =0; i < oInvoiceTypeData.length; i++){
            //     var sTypes = oInvoiceTypeData[i].outputType.split(",");
                
            //     if(sTypes.includes(sOutputType)){
            //         if(oInvoiceTypeData[i].fileGroup === "Interactive Invoice" || oInvoiceTypeData[i].fileGroup === "Interactive & PDF Hire Invoice"){
            //             // flag = true;

            //             if(oInvoiceTypeData[i].fileGroup === "Interactive Invoice" && new Date(sBillingDate) < new Date("2017/08/08")){
            //                 sFileGroup = oInvoiceTypeData[i].fileGroup;
            //                 break;
            //             }else if (oInvoiceTypeData[i].fileGroup === "Interactive & PDF Hire Invoice" && new Date(sBillingDate) >= new Date("2017/08/08")){
            //                 sFileGroup = oInvoiceTypeData[i].fileGroup;
            //                 break;
            //             }
                        
            //         }else{
            //             sFileGroup = oInvoiceTypeData[i].fileGroup;
            //             break;
            //         }
                    
            //         // if(oInvoiceTypeData[i].fileGroup === "Interactive Invoice" && new Date(sBillingDate) < new Date("2017/08/08")){
            //         //     sFileGroup = oInvoiceTypeData[i].fileGroup;
            //         //     break;
            //         // }else if (oInvoiceTypeData[i].fileGroup === "Interactive PDF Only Hire Invoice" && new Date(sBillingDate) >= new Date("2017/08/08")){
            //         //     sFileGroup = oInvoiceTypeData[i].fileGroup;
            //         //     break;
            //         // }else{
            //         //     sFileGroup = oInvoiceTypeData[i].fileGroup;
            //         //     break;
            //         // }
                    
                    
            //     }
            // }

            // return sFileGroup;
            
        }
        
    };

});