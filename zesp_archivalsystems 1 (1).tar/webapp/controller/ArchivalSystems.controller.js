var XLSX;
var maxRowsSelect = 25;


sap.ui.define([    
    "com/archivalsystems/zesparchivalsystems/controller/BaseController",
    "sap/ui/model/json/JSONModel",
    "sap/m/MessageBox",
    'sap/ui/core/Fragment',
    "com/archivalsystems/zesparchivalsystems/model/formatter",
    "com/archivalsystems/zesparchivalsystems/Libs/jszip"

],
    /**
     * @param {typeof sap.ui.core.mvc.Controller} Controller
     */
    function (BaseController, JSONModel, MessageBox, Fragment, formatter, jszip) {
        "use strict";

        return BaseController.extend("com.archivalsystems.zesparchivalsystems.controller.ArchivalSystems", {
            formatter: formatter,

            onInit: function () {
                var that = this;

                //initialising Filter model 
                var oFilterModel = new JSONModel({
                    payer: "",
                    soldTo: "",
                    country: "",
                    invoiceNumber: "",
                    invoiceType: "",
                    billingDate: "",
                    outputType: ""
                });
                that.setModel(oFilterModel, "FilterModel");


                //initialising Select model to store report data
                var oSelectModel = new JSONModel({
                    tableData: [],
                    originalData: [],
                    selectedRows: [],
                    noOfRows: 0,
                    startIndex: 0,
                    endIndex: 0,
                    noOfTableRows: 25,
                    isSelectDataLoading: false,
                    isPdfDataLoading: false,
                    page: 0,
                    totalPages: 0
                });
                that.setModel(oSelectModel, "SelectModel");

                //Initialising Search Model to store data of search parameters
                var oSearchModel = new JSONModel({
                    InvoiceTypeData: [],
                    CountryData: [],
                    OutputTypeData: [],
                    PayerData: [],
                    SoldToData: [],
                    IsDetailsLoading: true,
                    ApiData: []
                });

                that.setModel(oSearchModel, "SearchModel");

                //Initialising Nav Model to store data of navigation properties
                var oNavModel = new JSONModel({
                    navButtonsVisible: false,
                    firstPageBtnEnable: false,
                    nextPageBtnEnable: false,
                    previousPageBtnEnable: false,
                    lastPageBtnEnable: false
                });

                that.setModel(oNavModel, "NavModel");


                //Getting search parameters data
                that.fnGetSearchParametersData();
                

                
                var oModel = that.getOwnerComponent().getModel("searchDataModel");
                
                //Attaching event for oData model call 
                oModel.attachRequestCompleted(function (oEvent) {
                    //Checks urldataset response 
                    if(oEvent.getParameter("success") && oEvent.getParameter("url").includes("UrlDataSet")){
                        //To get output type data
						that.fnGetOutputTypeData();
					}
                    });

            },

        
            //Gets invoice type data
            fnGetOutputTypeData: function () {
                var that = this;


                var apiData = that.getModel("SearchModel").getProperty("/ApiData");

                that.getModel("SearchModel").setProperty("/IsDetailsLoading", true);

                var settings = {
                    "crossDomain": true,
                    "async": true,
                    "url": apiData[0].Url + "document/archive",
                    "method": "GET",
                    "headers": {
                        "Access-Control-Allow-Origin": "*",
                        "Access-Control-Allow-Methods": "GET, POST, PUT, DELETE, OPTIONS",
                        "cache-control": "no-cache",
                        "system": "sap",
                        "client_id": apiData[0].ClientId,
                        "client_secret": apiData[0].SecreteCode
                    }
                };

                $.ajax(settings).success(function (response) {


                    that.getModel("SearchModel").setProperty("/OutputTypeData", response.resultSet);
                    that.getModel("SearchModel").setProperty("/IsDetailsLoading", false);

                   
                }).error(function (error) {
                    //Display error message
                    that.fnDisplayErrorMessage();
                    that.getModel("SearchModel").setProperty("/IsDetailsLoading", false);
                });

            },

            //Gets Search parameters data
            fnGetSearchParametersData: function () {
                
                var that = this;

                that.fnReadData("/BillingTypeSet", "/InvoiceTypeData");
                that.fnReadData("/CountrySet", "/CountryData");
                that.fnReadData("/UrlDataSet", "/ApiData");

                
            },

            //Reads the Search parameters data
            fnReadData: function (sEntitySet, sProperty) {
                var that = this;
                var oModel = that.getOwnerComponent().getModel("searchDataModel");

                oModel.read(sEntitySet, {
                    success: function (oData) {
                        that.getModel("SearchModel").setProperty(sProperty, oData.results);
                    },
                    error: function (oError) {
                        //Display error message
                        that.fnDisplayErrorMessage();
                        that.getModel("SearchModel").setProperty("/IsDetailsLoading", false);
                    }
                });
            },

            //Displays error message
            fnDisplayErrorMessage: function () {
                var that = this;
                var msg = that.getResourceBundle().getText("dataError");
                MessageBox.error(msg);
            },

            // clears all the search parameters data
            onClear: function () {
                var that = this;
                that.getModel("FilterModel").setProperty("/payer", "");
                that.getModel("FilterModel").setProperty("/country", "");
                that.getModel("FilterModel").setProperty("/invoiceNumber", "");
                that.getModel("FilterModel").setProperty("/invoiceType", "");
                that.getModel("FilterModel").setProperty("/soldTo", "");
                that.getModel("FilterModel").setProperty("/billingDate", "");
                that.getModel("FilterModel").setProperty("/outputType", "");

                
                that.getView().byId("invoiceTypeMCBox").removeAllSelectedItems();
                that.getView().byId("countryMCBox").removeAllSelectedItems();
                that.getView().byId("outputTypeMCBox").removeAllSelectedItems();

            },

            //Gets the data by sending search parameters
            onSearch: function () {
                var that = this;
                

                //To reset table data
                that.fnResetData();

                
                that._SortDialog = undefined;

                that.getModel("SelectModel").setProperty("/isSelectDataLoading", true);


                var payer = that.fnCheckData(that.getModel("FilterModel").getProperty("/payer"));
                var soldTo = that.fnCheckData(that.getModel("FilterModel").getProperty("/soldTo"));
                var country = that.fnCheckData(that.getModel("FilterModel").getProperty("/country"));
                var invoiceNumber = that.fnCheckData(that.getModel("FilterModel").getProperty("/invoiceNumber"));
                var invoiceType = that.fnCheckData(that.getModel("FilterModel").getProperty("/invoiceType"));
                var billingDate = that.fnCheckData(that.getModel("FilterModel").getProperty("/billingDate"));
                var outputType = that.fnCheckData(that.getModel("FilterModel").getProperty("/outputType"));


                
                var apiData = that.getModel("SearchModel").getProperty("/ApiData");

                if (invoiceNumber !== null) {
                    invoiceNumber = [invoiceNumber];
                }

                var fromDate;
                var toDate;

                var dateFormat = sap.ui.core.format.DateFormat.getDateInstance({ pattern: "YYYYMMdd" });

                if (billingDate !== "" && billingDate !== null) {
                    var date = billingDate.split(" - ");
                    fromDate = dateFormat.format(new Date(date[0]));
                    toDate = dateFormat.format(new Date(date[1]));
                } else {
                    fromDate = null;
                    toDate = null;
                }


                var requestBody = {
                    "payer": payer,
                    "soldTo": soldTo,
                    "invoiceNumber": invoiceNumber,
                    "invoiceType": invoiceType,
                    "billingDateFrom": fromDate,
                    "billingDateTo": toDate,
                    "country": country,
                    "outputType": outputType
                };

                
                var settings = {
                    "crossDomain": true,
                    "async": true,
                    "url": apiData[0].Url + "document/index",
                    "method": "POST",
                    "timeout": 0,
                    "headers": {
                        "Access-Control-Allow-Origin": "*",
                        "Access-Control-Allow-Methods": "GET, POST, PUT, DELETE, OPTIONS",
                        "cache-control": "no-cache",
                        "client_id": apiData[0].ClientId,
                        "client_secret": apiData[0].SecreteCode,
                        "Content-Type": "application/json",
                        "system": "sap"
                    },
                    "data": JSON.stringify(requestBody),


                };


                $.ajax(settings).success(function (response) {
                    var oCountryData = that.getModel("SearchModel").getProperty("/CountryData");
                    var oOutputTypeData = that.getModel("SearchModel").getProperty("/OutputTypeData");
                    response.resultSet.forEach(function (data) {
                        data.selected = false;
                        //Gets the country text based on country code
                        oCountryData.forEach(function (sCountry) {
                            if (data.country === sCountry.Land1) {
                                data.countryText = sCountry.Landx;
                            }
                        });

                        //Gets the formatted text for invoice type based on description
                        data.formattedInvoiceType = formatter.getInvoiceType(data.description, oOutputTypeData);

                        
                    });
                    that.getModel("SelectModel").setProperty("/originalData", response.resultSet);

                    that.getModel("SelectModel").setProperty("/noOfRows", response.resultSet.length);
                    that.getModel("SelectModel").setProperty("/isSelectDataLoading", false);
                    //Gets the data for first page of table
                    that.onFirstPress();
                    //Sets nav buttons visible
                    that.fnSetButtonsVisible();

                }).error(function (error) {
                    //Display error message
                    that.fnDisplayErrorMessage();

                    that.getModel("SelectModel").setProperty("/isSelectDataLoading", false);
                });

              
            },

            
            //checks data present and returns null if no value present
            fnCheckData: function (data) {
                if (data.length > 0) {
                    return data;
                } else {
                    return null;
                }
            },

            //Navigates to first view of table
            onFirstPress: function () {
                var that = this;
                var data = that.getModel("SelectModel").getProperty("/originalData");
                var noOfTableRows = parseInt(that.getModel("SelectModel").getProperty("/noOfTableRows"));

                var newData = data.slice(0, noOfTableRows);
                //Checks the data and selects checkbox for table
                that.setSelectAllCBSelect(newData);

                that.getModel("SelectModel").setProperty("/tableData", newData);
                that.getModel("SelectModel").setProperty("/startIndex", 0);
                that.getModel("SelectModel").setProperty("/endIndex", noOfTableRows - 1);

                that.getModel("SelectModel").setProperty("/page", 1);

                //To enable nav buttons
                that.fnNavButtonsEnable();

            },

            //Navigates to previous view of table
            onPreviousPress: function () {
                var that = this;
                var data = that.getModel("SelectModel").getProperty("/originalData");
                var noOfTableRows = parseInt(that.getModel("SelectModel").getProperty("/noOfTableRows"));
                var startIndex = that.getModel("SelectModel").getProperty("/startIndex");

                var newData = data.slice(startIndex - noOfTableRows, startIndex);

                //Checks the data and selects checkbox for table
                that.setSelectAllCBSelect(newData);

                that.getModel("SelectModel").setProperty("/tableData", newData);
                that.getModel("SelectModel").setProperty("/startIndex", startIndex - noOfTableRows);
                that.getModel("SelectModel").setProperty("/endIndex", startIndex - 1);

                that.getModel("SelectModel").setProperty("/page", that.getModel("SelectModel").getProperty("/page") - 1);

                //To enable nav buttons
                that.fnNavButtonsEnable();

            },

            //Navigates to next view of table
            onNextPress: function () {
                var that = this;
                var data = that.getModel("SelectModel").getProperty("/originalData");
                var noOfTableRows = parseInt(that.getModel("SelectModel").getProperty("/noOfTableRows"));
                var endIndex = that.getModel("SelectModel").getProperty("/endIndex");

                var newData = data.slice(endIndex + 1, endIndex + 1 + noOfTableRows);

                //Checks the data and selects checkbox for table
                that.setSelectAllCBSelect(newData);

                that.getModel("SelectModel").setProperty("/tableData", newData);
                that.getModel("SelectModel").setProperty("/startIndex", endIndex + 1);
                that.getModel("SelectModel").setProperty("/endIndex", endIndex + noOfTableRows);

                that.getModel("SelectModel").setProperty("/page", that.getModel("SelectModel").getProperty("/page") + 1);

                //To enable nav buttons
                that.fnNavButtonsEnable();
            },

            //Navigates to last view of table
            onLastPress: function () {
                var that = this;
                var data = that.getModel("SelectModel").getProperty("/originalData");
                var noOfTableRows = parseInt(that.getModel("SelectModel").getProperty("/noOfTableRows"));
                var startIndex;
                var oIndex = data.length % noOfTableRows;
                if (oIndex === 0) {
                    startIndex = data.length - noOfTableRows;
                } else {
                    startIndex = data.length - oIndex;
                }

                var newData = data.slice(startIndex);

                //Checks the data and selects checkbox for table
                that.setSelectAllCBSelect(newData);

                that.getModel("SelectModel").setProperty("/tableData", newData);
                that.getModel("SelectModel").setProperty("/startIndex", startIndex);
                that.getModel("SelectModel").setProperty("/endIndex", data.length);

                that.getModel("SelectModel").setProperty("/page", Math.ceil(data.length / noOfTableRows));

                //To enable nav buttons
                that.fnNavButtonsEnable();
            },

            //controls nav buttons visibility when data is available
            fnNavButtonsEnable: function () {
                var that = this;
                var data = that.getModel("SelectModel").getProperty("/originalData");
                var noOfTableRows = parseInt(that.getModel("SelectModel").getProperty("/noOfTableRows"));
                var startIndex = that.getModel("SelectModel").getProperty("/startIndex");
                var endIndex = that.getModel("SelectModel").getProperty("/endIndex");

                that.getModel("SelectModel").setProperty("/totalPages", Math.ceil(data.length / noOfTableRows));

                if (data.length > endIndex + 1) {

                    that.getView().getModel("NavModel").setProperty("/nextPageBtnEnable", true);
                    that.getView().getModel("NavModel").setProperty("/lastPageBtnEnable", true);

                } else {

                    that.getView().getModel("NavModel").setProperty("/nextPageBtnEnable", false);
                    that.getView().getModel("NavModel").setProperty("/lastPageBtnEnable", false);
                }

                if (startIndex === 0) {

                    that.getView().getModel("NavModel").setProperty("/previousPageBtnEnable", false);
                    that.getView().getModel("NavModel").setProperty("/firstPageBtnEnable", false);
                } else {

                    that.getView().getModel("NavModel").setProperty("/previousPageBtnEnable", true);
                    that.getView().getModel("NavModel").setProperty("/firstPageBtnEnable", true);
                }
            },

            //controls nav buttons visibility when data not present
            fnSetButtonsVisible: function () {
                var that = this;
                var noOfRows = that.getModel("SelectModel").getProperty("/noOfRows");

                if (noOfRows > 0) {
                    that.getView().getModel("NavModel").setProperty("/navButtonsVisible", true);
                } else {
                    that.getView().getModel("NavModel").setProperty("/navButtonsVisible", false);
                }

            },

            //Selects check box in table based on already selected items before navigation to other page in table
            setSelectAllCBSelect: function (newData) {
                var that = this;
                if (newData.length > 0) {
                    var count = 0;
                    newData.forEach(function (item, index) {
                        if (item.selected) {
                            count += 1;
                        }
                    });

                    if (count === maxRowsSelect || count === newData.length) {
                        that.getView().byId("selectAllCB").setSelected(true);
                    } else {
                        that.getView().byId("selectAllCB").setSelected(false);
                    }
                }
            },

            //gets the pdf data
            fnGetPDFData: function (Data, flag) {
                var that = this;
                var apiData = that.getModel("SearchModel").getProperty("/ApiData");

                var body = [];

                Data.forEach(function (data) {
                    
                    body.push({
                        "fileName": data.fileName

                    });
                });

                var settings = {
                    "crossDomain": true,
                    "async": true,
                    "url": apiData[0].Url + "document/file",
                    "method": "POST",
                    "headers": {
                        "Access-Control-Allow-Origin": "*",
                        "Access-Control-Allow-Methods": "GET, POST, PUT, DELETE, OPTIONS",
                        "cache-control": "no-cache",
                        "client_id": apiData[0].ClientId,
                        "client_secret": apiData[0].SecreteCode,
                        "Content-Type": "application/json",
                        "system": "sap"
                    },
                    "data": JSON.stringify(body),
                };




                $.ajax(settings).success(function (response) {

                    var oFileName = "";
                    var count = 0;

                    response.forEach(function (data) {
                        if (!data.fileBody) {
                            oFileName = oFileName + "\n" + data.fileName;
                            count += 1;
                        }
                    });

                    //Displays error message if failed to get some files data
                    if (count > 0) {
                        var msg = that.getResourceBundle().getText("fileRetrieveErrMsg");
                        MessageBox.error(msg.replace("{0}", oFileName));
                    }

                    if (count === response.length) {
                        that.getModel("SelectModel").setProperty("/isPdfDataLoading", false);
                    } else {

                        if (flag === "ViewPdf") {
                            //To open file data
                            that.openPDF(response);
                        } else if (flag === "DownloadZip") {
                            //TO download zip file
                            that.downloadZip(response);
                        } else {
                            //To download the file
                            that.downloadPDF(response);
                        }
                    }


                }).error(function (error) {
                    //Display error message
                    that.fnDisplayErrorMessage();
                    that.getModel("SelectModel").setProperty("/isPdfDataLoading", false);
                });

            },

            //calls when view button pressed in table
            onViewBtnPress: function (oEvent) {
                var that = this;
                that.getModel("SelectModel").setProperty("/isPdfDataLoading", true);
                var index = oEvent.getSource().getBindingContext("SelectModel").sPath.split("/")[2];
                var oSelectedRow = that.getModel("SelectModel").getData().tableData[index];
                
                //To get files data
                that.fnGetPDFData([oSelectedRow], "ViewPdf");

            },

            //Decodes encoded data
            decodePdfData: function (data) {
                var base64EncodedPDF = data.fileBody; // the encoded string
                var decodedPdfContent = atob(base64EncodedPDF);
                var byteArray = new Uint8Array(decodedPdfContent.length)
                for (var i = 0; i < decodedPdfContent.length; i++) {
                    byteArray[i] = decodedPdfContent.charCodeAt(i);
                }
                return byteArray;
            },

            //Opens the pdf data in new window pop up
            openPDF: function (response) {
                var that = this;

                if (!response[0].fileBody) {
                    that.getModel("SelectModel").setProperty("/isPdfDataLoading", false);
                    return;
                }

                //Decodes the file data
                var byteArray = that.decodePdfData(response[0]);

                var fileName = response[0].fileName.split("/");

                var fileFormat = fileName[fileName.length - 1].split(".");


                //for show pdf data 

                var blob = new Blob([byteArray.buffer], { type: 'application/' + fileFormat[fileFormat.length - 1].toLowerCase() });
                var _pdfurl = URL.createObjectURL(blob);

                

                let params = `scrollbars=no,resizable=no,status=no,location=no,toolbar=no,menubar=no,width=600,height=300,left=100,top=100`;

                that.getModel("SelectModel").setProperty("/isPdfDataLoading", false);

                open(_pdfurl, fileName[fileName.length - 1], params);


            },

            //Downloads the pdf data
            downloadPDF: function (response) {
                var that = this;

                if (!response[0].fileBody) {
                    that.getModel("SelectModel").setProperty("/isPdfDataLoading", false);
                    return;
                }
                //Decodes the file data
                var byteArray = that.decodePdfData(response[0]);

                var fileName = response[0].fileName.split("/");

                var fileFormat = fileName[fileName.length - 1].split(".");

                const blobURL = window.URL.createObjectURL(new Blob([byteArray.buffer], { type: 'application/' + fileFormat[fileFormat.length - 1].toLowerCase() }));
                var downloadLink = window.document.createElement('a');
                
                downloadLink.href = blobURL;
                downloadLink.download = fileName[fileName.length - 1];
                document.body.appendChild(downloadLink);
                downloadLink.click();
                document.body.removeChild(downloadLink);

                that.getModel("SelectModel").setProperty("/isPdfDataLoading", false);

            },

            //calls when download button in table is pressed
            onDownloadBtnPress: function (oEvent) {
                var that = this;
                that.getModel("SelectModel").setProperty("/isPdfDataLoading", true);
                var index = oEvent.getSource().getBindingContext("SelectModel").sPath.split("/")[2];
                var oSelectedRow = that.getModel("SelectModel").getData().tableData[index];
                
                //To get files data
                that.fnGetPDFData([oSelectedRow], "DownloadPdf");

            },

            //calls when download all button clicked
            onPressDownloadAll: function () {

                var that = this;
                var data = that.getModel("SelectModel").getProperty("/originalData");

                //Gets the selected data
                var oSelectedData = jQuery.grep(data, function (element) {
                    return element.selected === true;
                });

                //Shows error message if more than the max limit data selected
                if (oSelectedData.length > maxRowsSelect) {
                    var msg = that.getResourceBundle().getText("maxRowSelect");
                    MessageBox.information(msg.replace("{0}", maxRowsSelect));

                    ////To get files data
                } else if (oSelectedData.length > 0) {
                    that.fnGetPDFData(oSelectedData, "DownloadZip");
                    that.getModel("SelectModel").setProperty("/isPdfDataLoading", true);
                } else {
                    //Shows error message if no data selected
                    var msg = that.getResourceBundle().getText("rowSelect");
                    MessageBox.warning(msg);

                }



            },

            //downloads a zip file
            downloadZip: function (response) {

                var that = this;
                var files = [];
                var fileName;

                response.forEach(function (data) {

                    if (data.fileBody) {

                        fileName = data.fileName.split("/");
                        var byteArray = that.decodePdfData(data);
                        files.push({ name: fileName[fileName.length - 1], data: byteArray });
                    }
                });

                var zip = new JSZip();
                files.forEach(function (file) {
                    zip.file(file.name, file.data);
                });

                var dateFormat = sap.ui.core.format.DateFormat.getDateInstance({ pattern: "YYYYMMdd_HHmmss" });
                var sFileName = "Archival Systems files " + dateFormat.format(new Date()) + ".zip";

                var content = zip.generate({ type: 'blob' });
                var link = document.createElement('a');
                link.href = URL.createObjectURL(content);
                link.download = sFileName;
                document.body.appendChild(link);
                link.click();
                document.body.removeChild(link);

                that.getModel("SelectModel").setProperty("/isPdfDataLoading", false);
            },

            //resets the table data
            fnResetData: function () {
                var that = this;
                that.getModel("SelectModel").setProperty("/tableData", []);
                that.getModel("SelectModel").setProperty("/selectedRows", []);
                that.getModel("SelectModel").setProperty("/originalData", []);
                that.getModel("SelectModel").setProperty("/noOfRows", 0);
                that.getModel("SelectModel").setProperty("/startIndex", 0);
                that.getModel("SelectModel").setProperty("/endIndex", 0);

            },

            //on press checkbox at table header checks first max allowed rows and unchecks all the rows
            onPressCheckBox: function (oEvent) {
                var that = this;

                if (oEvent.getSource().getSelected()) {
                    if (parseInt(that.getModel("SelectModel").getProperty("/noOfTableRows")) > maxRowsSelect) {
                        //shows information message if number of visible rows greater than the max allowed selectable rows
                        var msg = that.getResourceBundle().getText("selectAllErrorMsg");

                        MessageBox.information(msg.replace("{0}", maxRowsSelect),
                            {
                                onClose: function (sAction) {
                                    //Selects max allowed selectable rows
                                    var data = that.getModel("SelectModel").getProperty("/tableData");
                                    data.forEach(function (item, index) {
                                        if (index < maxRowsSelect) {
                                            item.selected = true;
                                        } else {
                                            return;
                                        }
                                    });

                                    that.getModel("SelectModel").setProperty("/tableData", data);
                                }
                            });
                    } else {
                        //Selects max allowed selectable rows
                        var data = that.getModel("SelectModel").getProperty("/tableData");
                        data.forEach(function (item, index) {
                            if (index < maxRowsSelect) {
                                item.selected = true;
                            } else {
                                return;
                            }
                        });

                        that.getModel("SelectModel").setProperty("/tableData", data);
                    }
                }
                else {
                    //Un selects all the seleted rows
                    var data = that.getModel("SelectModel").getProperty("/originalData");
                    data.forEach(function (item) {
                        item.selected = false;
                    });

                    that.getModel("SelectModel").setProperty("/originalData", data);
                }


            },

            //calls when invoice type selection is completed
            handleInvoiceTypeSelectionFinish: function (oEvent) {
                var that = this;
                var selectedItems = oEvent.getParameter("selectedItems");
                var oInvoiceType = [];

                for (var i = 0; i < selectedItems.length; i++) {                
                    oInvoiceType.push(selectedItems[i].getKey());
                }

                that.getView().getModel("FilterModel").setProperty("/invoiceType", oInvoiceType);

            },

            //calls when country selection is completed
            handleCountrySelectionFinish: function (oEvent) {
                var that = this;
                var selectedItems = oEvent.getParameter("selectedItems");
                var oCountry = [];

                for (var i = 0; i < selectedItems.length; i++) {  
                    oCountry.push(selectedItems[i].getKey());
                }

                that.getView().getModel("FilterModel").setProperty("/country", oCountry);

            },           

            //calls when output type selection is completed
            handleOutputTypeSelectionFinish: function (oEvent) {
                var that = this;
                var selectedItems = oEvent.getParameter("selectedItems");
                var oOutputType = [];

                for (var i = 0; i < selectedItems.length; i++) {                    
                    oOutputType.push((selectedItems[i].getKey()).toString());
                }

                that.getView().getModel("FilterModel").setProperty("/outputType", oOutputType);

            
            },        

            //Open fragment for sorting
            handleSortButtonPressed: function () {
                var that = this;
                var oView = that.getView();
                if (!that._SortDialog) {
                    that._SortDialog = Fragment.load({
                        id: oView.getId(),
                        name: "com.archivalsystems.zesparchivalsystems.view.fragments.SortDialog",
                        controller: this
                    }).then(function (oDialog) {
                        oView.addDependent(oDialog);
                        return oDialog;
                    });
                }

                that._SortDialog.then(function (oDialog) {
                    oDialog.open();
                });
            },

            //Sorts the header data based on selection
            handleSortDialogConfirm: function (oEvent) {
                var that = this;
                var mParams = oEvent.getParameters(),
                    sPath,
                    bDescending;
                    

                sPath = mParams.sortItem.getKey();
                bDescending = mParams.sortDescending;
                

                var data = that.getModel("SelectModel").getProperty("/originalData");
                if (bDescending) {
                    data.sort((a, b) => (!a[sPath]) ? 1 : (!b[sPath]) ? -1 : (a[sPath] === b[sPath]) ? 0 : ((b[sPath] > a[sPath]) ? 1 : -1));
                } else {
                    data.sort((a, b) => (!b[sPath]) ? 1 : (!a[sPath]) ? -1 : (b[sPath] === a[sPath]) ? 0 : ((a[sPath] > b[sPath]) ? 1 : -1));
                }

                that.getModel("SelectModel").setProperty("/originalData", data);
                //Creates data for first page of table
                that.onFirstPress();

                
            },

            

        });
    });

