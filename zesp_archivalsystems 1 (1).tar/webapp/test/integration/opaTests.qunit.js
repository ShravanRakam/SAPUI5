/* global QUnit */

sap.ui.require(["com/archivalsystems/zesparchivalsystems/test/integration/AllJourneys"
], function () {
	QUnit.config.autostart = false;
	QUnit.start();
});
