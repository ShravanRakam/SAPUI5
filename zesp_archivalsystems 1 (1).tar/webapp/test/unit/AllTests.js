sap.ui.define([
	"comarchivalsystems/zesp_archivalsystems/test/unit/controller/View1.controller"
], function () {
	"use strict";
});
