sap.ui.define(['jquery.sap.global'],
	function(jQuery) {
		"use strict";
		var persocode = {
			oData: {

				_persoSchemaVersion: "1.0",
				aColumn: [{
					id: "demo-TableId-column1",
					order: "0",
					text: "Sno",
					visible: true
				}, {
					id: "demo-TableId-column2",
					order: "1",
					text: "userId",
					visible: false
				}, {
					id: "demo-TableId-column3",
					order: "2",
					text: "jobTitleName",
					visible: true
				}, {
					id: "demo-TableId-column4",
					order: "3",
					text: "firstName",
					visible: true
				}, {
					id: "demo-TableId-column5",
					order: "4",
					text: "employeeCode",
					visible: true
				}, {
					id: "demo-TableId-column6",
					order: "5",
					text: "CRUD operations",
					visible: true
				}
            
            ]
			},
			getPersData: function() {
				var oDeferred = new jQuery.Deferred();
				if (!this._oBundle) {
					this._oBundle = this.Data;
				}
				var oBundle = this._oBundle;
				oDeferred.resolve(oBundle);
				return oDeferred.promise();
			},
			setPersData: function(oBundle) {
				var oDeferred = new jQuery.Deferred();
				this._oBundle = oBundle;
				oDeferred.resolve();
				return oDeferred.promise();
			},
			resetPersData: function() {
				var oDeferred = new jQuery.Deferred();
				var oInitialData = {
					_persoSchemaVersion: "1.0",
					aColumns: [{
						id: "demo-TableId-column1",
						order: "0",
						text: "Sno",
						visible: true
					}, {
						id: "demo-TableId-column2",
						order: "1",
						text: "userId",
						visible: false
					}, {
						id: "demo-TableId-column3",
						order: "2",
						text: "jobTitleName",
						visible: true
					}, {
						id: "demo-TableId-column4",
						order: "3",
						text: "firstName",
						visible: true
					}, {
						id: "demo-TableId-column5",
						order: "4",
						text: "employeeCode",
						visible: true
					}, {
						id: "demo-TableId-column6",
						order: "5",
						text: "CRUD operations",
						visible: true
					}
					]
				};
				this._oBundle = oInitialData;

				oDeferred.resolve();
				return oDeferred.promise();
			}

		};

		return persocode;
				
	}, /* bExport= */ true);