sap.ui.define([
    "sap/ui/core/mvc/Controller",
    "sap/ui/model/json/JSONModel",

    "jquery.sap.global",
    "sap/m/TablePersoController",
    "../model/basicperso",
    "sap/ui/export/Spreadsheet"
],
    function (Controller, JSONModel, jquery, TablePersoController, basicperso, Spreadsheet) {
        "use strict";

        return Controller.extend("jsoncrud.controller.View1", {
            onInit: function () {
                var that = this;

                that.oldDataArry = [];
                var dataModel = new JSONModel({
                    "Employees": [
                        {
                            "sno": "1",
                            "userId": "rirani",
                            "jobTitleName": "Developer",
                            "firstName": "Romin",
                            "employeeCode": "E1",
                            "dateofBirth": "2010/2/2",
                            "edit": true,
                            "cancel": false,
                            "Save": false,
                            "delete": true
                        },
                        {
                            "sno": "2",
                            "userId": "nirani",
                            "jobTitleName": "Developer",
                            "firstName": "Neil",
                            "employeeCode": "E2",
                            "dateofBirth": "2010/2/2",
                            "edit": true,
                            "cancel": false,
                            "Save": false,
                            "delete": true
                        },
                        {
                            "sno": "3",
                            "userId": "thanks",
                            "jobTitleName": "Program Directory",
                            "firstName": "Tom",
                            "employeeCode": "E3",
                            "dateofBirth": "2010/7/12",

                            "edit": true,
                            "cancel": false,
                            "Save": false,
                            "delete": true
                        },
                        {
                            "sno": "4",
                            "userId": "rirani",
                            "jobTitleName": "Developer",
                            "firstName": "Romin",
                            "employeeCode": "E1",
                            "dateofBirth": "2010/2/2",

                            "edit": true,
                            "cancel": false,
                            "Save": false,
                            "delete": true
                        },
                        {
                            "sno": "5",
                            "userId": "nirani",
                            "jobTitleName": "Developer",
                            "firstName": "Neil",
                            "employeeCode": "E2",
                            "dateofBirth": "2010/2/2",
                            "edit": true,
                            "cancel": false,
                            "Save": false,
                            "delete": true
                        },
                        {
                            "sno": "6",
                            "userId": "rirani",
                            "jobTitleName": "Developer",
                            "firstName": "Romin",
                            "employeeCode": "E1",
                            "dateofBirth": "2010/7/12",

                            "edit": true,
                            "cancel": false,
                            "Save": false,
                            "delete": true
                        },
                        {
                            "sno": "7",
                            "userId": "nirani",
                            "jobTitleName": "Developer",
                            "firstName": "Neil",
                            "employeeCode": "E2",
                            "dateofBirth": "2010/7/12",

                            "edit": true,
                            "cancel": false,
                            "Save": false,
                            "delete": true
                        },
                        {
                            "sno": "8",
                            "userId": "thanks",
                            "jobTitleName": "Program Directory",
                            "firstName": "Tom",
                            "employeeCode": "E3",
                            "dateofBirth": "2010/9/22",

                            "edit": true,
                            "cancel": false,
                            "Save": false,
                            "delete": true
                        },
                        {
                            "sno": "9",
                            "userId": "rirani",
                            "jobTitleName": "Developer",
                            "firstName": "Romin",
                            "employeeCode": "E1",
                            "dateofBirth": "2010/7/12",

                            "edit": true,
                            "cancel": false,
                            "Save": false,
                            "delete": true
                        },
                        {
                            "sno": "10",
                            "userId": "nirani",
                            "jobTitleName": "Developer",
                            "firstName": "Neil",
                            "employeeCode": "E2",
                            "dateofBirth": "2010/7/12",

                            "edit": true,
                            "cancel": false,
                            "Save": false,
                            "delete": true
                        },
                        {
                            "sno": "11",
                            "userId": "rirani",
                            "jobTitleName": "Developer",
                            "firstName": "Romin",
                            "employeeCode": "E1",
                            "edit": true,
                            "cancel": false,
                            "dateofBirth": "2010/7/12",

                            "Save": false,
                            "delete": true
                        },
                        {
                            "sno": "12",
                            "userId": "nirani",
                            "jobTitleName": "Developer",
                            "firstName": "Neil",
                            "employeeCode": "E2",
                            "dateofBirth": "2010/7/12",

                            "edit": true,
                            "cancel": false,
                            "Save": false,
                            "delete": true
                        },
                        {
                            "sno": "13",
                            "userId": "thanks",
                            "jobTitleName": "Program Directory",
                            "firstName": "Tom",
                            "employeeCode": "E3",
                            "dateofBirth": "2010/7/12",

                            "edit": true,
                            "cancel": false,
                            "Save": false,
                            "delete": true
                        },
                        {
                            "sno": "14",
                            "userId": "rirani",
                            "jobTitleName": "Developer",
                            "firstName": "Romin",
                            "employeeCode": "E1",
                            "dateofBirth": "2010/7/12",

                            "edit": true,
                            "cancel": false,
                            "Save": false,
                            "delete": true
                        },
                        {
                            "sno": "15",
                            "userId": "nirani",
                            "jobTitleName": "Developer",
                            "firstName": "Neil",
                            "employeeCode": "E2",
                            "dateofBirth": "2010/7/12",

                            "edit": true,
                            "cancel": false,
                            "Save": false,
                            "delete": true


                        }]
                });
                that.getView().setModel(dataModel, "empData1");

                var newModel1 = new JSONModel({
                    visibleHeader: true,
                    "editable": false,
                    "valueState": "None",
                    "Save": false,
                    "edit": true,
                    "delete": true,
                    "cancel": false,
                    "status": "completed",
                    "status1": "Edited",

                });
                this.getView().setModel(newModel1, "newModel");

                // var modelData = this.getView().getModel("empData1").getData().Employees;
                // var Length = modelData.length;
                // this.getView().getModel("newModel").setProperty("/length",Length);

                that._oTPC = new TablePersoController({
                    table: that.getView().byId("TableId"),
                    componentName: "demo",
                    persoService: basicperso
                }).activate();

                // dataModel.attachRequestCompleted(function () {
                //     var tabData = that.getView().getModel("empData1").getData();
                //     tabData.Employees.forEach(function (item) {
                // item.Save = false;
                // item.cancel = true;
                // item.delete = false;
                // item.edit = true;
                //     });
                // });


            },

            onbuttonpersonlization: function (oEvent) {
                var that = this
                that._oTPC.openDialog();
            },
            // onAfterRendering: function () {
            //     var that = this;
            //     var tabData = that.getView().getModel("empData1").getData();
            //     tabData.Employees.forEach(function (item) {
            //         item.Save = false;
            //         item.cancel = true;
            //         item.delete = false;
            //         item.edit = true;
            //     });
            // },

            // onEdit: function (oEvent) {
            //     var oButton = oEvent.getSource();
            //     var oBindingContext = oButton.getBindingContext("empData1");
            //     var sPath = oBindingContext.getPath();
            //     var oData = oBindingContext.getModel().getProperty(sPath);

            //     // that.getView().getModel("newModel").setProperty("/editable", true);
            //     // Log the data to the console (for debugging)
            //     console.log("Selected Row Data:", oData);

            //     // Perform any additional actions with the data
            //     // For example, you could open a dialog to edit the row data
            // },
            onEdit: function (oEvent) {
                // this.mode is a global varible 
                this.mode = "Edit";
                var that = this;



                var oTable = this.byId("TableId");

                var selItem = oEvent.getSource().getBindingContext("empData1");


                var sContext = oTable.getItems()[selItem.getPath().split("/")[2]];
                var sPath = selItem.getPath();
                var sObj = selItem.getObject();
                var oldObj = {
                    sPath: sPath,
                    sObj: JSON.stringify(sObj)
                };
                that.oldDataArry.push(oldObj);
                sObj.editable = true;
                sObj.Save = true;
                sObj.cancel = true;
                sObj.delete = false;
                sObj.edit = false;

                that.getView().getModel("empData1").setProperty(sPath, sObj, sContext, true);

            },
            onCancel: function (oEvent) {
                var that = this;
                var oTable = this.byId("TableId");


                var selItem = oEvent.getSource().getBindingContext("empData1");
                // var sContext = oTable.getItems()[selItem.getPath().split("/")[2]];

                that.oldDataArry.forEach(function (item) {

                    if (item.sPath === selItem.getPath()) {


                        // var sContext = item;
                        var sPath = item.sPath;
                        var sObj = JSON.parse(item.sObj);
                        sObj.editable = false;
                        sObj.Save = false;
                        sObj.cancel = false;
                        sObj.delete = true;
                        sObj.edit = true;
                        that.getView().getModel("empData1").setProperty(sPath, sObj, true);
                    }
                });



            },

            onPress: function () {
                if (this.mode === "Edit") {
                    var that = this;
                    this.oldDataArry.forEach(function (item) {
                        // var sContext = item;
                        var sPath = item.sPath;
                        var sObj = JSON.parse(item.sObj);
                        sObj.editable = false;
                        that.getView().getModel("empData1").setProperty(sPath, sObj, true);
                    });

                    that.getView().getModel("newModel").setProperty("/Save", false);
                    that.getView().getModel("newModel").setProperty("/delete", true);
                    that.getView().getModel("newModel").setProperty("/cancel", false);
                    that.getView().getModel("newModel").setProperty("/edit", true);
                }
                that.getView().getModel("empData1");
            },
            onDelete: function (oEvent) {
                var that = this;
                var viewData22 = that.getView().getModel("empData1").getData();
                var oDelete = oEvent.getSource().getBindingContext("empData1").getPath();
                var idx = oDelete.split("/")[2];

                viewData22.Employees.splice(idx, 1);
                that.getView().getModel("empData1").setData(viewData22).updateBindings(true);

            },
            onSave: function (oEvent) {
                var that = this;
                var oTable = this.byId("TableId");
                var selItem = oEvent.getSource().getBindingContext("empData1");
                var sContext = oTable.getItems()[selItem.getPath().split("/")[2]];
                var sPath = selItem.getPath();
                var sObj = selItem.getObject();
                // var date = selItem.getObject().dateofBirth;
                // // Function to convert date format from 'mm/dd/yyyy' to 'yyyy/mm/dd'
                // function convertDateFormat(dateString) {
                //     var dateParts = dateString.split('/');
                //     return dateParts[2] + '/' + dateParts[0] + '/' + dateParts[1];
                // }

                // // Convert the date format
                // var formattedDate = convertDateFormat(date);
                // sObj.dateofBirth = formattedDate;

                sObj.editable = false;
                sObj.Save = false;
                sObj.cancel = false;
                sObj.delete = true;
                sObj.edit = true;

                that.getView().getModel("empData1").setProperty(sPath, sObj, sContext, true);
                // that.getView().getModel("newModel").setProperty("/Save", false);
                // that.getView().getModel("newModel").setProperty("/delete", true);
                // that.getView().getModel("newModel").setProperty("/cancel", false);
                // that.getView().getModel("newModel").setProperty("/edit", true);
                sap.m.MessageToast.show("Record updated Successfully");
            },


            formatDate: function(dateString) {
                var date = new Date(dateString);
                if (!isNaN(date.getTime())) {
                    var date1 =date.toLocaleDateString();
                    var dateParts = date1.split('/');
                    return dateParts[2] + '/' + dateParts[0] + '/' + dateParts[1];
                }
                return dateString;
            },


            onExport: function () {
                var that = this;
                var TableData = that.getView().byId("TableId");
                var TableItems = TableData.getItems();
                // var format = that.formatDate("2022/04/24");
                
                if (TableItems.length > 0) {
                    var aCols = that.createColumnConfig();  // Ensure this function returns the column configuration
                    var Collectionrecord = that.getView().getModel("empData1").getProperty("/Employees");
                    var Collectionrecord1 = [];
                    for(var i of Collectionrecord){
                        i.dateofBirth = that.formatDate(i.dateofBirth);
                        Collectionrecord1.push(i);
                    }
            
                    // Ensure that Collectionrecord is an array and contains data
                    if (Array.isArray(Collectionrecord1) && Collectionrecord1.length > 0) {
                        var oSettings = {
                            workbook: {
                                columns: aCols,
                                context: {
                                    sheetName: "Employee Details List"
                                }
                            },
                            dataSource: Collectionrecord1, // Correctly assigned data source
                            fileName: "Employee_Details_List.xlsx"
                        };
            
                        var oSheet = new sap.ui.export.Spreadsheet(oSettings);
                        oSheet.build()
                            .then(function() {
                                sap.m.MessageToast.show("Spreadsheet export has finished");
                                console.log("Spreadsheet created successfully.");
                            })
                            .catch(function(oError) {
                                sap.m.MessageBox.error("Error occurred while exporting data: " + oError);
                                console.log(oError, "oError");
                            });
                    } else {
                        sap.m.MessageBox.warning("No data available for export");
                    }
                } else {
                    sap.m.MessageBox.warning("No data available in the table to export");
                }
            },
            createColumnConfig: function() {
                return [
                    {
                        label: 'Sno',
                        property: 'sno',
                        type: 'string'
                    },
                    {
                        label: 'jobTitleName',
                        property: 'jobTitleName',
                        type: 'string'
                    },
                    {
                        label: 'dateofBirth',
                        property: 'dateofBirth',
                        type: 'string'
                       
                    },
                    {
                        label: 'firstName',
                        property: 'firstName',
                        type: 'string'
                    },
                    {
                        label: 'employeeCode',
                        property: 'employeeCode',
                        type: 'string'
                    },
                    {
                        label: 'userId',
                        property: 'userId',
                        type: 'string'
                    }
                ];
            },
            
            onreset: function () {
                var that = this;

                var dataModel = new JSONModel({
                    "Employees": [
                        {
                            "sno": "1",
                            "userId": "rirani",
                            "jobTitleName": "Developer",
                            "firstName": "Romin",
                            "employeeCode": "E1",
                            "dateofBirth": "2010/2/2",
                            "edit": true,
                            "cancel": false,
                            "Save": false,
                            "delete": true
                        },
                        {
                            "sno": "2",
                            "userId": "nirani",
                            "jobTitleName": "Developer",
                            "firstName": "Neil",
                            "employeeCode": "E2",
                            "dateofBirth": "2010/2/2",
                            "edit": true,
                            "cancel": false,
                            "Save": false,
                            "delete": true
                        },
                        {
                            "sno": "3",
                            "userId": "thanks",
                            "jobTitleName": "Program Directory",
                            "firstName": "Tom",
                            "employeeCode": "E3",
                            "dateofBirth": "2010/7/12",

                            "edit": true,
                            "cancel": false,
                            "Save": false,
                            "delete": true
                        },
                        {
                            "sno": "4",
                            "userId": "rirani",
                            "jobTitleName": "Developer",
                            "firstName": "Romin",
                            "employeeCode": "E1",
                            "dateofBirth": "2010/2/2",

                            "edit": true,
                            "cancel": false,
                            "Save": false,
                            "delete": true
                        },
                        {
                            "sno": "5",
                            "userId": "nirani",
                            "jobTitleName": "Developer",
                            "firstName": "Neil",
                            "employeeCode": "E2",
                            "dateofBirth": "2010/2/2",
                            "edit": true,
                            "cancel": false,
                            "Save": false,
                            "delete": true
                        },
                        {
                            "sno": "6",
                            "userId": "rirani",
                            "jobTitleName": "Developer",
                            "firstName": "Romin",
                            "employeeCode": "E1",
                            "dateofBirth": "2010/7/12",

                            "edit": true,
                            "cancel": false,
                            "Save": false,
                            "delete": true
                        },
                        {
                            "sno": "7",
                            "userId": "nirani",
                            "jobTitleName": "Developer",
                            "firstName": "Neil",
                            "employeeCode": "E2",
                            "dateofBirth": "2010/7/12",

                            "edit": true,
                            "cancel": false,
                            "Save": false,
                            "delete": true
                        },
                        {
                            "sno": "8",
                            "userId": "thanks",
                            "jobTitleName": "Program Directory",
                            "firstName": "Tom",
                            "employeeCode": "E3",
                            "dateofBirth": "2010/9/22",

                            "edit": true,
                            "cancel": false,
                            "Save": false,
                            "delete": true
                        },
                        {
                            "sno": "9",
                            "userId": "rirani",
                            "jobTitleName": "Developer",
                            "firstName": "Romin",
                            "employeeCode": "E1",
                            "dateofBirth": "2010/7/12",

                            "edit": true,
                            "cancel": false,
                            "Save": false,
                            "delete": true
                        },
                        {
                            "sno": "10",
                            "userId": "nirani",
                            "jobTitleName": "Developer",
                            "firstName": "Neil",
                            "employeeCode": "E2",
                            "dateofBirth": "2010/7/12",

                            "edit": true,
                            "cancel": false,
                            "Save": false,
                            "delete": true
                        },
                        {
                            "sno": "11",
                            "userId": "rirani",
                            "jobTitleName": "Developer",
                            "firstName": "Romin",
                            "employeeCode": "E1",
                            "edit": true,
                            "cancel": false,
                            "dateofBirth": "2010/7/12",

                            "Save": false,
                            "delete": true
                        },
                        {
                            "sno": "12",
                            "userId": "nirani",
                            "jobTitleName": "Developer",
                            "firstName": "Neil",
                            "employeeCode": "E2",
                            "dateofBirth": "2010/7/12",

                            "edit": true,
                            "cancel": false,
                            "Save": false,
                            "delete": true
                        },
                        {
                            "sno": "13",
                            "userId": "thanks",
                            "jobTitleName": "Program Directory",
                            "firstName": "Tom",
                            "employeeCode": "E3",
                            "dateofBirth": "2010/7/12",

                            "edit": true,
                            "cancel": false,
                            "Save": false,
                            "delete": true
                        },
                        {
                            "sno": "14",
                            "userId": "rirani",
                            "jobTitleName": "Developer",
                            "firstName": "Romin",
                            "employeeCode": "E1",
                            "dateofBirth": "2010/7/12",

                            "edit": true,
                            "cancel": false,
                            "Save": false,
                            "delete": true
                        },
                        {
                            "sno": "15",
                            "userId": "nirani",
                            "jobTitleName": "Developer",
                            "firstName": "Neil",
                            "employeeCode": "E2",
                            "dateofBirth": "2010/7/12",

                            "edit": true,
                            "cancel": false,
                            "Save": false,
                            "delete": true


                        }]
                });
                that.getView().setModel(dataModel, "empData1");
            }

        });
    });
