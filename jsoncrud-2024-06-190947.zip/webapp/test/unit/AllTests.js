sap.ui.define([
	"jsoncrud/test/unit/controller/View1.controller"
], function () {
	"use strict";
});
