/* global QUnit */

sap.ui.require(["jsoncrud/test/integration/AllJourneys"
], function () {
	QUnit.config.autostart = false;
	QUnit.start();
});
