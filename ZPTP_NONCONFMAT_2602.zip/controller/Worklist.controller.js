var sMsg = "";
sap.ui.define([
	"ZPTP_NON_CONFMAT/controller/BaseController",
	"sap/ui/model/json/JSONModel",
	"sap/ui/core/routing/History",
	"ZPTP_NON_CONFMAT/model/formatter",
	"sap/ui/model/Filter",
	"sap/ui/model/FilterOperator",
	'sap/ui/model/type/String',
	'sap/ui/model/type/Date',
	'sap/ui/export/library',
	'sap/ui/export/Spreadsheet',
	"sap/m/MessageBox",
	"sap/m/MessageToast",
	// 'sap/m/TablePersoController',
	"sap/ui/table/TablePersoController",
	'../model/DashboardPersoService',
	'sap/ui/core/BusyIndicator'
], function(BaseController, JSONModel, History, formatter, Filter, FilterOperator, TypeString, TypeDate, exportLibrary, Spreadsheet,
	MessageBox, MessageToast, TablePersoController, DashboardPersoService, BusyIndicator) {
	"use strict";
	var EdmType = exportLibrary.EdmType;

	return BaseController.extend("ZPTP_NON_CONFMAT.controller.Worklist", {

		formatter: formatter,

		/* =========================================================== */
		/* lifecycle methods                                           */
		/* =========================================================== */

		/**
		 * Called when the worklist controller is instantiated.
		 * @public
		 */
		onInit: function() {
			var oViewModel,
				iOriginalBusyDelay,
				oTable = this.byId("table");

			// Put down worklist table's original value for busy indicator delay,
			// so it can be restored later on. Busy handling on the table is
			// taken care of by the table itself.
			iOriginalBusyDelay = oTable.getBusyIndicatorDelay();
			// keeps the search state
			this._aTableSearchState = [];

			// Model used to manipulate control states
			oViewModel = new JSONModel({
				worklistTableTitle: this.getResourceBundle().getText("worklistTableTitle"),
				saveAsTileTitle: this.getResourceBundle().getText("saveAsTileTitle", this.getResourceBundle().getText("worklistViewTitle")),
				shareOnJamTitle: this.getResourceBundle().getText("worklistTitle"),
				shareSendEmailSubject: this.getResourceBundle().getText("shareSendEmailWorklistSubject"),
				shareSendEmailMessage: this.getResourceBundle().getText("shareSendEmailWorklistMessage", [location.href]),
				tableNoDataText: this.getResourceBundle().getText("tableNoDataText"),
				tableBusyDelay: 0,
				tableCount: 0
			});
			this.setModel(oViewModel, "worklistView");

			// Make sure, busy indication is showing immediately so there is no
			// break after the busy indication for loading the view's meta data is
			// ended (see promise 'oWhenMetadataIsLoaded' in AppController)
			oTable.attachEventOnce("updateFinished", function() {
				// Restore original busy indicator delay for worklist's table
				oViewModel.setProperty("/tableBusyDelay", iOriginalBusyDelay);
			});
			// Add the worklist page to the flp routing history
			this.addHistoryEntry({
				title: this.getResourceBundle().getText("worklistViewTitle"),
				icon: "sap-icon://table-view",
				intent: "#NonConformingMaterials-display"
			}, true);
			// add validator
			var fnValidator = function(args) {
				var text = args.text;

				return new sap.m.Token({
					key: text,
					text: text
				});
			};

			this.getView().byId("Plant").addValidator(fnValidator);
			this.getView().byId("Material").addValidator(fnValidator);
			this.getView().byId("MoveDate").addValidator(fnValidator);
			this.getView().byId("MoveType").addValidator(fnValidator);
			this.getView().byId("Refno").addValidator(fnValidator);

			/* =================================================================*/
			// initialising the Table perso from the model
			/* =================================================================*/

			this.DashboardTable = new TablePersoController({
				table: this.getView().byId("table"),
				persoService: DashboardPersoService
			});
			this.busyPost = new sap.m.BusyDialog({
				text: "Material Document Posting Please Wait"
			});
		},

		/* =========================================================== */
		/* event handlers                                              */
		/* =========================================================== */

		/**
		 * Triggered by the table's 'updateFinished' event: after new table
		 * data is available, this handler method updates the table counter.
		 * This should only happen if the update was successful, which is
		 * why this handler is attached to 'updateFinished' and not to the
		 * table's list binding's 'dataReceived' method.
		 * @param {sap.ui.base.Event} oEvent the update finished event
		 * @public
		 */
		onUpdateFinished: function(oEvent) {
			// update the worklist's object counter after the table update
			var sTitle,
				oTable = oEvent.getSource(),
				iTotalItems = oEvent.getParameter("total");
			// only update the counter if the length is final and
			// the table is not empty
			if (iTotalItems && oTable.getBinding("items").isLengthFinal()) {
				sTitle = this.getResourceBundle().getText("worklistTableTitleCount", [iTotalItems]);
			} else {
				sTitle = this.getResourceBundle().getText("worklistTableTitle");
			}
			this.getModel("worklistView").setProperty("/worklistTableTitle", sTitle);
		},
		onPersoButtonPressed: function() {

			this.DashboardTable.openDialog();
		},
		onExit: function() {

			this.DashboardTable.destroy();
		},

		onValueHelpReq: function(oEvent) {
			var that = this,
				fragmentName;
			that.valueHelpinput = oEvent.getSource();
			that.inpName = oEvent.getSource().getName();
			if (that.inpName === "Plant") {
				fragmentName = "ZPTP_NON_CONFMAT.fragments.plantValHelpInput";
			} else if (that.inpName === "Material") {
				fragmentName = "ZPTP_NON_CONFMAT.fragments.materialValHelpInput";
			} else if (that.inpName === "Movedate") {
				fragmentName = "ZPTP_NON_CONFMAT.fragments.moveDateValHelpInput";
			} else if (that.inpName === "Movetype") {
				fragmentName = "ZPTP_NON_CONFMAT.fragments.moveTypeValHelpInput";
			} else if (that.inpName === "Refno") {
				fragmentName = "ZPTP_NON_CONFMAT.fragments.refnoValHelpInput";
			} else if (that.inpName === "Matdocno") {
				fragmentName = "ZPTP_NON_CONFMAT.fragments.materialDocNum";
			}
			if (!that.valueHelpDialog) {
				that.valueHelpDialog = sap.ui.xmlfragment(fragmentName, that);
				that.getView().addDependent(that.BatchCodeDialog2);
			}
			if (that.inpName === "Movedate") {

				that.valueHelpDialog.setRangeKeyFields([{
					label: "Move Date",
					key: "Movedate",
					type: "date",
					typeInstance: new TypeDate({}, {
						displayFormat: "MM/dd/YYYY",
						valueFormat: "YYYY-MM-dd",
						formatOptions: {
							UTC: false
						}
					})
				}]);
			} else {
				that.valueHelpDialog.setRangeKeyFields([{
					label: that.inpName,
					key: that.inpName,
					type: "string",
					typeInstance: new TypeString()
				}]);
			}
			that.valueHelpDialog.setTokens(that.valueHelpinput.getTokens());
			this._bMultipleConditionsInitialized = true;
			that.valueHelpDialog.open();
		},
		onValHelpOkPress: function(oEvent) {
			var aTokens = oEvent.getParameter("tokens");
			this.valueHelpinput.setTokens(aTokens);
			this.valueHelpDialog.close();
			this.valueHelpDialog.destroy();
			this.valueHelpDialog = null;
		},
		onValHelpCancelPress: function() {
			this.valueHelpDialog.close();
			this.valueHelpDialog.destroy();
			this.valueHelpDialog = null;
		},

		onPressGo: function(oEvent) {
			var l = this.getView().byId("MoveDate");
			this.matd = this.getView().byId('Mtype').getSelectedKey();
			// var mat = this.getView().byId("MatDocN");
			var mat = this.getView().byId('Mtype').getSelectedKey();
			if (l.getTokens().length === 0) {
				MessageBox.error("Please select Move Date", {
					actions: [MessageBox.Action.CLOSE],
					// emphasizedAction: "Manage Products",
					onClose: function(sAction) {
						MessageToast.show("Move Date is a required field");
					}
				});
			} else {
				var busyDialog = new sap.m.BusyDialog({
					text: "Data Loading please wait..."
				});
				this.getView().byId("table").clearSelection();
				busyDialog.open();
				var that = this,
					filters = [],
					aTableFilters = that.byId("filterbar").getFilterGroupItems();
				// 	aTableFilters[5].destroy();
				for (var i = aTableFilters.length - 1; i >= 0; i--) {
					if (aTableFilters[i].mProperties.label === "Material Doc Number") {
						aTableFilters.splice(i, 1);
					}
				}
				// aTableFilters = that.byId("filterbar").getFilterGroupItems().reduce(function(aResult, oFilterGroupItem) {
				aTableFilters = aTableFilters.reduce(function(aResult, oFilterGroupItem) {
					var oControl = oFilterGroupItem.getControl(),
						// if (that.getView().byId('Mtype').getSelectedKey() === "A") {
						// var matd = oControl.getSelectedKey();
						// } else {
						aTokens = oControl.getTokens();
					// },

					if (aTokens.length > 0) {
						var aFilters = [];
						aTokens.forEach(function(item) {
							var keyField, oBillFilter, opt, value1, value2;
							if (item.getAggregation("customData").length > 0) {
								oBillFilter = item.getAggregation("customData")[0].getProperty("value");
								keyField = oBillFilter.keyField;
								opt = oBillFilter.operation;
								value1 = oBillFilter.value1;
								value2 = oBillFilter.value2;
								if (oBillFilter.exclude === true & opt === "EQ") {
									opt = "NE";
								}
								if (oBillFilter.keyField === "Plant") {
									value1 = value1.toUpperCase();
								}
								if (oBillFilter.keyField === "Movedate") {
									value1 = oBillFilter.value1;
									var tzOffsetFromDateMs = value1.getTimezoneOffset() * 60 * 1000,
										fromDateMs = value1.getTime() - tzOffsetFromDateMs;
									value1 = JSON.stringify(new Date(fromDateMs)).replace(/\"/g, "");

									if (value2 !== undefined && value2 !== null && value2 !== "") {
										if (value2.length > 0) {
											value2 = oBillFilter.value2;
											var tzOffsetFromDateMs1 = value2.getTimezoneOffset() * 60 * 1000,
												fromDateMs1 = value2.getTime() - tzOffsetFromDateMs1;
											value2 = JSON.stringify(new Date(fromDateMs1)).replace(/\"/g, "");
										}
									}
								}
							} else {
								keyField = oControl.getName();
								opt = "EQ";
								value1 = item.getKey();
								if (keyField === "Plant") {
									value1 = value1.toUpperCase();
								}
								if (keyField === "Movedate") {
									var tzOffsetFromDateMs2 = new Date(value1).getTimezoneOffset() * 60 * 1000,
										fromDateMs2 = new Date(value1).getTime() - tzOffsetFromDateMs2;
									value1 = JSON.stringify(new Date(fromDateMs2)).replace(/\"/g, "");
								}
							}
							aFilters.push(new Filter({
								path: keyField,
								operator: opt,
								value1: value1,
								value2: value2
							}));
						});
						aResult.push(new Filter({
							filters: aFilters,
							and: false
						}));
					}
					return aResult;
				}, []);
				var sFilters = [new Filter({
					filters: aTableFilters,
					and: true
				})];
				if (aTableFilters.length === 0) {
					sFilters = [];
				}
				var sModel = this.getOwnerComponent().getModel();
				sModel.read("/ZCDSV_PTP_NONCNFMAT", {
					filters: sFilters,
					success: function(oData, res) {
						if (res.statusCode === 200 || res.statusCode === "200") {
							busyDialog.close();
							var oModel = new JSONModel(oData);
							that.getView().setModel(oModel, "dataModel");
							that.getModel("worklistView").setProperty("/tableCount", oData.results.length);
							that.onQuantitySort();
							if (that.matd === "A") {
								that.onQuantityCustomItemSelect();
							}

						} else {
							var oModel1 = new JSONModel(oData);
							that.getView().setModel(oModel1, "dataModel");
							that.getModel("worklistView").setProperty("/tableCount", "0");
						}
					},
					error: function() {
						busyDialog.close();
					}
				});

			}

		},
		onSendMailPress: function(oEvent) {
			var busyDialogMesg = new sap.m.BusyDialog({
				text: "Sending email please wait..."
			});
			busyDialogMesg.open();
			var oTable = oEvent.getSource().getParent();
			var oContext = oTable.getBindingContext("dataModel");
			var sObj = oContext.getObject();
			var itemArray = [{
				Action: "SEMAIL",
				Matdocno: sObj.Matdocno,
				BELNR: sObj.BELNR,
				Refno: sObj.Refno,
				Movedate: sObj.Movedate,
				Matdocdate: sObj.Matdocdate,
				BUDAT: sObj.BUDAT
			}];

			// Service call
			var sServiceUrl = "/sap/opu/odata/sap/ZPTP_SB_NONCNFMAT/";
			var oModel = new sap.ui.model.odata.ODataModel(sServiceUrl);
			var oEntry = {
				"Plant": "US01",
				"to_items": itemArray
			};

			oModel.create("/ZPTP_NONCNFMAT_HEAD", oEntry, {
				success: function(oData, res) {
					busyDialogMesg.close();
					if (res.statusCode === "201" || res.statusCode === 201) {
						sap.m.MessageBox.success("Email sent succesfully");
					}
				},
				error: function() {
					busyDialogMesg.close();
					var oMessage = "Email sent failed!";
					sap.m.MessageBox.show(oMessage, {
						icon: sap.m.MessageBox.Icon.Error,
						title: "Error"
					});
				}
			});
		},

		/**
		 * Event handler when a table item gets pressed
		 * @param {sap.ui.base.Event} oEvent the table selectionChange event
		 * @public
		 */
		onPress: function(oEvent) {
			// The source is the list item that got pressed
			this._showObject(oEvent.getSource());
		},

		/**
		 * Event handler when the share in JAM button has been clicked
		 * @public
		 */
		onShareInJamPress: function() {
			var oViewModel = this.getModel("worklistView"),
				oShareDialog = sap.ui.getCore().createComponent({
					name: "sap.collaboration.components.fiori.sharing.dialog",
					settings: {
						object: {
							id: location.href,
							share: oViewModel.getProperty("/shareOnJamTitle")
						}
					}
				});
			oShareDialog.open();
		},

		onSearch: function(oEvent) {
			if (oEvent.getParameters().refreshButtonPressed) {
				// Search field's 'refresh' button has been pressed.
				// This is visible if you select any master list item.
				// In this case no new search is triggered, we only
				// refresh the list binding.
				this.onRefresh();
			} else {
				var aTableSearchState = [];
				var sQuery = oEvent.getParameter("query");

				if (sQuery && sQuery.length > 0) {
					aTableSearchState = [new Filter("MatDesc", FilterOperator.Contains, sQuery)];
				}
				this._applySearch(aTableSearchState);
			}

		},

		/**
		 * Event handler for refresh event. Keeps filter, sort
		 * and group settings and refreshes the list binding.
		 * @public
		 */
		onRefresh: function() {
			var oTable = this.byId("table");
			oTable.getBinding("items").refresh();
		},

		/* =========================================================== */
		/* internal methods                                            */
		/* =========================================================== */

		/**
		 * Shows the selected item on the object page
		 * On phones a additional history entry is created
		 * @param {sap.m.ObjectListItem} oItem selected Item
		 * @private
		 */
		_showObject: function(oItem) {
			this.getRouter().navTo("object", {
				objectId: oItem.getBindingContext().getProperty("Material")
			});
		},

		/**
		 * Internal helper method to apply both filter and search state together on the list binding
		 * @param {sap.ui.model.Filter[]} aTableSearchState An array of filters for the search
		 * @private
		 */
		_applySearch: function(aTableSearchState) {
			var oTable = this.byId("table"),
				oViewModel = this.getModel("worklistView");
			oTable.getBinding("items").filter(aTableSearchState, "Application");
			// changes the noDataText of the list in case there are no filter results
			if (aTableSearchState.length !== 0) {
				oViewModel.setProperty("/tableNoDataText", this.getResourceBundle().getText("worklistNoDataWithSearchText"));
			}
		},
		// Export Table Data Functionality
		onTableDataExport: function() {
			var that = this;
			var aCols, oRowBinding, oSettings, oSheet, oTable;
			if (!that._oTable) {
				that._oTable = that.getView().byId('table');
			}
			oTable = that._oTable;
			oRowBinding = oTable.getBinding('rows').oList;
			oRowBinding.forEach(function(item) {
				if (item.Createdon !== undefined && item.Createdon !== "" && item.Createdon !== null) {
					item.Createdon = formatter.dateFormat(item.Createdon);
				}
				if (item.Movedate !== undefined && item.Movedate !== "" && item.Movedate !== null) {
					item.Movedate = formatter.dateFormat(item.Movedate);
				}
				if (item.Matdocdate !== undefined && item.Matdocdate !== "" && item.Matdocdate !== null) {
					item.Matdocdate = formatter.dateFormat(item.Matdocdate);
				}
				if (item.BUDAT !== undefined && item.BUDAT !== "" && item.BUDAT !== null) {
					item.BUDAT = formatter.dateFormat(item.BUDAT);
				}
				if (item.PrintStatus === "X") {
					item.PrintStatus = "Printed/Completed";
				}
			});
			aCols = that.createColumnConfig();
			oSettings = {
				workbook: {
					columns: aCols,
					hierarchyLevel: 'Level'
				},
				dataSource: oRowBinding,
				fileName: 'Non Conforming Materials.xlsx',
				worker: false // We need to disable worker because we are using a MockServer as OData Service
			};

			oSheet = new Spreadsheet(oSettings);
			oSheet.build().finally(function() {
				oSheet.destroy();
			});
		},
		createColumnConfig: function() {
			var aCols = [];
			aCols.push({
				label: "Created On",
				type: EdmType.String,
				property: "Createdon"
			});
			aCols.push({
				label: "Plant",
				type: EdmType.String,
				property: "Plant"
			});
			aCols.push({
				label: "Material",
				type: EdmType.String,
				property: 'Material'
			});
			aCols.push({
				label: "Version",
				type: EdmType.String,
				property: 'Version'
			});
			aCols.push({
				label: "Material Description",
				type: EdmType.String,
				property: 'MatDesc'
			});
			aCols.push({
				label: "Move Type",
				type: EdmType.String,
				property: 'Movetype'
			});
			aCols.push({
				label: "Move Type Name",
				type: EdmType.String,
				property: 'Movetypname'
			});
			aCols.push({
				label: "Quantity",
				type: EdmType.String,
				property: 'Quantity'
			});
			aCols.push({
				label: "Sign",
				type: EdmType.String,
				property: 'Sign'
			});
			aCols.push({
				label: "UOM",
				type: EdmType.String,
				property: 'Uom'
			});
			aCols.push({
				label: "Move Date",
				type: EdmType.String,
				property: 'Movedate'
			});
			aCols.push({
				label: "Refno",
				type: EdmType.String,
				property: 'Refno'
			});
			aCols.push({
				label: "Material Doc No",
				type: EdmType.String,
				property: 'Matdocno'
			});
			aCols.push({
				label: "Material Doc Date",
				type: EdmType.String,
				property: 'Matdocdate'
			});
			aCols.push({
				label: "Storage Location",
				type: EdmType.String,
				property: 'storageloc'
			});
			aCols.push({
				label: "Invoice Doc No",
				type: EdmType.String,
				property: 'BELNR'
			});
			aCols.push({
				label: "Invoice Doc Date",
				type: EdmType.String,
				property: 'BUDAT'
			});
			aCols.push({
				label: "Print Status",
				property: 'PrintStatus'
			});

			return aCols;
		},
		/*Function for when press on  POST changes START*/
		onPostPress: function(oEvent) {
			var that = this;
			var oArr = [];
			var inValidArr = [];
			var oTable = oEvent.getSource().getParent().getParent().getSelectedIndices();
			if (oTable.length !== 0) {
				var matDocCheck = oEvent.getSource().getParent().getParent().getRows();
				var error1 = "",
					error2 = "",
					error3 = "";
				oTable.forEach(function(item) {
					// var obj = matDocCheck[item].getBindingContext("dataModel").getObject();
					var obj = oEvent.getSource().getParent().getParent().getContextByIndex(item).getObject();
					if (obj.Matdocno !== "") {
						error1 = true;
						inValidArr.push(obj);
					} else if (obj.Movetype === "ZS" && obj.seq_num === "" && obj.preseq_num === "") {
						error2 = true;
						inValidArr.push(obj);
					} else if (obj.Movetype === "ID" && obj.Sign === "H" && (obj.stprs === "0" || obj.stprs === "0.000")) {
						error3 = true;
						inValidArr.push(obj);
					} else {
						delete obj.__metadata;
						oArr.push(obj);
					}
					//    oArr.push(matDocCheck[item]);
				});
				if (inValidArr.length > 0) {
					var oMessageMove = "POST not possible with this Move type/Material Doc Number";
					if (error1 === true) {
						oMessageMove = "Please Select a Record Which are Not Already Posted!";
					} else if (error2 === true) {
						oMessageMove = "You Can't Reverse the document for Move Type ZS with no Seq,Pre Seq Number";
					} else if (error3 === true) {
						oMessageMove = "Standard Cost is Zero, Please check ";
					}
					sap.m.MessageBox.error(oMessageMove, {
						icon: sap.m.MessageBox.Icon.Error,
						title: "Error"
					});
					
					return;
				}
				if (oArr.length <= 0) {
					if (error1 === true || error2 === true || error3 === true) {
						return;
					}
					var oMessageMove1 = "Please select atleast one Valid Record";
					sap.m.MessageBox.error(oMessageMove1, {
						icon: sap.m.MessageBox.Icon.Error,
						title: "Error"
					});
					return;
				}
				// Service call
				that.busyPost.open();
				var sServiceUrl = "/sap/opu/odata/sap/ZPTP_SB_NONCNFMAT/";
				var oModelPost = new sap.ui.model.odata.v2.ODataModel(sServiceUrl);
				var oEntry = {
					"Plant": "US01",
					"Action": "POSTING",
					"to_items": oArr
				};
				oModelPost.create("/ZPTP_NONCNFMAT_HEAD", oEntry, {
					success: function(oData, res) {
						if (res.statusCode === "201" || res.statusCode === 201) {
							that.busyPost.close();
							sap.m.MessageBox.success("Post succesfully");
							that.onPressGo();
						}
					},
					error: function(error) {
						that.busyPost.close();
						// var oMsg = jQuery.parseXML(error.response.body).getElementsByTagName("message")[0].childNodes[0];
						JSON.parse(error.responseText).error.innererror.errordetails.forEach(function(sItm) {
							if (sMsg === "") {
								sMsg = sItm.message + '. ';
							} else {
								sMsg = sMsg + "" + sItm.message;
							}
						});
						//var oMsg = JSON.parse(error.responseText).error.message.value;
						sap.m.MessageBox.error(
							sMsg, {
								actions: [sap.m.MessageBox.Action.OK],
								onClose: function(sAction) {
									if (sAction === "OK") {
										// that.busyPost.close();
										sMsg = "";
									}
								}
							}
						);
					}
				});
			} else {
				var oMessage = "Please select atleast one record";
				sap.m.MessageBox.error(oMessage, {
					icon: sap.m.MessageBox.Icon.Error,
					title: "Error"
				});
			}
		},
		/*On press POST Changes END*/
		/*Function for when press Reverse Changes START*/
		onReversePress: function(oEvent) {
			var oArr = [];
			var validArr = [];
			var dialog1 = new sap.m.BusyDialog({
				text: "REVERSE Saving please wait"
			});
			var oTable = oEvent.getSource().getParent().getParent().getSelectedIndices();
			if (oTable.length !== 0) {
				var matDocCheck = oEvent.getSource().getParent().getParent().getModel("dataModel").getData().results;
				oTable.forEach(function(item) {
					if (matDocCheck[item].Matdocno === "") {
						validArr.push(matDocCheck[item]);
					} else {
						oArr.push(matDocCheck[item]);
					}
				});
				if (validArr.length > 0) {
					dialog1.close();
					var oMessageMove = "REQUEST not possible with this Move type";
					sap.m.MessageBox.show(oMessageMove, {
						icon: sap.m.MessageBox.Icon.Error,
						title: "Error"
					});
					return;
				}
				// Service call
				dialog1.open();
				var sServiceUrl = "/sap/opu/odata/sap/ZPTP_SB_NONCNFMAT/";
				var oModelPost = new sap.ui.model.odata.ODataModel(sServiceUrl);
				var oEntry = {
					"Plant": "US01",
					"Action": "REVERSE",
					"to_items": oArr
				};

				oModelPost.create("/ZPTP_NONCNFMAT_HEAD", oEntry, {
					success: function(oData, res) {
						dialog1.close();
						if (res.statusCode === "201" || res.statusCode === 201) {
							sap.m.MessageBox.success("REVERSE succesfully");
						}
					},
					error: function(error, response) {
						dialog1.close();
						var oMsg = jQuery.parseXML(error.response.body).getElementsByTagName("message")[0].childNodes[0];
						sap.m.MessageBox.show(
							oMsg.data, {
								actions: [sap.m.MessageBox.Action.OK],
								onClose: function(sAction) {
									if (sAction === "OK") {}
								}
							}
						);
					}
				});

			} else {
				dialog1.close();
				var oMessage = "Please select atleast one record";
				sap.m.MessageBox.show(oMessage, {
					icon: sap.m.MessageBox.Icon.Error,
					title: "Error"
				});
			}
		},

		onSaveTable: function(oEvent) {
			var that = this;
			// var sobj = [];
			// var oTable = that.byId("table").getColumns();
			// get variant parameters:
			var VariantParam = oEvent.getParameters();
			// get columns data: 

			var aColumnsData = [];
			that.getView().byId("table").getColumns().forEach(function(oColumn, index) {
				var aColumn = {};
				aColumn.fieldName = oColumn.getAggregation("label").getProperty("text");
				aColumn.Id = oColumn.getId();
				aColumn.index = index;
				aColumn.Visible = oColumn.getVisible();
				aColumnsData.push(aColumn);
			});

			that.oVariant = that.oVariantSet.addVariant(VariantParam.name);
			if (that.oVariant) {
				that.oVariant.setItemValue("ColumnsVal", JSON.stringify(aColumnsData));
				if (VariantParam.def === true) {
					that.oVariantSet.setCurrentVariantKey(that.oVariant.getVariantKey());
				}
				that.oContainer.save().done(function() {
					// Tell the user that the personalization data was saved
				});
			}

		},
		//---------------------------------------------------------------------------//
		/* Upon selecting a variant*/
		onSelect: function(e) {
			var t = e.getParameters().key;
			for (var a = 0; a < e.getSource().getVariantItems().length; a++) {
				if (e.getSource().getVariantItems()[a].getProperty("key") === t) {
					var i = e.getSource().getVariantItems()[a].getProperty("text");
					break;
				}
			}
			this._setSelectedVariantToTable(i);
		},
		//---------------------------------------------------------------------------//
		/* Applying a variant to the table*/
		_setSelectedVariantToTable: function(oSelectedVariant) {
			var that = this;
			if (oSelectedVariant) {
				var sVariant = that.oVariantSet.getVariant(that.oVariantSet.getVariantKeyByName(oSelectedVariant));
				var aColumns = JSON.parse(sVariant.getItemValue("ColumnsVal"));

				// Hide all columns first
				that.getView().byId("table").getColumns().forEach(function(oColumn) {
					oColumn.setVisible(false);
				});
				// re-arrange columns according to the saved variant

				aColumns.forEach(function(aColumn) {
					var aTableColumn = $.grep(that.getView().byId("table").getColumns(), function(el, id) {
						return el.getAggregation("label").getText() === aColumn.fieldName;
					});
					if (aTableColumn.length > 0) {
						aTableColumn[0].setVisible(aColumn.Visible);
						that.getView().byId("table").removeColumn(aTableColumn[0]);
						that.getView().byId("table").insertColumn(aTableColumn[0], aColumn.index);
					}
				}.bind(that));
			}
			// null means the standard variant is selected or the variant which is not available, then show all columns
			else {
				that.getView().byId("table").getColumns().forEach(function(oColumn) {
					oColumn.setVisible(true);
				});
			}
		},
		//---------------------------------------------------------------------------//
		/* On Managing variants*/
		onManage: function(oEvent) {
			var that = this;
			var aParameters = oEvent.getParameters();
			// rename variants
			if (aParameters.renamed.length > 0) {
				aParameters.renamed.forEach(function(aRenamed) {
					var sVariant = that.oVariantSet.getVariant(aRenamed.key),
						sItemValue = sVariant.getItemValue("ColumnsVal");
					// delete the variant 
					that.oVariantSet.delVariant(aRenamed.key);
					// after delete, add a new variant
					var oNewVariant = that.oVariantSet.addVariant(aRenamed.name);
					oNewVariant.setItemValue("ColumnsVal", sItemValue);
				}.bind(that));
			}
			// default variant change
			if (aParameters.def !== "*standard*") {
				that.oVariantSet.setCurrentVariantKey(aParameters.def);
			} else {
				that.oVariantSet.setCurrentVariantKey(null);
			}
			// Delete variants
			if (aParameters.deleted.length > 0) {
				aParameters.deleted.forEach(function(aDelete) {
					that.oVariantSet.delVariant(aDelete);
				}.bind(that));
			}
			//  Save the Variant Container
			that.oContainer.save().done(function() {
				// Tell the user that the personalization data was saved
			});
		},
		/*On press Reverse Changes END*/
		//---------------------------------------------------------------------------//
		/* Before the view is rendered*/

		onBeforeRendering: function() {
			var that = this;
			if (sap.ushell && sap.ushell.Container && sap.ushell.Container.getService) {

				var oComponent = sap.ui.core.Component.getOwnerComponentFor(that.getView());
				that.oPersonalizationService = sap.ushell.Container.getService("Personalization");
				var oPersId = {
					container: "TablePersonalisation",
					item: "table"
				};
				// define scope 
				var oScope = {
					keyCategory: that.oPersonalizationService.constants.keyCategory.FIXED_KEY,
					writeFrequency: that.oPersonalizationService.constants.writeFrequency.LOW,
					clientStorageAllowed: true
				};
				// Get a Personalizer
				var oPersonalizer = that.oPersonalizationService.getPersonalizer(oPersId, oScope, oComponent);
				that.oPersonalizationService.getContainer("TablePersonalisation", oScope, oComponent)
					.fail(function() {})
					.done(function(oContainer) {
						that.oContainer = oContainer;
						that.oVariantSetAdapter = new sap.ushell.services.Personalization.VariantSetAdapter(that.oContainer);
						// get variant set which is stored in backend
						that.oVariantSet = that.oVariantSetAdapter.getVariantSet("table");
						if (!that.oVariantSet) { //if not in backend, then create one
							that.oVariantSet = that.oVariantSetAdapter.addVariantSet("table");
						}
						// array to store the existing variants
						var Variants = [];
						// now get the existing variants from the backend to show as list
						for (var key in that.oVariantSet.getVariantNamesAndKeys()) {
							if (that.oVariantSet.getVariantNamesAndKeys().hasOwnProperty(key)) {
								var oVariantItemObject = {};
								oVariantItemObject.Key = that.oVariantSet.getVariantNamesAndKeys()[key];
								oVariantItemObject.Name = key;
								Variants.push(oVariantItemObject);
							}
						}
						this.oVariantListModel = new sap.ui.model.json.JSONModel();
						this.oVariantListModel.setData(Variants);
						this.getOwnerComponent().setModel(this.oVariantListModel, "VariantList");
						// create JSON model and attach to the variant management UI control
						that.oVariantModel = new sap.ui.model.json.JSONModel();
						that.oVariantModel.oData.Variants = Variants;
						that.getView().byId("Variants").setModel(that.oVariantModel);
					}.bind(that));

				// // create table persco controller
				that.oTablepersoService = new TablePersoController({
					table: that.getView().byId("table"),
					persoService: oPersonalizer
				});

			}
		},
		//---------------------------------------------------------------------------//
		/*When Press on Material Link -- START*/
		onMatPress: function(oEvent) {
			var oCrossAppNavigator = sap.ushell.Container.getService("CrossApplicationNavigation");
			var Material = oEvent.getSource().getText();
			/*	oCrossAppNavigator.toExternal({
					target: {
						semanticObject: "ZMM03SOBJ",
						action: "display"
					}, //App that you're navigating to
					params: {
						"Material": Material
					}
				}); */

			var hash = oCrossAppNavigator.hrefForExternal({
				target: {
					semanticObject: "ZMM03SOBJ",
					action: "display"
				}, //App that you're navigating to
				params: {
					"Material": Material
				}
			});

			var url = window.location.href.split('#')[0] + hash;
			sap.m.URLHelper.redirect(url, true);
		},
		/*When Press on Material Link -- END*/
		/*When Press on Material-Document Link -- START*/
		onMatDocNumPress: function(oEvent) {
			var oCrossAppNavigator = sap.ushell.Container.getService("CrossApplicationNavigation");
			var materialDocVal = oEvent.getSource().getText();
			var hash = oCrossAppNavigator.hrefForExternal({
				target: {
					semanticObject: "ZMIGOSOBJ",
					action: "display"
				}, //App that you're navigating to
				params: {
					"MAT_DOC": materialDocVal
				}
			});

			var url = window.location.href.split('#')[0] + hash;
			sap.m.URLHelper.redirect(url, true);

		},
		/*When Press on Material-Document Link -- END*/
		onQuantityCustomItemSelect: function() {
			var that = this,
				filters = [];
			var oTable = that.getView().byId("table");
			var oFilter1 = new sap.ui.model.Filter("Matdocno", sap.ui.model.FilterOperator.EQ, "");
			filters = [oFilter1];
			var oBinding = oTable.getBinding("rows");
			oBinding.filter(filters);
			that.getView().getModel("worklistView").updateBindings(true);
		},
		onQuantitySort: function(oEvent) {
			var that = this;
			// var bAdd = oEvent.getParameter("ctrlKey") === true;
			var oColumn = that.byId("idMovDate");
			var sOrder = oColumn.getSortOrder() === "Ascending" ? "Descending" : "Ascending";
			that.byId("table").sort(oColumn, sOrder, true);
		}
	});
});