sap.ui.define([
		"ZPTP_NON_CONFMAT/controller/BaseController"
	], function (BaseController) {
		"use strict";

		return BaseController.extend("ZPTP_NON_CONFMAT.controller.NotFound", {

			/**
			 * Navigates to the worklist when the link is pressed
			 * @public
			 */
			onLinkPressed : function () {
				this.getRouter().navTo("worklist");
			}

		});

	}
);