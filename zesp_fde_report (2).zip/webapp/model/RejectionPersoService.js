jQuery.sap.require("jquery.sap.resources");
sap.ui.define(['jquery.sap.global'],
	function(jQuery) {
		"use strict";

		// Very simple page-context personalization
		// persistence service, not for productive use!
		var RejectionPersoService = {

			oData: {
				_persoSchemaVersion: "1.0",
				aColumns: [{
						id: "rejectApp-table-location",
						order: 1,
						text: "Location",
						visible: true
					}, {
						id: "rejectApp-table-rejtrailId",
						order: 2,
						text: "Trailer ID",
						visible: true
					}, {
						id: "rejectApp-table-delivery",
						order: 3,
						text: "Delivery",
						visible: true
					}, {
						id: "rejectApp-table-RejectionRepPlant",
						order: 4,
						text: "Plant",
						visible: true
					},

					{
						id: "rejectApp-table-blockDate",
						order: 5,
						text: "Block Date",
						visible: true
					}, {
						id: "rejectApp-table-unblockDate",
						order: 6,
						text: "Unblock Date",
						visible: false
					}, {
						id: "rejectApp-table-rejectDate",
						order: 7,
						text: "Rejection Date",
						visible: true
					}, {
						id: "rejectApp-table-userID",
						order: 8,
						text: "User ID",
						visible: true
					}, {
						id: "rejectApp-table-failCheckQues",
						order: 9,
						text: "Failed Checklist Questions",
						visible: true
					}, {
						id: "rejectApp-table-reasonChecklist",
						order: 10,
						text: "Reason entered on checklist",
						visible: true
					}, {
						id: "rejectApp-table-comments",
						order: 11,
						text: "Comments",
						visible: true
					}
				]
			},

			getPersData: function() {
				var oDeferred = new jQuery.Deferred();
				if (!this._oBundle) {
					this._oBundle = this.oData;
				}
				var oBundle = this._oBundle;
				oDeferred.resolve(oBundle);
				return oDeferred.promise();
			},

			setPersData: function(oBundle) {
				var oDeferred = new jQuery.Deferred();
				this._oBundle = oBundle;
				oDeferred.resolve();
				return oDeferred.promise();
			},

			resetPersData: function() {
				var oDeferred = new jQuery.Deferred();
				var oInitialData = {
					_persoSchemaVersion: "1.0",
					aColumns: [{
							id: "rejectApp-table-location",
							order: 0,
							text: "Location",
							visible: true
						}, {
							id: "rejectApp-table-rejtrailId",
							order: 1,
							text: "Trailer ID",
							visible: true
						}, {
							id: "rejectApp-table-delivery",
							order: 4,
							text: "Delivery",
							visible: true
						}, {
							id: "rejectApp-table-RejectionRepPlant",
							order: 1,
							text: "Plant",
							visible: true
						},

						{
							id: "rejectApp-table-blockDate",
							order: 2,
							text: "Block Date",
							visible: true
						}, {
							id: "rejectApp-table-unblockDate",
							order: 3,
							text: "Unblock Date",
							visible: true
						}, {
							id: "rejectApp-table-rejectDate",
							order: 0,
							text: "Rejection Date",
							visible: true
						}, {
							id: "rejectApp-table-userID",
							order: 1,
							text: "User ID",
							visible: true
						}, {
							id: "rejectApp-table-failCheckQues",
							order: 4,
							text: "Failed Checklist Questions",
							visible: true
						}, {
							id: "rejectApp-table-reasonChecklist",
							order: 2,
							text: "Reason entered on checklist",
							visible: true
						}, {
							id: "rejectApp-table-comments",
							order: 3,
							text: "Comments",
							visible: true
						}
					]
				};

				//set personalization
				this._oBundle = oInitialData;

				//reset personalization, i.e. display table as defined
				//		this._oBundle = null;

				oDeferred.resolve();
				return oDeferred.promise();
			},

			//this caption callback will modify the TablePersoDialog' entry for the 'Weight' column
			//to 'Weight (Important!)', but will leave all other column names as they are.
			getCaption: function(oColumn) {
				if (oColumn.getHeader() && oColumn.getHeader().getText) {
					if (oColumn.getHeader().getText() === "Weight") {
						return "Weight (Important!)";
					}
				}
				return null;
			},

			getGroup: function(oColumn) {
				var that = this;
				var lang = sap.ui.getCore().getConfiguration().getLanguage();
				var propFile = $.sap.getModulePath("com.report", "/i18n/");
				var propData = propFile + "i18n_" + lang + ".properties";
				var oBundle = jQuery.sap.resources({
					url: propData, //"i18n/i18n.properties",
					locale: sap.ui.getCore().getConfiguration().getLanguage()
				});
				var pgroup = oBundle.getText("pgroup");
				var sgroup = oBundle.getText("sgroup");
				if (oColumn.getId().indexOf('Action') !== -1 || oColumn.getId().indexOf('updateTime') !== -1) {
					return pgroup;
				}
				return sgroup;
			}

			// getGroup: function(oColumn) {
			// 	if (oColumn.getId().indexOf('blockDate') != -1 || oColumn.getId().indexOf('unblockDate') != -1 ||
			// 		oColumn.getId().indexOf('rejectDate') != -1 ) {
			// 		return "Primary Group";
			// 	}
			// 	return "Secondary Group";
			// }
		};

		return RejectionPersoService;

	}, /* bExport= */ true);