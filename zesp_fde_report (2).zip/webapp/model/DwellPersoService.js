jQuery.sap.require("jquery.sap.resources");
sap.ui.define(['jquery.sap.global'],
	function(jQuery) {
		"use strict";

		// Very simple page-context personalization
		// persistence service, not for productive use!
		var DwellPersoService = {

			oData: {
				_persoSchemaVersion: "1.0",
				aColumns: [{
					id: "dwellApp-table-contId",
					order: 1,
					text: "Container ID",
					visible: true
				}, {
					id: "dwellApp-table-scacCarrier",
					order: 2,
					text: "Carrier",
					visible: true
				}, {
					id: "dwellApp-table-type",
					order: 3,
					text: "Type",
					visible: true
				}, {
					id: "dwellApp-table-dwellTime",
					order: 4,
					text: "Dwell Time",
					visible: true
				}, {
					id: "dwellApp-table-checkInStamp",
					order: 5,
					text: "Check-in Timestamp",
					visible: true
				}, {
					id: "dwellApp-table-checkOutStamp",
					order: 6,
					text: "Checkout Timestamp",
					visible: true
				}, {
					id: "dwellApp-table-ibDel",
					order: 7,
					text: "IB Delivery",
					visible: true
				}, {
					id: "dwellApp-table-drivName",
					order: 8,
					text: "Driver Name",
					visible: true
				}, {
					id: "dwellApp-table-obDel",
					order: 9,
					text: "OB Delivery",
					visible: true
				}, {
					id: "dwellApp-table-drivNameOb",
					order: 10,
					text: "Driver Name",
					visible: true
				}, {
					id: "dwellApp-table-dwellRepPlant",
					order: 11,
					text: "Plant",
					visible: true
				}, {
					id: "dwellApp-table-appTime",
					order: 12,
					text: "Appointment Time",
					visible: true
				}, {
					id: "dwellApp-table-planGIdate",
					order: 13,
					text: "Planned GI Date",
					visible: true
				}, {
					id: "dwellApp-table-doorArrivTime",
					order: 14,
					text: "Door Arrival Time",
					visible: true
				}, {
					id: "dwellApp-table-parkTime",
					order: 15,
					text: "Park Time",
					visible: true
				}, {
					id: "dwellApp-table-dwellRegNum",
					order: 16,
					text: "Reg Num",
					visible: true
				}, {
					id: "dwellApp-table-trailtype",
					order: 17,
					text: "Trailer Type",
					visible: true
				}, {
					id: "dwellApp-table-checkinSysDwell",
					order: 18,
					text: "Check In System",
					visible: true
				}, {
					id: "dwellApp-table-checkoutSysDwell",
					order: 19,
					text: "Check Out System",
					visible: true
				}]
			},

			getPersData: function() {
				var oDeferred = new jQuery.Deferred();
				if (!this._oBundle) {
					this._oBundle = this.oData;
				}
				var oBundle = this._oBundle;
				oDeferred.resolve(oBundle);
				return oDeferred.promise();
			},

			setPersData: function(oBundle) {
				var oDeferred = new jQuery.Deferred();
				this._oBundle = oBundle;
				oDeferred.resolve();
				return oDeferred.promise();
			},

			resetPersData: function() {
				var oDeferred = new jQuery.Deferred();
				var oInitialData = {
					_persoSchemaVersion: "1.0",
					aColumns: [{
						id: "dwellApp-table-contId",
						order: 0,
						text: "Container ID",
						visible: true
					}, {
						id: "dwellApp-table-scacCarrier",
						order: 1,
						text: "Carrier",
						visible: false
					}, {
						id: "dwellApp-table-type",
						order: 4,
						text: "Type",
						visible: false
					}, {
						id: "dwellApp-table-dwellTime",
						order: 2,
						text: "Dwell Time",
						visible: true
					}, {
						id: "dwellApp-table-checkInStamp",
						order: 3,
						text: "Check-in Timestamp",
						visible: true
					}, {
						id: "dwellApp-table-checkOutStamp",
						order: 0,
						text: "Checkout Timestamp",
						visible: true
					}, {
						id: "dwellApp-table-ibDel",
						order: 1,
						text: "IB Delivery",
						visible: false
					}, {
						id: "dwellApp-table-drivName",
						order: 4,
						text: "Driver Name",
						visible: false
					}, {
						id: "dwellApp-table-obDel",
						order: 2,
						text: "OB Delivery",
						visible: true
					}, {
						id: "dwellApp-table-drivNameOb",
						order: 3,
						text: "Driver Name",
						visible: true
					}, {
						id: "dwellApp-table-dwellRepPlant",
						order: 1,
						text: "Plant",
						visible: true
					}, {
						id: "dwellApp-table-appTime",
						order: 0,
						text: "Appointment Time",
						visible: true
					}, {
						id: "dwellApp-table-planGIdate",
						order: 1,
						text: "Planned GI Date",
						visible: false
					}, {
						id: "dwellApp-table-doorArrivTime",
						order: 4,
						text: "Door Arrival Time",
						visible: false
					}, {
						id: "dwellApp-table-parkTime",
						order: 2,
						text: "Park Time",
						visible: true
					}, {
						id: "dwellApp-table-dwellRegNum",
						order: 3,
						text: "Reg Num",
						visible: true
					}, {
						id: "dwellApp-table-trailtype",
						order: 3,
						text: "Trailer Type",
						visible: true
					}, {
						id: "dwellApp-table-checkinSysDwell",
						order: 2,
						text: "Check In System",
						visible: true
					}, {
						id: "dwellApp-table-checkoutSysDwell",
						order: 4,
						text: "Check Out System",
						visible: true
					}]
				};

				//set personalization
				this._oBundle = oInitialData;

				//reset personalization, i.e. display table as defined
				//		this._oBundle = null;

				oDeferred.resolve();
				return oDeferred.promise();
			},

			//this caption callback will modify the TablePersoDialog' entry for the 'Weight' column
			//to 'Weight (Important!)', but will leave all other column names as they are.
			getCaption: function(oColumn) {
				if (oColumn.getHeader() && oColumn.getHeader().getText) {
					if (oColumn.getHeader().getText() === "Weight") {
						return "Weight (Important!)";
					}
				}
				return null;
			},

			getGroup: function(oColumn) {
				var that = this;
				var lang = sap.ui.getCore().getConfiguration().getLanguage();
				var propFile = $.sap.getModulePath("com.report", "/i18n/");
				var propData = propFile + "i18n_" + lang + ".properties";
				var oBundle = jQuery.sap.resources({
					url: propData, //"i18n/i18n.properties",
					locale: sap.ui.getCore().getConfiguration().getLanguage()
				});
				var pgroup = oBundle.getText("pgroup");
				var sgroup = oBundle.getText("sgroup");
				if (oColumn.getId().indexOf('contId') != -1 || oColumn.getId().indexOf('scacCarrier') != -1 ||
					oColumn.getId().indexOf('type') != -1) {
					return pgroup;
				}
				return sgroup;
			}

			// getGroup: function(oColumn) {
			// 	if (oColumn.getId().indexOf('contId') != -1 || oColumn.getId().indexOf('scacCarrier') != -1 ||
			// 		oColumn.getId().indexOf('type') != -1) {
			// 		return "Primary Group";
			// 	}
			// 	return "Secondary Group";
			// }
		};

		return DwellPersoService;

	}, /* bExport= */ true);