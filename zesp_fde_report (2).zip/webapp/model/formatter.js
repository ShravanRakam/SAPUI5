var liveCount = 0;
var DnHCount = 0;

sap.ui.define([], function() {
	"use strict";

	var formatter = {

		IssueReturn: function(sStatus, delvtype) {
			if (delvtype === "" || delvtype === undefined) {
				if (sStatus === "01") {
					return "Issue";
				} else if (sStatus === "02") {
					return "Return";
				} else if (sStatus === "03") {
					return "Raw Material PO";
				} else if (sStatus === "04") {
					return "STO-Issue";
				} else if (sStatus === "05") {
					return "STO-Return";
				}
			} else {
				return delvtype;
			}
		},

		Quantity: function(sQty) {

			if (sQty) {
				return parseInt(sQty);
			}
		},

		calDwellTime: function(dwellTime, Region) {

			if (dwellTime !== "") {
				var sdwellTimeFormat;
				var day = parseInt(dwellTime / (24 * 3600));

				dwellTime = dwellTime % (24 * 3600);
				var hour = parseInt(dwellTime / 3600);

				dwellTime %= 3600;
				var minutes = parseInt(dwellTime / 60);
				if (Region === "EU" || Region === "LATAM" || Region === "ZA") {
					if (hour < 10) {
						hour = '0' + hour;
					}
					if (minutes < 10) {
						minutes = '0' + minutes;
					}
					sdwellTimeFormat = day + " "+":" + " " + hour  + " "+":" +" " +" " + minutes ;
				} else {

					sdwellTimeFormat = day + " days " + hour + " hrs " + minutes + " min ";
				}
				return sdwellTimeFormat;
			}
		},

		calTimeTaken: function(timeTaken) {
			if (timeTaken === "ONGOING") {
				return "ONGOING";
			} else if (timeTaken === "PLANNED") {
				return "PLANNED";
				// } 	if (timeTaken !== "ONGOING" || timeTaken !== "PLANNED") {
			} else if (timeTaken === "DELETED") {
				return "DELETED";
				// } 	if (timeTaken !== "ONGOING" || timeTaken !== "PLANNED") {
			} else {
				var day = parseInt(timeTaken / (24 * 3600));

				timeTaken = timeTaken % (24 * 3600);
				var hour = parseInt(timeTaken / 3600);

				timeTaken %= 3600;
				var minutes = parseInt(timeTaken / 60);

				var stimeTakenFormat = day + " days " + hour + " hrs " + minutes + " min ";
				return stimeTakenFormat;
			}
		},

		DwellTimeInHrs: function(dwellinhrs) {
			var sDaysHours = dwellinhrs.split(":");
			//	var sDays = sDaysHours[0] + " days ";
			//	var sHours = sDaysHours[1].substr(0, 2) + " hrs " + sDaysHours[1].substr(2, 2) + " min ";
			var minConersion = parseInt(parseInt(sDaysHours[0]) * 1440 +
				parseInt(sDaysHours[1].substr(0, 2)) * 60 +
				parseInt(sDaysHours[1].substr(2, 2)));

			return minConersion;
		},

		calculateDiffTimeAvg: function(outTime, inTime) {
			var sCheckOutTime = outTime.substr(0, 4) + " " + outTime.substr(4, 2) + " " + outTime.substr(6, 2) + " " + outTime.substr(8, 2) +
				":" +
				outTime
				.substr(10, 2) + ":" + outTime.substr(12);

			var sCheckInTime = inTime.substr(0, 4) + " " + inTime.substr(4, 2) + " " + inTime.substr(6, 2) + " " + inTime.substr(8, 2) + ":" +
				inTime
				.substr(10, 2) + ":" + inTime.substr(12);

			// console.log(data);

			var date1, date2;

			date1 = new Date(sCheckOutTime);
			date2 = new Date(sCheckInTime);

			var seconds = (date2.getTime() - date1.getTime()) / 1000;
			return seconds;

			//	var res = Math.abs(date1 - date2) / 1000;
			// get total days between two dates
			/*	var days = Math.floor(res / 86400);
			// get hours        
			var hours = Math.floor(res / 3600) % 24;
			// get minutes
			var minutes = Math.floor(res / 60) % 60;
			// get seconds
			var seconds = res % 60;

			var totalSec = (days * 24 * 60 * 60) + (hours * 60 * 60) + (minutes * 60) + seconds;*/

			//	return days + " days " + hours + " hrs " + minutes + " min ";
		},

		// calDwellTime: function(outTime, inTime) {

		// 	var sCheckOutTime = outTime.substr(0, 4) + " " + outTime.substr(4, 2) + " " + outTime.substr(6, 2) + " " + outTime.substr(8, 2) + ":" +
		// 		outTime
		// 		.substr(10, 2) + ":" + outTime.substr(12);

		// 	var sCheckInTime = inTime.substr(0, 4) + " " + inTime.substr(4, 2) + " " + inTime.substr(6, 2) + " " + inTime.substr(8, 2) + ":" +
		// 		inTime
		// 		.substr(10, 2) + ":" + inTime.substr(12);

		// 	// console.log(data);

		// 	var date1, date2;

		// 	date1 = new Date(sCheckOutTime);
		// 	date2 = new Date(sCheckInTime);
		// 	var res = Math.abs(date1 - date2) / 1000;
		// 	// get total days between two dates
		// 	var days = Math.floor(res / 86400);
		// 	// get hours        
		// 	var hours = Math.floor(res / 3600) % 24;
		// 	// get minutes
		// 	var minutes = Math.floor(res / 60) % 60;
		// 	// get seconds
		// 	// var seconds = res % 60;

		// 	//	console.log(this.getOwnerComponent());
		// 	jQuery.sap.require("jquery.sap.storage");
		// 	jQuery.sap.storage(jQuery.sap.storage.Type.local).put("total", "500");

		// 	return days + " days " + hours + " hrs " + minutes + " min ";

		// },

		InBoundDelivery: function(indelivery, delNumIn) {
			if (indelivery === "SAPR") {
				return delNumIn;
			}
		},

		driverNameIn: function(orderTypeIn, nameIn) {
			if (orderTypeIn === "SAPR") {
				return nameIn;
			}
		},

		OutBoundDelivery: function(outdelivery, delNumOut) {
			if (outdelivery === "SAPI") {
				return delNumOut;
			}
		},

		driverNameOut: function(orderTypeOut, nameOut) {
			if (orderTypeOut === "SAPI") {
				return nameOut;
			}
		},
		changeDateFormat: function(dt, Region) {

			if (Region === "EU" || Region === "LATAM" || Region === "ZA") {
				if (dt !== null) {
					if (dt !== "00000000") {
						var sDate = dt.slice(6, 8) + "/" + dt.slice(4, 6) + "/" + dt.slice(0, 4);
						return sDate;
					} else {
						return "";
					}
				}
			} else {

				if (Region === undefined) {
					if (dt !== "00000000") {
						var sDate1 = dt.slice(6, 8) + "/" + dt.slice(4, 6) + "/" + dt.slice(0, 4);
						return sDate1;
					} else {
						return "";
					}
				} else {

					if (dt !== null) {
						var date = dt.slice(0, 4) + "," + dt.slice(4, 6) + "," + dt.slice(6, 8);
						// console.log(date);
						var localtime = new Date(date);

						var dateFormat = sap.ui.core.format.DateFormat.getDateInstance({
							pattern: "dd MMM YYYY"
						});

						var dateFormatted = dateFormat.format(new Date(localtime));
						return dateFormatted;
					}
				}
			}

		},
		changeTimeFormat: function(time) {

			time = time.trim();
			if (time !== null && time !== "0" && time !== undefined) {
				var newAppoinTime = time.slice(0, 4) + "-" + time.slice(4, 6) + "-" + time.slice(6, 8) + " " + time.slice(8, 10) + ":" + time.slice(
					10, 12) + ":" + time.slice(12, 14);

				var localtime = new Date(newAppoinTime);

				var dateFormat = sap.ui.core.format.DateFormat.getDateInstance({
					pattern: "dd MMM YYYY hh:mm:ss a"
				});

				var TimeFormatted = dateFormat.format(new Date(localtime));
				return TimeFormatted;
			}
			return time;

		},

		ChangeOrderType: function(orderType, delvtype) {
			if (delvtype === "" || delvtype === undefined) {
				if ((orderType === "SAPI")) {
					return "Issue";
				} else if (orderType === "STOI") {
					return "STO-Issue";
				} else if (orderType === "SAPR") {
					return "Return";
				} else if (orderType === "STOR") {
					return "STO-Return";
				} else if (orderType === "PORAW") {
					return "Raw Material PO";
				}
			} else {
				return delvtype;
			}
		},

		PlannedQuantity: function(planqty) {
			return parseInt(planqty);
		},

		Variance: function(variance) {
			// var oString = variance.includes("-");

			// if (oString === true) {
			// 	var sVar = variance.split("-");
			// 	var sVariance = "-" + sVar[0];
			// 	return sVariance;
			// } else {
			// 	return variance;
			// }
			if (variance !== "" && variance !== null) {
				if (variance && variance.includes("-")) {
					if (variance.charAt(0) !== "-") {
						var sVariance = variance.trim().split("-");
						var newVariance = "-" + sVariance[0];
					}
					return newVariance;
				} else {
					return variance;
				}
			}

		},

		BlockDate: function(blckdate) {
			// 20180918090102
			blckdate = blckdate.trim();
			if (blckdate !== null && blckdate !== "0" && blckdate !== undefined) {
				var newBlockDate = blckdate.slice(4, 6) + "/" + blckdate.slice(6, 8) + "/" + blckdate.slice(0, 4) + " " + blckdate.slice(8, 10) +
					":" +
					blckdate.slice(10, 12) + ":" + blckdate.slice(12, 14);
				return newBlockDate;
			}
		},

		UnBlockDate: function(unblckdate) {
			unblckdate = unblckdate.trim();
			if (unblckdate !== null && unblckdate !== "0" && unblckdate !== undefined) {
				var newUnBlockDate = unblckdate.slice(4, 6) + "/" + unblckdate.slice(6, 8) + "/" + unblckdate.slice(0, 4) + " " + unblckdate.slice(
						8,
						10) + ":" +
					unblckdate.slice(10, 12) + ":" + unblckdate.slice(12, 14);
				return newUnBlockDate;
			}
		},

		RejectionDate: function(rejectdate) {
			rejectdate = rejectdate.trim();
			if (rejectdate !== null && rejectdate !== "0" && rejectdate !== undefined) {
				var newRejectionDate = rejectdate.slice(4, 6) + "/" + rejectdate.slice(6, 8) + "/" + rejectdate.slice(0, 4) + " " + rejectdate.slice(
						8, 10) + ":" +
					rejectdate.slice(10, 12) + ":" + rejectdate.slice(12, 14);
				return newRejectionDate;
			}
		},
		UpdateTime: function(updatetime, Region) {
			// 20180918090102
			updatetime = updatetime.trim();
			if (Region === "EU" || Region === "LATAM" || Region === "ZA") {
				var sNewParkTime;
				if (updatetime !== null && updatetime !== "0" && updatetime !== undefined) {
					sNewParkTime = updatetime.slice(6, 8) + "/" + updatetime.slice(4, 6) + "/" + updatetime.slice(0, 4) + " " + updatetime.slice(8,
						10) + ":" + updatetime.slice(10, 12) + ":" + updatetime.slice(12, 14);
					return sNewParkTime;
				} else {
					return 0;
				}

			} else {

				if (updatetime !== null && updatetime !== "0" && updatetime !== undefined) {
					var newUpdatetime = updatetime.slice(4, 6) + "/" + updatetime.slice(6, 8) + "/" + updatetime.slice(0, 4) + " " + updatetime.slice(
							8,
							10) + ":" +
						updatetime.slice(10, 12) + ":" + updatetime.slice(12, 14);
					return newUpdatetime;
				}
			}
		},
		AppTime: function(appTime, Region) {

			appTime = appTime.trim();
			if (Region === "EU" || Region === "LATAM" || Region === "ZA") {
				if ((appTime === "0") || (appTime === 0)) {
					return 0;
				} else {
					var sNewAppTime = appTime.slice(6, 8) + "/" + appTime.slice(4, 6) + "/" + appTime.slice(0, 4) + " " + appTime.slice(8, 10) + ":" +
						appTime.slice(10, 12) + ":" + appTime.slice(12, 14);
					return sNewAppTime;
				}
			} else {

				if (Region === undefined) {
					if ((appTime === "0") || (appTime === 0)) {
						return 0;
					} else {
						var sNewAppTime = appTime.slice(6, 8) + "/" + appTime.slice(4, 6) + "/" + appTime.slice(0, 4) + " " + appTime.slice(8, 10) + ":" +
							appTime.slice(10, 12) + ":" + appTime.slice(12, 14);
						return sNewAppTime;
					}
				} else {

					if ((appTime === "0") || (appTime === 0)) {
						return 0;
					} else if (appTime !== null && appTime !== "0" && appTime !== undefined) {
						var newAppointmentTime = appTime.slice(4, 6) + "/" + appTime.slice(6, 8) + "/" + appTime.slice(0, 4) + " " +
							appTime.slice(
								8, 10) + ":" + appTime.slice(10, 12) + ":" + appTime.slice(12, 14);
						return newAppointmentTime;
					}
				}
			}
		},

		plannedGIdate: function(PlanDate) {
			// 20190517
			// PlanDate = PlanDate.trim();
			if (PlanDate !== null && PlanDate !== "0" && PlanDate !== "" && PlanDate !== undefined) {
				var newPlannedGIDate = PlanDate.slice(4, 6) + "/" + PlanDate.slice(6, 8) + "/" + PlanDate.slice(0, 4);
				return newPlannedGIDate;
			}
		},

		doorArrival: function(DoorArrival) {
			// DoorArrival = DoorArrival.trim();
			if (DoorArrival === "0") {
				return 0;
			} else if (DoorArrival !== null && DoorArrival !== "0" && DoorArrival !== undefined) {
				var newDoorArrival = DoorArrival.slice(4, 6) + "/" + DoorArrival.slice(6, 8) + "/" + DoorArrival.slice(0, 4) + " " + DoorArrival.slice(
					8, 10) + ":" + DoorArrival.slice(10, 12) + ":" + DoorArrival.slice(12, 14);
				return newDoorArrival;
			}
		},

		parkTime: function(Parktime) {
			// 20190516130009
			// Parktime = Parktime.trim();
			if (Parktime === "0") {
				return 0;
			} else if (Parktime !== null && Parktime !== "0" && Parktime !== undefined) {
				var newParkTime = Parktime.slice(4, 6) + "/" + Parktime.slice(6, 8) + "/" + Parktime.slice(0, 4) + " " + Parktime.slice(
					8, 10) + ":" + Parktime.slice(10, 12) + ":" + Parktime.slice(12, 14);
				return newParkTime;
			}
		},
		trimDocNum: function(num) {
			var docNum = parseInt(num);
			if (docNum === 0) {
				return "";
			} else {
				return docNum;
			}
		},

		filteredOrderType: function(sOrdertype) {
			if (sOrdertype === "SAPI") {
				return "Issue";
			} else if (sOrdertype === "STOI") {
				return "STO-Issue";
			} else if (sOrdertype === "SAPR") {
				return "Return";
			} else if (sOrdertype === "STOR") {
				return "STO-Return";
			} else if (sOrdertype === "PORAW") {
				return "Raw Material PO";
			}
		},

		CheckInTypeForrmat: function(checkInType) {
			if (checkInType === "0" || checkInType === "" || checkInType === undefined) {
				return "Live";
			} else {
				return "D&H";
			}

		},

		CheckInTimeFormat: function(checkInTime) {
			// 20190516130009
			// Parktime = Parktime.trim();
			if (checkInTime === "0") {
				return 0;
			} else if (checkInTime !== null && checkInTime !== "0" && checkInTime !== undefined) {
				var newCheckInTime = checkInTime.slice(4, 6) + "/" + checkInTime.slice(6, 8) + "/" + checkInTime.slice(0, 4) + " " + checkInTime.slice(
					8, 10) + ":" + checkInTime.slice(10, 12) + ":" + checkInTime.slice(12, 14);
				return newCheckInTime;
			}
		},

		CheckOutTimeFormat: function(checkOutTime) {
			if (checkOutTime === "0") {
				return 0;
			} else if (checkOutTime !== null && checkOutTime !== "0" && checkOutTime !== undefined) {
				var newCheckOutTime = checkOutTime.slice(4, 6) + "/" + checkOutTime.slice(6, 8) + "/" + checkOutTime.slice(0, 4) + " " +
					checkOutTime
					.slice(
						8, 10) + ":" + checkOutTime.slice(10, 12) + ":" + checkOutTime.slice(12, 14);
				return newCheckOutTime;
			}
		},

		IdocDateFormat: function(date, Region) {

			if (date !== null) {

				if (Region === "EU" || Region === "LATAM" || Region === "ZA") {

					var sTimeSplit = date.split("T");

					var sBackEndDate = new Date(date);
					var sDate = sBackEndDate.getDate();
					var sMonth = sBackEndDate.getMonth() + 1;
					var sYear = sBackEndDate.getFullYear();
					var sFinalFormat = sDate + "/" + sMonth + "/" + sYear + " " + sTimeSplit[1];
					return sFinalFormat;

				} else {
					// var date = dt.slice(0, 4) + "," + dt.slice(4, 6) + "," + dt.slice(6, 8);
					var localtime = new Date(date);
					var dateFormat = sap.ui.core.format.DateFormat.getDateInstance({
						pattern: "dd-MMM-YYYY"
					});

					var dateFormatted = dateFormat.format(new Date(localtime));
					return dateFormatted;

				}
			}
		},

		FDERepDateFormat: function(date, Region) {
			if (date !== "") {
				if (Region === "EU" || Region === "LATAM" || Region === "ZA" || Region === "AP") {
					var newStartDate1 = date.slice(3, 5) + "/" + date.slice(0, 2) + "/" + date.slice(6, 20);
					return newStartDate1;
				} else {
					return date;
				}
			}
		},
		DwellRepDateFormat: function(date, Region) {
			if (date !== "") {
				var matchPattern = date.match(/\d+/g);
				if (matchPattern != null) {
					if (Region === "EU" || Region === "LATAM" || Region === "ZA") {
						var sFormat = date.slice(3, 5) + "/" + date.slice(0, 2) + "/" + date.slice(6, 20);
						return sFormat;
					} else {
						return date;
					}

				} else {
					return date;
				}

			}
		},

		DwellRepAppTimeFormt: function(sAppTime, Region) {

			if (sAppTime === "0") {
				return 0;
			} else {

				if (Region === "EU" || Region === "LATAM" || Region === "ZA") {
					var sNewAppTime = sAppTime.slice(6, 8) + "/" + sAppTime.slice(4, 6) + "/" + sAppTime.slice(0, 4) + " " + sAppTime.slice(8, 10) +
						":" + sAppTime.slice(10, 12) + ":" + sAppTime.slice(12, 14);
					return sNewAppTime;
				} else {
					return sAppTime;
				}

			}
		},

		DwellRepPlannedGIdate: function(PlanDate, Region) {
			if (PlanDate !== null && PlanDate !== "0" && PlanDate !== "" && PlanDate !== undefined) {
				var newPlannedGIDate;
				if (Region === "EU" || Region === "LATAM" || Region === "ZA") {
					newPlannedGIDate = PlanDate.slice(6, 8) + "/" + PlanDate.slice(4, 6) + "/" + PlanDate.slice(0, 4);
				} else {
					newPlannedGIDate = PlanDate.slice(4, 6) + "/" + PlanDate.slice(6, 8) + "/" + PlanDate.slice(0, 4);
				}

				return newPlannedGIDate;
			}
		},
		DwellRepDoorArrival: function(DoorArrival, Region) {
			if (Region === "EU" || Region === "LATAM" || Region === "ZA") {
				if (DoorArrival === "0") {
					return 0;
				} else if (DoorArrival !== null && DoorArrival !== "0" && DoorArrival !== undefined) {
					var newDoorArrival = DoorArrival.slice(6, 8) + "/" + DoorArrival.slice(4, 6) + "/" + DoorArrival.slice(0, 4) + " " + DoorArrival.slice(
						8, 10) + ":" + DoorArrival.slice(
						10, 12) + ":" + DoorArrival.slice(12, 14);
					return newDoorArrival;
				}
			} else {
				if (DoorArrival === "0") {
					return 0;
				} else if (DoorArrival !== null && DoorArrival !== "0" && DoorArrival !== undefined) {
					var newDoorArrival = DoorArrival.slice(4, 6) + "/" + DoorArrival.slice(6, 8) + "/" + DoorArrival.slice(0, 4) + " " + DoorArrival.slice(
						8, 10) + ":" + DoorArrival.slice(10, 12) + ":" + DoorArrival.slice(12, 14);
					return newDoorArrival;
				}

			}
		},
		//ctrm-1329
			parkingDate: function(date) {
			date = date.trim();
			if (date !== null && date !== "0" && date !== undefined) {
				var newDate = date.slice(4, 6) + "/" + date.slice(6, 8) + "/" + date.slice(0, 4);
				return newDate;
			}
		},
		parkingTime:function(time){
		time = time.trim();
			if (time !== null && time !== "0" && time !== undefined) {
				var newTime =  time.slice(0, 2) + ":" + time.slice(2, 4) + ":" + time.slice(4, 6) ;
				return newTime;
			}	
		},
		yardStop:function(yardStop){
			if (yardStop === "true" || yardStop === true) {
				return "ON";
			} else if(yardStop === "false" || yardStop === false){
				return "OFF";
			}	
		},
		//CTRM-1392 || Customer Rejection 
		CustRejType: function(CR) {
			if (CR === "X") {
				return "Y";
			} else if (CR === undefined || CR === "") {
				return "";
			} else {
				return "";
			}
		}

	};

	return formatter;

});