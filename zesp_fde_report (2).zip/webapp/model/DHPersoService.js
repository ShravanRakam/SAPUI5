jQuery.sap.require("jquery.sap.resources");
sap.ui.define(['jquery.sap.global'],
	function(jQuery) {
		"use strict";

		// Very simple page-context personalization
		// persistence service, not for productive use!
		var RejectionPersoService = {

			oData: {
				_persoSchemaVersion: "1.0",
				aColumns: [{
						id: "DHApp-table-DHContainerID",
						order: 1,
						text: "Container ID",
						visible: true
					}, {
						id: "DHApp-table-DHCarrier",
						order: 2,
						text: "Carrier",
						visible: true
					}, {
						id: "DHApp-table-DHType",
						order: 3,
						text: "Check-In Type",
						visible: true
					}, {
						id: "DHApp-table-DHCheckInTimestamp",
						order: 4,
						text: "Check-In",
						visible: true
					}, {
						id: "DHApp-table-DHDeliveryCreationTimestamp",
						order: 5,
						text: "Delivery Creation",
						visible: true
					}, {
						id: "DHApp-table-DHUnloadStartTimestamp",
						order: 6,
						text: "Unload Start",
						visible: true
					}, {
						id: "DHApp-table-DHUnloadCompTimestamp",
						order: 7,
						text: "Unload Completion",
						visible: true
					}, {
						id: "DHApp-table-DHLoadStartTimestamp",
						order: 8,
						text: "Load Start",
						visible: true
					}, {
						id: "DHApp-table-DHLoadCompletionTimestamp",
						order: 9,
						text: "Load Completion",
						visible: true
					}, {
						id: "DHApp-table-DHCheckOutTimestamp",
						order: 10,
						text: "Check-Out",
						visible: true
					}, {
						id: "DHApp-table-DHUADwellTime",
						order: 11,
						text: "UA Dwell",
						visible: true
					}, {
						id: "DHApp-table-DHLoadedDwellTime",
						order: 12,
						text: "Loaded Dwell",
						visible: true
					}, {
						id: "DHApp-table-DHUnloadingDwellTime",
						order: 13,
						text: "Unloading Dwell",
						visible: true
					}, {
						id: "DHApp-table-DHEmptyDwellTime",
						order: 14,
						text: "Empty Dwell",
						visible: true
					}, {
						id: "DHApp-table-DHLoadingDwellTime",
						order: 15,
						text: "Loading Dwell",
						visible: true
					}, {
						id: "DHApp-table-DHPreloadDwellTime",
						order: 16,
						text: " Preload Dwell",
						visible: true
					}, {
						id: "DHApp-table-DHTotalDwellTime",
						order: 17,
						text: "Total Dwell (DD:HH:MM)",
						visible: true
					}, {
						id: "DHApp-table-DHIBDelivery",
						order: 18,
						text: "IB Delivery",
						visible: true
					}, {
						id: "DHApp-table-DHOBDelivery",
						order: 19,
						text: "OB Delivery",
						visible: true
					}, {
						id: "DHApp-table-DHInboundDriverName",
						order: 20,
						text: "Inbound Driver Name",
						visible: true
					}, {
						id: "DHApp-table-DHOutboundDriverName",
						order: 21,
						text: "Outbound Driver Name",
						visible: true
					}, {
						id: "DHApp-table-DHAppointmentTime",
						order: 22,
						text: "Appointment Time",
						visible: true
					},

					{
						id: "DHApp-table-DHPlannedGIDate",
						order: 23,
						text: "Planned GI Date",
						visible: true
					}, {
						id: "DHApp-table-DHDoorArrivalTime",
						order: 24,
						text: "Door Arrival Time",
						visible: true
					}, {
						id: "DHApp-table-DHParkTime",
						order: 25,
						text: "Park Time",
						visible: true
					}, {
						id: "DHApp-table-DHTrailerType",
						order: 27,
						text: "Trailer Type",
						visible: true
					}, {
						id: "DHApp-table-DHCheckInSystem",
						order: 28,
						text: "Check In System",
						visible: true
					}, {
						id: "DHApp-table-DHCheckInType",
						order: 29,
						text: "Check-Out Type",
						visible: true
					}, {
						id: "DHApp-table-DHCheckOutSystem",
						order: 30,
						text: "Check Out System",
						visible: true
					},

					{
						id: "DHApp-table-DHTrailerSeal",
						order: 32,
						text: "Traile rSeal",
						visible: true
					}
				]
			},
			getPersData: function() {
				var oDeferred = new jQuery.Deferred();
				if (!this._oBundle) {
					this._oBundle = this.oData;
				}
				var oBundle = this._oBundle;
				oDeferred.resolve(oBundle);
				return oDeferred.promise();
			},

			setPersData: function(oBundle) {
				var oDeferred = new jQuery.Deferred();
				this._oBundle = oBundle;
				oDeferred.resolve();
				return oDeferred.promise();
			},

			resetPersData: function() {
				var oDeferred = new jQuery.Deferred();
				var oInitialData = {
					_persoSchemaVersion: "1.0",
					aColumns: [{
							id: "DHApp-table-DHContainerID",
							order: 1,
							text: "Container ID",
							visible: true
						}, {
							id: "DHApp-table-DHCarrier",
							order: 2,
							text: "Carrier",
							visible: true
						}, {
							id: "DHApp-table-DHType",
							order: 3,
							text: "Check-In Type",
							visible: true
						}, {
							id: "DHApp-table-DHCheckInTimestamp",
							order: 4,
							text: "Check-In",
							visible: true
						}, {
							id: "DHApp-table-DHDeliveryCreationTimestamp",
							order: 5,
							text: "Delivery Creation",
							visible: true
						}, {
							id: "DHApp-table-DHUnloadStartTimestamp",
							order: 6,
							text: "Unload Start",
							visible: true
						}, {
							id: "DHApp-table-DHUnloadCompTimestamp",
							order: 7,
							text: "Unload Completion",
							visible: true
						}, {
							id: "DHApp-table-DHLoadStartTimestamp",
							order: 8,
							text: "Load Start",
							visible: true
						}, {
							id: "DHApp-table-DHLoadCompletionTimestamp",
							order: 9,
							text: "Load Completion",
							visible: true
						}, {
							id: "DHApp-table-DHCheckOutTimestamp",
							order: 10,
							text: "Check-Out",
							visible: true
						}, {
							id: "DHApp-table-DHUADwellTime",
							order: 11,
							text: "UA Dwell",
							visible: true
						}, {
							id: "DHApp-table-DHLoadedDwellTime",
							order: 12,
							text: "Loaded Dwell",
							visible: true
						}, {
							id: "DHApp-table-DHUnloadingDwellTime",
							order: 13,
							text: "Unloading Dwell",
							visible: true
						}, {
							id: "DHApp-table-DHEmptyDwellTime",
							order: 14,
							text: "Empty Dwell",
							visible: true
						}, {
							id: "DHApp-table-DHLoadingDwellTime",
							order: 15,
							text: "Loading Dwell",
							visible: true
						}, {
							id: "DHApp-table-DHPreloadDwellTime",
							order: 16,
							text: " Preload Dwell",
							visible: true
						}, {
							id: "DHApp-table-DHTotalDwellTime",
							order: 17,
							text: "Total Dwell (DD:HH:MM)",
							visible: true
						}, {
							id: "DHApp-table-DHIBDelivery",
							order: 18,
							text: "IB Delivery",
							visible: true
						},

						{
							id: "DHApp-table-DHOBDelivery",
							order: 19,
							text: "OB Delivery",
							visible: true
						},

						{
							id: "DHApp-table-DHInboundDriverName",
							order: 20,
							text: "Inbound Driver Name",
							visible: true
						}, {
							id: "DHApp-table-DHOutboundDriverName",
							order: 21,
							text: "Outbound Driver Name",
							visible: true
						}, {
							id: "DHApp-table-DHAppointmentTime",
							order: 22,
							text: "Appointment Time",
							visible: true
						},

						{
							id: "DHApp-table-DHPlannedGIDate",
							order: 23,
							text: "Planned GI Date",
							visible: true
						}, {
							id: "DHApp-table-DHDoorArrivalTime",
							order: 24,
							text: "Door Arrival Time",
							visible: true
						}, {
							id: "DHApp-table-DHParkTime",
							order: 25,
							text: "Park Time",
							visible: true
						}, {
							id: "DHApp-table-DHTrailerType",
							order: 27,
							text: "Trailer Type",
							visible: true
						}, {
							id: "DHApp-table-DHCheckInSystem",
							order: 28,
							text: "Check In System",
							visible: true
						}, {
							id: "DHApp-table-DHCheckInType",
							order: 29,
							text: "Check-Out Type",
							visible: true
						}, {
							id: "DHApp-table-DHCheckOutSystem",
							order: 30,
							text: "Check Out System",
							visible: true
						},

						{
							id: "DHApp-table-DHTrailerSeal",
							order: 32,
							text: "Traile rSeal",
							visible: true
						}
					]
				};

				//set personalization
				this._oBundle = oInitialData;

				//reset personalization, i.e. display table as defined
				//		this._oBundle = null;

				oDeferred.resolve();
				return oDeferred.promise();
			},

			//this caption callback will modify the TablePersoDialog' entry for the 'Weight' column
			//to 'Weight (Important!)', but will leave all other column names as they are.
			getCaption: function(oColumn) {
				if (oColumn.getHeader() && oColumn.getHeader().getText) {
					if (oColumn.getHeader().getText() === "Weight") {
						return "Weight (Important!)";
					}
				}
				return null;
			},

			getGroup: function(oColumn) {
				var that = this;
				var lang = sap.ui.getCore().getConfiguration().getLanguage();
				var propFile = $.sap.getModulePath("com.report", "/i18n/");
				var propData = propFile + "i18n_" + lang + ".properties";
				var oBundle = jQuery.sap.resources({
					url: propData, //"i18n/i18n.properties",
					locale: sap.ui.getCore().getConfiguration().getLanguage()
				});
				var pgroup = oBundle.getText("pgroup");
				var sgroup = oBundle.getText("sgroup");
				if (oColumn.getId().indexOf('Action') !== -1 || oColumn.getId().indexOf('updateTime') !== -1) {
					return pgroup;
				}
				return sgroup;
			}

		};

		return RejectionPersoService;

	}, /* bExport= */ true);