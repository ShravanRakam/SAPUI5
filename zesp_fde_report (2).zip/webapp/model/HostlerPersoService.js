jQuery.sap.require("jquery.sap.resources");
sap.ui.define(['jquery.sap.global'],
	function(jQuery) {
		"use strict";

		// Very simple page-context personalization
		// persistence service, not for productive use!
		var HostlerPersoService = {

			oData: {
				_persoSchemaVersion: "1.0",
				aColumns: [{
					id: "hostlerApp-table-trailId",
					order: 1,
					text: "Trailer ID",
					visible: true
				}, {
					id: "hostlerApp-table-locFrom",
					order: 2,
					text: "Location From",
					visible: true
				}, {
					id: "hostlerApp-table-locTo",
					order: 3,
					text: "Location To",
					visible: true
				}, {
					id: "hostlerApp-table-startTmp",
					order: 4,
					text: "Start Timestamp",
					visible: true
				}, {
					id: "hostlerApp-table-compTmp",
					order: 5,
					text: "Complete Timestamp",
					visible: true
				}, {
					id: "hostlerApp-table-timeTaken",
					order: 6,
					text: "Time Taken",
					visible: true
				}, {
					id: "hostlerApp-table-personId",
					order: 7,
					text: "Personnel ID",
					visible: true
				}]
			},

			getPersData: function() {
				var oDeferred = new jQuery.Deferred();
				if (!this._oBundle) {
					this._oBundle = this.oData;
				}
				var oBundle = this._oBundle;
				oDeferred.resolve(oBundle);
				return oDeferred.promise();
			},

			setPersData: function(oBundle) {
				var oDeferred = new jQuery.Deferred();
				this._oBundle = oBundle;
				oDeferred.resolve();
				return oDeferred.promise();
			},

			resetPersData: function() {
				var oDeferred = new jQuery.Deferred();
				var oInitialData = {
					_persoSchemaVersion: "1.0",
					aColumns: [{
						id: "hostlerApp-table-trailId",
						order: 0,
						text: "Trailer ID",
						visible: true
					}, {
						id: "hostlerApp-table-locFrom",
						order: 1,
						text: "Location From",
						visible: false
					}, {
						id: "hostlerApp-table-locTo",
						order: 4,
						text: "Location To",
						visible: false
					}, {
						id: "hostlerApp-table-startTmp",
						order: 2,
						text: "Start Timestamp",
						visible: true
					}, {
						id: "hostlerApp-table-compTmp",
						order: 3,
						text: "Complete Timestamp",
						visible: true
					}, {
						id: "hostlerApp-table-timeTaken",
						order: 0,
						text: "Time Taken",
						visible: true
					}, {
						id: "hostlerApp-table-personId",
						order: 0,
						text: "Personnel ID",
						visible: true
					}]
				};

				//set personalization
				this._oBundle = oInitialData;

				//reset personalization, i.e. display table as defined
				//		this._oBundle = null;

				oDeferred.resolve();
				return oDeferred.promise();
			},

			//this caption callback will modify the TablePersoDialog' entry for the 'Weight' column
			//to 'Weight (Important!)', but will leave all other column names as they are.
			getCaption: function(oColumn) {
				if (oColumn.getHeader() && oColumn.getHeader().getText) {
					if (oColumn.getHeader().getText() === "Weight") {
						return "Weight (Important!)";
					}
				}
				return null;
			},
			
			getGroup: function(oColumn) {
				var that = this;
				var lang = sap.ui.getCore().getConfiguration().getLanguage();
				var propFile = $.sap.getModulePath("com.report", "/i18n/");
				var propData = propFile + "i18n_" + lang + ".properties";
				var oBundle = jQuery.sap.resources({
					url: propData, //"i18n/i18n.properties",
					locale: sap.ui.getCore().getConfiguration().getLanguage()
				});
				var pgroup = oBundle.getText("pgroup");
				var sgroup = oBundle.getText("sgroup");
				if (oColumn.getId().indexOf('trailId') != -1 || oColumn.getId().indexOf('locFrom') != -1 ||
					oColumn.getId().indexOf('locTo') != -1) {
					return pgroup;
				}
				return sgroup;
			}

			// getGroup: function(oColumn) {
			// 	if (oColumn.getId().indexOf('trailId') != -1 || oColumn.getId().indexOf('locFrom') != -1 ||
			// 		oColumn.getId().indexOf('locTo') != -1) {
			// 		return "Primary Group";
			// 	}
			// 	return "Secondary Group";
			// }
		};

		return HostlerPersoService;

	}, /* bExport= */ true);