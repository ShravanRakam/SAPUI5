jQuery.sap.require("jquery.sap.resources");
sap.ui.define(['jquery.sap.global'],
	function(jQuery) {
		"use strict";

		// Very simple page-context personalization
		// persistence service, not for productive use!
		var PPDiscrepancyPersoService = {

			oData: {
				_persoSchemaVersion: "1.0",
				aColumns: [{
						id: "PPDescripancyApp-table-PPRepPlant",
						order: 1,
						text: "Delivery Number",
						visible: true
					},

					{
						id: "PPDescripancyApp-table-delNum",
						order: 2,
						text: "Delivery Number",
						visible: true
					}, {
						id: "PPDescripancyApp-table-carrierName",
						order: 3,
						text: "Carrier Name",
						visible: true
					}, {
						id: "PPDescripancyApp-table-Type",
						order: 4,
						text: "Type",
						visible: true
					}, {
						id: "PPDescripancyApp-table-userID",
						order: 5,
						text: "User ID	",
						visible: true
					}, {
						id: "PPDescripancyApp-table-prdCode",
						order: 6,
						text: "Product Code	",
						visible: false
					}, {
						id: "PPDescripancyApp-table-expQuantity",
						order: 7,
						text: "Expected Quantity",
						visible: true
					}, {
						id: "PPDescripancyApp-table-actQuantity",
						order: 8,
						text: "Actual Quantity	",
						visible: true
					}, {
						id: "PPDescripancyApp-table-variance",
						order: 9,
						text: "Variance",
						visible: true
					}
				]
			},

			getPersData: function() {
				var oDeferred = new jQuery.Deferred();
				if (!this._oBundle) {
					this._oBundle = this.oData;
				}
				var oBundle = this._oBundle;
				oDeferred.resolve(oBundle);
				return oDeferred.promise();
			},

			setPersData: function(oBundle) {
				var oDeferred = new jQuery.Deferred();
				this._oBundle = oBundle;
				oDeferred.resolve();
				return oDeferred.promise();
			},

			resetPersData: function() {
				var oDeferred = new jQuery.Deferred();
				var oInitialData = {
					_persoSchemaVersion: "1.0",
					aColumns: [{
						id: "PPDescripancyApp-table-PPRepPlant",
						order: 1,
						text: "Delivery Number",
						visible: true
					}, {
						id: "PPDescripancyApp-table-delNum",
						order: 1,
						text: "Delivery Number",
						visible: true
					}, {
						id: "PPDescripancyApp-table-carrierName",
						order: 2,
						text: "Carrier Name",
						visible: true
					}, {
						id: "PPDescripancyApp-table-Type",
						order: 3,
						text: "Type",
						visible: true
					}, {
						id: "PPDescripancyApp-table-userID",
						order: 4,
						text: "User ID	",
						visible: true
					}, {
						id: "PPDescripancyApp-table-prdCode",
						order: 5,
						text: "Product Code	",
						visible: false
					}, {
						id: "PPDescripancyApp-table-expQuantity",
						order: 6,
						text: "Expected Quantity",
						visible: true
					}, {
						id: "PPDescripancyApp-table-actQuantity",
						order: 7,
						text: "Actual Quantity	",
						visible: true
					}, {
						id: "PPDescripancyApp-table-variance",
						order: 8,
						text: "Variance",
						visible: true
					}]
				};

				//set personalization
				this._oBundle = oInitialData;

				//reset personalization, i.e. display table as defined
				//		this._oBundle = null;

				oDeferred.resolve();
				return oDeferred.promise();
			},

			//this caption callback will modify the TablePersoDialog' entry for the 'Weight' column
			//to 'Weight (Important!)', but will leave all other column names as they are.
			getCaption: function(oColumn) {
				if (oColumn.getHeader() && oColumn.getHeader().getText) {
					if (oColumn.getHeader().getText() === "Weight") {
						return "Weight (Important!)";
					}
				}
				return null;
			},

			getGroup: function(oColumn) {
				var that = this;
				var lang = sap.ui.getCore().getConfiguration().getLanguage();
				var propFile = $.sap.getModulePath("com.report", "/i18n/");
				var propData = propFile + "i18n_" + lang + ".properties";
				var oBundle = jQuery.sap.resources({
					url: propData, //"i18n/i18n.properties",
					locale: sap.ui.getCore().getConfiguration().getLanguage()
				});
				var pgroup = oBundle.getText("pgroup");
				var sgroup = oBundle.getText("sgroup");
				if (oColumn.getId().indexOf('userID1') !== -1 || oColumn.getId().indexOf('expectedQty1') !== -1 || oColumn.getId().indexOf(
						'ActualQty1') !== -1) {
					return pgroup;
				}
				return sgroup;
			}

			// getGroup: function(oColumn) {
			// 	if (oColumn.getId().indexOf('blockDate') != -1 || oColumn.getId().indexOf('unblockDate') != -1 ||
			// 		oColumn.getId().indexOf('rejectDate') != -1 ) {
			// 		return "Primary Group";
			// 	}
			// 	return "Secondary Group";
			// }
		};

		return PPDiscrepancyPersoService;

	}, /* bExport= */ true);