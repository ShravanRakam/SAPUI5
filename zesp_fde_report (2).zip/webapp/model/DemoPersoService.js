jQuery.sap.require("jquery.sap.resources");
sap.ui.define(['jquery.sap.global'],
	function(jQuery) {
		"use strict";

		// Very simple page-context personalization
		// persistence service, not for productive use!
		var DemoPersoService = {

			oData: {
				_persoSchemaVersion: "1.0",
				aColumns: [{
					id: "demoApp-table-delNum",
					order: 1,
					text: "Del Num",
					visible: true
				}, {
					id: "demoApp-table-delType",
					order: 2,
					text: "Del Type",
					visible: true
				}, {
					id: "demoApp-table-transType",
					order: 3,
					text: "Transport Type",
					visible: true
				}, {
					id: "demoApp-table-userId",
					order: 4,
					text: "UserID",
					visible: true
				}, {
					id: "demoApp-table-ldAcptTime",
					order: 5,
					text: "Load Accept Time",
					visible: false
				}, {
					id: "demoApp-table-ldStartTime",
					order: 6,
					text: "Load Start Time",
					visible: true
				}, {
					id: "demoApp-table-ldCompTime",
					order: 7,
					text: "Load Complete Time",
					visible: true
				}, {
					id: "demoApp-table-prdCode",
					order: 8,
					text: "ProductCode",
					visible: true
				}, {
					id: "demoApp-table-batch",
					order: 9,
					text: "Batch",
					visible: true
				}, {
					id: "demoApp-table-qty",
					order: 10,
					text: "Quantity",
					visible: true
				}, {
					id: "demoApp-table-plannedQty",
					order: 11,
					text: "Planned Qty",
					visible: true
				}, {
					id: "demoApp-table-discrepancies",
					order: 12,
					text: "Variance",
					visible: true
				}, {
					id: "demoApp-table-custName",
					order: 13,
					text: "Customer Name",
					visible: true
				}, {
					id: "demoApp-table-glidGlobId",
					order: 14,
					text: "GLID/Global ID",
					visible: true
				}, {
					id: "demoApp-table-scac",
					order: 15,
					text: "SCAC",
					visible: true
				}, {
					id: "demoApp-table-storageLoc",
					order: 16,
					text: "Storage Loc",
					visible: true
				}, {
					id: "demoApp-table-typOfTruck",
					order: 17,
					text: "Type of Trucks",
					visible: true
				}, {
					id: "demoApp-table-dock",
					order: 18,
					text: "Dock/Service Bay",
					visible: true
				}, {
					id: "demoApp-table-trailerId",
					order: 19,
					text: "Trailer Id",
					visible: true
				}, {
					id: "demoApp-table-regNum",
					order: 20,
					text: "Reg Num",
					visible: true
				}, {
					id: "demoApp-table-termSaftyAcpt",
					order: 21,
					text: "Terms & Safety Agreement Accepted",
					visible: true
				}, {
					id: "demoApp-table-checkinSys",
					order: 22,
					text: "Check In System",
					visible: true
				}, {
					id: "demoApp-table-checkoutSys",
					order: 23,
					text: "Check Out System",
					visible: true
				// }, {
				// 	id: "demoApp-table-checkinTyp",
				// 	order: 24,
				// 	text: "Check-In Type",
				// 	visible: true
				}]
			},

			getPersData: function() {
				var oDeferred = new jQuery.Deferred();
				if (!this._oBundle) {
					this._oBundle = this.oData;
				}
				var oBundle = this._oBundle;
				oDeferred.resolve(oBundle);
				return oDeferred.promise();
			},

			setPersData: function(oBundle) {
				var oDeferred = new jQuery.Deferred();
				this._oBundle = oBundle;
				oDeferred.resolve();
				return oDeferred.promise();
			},

			resetPersData: function() {
				var oDeferred = new jQuery.Deferred();
				var oInitialData = {
					_persoSchemaVersion: "1.0",
					aColumns: [{
						id: "demoApp-table-delNum",
						order: 0,
						text: "Del Num",
						visible: true
					}, {
						id: "demoApp-table-delType",
						order: 1,
						text: "Del Type",
						visible: false
					}, {
						id: "demoApp-table-transType",
						order: 4,
						text: "Transport Type",
						visible: false
					}, {
						id: "demoApp-table-userId",
						order: 2,
						text: "UserID",
						visible: true
					}, {
						id: "demoApp-table-ldAcptTime",
						order: 3,
						text: "Load Accept Time",
						visible: true
					}, {
						id: "demoApp-table-ldStartTime",
						order: 0,
						text: "Load Start Time",
						visible: true
					}, {
						id: "demoApp-table-ldCompTime",
						order: 1,
						text: "Load Complete Time",
						visible: false
					}, {
						id: "demoApp-table-prdCode",
						order: 4,
						text: "ProductCode",
						visible: false
					}, {
						id: "demoApp-table-batch",
						order: 2,
						text: "Batch",
						visible: true
					}, {
						id: "demoApp-table-qty",
						order: 3,
						text: "Quantity",
						visible: true
					}, {
						id: "demoApp-table-plannedQty",
						order: 2,
						text: "Planned Qty",
						visible: true
					}, {
						id: "demoApp-table-discrepancies",
						order: 3,
						text: "Variance",
						visible: true
					}, {
						id: "demoApp-table-custName",
						order: 2,
						text: "Customer Name",
						visible: true
					}, {
						id: "demoApp-table-glidGlobId",
						order: 1,
						text: "GLID/Global ID",
						visible: true
					}, {
						id: "demoApp-table-scac",
						order: 3,
						text: "SCAC",
						visible: true
					}, {
						id: "demoApp-table-storageLoc",
						order: 0,
						text: "Storage Loc",
						visible: true
					}, {
						id: "demoApp-table-typOfTruck",
						order: 1,
						text: "Type of Trucks",
						visible: true
					}, {
						id: "demoApp-table-dock",
						order: 4,
						text: "Dock/Service Bay",
						visible: true
					}, {
						id: "demoApp-table-trailerId",
						order: 0,
						text: "Trailer Id",
						visible: true
					}, {
						id: "demoApp-table-regNum",
						order: 1,
						text: "Reg Num",
						visible: true
					}, {
						id: "demoApp-table-termSaftyAcpt",
						order: 4,
						text: "Terms & Safety Agreement Accepted",
						visible: true
					}, {
						id: "demoApp-table-checkinSys",
						order: 0,
						text: "Check In System",
						visible: true
					}, {
						id: "demoApp-table-checkoutSys",
						order: 3,
						text: "Check Out System",
						visible: true
					// }, {
					// 	id: "demoApp-table-checkinTyp",
					// 	order: 3,
					// 	text: "Check-In Type",
					// 	visible: true
					}]
				};

				//set personalization
				this._oBundle = oInitialData;

				//reset personalization, i.e. display table as defined
				//		this._oBundle = null;

				oDeferred.resolve();
				return oDeferred.promise();
			},

			//this caption callback will modify the TablePersoDialog' entry for the 'Weight' column
			//to 'Weight (Important!)', but will leave all other column names as they are.
			getCaption: function(oColumn) {
				if (oColumn.getHeader() && oColumn.getHeader().getText) {
					if (oColumn.getHeader().getText() === "Weight") {
						return "Weight (Important!)";
					}
				}
				return null;
			},

			getGroup: function(oColumn) {
				var that = this;
				var lang = sap.ui.getCore().getConfiguration().getLanguage();
				var propFile = $.sap.getModulePath("com.report", "/i18n/");
				var propData = propFile + "i18n_" + lang + ".properties";
				var oBundle = jQuery.sap.resources({
					url: propData, //"i18n/i18n.properties",
					locale: sap.ui.getCore().getConfiguration().getLanguage()
				});
				var pgroup = oBundle.getText("pgroup");
				var sgroup = oBundle.getText("sgroup");
				if (oColumn.getId().indexOf('delNum') != -1 || oColumn.getId().indexOf('delType') != -1 ||
					oColumn.getId().indexOf('prdCode') != -1 || oColumn.getId().indexOf('batch') != -1 ||
					oColumn.getId().indexOf('qty') != -1) {
					return pgroup;
				}
				return sgroup;
			}

			// getGroup: function(oColumn) {
			// 	if (oColumn.getId().indexOf('delNum') != -1 || oColumn.getId().indexOf('delType') != -1 ||
			// 		oColumn.getId().indexOf('prdCode') != -1 || oColumn.getId().indexOf('batch') != -1 ||
			// 		oColumn.getId().indexOf('qty') != -1) {
			// 		return "Primary Group";
			// 	}
			// 	return "Secondary Group";
			// }
		};

		return DemoPersoService;

	}, /* bExport= */ true);