sap.ui.jsview("com.report.view.DelStatusReport", {

	/** Specifies the Controller belonging to this View. 
	 * In the case that it is not implemented, or that "null" is returned, this View does not have a Controller.
	 * @memberOf com.report.DelStatusReport
	 */
	getControllerName: function() {
		return "com.report.controller.DelStatusReport";
	},

	/** Is initially called once after the Controller has been instantiated. It is the place where the UI is constructed. 
	 * Since the Controller is given to this method, its event handlers can be attached right away.
	 * @memberOf com.report.DelStatusReport
	 */
	createContent: function(oController) {
		var oPage = new sap.m.Page(this.createId("StatusReportPage"), {
			title: "{i18n>delStatRep}",
			showNavButton: true,
			navButtonPress: [oController.onNavButtonPress, oController],
			content: [],
			footer: new sap.m.OverflowToolbar({
				content: [
					new sap.m.ToolbarSpacer(),
					new sap.m.Button(this.createId("Export"), {
						icon: "sap-icon://excel-attachment",
						text: "{i18n>LabelExportCSV}",
						type: "Accept",
						press: [oController.onPressExcelSheetExport, oController]
					}),
					new sap.m.Button(this.createId("ExportXLS"), {
						icon: "sap-icon://excel-attachment",
						text: "{i18n>LabelExportXLS}",
						type: "Accept",
						press: [oController.onPressExcelSheetExportXLS, oController]
					})
				]
			}).addStyleClass("hideButtom")
		}).addStyleClass("sapUiSizeCompact");

		var app = new sap.m.App("StatusReportApp", {

		});
		app.addPage(oPage);
		return app;
	}

});