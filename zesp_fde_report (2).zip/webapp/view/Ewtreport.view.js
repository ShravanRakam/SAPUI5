sap.ui.jsview("com.report.view.Ewtreport", {
	/** Specifies the Controller belonging to this View. 
	 * In the case that it is not implemented, or that "null" is returned, this View does not have a Controller.
	 * @memberOf controller.ReportInter
	 */
	getControllerName: function() {
		return "com.report.controller.Ewtreport";
	},
	/** Is initially called once after the Controller has been instantiated. It is the place where the UI is constructed. 
	 * Since the Controller is given to this method, its event handlers can be attached right away.
	 * @memberOf controller.PlantDetails
	 */
	createContent: function(oController) {
		var oPlantPage = new sap.m.Page(this.createId("ewtPageId"), {
			title: "{i18n>ewtImgTitle}",
			// showHeader: false,
			content: [

			],
			showNavButton: true,
			navButtonPress: [oController.onNavButtonPress, oController],
			footer: new sap.m.Bar(this.createId("rejectRepFooter"), {
				design: sap.m.BarDesign.Footer,
				contentRight: [
					new sap.m.Button(this.createId("Export"), {
						icon: "sap-icon://excel-attachment",
						text: "{i18n>LabelExportCSV}", //"Export",
						type: "Accept",
						press: [oController.onPressEWTExport, oController]
					})
				]
			}).addStyleClass("hideButtom")
		}).addStyleClass("sapUiSizeCompact backgrnd");

		var app = new sap.m.App(this.createId("myRejectapp"), {

		});
		app.addPage(oPlantPage);
		return app;
	}
});