sap.ui.jsview("com.report.view.DHDwellTimeReport", {
	/** Specifies the Controller belonging to this View. 
	 * In the case that it is not implemented, or that "null" is returned, this View does not have a Controller.
	 * @memberOf controller.ReportInter
	 */
	getControllerName: function() {
		return "com.report.controller.DHDwellTimeReport";
	},
	/** Is initially called once after the Controller has been instantiated. It is the place where the UI is constructed. 
	 * Since the Controller is given to this method, its event handlers can be attached right away.
	 * @memberOf controller.PlantDetails
	 */
	createContent: function(oController) {
		var oDHPlantPage = new sap.m.Page(this.createId("DHDTReportPage"), {
			title: "{i18n>DHDwellTymReport}",
			// showHeader: false,
			content: [

			],
			showNavButton: true,
			navButtonPress: [oController.onNavButtonPress, oController],
			footer: new sap.m.Bar(this.createId("DHRepFooter"), {
				design: sap.m.BarDesign.Footer,
				contentRight: [
					new sap.m.Button(this.createId("Export"), {
						icon: "sap-icon://excel-attachment",
						text: "{i18n>LabelExportCSV}", //"Export",
						type: "Accept",
						press: [oController.onPressExport, oController]
					}),
						new sap.m.Button(this.createId("ExportXLS"), {
						icon: "sap-icon://excel-attachment",
						text: "{i18n>LabelExportXLS}", //"Export",
						type: "Accept",
						press: [oController.onPressExportXLS, oController]
					})
				]
			}).addStyleClass("hideButtom")
		}).addStyleClass("sapUiSizeCompact backgrnd");

		var app = new sap.m.App(this.createId("myDHapp"), {

		});
		app.addPage(oDHPlantPage);
		return app;
	}
});