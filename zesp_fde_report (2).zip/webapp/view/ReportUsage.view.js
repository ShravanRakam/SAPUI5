sap.ui.jsview("com.report.view.ReportUsage", {
	/** Specifies the Controller belonging to this View. 
	 * In the case that it is not implemented, or that "null" is returned, this View does not have a Controller.
	 * @memberOf controller.ReportInter
	 */
	getControllerName: function() {
		return "com.report.controller.ReportUsage";
	},
	/** Is initially called once after the Controller has been instantiated. It is the place where the UI is constructed. 
	 * Since the Controller is given to this method, its event handlers can be attached right away.
	 * @memberOf controller.PlantDetails
	 */
	createContent: function(oController) {
		var oPlantPage = new sap.m.Page(this.createId("RUsagePage"), {
			title: "{i18n>fdeReport}",
			// showHeader: false,
			content: [

			],
			showNavButton: true,
			navButtonPress: [oController.onNavButtonPress, oController],
			footer: new sap.m.Bar(this.createId("plantFooter"), {
				design: sap.m.BarDesign.Footer,
				contentLeft: [
					new sap.m.HBox({
						items: [
							new sap.m.Label({
								text: "{i18n>totalDistDel}",
								design: "Bold"
							}).addStyleClass("sapUiLargeMarginBegin"),
							new sap.m.Text("distCount", {
									text: "{distinctCountModel>/Count}"
							}).addStyleClass("bold sapUiTinyMarginBegin")
						]
					}).addStyleClass("footerLeftClass")
				],
				contentMiddle: [
					new sap.m.HBox({
						items: [
							// new sap.m.Label({
							// 	text: "Total Distinct Delivery Number: "
							// }),
							// new sap.m.Text("distCount", {
							// 	text: "{distinctCountModel>/Count}"
							// }),
							//   new sap.m.Text({
							// 	text: "    "
							// }),
							new sap.m.Label({
								text: "{i18n>totalQty}",
								design: "Bold"
							}).addStyleClass("sapUiMediumMarginBegin"),
							new sap.m.Text({
								text: "{distinctCountModel>/Sum}"
							}).addStyleClass("bold sapUiTinyMarginBegin")
						]
					}).addStyleClass("footerMiddleClass")
				],
				contentRight: [
					new sap.m.Button(this.createId("Export"), {
						icon: "sap-icon://excel-attachment",
						text: "{i18n>LabelExportCSV}", //"Export",
						type: "Accept",
						press: [oController.onPressExport, oController]
					}),
					new sap.m.Button(this.createId("ExportXLS"), {
						icon: "sap-icon://excel-attachment",
						text: "{i18n>LabelExportXLS}", //"Export",
						type: "Accept",
						press: [oController.onPressExportXLS, oController]
					})
				]
			}).addStyleClass("hideButtom")
		}).addStyleClass("sapUiSizeCompact backgrnd");

		var app = new sap.m.App(this.createId("myUsageapp"), {

		});
		app.addPage(oPlantPage);
		return app;
	}
});