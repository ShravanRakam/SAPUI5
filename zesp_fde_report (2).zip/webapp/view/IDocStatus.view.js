sap.ui.jsview("com.report.view.IDocStatus", {

	/** Specifies the Controller belonging to this View. 
	 * In the case that it is not implemented, or that "null" is returned, this View does not have a Controller.
	 * @memberOf com.report.webapp.view.IDocStatus
	 */
	getControllerName: function() {
		return "com.report.controller.IDocStatus";
	},

	/** Is initially called once after the Controller has been instantiated. It is the place where the UI is constructed. 
	 * Since the Controller is given to this method, its event handlers can be attached right away.
	 * @memberOf com.report.webapp.view.IDocStatus
	 */
	createContent: function(oController) {
		var oPage = new sap.m.Page(this.createId("IDocStatusPage"),{
			title: "{i18n>IdocStatusTitle}",
			showNavButton: true,
			navButtonPress: [oController.onNavButtonPress, oController],
			content: []
		}).addStyleClass("sapUiSizeCompact backgrnd");

		var app = new sap.m.App("IdocStatusApp", {
			initialPage: "oPage"
		});
		app.addPage(oPage);
		return app;
	}

});