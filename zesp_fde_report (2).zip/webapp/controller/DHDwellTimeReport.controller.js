var vPlant;
var vRegion;
sap.ui.define([
		"sap/ui/core/mvc/Controller",
		"sap/ui/layout/form/GridLayout",
		"sap/m/Panel",
		"sap/ui/model/json/JSONModel",
		"com/report/model/DHPersoService",
		"sap/m/TablePersoController",
		"sap/ui/core/util/Export",
		"sap/ui/core/util/ExportTypeCSV",
		"sap/ui/model/Filter",
		"sap/ui/model/Sorter",
		"com/report/model/formatter",
		"sap/m/MessageBox"
	],
	function(Controller, GridLayout, Panel, JSONModel, DHPersoService, TablePersoController, Export, ExportTypeCSV, Filter, Sorter,
		formatter, MessageBox) {
		"use strict";
		return Controller.extend("com.report.controller.DHDwellTimeReport", {

			onInit: function() {
				jQuery.sap.require("jquery.sap.storage");
				var that = this;

				var oRouter = sap.ui.core.UIComponent.getRouterFor(this);
				oRouter.getRoute("DHDwellTimeReport").attachMatched(this._onRouteMatched, this);
				var oViewObj = {
					ParentPlant: jQuery.sap.storage(jQuery.sap.storage.Type.local).get("ParentPlant")
				};
				var oViewModel = new JSONModel(oViewObj);
				that.getView().setModel(oViewModel, "ViewModel");

				var oDesktopDevice = sap.ui.Device.system.desktop;
				if (oDesktopDevice === true) {
					var oTitleBar = sap.ui.xmlfragment(this.createId("DHToolBar_Detail_Bar_ID"), "com.report.fragments.DHToolBarDetails", this);
					this.getView().addDependent(oTitleBar);
					this.getView().byId("DHDTReportPage").addContent(oTitleBar);

				} else {
					var oTitleBarMobile = sap.ui.xmlfragment(this.createId("DHTool_Mobile_Bar_ID"),
						"com.report.fragments.MobileHeaderDHDetails", this);
					this.getView().addDependent(oTitleBarMobile);
					this.getView().byId("DHDTReportPage").addContent(oTitleBarMobile);
				}

				var oGridLayout = new sap.ui.layout.Grid({
					defaultSpan: "L12 M12 S12",
					content: [
						new sap.m.Panel("DHTablepanel", {
							expandable: true,
							expanded: true,
							headerToolbar: new sap.m.Toolbar({
								content: [
									new sap.m.Title({
										text: "{i18n>DHDwellTymReport}"
									}).addStyleClass("pHeaderText"),
									new sap.m.ToolbarSpacer({}),
									new sap.m.Button({
										icon: "sap-icon://filter",
										press: function() {
											that.onFilterPressed();
										}
									}).addStyleClass("headerButton"),
									new sap.m.Button({
										icon: "sap-icon://sort",
										press: function() {
											that.onDHSorterPressed();
										}
									}).addStyleClass("headerButton"),
									new sap.m.Button({
										icon: "sap-icon://expand-group",
										press: function(oEvent) {
											that.onDHPressExp(oEvent);
										}
									}).addStyleClass("headerButton"),
									new sap.m.Button({
										icon: "sap-icon://refresh",
										press: function() {
											that.onDHTableRefresh();
										}
									}).addStyleClass("headerButton")
								]
							}),
							content: [
								new sap.m.Toolbar({
									content: [
										new sap.m.Label("DHReportheaderData", {
											text: "",
											design: "Bold"
										}),
										new sap.m.ToolbarSpacer({}),
										new sap.m.CheckBox("DHgroupCheck", {
											text: "{i18n>enablePerso}",
											select: function() {
												that.onDHTableGrouping();
											}
										}),
										new sap.m.Button({
											icon: "sap-icon://action-settings",
											press: function() {
												that.onDHPersoButtonPressed();
											}
										})
									]
								}),
								new sap.m.ScrollContainer("DHrejectscroll", {
									horizontal: true,
									vertical: true,
									height: '25rem',
									content: [
										new sap.m.Table("DHReportTab", {
											width: "4800px",
											mode: "SingleSelectMaster",
											// updateFinished: function(eve) {
											// 	that.onDHTableUpdateFinished(eve);
											// },
											columns: [new sap.m.Column("DHContainerID", {
													header: new sap.m.Label({
														text: "{i18n>ContainerID}",
														design: "Bold"
													}).addStyleClass("columnLabelStyle"),
													width: "8px"
												}), new sap.m.Column("DHCarrier", {
													header: new sap.m.Label({
														text: "{i18n>Carrier}",
														design: "Bold"
													}).addStyleClass("columnLabelStyle"),
													width: "12px"
												}), new sap.m.Column("DHType", {
													header: new sap.m.Label({
														text: "{i18n>checkInTyp}",
														design: "Bold"
													}).addStyleClass("columnLabelStyle"),
													width: "16px"
												}), new sap.m.Column("DHCheckInTimestamp", {
													header: new sap.m.Label({
														text: "{i18n>CheckIn}",
														design: "Bold"
													}).addStyleClass("columnLabelStyle"),
													width: "18px"
												}), new sap.m.Column("DHDeliveryCreationTimestamp", {
													header: new sap.m.Label({
														text: "{i18n>DeliveryCreationTimestamp}",
														design: "Bold"
													}).addStyleClass("columnLabelStyle"),
													width: "18px"
												}), new sap.m.Column("DHUnloadStartTimestamp", {
													header: new sap.m.Label({
														text: "{i18n>UnloadStartTimestamp}",
														design: "Bold"
													}).addStyleClass("columnLabelStyle"),
													width: "18px"
												}), new sap.m.Column("DHUnloadCompTimestamp", {
													header: new sap.m.Label({
														text: "{i18n>UnloadCompTimestamp}",
														design: "Bold"
													}).addStyleClass("columnLabelStyle"),
													width: "18px"
												}), new sap.m.Column("DHLoadStartTimestamp", {
													header: new sap.m.Label({
														text: "{i18n>LoadStartTimestamp}",
														design: "Bold"
													}).addStyleClass("columnLabelStyle"),
													width: "15px"
												}), new sap.m.Column("DHLoadCompletionTimestamp", {
													header: new sap.m.Label({
														text: "{i18n>LoadCompletionTimestamp}",
														design: "Bold"
													}).addStyleClass("columnLabelStyle"),
													width: "18px"
												}), new sap.m.Column("DHCheckOutTimestamp", {
													header: new sap.m.Label({
														text: "{i18n>CheckOut}",
														design: "Bold"
													}).addStyleClass("columnLabelStyle"),
													width: "16px"
												}), new sap.m.Column("DHUADwellTime", {
													header: new sap.m.Label({
														text: "{i18n>UADwellTime}",
														design: "Bold"
													}).addStyleClass("columnLabelStyle"),
													width: "8px"
												}), new sap.m.Column("DHLoadedDwellTime", {
													header: new sap.m.Label({
														text: "{i18n>LoadedDwellTime}",
														design: "Bold"
													}).addStyleClass("columnLabelStyle"),
													width: "10px"
												}), new sap.m.Column("DHUnloadingDwellTime", {
													header: new sap.m.Label({
														text: "{i18n>UnloadingDwellTime}",
														design: "Bold"
													}).addStyleClass("columnLabelStyle"),
													width: "12px"
												}), new sap.m.Column("DHEmptyDwellTime", {
													header: new sap.m.Label({
														text: "{i18n>EmptyDwellTime}",
														design: "Bold"
													}).addStyleClass("columnLabelStyle"),
													width: "10px"
												}), new sap.m.Column("DHLoadingDwellTime", {
													header: new sap.m.Label({
														text: "{i18n>LoadingDwellTime}",
														design: "Bold"
													}).addStyleClass("columnLabelStyle"),
													width: "10px"
												}), new sap.m.Column("DHPreloadDwellTime", {
													header: new sap.m.Label({
														text: "{i18n>PreloadDwellTime}",
														design: "Bold"
													}).addStyleClass("columnLabelStyle"),
													width: "12px"
												}), new sap.m.Column("DHTotalDwellTime", {
													header: new sap.m.Label({
														text: "{i18n>TotalDwellTime}",
														design: "Bold"
													}).addStyleClass("columnLabelStyle"),
													width: "20px"
												}),

												new sap.m.Column("DHIBDelivery", {
													header: new sap.m.Label({
														text: "{i18n>ibDelv}",
														design: "Bold"
													}).addStyleClass("columnLabelStyle"),
													width: "10px"
												}),

												new sap.m.Column("DHOBDelivery", {
													header: new sap.m.Label({
														text: "{i18n>obDelv}",
														design: "Bold"
													}).addStyleClass("columnLabelStyle"),
													width: "10px"
												}),

												new sap.m.Column("DHInboundDriverName", {
													header: new sap.m.Label({
														text: "{i18n>InboundDriverName}",
														design: "Bold"
													}).addStyleClass("columnLabelStyle"),
													width: "16px"
												}), new sap.m.Column("DHOutboundDriverName", {
													header: new sap.m.Label({
														text: "{i18n>OutboundDriverName}",
														design: "Bold"
													}).addStyleClass("columnLabelStyle"),
													width: "18px"
												}),

												new sap.m.Column("DHAppointmentTime", {
													header: new sap.m.Label({
														text: "{i18n>appTime}",
														design: "Bold"
													}).addStyleClass("columnLabelStyle"),
													width: "14px"
												}),

												new sap.m.Column("DHPlannedGIDate", {
													header: new sap.m.Label({
														text: "{i18n>planGIdate}",
														design: "Bold"
													}).addStyleClass("columnLabelStyle"),
													width: "12px"
												}), new sap.m.Column("DHDoorArrivalTime", {
													header: new sap.m.Label({
														text: "{i18n>doorArrivTime}",
														design: "Bold"
													}).addStyleClass("columnLabelStyle"),
													width: "14px"
												}), new sap.m.Column("DHParkTime", {
													header: new sap.m.Label({
														text: "{i18n>parkTime}",
														design: "Bold"
													}).addStyleClass("columnLabelStyle"),
													width: "14px"
												}),
												new sap.m.Column("DHTrailerType", {
													header: new sap.m.Label({
														text: "{i18n>trailtype}",
														design: "Bold"
													}).addStyleClass("columnLabelStyle"),
													width: "10px"
												}), new sap.m.Column("DHCheckInSystem", {
													header: new sap.m.Label({
														text: "{i18n>checkInSys}",
														design: "Bold"
													}).addStyleClass("columnLabelStyle"),
													width: "12px"
												}), new sap.m.Column("DHCheckInType", {
													header: new sap.m.Label({
														text: "{i18n>checkOutType}",
														design: "Bold"
													}).addStyleClass("columnLabelStyle"),
													width: "18px"
												}), new sap.m.Column("DHCheckOutSystem", {
													header: new sap.m.Label({
														text: "{i18n>checkOutSys}",
														design: "Bold"
													}).addStyleClass("columnLabelStyle"),
													width: "12px"
												}), new sap.m.Column("DHTrailerSeal", {
													header: new sap.m.Label({
														text: "{i18n>TrailerSeal}",
														design: "Bold"
													}).addStyleClass("columnLabelStyle"),
													width: "10px"
												})

											]
										}).addStyleClass("tableStyle")
									]
								}).addStyleClass("tableClass")
							]
						}).addStyleClass("pHeading panelBackground")
					]
				}).addStyleClass("sapUiSmallMarginTop");
				that.byId("DHDTReportPage").addContent(oGridLayout);
				this._oTPC = new TablePersoController({
					table: sap.ui.getCore().byId("DHReportTab"),
					componentName: "DHApp",
					persoService: DHPersoService
				}).activate();

			},

			_onRouteMatched: function(oEvent) {
				var that = this;
				that.fnCreateBusyDialog("pallet.svg", "true");
				var oArgs = oEvent.getParameter("arguments");
				vPlant = oArgs.Plants;
				var sDateRange = oArgs.DateRange.split(",");
				var oStartDate = sDateRange[0];
				var newStrDate = oStartDate.replace(/-/g, "");
				var oEndDate = sDateRange[1];
				var newEndDate = oEndDate.replace(/-/g, "");
				oArgs.DateStart = oStartDate;
				oArgs.DateEnd = oEndDate;
				var startTime = oArgs.StartTime;
				var newStrTime = startTime.replace(/:/g, "");
				var endTime = oArgs.EndTime;
				var newEndTime = endTime.replace(/:/g, "");
				var plantModel = new sap.ui.model.json.JSONModel();
				plantModel.setData(oArgs);
				that.getView().setModel(plantModel, "plantDetailModel");
				vRegion = jQuery.sap.storage(jQuery.sap.storage.Type.local).get("region");
				// var sLanguage = that.getCurrentLanguage();
				var sRejecFilter = [];
				sRejecFilter.push(new sap.ui.model.Filter("Plant", sap.ui.model.FilterOperator.EQ, oArgs.Plants));
				sRejecFilter.push(new sap.ui.model.Filter("StartDate", sap.ui.model.FilterOperator.EQ, newStrDate));
				sRejecFilter.push(new sap.ui.model.Filter("EndDate", sap.ui.model.FilterOperator.EQ, newEndDate));
				sRejecFilter.push(new sap.ui.model.Filter("StartTime", sap.ui.model.FilterOperator.EQ, newStrTime));
				sRejecFilter.push(new sap.ui.model.Filter("EndTime", sap.ui.model.FilterOperator.EQ, newEndTime));
				// sRejecFilter.push(new sap.ui.model.Filter("Zlangu", sap.ui.model.FilterOperator.EQ, sLanguage));
				var oTable = sap.ui.getCore().byId("DHReportTab");
				oTable.setBusy(true);
				oTable.setBusyIndicatorDelay(0);
				that.getOwnerComponent().getModel("fdeRepModel").read("/EMPTY_TRAILERSet", {
					filters: sRejecFilter,
					success: function(oData, oResponse) {
						if (oResponse.statusCode === 200 || oResponse.statusCode === "200") {

							for (var k = 0; k < oData.results.length; k++) {
								oData.results[k].Region = vRegion;
							}

							that.bindAllPanelsandTables(oData.results);
						}
						oTable.setBusy(false);
						oTable.setBusyIndicatorDelay(0);
						that.fnCreateBusyDialog("pallet.svg", "false");
					},
					error: function() {
						that.fnCreateBusyDialog("pallet.svg", "false");
						oTable.setBusy(false);
						oTable.setBusyIndicatorDelay(0);
					}
				});
			},

			bindAllPanelsandTables: function(tableData) {
				var that = this;
				// that.onIssuesReturnsBind(tableData);
				that.tableBinding(tableData);
			},
			// for getting the launges code
			// getCurrentLanguage: function() {

			// 	var sCurrentLang = sap.ui.getCore().getConfiguration().getLanguage();
			// 	if (sCurrentLang.indexOf("ES") !== -1 || sCurrentLang.indexOf("es") !== -1) {
			// 		sCurrentLang = "S";
			// 	} else if (sCurrentLang.indexOf("EN") !== -1 || sCurrentLang.indexOf("en") !== -1) {
			// 		sCurrentLang = "E";
			// 	} else if (sCurrentLang.indexOf("NL") !== -1 || sCurrentLang.indexOf("nl") !== -1) {
			// 		sCurrentLang = "N";
			// 	} else if (sCurrentLang.indexOf("FR") !== -1 || sCurrentLang.indexOf("fr") !== -1) {
			// 		sCurrentLang = "F";
			// 	} else if (sCurrentLang.indexOf("PT") !== -1 || sCurrentLang.indexOf("pt") !== -1) {
			// 		sCurrentLang = "P";
			// 	} else if (sCurrentLang.indexOf("IT") !== -1 || sCurrentLang.indexOf("it") !== -1) {
			// 		sCurrentLang = "I";
			// 	} else if (sCurrentLang.indexOf("RO") !== -1 || sCurrentLang.indexOf("ro") !== -1) {
			// 		sCurrentLang = "4";
			// 	} else if (sCurrentLang.indexOf("DE") !== -1 || sCurrentLang.indexOf("de") !== -1) {
			// 		sCurrentLang = "D";
			// 	} else if (sCurrentLang.indexOf("PL") !== -1 || sCurrentLang.indexOf("pl") !== -1) {
			// 		sCurrentLang = "L";
			// 	} else if (sCurrentLang.indexOf("ZH") !== -1 || sCurrentLang.indexOf("zh") !== -1) {
			// 		sCurrentLang = "1";
			// 	} else if (sCurrentLang.indexOf("CS") !== -1 || sCurrentLang.indexOf("cs") !== -1) {
			// 		sCurrentLang = "C";
			// 	} else if (sCurrentLang.indexOf("HU") !== -1 || sCurrentLang.indexOf("hu") !== -1) {
			// 		sCurrentLang = "H";
			// 	} else if (sCurrentLang.indexOf("EL") !== -1 || sCurrentLang.indexOf("el") !== -1) {
			// 		sCurrentLang = "G";
			// 	} else if (sCurrentLang.indexOf("LT") !== -1 || sCurrentLang.indexOf("lt") !== -1) {
			// 		sCurrentLang = "X";
			// 	} else if (sCurrentLang.indexOf("SK") !== -1 || sCurrentLang.indexOf("sk") !== -1) {
			// 		sCurrentLang = "Q";
			// 	} else if (sCurrentLang.indexOf("TR") !== -1 || sCurrentLang.indexOf("tr") !== -1) {
			// 		sCurrentLang = "T";
			// 	} else if (sCurrentLang.indexOf("BG") !== -1 || sCurrentLang.indexOf("bg") !== -1) {
			// 		sCurrentLang = "W";
			// 	} else if (sCurrentLang.indexOf("DA") !== -1 || sCurrentLang.indexOf("da") !== -1) {
			// 		sCurrentLang = "K";
			// 	} else if (sCurrentLang.indexOf("FI") !== -1 || sCurrentLang.indexOf("fi") !== -1) {
			// 		sCurrentLang = "U";
			// 	} else if (sCurrentLang.indexOf("SV") !== -1 || sCurrentLang.indexOf("sv") !== -1) {
			// 		sCurrentLang = "V";
			// 	} else {
			// 		sCurrentLang = "E";
			// 	}
			// 	return sCurrentLang;
			// },
			//binding the data to table
			tableBinding: function(tableData) {
				/*Pass Data to Tables*/
				var that = this;
				var oTemplate = new sap.m.ColumnListItem({
					type: "Navigation",
					cells: [
						new sap.m.Text({
							text: "{Containerid}"
						}).addStyleClass("bold"),
						new sap.m.Text({
							text: "{Carrier}"
						}),
						new sap.m.Text({
							text: "{Type}"
						}),
						new sap.m.Text({
							text: {
								parts: [{
									path: "CheckInTimestamp"
								}, {
									path: "Region"
								}],
								formatter: function(updttime, Region) {
									return formatter.UpdateTime(updttime, Region);
								}
							}
						}),
						new sap.m.Text({
							text: {
								parts: [{
									path: "DeliveryCreationTimestamp"
								}, {
									path: "Region"
								}],
								formatter: function(updttime, Region) {
									return formatter.UpdateTime(updttime, Region);
								}
							}
						}),
						new sap.m.Text({
							text: {
								parts: [{
									path: "UnloadStartTimestamp"
								}, {
									path: "Region"
								}],
								formatter: function(updttime, Region) {
									return formatter.UpdateTime(updttime, Region);
								}
							}
						}),
						new sap.m.Text({
							text: {
								parts: [{
									path: "UnloadCompletionTimestamp"
								}, {
									path: "Region"
								}],
								formatter: function(updttime, Region) {
									return formatter.UpdateTime(updttime, Region);
								}
							}
						}),
						new sap.m.Text({
							text: {
								parts: [{
									path: "LoadStartTimestamp"
								}, {
									path: "Region"
								}],
								formatter: function(updttime, Region) {
									return formatter.UpdateTime(updttime, Region);
								}
							}
						}),
						new sap.m.Text({
							text: {
								parts: [{
									path: "LoadCompletionTimestamp"
								}, {
									path: "Region"
								}],
								formatter: function(updttime, Region) {
									return formatter.UpdateTime(updttime, Region);
								}
							}
						}),
						new sap.m.Text({
							text: {
								parts: [{
									path: "CheckOutTimestamp"
								}, {
									path: "Region"
								}],
								formatter: function(updttime, Region) {
									return formatter.UpdateTime(updttime, Region);
								}
							}
						}),
						new sap.m.Text({
							text: "{UaDwellTime}"
						}),
						new sap.m.Text({
							text: "{LoadedDwellTime}"
						}),
						new sap.m.Text({
							text: "{UnloadingDwellTime}"
						}),
						new sap.m.Text({
							text: "{EmptyDwellTime}"
						}),
						new sap.m.Text({
							text: "{LoadingDwellTime}"
						}),
						new sap.m.Text({
							text: "{PreloadDwellTime}"
						}),
						new sap.m.Text({
							text: "{TotalDwellTime}"
						}),

						new sap.m.Text({
							text: "{InboundDelivery}"
						}),
						new sap.m.Text({
							text: "{OutboundDelivery}"
						}),
						new sap.m.Text({
							text: "{InboundDriverName}"
						}),
						new sap.m.Text({
							text: "{OutboundDriverName}"
						}),
						new sap.m.Text({
							text: "{AppointmentTime}"
						}),
						new sap.m.Text({
							text: {
								parts: [{
									path: 'PlannedGiDate'
								}, {
									path: 'Region'
								}],
								formatter: function(GiTime, Region) {
									return formatter.DwellRepPlannedGIdate(GiTime, Region);
								}

							}
						}),
						new sap.m.Text({
							// text: "{DoorArrivalTime}"
							text: {
								parts: [{
									path: 'DoorArrivalTime'
								}, {
									path: 'Region'
								}],
								formatter: function(DoorTime, Region) {
									return formatter.DwellRepDoorArrival(DoorTime, Region);
								}

							}
						}),
						new sap.m.Text({
							text: {
								parts: [{
									path: 'ParkTime'
								}, {
									path: 'Region'
								}],
								formatter: function(DoorTime, Region) {
									return formatter.DwellRepDoorArrival(DoorTime, Region);
								}

							}
						}),
						new sap.m.Text({
							text: "{TrailerType}"
						}),
						new sap.m.Text({
							text: "{CheckInSystem}"
						}),
						new sap.m.Text({
							text: "{CheckInType}"
						}),
						new sap.m.Text({
							text: "{CheckOutSystem}"
						}),

						new sap.m.Text({
							text: "{TrailerSeal}"
						})

					]
				});

				/*Table Binding*/
				var oRejReportTable = sap.ui.getCore().byId("DHReportTab");
				var oModel1 = new sap.ui.model.json.JSONModel();
				oModel1.setSizeLimit(tableData.length);
				oModel1.setData(tableData);
				if (oRejReportTable !== undefined) {
					oRejReportTable.setModel(oModel1);
					oRejReportTable.bindAggregation("items", {
						path: "/",
						template: oTemplate
					});
				}
				/*Table Grouping*/
				var oGroupingModel = new JSONModel({
					hasGrouping: false
				});
				this.getView().setModel(oGroupingModel, 'Grouping');

			},
			// onDHTableUpdateFinished: function(oEvent) {
			// 	// var oData = sap.ui.getCore().byId("RejReportTab").getModel().getData();
			// 	var aItems = sap.ui.getCore().byId("DHReportTab").getItems();
			// 	// var data =oData.results;
			// 	/*	for (var i = 0; i < oData.length; i++) {
			// 		if (oData[i].Zymstatus === "DELE") {
			// 			aItems[i].addStyleClass("redBack");
			// 		}
			// 	}*/
			// 	for (var i = 0; i < aItems.length; i++) {
			// 		var sObj = aItems[i].getBindingContext().getObject();
			// 		if (sObj.Zymstatus === "DELE") {
			// 			aItems[i].addStyleClass("redBack");
			// 		} else {
			// 			aItems[i].removeStyleClass("redBack");
			// 		}
			// 	}
			// },
			//----------------------------------------------------------------------------------
			//Function to create Busy Dialog
			//----------------------------------------------------------------------------------
			fnCreateBusyDialog: function(sImage, sBusy) {
				var that = this;
				//	that.oInsCreateDailog;
				if (sBusy === "true") {
					that.oInsCreateDailog = new sap.m.Dialog({
						showHeader: false
					}).addStyleClass("busyDialog sapUiTinyMargin");
					var sComponentName = that.getOwnerComponent().getMetadata().getComponentName();
					var imgUrl = $.sap.getModulePath(sComponentName, "/images/");
					var oImage = new sap.m.Image().addStyleClass("sapUiMediumMargin");
					oImage.setSrc(imgUrl + sImage);
					that.oInsCreateDailog.addContent(oImage);
					that.oInsCreateDailog.open();
				} else {
					that.oInsCreateDailog.close();
				}
			},

			loadFiltersData: function() {
				var filterResults = sap.ui.getCore().byId("DHReportTab").getModel().getData();

				//----Binded unique data of Location to filter fragment----//
				var Carrierarray = [];
				for (var i = 0; i < filterResults.length; i++) {
					if (Carrierarray.indexOf(filterResults[i].Carrier) === -1) {
						Carrierarray.push(filterResults[i].Carrier);
					}
				}
				if (sap.ui.getCore().byId("DHCarrierFilter") !== undefined) {
					sap.ui.getCore().byId("DHCarrierFilter").setModel(new JSONModel(Carrierarray), "Carrier");
				}

				//----Binded unique data of Users to filter fragment----//
				var Typearray = [];
				for (var i = 0; i < filterResults.length; i++) {
					if (Typearray.indexOf(filterResults[i].Type) === -1) {
						Typearray.push(filterResults[i].Type);
					}
				}
				if (sap.ui.getCore().byId("DHTypeFilter") !== undefined) {
					sap.ui.getCore().byId("DHTypeFilter").setModel(new JSONModel(Typearray), "Type");
				}

				//----CTRM-1424 Binded unique data of Action to filter fragment----//
				var ATrailerTypearray = [];
				for (var i = 0; i < filterResults.length; i++) {
					if (ATrailerTypearray.indexOf(filterResults[i].TrailerType) === -1) {
						ATrailerTypearray.push(filterResults[i].TrailerType);
					}
				}
				if (sap.ui.getCore().byId("DHTrailerTypeFilter") !== undefined) {
					sap.ui.getCore().byId("DHTrailerTypeFilter").setModel(new JSONModel(ATrailerTypearray), "TrailerType");
				}

				//----Binded unique data of parentplants to filter fragment----//
				var parentplant = [];
				for (var i = 0; i < filterResults.length; i++) {
					if (parentplant.indexOf(filterResults[i].Plant) === -1) {
						parentplant.push(filterResults[i].Plant);
					}
				}
				if (sap.ui.getCore().byId("DHPlantFilter") !== undefined) {
					sap.ui.getCore().byId("DHPlantFilter").setModel(new JSONModel(parentplant), "sParentPlant");
				}
			},

			onFilterPressed: function() {
				var that = this;
				that.oInsCreateDailog.open();

				if (!this._filterDialog) {
					this._filterDialog = sap.ui.xmlfragment("com.report.fragments.DHFilter", this);
					this.getView().addDependent(this._filterDialog);
				}
				/*** adding filter items for the multiplant/ parentplant scenario ***/
				var parentplant = this.getView().getModel("ViewModel").getProperty("/ParentPlant");
				if (parentplant !== "") {
					if (sap.ui.getCore().byId("DHPlantFilter") === undefined) {
						var ParentPlantFilter = new sap.m.ViewSettingsFilterItem("DHPlantFilter", {
							multiSelect: true,
							text: "{i18n>Plant}"

						});
						var Template = new sap.m.ViewSettingsItem({
							key: "Plant",
							text: "{sParentPlant>}"
						});
						ParentPlantFilter.bindAggregation("items", "sParentPlant>/", Template);
						this._filterDialog.addFilterItem(ParentPlantFilter);
					}
				}
				this.loadFiltersData();
				// toggle compact style
				jQuery.sap.syncStyleClass("sapUiSizeCompact", this.getView(), this._filterDialog);
				this._filterDialog.open();

				that.oInsCreateDailog.close();
			},

			//---------------------Code for filtering----------------------//

			onDHFilterConfirm: function(oEvent) {
				var that = this;
				that.oInsCreateDailog.open();
				var oView = sap.ui.getCore();
				if (oView.byId("DHReportTab") !== undefined) {
					var rejTableFilter = oView.byId("DHReportTab");
					var mParams = oEvent.getParameters();
					var oBinding = rejTableFilter.getBinding("items");
					var aFilters = [];
					for (var i = 0, l = mParams.filterItems.length; i < l; i++) {
						var oItem = mParams.filterItems[i];
						if (oItem.getKey() === "Carrier") {
							var oFilter1 = new sap.ui.model.Filter("Carrier", "EQ", oItem.getText());
							aFilters.push(oFilter1);
						} else if (oItem.getKey() === "Type") {
							var oFilter2 = new sap.ui.model.Filter("Type", "EQ", oItem.getText());
							aFilters.push(oFilter2);
						} else if (oItem.getKey() === "Plant") {
							var oFilter3 = new sap.ui.model.Filter("Plant", "EQ", oItem.getText());
							aFilters.push(oFilter3);
						} else if (oItem.getKey() === "TrailerType") {
							var oFilter4 = new sap.ui.model.Filter("TrailerType", "EQ", oItem.getText()); //CTRM-1424
							aFilters.push(oFilter4);
						}
					}
					oBinding.filter(aFilters);
				}

				that.oInsCreateDailog.close();

				if (oEvent.getParameters().filterString) {
					var filteredData = oEvent.getParameters().filterString;
				}
				sap.ui.getCore().byId("DHReportheaderData").setText(filteredData);
			},

			onDHTableRefresh: function() {
				//Remove Filters
				if (sap.ui.getCore().byId("DHReportTab") !== undefined) {
					var oTable = sap.ui.getCore().byId("DHReportTab");
					var oModel = oTable.getModel();
					var oTableBinding = oTable.getBinding("items");
					oTableBinding.aSorters = null;
					oTableBinding.aFilters = null;
					oModel.refresh(true);
				}
				if (sap.ui.getCore().byId("DHReportheaderData") !== undefined) {
					sap.ui.getCore().byId("DHReportheaderData").setText("");
				}
				this.resetFilterItems();
			},

			resetFilterItems: function() {
				var that = this;
				that.oInsCreateDailog.open();
				if (this._filterDialog !== undefined) {
					var aFilterItems = this._filterDialog.getFilterItems();

					aFilterItems.forEach(function(item) {
						var aItems = item.getItems();
						aItems.forEach(function(item) {
							item.setSelected(false);
						});
					});
				}
				that.oInsCreateDailog.close();
			},

			//----------------Code for opening Sorter Dailog when sorter icon pressed---------------------//

			onDHSorterPressed: function() {
				var that = this;
				that.oInsCreateDailog.open();
				if (!this._sorterDialog) {
					this._sorterDialog = sap.ui.xmlfragment("com.report.fragments.DHSorter", this);
					this.getView().addDependent(this._sorterDialog);
				}
				/*** adding sort items for the multiplant scenario ***/
				var parentplant = this.getView().getModel("ViewModel").getProperty("/ParentPlant");
				if (parentplant !== "") {
					if (sap.ui.getCore().byId("RejPlantSorter") === undefined) {
						var ParentPlantSort = new sap.m.ViewSettingsItem("RejPlantSorter", {
							text: "{i18n>Plant}",
							key: "Plant"

						});
						this._sorterDialog.addSortItem(ParentPlantSort);
					}
				}
				// toggle compact style
				jQuery.sap.syncStyleClass("sapUiSizeCompact", this.getView(), this._sorterDialog);
				this._sorterDialog.open();
				that.oInsCreateDailog.close();
			},

			//-----------------------Code for Sorting---------------------------//

			onDHSortConfirm: function(oEvent) {

				var that = this;
				that.oInsCreateDailog.open();
				var oView = sap.ui.getCore();
				if (oView.byId("DHReportTab") !== undefined) {
					var rejecRepTable = oView.byId("DHReportTab");
					var mParams = oEvent.getParameters();
					var oBinding = rejecRepTable.getBinding("items");
					var aSorters = [];
					if (mParams.sortItem !== undefined) {
						var sPath = mParams.sortItem.getKey();
						var bDescending = mParams.sortDescending;
						aSorters.push(new sap.ui.model.Sorter(sPath, bDescending));
						oBinding.sort(aSorters);
					}
				}

				that.oInsCreateDailog.close();
			},

			//-----------------------------------------------------------------------------------------
			// Function for expanding the pnales inside the plant panels
			//-----------------------------------------------------------------------------------------
			onDHPressExp: function(oEvent) {
				var oPanelId = oEvent.getSource().getParent().getParent().getId();
				var oButtonId = oEvent.getSource().getId();
				if (sap.ui.getCore().byId(oPanelId).getExpanded()) {
					sap.ui.getCore().byId(oPanelId).setExpanded(false);
					sap.ui.getCore().byId(oButtonId).setIcon("sap-icon://expand-group");
				} else {
					sap.ui.getCore().byId(oPanelId).setExpanded(true);
					sap.ui.getCore().byId(oButtonId).setIcon("sap-icon://collapse-group");
				}
			},

			//-----------------------------------------------------------------------------------------
			// Function for table export
			//-----------------------------------------------------------------------------------------

			onPressExport: sap.m.Table.prototype.exportData || function(oEvent) {
				var oExport = new Export({
					exportType: new ExportTypeCSV({
						separatorChar: ",",
						fileExtension: "csv"
					}),
					models: sap.ui.getCore().byId("DHReportTab").getModel(),
					rows: {
						path: "/"
					},

					columns: [{
							name: this.getOwnerComponent().getModel("i18n").getProperty("ContainerID"),
							template: {
								content: "{Containerid}"
							}
						}, {

							name: this.getOwnerComponent().getModel("i18n").getProperty("Carrier"),
							template: {
								content: "{Carrier}"
							}
						}, {

							name: this.getOwnerComponent().getModel("i18n").getProperty("checkInTyp"),
							template: {
								content: "{Type}"
							}
						}, {

							name: this.getOwnerComponent().getModel("i18n").getProperty("CheckIn"),
							template: {
								// content: "{CheckInTimestamp}"
								content: {
									parts: ["CheckInTimestamp", "Region"],
									formatter: function(CheckInTimestamp, Region) {
										if (Region === "EU" || Region === "LATAM" || Region === "ZA") {
											if (CheckInTimestamp !== null && CheckInTimestamp !== "0") {
												var newUpdateTime = CheckInTimestamp.slice(6, 8) + "/" + CheckInTimestamp.slice(4, 6) + "/" + CheckInTimestamp.slice(0, 4) +
													" " +
													CheckInTimestamp.slice(8, 10) + ":" +
													CheckInTimestamp.slice(10, 12) + ":" + CheckInTimestamp.slice(12, 14);
												return newUpdateTime;
											}
										} else {
											if (CheckInTimestamp !== null && CheckInTimestamp !== "0") {
												var newUpdateTime = CheckInTimestamp.slice(4, 6) + "/" + CheckInTimestamp.slice(6, 8) + "/" + CheckInTimestamp.slice(0, 4) +
													" " +
													CheckInTimestamp.slice(8, 10) + ":" +
													CheckInTimestamp.slice(10, 12) + ":" + CheckInTimestamp.slice(12, 14);
												return newUpdateTime;
											}
										}
									}
								}
							}
						}, {

							name: this.getOwnerComponent().getModel("i18n").getProperty("DeliveryCreationTimestamp"),
							template: {
								// content: "{DeliveryCreationTimestamp}"
								content: {
									parts: ["DeliveryCreationTimestamp", "Region"],
									formatter: function(DeliveryCreationTimestamp, Region) {
										if (Region === "EU" || Region === "LATAM" || Region === "ZA") {
											if (DeliveryCreationTimestamp !== null && DeliveryCreationTimestamp !== "0") {
												var newUpdateTime = DeliveryCreationTimestamp.slice(6, 8) + "/" + DeliveryCreationTimestamp.slice(4, 6) + "/" +
													DeliveryCreationTimestamp.slice(0, 4) + " " +
													DeliveryCreationTimestamp.slice(8, 10) + ":" +
													DeliveryCreationTimestamp.slice(10, 12) + ":" + DeliveryCreationTimestamp.slice(12, 14);
												return newUpdateTime;
											}
										} else {
											if (DeliveryCreationTimestamp !== null && DeliveryCreationTimestamp !== "0") {
												var newUpdDeliveryCreationTimestampateTime = DeliveryCreationTimestamp.slice(4, 6) + "/" + DeliveryCreationTimestamp.slice(
														6, 8) + "/" + DeliveryCreationTimestamp.slice(0, 4) + " " +
													DeliveryCreationTimestamp.slice(8, 10) + ":" +
													DeliveryCreationTimestamp.slice(10, 12) + ":" + DeliveryCreationTimestamp.slice(12, 14);
												return newUpdateTime;
											}
										}
									}
								}
							}
						}, {

							name: this.getOwnerComponent().getModel("i18n").getProperty("UnloadStartTimestamp"),
							template: {
								// content: "{UnloadStartTimestamp}"
								content: {
									parts: ["UnloadStartTimestamp", "Region"],
									formatter: function(UnloadStartTimestamp, Region) {
										if (Region === "EU" || Region === "LATAM" || Region === "ZA") {
											if (UnloadStartTimestamp !== null && UnloadStartTimestamp !== "0") {
												var newUpdateTime = UnloadStartTimestamp.slice(6, 8) + "/" + UnloadStartTimestamp.slice(4, 6) + "/" + UnloadStartTimestamp.slice(
														0, 4) + " " +
													UnloadStartTimestamp.slice(8, 10) + ":" +
													UnloadStartTimestamp.slice(10, 12) + ":" + UnloadStartTimestamp.slice(12, 14);
												return newUpdateTime;
											}
										} else {
											if (UnloadStartTimestamp !== null && UnloadStartTimestamp !== "0") {
												var newUpdateTime = UnloadStartTimestamp.slice(4, 6) + "/" + UnloadStartTimestamp.slice(6, 8) + "/" + UnloadStartTimestamp.slice(
														0, 4) + " " +
													UnloadStartTimestamp.slice(8, 10) + ":" +
													UnloadStartTimestamp.slice(10, 12) + ":" + UnloadStartTimestamp.slice(12, 14);
												return newUpdateTime;
											}
										}
									}
								}
							}
						}, {

							name: this.getOwnerComponent().getModel("i18n").getProperty("UnloadCompTimestamp"),
							template: {
								// content: "{UnloadCompletionTimestamp}"
								content: {
									parts: ["UnloadCompletionTimestamp", "Region"],
									formatter: function(UnloadCompletionTimestamp, Region) {
										if (Region === "EU" || Region === "LATAM" || Region === "ZA") {
											if (UnloadCompletionTimestamp !== null && UnloadCompletionTimestamp !== "0") {
												var newUpdateTime = UnloadCompletionTimestamp.slice(6, 8) + "/" + UnloadCompletionTimestamp.slice(4, 6) + "/" +
													UnloadCompletionTimestamp.slice(0, 4) + " " +
													UnloadCompletionTimestamp.slice(8, 10) + ":" +
													UnloadCompletionTimestamp.slice(10, 12) + ":" + UnloadCompletionTimestamp.slice(12, 14);
												return newUpdateTime;
											}
										} else {
											if (UnloadCompletionTimestamp !== null && UnloadCompletionTimestamp !== "0") {
												var newUpdateTime = UnloadCompletionTimestamp.slice(4, 6) + "/" + UnloadCompletionTimestamp.slice(6, 8) + "/" +
													UnloadCompletionTimestamp.slice(0, 4) + " " +
													UnloadCompletionTimestamp.slice(8, 10) + ":" +
													UnloadCompletionTimestamp.slice(10, 12) + ":" + UnloadCompletionTimestamp.slice(12, 14);
												return newUpdateTime;
											}
										}
									}
								}
							}
						}, {

							name: this.getOwnerComponent().getModel("i18n").getProperty("LoadStartTimestamp"),
							template: {
								// content: "{LoadStartTimestamp}"
								content: {
									parts: ["LoadStartTimestamp", "Region"],
									formatter: function(LoadStartTimestamp, Region) {
										if (Region === "EU" || Region === "LATAM" || Region === "ZA") {
											if (LoadStartTimestamp !== null && LoadStartTimestamp !== "0") {
												var newUpdateTime = LoadStartTimestamp.slice(6, 8) + "/" + LoadStartTimestamp.slice(4, 6) + "/" + LoadStartTimestamp.slice(
														0, 4) + " " +
													LoadStartTimestamp.slice(8, 10) + ":" +
													LoadStartTimestamp.slice(10, 12) + ":" + LoadStartTimestamp.slice(12, 14);
												return newUpdateTime;
											}
										} else {
											if (LoadStartTimestamp !== null && LoadStartTimestamp !== "0") {
												var newUpdateTime = LoadStartTimestamp.slice(4, 6) + "/" + LoadStartTimestamp.slice(6, 8) + "/" + LoadStartTimestamp.slice(
														0, 4) + " " +
													LoadStartTimestamp.slice(8, 10) + ":" +
													LoadStartTimestamp.slice(10, 12) + ":" + LoadStartTimestamp.slice(12, 14);
												return newUpdateTime;
											}
										}
									}
								}
							}
						}, {

							name: this.getOwnerComponent().getModel("i18n").getProperty("LoadCompletionTimestamp"),
							template: {
								// content: "{LoadCompletionTimestamp}"
								content: {
									parts: ["LoadCompletionTimestamp", "Region"],
									formatter: function(LoadCompletionTimestamp, Region) {
										if (Region === "EU" || Region === "LATAM" || Region === "ZA") {
											if (LoadCompletionTimestamp !== null && LoadCompletionTimestamp !== "0") {
												var newUpdateTime = LoadCompletionTimestamp.slice(6, 8) + "/" + LoadCompletionTimestamp.slice(4, 6) + "/" +
													LoadCompletionTimestamp.slice(0, 4) + " " +
													LoadCompletionTimestamp.slice(8, 10) + ":" +
													LoadCompletionTimestamp.slice(10, 12) + ":" + LoadCompletionTimestamp.slice(12, 14);
												return newUpdateTime;
											}
										} else {
											if (LoadCompletionTimestamp !== null && LoadCompletionTimestamp !== "0") {
												var newUpdLoadCompletionTimestampateTime = LoadCompletionTimestamp.slice(4, 6) + "/" + LoadCompletionTimestamp.slice(6, 8) +
													"/" + LoadCompletionTimestamp.slice(0, 4) + " " +
													LoadCompletionTimestamp.slice(8, 10) + ":" +
													LoadCompletionTimestamp.slice(10, 12) + ":" + LoadCompletionTimestamp.slice(12, 14);
												return newUpdateTime;
											}
										}
									}
								}
							}
						}, {

							name: this.getOwnerComponent().getModel("i18n").getProperty("CheckOut"),
							template: {
								// content: "{CheckOutTimestamp}"
								content: {
									parts: ["CheckOutTimestamp", "Region"],
									formatter: function(CheckOutTimestamp, Region) {
										if (Region === "EU" || Region === "LATAM" || Region === "ZA") {
											if (CheckOutTimestamp !== null && CheckOutTimestamp !== "0") {
												var newUpdateTime = CheckOutTimestamp.slice(6, 8) + "/" + CheckOutTimestamp.slice(4, 6) + "/" + CheckOutTimestamp.slice(0,
														4) + " " +
													CheckOutTimestamp.slice(8, 10) + ":" +
													CheckOutTimestamp.slice(10, 12) + ":" + CheckOutTimestamp.slice(12, 14);
												return newUpdateTime;
											}
										} else {
											if (CheckOutTimestamp !== null && CheckOutTimestamp !== "0") {
												var newUpdateTime = CheckOutTimestamp.slice(4, 6) + "/" + CheckOutTimestamp.slice(6, 8) + "/" + CheckOutTimestamp.slice(0,
														4) + " " +
													CheckOutTimestamp.slice(8, 10) + ":" +
													CheckOutTimestamp.slice(10, 12) + ":" + CheckOutTimestamp.slice(12, 14);
												return newUpdateTime;
											}
										}
									}
								}
							}
						}, {

							name: this.getOwnerComponent().getModel("i18n").getProperty("UADwellTime"),
							template: {
								content: "{UaDwellTime}"
							}
						}, {

							name: this.getOwnerComponent().getModel("i18n").getProperty("LoadedDwellTime"),
							template: {
								content: "{LoadedDwellTime}"
							}
						}, {

							name: this.getOwnerComponent().getModel("i18n").getProperty("UnloadingDwellTime"),
							template: {
								content: "{UnloadingDwellTime}"
							}
						}, {

							name: this.getOwnerComponent().getModel("i18n").getProperty("EmptyDwellTime"),
							template: {
								content: "{EmptyDwellTime}"
							}
						}, {

							name: this.getOwnerComponent().getModel("i18n").getProperty("LoadingDwellTime"),
							template: {
								content: "{LoadingDwellTime}"
							}
						}, {

							name: this.getOwnerComponent().getModel("i18n").getProperty("PreloadDwellTime"),
							template: {
								content: "{PreloadDwellTime}"
							}
						}, {

							name: this.getOwnerComponent().getModel("i18n").getProperty("TotalDwellTime"),
							template: {
								content: "{TotalDwellTime}"
							}
						}, {

							name: this.getOwnerComponent().getModel("i18n").getProperty("ibDelv"),
							template: {
								content: "{InboundDelivery}"
							}
						},

						{

							name: this.getOwnerComponent().getModel("i18n").getProperty("obDelv"),
							template: {
								content: "{OutboundDelivery}"
							}
						},

						{

							name: this.getOwnerComponent().getModel("i18n").getProperty("InboundDriverName"),
							template: {
								content: "{InboundDriverName}"
							}
						}, {

							name: this.getOwnerComponent().getModel("i18n").getProperty("OutboundDriverName"),
							template: {
								content: "{OutboundDriverName}"
							}
						}, {

							name: this.getOwnerComponent().getModel("i18n").getProperty("appTime"),
							template: {
								// content: "{AppointmentTime}"
								content: {
									parts: ["AppointmentTime", "Region"],
									formatter: function(AppointmentTime, region) {
										if (AppointmentTime !== null) {
											AppointmentTime = AppointmentTime.trim();
											if (region === "EU" || region === "LATAM" || region === "ZA") {
												if ((AppointmentTime === "0") || (AppointmentTime === 0)) {
													return 0;
												} else if (AppointmentTime !== null && AppointmentTime !== "0" && AppointmentTime !== undefined) {
													var newAppointmentTime = AppointmentTime.slice(6, 8) + "/" + AppointmentTime.slice(4, 6) + "/" + AppointmentTime.slice(0,
															4) + " " +
														AppointmentTime.slice(
															8, 10) + ":" + AppointmentTime.slice(10, 12) + ":" + AppointmentTime.slice(12, 14);
													return newAppointmentTime;
												}
											} else {
												if ((AppointmentTime === "0") || (AppointmentTime === 0)) {
													return 0;
												} else if (AppointmentTime !== null && AppointmentTime !== "0" && AppointmentTime !== undefined) {
													var newAppointmentTime = AppointmentTime.slice(4, 6) + "/" + AppointmentTime.slice(6, 8) + "/" + AppointmentTime.slice(0,
															4) + " " +
														AppointmentTime.slice(
															8, 10) + ":" + AppointmentTime.slice(10, 12) + ":" + AppointmentTime.slice(12, 14);
													return newAppointmentTime;
												}
											}
										}
									}
								}
							}
						},

						{

							name: this.getOwnerComponent().getModel("i18n").getProperty("planGIdate"),
							template: {
								// content: "{PlannedGiDate}"
								content: {
									parts: ["PlannedGiDate", "Region"],
									formatter: function(PlannedGiDate, Region) {
										if (Region === "EU" || Region === "LATAM" || Region === "ZA") {
											if (PlannedGiDate !== null && PlannedGiDate !== "0" && PlannedGiDate !== "" && PlannedGiDate !== undefined) {
												var newPlannedGIDate = PlannedGiDate.slice(6, 8) + "/" + PlannedGiDate.slice(4, 6) + "/" + PlannedGiDate.slice(0, 4);
												return newPlannedGIDate;
											}
										} else {
											if (PlannedGiDate !== null && PlannedGiDate !== "0" && PlannedGiDate !== "" && PlannedGiDate !== undefined) {
												var newPlannedGIDate = PlannedGiDate.slice(4, 6) + "/" + PlannedGiDate.slice(6, 8) + "/" + PlannedGiDate.slice(0, 4);
												return newPlannedGIDate;
											}
										}
									}
								}
							}
						}, {

							name: this.getOwnerComponent().getModel("i18n").getProperty("doorArrivTime"),
							template: {
								// content: "{DoorArrivalTime}"
								content: {
									parts: ["DoorArrivalTime", "Region"],
									formatter: function(DoorArrivalTime, Region) {
										if (Region === "EU" || Region === "LATAM" || Region === "ZA") {
											if (DoorArrivalTime === "0") {
												return 0;
											} else if (DoorArrivalTime !== null && DoorArrivalTime !== "0" && DoorArrivalTime !== undefined) {
												var DoorArrivalTime = DoorArrivalTime.slice(6, 8) + "/" + DoorArrivalTime.slice(4, 6) + "/" + DoorArrivalTime.slice(0, 4) +
													" " + DoorArrivalTime.slice(
														8, 10) + ":" + DoorArrivalTime.slice(10, 12) + ":" + DoorArrivalTime.slice(12, 14);
												return DoorArrivalTime;
											}
										} else {

											if (DoorArrivalTime === "0") {
												return 0;
											} else if (DoorArrivalTime !== null && DoorArrivalTime !== "0" && DoorArrivalTime !== undefined) {
												var DoorArrivalTime = DoorArrivalTime.slice(4, 6) + "/" + DoorArrivalTime.slice(6, 8) + "/" + DoorArrivalTime.slice(0, 4) +
													" " + DoorArrivalTime.slice(
														8, 10) + ":" + DoorArrivalTime.slice(10, 12) + ":" + DoorArrivalTime.slice(12, 14);
												return DoorArrivalTime;
											}
										}
									}
								}
							}
						}, {

							name: this.getOwnerComponent().getModel("i18n").getProperty("parkTime"),
							template: {
								// content: "{ParkTime}"
								content: {
									parts: ["ParkTime", "Region"],
									formatter: function(ParkTime, Region) {
										if (Region === "EU" || Region === "LATAM" || Region === "ZA") {
											if (ParkTime === "0") {
												return 0;
											} else if (ParkTime !== null && ParkTime !== "0" && ParkTime !== undefined) {
												var newParkTime = ParkTime.slice(6, 8) + "/" + ParkTime.slice(4, 6) + "/" + ParkTime.slice(0, 4) + " " + ParkTime.slice(
													8, 10) + ":" + ParkTime.slice(10, 12) + ":" + ParkTime.slice(12, 14);
												return newParkTime;
											}
										} else {

											if (ParkTime === "0") {
												return 0;
											} else if (ParkTime !== null && ParkTime !== "0" && ParkTime !== undefined) {
												var newParkTime = ParkTime.slice(4, 6) + "/" + ParkTime.slice(6, 8) + "/" + ParkTime.slice(0, 4) + " " + ParkTime.slice(
													8, 10) + ":" + ParkTime.slice(10, 12) + ":" + ParkTime.slice(12, 14);
												return newParkTime;
											}
										}
									}
								}
							}
						},
						{

							name: this.getOwnerComponent().getModel("i18n").getProperty("trailtype"),
							template: {
								content: "{TrailerType}"
							}
						}, {

							name: this.getOwnerComponent().getModel("i18n").getProperty("checkInSys"),
							template: {
								content: "{CheckInSystem}"
							}
						}, {

							name: this.getOwnerComponent().getModel("i18n").getProperty("checkOutType"),
							template: {
								content: "{CheckInType}"
							}
						}, {

							name: this.getOwnerComponent().getModel("i18n").getProperty("checkOutSys"),
							template: {
								content: "{CheckOutSystem}"
							}
						},

						{

							name: this.getOwnerComponent().getModel("i18n").getProperty("TrailerSeal"),
							template: {
								content: "{TrailerSeal}"
							}
						}

					]
				});

				/*** add this column only when parentplant is active ***/
				var parentplant = this.getView().getModel("ViewModel").getProperty("/ParentPlant");
				if (parentplant !== "") {
					oExport.insertColumn(new sap.ui.core.util.ExportColumn({
						name: this.getOwnerComponent().getModel("i18n").getProperty("Plant"),
						template: {
							content: "{Plant}"
						}
					}), 0);
				}

				var srejectDetails = this.getOwnerComponent().getModel("i18n").getProperty("DHDwellTymReport");
				oExport.saveFile(srejectDetails).catch(function(oError) {
					// MessageBox.error("Error when downloading data. Browser might not be supported!\n\n" + oError);
				}).then(function() {
					oExport.destroy();
				});
			},

			onPressExportXLS: sap.m.Table.prototype.exportData || function(oEvent) {
				var oExport = new Export({
					exportType: new ExportTypeCSV({
						separatorChar: "\t",
						fileExtension: "xls"
					}),
					models: sap.ui.getCore().byId("DHReportTab").getModel(),
					rows: {
						path: "/"
					},

					columns: [{
							name: this.getOwnerComponent().getModel("i18n").getProperty("ContainerID"),
							template: {
								content: "{Containerid}"
							}
						}, {

							name: this.getOwnerComponent().getModel("i18n").getProperty("Carrier"),
							template: {
								content: "{Carrier}"
							}
						}, {

							name: this.getOwnerComponent().getModel("i18n").getProperty("checkInTyp"),
							template: {
								content: "{Type}"
							}
						}, {

							name: this.getOwnerComponent().getModel("i18n").getProperty("CheckIn"),
							template: {
								// content: "{CheckInTimestamp}"
								content: {
									parts: ["CheckInTimestamp", "Region"],
									formatter: function(CheckInTimestamp, Region) {
										if (Region === "EU" || Region === "LATAM" || Region === "ZA") {
											if (CheckInTimestamp !== null && CheckInTimestamp !== "0") {
												var newUpdateTime = CheckInTimestamp.slice(6, 8) + "/" + CheckInTimestamp.slice(4, 6) + "/" + CheckInTimestamp.slice(0, 4) +
													" " +
													CheckInTimestamp.slice(8, 10) + ":" +
													CheckInTimestamp.slice(10, 12) + ":" + CheckInTimestamp.slice(12, 14);
												return newUpdateTime;
											}
										} else {
											if (CheckInTimestamp !== null && CheckInTimestamp !== "0") {
												var newUpdateTime = CheckInTimestamp.slice(4, 6) + "/" + CheckInTimestamp.slice(6, 8) + "/" + CheckInTimestamp.slice(0, 4) +
													" " +
													CheckInTimestamp.slice(8, 10) + ":" +
													CheckInTimestamp.slice(10, 12) + ":" + CheckInTimestamp.slice(12, 14);
												return newUpdateTime;
											}
										}
									}
								}
							}
						}, {

							name: this.getOwnerComponent().getModel("i18n").getProperty("DeliveryCreationTimestamp"),
							template: {
								// content: "{DeliveryCreationTimestamp}"
								content: {
									parts: ["DeliveryCreationTimestamp", "Region"],
									formatter: function(DeliveryCreationTimestamp, Region) {
										if (Region === "EU" || Region === "LATAM" || Region === "ZA") {
											if (DeliveryCreationTimestamp !== null && DeliveryCreationTimestamp !== "0") {
												var newUpdateTime = DeliveryCreationTimestamp.slice(6, 8) + "/" + DeliveryCreationTimestamp.slice(4, 6) + "/" +
													DeliveryCreationTimestamp.slice(0, 4) + " " +
													DeliveryCreationTimestamp.slice(8, 10) + ":" +
													DeliveryCreationTimestamp.slice(10, 12) + ":" + DeliveryCreationTimestamp.slice(12, 14);
												return newUpdateTime;
											}
										} else {
											if (DeliveryCreationTimestamp !== null && DeliveryCreationTimestamp !== "0") {
												var newUpdDeliveryCreationTimestampateTime = DeliveryCreationTimestamp.slice(4, 6) + "/" + DeliveryCreationTimestamp.slice(
														6, 8) + "/" + DeliveryCreationTimestamp.slice(0, 4) + " " +
													DeliveryCreationTimestamp.slice(8, 10) + ":" +
													DeliveryCreationTimestamp.slice(10, 12) + ":" + DeliveryCreationTimestamp.slice(12, 14);
												return newUpdateTime;
											}
										}
									}
								}
							}
						}, {

							name: this.getOwnerComponent().getModel("i18n").getProperty("UnloadStartTimestamp"),
							template: {
								// content: "{UnloadStartTimestamp}"
								content: {
									parts: ["UnloadStartTimestamp", "Region"],
									formatter: function(UnloadStartTimestamp, Region) {
										if (Region === "EU" || Region === "LATAM" || Region === "ZA") {
											if (UnloadStartTimestamp !== null && UnloadStartTimestamp !== "0") {
												var newUpdateTime = UnloadStartTimestamp.slice(6, 8) + "/" + UnloadStartTimestamp.slice(4, 6) + "/" + UnloadStartTimestamp.slice(
														0, 4) + " " +
													UnloadStartTimestamp.slice(8, 10) + ":" +
													UnloadStartTimestamp.slice(10, 12) + ":" + UnloadStartTimestamp.slice(12, 14);
												return newUpdateTime;
											}
										} else {
											if (UnloadStartTimestamp !== null && UnloadStartTimestamp !== "0") {
												var newUpdateTime = UnloadStartTimestamp.slice(4, 6) + "/" + UnloadStartTimestamp.slice(6, 8) + "/" + UnloadStartTimestamp.slice(
														0, 4) + " " +
													UnloadStartTimestamp.slice(8, 10) + ":" +
													UnloadStartTimestamp.slice(10, 12) + ":" + UnloadStartTimestamp.slice(12, 14);
												return newUpdateTime;
											}
										}
									}
								}
							}
						}, {

							name: this.getOwnerComponent().getModel("i18n").getProperty("UnloadCompTimestamp"),
							template: {
								// content: "{UnloadCompletionTimestamp}"
								content: {
									parts: ["UnloadCompletionTimestamp", "Region"],
									formatter: function(UnloadCompletionTimestamp, Region) {
										if (Region === "EU" || Region === "LATAM" || Region === "ZA") {
											if (UnloadCompletionTimestamp !== null && UnloadCompletionTimestamp !== "0") {
												var newUpdateTime = UnloadCompletionTimestamp.slice(6, 8) + "/" + UnloadCompletionTimestamp.slice(4, 6) + "/" +
													UnloadCompletionTimestamp.slice(0, 4) + " " +
													UnloadCompletionTimestamp.slice(8, 10) + ":" +
													UnloadCompletionTimestamp.slice(10, 12) + ":" + UnloadCompletionTimestamp.slice(12, 14);
												return newUpdateTime;
											}
										} else {
											if (UnloadCompletionTimestamp !== null && UnloadCompletionTimestamp !== "0") {
												var newUpdateTime = UnloadCompletionTimestamp.slice(4, 6) + "/" + UnloadCompletionTimestamp.slice(6, 8) + "/" +
													UnloadCompletionTimestamp.slice(0, 4) + " " +
													UnloadCompletionTimestamp.slice(8, 10) + ":" +
													UnloadCompletionTimestamp.slice(10, 12) + ":" + UnloadCompletionTimestamp.slice(12, 14);
												return newUpdateTime;
											}
										}
									}
								}
							}
						}, {

							name: this.getOwnerComponent().getModel("i18n").getProperty("LoadStartTimestamp"),
							template: {
								// content: "{LoadStartTimestamp}"
								content: {
									parts: ["LoadStartTimestamp", "Region"],
									formatter: function(LoadStartTimestamp, Region) {
										if (Region === "EU" || Region === "LATAM" || Region === "ZA") {
											if (LoadStartTimestamp !== null && LoadStartTimestamp !== "0") {
												var newUpdateTime = LoadStartTimestamp.slice(6, 8) + "/" + LoadStartTimestamp.slice(4, 6) + "/" + LoadStartTimestamp.slice(
														0, 4) + " " +
													LoadStartTimestamp.slice(8, 10) + ":" +
													LoadStartTimestamp.slice(10, 12) + ":" + LoadStartTimestamp.slice(12, 14);
												return newUpdateTime;
											}
										} else {
											if (LoadStartTimestamp !== null && LoadStartTimestamp !== "0") {
												var newUpdateTime = LoadStartTimestamp.slice(4, 6) + "/" + LoadStartTimestamp.slice(6, 8) + "/" + LoadStartTimestamp.slice(
														0, 4) + " " +
													LoadStartTimestamp.slice(8, 10) + ":" +
													LoadStartTimestamp.slice(10, 12) + ":" + LoadStartTimestamp.slice(12, 14);
												return newUpdateTime;
											}
										}
									}
								}
							}
						}, {

							name: this.getOwnerComponent().getModel("i18n").getProperty("LoadCompletionTimestamp"),
							template: {
								// content: "{LoadCompletionTimestamp}"
								content: {
									parts: ["LoadCompletionTimestamp", "Region"],
									formatter: function(LoadCompletionTimestamp, Region) {
										if (Region === "EU" || Region === "LATAM" || Region === "ZA") {
											if (LoadCompletionTimestamp !== null && LoadCompletionTimestamp !== "0") {
												var newUpdateTime = LoadCompletionTimestamp.slice(6, 8) + "/" + LoadCompletionTimestamp.slice(4, 6) + "/" +
													LoadCompletionTimestamp.slice(0, 4) + " " +
													LoadCompletionTimestamp.slice(8, 10) + ":" +
													LoadCompletionTimestamp.slice(10, 12) + ":" + LoadCompletionTimestamp.slice(12, 14);
												return newUpdateTime;
											}
										} else {
											if (LoadCompletionTimestamp !== null && LoadCompletionTimestamp !== "0") {
												var newUpdLoadCompletionTimestampateTime = LoadCompletionTimestamp.slice(4, 6) + "/" + LoadCompletionTimestamp.slice(6, 8) +
													"/" + LoadCompletionTimestamp.slice(0, 4) + " " +
													LoadCompletionTimestamp.slice(8, 10) + ":" +
													LoadCompletionTimestamp.slice(10, 12) + ":" + LoadCompletionTimestamp.slice(12, 14);
												return newUpdateTime;
											}
										}
									}
								}
							}
						}, {

							name: this.getOwnerComponent().getModel("i18n").getProperty("CheckOut"),
							template: {
								// content: "{CheckOutTimestamp}"
								content: {
									parts: ["CheckOutTimestamp", "Region"],
									formatter: function(CheckOutTimestamp, Region) {
										if (Region === "EU" || Region === "LATAM" || Region === "ZA") {
											if (CheckOutTimestamp !== null && CheckOutTimestamp !== "0") {
												var newUpdateTime = CheckOutTimestamp.slice(6, 8) + "/" + CheckOutTimestamp.slice(4, 6) + "/" + CheckOutTimestamp.slice(0,
														4) + " " +
													CheckOutTimestamp.slice(8, 10) + ":" +
													CheckOutTimestamp.slice(10, 12) + ":" + CheckOutTimestamp.slice(12, 14);
												return newUpdateTime;
											}
										} else {
											if (CheckOutTimestamp !== null && CheckOutTimestamp !== "0") {
												var newUpdateTime = CheckOutTimestamp.slice(4, 6) + "/" + CheckOutTimestamp.slice(6, 8) + "/" + CheckOutTimestamp.slice(0,
														4) + " " +
													CheckOutTimestamp.slice(8, 10) + ":" +
													CheckOutTimestamp.slice(10, 12) + ":" + CheckOutTimestamp.slice(12, 14);
												return newUpdateTime;
											}
										}
									}
								}
							}
						}, {

							name: this.getOwnerComponent().getModel("i18n").getProperty("UADwellTime"),
							template: {
								content: "{UaDwellTime}"
							}
						}, {

							name: this.getOwnerComponent().getModel("i18n").getProperty("LoadedDwellTime"),
							template: {
								content: "{LoadedDwellTime}"
							}
						}, {

							name: this.getOwnerComponent().getModel("i18n").getProperty("UnloadingDwellTime"),
							template: {
								content: "{UnloadingDwellTime}"
							}
						}, {

							name: this.getOwnerComponent().getModel("i18n").getProperty("EmptyDwellTime"),
							template: {
								content: "{EmptyDwellTime}"
							}
						}, {

							name: this.getOwnerComponent().getModel("i18n").getProperty("LoadingDwellTime"),
							template: {
								content: "{LoadingDwellTime}"
							}
						}, {

							name: this.getOwnerComponent().getModel("i18n").getProperty("PreloadDwellTime"),
							template: {
								content: "{PreloadDwellTime}"
							}
						}, {

							name: this.getOwnerComponent().getModel("i18n").getProperty("TotalDwellTime"),
							template: {
								content: "{TotalDwellTime}"
							}
						}, {

							name: this.getOwnerComponent().getModel("i18n").getProperty("ibDelv"),
							template: {
								content: "{InboundDelivery}"
							}
						},

						{

							name: this.getOwnerComponent().getModel("i18n").getProperty("obDelv"),
							template: {
								content: "{OutboundDelivery}"
							}
						},

						{

							name: this.getOwnerComponent().getModel("i18n").getProperty("InboundDriverName"),
							template: {
								content: "{InboundDriverName}"
							}
						}, {

							name: this.getOwnerComponent().getModel("i18n").getProperty("OutboundDriverName"),
							template: {
								content: "{OutboundDriverName}"
							}
						}, {

							name: this.getOwnerComponent().getModel("i18n").getProperty("appTime"),
							template: {
								// content: "{AppointmentTime}"
								content: {
									parts: ["AppointmentTime", "Region"],
									formatter: function(AppointmentTime, region) {
										if (AppointmentTime !== null) {
											AppointmentTime = AppointmentTime.trim();
											if (region === "EU" || region === "LATAM" || region === "ZA") {
												if ((AppointmentTime === "0") || (AppointmentTime === 0)) {
													return 0;
												} else if (AppointmentTime !== null && AppointmentTime !== "0" && AppointmentTime !== undefined) {
													var newAppointmentTime = AppointmentTime.slice(6, 8) + "/" + AppointmentTime.slice(4, 6) + "/" + AppointmentTime.slice(0,
															4) + " " +
														AppointmentTime.slice(
															8, 10) + ":" + AppointmentTime.slice(10, 12) + ":" + AppointmentTime.slice(12, 14);
													return newAppointmentTime;
												}
											} else {
												if ((AppointmentTime === "0") || (AppointmentTime === 0)) {
													return 0;
												} else if (AppointmentTime !== null && AppointmentTime !== "0" && AppointmentTime !== undefined) {
													var newAppointmentTime = AppointmentTime.slice(4, 6) + "/" + AppointmentTime.slice(6, 8) + "/" + AppointmentTime.slice(0,
															4) + " " +
														AppointmentTime.slice(
															8, 10) + ":" + AppointmentTime.slice(10, 12) + ":" + AppointmentTime.slice(12, 14);
													return newAppointmentTime;
												}
											}
										}
									}
								}
							}
						},

						{

							name: this.getOwnerComponent().getModel("i18n").getProperty("planGIdate"),
							template: {
								// content: "{PlannedGiDate}"
								content: {
									parts: ["PlannedGiDate", "Region"],
									formatter: function(PlannedGiDate, Region) {
										if (Region === "EU" || Region === "LATAM" || Region === "ZA") {
											if (PlannedGiDate !== null && PlannedGiDate !== "0" && PlannedGiDate !== "" && PlannedGiDate !== undefined) {
												var newPlannedGIDate = PlannedGiDate.slice(6, 8) + "/" + PlannedGiDate.slice(4, 6) + "/" + PlannedGiDate.slice(0, 4);
												return newPlannedGIDate;
											}
										} else {
											if (PlannedGiDate !== null && PlannedGiDate !== "0" && PlannedGiDate !== "" && PlannedGiDate !== undefined) {
												var newPlannedGIDate = PlannedGiDate.slice(4, 6) + "/" + PlannedGiDate.slice(6, 8) + "/" + PlannedGiDate.slice(0, 4);
												return newPlannedGIDate;
											}
										}
									}
								}
							}
						}, {

							name: this.getOwnerComponent().getModel("i18n").getProperty("doorArrivTime"),
							template: {
								// content: "{DoorArrivalTime}"
								content: {
									parts: ["DoorArrivalTime", "Region"],
									formatter: function(DoorArrivalTime, Region) {
										if (Region === "EU" || Region === "LATAM" || Region === "ZA") {
											if (DoorArrivalTime === "0") {
												return 0;
											} else if (DoorArrivalTime !== null && DoorArrivalTime !== "0" && DoorArrivalTime !== undefined) {
												var DoorArrivalTime = DoorArrivalTime.slice(6, 8) + "/" + DoorArrivalTime.slice(4, 6) + "/" + DoorArrivalTime.slice(0, 4) +
													" " + DoorArrivalTime.slice(
														8, 10) + ":" + DoorArrivalTime.slice(10, 12) + ":" + DoorArrivalTime.slice(12, 14);
												return DoorArrivalTime;
											}
										} else {

											if (DoorArrivalTime === "0") {
												return 0;
											} else if (DoorArrivalTime !== null && DoorArrivalTime !== "0" && DoorArrivalTime !== undefined) {
												var DoorArrivalTime = DoorArrivalTime.slice(4, 6) + "/" + DoorArrivalTime.slice(6, 8) + "/" + DoorArrivalTime.slice(0, 4) +
													" " + DoorArrivalTime.slice(
														8, 10) + ":" + DoorArrivalTime.slice(10, 12) + ":" + DoorArrivalTime.slice(12, 14);
												return DoorArrivalTime;
											}
										}
									}
								}
							}
						}, {

							name: this.getOwnerComponent().getModel("i18n").getProperty("parkTime"),
							template: {
								// content: "{ParkTime}"
								content: {
									parts: ["ParkTime", "Region"],
									formatter: function(ParkTime, Region) {
										if (Region === "EU" || Region === "LATAM" || Region === "ZA") {
											if (ParkTime === "0") {
												return 0;
											} else if (ParkTime !== null && ParkTime !== "0" && ParkTime !== undefined) {
												var newParkTime = ParkTime.slice(6, 8) + "/" + ParkTime.slice(4, 6) + "/" + ParkTime.slice(0, 4) + " " + ParkTime.slice(
													8, 10) + ":" + ParkTime.slice(10, 12) + ":" + ParkTime.slice(12, 14);
												return newParkTime;
											}
										} else {

											if (ParkTime === "0") {
												return 0;
											} else if (ParkTime !== null && ParkTime !== "0" && ParkTime !== undefined) {
												var newParkTime = ParkTime.slice(4, 6) + "/" + ParkTime.slice(6, 8) + "/" + ParkTime.slice(0, 4) + " " + ParkTime.slice(
													8, 10) + ":" + ParkTime.slice(10, 12) + ":" + ParkTime.slice(12, 14);
												return newParkTime;
											}
										}
									}
								}
							}
						},
						{

							name: this.getOwnerComponent().getModel("i18n").getProperty("trailtype"),
							template: {
								content: "{TrailerType}"
							}
						}, {

							name: this.getOwnerComponent().getModel("i18n").getProperty("checkInSys"),
							template: {
								content: "{CheckInSystem}"
							}
						}, {

							name: this.getOwnerComponent().getModel("i18n").getProperty("checkOutType"),
							template: {
								content: "{CheckInType}"
							}
						}, {

							name: this.getOwnerComponent().getModel("i18n").getProperty("checkOutSys"),
							template: {
								content: "{CheckOutSystem}"
							}
						},

						{

							name: this.getOwnerComponent().getModel("i18n").getProperty("TrailerSeal"),
							template: {
								content: "{TrailerSeal}"
							}
						}

					]
				});

				/*** add this column only when parentplant is active ***/
				var parentplant = this.getView().getModel("ViewModel").getProperty("/ParentPlant");
				if (parentplant !== "") {
					oExport.insertColumn(new sap.ui.core.util.ExportColumn({
						name: this.getOwnerComponent().getModel("i18n").getProperty("Plant"),
						template: {
							content: "{Plant}"
						}
					}), 0);
				}

				var srejectDetails = this.getOwnerComponent().getModel("i18n").getProperty("DHDwellTymReport");
				oExport.saveFile(srejectDetails).catch(function(oError) {
					// MessageBox.error("Error when downloading data. Browser might not be supported!\n\n" + oError);
				}).then(function() {
					oExport.destroy();
				});
			},

			onNavButtonPress: function() {
				sap.ui.getCore().byId("DHReportTab").destroyItems();
				var oRouter = sap.ui.core.UIComponent.getRouterFor(this);
				oRouter.navTo("ReportInter");
			},

			onDHPersoButtonPressed: function(oEvent) {
				this._oTPC.openDialog();
			},

			onTablePersoRefresh: function() {
				DHPersoService.resetPersData();
				this._oTPC.refresh();
			},

			onDHTableGrouping: function(oEvent) {
				// alert("msg")
				// this._oTPC.setHasGrouping(oEvent.getSource().getSelected());
				this._oTPC.setHasGrouping(sap.ui.getCore().byId("DHgroupCheck").getSelected());

			}

		});
	});