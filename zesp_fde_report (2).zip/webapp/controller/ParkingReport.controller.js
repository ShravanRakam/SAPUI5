var vRegion;
var vPlant;
sap.ui.define([
		"sap/ui/core/mvc/Controller",
		"sap/ui/layout/form/GridLayout",
		"sap/m/Panel",
		"sap/ui/model/json/JSONModel",
		"com/report/model/RejectionPersoService",
		"sap/m/TablePersoController",
		"sap/ui/core/util/Export",
		"sap/ui/core/util/ExportTypeCSV",
		"sap/ui/model/Filter",
		"sap/ui/model/Sorter",
		"com/report/model/formatter",
		"sap/m/MessageBox"
	],
	function(Controller, GridLayout, Panel, JSONModel, RejectionPersoService, TablePersoController, Export, ExportTypeCSV, Filter, Sorter,
		formatter, MessageBox) {
		"use strict";
		return Controller.extend("com.report.controller.ParkingReport", {
			formatter: formatter,
			onInit: function() {
				jQuery.sap.require("jquery.sap.storage");
				var that = this;

				var oRouter = sap.ui.core.UIComponent.getRouterFor(this);
				oRouter.getRoute("ParkingReport").attachMatched(this._onRouteMatched, this);

				var oViewObj = {
					ParentPlant: jQuery.sap.storage(jQuery.sap.storage.Type.local).get("ParentPlant")
				};
				var oViewModel = new JSONModel(oViewObj);
				that.getView().setModel(oViewModel, "ViewModel");

				var oDesktopDevice = sap.ui.Device.system.desktop;
				if (oDesktopDevice === true) {
					var oTitleBar = sap.ui.xmlfragment(this.createId("Plant_Detail_Bar_ID"), "com.report.fragments.PlantDetails", this);
					this.getView().addDependent(oTitleBar);
					this.getView().byId("ParkingReport").addContent(oTitleBar);

				} else {
					var oTitleBarMobile = sap.ui.xmlfragment(this.createId("Header_PlantDetail_Mobile_Bar_ID"),
						"com.report.fragments.MobileHeaderPlantDetails", this);
					this.getView().addDependent(oTitleBarMobile);
					this.getView().byId("ParkingReport").addContent(oTitleBarMobile);
				}

				var oGridLayout = new sap.ui.layout.Grid({
					defaultSpan: "L12 M12 S12",
					content: [
						new sap.m.Panel("RejectTablepanel", {
							expandable: true,
							expanded: true,
							// headerText: "Table Data",
							headerToolbar: new sap.m.Toolbar({
								content: [
									new sap.m.Title({
										text: "{i18n>yardStopReport}"
									}).addStyleClass("pHeaderText"),
									new sap.m.ToolbarSpacer({}),
									new sap.m.Button({
										icon: "sap-icon://filter",
										press: function() {
											that.onFilterPressed();
										}
									}).addStyleClass("headerButton"),
									new sap.m.Button({
										icon: "sap-icon://sort",
										press: function() {
											that.onSorterPressed();
										}
									}).addStyleClass("headerButton"),
									// new sap.m.Button({
									// 	icon: "sap-icon://expand-group",
									// 	press: function(oEvent) {
									// 		that.onPressExp(oEvent);
									// 	}
									// }).addStyleClass("headerButton"),
									new sap.m.Button({
										icon: "sap-icon://refresh",
										press: function() {
											that.onTableRefresh();
										}
									}).addStyleClass("headerButton")
								]
							}),
							content: [
								new sap.m.Toolbar({
									content: [
										new sap.m.Label("parkheaderData", {
											text: "",
											design: "Bold"
										}),
												new sap.m.ToolbarSpacer({}),
												new sap.m.CheckBox("rejectgroupCheck", {
													text: "{i18n>enablePerso}",
													select: function() {
														that.onTableGrouping();
													}
												}),
												new sap.m.Button({
													icon: "sap-icon://action-settings",
													press: function() {
														that.onPersoButtonPressed();
													}
												})
									]
								}),
								new sap.m.ScrollContainer("rejectscroll", {
									// focusable: true,
									horizontal: true,
									vertical: true,
									height: '25rem',
									content: [
										new sap.m.Table("ParkingReportTab", {
											width: "auto",
											mode: "SingleSelectMaster",
											updateFinished: function(eve) {
												that.onRejectionTableUpdateFinished(eve);
											},
											selectionChange: function(oEvent) {
												// that.onSelectionChange(oEvent);
											},
											columns: [new sap.m.Column("PlantId", {
													header: new sap.m.Label({
														text: "{i18n>plant}",
														design: "Bold"
													}).addStyleClass("columnLabelStyle"),
													width: "4rem"
												}),
												new sap.m.Column("User", {
													header: new sap.m.Label({
														text: "{i18n>usrName}",
														design: "Bold"
													}).addStyleClass("columnLabelStyle"),
													width: "8rem"
												}),
												new sap.m.Column("yardStopButton", {
													header: new sap.m.Label({
														text: "{i18n>yardStopBtn}",
														design: "Bold"
													}).addStyleClass("columnLabelStyle"),
													width: "7rem"
												}),
												// new sap.m.Column("Application", {
												// 	header: new sap.m.Label({
												// 		// text: "{i18n>trailId}",
												// 		text: "Application",
												// 		design: "Bold"
												// 	}).addStyleClass("columnLabelStyle"),
												// 	width: "10rem"
												// }),
												new sap.m.Column("Date", {
													header: new sap.m.Label({
														text: "{i18n>date}",
														design: "Bold"
													}).addStyleClass("columnLabelStyle"),
													width: "6rem"
												}),
												new sap.m.Column("Time", {
													header: new sap.m.Label({
														text: "{i18n>time}",
														design: "Bold"
													}).addStyleClass("columnLabelStyle"),
													width: "6rem"
												}),

												new sap.m.Column("Comment", {
													header: new sap.m.Label({
														text: "{i18n>comments}",
														design: "Bold"
													}).addStyleClass("columnLabelStyle"),
													width: "20rem"
												})

											]
										}).addStyleClass("tableStyle")
									]
								}).addStyleClass("tableClass")
							]
						}).addStyleClass("pHeading panelBackground")
					]
				}).addStyleClass("sapUiSmallMarginTop");
				that.byId("ParkingReport").addContent(oGridLayout);

				// init and activate controller
				this._oTPC = new TablePersoController({
					table: sap.ui.getCore().byId("ParkingReportTab"),
					//specify the first part of persistence ids e.g. 'demoApp-productsTable-dimensionsCol'
					componentName: "rejectApp",
					persoService: RejectionPersoService
				}).activate();

			},

			_onRouteMatched: function(oEvent) {
				var that = this;
				// that.fnCreateBusyDialog("pallet.svg", "true");
				var oArgs = oEvent.getParameter("arguments");
				vPlant = oArgs.Plants;
				var sDateRange = oArgs.DateRange.split(",");
				var oStartDate = sDateRange[0];
				var newStrDate = oStartDate.replace(/-/g, "");
				var oEndDate = sDateRange[1];
				var newEndDate = oEndDate.replace(/-/g, "");
				oArgs.DateStart = oStartDate;
				oArgs.DateEnd = oEndDate;
				var startTime = oArgs.StartTime;
				var newStrTime = startTime.replace(/:/g, "");
				var endTime = oArgs.EndTime;
				var newEndTime = endTime.replace(/:/g, "");
				var plantModel = new sap.ui.model.json.JSONModel();
				plantModel.setData(oArgs);
				that.getView().setModel(plantModel, "plantDetailModel");
				vRegion = jQuery.sap.storage(jQuery.sap.storage.Type.local).get("region");
				that.fnCreateBusyDialog("pallet.svg", "true");
				var sLanguage = that.getCurrentLanguage();
				var sRejecFilter = [];
				// http://localhost:62816/sap/opu/odata/sap/ZYM_NOTIFICATIONS_SRV/YardStopSet?$filter=Werks eq 'GB03' and STARTDATE eq '20220701' and ENDDATE eq '20220721' and STARTTIME eq '000000'
				sRejecFilter.push(new sap.ui.model.Filter("Werks", sap.ui.model.FilterOperator.EQ, oArgs.Plants));
				sRejecFilter.push(new sap.ui.model.Filter("STARTDATE", sap.ui.model.FilterOperator.EQ, newStrDate));
				sRejecFilter.push(new sap.ui.model.Filter("ENDDATE", sap.ui.model.FilterOperator.EQ, newEndDate));
				sRejecFilter.push(new sap.ui.model.Filter("STARTTIME", sap.ui.model.FilterOperator.EQ, newStrTime));
				sRejecFilter.push(new sap.ui.model.Filter("ENDTIME", sap.ui.model.FilterOperator.EQ, newEndTime));
				// sRejecFilter.push(new sap.ui.model.Filter("Zlangu", sap.ui.model.FilterOperator.EQ, sLanguage));

				that.getOwnerComponent().getModel("parkingSpotRptModel").read("/YardStopSet", {
					filters: sRejecFilter,
					success: function(oData, oResponse) {
						if (oResponse.statusCode === 200 || oResponse.statusCode === "200") {
							var parkingTableModel = new JSONModel();

							for (var k = 0; k < oData.results.length; k++) {
								oData.results[k].Region = vRegion;
							}

							parkingTableModel.setData(oData.results);
							parkingTableModel.setSizeLimit(oData.results.length);
							that.getView().setModel(parkingTableModel, "parkingTableModel");
							that.bindAllPanelsandTables(oData.results);
						}
						that.fnCreateBusyDialog("pallet.svg", "false");
					},
					error: function() {
						MessageBox.show("Error");
						that.fnCreateBusyDialog("pallet.svg", "false");
					}
				});
			},

			bindAllPanelsandTables: function(tableData) {
				var that = this;
				// that.onIssuesReturnsBind(tableData);
				that.tableBinding(tableData);
			},
			getCurrentLanguage: function() {

				var sCurrentLang = sap.ui.getCore().getConfiguration().getLanguage();
				if (sCurrentLang.indexOf("ES") !== -1 || sCurrentLang.indexOf("es") !== -1) {
					sCurrentLang = "S";
				} else if (sCurrentLang.indexOf("EN") !== -1 || sCurrentLang.indexOf("en") !== -1) {
					sCurrentLang = "E";
				} else if (sCurrentLang.indexOf("NL") !== -1 || sCurrentLang.indexOf("nl") !== -1) {
					sCurrentLang = "N";
				} else if (sCurrentLang.indexOf("FR") !== -1 || sCurrentLang.indexOf("fr") !== -1) {
					sCurrentLang = "F";
				} else if (sCurrentLang.indexOf("PT") !== -1 || sCurrentLang.indexOf("pt") !== -1) {
					sCurrentLang = "P";
				} else if (sCurrentLang.indexOf("IT") !== -1 || sCurrentLang.indexOf("it") !== -1) {
					sCurrentLang = "I";
				} else if (sCurrentLang.indexOf("RO") !== -1 || sCurrentLang.indexOf("ro") !== -1) {
					sCurrentLang = "4";
				} else if (sCurrentLang.indexOf("DE") !== -1 || sCurrentLang.indexOf("de") !== -1) {
					sCurrentLang = "D";
				} else if (sCurrentLang.indexOf("PL") !== -1 || sCurrentLang.indexOf("pl") !== -1) {
					sCurrentLang = "L";
				} else if (sCurrentLang.indexOf("ZH") !== -1 || sCurrentLang.indexOf("zh") !== -1) {
					sCurrentLang = "1";
				} else if (sCurrentLang.indexOf("CS") !== -1 || sCurrentLang.indexOf("cs") !== -1) {
					sCurrentLang = "C";
				} else if (sCurrentLang.indexOf("HU") !== -1 || sCurrentLang.indexOf("hu") !== -1) {
					sCurrentLang = "H";
				} else if (sCurrentLang.indexOf("EL") !== -1 || sCurrentLang.indexOf("el") !== -1) {
					sCurrentLang = "G";
				} else if (sCurrentLang.indexOf("LT") !== -1 || sCurrentLang.indexOf("lt") !== -1) {
					sCurrentLang = "X";
				} else if (sCurrentLang.indexOf("SK") !== -1 || sCurrentLang.indexOf("sk") !== -1) {
					sCurrentLang = "Q";
				} else if (sCurrentLang.indexOf("TR") !== -1 || sCurrentLang.indexOf("tr") !== -1) {
					sCurrentLang = "T";
				} else if (sCurrentLang.indexOf("BG") !== -1 || sCurrentLang.indexOf("bg") !== -1) {
					sCurrentLang = "W";
				} else if (sCurrentLang.indexOf("DA") !== -1 || sCurrentLang.indexOf("da") !== -1) {
					sCurrentLang = "K";
				} else if (sCurrentLang.indexOf("FI") !== -1 || sCurrentLang.indexOf("fi") !== -1) {
					sCurrentLang = "U";
				} else if (sCurrentLang.indexOf("SV") !== -1 || sCurrentLang.indexOf("sv") !== -1) {
					sCurrentLang = "V";
				} else {
					sCurrentLang = "E";
				}
				return sCurrentLang;
			},

			tableBinding: function(tableData) {
				/*Pass Data to Tables*/
				var that = this;
				var oTemplate = new sap.m.ColumnListItem({
					// type: "Navigation",
					cells: [
						new sap.m.Text({
							text: "{Werks}"
						}),
						// .addStyleClass("bold"),
						new sap.m.Text({
							text: "{User}"
						}),
						new sap.m.Text({
							text: {
								parts: [{
									path: "YardStopbutton"
								}]
								// formatter: function(yardStop) {
								// 	return formatter.yardStop(yardStop);
								// }
							}
						}),
						new sap.m.ObjectStatus({
							text: {
								parts: [{
									path: "Date"
								}],
								formatter: function(rejectdate) {
									return formatter.parkingDate(rejectdate);
								}
							}
						}),
						new sap.m.ObjectStatus({
							text: {
								parts: [{
									path: "Time"
								}],
								formatter: function(rejectdate) {
									return formatter.parkingTime(rejectdate);
								}
							}
						}),
						new sap.m.Text({
							text: "{Comment}"
						})
						// new sap.m.Text({
						// 	text: "{Reason}"
						// }),
						// new sap.m.Text({
						// 	text: "{Comments}"
						// })
					]
				});

				/*Table Binding*/
				var oParkingReportTable = sap.ui.getCore().byId("ParkingReportTab");
				var oModel1 = new sap.ui.model.json.JSONModel();
				oModel1.setSizeLimit(tableData.length);
				for(var k=0; k<tableData.length; k++){
				var comment = tableData[k].Comment;
				if (comment.includes("ON") === "true" || comment.includes("ON") === true) {
						tableData[k].YardStopbutton = "ON";
					} else if (comment.includes("OFF") === "true" || comment.includes("OFF") === true) {
						tableData[k].YardStopbutton = "OFF";
					}
				}
				oModel1.setData(tableData);
				if (oParkingReportTable !== undefined) {
					oParkingReportTable.setModel(oModel1);
					oParkingReportTable.bindAggregation("items", {
						path: "/",
						template: oTemplate
					});
				}
				/*Table Grouping*/
				var oGroupingModel = new JSONModel({
					hasGrouping: false
				});
				this.getView().setModel(oGroupingModel, 'Grouping');

			},
			onRejectionTableUpdateFinished: function(oEvent) {
				// var oData = sap.ui.getCore().byId("ParkingReportTab").getModel().getData();
				var aItems = sap.ui.getCore().byId("ParkingReportTab").getItems();
				// var data =oData.results;
				/*	for (var i = 0; i < oData.length; i++) {
					if (oData[i].Zymstatus === "DELE") {
						aItems[i].addStyleClass("redBack");
					}
				}*/
				// for (var i = 0; i < aItems.length; i++) {
				// 	var sObj = aItems[i].getBindingContext().getObject();
				// 	var comment = sObj.Comment;
				// 	if (comment.includes("on") === "true" || comment.includes("on") === true) {
				// 		aItems[i].addStyleClass("redBack");
				// 	} else if (comment.includes("Off") === "true" || comment.includes("Off") === true) {
				// 		aItems[i].removeStyleClass("redBack");
				// 	}
				// }
			},

			//----------------------------------------------------------------------------------
			//Function to create Busy Dialog
			//----------------------------------------------------------------------------------
			fnCreateBusyDialog: function(sImage, sBusy) {
				var that = this;
				//	that.oInsCreateDailog;
				if (sBusy === "true") {
					that.oInsCreateDailog = new sap.m.Dialog({
						showHeader: false
					}).addStyleClass("busyDialog sapUiTinyMargin");
					var sComponentName = that.getOwnerComponent().getMetadata().getComponentName();
					var imgUrl = $.sap.getModulePath(sComponentName, "/images/");
					var oImage = new sap.m.Image().addStyleClass("sapUiMediumMargin");
					oImage.setSrc(imgUrl + sImage);
					that.oInsCreateDailog.addContent(oImage);
					that.oInsCreateDailog.open();
				} else {
					that.oInsCreateDailog.close();
				}
			},

			loadFiltersData: function() {
				var filterResults = sap.ui.getCore().byId("ParkingReportTab").getModel().getData();

				//----Binded unique data of Location to filter fragment----//
				var Locationarray = [];
				for (var i = 0; i < filterResults.length; i++) {
					if (Locationarray.indexOf(filterResults[i].YardStopbutton) === -1) {
						Locationarray.push(filterResults[i].YardStopbutton);
					}
				}
				if (sap.ui.getCore().byId("ParkYardFilter") !== undefined) {
					sap.ui.getCore().byId("ParkYardFilter").setModel(new JSONModel(Locationarray), "sLocation");
				}

				//----Binded unique data of Users to filter fragment----//
				var Userarray = [];
				for (var i = 0; i < filterResults.length; i++) {
					if (Userarray.indexOf(filterResults[i].User) === -1) {
						Userarray.push(filterResults[i].User);
					}
				}
				if (sap.ui.getCore().byId("UserParkingFilter") !== undefined) {
					sap.ui.getCore().byId("UserParkingFilter").setModel(new JSONModel(Userarray), "sUser");
				}
				//----Binded unique data of parentplants to filter fragment----//
				var parentplant = [];
				for (var i = 0; i < filterResults.length; i++) {
					if (parentplant.indexOf(filterResults[i].Plant) === -1) {
						parentplant.push(filterResults[i].Plant);
					}
				}
				if (sap.ui.getCore().byId("RejPlantFilter") !== undefined) {
					sap.ui.getCore().byId("RejPlantFilter").setModel(new JSONModel(parentplant), "sParentPlant");
				}
			},

			onFilterPressed: function() {
				var that = this;
				that.oInsCreateDailog.open();

				if (!this._filterDialog) {
					this._filterDialog = sap.ui.xmlfragment("com.report.fragments.ParkingFilter", this);
					this.getView().addDependent(this._filterDialog);
				}
				/*** adding filter items for the multiplant/ parentplant scenario ***/
				var parentplant = this.getView().getModel("ViewModel").getProperty("/ParentPlant");
				if (parentplant !== "") {
					if (sap.ui.getCore().byId("RejPlantFilter") === undefined) {
						var ParentPlantFilter = new sap.m.ViewSettingsFilterItem("RejPlantFilter", {
							multiSelect: true,
							text: "{i18n>Plant}"

						});
						var Template = new sap.m.ViewSettingsItem({
							key: "Plant",
							text: "{sParentPlant>}"
						});
						ParentPlantFilter.bindAggregation("items", "sParentPlant>/", Template);
						this._filterDialog.addFilterItem(ParentPlantFilter);
					}
				}
				this.loadFiltersData();
				// toggle compact style
				jQuery.sap.syncStyleClass("sapUiSizeCompact", this.getView(), this._filterDialog);
				this._filterDialog.open();

				that.oInsCreateDailog.close();
			},

			//---------------------Code for filtering----------------------//

			onFilterConfirm: function(oEvent) {
				var that = this;
				that.oInsCreateDailog.open();
				var oView = sap.ui.getCore();
				if (oView.byId("ParkingReportTab") !== undefined) {
					var rejTableFilter = oView.byId("ParkingReportTab");
					var mParams = oEvent.getParameters();
					var oBinding = rejTableFilter.getBinding("items");
					var aFilters = [];
					for (var i = 0, l = mParams.filterItems.length; i < l; i++) {
						var oItem = mParams.filterItems[i];
						if (oItem.getKey() === "Location") {
							var oFilter1 = new sap.ui.model.Filter("YardStopbutton", "EQ", oItem.getText());
							aFilters.push(oFilter1);
						} else if (oItem.getKey() === "User") {
							var oFilter2 = new sap.ui.model.Filter("User", "EQ", oItem.getText());
							aFilters.push(oFilter2);
						}
						// else if (oItem.getKey() === "Plant") {
						// 	var oFilter3 = new sap.ui.model.Filter("Plant", "EQ", oItem.getText());
						// 	aFilters.push(oFilter3);
						// }
					}
					oBinding.filter(aFilters);
				}

				that.oInsCreateDailog.close();

				if (oEvent.getParameters().filterString) {
					var filteredData = oEvent.getParameters().filterString;
				}
				sap.ui.getCore().byId("parkheaderData").setText(filteredData);
			},

			onTableRefresh: function() {
				//Remove Filters
				if (sap.ui.getCore().byId("ParkingReportTab") !== undefined) {
					var oTable = sap.ui.getCore().byId("ParkingReportTab");
					var oModel = oTable.getModel();
					var oTableBinding = oTable.getBinding("items");
					oTableBinding.aSorters = null;
					oTableBinding.aFilters = null;
					oModel.refresh(true);
				}
				if (sap.ui.getCore().byId("parkheaderData") !== undefined) {
					sap.ui.getCore().byId("parkheaderData").setText("");
				}
				this.resetFilterItems();
			},

			resetFilterItems: function() {
				var that = this;
				that.oInsCreateDailog.open();
				if (this._filterDialog !== undefined) {
					var aFilterItems = this._filterDialog.getFilterItems();

					aFilterItems.forEach(function(item) {
						var aItems = item.getItems();
						aItems.forEach(function(item) {
							item.setSelected(false);
						});
					});
				}
				that.oInsCreateDailog.close();
			},

			//----------------Code for opening Sorter Dailog when sorter icon pressed---------------------//

			onSorterPressed: function() {
				var that = this;
				that.oInsCreateDailog.open();
				if (!this._sorterDialog) {
					this._sorterDialog = sap.ui.xmlfragment("com.report.fragments.ParkingSorter", this);
					this.getView().addDependent(this._sorterDialog);
				}
				/*** adding sort items for the multiplant scenario ***/
				var parentplant = this.getView().getModel("ViewModel").getProperty("/ParentPlant");
				if (parentplant !== "") {
					if (sap.ui.getCore().byId("RejPlantSorter") === undefined) {
						var ParentPlantSort = new sap.m.ViewSettingsItem("RejPlantSorter", {
							text: "{i18n>Plant}",
							key: "Plant"

						});
						this._sorterDialog.addSortItem(ParentPlantSort);
					}
				}
				// toggle compact style
				jQuery.sap.syncStyleClass("sapUiSizeCompact", this.getView(), this._sorterDialog);
				this._sorterDialog.open();
				that.oInsCreateDailog.close();
			},

			//-----------------------Code for Sorting---------------------------//

			onSortConfirm: function(oEvent) {

				var that = this;
				that.oInsCreateDailog.open();
				var oView = sap.ui.getCore();
				if (oView.byId("ParkingReportTab") !== undefined) {
					var rejecRepTable = oView.byId("ParkingReportTab");
					var mParams = oEvent.getParameters();
					var oBinding = rejecRepTable.getBinding("items");
					var aSorters = [];
					if (mParams.sortItem !== undefined) {
						var sPath = mParams.sortItem.getKey();
						var bDescending = mParams.sortDescending;
						aSorters.push(new sap.ui.model.Sorter(sPath, bDescending));
						oBinding.sort(aSorters);
					}
				}

				that.oInsCreateDailog.close();
			},

			//-----------------------------------------------------------------------------------------
			// Function for expanding the pnales inside the plant panels
			//-----------------------------------------------------------------------------------------
			onPressExp: function(oEvent) {
				var oPanelId = oEvent.getSource().getParent().getParent().getId();
				var oButtonId = oEvent.getSource().getId();
				if (sap.ui.getCore().byId(oPanelId).getExpanded()) {
					sap.ui.getCore().byId(oPanelId).setExpanded(false);
					sap.ui.getCore().byId(oButtonId).setIcon("sap-icon://expand-group");
				} else {
					sap.ui.getCore().byId(oPanelId).setExpanded(true);
					sap.ui.getCore().byId(oButtonId).setIcon("sap-icon://collapse-group");
				}
			},

			//-----------------------------------------------------------------------------------------
			// Function for table export
			//-----------------------------------------------------------------------------------------

			onPressExport: sap.m.Table.prototype.exportData || function(oEvent) {
				var oExport = new Export({
					exportType: new ExportTypeCSV({
						separatorChar: ",",
						fileExtension: "csv"
					}),
					models: sap.ui.getCore().byId("ParkingReportTab").getModel(),
					rows: {
						path: "/"
					},

					columns: [{
							name: this.getOwnerComponent().getModel("i18n").getProperty("plant"),
							template: {
								content: "{Werks}"
							}
						}, {
							name: this.getOwnerComponent().getModel("i18n").getProperty("usrName"),
							template: {
								content: "{User}"
							}
						}, {
							name: this.getOwnerComponent().getModel("i18n").getProperty("yardStopBtn"),
							template: {
								content: {
									parts: ["YardStopbutton"],
									formatter: function(sStatus) {
										if (sStatus === true || sStatus === "true") {
											return "ON";
										} else if (sStatus === false || sStatus === "false") {
											return "OFF";
										}
									}
								}
							}
						}, 
						// {
						// 	name: "Application",
						// 	// name: this.getOwnerComponent().getModel("i18n").getProperty("Action"),
						// 	template: {
						// 		content: "{Application}"
						// 	}
						// }, 
						{
							name: this.getOwnerComponent().getModel("i18n").getProperty("date"),
							template: {
								
								content: {
								path: 'Date',
								type: 'sap.ui.model.type.DateTime',
								formatOptions: {
									source: {
										pattern: 'yyyyMMdd'
									},
									pattern: 'dd/MM/yyyy'
								}
							}

							}
						}, {
							name: this.getOwnerComponent().getModel("i18n").getProperty("time"),
							template: {
								content: {
								path: 'Time',
								type: 'sap.ui.model.type.DateTime',
								formatOptions: {
									source: {
										pattern: 'hhmmss'
									},
									pattern: 'hh:mm:ss'
								}
							}
							}
						}, {
							name: this.getOwnerComponent().getModel("i18n").getProperty("comments"),
							template: {
								content: "{Comment}"
							}
						}

					]
				});

				// var srejectDetails = this.getOwnerComponent().getModel("i18n").getProperty("rejectDetails");
				var srejectDetails = "Parking Spots";
				oExport.saveFile(srejectDetails).catch(function(oError) {
					// MessageBox.error("Error when downloading data. Browser might not be supported!\n\n" + oError);
				}).then(function() {
					oExport.destroy();
				});
			},

			onPressExportXLS: sap.m.Table.prototype.exportData || function(oEvent) {
				var oExport = new Export({
					exportType: new ExportTypeCSV({
						separatorChar: "\t",
						fileExtension: "xls"
					}),
					models: sap.ui.getCore().byId("ParkingReportTab").getModel(),
					rows: {
						path: "/"
					},

					columns: [{
							name: this.getOwnerComponent().getModel("i18n").getProperty("plant"),
							template: {
								content: "{Werks}"
							}
						}, {
							name: this.getOwnerComponent().getModel("i18n").getProperty("usrName"),
							template: {
								content: "{User}"
							}
						}, {
							name: this.getOwnerComponent().getModel("i18n").getProperty("yardStopBtn"),
							template: {
								content: {
									parts: ["YardStopbutton"],
									formatter: function(sStatus) {
										if (sStatus === true || sStatus === "true") {
											return "ON";
										} else if (sStatus === false || sStatus === "false") {
											return "OFF";
										}
									}
								}
							}
						},
						// {
						// 	name: "Application",
						// 	// name: this.getOwnerComponent().getModel("i18n").getProperty("Action"),
						// 	template: {
						// 		content: "{Application}"
						// 	}
						// }, 
						{
							name: this.getOwnerComponent().getModel("i18n").getProperty("date"),
							template: {
								
								content: {
								path: 'Date',
								type: 'sap.ui.model.type.DateTime',
								formatOptions: {
									source: {
										pattern: 'yyyyMMdd'
									},
									pattern: 'dd/MM/yyyy'
								}
							}
								
								
							}
						}, {
							name: this.getOwnerComponent().getModel("i18n").getProperty("time"),
							template: {
								
								content: {
								path: 'Time',
								type: 'sap.ui.model.type.DateTime',
								formatOptions: {
									source: {
										pattern: 'hhmmss'
									},
									pattern: 'hh:mm:ss'
								}
							}
							}
						}, {
							name: this.getOwnerComponent().getModel("i18n").getProperty("comments"),
							template: {
								content: "{Comment}"
							}
						}

					]
				});

				// var srejectDetails = this.getOwnerComponent().getModel("i18n").getProperty("rejectDetails");
				var srejectDetails = "Parking Spots";
				oExport.saveFile(srejectDetails).catch(function(oError) {
					// MessageBox.error("Error when downloading data. Browser might not be supported!\n\n" + oError);
				}).then(function() {
					oExport.destroy();
				});
			},

			onNavButtonPress: function() {
				sap.ui.getCore().byId("ParkingReportTab").destroyItems();
				var oRouter = sap.ui.core.UIComponent.getRouterFor(this);
				oRouter.navTo("ReportInter");
			},

			onPersoButtonPressed: function(oEvent) {
				this._oTPC.openDialog();
			},

			onTablePersoRefresh: function() {
				RejectionPersoService.resetPersData();
				this._oTPC.refresh();
			},

			onTableGrouping: function(oEvent) {
				// alert("msg")
				// this._oTPC.setHasGrouping(oEvent.getSource().getSelected());
				this._oTPC.setHasGrouping(sap.ui.getCore().byId("rejectgroupCheck").getSelected());

			}

		});
	});