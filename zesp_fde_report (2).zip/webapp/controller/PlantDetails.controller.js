var sPlantReport;
var sPanelContent;
var plantids;
var tabPlantids = [];
var sInsLoggedUser;
var sInsPlantId;
var sInsUrl;
var sInsUserId;
var sInsHeadPlantId;
var sToolBarIds = [];
var sInsCdateId;
var sInsResult;
var oInsCreateDailog;
var sPlantNames;
var sDateRange = [];
var aplantReport;
var sSourcePanelIds = [];
var sExpandIds = [];
var sButtonIds = [];
var sPlantReportId;
var oMainData;
var oPlantSelected;

sap.ui.define([
		"sap/ui/core/mvc/Controller"
	],
	function(Controller) {
		"use strict";
		return Controller.extend("com.report.controller.PlantDetails", {
			onInit: function() {
				
				jQuery.sap.require("jquery.sap.storage");
				var oRouter = sap.ui.core.UIComponent.getRouterFor(this);
				oRouter.getRoute("PlantDetails").attachMatched(this._onRouteMatched, this);
				var that = this;
				var sStartup = "/sap/bc/ui2/start_up";
				var xmlHttp = null;
				xmlHttp = new XMLHttpRequest();
				xmlHttp.onreadystatechange = function() {
					if (xmlHttp.readyState === 4 && xmlHttp.status === 200) {
						var oUserData = JSON.parse(xmlHttp.responseText);
						sInsLoggedUser = oUserData.id;
						that.fnGetHeaderDetails(sInsLoggedUser);
					}
				};
				xmlHttp.open("GET", sStartup, false);
				xmlHttp.send(null);

				var oDesktopDevice = sap.ui.Device.system.desktop;
				if (oDesktopDevice === true) {
					//Desktop Title Bar
					var oTitleBar = sap.ui.xmlfragment(this.createId("Header_Desktop_Bar_ID"), "com.report.fragments.DesktopHeader", this);
					this.getView().addDependent(oTitleBar);
					this.getView().byId("PlantPage").addContent(oTitleBar);
					sInsUserId = "Header_Desktop_Bar_ID--userName";
					sInsHeadPlantId = "Header_Desktop_Bar_ID--plantName";
					sInsCdateId = "Header_Desktop_Bar_ID--cDate";
				} else {
					//Mobile Title Bar
					var oTitleMobBar = sap.ui.xmlfragment(this.createId("Header_Mobile_Bar_ID"), "com.report.fragments.MobileHeader", this);
					this.getView().addDependent(oTitleMobBar);
					this.getView().byId("PlantPage").addContent(oTitleMobBar);
					sInsUserId = "Header_Mobile_Bar_ID--userName1";
					sInsHeadPlantId = "Header_Mobile_Bar_ID--plantName1";
					sInsCdateId = "Header_Mobile_Bar_ID--cDate1";
				}
				// ----------------------------------------------------------------------------------
				// 	To get the clock
				// 	----------------------------------------------------------------------------------
				/*setInterval(function() {
					// sInsResult = sap.ui.controller("com.report.controller.ReportInter").fnGetClock();
					var realClock = that.realDateTimeClock();
					if (that.byId(sInsCdateId) !== undefined) {
						that.byId(sInsCdateId).setText(realClock);
					}
				}, 1000);*/
				
					setInterval(function() {
										var oTimeZone = jQuery.sap.storage(jQuery.sap.storage.Type.local).get("sTimeZone");
										var oDayLightSaving = jQuery.sap.storage(jQuery.sap.storage.Type.local).get("sDayLightSaving");
										var oFlag = jQuery.sap.storage(jQuery.sap.storage.Type.local).get("sFlag");
										// var oFlag = true;

										if (oFlag === false || oFlag === "false" || oFlag === null || oFlag === undefined ) {
											var resultBrowser = that.realDateTimeClockBrowser();

											if (that.byId(sInsCdateId) !== undefined) {
												that.byId(sInsCdateId).setText(resultBrowser);
											}

										} else if (oFlag === true || oFlag === "true") {

											var realClock = that.realDateTimeClock(oTimeZone, oDayLightSaving);
											if (that.byId(sInsCdateId) !== undefined) {
												that.byId(sInsCdateId).setText(realClock);
											}
										}

									}, 1000);
				
			},
			
		realDateTimeClockBrowser: function() {
			var dateObject = new Date();
			var dateFormat = sap.ui.core.format.DateFormat.getDateInstance({
				style: 'full',
				pattern: "EEEE, MMMM dd, YYYY hh:mm:ss a"
			});
			// Format the date
			var dateFormatted = dateFormat.format(dateObject);
			return dateFormatted;
		},

		realDateTimeClock: function(TimeZone, DayLightSaving) {
			var that = this;

			/*	var sData = that.getView().getModel("HeaderDetailsPlant").getData();
			var TimeZone = sData.UTC_DIFF;
			var DayLightSaving = sData.DST_DIFF;*/

			var timeZoneOutput = [TimeZone.slice(0, 3), ":", TimeZone.slice(3, 5)].join('');

			if (DayLightSaving === "") {
				DayLightSaving = "0";
			}

			// var DayLightSavingOutput = [DayLightSaving.slice(0, 2), ":", DayLightSaving.slice(2, 4)].join('');

			if (timeZoneOutput.startsWith("-")) {
				var concatTimeZoneDayLight = parseInt(TimeZone.slice(1, 3)) - parseInt(DayLightSaving.slice(0, 2));
			} else if (timeZoneOutput.startsWith("+")) {
				var concatTimeZoneDayLight = parseInt(TimeZone.slice(1, 3)) + parseInt(DayLightSaving.slice(0, 2));
			}

			var finalOffset = [TimeZone.slice(0, 1), concatTimeZoneDayLight, ":", TimeZone.slice(3, 5)].join('');

			var _now = new Date();

			//var timeZoneOutput = "+11:00";
			var date = that.timezoneShifter(_now, finalOffset);

			var resultDate = that.formatTimeClock(date);
			return resultDate;
		},

		timezoneShifter: function(date, timezone) {

			var isBehindGTM = false;
			if (timezone.startsWith("-")) {
				timezone = timezone.substr(1);
				isBehindGTM = true;
			}

			var hDiff = timezone.split(":").map(myFunction);

			function myFunction(t) {
				return parseInt(t);
			}

			var value = isBehindGTM ? 1 : -1;
			var diff = (hDiff[0] * 60 + hDiff[1]) * value;
			var currentDiff = new Date().getTimezoneOffset();

			return new Date(date.valueOf() + (currentDiff - diff) * 60 * 1000);
		},

		formatTimeClock: function(_now) {
			var dateObject = _now;
			var dateFormat = sap.ui.core.format.DateFormat.getDateInstance({
				style: 'full',
				pattern: "EEEE, MMMM dd, YYYY hh:mm:ss a"
			});
			// Format the date
			var dateFormatted = dateFormat.format(dateObject);
			return dateFormatted;
		},


			_onRouteMatched: function(oEvent) {
				var that = this;
				SVGElement.prototype.getTransformToElement = SVGElement.prototype.getTransformToElement || function(elem) {
					return elem.getScreenCTM().inverse().multiply(this.getScreenCTM());
				};

				var oArgs = oEvent.getParameter("arguments");
				sPlantNames = oArgs.Plants.split(",");
				sDateRange = oArgs.DateRange.split(",");

				//Setting the selected report as page title 
				// this.byId("PlantPage").setTitle(oArgs.reportname);

				var oPlantsVBox = that.byId("plantsVBox");
				if (oPlantsVBox !== undefined) {
					oPlantsVBox.destroy();
				}

				// var dDateForm = sDateRange[0].slice(6, 10) + sDateRange[0].slice(0, 2) + sDateRange[0].slice(3, 5);
				// var dDateTo = sDateRange[1].slice(6, 10) + sDateRange[1].slice(0, 2) + sDateRange[1].slice(3, 5);
				var dDateForm = sDateRange[0].slice(0, 4) + sDateRange[0].slice(5, 7) + sDateRange[0].slice(8, 10);
				var dDateTo = sDateRange[1].slice(0, 4) + sDateRange[1].slice(5, 7) + sDateRange[1].slice(8, 10);
				var sInpDates = dDateForm + "," + dDateTo;

				sInsPlantId = oArgs.Plants;
				var sService = "/sap/opu/odata/sap/ZGW_REPORTS_SRV/";
				var oModel = new sap.ui.model.odata.ODataModel(sService);
				oModel.read("/UsageReportSet?$filter=Plants eq '" + sInsPlantId + "' and Dates eq '" + sInpDates + "'", null, null, false,
					function(oData) {
						oMainData = oData.results;
					});

				var oVBox = new sap.m.VBox(this.createId("plantsVBox"), {
					items: [
						new sap.m.Bar(this.createId("DateRange"), {
							contentLeft: [
								new sap.m.Button(this.createId("expAllId"), {
									icon: "sap-icon://expand-group",
									text: "{i18n>expandAll}",
									press: function() {
										that.onExpandAll();
									}
								}).addStyleClass("hideButtom"),
								new sap.m.Button(this.createId("collAllId"), {
									icon: "sap-icon://collapse-group",
									text: "{i18n>collapseAll}",
									press: function() {
										that.onCollapseAll();
									}
								}).addStyleClass("hideButtom")
							],
							contentMiddle: [
								new sap.m.Label(this.createId("onFrom"), {
									text: "{i18n>dateRange}",
									design: "Bold"
								}).addStyleClass("from"),
								new sap.m.Label(this.createId("onDateFrom"), {

								}).addStyleClass("fromData"),
								new sap.m.Label(this.createId("onTo"), {
									design: "Bold",
									text: "{i18n>to}"
								}).addStyleClass("to"),
								new sap.m.Label(this.createId("onDateTo"), {}).addStyleClass("toValue")
							]
						}),
						new sap.m.Label(this.createId("onPlants"), {
							design: "Bold",
							text: "{i18n>LabelPlants}" //"Plants:"
						}).addStyleClass("sapUiTinyMarginTop sapUiSmallMargin"),
						new sap.ui.view({
							viewName: "com.report.view.printTab",
							type: sap.ui.core.mvc.ViewType.HTML
						}).addStyleClass("hideHTMLView")
					]
				}).addStyleClass("sapUiSizeCompact printClass");

				//Adding the panels for the page
				var oBox = this.byId("PlantPage");
				oBox.addContent(oVBox);

				this.byId("onDateFrom").setText(sDateRange[0]);
				this.byId("onDateTo").setText(sDateRange[1]);
				if (sDateRange[1] === "") {
					this.byId("onTo").setVisible(false);
				} else {
					this.byId("onTo").setVisible(true);
				}
				that.onTabsPress();
			},

			destroyPanels: function(plantids) {
				var that = this;
				for (var l = 0; l < plantids.length; l++) {
					var PanelID = sap.ui.getCore().byId(plantids[l]);
					if (PanelID !== undefined) {
						PanelID.destroy();
					}
				}
				plantids = [];
				var oPlantsVBox = that.byId("plantsVBox");
				if (oPlantsVBox !== undefined) {
					oPlantsVBox.destroy();
				}
			},

			//------------------------------------------------------
			// Function for Expanding All Plants                    
			//--------------------------------------------------------------
			onExpandAll: function() {
				for (var l = 0; l < plantids.length; l++) {
					sap.ui.getCore().byId(plantids[l]).setExpanded(true);
					var oButtonIcon = sap.ui.getCore().byId(sExpandIds[l]).getIcon();
					if (oButtonIcon === "sap-icon://expand-group") {
						sap.ui.getCore().byId(sExpandIds[l]).setIcon("sap-icon://collapse-group");
					}
					for (var m = 0; m < sSourcePanelIds.length; m++) {
						sap.ui.getCore().byId(sSourcePanelIds[m]).setExpanded(true);
						var oSourceButtonIcon = sap.ui.getCore().byId(sButtonIds[m]).getIcon();
						if (oSourceButtonIcon === "sap-icon://expand-group") {
							sap.ui.getCore().byId(sButtonIds[m]).setIcon("sap-icon://collapse-group");
						}
					}
				}
			},

			//--------------------------------------------------------------
			// Function for Collapsing All Plants                    
			//--------------------------------------------------------------
			onCollapseAll: function() {
				for (var l = 0; l < plantids.length; l++) {
					sap.ui.getCore().byId(plantids[l]).setExpanded(false);
					var oButtonIcon = sap.ui.getCore().byId(sExpandIds[l]).getIcon();
					if (oButtonIcon === "sap-icon://collapse-group") {
						sap.ui.getCore().byId(sExpandIds[l]).setIcon("sap-icon://expand-group");
					}
					for (var m = 0; m < sSourcePanelIds.length; m++) {
						sap.ui.getCore().byId(sSourcePanelIds[m]).setExpanded(false);
						var oSourceButtonIcon = sap.ui.getCore().byId(sButtonIds[m]).getIcon();
						if (oSourceButtonIcon === "sap-icon://collapse-group") {
							sap.ui.getCore().byId(sButtonIds[m]).setIcon("sap-icon://expand-group");
						}
					}
				}
			},

			onSourceContent: function(oTemporaryjson, aplantReport) {
				var that = this;
				var systemChartData = [];
				for (var j = 0; j < oTemporaryjson.length; j++) {
					var oTempArray = [];
					var tempJson1 = {};
					tempJson1.DelType = "Issues";
					tempJson1.ShipCondt = "Z1";
					if (oTemporaryjson[j].IssueZ1 === "") {
						tempJson1.Qty = 0;
					} else {
						tempJson1.Qty = parseInt(oTemporaryjson[j].IssueZ1);
					}
					oTempArray.push(tempJson1);

					tempJson1 = {};
					tempJson1.DelType = "Returns";
					tempJson1.ShipCondt = "Z1";
					if (oTemporaryjson[j].ReturnZ1 === "") {
						tempJson1.Qty = 0;
					} else {
						tempJson1.Qty = parseInt(oTemporaryjson[j].ReturnZ1);
					}
					oTempArray.push(tempJson1);

					tempJson1 = {};
					tempJson1.DelType = "Issues";
					tempJson1.ShipCondt = "Z2";
					if (oTemporaryjson[j].IssueZ2 === "") {
						tempJson1.Qty = 0;
					} else {
						tempJson1.Qty = parseInt(oTemporaryjson[j].IssueZ2);
					}
					oTempArray.push(tempJson1);

					tempJson1 = {};
					tempJson1.DelType = "Returns";
					tempJson1.ShipCondt = "Z2";
					if (oTemporaryjson[j].ReturnZ2 === "") {
						tempJson1.Qty = 0;
					} else {
						tempJson1.Qty = parseInt(oTemporaryjson[j].ReturnZ2);
					}
					oTempArray.push(tempJson1);

					var iZ1, rZ1, iZ2, rZ2;

					if (oTemporaryjson[j].IssueZ1 === "") {
						iZ1 = 0;
					} else {
						iZ1 = parseInt(oTemporaryjson[j].IssueZ1);
					}

					if (oTemporaryjson[j].ReturnZ1 === "") {
						rZ1 = 0;
					} else {
						rZ1 = parseInt(oTemporaryjson[j].ReturnZ1);
					}

					if (oTemporaryjson[j].IssueZ2 === "") {
						iZ2 = 0;
					} else {
						iZ2 = parseInt(oTemporaryjson[j].IssueZ2);
					}

					if (oTemporaryjson[j].ReturnZ2 === "") {
						rZ2 = 0;
					} else {
						rZ2 = parseInt(oTemporaryjson[j].ReturnZ2);
					}

					var z1per = 0;
					if (((iZ1 + rZ1) !== 0) && (parseInt(oTemporaryjson[j].SourceCount) !== 0)) {
						z1per = ((iZ1 + rZ1) / parseInt(oTemporaryjson[j].SourceCount)) * 100;
						z1per = parseFloat(Math.round(z1per * 100) / 100).toFixed(2);
					} else {
						z1per = 0;
					}
					var z2per = 0;
					if (((iZ2 + rZ2) !== 0) && (parseInt(oTemporaryjson[j].SourceCount) !== 0)) {
						z2per = ((iZ2 + rZ2) / parseInt(oTemporaryjson[j].SourceCount)) * 100;
						z2per = parseFloat(Math.round(z2per * 100) / 100).toFixed(2);
					} else {
						z2per = 0;
					}

					var pieChartData = [];
					var pieJson = {};
					pieJson.ShipCond = "Z1" + "-" + z1per + "%";
					pieJson.Quantity = iZ1 + rZ1;
					pieChartData.push(pieJson);
					pieJson = {};
					pieJson.ShipCond = "Z2" + "-" + z2per + "%";
					pieJson.Quantity = iZ2 + rZ2;
					pieChartData.push(pieJson);

					//if Z1 and Z2 both are Zero count
					/*	if((iZ1 + rZ1) === 0 && (iZ2 + rZ2)=== 0){
					pieJson = {};
					pieJson.ShipCond = "None" + "-" + "100%";
					pieJson.Quantity = 2;
					pieChartData.push(pieJson);
					}*/

					switch (oTemporaryjson[j].Source) {
						case "SAP":
							var sysJson = {};
							sysJson.Source = "SAP";
							if (oTemporaryjson[j].SourceCount === "") {
								sysJson.SourceCount = 0;
							} else {
								sysJson.SourceCount = oTemporaryjson[j].SourceCount;
							}
							systemChartData.push(sysJson);

							var oTable1 = sap.ui.getCore().byId(aplantReport + "--" + "Table1Tab");
							var panelTotal1 = sap.ui.getCore().byId(aplantReport + "--" + "input1Tab");
							if (oTemporaryjson[j].SourceCount === "") {
								panelTotal1.setValue("        0");
							} else {
								panelTotal1.setValue(oTemporaryjson[j].SourceCount);
							}
							var sapTable = new sap.ui.model.json.JSONModel(oTempArray);
							oTable1.setModel(sapTable, "FDE");

							var oVizFrame0 = sap.ui.getCore().byId(aplantReport + "--" + "Chart1Tab");
							/*	oVizFrame0.setUiConfig({
							"applicationSet": "fiori"
						});*/
							var sapChart = new sap.ui.model.json.JSONModel({
								"SAP": pieChartData
							});
							oVizFrame0.setModel(sapChart);
							oVizFrame0.setVizProperties({
								title: {
									text: oTemporaryjson[j].Source //+ " Chart"
								},
								plotArea: {
									colorPalette: d3.scale.category20().range(),
									drawingEffect: "glossy",
									type: "percentage"
								},
								dataLabel: {
									visible: false,
									type: "percentage"
								},
								legendGroup: {
									layout: {
										//	width: "4px",
										position: "bottom"
									}
								}
							});
							break;
						case "SARAH":
							var sysJson = {};
							sysJson.Source = "SARAH";
							if (oTemporaryjson[j].SourceCount === "") {
								sysJson.SourceCount = 0;
							} else {
								sysJson.SourceCount = oTemporaryjson[j].SourceCount;
							}
							systemChartData.push(sysJson);
							var oTable2 = sap.ui.getCore().byId(aplantReport + "--" + "Table2Tab");
							var panelTotal2 = sap.ui.getCore().byId(aplantReport + "--" + "input2Tab");
							if (oTemporaryjson[j].SourceCount === "") {
								panelTotal2.setValue("        0");
							} else {
								panelTotal2.setValue(oTemporaryjson[j].SourceCount);
							}
							var sarahTable = new sap.ui.model.json.JSONModel(oTempArray);
							oTable2.setModel(sarahTable, "FDE");

							var oVizFrame1 = sap.ui.getCore().byId(aplantReport + "--" + "Chart2Tab");
							var sarahChart = new sap.ui.model.json.JSONModel({
								"SARAH": pieChartData
							});
							/*	oVizFrame1.setUiConfig({
							"applicationSet": "fiori"
						});*/
							oVizFrame1.setModel(sarahChart);
							oVizFrame1.setVizProperties({
								title: {
									text: oTemporaryjson[j].Source //+ " Chart"
								},
								plotArea: {
									colorPalette: d3.scale.category20().range(),
									drawingEffect: "glossy",
									type: "percentage"
								},
								dataLabel: {
									visible: false,
									type: "percentage"
								},
								legendGroup: {
									layout: {
										//	width: "4px",
										position: "bottom"
									}
								}
							});
							break;
						case "ESP":
							var sysJson = {};
							sysJson.Source = "ESP";
							if (oTemporaryjson[j].SourceCount === "") {
								sysJson.SourceCount = 0;
							} else {
								sysJson.SourceCount = oTemporaryjson[j].SourceCount;
							}
							systemChartData.push(sysJson);
							var oTable3 = sap.ui.getCore().byId(aplantReport + "--" + "Table3Tab");
							var panelTotal3 = sap.ui.getCore().byId(aplantReport + "--" + "input3Tab");
							if (oTemporaryjson[j].SourceCount === "") {
								panelTotal3.setValue("        0");
							} else {
								panelTotal3.setValue(oTemporaryjson[j].SourceCount);
							}
							var espTable = new sap.ui.model.json.JSONModel(oTempArray);
							oTable3.setModel(espTable, "FDE");

							var oVizFrame2 = sap.ui.getCore().byId(aplantReport + "--" + "Chart3Tab");
							var espChart = new sap.ui.model.json.JSONModel({
								"ESP": pieChartData
							});
							/*	oVizFrame2.setUiConfig({
							"applicationSet": "fiori"
						});*/
							oVizFrame2.setModel(espChart);
							oVizFrame2.setVizProperties({
								title: {
									text: oTemporaryjson[j].Source //+ " Chart"
								},
								plotArea: {
									colorPalette: d3.scale.category20().range(),
									drawingEffect: "glossy",
									type: "percentage"
								},
								dataLabel: {
									visible: false,
									type: "percentage"
								},
								legendGroup: {
									layout: {
										//	width: "4px",
										position: "bottom"
									}
								}
							});
							break;
					}
				}
				var oVizFrame = sap.ui.getCore().byId(aplantReport + "--" + "Chart0Tab");
				/*				oVizFrame.setUiConfig({
					"applicationSet": "fiori"
				});*/
				var totalCount = 0;
				var tempVal = 0;
				for (var k = 0; k < systemChartData.length; k++) {
					if (systemChartData[k].SourceCount === "") {
						tempVal = 0;
					} else {
						tempVal = parseInt(systemChartData[k].SourceCount);
					}
					totalCount = totalCount + tempVal;
				}
				var finalChatData = [];
				for (var l = 0; l < systemChartData.length; l++) {
					var sysJson = {};
					if (systemChartData[l].Source === "ESP") {
						if ((parseInt(systemChartData[l].SourceCount) !== 0) && (systemChartData[l].SourceCount !== "") && (totalCount !== 0)) {
							sysJson.SourceCount = parseInt(systemChartData[l].SourceCount);
							var espCount = (parseInt(systemChartData[l].SourceCount) / totalCount) * 100;
							espCount = parseFloat(Math.round(espCount * 100) / 100).toFixed(2);
						} else {
							espCount = 0;
						}
						sysJson.Source = "ESP" + "-" + espCount + "%";
						finalChatData.push(sysJson);
					} else if (systemChartData[l].Source === "SAP") {
						if ((parseInt(systemChartData[l].SourceCount) !== 0) && (systemChartData[l].SourceCount !== "") && (totalCount !== 0)) {
							sysJson.SourceCount = parseInt(systemChartData[l].SourceCount);
							var sapCount = (parseInt(systemChartData[l].SourceCount) / totalCount) * 100;
							sapCount = parseFloat(Math.round(sapCount * 100) / 100).toFixed(2);
						} else {
							sapCount = 0;
						}
						sysJson.Source = "SAP" + "-" + sapCount + "%";
						finalChatData.push(sysJson);
					} else if (systemChartData[l].Source === "SARAH") {
						if ((parseInt(systemChartData[l].SourceCount) !== 0) && (systemChartData[l].SourceCount !== "") && (totalCount !== 0)) {
							sysJson.SourceCount = parseInt(systemChartData[l].SourceCount);
							var sarahCount = (parseInt(systemChartData[l].SourceCount) / totalCount) * 100;
							sarahCount = parseFloat(Math.round(sarahCount * 100) / 100).toFixed(2);
						} else {
							sarahCount = 0;
						}
						sysJson.Source = "SARAH" + "-" + sarahCount + "%";
						finalChatData.push(sysJson);
					}
				}
				var systemChart = new sap.ui.model.json.JSONModel({
					"System": finalChatData
				});
				oVizFrame.setModel(systemChart);
				oVizFrame.setVizProperties({
					title: {
						// text: "System" // + " Chart"
						text: that.getOwnerComponent().getModel("i18n").getProperty('system')
					},
					plotArea: {
						colorPalette: d3.scale.category20().range(),
						drawingEffect: "glossy",
						type: "percentage"
					},
					dataLabel: {
						visible: false,
						type: "percentage"
					},
					legendGroup: {
						layout: {
							//	width: "4px",
							position: "bottom"
						}
					}
				});
			},

			onSourceContentPanels: function(oTemporaryjson, aplantReport) {
				var systemChartData = [];
				for (var j = 0; j < oTemporaryjson.length; j++) {
					var oTempArray = [];

					var tempJson1 = {};
					tempJson1.DelType = "Issues";
					tempJson1.ShipCondt = "Z1";
					if (oTemporaryjson[j].IssueZ1 === "") {
						tempJson1.Qty = 0;
					} else {
						tempJson1.Qty = parseInt(oTemporaryjson[j].IssueZ1);
					}
					oTempArray.push(tempJson1);

					tempJson1 = {};
					tempJson1.DelType = "Returns";
					tempJson1.ShipCondt = "Z1";
					if (oTemporaryjson[j].ReturnZ1 === "") {
						tempJson1.Qty = 0;
					} else {
						tempJson1.Qty = parseInt(oTemporaryjson[j].ReturnZ1);
					}
					oTempArray.push(tempJson1);

					tempJson1 = {};
					tempJson1.DelType = "Issues";
					tempJson1.ShipCondt = "Z2";
					if (oTemporaryjson[j].IssueZ2 === "") {
						tempJson1.Qty = 0;
					} else {
						tempJson1.Qty = parseInt(oTemporaryjson[j].IssueZ2);
					}
					oTempArray.push(tempJson1);

					tempJson1 = {};
					tempJson1.DelType = "Returns";
					tempJson1.ShipCondt = "Z2";
					if (oTemporaryjson[j].ReturnZ2 === "") {
						tempJson1.Qty = 0;
					} else {
						tempJson1.Qty = parseInt(oTemporaryjson[j].ReturnZ2);
					}
					oTempArray.push(tempJson1);

					var iZ1, rZ1, iZ2, rZ2;

					if (oTemporaryjson[j].IssueZ1 === "") {
						iZ1 = 0;
					} else {
						iZ1 = parseInt(oTemporaryjson[j].IssueZ1);
					}

					if (oTemporaryjson[j].ReturnZ1 === "") {
						rZ1 = 0;
					} else {
						rZ1 = parseInt(oTemporaryjson[j].ReturnZ1);
					}

					if (oTemporaryjson[j].IssueZ2 === "") {
						iZ2 = 0;
					} else {
						iZ2 = parseInt(oTemporaryjson[j].IssueZ2);
					}

					if (oTemporaryjson[j].ReturnZ2 === "") {
						rZ2 = 0;
					} else {
						rZ2 = parseInt(oTemporaryjson[j].ReturnZ2);
					}
					var z1per = 0;
					if (((iZ1 + rZ1) !== 0) && (parseInt(oTemporaryjson[j].SourceCount) !== 0)) {
						z1per = ((iZ1 + rZ1) / parseInt(oTemporaryjson[j].SourceCount)) * 100;
						z1per = parseFloat(Math.round(z1per * 100) / 100).toFixed(2);
					} else {
						z1per = 0;
					}
					var z2per = 0;
					if (((iZ2 + rZ2) !== 0) && (parseInt(oTemporaryjson[j].SourceCount) !== 0)) {
						z2per = ((iZ2 + rZ2) / parseInt(oTemporaryjson[j].SourceCount)) * 100;
						z2per = parseFloat(Math.round(z2per * 100) / 100).toFixed(2);
					} else {
						z2per = 0;
					}

					var pieChartData = [];
					var pieJson = {};
					pieJson.ShipCond = "Z1" + "-" + z1per + "%";
					pieJson.Quantity = iZ1 + rZ1;
					pieChartData.push(pieJson);
					pieJson = {};
					pieJson.ShipCond = "Z2" + "-" + z2per + "%";
					pieJson.Quantity = iZ2 + rZ2;
					pieChartData.push(pieJson);
					//if Z1 and Z2 both are Zero count
					/*	if((iZ1 + rZ1) === 0 && (iZ2 + rZ2)=== 0){
					pieJson = {};
					pieJson.ShipCond = "None" + "-" + "100%";
					pieJson.Quantity = 2;
					pieChartData.push(pieJson);
					}*/

					switch (oTemporaryjson[j].Source) {
						case "SAP":
							var sysJson = {};
							sysJson.Source = "SAP";
							if (oTemporaryjson[j].SourceCount === "") {
								sysJson.SourceCount = 0;
							} else {
								sysJson.SourceCount = oTemporaryjson[j].SourceCount;
							}
							systemChartData.push(sysJson);

							var oTable1 = sap.ui.getCore().byId(aplantReport + "--" + "Table1");
							var panelTotal1 = sap.ui.getCore().byId(aplantReport + "--" + "input1");
							if (oTemporaryjson[j].SourceCount === "") {
								panelTotal1.setValue("        0");
							} else {
								panelTotal1.setValue(oTemporaryjson[j].SourceCount);
							}
							var sapTable = new sap.ui.model.json.JSONModel(oTempArray);
							oTable1.setModel(sapTable, "FDE");

							var oVizFrame0 = sap.ui.getCore().byId(aplantReport + "--" + "Chart1");
							/*	oVizFrame0.setUiConfig({
							"applicationSet": "fiori"
						});*/
							var sapChart = new sap.ui.model.json.JSONModel({
								"SAP": pieChartData
							});
							oVizFrame0.setModel(sapChart);
							oVizFrame0.setVizProperties({
								title: {
									text: oTemporaryjson[j].Source //+ " Chart"
								},
								plotArea: {
									colorPalette: d3.scale.category20().range(),
									drawingEffect: "glossy",
									type: "percentage"
								},
								dataLabel: {
									visible: false,
									type: "percentage"
								},
								legendGroup: {
									layout: {
										//	width: "4px",
										position: "bottom"
									}
								}
							});
							break;
						case "SARAH":
							var sysJson = {};
							sysJson.Source = "SARAH";
							if (oTemporaryjson[j].SourceCount === "") {
								sysJson.SourceCount = 0;
							} else {
								sysJson.SourceCount = oTemporaryjson[j].SourceCount;
							}
							systemChartData.push(sysJson);

							var oTable2 = sap.ui.getCore().byId(aplantReport + "--" + "Table2");
							var panelTotal2 = sap.ui.getCore().byId(aplantReport + "--" + "input2");
							if (oTemporaryjson[j].SourceCount === "") {
								panelTotal2.setValue("        0");
							} else {
								panelTotal2.setValue(oTemporaryjson[j].SourceCount);
							}
							var sarahTable = new sap.ui.model.json.JSONModel(oTempArray);
							oTable2.setModel(sarahTable, "FDE");

							var oVizFrame1 = sap.ui.getCore().byId(aplantReport + "--" + "Chart2");
							var sarahChart = new sap.ui.model.json.JSONModel({
								"SARAH": pieChartData
							});
							/*	oVizFrame1.setUiConfig({
							"applicationSet": "fiori"
						});*/
							oVizFrame1.setModel(sarahChart);
							oVizFrame1.setVizProperties({
								title: {
									text: oTemporaryjson[j].Source //+ " Chart"
								},
								plotArea: {
									colorPalette: d3.scale.category20().range(),
									drawingEffect: "glossy",
									type: "percentage"
								},
								dataLabel: {
									visible: false,
									type: "percentage"
								},
								legendGroup: {
									layout: {
										//	width: "4px",
										position: "bottom"
									}
								}
							});
							break;
						case "ESP":
							var sysJson = {};
							sysJson.Source = "ESP";
							if (oTemporaryjson[j].SourceCount === "") {
								sysJson.SourceCount = 0;
							} else {
								sysJson.SourceCount = oTemporaryjson[j].SourceCount;
							}
							systemChartData.push(sysJson);
							var oTable3 = sap.ui.getCore().byId(aplantReport + "--" + "Table3");
							var panelTotal3 = sap.ui.getCore().byId(aplantReport + "--" + "input3");
							if (oTemporaryjson[j].SourceCount === "") {
								panelTotal3.setValue("        0");
							} else {
								panelTotal3.setValue(oTemporaryjson[j].SourceCount);
							}
							var espTable = new sap.ui.model.json.JSONModel(oTempArray);
							oTable3.setModel(espTable, "FDE");

							var oVizFrame2 = sap.ui.getCore().byId(aplantReport + "--" + "Chart3");
							var espChart = new sap.ui.model.json.JSONModel({
								"ESP": pieChartData
							});
							/*	oVizFrame2.setUiConfig({
							"applicationSet": "fiori"
						});*/
							oVizFrame2.setModel(espChart);
							oVizFrame2.setVizProperties({
								title: {
									text: oTemporaryjson[j].Source //+ " Chart"
								},
								plotArea: {
									colorPalette: d3.scale.category20().range(),
									drawingEffect: "glossy",
									type: "percentage"
								},
								dataLabel: {
									visible: false,
									type: "percentage"
								},
								legendGroup: {
									layout: {
										//	width: "4px",
										position: "bottom"
									}
								}
							});
							break;
					}
				}

				var oVizFrame = sap.ui.getCore().byId(aplantReport + "--" + "Chart0");
				/*				oVizFrame.setUiConfig({
					"applicationSet": "fiori"
				});*/

				var totalCount = 0;
				var tempVal = 0;
				for (var k = 0; k < systemChartData.length; k++) {
					if (systemChartData[k].SourceCount === "") {
						tempVal = 0;
					} else {
						tempVal = parseInt(systemChartData[k].SourceCount);
					}
					totalCount = totalCount + tempVal;
				}
				var finalChatData = [];
				for (var l = 0; l < systemChartData.length; l++) {
					var sysJson = {};
					if (systemChartData[l].Source === "ESP") {
						if ((parseInt(systemChartData[l].SourceCount) !== 0) && (systemChartData[l].SourceCount !== "") && (totalCount !== 0)) {
							sysJson.SourceCount = parseInt(systemChartData[l].SourceCount);
							var espCount = (parseInt(systemChartData[l].SourceCount) / totalCount) * 100;
							espCount = parseFloat(Math.round(espCount * 100) / 100).toFixed(2);
						} else {
							espCount = 0;
						}
						sysJson.Source = "ESP" + "-" + espCount + "%";
						finalChatData.push(sysJson);
					} else if (systemChartData[l].Source === "SAP") {
						if ((parseInt(systemChartData[l].SourceCount) !== 0) && (systemChartData[l].SourceCount !== "") && (totalCount !== 0)) {
							sysJson.SourceCount = parseInt(systemChartData[l].SourceCount);
							var sapCount = (parseInt(systemChartData[l].SourceCount) / totalCount) * 100;
							sapCount = parseFloat(Math.round(sapCount * 100) / 100).toFixed(2);
						} else {
							sapCount = 0;
						}
						sysJson.Source = "SAP" + "-" + sapCount + "%";
						finalChatData.push(sysJson);
					} else if (systemChartData[l].Source === "SARAH") {
						if ((parseInt(systemChartData[l].SourceCount) !== 0) && (systemChartData[l].SourceCount !== "") && (totalCount !== 0)) {
							sysJson.SourceCount = parseInt(systemChartData[l].SourceCount);
							var sarahCount = (parseInt(systemChartData[l].SourceCount) / totalCount) * 100;
							sarahCount = parseFloat(Math.round(sarahCount * 100) / 100).toFixed(2);
						} else {
							sarahCount = 0;
						}
						sysJson.Source = "SARAH" + "-" + sarahCount + "%";
						finalChatData.push(sysJson);
					}
				}
				var systemChart = new sap.ui.model.json.JSONModel({
					"System": finalChatData
				});
				oVizFrame.setModel(systemChart);
				oVizFrame.setVizProperties({
					title: {
						text: "System" // + " Chart"
					},
					plotArea: {
						colorPalette: d3.scale.category20().range(),
						drawingEffect: "glossy",
						type: "percentage"
					},
					dataLabel: {
						visible: false,
						type: "percentage"
					},
					legendGroup: {
						layout: {
							//	width: "4px",
							position: "bottom"
						}
					}
				});
			},

			//----------------------------------------------------------------------------------
			//Function to get Header details
			//----------------------------------------------------------------------------------
			fnGetHeaderDetails: function(sInsLoggedUser) {
				var that = this;
				that.fnCreateBusyDialog("pallet.svg");
				sInsUrl = "/sap/opu/odata/sap/ZGW_ACTIVITY_SRV";
				var oHeaderModel = new sap.ui.model.odata.ODataModel(sInsUrl);
				oHeaderModel.read("/HeaderDetailsSet('" + sInsLoggedUser + "') ", null, null,
					true, function(oData, oResponse) {
						if (oResponse.statusCode === 200) {
							var oODataJSONModel2 = new sap.ui.model.json.JSONModel();
							oODataJSONModel2.setData(oData);
							if (that.byId(sInsUserId) !== undefined) {
								that.byId(sInsUserId).setText(oData.Firstname + " " + oData.Lastname); // Binding the user name
							}
							if (that.byId(sInsHeadPlantId) !== undefined) {
								that.byId(sInsHeadPlantId).setText(oData.Plant + "-" + oData.Name1); // Binding the plant name
							}
							sInsPlantId = oData.Plant;
						}
						oInsCreateDailog.close();
					},
					function() {
						oInsCreateDailog.close();
					});
			},

			//----------------------------------------------------------------------------------
			// Function for selecting the settings for seeing the view 
			//----------------------------------------------------------------------------------
			onSetting: function(event) {
				var that = this;
				var panels = that.getOwnerComponent().getModel("i18n").getProperty('panels');
				var tabs = that.getOwnerComponent().getModel("i18n").getProperty('tabs');
				var popover = new sap.m.Popover({
					showHeader: false,
					placement: sap.m.PlacementType.Bottom,
					content: [
						new sap.m.Button({
							text: panels,
							type: sap.m.ButtonType.Transparent,
							press: function() {

								sToolBarIds = [];
								sSourcePanelIds = [];
								sExpandIds = [];
								sButtonIds = [];

								//	var barIdDest = that.byId("plantsVBox");
								//	if (barIdDest !== undefined) {
								//		barIdDest.destroy();
								//	}
								var tabsIdDest = that.byId("plantTabs");
								if (tabsIdDest !== undefined) {
									tabsIdDest.destroy();
								}
								for (var i = 0; i < plantids.length; i++) {
									var panelIdDest = sap.ui.getCore().byId(plantids[i]);
									if (panelIdDest !== undefined) {
										panelIdDest.destroy();
									}
								}
								plantids = [];
								that.onPanelsPress();
								popover.close();
							}
						}),
						new sap.m.Button({
							text: tabs,
							type: sap.m.ButtonType.Transparent,
							press: function() {
								//	var barIdDest = that.byId("plantsVBox");
								//	if (barIdDest !== undefined) {
								//		barIdDest.destroy();
								//	}
								for (var i = 0; i < plantids.length; i++) {
									var panelIdDest = sap.ui.getCore().byId(plantids[i]);
									if (panelIdDest !== undefined) {
										panelIdDest.destroy();
									}
								}
								plantids = [];
								that.onTabsPress();
								popover.close();
							}
						})
					]
				}).addStyleClass("sapMOTAPopover sapTntToolHeaderPopover");
				popover.openBy(event.getSource());
			},

			//--------------------------------------------------------------------------
			// Function for Viewing the Plantdetails in Panel View
			//--------------------------------------------------------------------------
			onPanelsPress: function() {
				var that = this;
				that.fnCreateBusyDialog("pallet.svg");
				this.byId("plantFooter").setVisible(true);
				this.byId("expAllId").setVisible(true);
				this.byId("collAllId").setVisible(true);
				// Check whether the device is desktop
				var oDesktopDevice = sap.ui.Device.system.desktop;
				if (oDesktopDevice === true) {
					this.byId("Export").setVisible(true);
				} else {
					this.byId("Export").setVisible(false);
				}
				var oTemporaryjson;
				for (var i = 0; i < sPlantNames.length; i++) {
					oTemporaryjson = $.grep(oMainData, function(n, m) {
						oPlantSelected = n.Werks === sPlantNames[i];
						return oPlantSelected;
					});
					//	if (oPlantSelected) {
					if (oTemporaryjson.length > 0) {
						var aplantReport = "PlantReport" + i;
						sPanelContent = sap.ui.xmlfragment(aplantReport, "com.report.fragments.PlantReport", this);

						var headerPanel = sap.ui.getCore().byId(aplantReport + "--panelParent");
						var plantPanels = aplantReport + "--panelParent";
						plantids.push(plantPanels);

						//	sSourcePanelIds = [];
						var aSourcepanel = "";
						aSourcepanel = aplantReport + "--" + "panel1";
						sSourcePanelIds.push(aSourcepanel);
						aSourcepanel;
						aSourcepanel = aplantReport + "--" + "panel2";
						sSourcePanelIds.push(aSourcepanel);
						aSourcepanel;
						aSourcepanel = aplantReport + "--" + "panel3";
						sSourcePanelIds.push(aSourcepanel);

						//	sButtonIds = [];
						var aButtonIds = "";
						aButtonIds = aplantReport + "--" + "button1";
						sButtonIds.push(aButtonIds);
						aButtonIds;
						aButtonIds = aplantReport + "--" + "button2";
						sButtonIds.push(aButtonIds);
						aButtonIds;
						aButtonIds = aplantReport + "--" + "button3";
						sButtonIds.push(aButtonIds);

						//	sExpandIds = [];
						// Ids for the button to expand
						var aExpand = "Expand" + i;
						sExpandIds.push(aExpand); // TODO: 
						//	sToolBarIds = [];
						//Ids for the Panel toolbar
						var aToolbar = "Toolbar" + i;
						sToolBarIds.push(aToolbar);

						if (headerPanel !== undefined) {
							headerPanel.setHeaderToolbar(
								new sap.m.Toolbar({
									design: sap.m.ToolbarDesign.Transparent,
									content: [
										new sap.m.Label(aToolbar, {
											text: sPlantNames[i]
										}).addStyleClass("plantName"),
										new sap.m.ToolbarSpacer({}),
										new sap.m.Button(aExpand, {
											icon: "sap-icon://expand-group",
											press: function(oEvent) {
												var oPanelId = oEvent.getSource().getParent().getParent().getId();
												var oButtonId = oEvent.getSource().getId();
												that.onPressExpand(oPanelId, oButtonId);
											}
										}).addStyleClass("hideButtom sapUiSizeCompact")
									]
								})
							);
						}
						that.onSourceContentPanels(oTemporaryjson, aplantReport);
						this.getView().byId("PlantPage").addContent(sPanelContent);
					}
				}
				oInsCreateDailog.close();
			},

			//----------------------------------------------------------------------------------------
			// Function for viewing the plant details in Tab View
			//-----------------------------------------------------------------------------------------
			onTabsPress: function() {
				var that = this;
				that.fnCreateBusyDialog("pallet.svg");
				this.byId("plantFooter").setVisible(false);
				this.byId("expAllId").setVisible(false);
				this.byId("collAllId").setVisible(false);
				var aTabId = this.byId("plantTabs");
				if (aTabId !== undefined) {
					aTabId.destroy();
				}
				var aPlantTab = new sap.m.IconTabBar(this.createId("plantTabs"), {
					items: []
				});
				this.getView().byId("PlantPage").addContent(aPlantTab);
				/*if (tabPlantids.length > 0) {
				that.destroyPanels(tabPlantids);
			}*/
				var oTemporaryjson;
				for (var i = 0; i < sPlantNames.length; i++) {
					oTemporaryjson = $.grep(oMainData, function(n, m) {
						oPlantSelected = n.Werks === sPlantNames[i];
						return oPlantSelected;
					});

					//	if (oPlantSelected) {
					if (oTemporaryjson.length > 0) {
						var aplantReport = "PlantReport" + i;
						sPlantReport = sap.ui.xmlfragment(aplantReport, "com.report.fragments.Tabs", this);
						that.onSourceContent(oTemporaryjson, aplantReport);
						//	tabPlantids = [];
						var plantid = "Plant" + i;
						tabPlantids.push(plantid);
						var oTabFilter = "";
						oTabFilter = new sap.m.IconTabFilter(plantid, {
							text: sPlantNames[i],
							content: [sPlantReport]
						});
						var oTabBar = this.byId("plantTabs");
						oTabBar.addItem(oTabFilter);
					}
				}
				oInsCreateDailog.close();
			},
			//-----------------------------------------------------------------------
			// Function to print the data
			//-----------------------------------------------------------------------
			onPressPrint: function() {
				var that = this;
				that.fnCreateBusyDialog("pallet.svg");
				for (var l = 0; l < plantids.length; l++) {
					sap.ui.getCore().byId(plantids[l]).setExpanded(true);
					var oButtonIcon = sap.ui.getCore().byId(sExpandIds[l]).getIcon();
					if (oButtonIcon === "sap-icon://expand-group") {
						sap.ui.getCore().byId(sExpandIds[l]).setIcon("sap-icon://collapse-group");
					}
					for (var m = 0; m < sSourcePanelIds.length; m++) {
						sap.ui.getCore().byId(sSourcePanelIds[m]).setExpanded(true);
						var oSourceButtonIcon = sap.ui.getCore().byId(sButtonIds[m]).getIcon();
						if (oSourceButtonIcon === "sap-icon://expand-group") {
							sap.ui.getCore().byId(sButtonIds[m]).setIcon("sap-icon://collapse-group");
						}
						/*	if ((l + 1) * (m + 1) === plantids.length * sSourcePanelIds.length) {
							setTimeout(function() {
								that.printReport();
							}, 2000);
						}*/
					}
				}
				var last_panel = sSourcePanelIds[sSourcePanelIds.length - 1];
				if (sap.ui.getCore().byId(last_panel).getExpanded() === true) {
					setTimeout(function() {
						that.printReport();
					}, 2000);
				}
				oInsCreateDailog.close();
			},
			//-----------------------------------------------------------------------
			// Function to build the html content to print the data
			//-----------------------------------------------------------------------
			printReport: function() {
				var that = this;
				// Check whether the device is desktop
				var oDesktopDevice = sap.ui.Device.system.desktop;
				if (oDesktopDevice === true) {
					var win = window.open("PrintWindow", "");
					var print_Url = $.sap.getModulePath("com.report", "/css/");
					var printCssUrl = print_Url + "print.css";

					//Read the HTML content Dynamically 
					var hContent = '<html><head><link rel="stylesheet" href=' + printCssUrl +
						' type="text/css" /></head><body class="sapUiSizeCompact displayCSS" >';

					var bodyContent = "";
					bodyContent = $(".printClass").html();

					for (var i = 0; i < plantids.length; i++) {
						bodyContent = bodyContent + $("#" + plantids[i]).html();
					}

					var closeContent = "</body></html>";
					var htmlpage = hContent + bodyContent + closeContent;

					win.document.write(htmlpage);
					var cssLinks = "";
					$.each(document.styleSheets, function(index, oStyleSheet) {
						if (oStyleSheet.href) {
							var link = document.createElement("link");
							link.type = oStyleSheet.type;
							link.rel = "stylesheet";
							link.href = oStyleSheet.href;
							win.document.head.appendChild(link);
						}
					});
					setTimeout(function() {
						win.print();
						win.close();
						//	win.stop();
					}, 2000);
				} else {
					var cssLinks = "";
					$.each(document.styleSheets, function(index, oStyleSheet) {
						if (oStyleSheet.href) {
							var link = document.createElement("link");
							link.type = oStyleSheet.type;
							link.rel = "stylesheet";
							link.href = oStyleSheet.href;
							cssLinks = cssLinks + "<link rel='stylesheet' type='text/css' href=" + oStyleSheet.href + ">";
						}
					});

					var hContent = "<html><head>" + cssLinks + "</head><body class='sapUiSizeCompact'>";
					/*			var bodyContent;
					var bodyContent = $(".printFullContent").html();*/
					var bodyContent = "";
					bodyContent = $(".printClass").html();

					for (var i = 0; i < plantids.length; i++) {
						bodyContent = bodyContent + $("#" + plantids[i]).html();
					}
					var closeContent = "</body></html>";
					var htmlpage = hContent + bodyContent + closeContent;

					cordova.plugins.printer.print(htmlpage, {
						duplex: 'long'
					}, function(res) {
						//	alert(res ? 'Done' : 'Canceled');
					});
				}
			},

			//-----------------------------------------------------------------------
			// Function to build html content to export data to excel
			//-----------------------------------------------------------------------
			onExcelExport: function() {
				//		var print_Url = $.sap.getModulePath("com.report", "/css/");
				//		var printCssUrl = print_Url + "print.css";

				//Read the HTML content Dynamically 
				// var hContent = '<html><head><link rel="stylesheet" href=' + printCssUrl +
				// 	' type="text/css" /></head><body class="sapUiSizeCompact displayCSS" >';

				var dataC = $(".toValue").html();
				if (dataC === undefined || dataC === "undefined" || dataC === "") {
					dataC = "";
				}
				var dataT = $(".to").html();
				if (dataT === undefined || dataT === "undefined" || dataT === "") {
					dataT = "";
				}

				var hContent = '<html><head></head><body class="sapUiSizeCompact" >';
				var bodyContent = "";
				bodyContent = $(".from").html() + $(".fromData").html() + dataT + dataC + "<br>"; //$(".printClass").html();

				for (var i = 0; i < plantids.length; i++) {
					bodyContent = bodyContent + $("#" + plantids[i]).html();
				}

				var closeContent = "</body></html>";
				var htmlpage = hContent + bodyContent + closeContent;

				var htmls = "";
				var uri = 'data:application/vnd.ms-excel;base64,';
				var base64 = function(s) {
					return window.btoa(unescape(encodeURIComponent(s)));
				};

				var format = function(s, c) {
					return s.replace(/{(\w+)}/g, function(m, p) {
						return c[p];
					});
				};

				htmls = "FDE Report";

				var ctx = {
					worksheet: 'FDE_Report',
					table: htmls
				};

				var link = document.createElement("a");
				link.download = "FDE_Report.xls";
				link.href = uri + base64(format(htmlpage, ctx));
				link.click();
			},
			//-----------------------------------------------------------------------
			// Function to export data to excel
			//-----------------------------------------------------------------------
			onPressExport: function() {
				var that = this;
				for (var l = 0; l < plantids.length; l++) {
					sap.ui.getCore().byId(plantids[l]).setExpanded(true);
					var oButtonIcon = sap.ui.getCore().byId(sExpandIds[l]).getIcon();
					if (oButtonIcon === "sap-icon://expand-group") {
						sap.ui.getCore().byId(sExpandIds[l]).setIcon("sap-icon://collapse-group");
					}
					for (var m = 0; m < sSourcePanelIds.length; m++) {
						sap.ui.getCore().byId(sSourcePanelIds[m]).setExpanded(true);
						var oSourceButtonIcon = sap.ui.getCore().byId(sButtonIds[m]).getIcon();
						if (oSourceButtonIcon === "sap-icon://expand-group") {
							sap.ui.getCore().byId(sButtonIds[m]).setIcon("sap-icon://collapse-group");
						}
						if ((l + 1) * (m + 1) === plantids.length * sSourcePanelIds.length) {
							setTimeout(function() {
								that.onExcelExport();
							}, 2000);
						}
					}
				}
			},

			//----------------------------------------------------------------------------------
			//Function to create Busy Dialog
			//----------------------------------------------------------------------------------
			fnCreateBusyDialog: function(sImage) {
				var that = this;
				oInsCreateDailog = new sap.m.Dialog({
					showHeader: false
				}).addStyleClass("busyDialog sapUiTinyMargin");
				var sComponentName = that.getOwnerComponent().getMetadata().getComponentName();
				var imgUrl = $.sap.getModulePath(sComponentName, "/images/");
				var oImage = new sap.m.Image().addStyleClass("sapUiMediumMargin");
				oImage.setSrc(imgUrl + sImage);
				oInsCreateDailog.addContent(oImage);
				oInsCreateDailog.open();
			},

			//--------------------------------------------------------------------------------
			// Function for Expanding the plant panels
			//--------------------------------------------------------------------------------
			onPressExpand: function(panelId, buttonId) {
				if (sap.ui.getCore().byId(panelId).getExpanded()) {
					sap.ui.getCore().byId(panelId).setExpanded(false);
					sap.ui.getCore().byId(buttonId).setIcon("sap-icon://expand-group");
				} else {
					sap.ui.getCore().byId(panelId).setExpanded(true);
					sap.ui.getCore().byId(buttonId).setIcon("sap-icon://collapse-group");
				}
			},

			//-----------------------------------------------------------------------------------------
			// Function for expanding the pnales inside the plant panels
			//-----------------------------------------------------------------------------------------
			onPressExp: function(oEvent) {
				var oPanelId = oEvent.getSource().getParent().getParent().getId();
				var oButtonId = oEvent.getSource().getId();
				if (sap.ui.getCore().byId(oPanelId).getExpanded()) {
					sap.ui.getCore().byId(oPanelId).setExpanded(false);
					sap.ui.getCore().byId(oButtonId).setIcon("sap-icon://expand-group");
				} else {
					sap.ui.getCore().byId(oPanelId).setExpanded(true);
					sap.ui.getCore().byId(oButtonId).setIcon("sap-icon://collapse-group");
				}
			},

			onExit: function() {
				sPlantReport = "";
				sPanelContent = "";
				plantids = [];
				tabPlantids = [];
				sInsLoggedUser = "";
				sInsPlantId = "";
				sInsUrl = "";
				sInsUserId = "";
				sInsHeadPlantId = "";
				sToolBarIds = [];
				sInsCdateId = "";
				sInsResult = "";
				oInsCreateDailog = "";
				sPlantNames = "";
				sDateRange = [];
				aplantReport = "";
				sSourcePanelIds = [];
				sExpandIds = [];
				sButtonIds = [];
				sPlantReportId = "";
				oMainData = "";
				oPlantSelected = "";
			},
			//-----------------------------------------------------------------------
			// Function for going back for the main page
			//-----------------------------------------------------------------------
			onNavButtonPress: function() {
				var that = this;
				var tabsIdDest = that.byId("plantTabs");
				if (tabsIdDest !== undefined) {
					tabsIdDest.destroy();
				}
				var barIdDest = that.byId("plantsVBox");
				if (barIdDest !== undefined) {
					barIdDest.destroy();
				}
				for (var i = 0; i < plantids.length; i++) {
					var panelIdDest = sap.ui.getCore().byId(plantids[i]);
					if (panelIdDest !== undefined) {
						panelIdDest.destroy();
					}
				}
				plantids = [];
				sToolBarIds = [];
				sSourcePanelIds = [];
				sExpandIds = [];
				sButtonIds = [];
				var oRouter = sap.ui.core.UIComponent.getRouterFor(this);
				oRouter.navTo("ReportInter");
			}
		});
	});