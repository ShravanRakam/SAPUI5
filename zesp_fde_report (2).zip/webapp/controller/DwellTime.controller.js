var DnHflag;
var vRegion;
jQuery.sap.require("jquery.sap.storage");

sap.ui.define([
		"sap/ui/core/mvc/Controller",
		"sap/ui/layout/form/GridLayout",
		"sap/m/Panel",
		"sap/ui/model/json/JSONModel",
		"com/report/model/DwellPersoService",
		"sap/m/TablePersoController",
		"sap/ui/core/util/Export",
		"sap/ui/core/util/ExportTypeCSV",
		"sap/ui/model/Filter",
		"sap/ui/model/Sorter",
		"com/report/model/formatter"
	],
	function(Controller, GridLayout, Panel, JSONModel, DwellPersoService, TablePersoController, Export, ExportTypeCSV, Filter, Sorter,
		formatter) {
		"use strict";
		return Controller.extend("com.report.controller.DwellTime", {

			onInit: function() {
				jQuery.sap.require("jquery.sap.storage");
				var that = this;
				var oViewObj = {
					ParentPlant: jQuery.sap.storage(jQuery.sap.storage.Type.local).get("ParentPlant"),
					region: jQuery.sap.storage(jQuery.sap.storage.Type.local).get("region")
				};
				var oViewModel = new JSONModel(oViewObj);
				that.getView().setModel(oViewModel, "ViewModel");
				var oRouter = sap.ui.core.UIComponent.getRouterFor(this);
				oRouter.getRoute("DwellTime").attachMatched(this._onRouteMatched, this);

				var oDesktopDevice = sap.ui.Device.system.desktop;
				if (oDesktopDevice === true) {
					var oTitleBar = sap.ui.xmlfragment(this.createId("Plant_Detail_Bar_ID"), "com.report.fragments.PlantDetails", this);
					this.getView().addDependent(oTitleBar);
					this.getView().byId("DwellPage").addContent(oTitleBar);
				} else {
					var oTitleBarMobile = sap.ui.xmlfragment(this.createId("Header_PlantDetail_Mobile_Bar_ID"),
						"com.report.fragments.MobileHeaderPlantDetails", this);
					this.getView().addDependent(oTitleBarMobile);
					this.getView().byId("DwellPage").addContent(oTitleBarMobile);
				}

				vRegion = jQuery.sap.storage(jQuery.sap.storage.Type.local).get("region");

				var sDwellTimeCol;
				if (vRegion === "ZA") {
					sDwellTimeCol = this.getOwnerComponent().getModel("i18n").getProperty("dwellColForZA");
				} else {
					sDwellTimeCol = this.getOwnerComponent().getModel("i18n").getProperty("dwellTime");
				}

				var oGridLayout = new sap.ui.layout.Grid({
					defaultSpan: "L12 M12 S12",
					content: [

						new sap.m.Panel("DwellSummarypanel", {
							expandable: true,
							expanded: true,
							// visible: false,
							// headerText: "{i18n>summary}",
							headerToolbar: new sap.m.Toolbar({
								content: [
									new sap.m.Title({
										text: "{i18n>summary}"
									}).addStyleClass("pHeaderText"),
									new sap.m.ToolbarSpacer({}),
									new sap.m.Button({
										icon: "sap-icon://expand-group",
										press: function(oEvent) {
											that.onPressExp(oEvent);
										}
									}).addStyleClass("headerButton")
								]
							}),
							content: [
								// new sap.ui.layout.Grid({
								// 	defaultSpan: "L6 M6 S12",
								// 	content: [
								// 		new sap.ui.layout.HorizontalLayout({
								// 			content: [
								// 				new sap.ui.layout.HorizontalLayout({
								// 					content: [
								// 						new sap.ui.layout.VerticalLayout({
								// 							content: [
								// 								new sap.m.Label({
								// 									text: "{i18n>trailerProceed}",
								// 									design: "Bold"
								// 								}),
								// 								new sap.m.Label({
								// 									text: "{i18n>trailerProceed}",
								// 									design: "Bold"
								// 								}),
								// 								new sap.m.Label({
								// 									text: "{i18n>trailerProceed}",
								// 									design: "Bold"
								// 								})
								// 							]
								// 						}),
								// 						new sap.ui.layout.VerticalLayout({
								// 							content: [
								// 								new sap.m.Label({
								// 									text: "GB03",
								// 									design: "Bold"
								// 								}),
								// 								new sap.m.Label({
								// 									text: "{i18n>trailerProceed}",
								// 									design: "Bold"
								// 								}),
								// 								new sap.m.Label({
								// 									text: "{i18n>trailerProceed}",
								// 									design: "Bold"
								// 								})
								// 							]
								// 						})
								// 					]
								// 				})
								// 			]
								// 		}),
								// 		new sap.ui.layout.HorizontalLayout({
								// 			content: [
								// 				new sap.ui.layout.VerticalLayout({
								// 					content: [
								// 						new sap.m.Label({
								// 							text: "{i18n>trailerProceed}",
								// 							design: "Bold"
								// 						}),
								// 						new sap.m.Label({
								// 							text: "{i18n>trailerProceed}",
								// 							design: "Bold"
								// 						}),
								// 						new sap.m.Label({
								// 							text: "{i18n>trailerProceed}",
								// 							design: "Bold"
								// 						})
								// 					]
								// 				}),
								// 				new sap.ui.layout.VerticalLayout({
								// 					content: [
								// 						new sap.m.Label({
								// 							text: "{i18n>trailerProceed}",
								// 							design: "Bold"
								// 						}),
								// 						new sap.m.Label({
								// 							text: "{i18n>trailerProceed}",
								// 							design: "Bold"
								// 						}),
								// 						new sap.m.Label({
								// 							text: "{i18n>trailerProceed}",
								// 							design: "Bold"
								// 						})
								// 					]
								// 				})
								// 			]
								// 		})
								// 	]
								// })

								new sap.ui.layout.Grid({
									defaultSpan: "L6 M6 S12",
									content: [
										new sap.ui.layout.Grid({
											hSpacing: 0,
											vSpacing: 0,
											defaultSpan: "L6 M6 S12",
											content: [

												new sap.m.Label({
													text: "{i18n>trailerProceed}",
													design: "Bold",
													layoutData: new sap.ui.layout.GridData({
														linebreakL: true,
														linebreakM: true,
														linebreakS: true,
														span: "L3 M6 S12"
													})
												}),
												new sap.m.Label({
													text: "{averageModel>/TrailersCount}",
													design: "Bold",
													width: "100%"
												}),
												new sap.m.Label("liveLabel", {
													text: "{i18n>live}",
													// visible: "{visibleModel>/liveLabel}",
													visible: false,
													design: "Bold",
													layoutData: new sap.ui.layout.GridData({
														linebreakL: true,
														linebreakM: true,
														linebreakS: true,
														span: "L3 M6 S12"
													})
												}),
												new sap.m.Label("liveText", {
													text: "{averageModel>/LiveCount}",
													// visible: "{visibleModel>/liveText}",
													visible: false,
													design: "Bold",
													width: "100%"
												}),

												new sap.m.Label("dnhLabel", {
													text: "{i18n>dandh}",
													// visible: "{visibleModel>/dnhLabel}",
													visible: false,
													design: "Bold",
													layoutData: new sap.ui.layout.GridData({
														linebreakL: true,
														linebreakM: true,
														linebreakS: true,
														span: "L3 M6 S12"
													})
												}),
												new sap.m.Label("dnhText", {
													text: "{averageModel>/DhCount}",
													// visible: "{visibleModel>/dnhText}",
													visible: false,
													design: "Bold",
													width: "100%"
												})
											]
										}),

										new sap.ui.layout.Grid({
											hSpacing: 0,
											vSpacing: 0,
											defaultSpan: "L6 M6 S12",
											content: [

												new sap.m.Label({
													text: "{i18n>avgDwellTime}",
													design: "Bold",
													layoutData: new sap.ui.layout.GridData({
														linebreakL: true,
														linebreakM: true,
														linebreakS: true,
														span: "L4 M6 S12"
													})
												}),
												new sap.m.Label({
													text: "{averageModel>/AvgDwellTime}",
													design: "Bold",
													width: "100%"
												}),
												new sap.m.Label("avgLiveTimeLabel", {
													text: "{i18n>liveAvg}",
													// visible: "{visibleModel>/avgLiveTimeLabel}",
													visible: false,
													design: "Bold",
													layoutData: new sap.ui.layout.GridData({
														linebreakL: true,
														linebreakM: true,
														linebreakS: true,
														span: "L4 M6 S12"
													})
												}),
												new sap.m.Label("avgLiveTimeText", {
													text: "{averageModel>/AvgLiveTime}",
													// visible: "{visibleModel>/avgLiveTimeText}",
													visible: false,
													design: "Bold",
													width: "100%"
												}),

												new sap.m.Label("avgDnHTimeLabel", {
													text: "{i18n>dhAvg}",
													// visible: "{visibleModel>/avgDnHTimeLabel}",
													visible: false,
													design: "Bold",
													layoutData: new sap.ui.layout.GridData({
														linebreakL: true,
														linebreakM: true,
														linebreakS: true,
														span: "L4 M6 S12"
													})
												}),
												new sap.m.Label("avgDnHTimeText", {
													text: "{averageModel>/AvgDhTime}",
													// visible: "{visibleModel>/avgDnHTimeText}",
													visible: false,
													design: "Bold",
													width: "100%"
												})
											]
										})

									]
								})

							]
						}).addStyleClass("pHeading panelBackground"),
						new sap.m.Panel("DwellTablepanel", {
							expandable: true,
							expanded: true,
							// headerText: "Table Data",
							headerToolbar: new sap.m.Toolbar({
								content: [
									new sap.m.Title({
										text: "{i18n>dwellDetails}"
									}).addStyleClass("pHeaderText"),
									new sap.m.ToolbarSpacer({}),
									new sap.m.Button({
										icon: "sap-icon://filter",
										press: function() {
											that.onFilterPressed();
										}
									}).addStyleClass("headerButton"),
									new sap.m.Button({
										icon: "sap-icon://sort",
										press: function() {
											that.onSorterPressed();
										}
									}).addStyleClass("headerButton"),
									new sap.m.Button({
										icon: "sap-icon://expand-group",
										press: function(oEvent) {
											that.onPressExp(oEvent);
										}
									}).addStyleClass("headerButton"),
									new sap.m.Button({
										icon: "sap-icon://refresh",
										press: function() {
											that.onTableRefresh();
										}
									}).addStyleClass("headerButton")
								]
							}),
							content: [
								new sap.m.Toolbar({
									content: [
										new sap.m.Label("dwellheaderData", {
											text: "",
											design: "Bold"
										}),
										new sap.m.ToolbarSpacer({}),
										new sap.m.CheckBox("dwellgroupCheck", {
											text: "{i18n>enablePerso}",
											select: function() {
												that.onTableGrouping();
											}
										}),
										new sap.m.Button({
											icon: "sap-icon://action-settings",
											press: function() {
												that.onPersoButtonPressed();
											}
										})
									]
								}),
								new sap.m.ScrollContainer("dwellscroll", {
									// focusable: true,
									horizontal: true,
									vertical: true,
									height: '15rem',
									content: [
										new sap.m.Table("DwellTimeTab", {
											width: "2800px",
											mode: "SingleSelectMaster",
											// select: function(oEvent){
											// 	that.onItemSelected(oEvent);                       
											// },
											// headerText: "Table",
											updateFinished: function() {
												// that.onTableUpdateFinish();
											},
											columns: [new sap.m.Column("contId", {
													header: new sap.m.Label({
														text: "{i18n>containerId}",
														design: "Bold"
													}).addStyleClass("columnLabelStyle"),
													width: "19%"
													// demandPopin: true,
													// minScreenWidth: "Desktop",
													// popinDisplay: "Inline"
												}),
												new sap.m.Column("scacCarrier", {
													header: new sap.m.Label({
														text: "{i18n>carrier}",
														design: "Bold"
													}).addStyleClass("columnLabelStyle"),
													width: "10%"
												}),
												new sap.m.Column("type", {
													header: new sap.m.Label({
														text: "{i18n>type}",
														design: "Bold"
													}).addStyleClass("columnLabelStyle"),
													width: "7%"
												}),
												new sap.m.Column("dwellTime", {
													header: new sap.m.Label({
														text: sDwellTimeCol,
														design: "Bold"
													}).addStyleClass("columnLabelStyle"),
													width: "20%",
													demandPopin: true,
													minScreenWidth: "Desktop",
													popinDisplay: "Inline"
												}),
												new sap.m.Column("checkInStamp", {
													header: new sap.m.Label({
														text: "{i18n>checkInStamp}",
														design: "Bold"
													}).addStyleClass("columnLabelStyle"),
													width: "20%",
													demandPopin: true,
													minScreenWidth: "Desktop",
													popinDisplay: "Inline"
												}),
												new sap.m.Column("checkOutStamp", {
													header: new sap.m.Label({
														text: "{i18n>checkOutStamp}",
														design: "Bold"
													}).addStyleClass("columnLabelStyle"),
													width: "20%",
													demandPopin: true,
													minScreenWidth: "Desktop",
													popinDisplay: "Inline"
												}),
												new sap.m.Column("ibDel", {
													header: new sap.m.Label({
														text: "{i18n>ibDelv}",
														design: "Bold"
													}).addStyleClass("columnLabelStyle"),
													width: "12%"
												}),
												new sap.m.Column("drivName", {
													header: new sap.m.Label({
														text: "{i18n>driverName}",
														design: "Bold"
													}).addStyleClass("columnLabelStyle"),
													width: "16%"
												}),
												new sap.m.Column("obDel", {
													header: new sap.m.Label({
														text: "{i18n>obDelv}",
														design: "Bold"
													}).addStyleClass("columnLabelStyle"),
													width: "12%",
													demandPopin: true,
													minScreenWidth: "Desktop",
													popinDisplay: "Inline"
												}),
												new sap.m.Column("drivNameOb", {
													header: new sap.m.Label({
														text: "{i18n>driverName}",
														design: "Bold"
													}).addStyleClass("columnLabelStyle"),
													width: "15%",
													demandPopin: true,
													minScreenWidth: "Desktop",
													popinDisplay: "Inline"
												}),
												new sap.m.Column("dwellRepPlant", {
													header: new sap.m.Label({
														text: "{i18n>Plant}",
														design: "Bold"
													}).addStyleClass("columnLabelStyle"),
													width: "15%",
													visible: "{= ${ViewModel>/ParentPlant} !==''}",
													demandPopin: true,
													minScreenWidth: "Desktop",
													popinDisplay: "Inline"
												}),
												new sap.m.Column("appTime", {
													header: new sap.m.Label({
														text: "{i18n>appTime}",
														design: "Bold"
													}).addStyleClass("columnLabelStyle"),
													width: "17%"
												}),
												new sap.m.Column("planGIdate", {
													header: new sap.m.Label({
														text: "{i18n>planGIdate}",
														design: "Bold"
													}).addStyleClass("columnLabelStyle"),
													width: "16%",
													demandPopin: true,
													minScreenWidth: "Desktop",
													popinDisplay: "Inline"
												}),
												new sap.m.Column("doorArrivTime", {
													header: new sap.m.Label({
														text: "{i18n>doorArrivTime}",
														design: "Bold"
													}).addStyleClass("columnLabelStyle"),
													width: "17%",
													demandPopin: true,
													minScreenWidth: "Desktop",
													popinDisplay: "Inline"
												}),
												new sap.m.Column("parkTime", {
													header: new sap.m.Label({
														text: "{i18n>parkTime}",
														design: "Bold"
													}).addStyleClass("columnLabelStyle"),
													width: "17%"
												}),
												new sap.m.Column("dwellRegNum", {
													header: new sap.m.Label({
														text: "{i18n>regNum}",
														design: "Bold"
													}).addStyleClass("columnLabelStyle"),
													width: "12%",
													demandPopin: true,
													minScreenWidth: "Desktop",
													popinDisplay: "Inline"
												}),
												new sap.m.Column("trailtype", {
													header: new sap.m.Label({
														text: "{i18n>trailtype}",
														design: "Bold"
													}).addStyleClass("columnLabelStyle"),
													width: "12%",
													demandPopin: true,
													minScreenWidth: "Desktop",
													popinDisplay: "Inline"
												}),
												new sap.m.Column("checkinSysDwell", {
													header: new sap.m.Label({
														text: "{i18n>checkInSys}",
														design: "Bold"
													}).addStyleClass("columnLabelStyle"),
													width: "16%",
													demandPopin: true,
													minScreenWidth: "Desktop",
													popinDisplay: "Inline"
												}),
												new sap.m.Column("checkoutSysDwell", {
													header: new sap.m.Label({
														text: "{i18n>checkOutSys}",
														design: "Bold"
													}).addStyleClass("columnLabelStyle"),
													width: "18%",
													demandPopin: true,
													minScreenWidth: "Desktop",
													popinDisplay: "Inline"
												}),
												new sap.m.Column("checkinTypDwell", {
													header: new sap.m.Label({
														text: "{i18n>checkInTyp}",
														design: "Bold"
													}).addStyleClass("columnLabelStyle"),
													width: "14%",
													visible: "{= ${regionModel>/region} === 'US'? true : false}",
													demandPopin: true,
													minScreenWidth: "Desktop",
													popinDisplay: "Inline"
												})

											]
										}).addStyleClass("tableStyle")
									]
								}).addStyleClass("tableClass")
							]
						}).addStyleClass("pHeading panelBackground")

					]
				}).addStyleClass("sapUiTinyMarginTop");

				that.byId("DwellPage").addContent(oGridLayout);
				
				var sRegionMod = that.getView().getModel("ViewModel").getProperty("/region");

				if (sRegionMod !== "US") {
					sap.ui.getCore().byId("DwellTimeTab").removeColumn("checkinTypDwell");
				}

				// init and activate controller
				this._oTPC = new TablePersoController({
					table: sap.ui.getCore().byId("DwellTimeTab"),
					//specify the first part of persistence ids e.g. 'demoApp-productsTable-dimensionsCol'
					componentName: "dwellApp",
					persoService: DwellPersoService
				}).activate();

			},

			_onRouteMatched: function(oEvent) {
				var that = this;
				that.fnCreateBusyDialog("pallet.svg", "true");
				var oArgs = oEvent.getParameter("arguments");
				var sDateRange = oArgs.DateRange.split(",");
				var oStartDate = sDateRange[0];
				var newStrDate = oStartDate.replace(/-/g, "");
				var oEndDate = sDateRange[1];
				var newEndDate = oEndDate.replace(/-/g, "");
				oArgs.DateStart = oStartDate;
				oArgs.DateEnd = oEndDate;
				var startTime = oArgs.StartTime;
				var newStrTime = startTime.replace(/:/g, "");
				var endTime = oArgs.EndTime;
				var newEndTime = endTime.replace(/:/g, "");
				var plantModel = new sap.ui.model.json.JSONModel();
				plantModel.setData(oArgs);
				that.getView().setModel(plantModel, "plantDetailModel");
				vRegion = jQuery.sap.storage(jQuery.sap.storage.Type.local).get("region");
				var sObj = {
					region: vRegion
				};
				var oViewModel = new JSONModel(sObj);
				that.getView().setModel(oViewModel, "regionModel");

				that.mainTableBinding();

				/*var sDwellFilter = [];
				sDwellFilter.push(new sap.ui.model.Filter("Werks", sap.ui.model.FilterOperator.EQ, oArgs.Plants));
				sDwellFilter.push(new sap.ui.model.Filter("StartDate", sap.ui.model.FilterOperator.EQ, newStrDate));
				sDwellFilter.push(new sap.ui.model.Filter("EndDate", sap.ui.model.FilterOperator.EQ, newEndDate));
				sDwellFilter.push(new sap.ui.model.Filter("StartTime", sap.ui.model.FilterOperator.EQ, newStrTime));
				sDwellFilter.push(new sap.ui.model.Filter("EndTime", sap.ui.model.FilterOperator.EQ, newEndTime));*/

				// that.getOwnerComponent().getModel("fdeRepModel").read("/DWELL_SUMMERYSet(Werks='" + oArgs.Plants + "',StartDate='" + newStrDate +
				// 	"',EndDate='" + newEndDate + "',StartTime='" + newStrTime + "',EndTime='" + newEndTime + "')", {
				// 		/*	parameters: {
				// 			expand: "DwellNavig"
				// 		},*/
				// 		urlParameters: {
				// 			"$expand": "DwellNavig"
				// 		},
				// 		//	filters: sDwellFilter,

				// 		success: function(oData, oResponse) {
				// 			if (oResponse.statusCode === 200 || oResponse.statusCode === "200") {
				// 				var dwellModel = new JSONModel();
				// 				dwellModel.setData(oData.DwellNavig.results);
				// 				dwellModel.setSizeLimit(oData.DwellNavig.results.length);
				// 				that.getView().setModel(dwellModel, "dwelltabModel");
				// 				that.bindAllPanelsandTables(oData.DwellNavig.results);
				// 				that.totalCount();

				// 				var DnHflag = oData.DhFlag;

				// 				var sAvgModel = new JSONModel();
				// 				var objAvg = {};
				// 				objAvg.LiveCount = oData.LiveCount;
				// 				objAvg.DhCount = oData.DhCount;
				// 				objAvg.TrailersCount = oData.TrailersCount;

				// 				objAvg.AvgDwellTime = formatter.calDwellTime(oData.AvgDwellTime);
				// 				objAvg.AvgLiveTime = formatter.calDwellTime(oData.AvgLiveTime);
				// 				objAvg.AvgDhTime = formatter.calDwellTime(oData.AvgDhTime);

				// 				objAvg.DhFlag = oData.DhFlag;

				// 				sAvgModel.setData(objAvg);
				// 				that.getView().setModel(sAvgModel, "averageModel");
				// 				jQuery.sap.storage(jQuery.sap.storage.Type.local).put("dwellTimeAvg", objAvg);
				// 				// jQuery.sap.storage(jQuery.sap.storage.Type.local).put("liveTimeAvg", objAvg.AvgLiveTime);
				// 				// jQuery.sap.storage(jQuery.sap.storage.Type.local).put("dhTimeAvg", objAvg.AvgDhTime);
				// 				// that.getView().setModel(sAvgModel, "onRefreshModel");

				// 				if (DnHflag === 'X') {

				// 					sap.ui.getCore().byId("liveLabel").setVisible(true);
				// 					sap.ui.getCore().byId("liveText").setVisible(true);
				// 					sap.ui.getCore().byId("avgLiveTimeLabel").setVisible(true);
				// 					sap.ui.getCore().byId("avgLiveTimeText").setVisible(true);
				// 					sap.ui.getCore().byId("dnhLabel").setVisible(true);
				// 					sap.ui.getCore().byId("dnhText").setVisible(true);
				// 					sap.ui.getCore().byId("avgDnHTimeLabel").setVisible(true);
				// 					sap.ui.getCore().byId("avgDnHTimeText").setVisible(true);
				// 					// var sObj = {
				// 					// 	"liveLabel": true,
				// 					// 	"liveText": true,
				// 					// 	"avgLiveTimeLabel": true,
				// 					// 	"avgLiveTimeText": true,
				// 					// 	"dnhLabel": true,
				// 					// 	"dnhText": true,
				// 					// 	"avgDnHTimeLabel": true,
				// 					// 	"avgDnHTimeText": true

				// 					// };

				// 					// var sModel = new sap.ui.model.json.JSONModel(sObj);
				// 					// that.getView().setModel(sModel, "visibleModel");

				// 					// sap.ui.getCore().byId("DwellSummarypanel").setVisible(true);
				// 					sap.ui.getCore().byId("dwellscroll").setHeight("15rem");
				// 				} else {
				// 					sap.ui.getCore().byId("liveLabel").setVisible(false);
				// 					sap.ui.getCore().byId("liveText").setVisible(false);
				// 					sap.ui.getCore().byId("avgLiveTimeLabel").setVisible(false);
				// 					sap.ui.getCore().byId("avgLiveTimeText").setVisible(false);
				// 					sap.ui.getCore().byId("dnhLabel").setVisible(false);
				// 					sap.ui.getCore().byId("dnhText").setVisible(false);
				// 					sap.ui.getCore().byId("avgDnHTimeLabel").setVisible(false);
				// 					sap.ui.getCore().byId("avgDnHTimeText").setVisible(false);
				// 					// var sObj = {
				// 					// 	"liveLabel": false,
				// 					// 	"liveText": false,
				// 					// 	"avgLiveTimeLabel": false,
				// 					// 	"avgLiveTimeText": false,
				// 					// 	"dnhLabel": false,
				// 					// 	"dnhText": false,
				// 					// 	"avgDnHTimeLabel": false,
				// 					// 	"avgDnHTimeText": false
				// 					// };

				// 					// var sModel = new sap.ui.model.json.JSONModel(sObj);
				// 					// that.getView().setModel(sModel, "visibleModel");

				// 					// sap.ui.getCore().byId("DwellSummarypanel").setVisible(false);
				// 					sap.ui.getCore().byId("dwellscroll").setHeight("18rem");
				// 				}

				// 				that.fnCreateBusyDialog("pallet.svg", "false");
				// 			}

				// 		},
				// 		error: function() {
				// 			that.fnCreateBusyDialog("pallet.svg", "false");
				// 		}
				// 	});

			},

			mainTableBinding: function() {
				var that = this;
				var sInputModel = that.getView().getModel("plantDetailModel").getData();
				var sPlant = sInputModel.Plants;
				var oStartDate = sInputModel.DateStart.replace(/-/g, "");
				var oEndDate = sInputModel.DateEnd.replace(/-/g, "");
				var oStartTime = sInputModel.StartTime.replace(/:/g, "");
				var oEndTime = sInputModel.EndTime.replace(/:/g, "");
				vRegion = jQuery.sap.storage(jQuery.sap.storage.Type.local).get("region");
				that.getOwnerComponent().getModel("fdeRepModel").read("/DWELL_SUMMERYSet(Werks='" + sPlant + "',StartDate='" + oStartDate +
					"',EndDate='" + oEndDate + "',StartTime='" + oStartTime + "',EndTime='" + oEndTime + "')", {
						/*	parameters: {
							expand: "DwellNavig"
						},*/
						urlParameters: {
							"$expand": "DwellNavig"
						},
						//	filters: sDwellFilter,

						success: function(oData, oResponse) {
							if (oResponse.statusCode === 200 || oResponse.statusCode === "200") {
								var dwellModel = new JSONModel();
								dwellModel.setData(oData.DwellNavig.results);
								for (var i = 0; i < oData.DwellNavig.results.length; i++) {
									oData.DwellNavig.results[i].Region = vRegion;
								}
								// if (vRegion === "EU") {
								// 	for (var i = 0; i < oData.DwellNavig.results.length; i++) {
								// 		var sDwellTime = dwellModel.getProperty("/" + i + "/DwellTime");
								// 		if (sDwellTime !== "") {
								// 			var day = parseInt(sDwellTime / (24 * 3600));

								// 			sDwellTime = sDwellTime % (24 * 3600);
								// 			var hour = parseInt(sDwellTime / 3600);

								// 			sDwellTime %= 3600;
								// 			var minutes = parseInt(sDwellTime / 60);

								// 			var sdwellTimeFormat = day + " D " + ":" + hour + " HH " + ":" + minutes + " MM ";
								// 			dwellModel.setProperty("/" + i + "/DwellTime", sdwellTimeFormat);
								// 		} else {
								// 			sDwellTime = "";
								// 		}

								// 		var sCheckInTime = dwellModel.getProperty("/" + i + "/CheckinTime");
								// 		if (sCheckInTime !== "") {
								// 			var sNewCheckInTime = sCheckInTime.slice(3, 5) + "/" + sCheckInTime.slice(0, 2) + "/" + sCheckInTime.slice(6, 20);
								// 		} else {
								// 			sNewCheckInTime = "";
								// 		}
								// 		dwellModel.setProperty("/" + i + "/CheckinTime", sNewCheckInTime);

								// 		var sCheckOutTime = dwellModel.getProperty("/" + i + "/CheckoutTime");
								// 		if (sCheckOutTime !== "") {
								// 			var sNewCheckOutTime = sCheckOutTime.slice(3, 5) + "/" + sCheckOutTime.slice(0, 2) + "/" + sCheckOutTime.slice(6, 20);
								// 		} else {
								// 			sNewCheckOutTime = "";
								// 		}
								// 		dwellModel.setProperty("/" + i + "/CheckoutTime", sNewCheckOutTime);

								// 		var sAppTime = dwellModel.getProperty("/" + i + "/Apptime");
								// 		if (sAppTime !== "0") {
								// 			var sNewAppTime = sAppTime.slice(6, 8) + "/" + sAppTime.slice(4, 6) + "/" + sAppTime.slice(0, 4) + " " +
								// 				sAppTime.slice(8, 10) + ":" + sAppTime.slice(10, 12) + ":" + sAppTime.slice(12, 14);

								// 		} else {
								// 			sNewAppTime = 0;
								// 		}
								// 		dwellModel.setProperty("/" + i + "/Apptime", sNewAppTime);

								// 		var sPlannedGIDate = dwellModel.getProperty("/" + i + "/PlannedGI_date");
								// 		if (sPlannedGIDate !== "") {
								// 			var sNewGIDate = sPlannedGIDate.slice(6, 8) + "/" + sPlannedGIDate.slice(4, 6) + "/" + sPlannedGIDate.slice(0, 4);

								// 		} else {
								// 			sNewGIDate = "";
								// 		}
								// 		dwellModel.setProperty("/" + i + "/PlannedGI_date", sNewGIDate);

								// 		var sDoorArrivalTime = dwellModel.getProperty("/" + i + "/DoorArrival");
								// 		if (sDoorArrivalTime !== "0") {
								// 			var sNewDoorArrivalTime = sDoorArrivalTime.slice(6, 8) + "/" + sDoorArrivalTime.slice(4, 6) + "/" + sDoorArrivalTime.slice(
								// 					0, 4) + " " +
								// 				sDoorArrivalTime.slice(8, 10) + ":" + sDoorArrivalTime.slice(10, 12) + ":" + sDoorArrivalTime.slice(12, 14);

								// 		} else {
								// 			sNewDoorArrivalTime = 0;
								// 		}
								// 		dwellModel.setProperty("/" + i + "/DoorArrival", sNewDoorArrivalTime);

								// 		var sParkTime = dwellModel.getProperty("/" + i + "/ParkTime");
								// 		if (sParkTime !== "0") {
								// 			var sNewParkTime = sParkTime.slice(6, 8) + "/" + sParkTime.slice(4, 6) + "/" + sParkTime.slice(0, 4) + " " +
								// 				sParkTime.slice(8, 10) + ":" + sParkTime.slice(10, 12) + ":" + sParkTime.slice(12, 14);

								// 		} else {
								// 			sNewParkTime = 0;
								// 		}
								// 		dwellModel.setProperty("/" + i + "/ParkTime", sNewParkTime);

								// 	}

								// }
								dwellModel.setSizeLimit(oData.DwellNavig.results.length);
								that.getView().setModel(dwellModel, "dwelltabModel");
								that.bindAllPanelsandTables(oData.DwellNavig.results);
								that.totalCount();

								var DnHflag = oData.DhFlag;

								var sAvgModel = new JSONModel();
								var objAvg = {};
								objAvg.LiveCount = oData.LiveCount;
								objAvg.DhCount = oData.DhCount;
								objAvg.TrailersCount = oData.TrailersCount;

								objAvg.AvgDwellTime = formatter.calDwellTime(oData.AvgDwellTime);
								objAvg.AvgLiveTime = formatter.calDwellTime(oData.AvgLiveTime);
								objAvg.AvgDhTime = formatter.calDwellTime(oData.AvgDhTime);

								objAvg.DhFlag = oData.DhFlag;

								sAvgModel.setData(objAvg);
								that.getView().setModel(sAvgModel, "averageModel");
								jQuery.sap.storage(jQuery.sap.storage.Type.local).put("dwellTimeAvg", objAvg);
								// jQuery.sap.storage(jQuery.sap.storage.Type.local).put("liveTimeAvg", objAvg.AvgLiveTime);
								// jQuery.sap.storage(jQuery.sap.storage.Type.local).put("dhTimeAvg", objAvg.AvgDhTime);
								// that.getView().setModel(sAvgModel, "onRefreshModel");

								if (DnHflag === 'X') {

									sap.ui.getCore().byId("liveLabel").setVisible(true);
									sap.ui.getCore().byId("liveText").setVisible(true);
									sap.ui.getCore().byId("avgLiveTimeLabel").setVisible(true);
									sap.ui.getCore().byId("avgLiveTimeText").setVisible(true);
									sap.ui.getCore().byId("dnhLabel").setVisible(true);
									sap.ui.getCore().byId("dnhText").setVisible(true);
									sap.ui.getCore().byId("avgDnHTimeLabel").setVisible(true);
									sap.ui.getCore().byId("avgDnHTimeText").setVisible(true);
									// var sObj = {
									// 	"liveLabel": true,
									// 	"liveText": true,
									// 	"avgLiveTimeLabel": true,
									// 	"avgLiveTimeText": true,
									// 	"dnhLabel": true,
									// 	"dnhText": true,
									// 	"avgDnHTimeLabel": true,
									// 	"avgDnHTimeText": true

									// };

									// var sModel = new sap.ui.model.json.JSONModel(sObj);
									// that.getView().setModel(sModel, "visibleModel");

									// sap.ui.getCore().byId("DwellSummarypanel").setVisible(true);
									sap.ui.getCore().byId("dwellscroll").setHeight("15rem");
								} else {
									sap.ui.getCore().byId("liveLabel").setVisible(false);
									sap.ui.getCore().byId("liveText").setVisible(false);
									sap.ui.getCore().byId("avgLiveTimeLabel").setVisible(false);
									sap.ui.getCore().byId("avgLiveTimeText").setVisible(false);
									sap.ui.getCore().byId("dnhLabel").setVisible(false);
									sap.ui.getCore().byId("dnhText").setVisible(false);
									sap.ui.getCore().byId("avgDnHTimeLabel").setVisible(false);
									sap.ui.getCore().byId("avgDnHTimeText").setVisible(false);
									// var sObj = {
									// 	"liveLabel": false,
									// 	"liveText": false,
									// 	"avgLiveTimeLabel": false,
									// 	"avgLiveTimeText": false,
									// 	"dnhLabel": false,
									// 	"dnhText": false,
									// 	"avgDnHTimeLabel": false,
									// 	"avgDnHTimeText": false
									// };

									// var sModel = new sap.ui.model.json.JSONModel(sObj);
									// that.getView().setModel(sModel, "visibleModel");

									// sap.ui.getCore().byId("DwellSummarypanel").setVisible(false);
									sap.ui.getCore().byId("dwellscroll").setHeight("18rem");
								}

								that.fnCreateBusyDialog("pallet.svg", "false");
							}

						},
						error: function() {
							that.fnCreateBusyDialog("pallet.svg", "false");
						}
					});

			},

			totalCount: function() {

				var sModel = this.getView().getModel("dwelltabModel").getData();

				var liveCount = 0;
				var DnHCount = 0;
				for (var i = 0; i < sModel.length; i++) {
					var sCheckinType = sModel[i].ZcheckinTy;
					if (sCheckinType === "Live") {
						liveCount = liveCount + 1;
					} else if (sCheckinType === "D & H") {
						DnHCount = DnHCount + 1;
					}
				}

				var TrailProceed = liveCount + DnHCount;
				var sCountModel = new JSONModel();
				var modelobject = {
					"CountLive": liveCount,
					"CountDnH": DnHCount,
					"CountTrail": TrailProceed
				};
				sCountModel.setData(modelobject);
				this.getView().setModel(sCountModel, "totalCountModel");
			},

			//----------------------------------------------------------------------------------
			//Function to create Busy Dialog
			//----------------------------------------------------------------------------------
			fnCreateBusyDialog: function(sImage, sBusy) {
				var that = this;
				//	that.oInsCreateDailog;
				if (sBusy === "true") {
					that.oInsCreateDailog = new sap.m.Dialog({
						showHeader: false
					}).addStyleClass("busyDialog sapUiTinyMargin");
					var sComponentName = that.getOwnerComponent().getMetadata().getComponentName();
					var imgUrl = $.sap.getModulePath(sComponentName, "/images/");
					var oImage = new sap.m.Image().addStyleClass("sapUiMediumMargin");
					oImage.setSrc(imgUrl + sImage);
					that.oInsCreateDailog.addContent(oImage);
					that.oInsCreateDailog.open();
				} else {
					that.oInsCreateDailog.close();
				}
			},

			bindAllPanelsandTables: function(tableData) {
				var that = this;
				// that.onIssuesReturnsBind(tableData);
				that.dwelltableBinding(tableData);
			},

			dwelltableBinding: function(tableData) {
				/*Pass Data to Tables*/
				var oTemplate = new sap.m.ColumnListItem({
					type: "Navigation",
					cells: [
						new sap.m.Text({
							text: "{Signi}"
						}).addStyleClass("bold"),
						new sap.m.Text({
							text: "{Name1}"
						}).addStyleClass("bold"),
						new sap.m.Text({
							text: "{ZcheckinTy}"
							// 	text: {
							// 	parts: [{
							// 		path: 'ZcheckinTy'
							// 	}],

							// 	formatter: function(Zcheckintype) {
							// 		return formatter.checkInType(Zcheckintype);
							// 	}
							// }
						}),
						// new sap.m.Text({
						// 	text: "{Zcintime}"
						// }),
						new sap.m.ObjectStatus({
							text: {
								parts: [{
									path: 'DwellTime'
								}, {
									path: 'Region'
								}],
								formatter: function(Zdwelltime, Region) {
									return formatter.calDwellTime(Zdwelltime, Region);
								}

							}
						}).addStyleClass("bold"),
						// new sap.m.Text({
						// 	text: "{CheckinTime}"
						// }),
						new sap.m.Text({
							text: {
								parts: [{
									path: 'CheckinTime'
								}, {
									path: 'Region'
								}],
								formatter: function(CheckinTime, Region) {
									return formatter.DwellRepDateFormat(CheckinTime, Region);
								}

							}
						}),

						new sap.m.Text({
							// text: "{CheckoutTime}"
							text: {
								parts: [{
									path: 'CheckoutTime'
								}, {
									path: 'Region'
								}],
								formatter: function(CheckoutTime, Region) {
									return formatter.DwellRepDateFormat(CheckoutTime, Region);
								}

							}
						}),
						new sap.m.Text({
							text: "{Ib_Delivery}"
						}),
						new sap.m.Text({
							text: "{Driver_Name}"
						}),
						new sap.m.Text({
							text: "{Ob_Delivery}"
						}),
						new sap.m.Text({
							text: "{Namef}"
						}),
						new sap.m.Text({
							text: "{Werks}"
						}),
						new sap.m.Text({
							// text: "{Apptime}"
							text: {
								parts: [{
									path: 'Apptime'
								}, {
									path: 'Region'
								}],
								formatter: function(appTime, Region) {
									return formatter.DwellRepAppTimeFormt(appTime, Region);
								}

							}
						}),
						new sap.m.ObjectStatus({
							text: {
								parts: [{
									path: 'PlannedGI_date'
								}, {
									path: 'Region'
								}],
								formatter: function(GiTime, Region) {
									return formatter.DwellRepPlannedGIdate(GiTime, Region);
								}

							}
						}),
						// new sap.m.Text({
						// 	text: "{PlannedGI_date}"
						// }),
						// new sap.m.Text({
						// 	text: "{DoorArrival}"
						// }),
						new sap.m.ObjectStatus({
							// text: {
							// 	parts: [{
							// 		path: 'DoorArrival'
							// 	}],
							// 	// formatter: function(DoorArrival) {
							// 	// 	return formatter.doorArrival(DoorArrival);
							// 	// }

							// }

							text: {
								parts: [{
									path: 'DoorArrival'
								}, {
									path: 'Region'
								}],
								formatter: function(DoorTime, Region) {
									return formatter.DwellRepDoorArrival(DoorTime, Region);
								}

							}
						}),
						new sap.m.ObjectStatus({
							// text: {
							// 	parts: [{
							// 		path: 'ParkTime'
							// 	}],
							// }
							text: {
								parts: [{
									path: 'ParkTime'
								}, {
									path: 'Region'
								}],
								formatter: function(DoorTime, Region) {
									return formatter.DwellRepDoorArrival(DoorTime, Region);
								}

							}
						}),
						// new sap.m.Text({
						// 	text: "{ParkTime}"
						// }),
						new sap.m.Text({
							text: "{RegNo}"
						}),
						new sap.m.Text({
							text: "{Trailer_type}"
						}),
						new sap.m.Text({
							text: "{CheckInSystem}"
						}),
						new sap.m.Text({
							text: "{CheckOutSystem}"
						}),
						new sap.m.Text({
							text: "{CheckInType}"
						})
					]
				});

				/*Table Binding*/
				var oDwellTimeTable = sap.ui.getCore().byId("DwellTimeTab");
				var oModel1 = new sap.ui.model.json.JSONModel();
				oModel1.setSizeLimit(tableData.length);
				oModel1.setData(tableData);
				if (oDwellTimeTable !== undefined) {
					oDwellTimeTable.setModel(oModel1);
					oDwellTimeTable.bindAggregation("items", {
						path: "/",
						template: oTemplate
					});
				}
				/*Table Grouping*/
				var oGroupingModel = new JSONModel({
					hasGrouping: false
				});
				this.getView().setModel(oGroupingModel, 'Grouping');

			},

			distinctData: function(oEvent) {

				// this._onRouteMatched();

				/*All Model Data of table*/
				var sModel = this.getView().getModel("dwelltabModel").getData();
				/*	var sCountModel = new JSONModel();
				sCountModel.setData(sModel);*/
				this.getView().getModel("dwelltabModel").setData(sModel);
				// 	that.getView().getModel("averageModel").setProperty("/AvgDwellTime", formatter.calDwellTime(sDwellCount));

				// if (oEvent.getParameters().filterString) {
				// 	var filteredData = oEvent.getParameters().filterString;
				// 	if (filteredData.includes("Live")) {
				// 		that.getView().getModel("averageModel").setProperty("/AvgLiveTime", formatter.calDwellTime(totalFilteredSeconds));
				// 	} else if (filteredData.includes("D&H")) {
				// 		that.getView().getModel("averageModel").setProperty("/AvgDhTime", formatter.calDwellTime(totalFilteredSeconds));
				// 	}

				/*Refresh Model Data*/
				var initialAvg = jQuery.sap.storage(jQuery.sap.storage.Type.local).get("dwellTimeAvg");
				this.getView().getModel("averageModel").setProperty("/AvgDwellTime", initialAvg.AvgDwellTime);
				this.getView().getModel("averageModel").setProperty("/AvgLiveTime", initialAvg.AvgLiveTime);
				this.getView().getModel("averageModel").setProperty("/AvgDhTime", initialAvg.AvgDhTime);

				// jQuery.sap.storage(jQuery.sap.storage.Type.local).get("liveTimeAvg");
				// jQuery.sap.storage(jQuery.sap.storage.Type.local).get("dhTimeAvg");
				//var totalModDaata = this.getView().getModel("onRefreshModel").getData();//
				// var dwelldwell = this.getView().getModel().getProperty("/averageModel/AvgDwellTime");
				// console.log(dwelldwell);
				// var beginAvgModel = new JSONModel();
				// beginAvgModel.setData(totalModDaata);
				// this.getView().setModel(totalModDaata, "averageModel");
				//	this.getView().getModel("averageModel").setData(totalModDaata);//
				/*	var modelobject = {
					"Count": aUniqueDelNum.length,
					"Sum": tot_Quantity
				};*/

			},

			onTableRefresh: function() {
				//Remove Filters
				if (sap.ui.getCore().byId("DwellTimeTab") !== undefined) {
					var oTable = sap.ui.getCore().byId("DwellTimeTab");
					var oModel = oTable.getModel();
					var oTableBinding = oTable.getBinding("items");
					oTableBinding.aSorters = null;
					oTableBinding.aFilters = null;
					oModel.refresh(true);
				}
				if (sap.ui.getCore().byId("dwellheaderData") !== undefined) {
					sap.ui.getCore().byId("dwellheaderData").setText("");
				}
				this.resetFilterItems();
				this.distinctData();
				this.mainTableBinding();
			},

			resetFilterItems: function() {
				var that = this;
				that.oInsCreateDailog.open();
				if (this._filterDialog !== undefined) {
					var aFilterItems = this._filterDialog.getFilterItems();

					aFilterItems.forEach(function(item) {
						var aItems = item.getItems();
						aItems.forEach(function(item) {
							item.setSelected(false);
						});
					});
				}
				that.oInsCreateDailog.close();
			},

			onPersoButtonPressed: function(oEvent) {
				this._oTPC.openDialog();
			},

			onTablePersoRefresh: function() {
				DwellPersoService.resetPersData();
				this._oTPC.refresh();
			},

			onTableGrouping: function(oEvent) {
				// alert("msg")
				// this._oTPC.setHasGrouping(oEvent.getSource().getSelected());
				this._oTPC.setHasGrouping(sap.ui.getCore().byId("dwellgroupCheck").getSelected());

			},

			loadFiltersData: function() {
				var filterResults = sap.ui.getCore().byId("DwellTimeTab").getModel().getData();

				//----Binded unique data of scac/carrier to filter fragment----//
				var carrierarray = [];
				for (var i = 0; i < filterResults.length; i++) {
					if (carrierarray.indexOf(filterResults[i].Name1) === -1) {
						carrierarray.push(filterResults[i].Name1);
					}
				}
				if (sap.ui.getCore().byId("CarrierFilter") !== undefined) {
					sap.ui.getCore().byId("CarrierFilter").setModel(new JSONModel(carrierarray), "sCarrier");
				}

				//----Binded unique data of type to filter fragment----//
				var Typearray = [];
				for (var i = 0; i < filterResults.length; i++) {
					if (Typearray.indexOf(filterResults[i].ZcheckinTy) === -1) {
						Typearray.push(filterResults[i].ZcheckinTy);
					}
				}

				if (sap.ui.getCore().byId("TypeFilter") !== undefined) {
					sap.ui.getCore().byId("TypeFilter").setModel(new JSONModel(Typearray), "sCheckInType");
				}

				//----Binded unique data of trailer type to filter fragment----//
				var Trailerarray = [];
				for (var i = 0; i < filterResults.length; i++) {
					if (Trailerarray.indexOf(filterResults[i].Trailer_type) === -1) {
						Trailerarray.push(filterResults[i].Trailer_type);
					}
				}

				if (sap.ui.getCore().byId("TrailerFilter") !== undefined) {
					sap.ui.getCore().byId("TrailerFilter").setModel(new JSONModel(Trailerarray), "sTrailerType");
				}
				//----Binded unique data of parent plant to filter fragment----//
				var ParentPlant = [];
				for (var i = 0; i < filterResults.length; i++) {
					if (ParentPlant.indexOf(filterResults[i].Werks) === -1) {
						ParentPlant.push(filterResults[i].Werks);
					}
				}
				if (sap.ui.getCore().byId("DwellPlantFilter") !== undefined) {
					sap.ui.getCore().byId("DwellPlantFilter").setModel(new JSONModel(ParentPlant), "sParentPlant");
				}

			},

			onFilterPressed: function() {
				var that = this;
				that.oInsCreateDailog.open();

				if (!this._filterDialog) {
					this._filterDialog = sap.ui.xmlfragment("com.report.fragments.DwellFilter", this);
					this.getView().addDependent(this._filterDialog);
				}
				/*** adding filter items for the multiplant scenario ***/
				var parentplant = this.getView().getModel("ViewModel").getProperty("/ParentPlant");
				if (parentplant !== "") {
					if (sap.ui.getCore().byId("DwellPlantFilter") === undefined) {
						var ParentPlantFilter = new sap.m.ViewSettingsFilterItem("DwellPlantFilter", {
							multiSelect: true,
							text: "{i18n>Plant}"

						});
						var Template = new sap.m.ViewSettingsItem({
							key: "Werks",
							text: "{sParentPlant>}"
						});
						ParentPlantFilter.bindAggregation("items", "sParentPlant>/", Template);
						this._filterDialog.addFilterItem(ParentPlantFilter);
					}
				}
				this.loadFiltersData();
				// toggle compact style
				jQuery.sap.syncStyleClass("sapUiSizeCompact", this.getView(), this._filterDialog);
				this._filterDialog.open();

				that.oInsCreateDailog.close();
			},

			//---------------------Code for filtering----------------------//

			onFilterConfirm: function(oEvent) {
				var that = this;
				that.oInsCreateDailog.open();
				var oView = sap.ui.getCore();
				if (oView.byId("DwellTimeTab") !== undefined) {
					var yTableFilter = oView.byId("DwellTimeTab");
					var mParams = oEvent.getParameters();
					var oBinding = yTableFilter.getBinding("items");
					var aFilters = [];
					for (var i = 0, l = mParams.filterItems.length; i < l; i++) {
						var oItem = mParams.filterItems[i];
						if (oItem.getKey() === "CarrierType") {
							var oFilter1 = new sap.ui.model.Filter("Name1", "EQ", oItem.getText());
							aFilters.push(oFilter1);
						} else if (oItem.getKey() === "CheckInType") {
							var oFilter2 = new sap.ui.model.Filter("ZcheckinTy", "EQ", oItem.getText());
							aFilters.push(oFilter2);
						} else if (oItem.getKey() === "TrailerType") {
							var oFilter3 = new sap.ui.model.Filter("Trailer_type", "EQ", oItem.getText());
							aFilters.push(oFilter3);
						} else if (oItem.getKey() === "Werks") {
							var oFilter3 = new sap.ui.model.Filter("Werks", "EQ", oItem.getText());
							aFilters.push(oFilter3);
						}
					}
					oBinding.filter(aFilters);
				}

				var filteredIndices = oBinding.getContexts();
				var sDwellCount = 0;
				var totalFilteredSeconds = 0;
				for (var k = 0; k < filteredIndices.length; k++) {
					var docPath = oBinding.getContexts()[k].getPath();
					/*Calculate Filtered Dwell Time Average*/
					var sCount = sap.ui.getCore().byId("DwellTimeTab").getModel("dwelltabModel").getProperty(docPath).DwellTime;
					sDwellCount = sDwellCount + Number(sCount);

					/*Calculate Live and D&H average*/
					var sInTime = this.getView().getModel("dwelltabModel").getProperty(docPath).Zcheckout;
					var sOutTime = this.getView().getModel("dwelltabModel").getProperty(docPath).Zcintime;
					totalFilteredSeconds = totalFilteredSeconds + formatter.calculateDiffTimeAvg(sOutTime, sInTime);

				}
				sDwellCount = sDwellCount / that.getView().getModel("averageModel").getProperty("/TrailersCount");
				totalFilteredSeconds = totalFilteredSeconds / filteredIndices.length;

				that.getView().getModel("averageModel").setProperty("/AvgDwellTime", formatter.calDwellTime(sDwellCount));

				if (oEvent.getParameters().filterString) {
					var filteredData = oEvent.getParameters().filterString;
					if (filteredData.includes("Live")) {
						that.getView().getModel("averageModel").setProperty("/AvgLiveTime", formatter.calDwellTime(totalFilteredSeconds));
					} else if (filteredData.includes("D&H")) {
						that.getView().getModel("averageModel").setProperty("/AvgDhTime", formatter.calDwellTime(totalFilteredSeconds));
					}
					that.getView().getModel("averageModel").updateBindings();
					that.getView().getModel("onRefreshModel");

					if (sap.ui.getCore().byId("dwellheaderData") !== undefined) {
						sap.ui.getCore().byId("dwellheaderData").setText(filteredData);
					}
				}

				that.oInsCreateDailog.close();
			},

			//----------------Code for opening Sorter Dailog when sorter icon pressed---------------------//

			onSorterPressed: function() {
				var that = this;
				that.oInsCreateDailog.open();
				if (!this._sorterDialog) {
					this._sorterDialog = sap.ui.xmlfragment("com.report.fragments.DwellSorter", this);
					this.getView().addDependent(this._sorterDialog);
				}
				/*** adding sort items for the multiplant scenario ***/
				var parentplant = this.getView().getModel("ViewModel").getProperty("/ParentPlant");
				if (parentplant !== "") {
					if (sap.ui.getCore().byId("DwellPlantSorter") === undefined) {
						var ParentPlantSort = new sap.m.ViewSettingsItem("DwellPlantSorter", {
							text: "{i18n>Plant}",
							key: "Werks"

						});
						this._sorterDialog.addSortItem(ParentPlantSort);
					}
				}
				// toggle compact style
				jQuery.sap.syncStyleClass("sapUiSizeCompact", this.getView(), this._sorterDialog);
				this._sorterDialog.open();
				that.oInsCreateDailog.close();
			},

			//-----------------------Code for Sorting---------------------------//

			onSortConfirm: function(oEvent) {

				var that = this;
				that.oInsCreateDailog.open();
				var oView = sap.ui.getCore();
				if (oView.byId("DwellTimeTab") !== undefined) {
					var dwellRepTable = oView.byId("DwellTimeTab");
					var mParams = oEvent.getParameters();
					var oBinding = dwellRepTable.getBinding("items");
					var aSorters = [];
					if (mParams.sortItem !== undefined) {
						var sPath = mParams.sortItem.getKey();
						var bDescending = mParams.sortDescending;
						aSorters.push(new sap.ui.model.Sorter(sPath, bDescending));
						oBinding.sort(aSorters);
						// var sModel = this.getView().getModel("dwelltabModel").getData();
						// var minArray = [];
						// for (var i = 0; i < sModel.length; i++) {
						// 	var sCheckinType = sModel[i].DwellTime;
						// 	var sDaysHours = sCheckinType.split(":");
						// 	var sDays = sDaysHours[0] + " days ";
						// 	var sHours = sDaysHours[1].substr(0, 2) + " hrs " + sDaysHours[1].substr(2, 2) + " min ";
						// 	var minConersion = (sDaysHours[0] * 1440) + (sDaysHours[1].substr(0, 2) * 60) + sDaysHours[1].substr(2, 2);
						// 	minArray.push(minConersion);
						// }

						// if (bDescending === "true") {
						// 	aSorters.push(minArray.reverse());
						// 	oBinding.sort(aSorters);
						// } else {
						// 	aSorters.push(minArray.sort());
						// 	oBinding.sort(aSorters);
						// }
					}
				}

				that.oInsCreateDailog.close();
			},

			//-----------------------------------------------------------------------------------------
			// Function for expanding the panles inside the plant panels
			//-----------------------------------------------------------------------------------------
			onPressExp: function(oEvent) {
				var oPanelId = oEvent.getSource().getParent().getParent().getId();
				var oButtonId = oEvent.getSource().getId();
				if (sap.ui.getCore().byId(oPanelId).getExpanded()) {
					sap.ui.getCore().byId(oPanelId).setExpanded(false);
					sap.ui.getCore().byId(oButtonId).setIcon("sap-icon://expand-group");
				} else {
					sap.ui.getCore().byId(oPanelId).setExpanded(true);
					sap.ui.getCore().byId(oButtonId).setIcon("sap-icon://collapse-group");
				}
			},

			onNavButtonPress: function() {
				var that = this;
				// DnHflag = "";

				// that.getView().getModel("visibleModel").setData([]);

				var oRouter = sap.ui.core.UIComponent.getRouterFor(this);
				oRouter.navTo("ReportInter");

			},

			onPressExport: sap.m.Table.prototype.exportData || function(oEvent) {

				var that = this;

				var sDwellTimeCol;
				if (vRegion === "ZA") {
					sDwellTimeCol = that.getOwnerComponent().getModel("i18n").getProperty("dwellColForZA");
				} else {
					sDwellTimeCol = that.getOwnerComponent().getModel("i18n").getProperty("dwellTime");
				}

				var oExport = new Export({
					exportType: new ExportTypeCSV({
						separatorChar: ",",
						fileExtension: "csv"
						// mimeType: "application/vnd.ms-excel",
						// charset: "utf-8"
					}),
					models: sap.ui.getCore().byId("DwellTimeTab").getModel(),
					rows: {
						path: "/"
					},
					// columns: aTemplate

					columns: [{
							// name: "Container ID",
							name: this.getOwnerComponent().getModel("i18n").getProperty("containerId"),
							template: {
								content: "{Signi}"
							}
						}, {
							// name: "Carrier",
							name: this.getOwnerComponent().getModel("i18n").getProperty("carrier"),
							template: {
								content: "{Name1}"
							}
						}, {
							// name: "Type",
							name: this.getOwnerComponent().getModel("i18n").getProperty("type"),
							template: {
								content: "{ZcheckinTy}"
							}
						}, {
							// name: "Dwell Time",
							name: sDwellTimeCol,
							template: {
								// content: "{DwellTime}"
								content: {
									parts: ["DwellTime", "Region"],
									formatter: function(dwellTime, Region) {
										// var day = parseInt(dwell / (24 * 3600));

										// dwell = dwell % (24 * 3600);
										// var hour = parseInt(dwell / 3600);

										// dwell %= 3600;
										// var minutes = parseInt(dwell / 60);

										// var sdwellTimeFormat = day + " days " + hour + " hrs " + minutes + " min ";
										// return sdwellTimeFormat;
										var sdwellTimeFormat;
										var day = parseInt(dwellTime / (24 * 3600));

										dwellTime = dwellTime % (24 * 3600);
										var hour = parseInt(dwellTime / 3600);

										dwellTime %= 3600;

										var minutes = parseInt(dwellTime / 60);

										if (Region === "EU" || Region === "LATAM" || Region === "ZA") {
											if (hour < 10) {
												hour = '0' + hour;
											}
											if (minutes < 10) {
												minutes = '0' + minutes;
											}
											sdwellTimeFormat = day + " " + ":" + " " + hour + " " + ":" + " " + " " + minutes;
										} else {

											sdwellTimeFormat = day + " days " + hour + " hrs " + minutes + " min ";
										}
										return sdwellTimeFormat;
									}
								}
							}
						}, {
							// name: "Check-In Timestamp",
							name: this.getOwnerComponent().getModel("i18n").getProperty("checkInStamp"),
							// template: {
							// 	content: "{CheckinTime}"
							// }
							template: {
								// content: "{DeliveryType}"
								content: {
									parts: ["CheckinTime", "Region"],
									formatter: function(date, Region) {
										if (date !== null) {
											if (Region === "EU" || Region === "LATAM" || Region === "ZA") {
												var sFormat = date.slice(3, 5) + "/" + date.slice(0, 2) + "/" + date.slice(6, 20);
												return sFormat;
											} else {
												return date;
											}
										}
									}
								}
							}
						}, {
							// name: "Check-Out Timestamp",
							name: this.getOwnerComponent().getModel("i18n").getProperty("checkOutStamp"),
							template: {
								// content: "{CheckoutTime}"
								content: {
									parts: ["CheckoutTime", "Region"],
									formatter: function(date, Region) {
										if (date !== null) {
											var matchPattern = date.match(/\d+/g);
											if (matchPattern != null) {
												if (Region === "EU" || Region === "LATAM" || Region === "ZA") {
													var sFormat = date.slice(3, 5) + "/" + date.slice(0, 2) + "/" + date.slice(6, 20);
													return sFormat;
												} else {
													return date;
												}

											} else {
												return date;
											}

										}
									}
								}
							}
						}, {
							// name: "IB Delivery",
							name: this.getOwnerComponent().getModel("i18n").getProperty("ibDelv"),
							template: {
								content: "{Ib_Delivery}"
							}
						}, {
							// name: "Driver Name",
							name: this.getOwnerComponent().getModel("i18n").getProperty("driverName"),
							template: {
								content: "{Driver_Name}"
							}
						}, {
							// name: "OB Delivery",
							name: this.getOwnerComponent().getModel("i18n").getProperty("obDelv"),
							template: {
								content: "{Ob_Delivery}"
							}
						}, {
							// name: "Driver Name",
							name: this.getOwnerComponent().getModel("i18n").getProperty("driverName"),
							template: {
								content: "{Namef}"
							}
						}, {
							// name: "Appointment Time",
							name: this.getOwnerComponent().getModel("i18n").getProperty("appTime"),
							template: {
								// content: "{Apptime}"
								// parts: ["Apptime"],
								// formatter: function(apptime) {
								// 	if (apptime === "0") {
								// 		return "";
								// 	} else {
								// 		return apptime;
								// 	}
								// }

								content: {
									parts: ["Apptime", "Region"],
									formatter: function(appTime, Region) {
										if (Region === "EU" || Region === "LATAM" || Region === "ZA") {
											if ((appTime === "0") || (appTime === 0)) {
												return 0;
											} else if (appTime !== null && appTime !== "0" && appTime !== undefined) {
												var newAppointmentTime = appTime.slice(6, 8) + "/" + appTime.slice(4, 6) + "/" + appTime.slice(0, 4) + " " +
													appTime.slice(
														8, 10) + ":" + appTime.slice(10, 12) + ":" + appTime.slice(12, 14);
												return newAppointmentTime;
											}
										} else {
											if ((appTime === "0") || (appTime === 0)) {
												return 0;
											} else if (appTime !== null && appTime !== "0" && appTime !== undefined) {
												var newAppointmentTime = appTime.slice(4, 6) + "/" + appTime.slice(6, 8) + "/" + appTime.slice(0, 4) + " " +
													appTime.slice(
														8, 10) + ":" + appTime.slice(10, 12) + ":" + appTime.slice(12, 14);
												return newAppointmentTime;
											}
										}
									}
								}
							}
						}, {
							// name: "Planned GI Date",
							name: this.getOwnerComponent().getModel("i18n").getProperty("planGIdate"),
							template: {
								// content: "{PlannedGI_date}"
								content: {
									parts: ["PlannedGI_date", "Region"],
									formatter: function(PlanDate, Region) {
										if (Region === "EU" || Region === "LATAM" || Region === "ZA") {
											if (PlanDate !== null && PlanDate !== "0" && PlanDate !== "" && PlanDate !== undefined) {
												var newPlannedGIDate = PlanDate.slice(6, 8) + "/" + PlanDate.slice(4, 6) + "/" + PlanDate.slice(0, 4);
												return newPlannedGIDate;
											}
										} else {
											if (PlanDate !== null && PlanDate !== "0" && PlanDate !== "" && PlanDate !== undefined) {
												var newPlannedGIDate = PlanDate.slice(4, 6) + "/" + PlanDate.slice(6, 8) + "/" + PlanDate.slice(0, 4);
												return newPlannedGIDate;
											}
										}
									}
								}
							}
						}, {
							// name: "Door Arrival Time",
							name: this.getOwnerComponent().getModel("i18n").getProperty("doorArrivTime"),
							template: {
								// content: "{DoorArrival}"
								content: {
									parts: ["DoorArrival", "Region"],
									formatter: function(DoorArrival, Region) {
										if (Region === "EU" || Region === "LATAM" || Region === "ZA") {
											if (DoorArrival === "0") {
												return 0;
											} else if (DoorArrival !== null && DoorArrival !== "0" && DoorArrival !== undefined) {
												var newDoorArrival = DoorArrival.slice(6, 8) + "/" + DoorArrival.slice(4, 6) + "/" + DoorArrival.slice(0, 4) + " " +
													DoorArrival.slice(8, 10) + ":" + DoorArrival.slice(10, 12) + ":" + DoorArrival.slice(12, 14);
												return newDoorArrival;
											}
										}
										if (DoorArrival === "0") {
											return 0;
										} else if (DoorArrival !== null && DoorArrival !== "0" && DoorArrival !== undefined) {
											var newDoorArrival = DoorArrival.slice(4, 6) + "/" + DoorArrival.slice(6, 8) + "/" + DoorArrival.slice(0, 4) + " " +
												DoorArrival.slice(
													8, 10) + ":" + DoorArrival.slice(10, 12) + ":" + DoorArrival.slice(12, 14);
											return newDoorArrival;
										}
									}
								}
							}
						}, {
							// name: "Park Time",
							name: this.getOwnerComponent().getModel("i18n").getProperty("parkTime"),
							template: {
								// content: "{ParkTime}"
								content: {
									parts: ["ParkTime", "Region"],
									formatter: function(Parktime, Region) {
										if (Region === "EU" || Region === "LATAM" || Region === "ZA") {
											if (Parktime === "0") {
												return 0;
											} else if (Parktime !== null && Parktime !== "0" && Parktime !== undefined) {
												var newParkTime = Parktime.slice(6, 8) + "/" + Parktime.slice(4, 6) + "/" + Parktime.slice(0, 4) + " " + Parktime.slice(
													8, 10) + ":" + Parktime.slice(10, 12) + ":" + Parktime.slice(12, 14);
												return newParkTime;
											}
										} else {

											if (Parktime === "0") {
												return 0;
											} else if (Parktime !== null && Parktime !== "0" && Parktime !== undefined) {
												var newParkTime = Parktime.slice(4, 6) + "/" + Parktime.slice(6, 8) + "/" + Parktime.slice(0, 4) + " " + Parktime.slice(
													8, 10) + ":" + Parktime.slice(10, 12) + ":" + Parktime.slice(12, 14);
												return newParkTime;
											}
										}
									}
								}
							}
						}, {
							// name: "Reg Num",
							name: this.getOwnerComponent().getModel("i18n").getProperty("regNum"),
							template: {
								content: "{RegNo}"
							}
						}, {
							// name: "Trailer Type",
							name: this.getOwnerComponent().getModel("i18n").getProperty("trailtype"),
							template: {
								content: "{Trailer_type}"
							}
						}, {
							// name: "Check In System",
							name: this.getOwnerComponent().getModel("i18n").getProperty("checkInSys"),
							template: {
								content: "{CheckInSystem}"
							}
						}, {
							// name: "Check Out System",
							name: this.getOwnerComponent().getModel("i18n").getProperty("checkOutSys"),
							template: {
								content: "{CheckOutSystem}"
							}
						}

					]
				});
				/*** add this column only when parentplant is active ***/
				var parentplant = this.getView().getModel("ViewModel").getProperty("/ParentPlant");
				var sGetRegion = this.getView().getModel("regionModel").getProperty("/region");

				if (parentplant !== "") {
					oExport.insertColumn(new sap.ui.core.util.ExportColumn({
						name: this.getOwnerComponent().getModel("i18n").getProperty("Plant"),
						template: {
							content: "{Werks}"
						}
					}), 0);
					if (sGetRegion === "US") {
						oExport.insertColumn(new sap.ui.core.util.ExportColumn({
							name: this.getOwnerComponent().getModel("i18n").getProperty("checkInTyp"),
							template: {
								content: "{CheckInType}"
							}
						}), 18);
					}
				} else {
					if (sGetRegion === "US") {
						oExport.insertColumn(new sap.ui.core.util.ExportColumn({
							name: this.getOwnerComponent().getModel("i18n").getProperty("checkInTyp"),
							template: {
								content: "{CheckInType}"
							}
						}), 17);
					}
				}

				var sdwellReport = this.getOwnerComponent().getModel("i18n").getProperty("dwellReport");
				oExport.saveFile(sdwellReport).catch(function(oError) {
					// MessageBox.error("Error when downloading data. Browser might not be supported!\n\n" + oError);
				}).then(function() {
					oExport.destroy();
				});
			},

			onPressExportXLS: sap.m.Table.prototype.exportData || function(oEvent) {
				var that = this;
				var sDwellTimeCol;
				if (vRegion === "ZA") {
					sDwellTimeCol = that.getOwnerComponent().getModel("i18n").getProperty("dwellColForZA");
				} else {
					sDwellTimeCol = that.getOwnerComponent().getModel("i18n").getProperty("dwellTime");
				}
				var oExport = new Export({
					exportType: new ExportTypeCSV({
						separatorChar: "\t",
						fileExtension: "xls"
						// mimeType: "application/vnd.ms-excel",
						// charset: "utf-8"
					}),
					models: sap.ui.getCore().byId("DwellTimeTab").getModel(),
					rows: {
						path: "/"
					},

					columns: [{
							// name: "Container ID",
							name: this.getOwnerComponent().getModel("i18n").getProperty("containerId"),
							template: {
								content: "{Signi}"
							}
						}, {
							// name: "Carrier",
							name: this.getOwnerComponent().getModel("i18n").getProperty("carrier"),
							template: {
								content: "{Name1}"
							}
						}, {
							// name: "Type",
							name: this.getOwnerComponent().getModel("i18n").getProperty("type"),
							template: {
								content: "{ZcheckinTy}"
							}
						}, {
							// name: "Dwell Time",
							name: sDwellTimeCol,
							template: {
								// content: "{DwellTime}"
								content: {
									parts: ["DwellTime", "Region"],
									formatter: function(dwellTime, Region) {

										var sdwellTimeFormat;
										var day = parseInt(dwellTime / (24 * 3600));
										dwellTime = dwellTime % (24 * 3600);
										var hour = parseInt(dwellTime / 3600);

										dwellTime %= 3600;
										var minutes = parseInt(dwellTime / 60);
										if (Region === "EU" || Region === "LATAM" || Region === "ZA") {

											if (hour < 10) {
												hour = '0' + hour;
											}
											if (minutes < 10) {
												minutes = '0' + minutes;
											}

											sdwellTimeFormat = day + " " + ":" + " " + hour + " " + ":" + " " + " " + minutes;
										} else {

											sdwellTimeFormat = day + " days " + hour + " hrs " + minutes + " min ";
										}
										return sdwellTimeFormat;
									}
								}
							}
						}, {
							// name: "Check-In Timestamp",
							name: this.getOwnerComponent().getModel("i18n").getProperty("checkInStamp"),
							// template: {
							// 	content: "{CheckinTime}"
							// }

							// content: "{DeliveryType}"
							template: {
								content: {
									parts: ["CheckinTime", "Region"],
									formatter: function(date, Region) {
										if (date !== null) {
											if (Region === "EU" || Region === "LATAM" || Region === "ZA") {
												var sFormat = date.slice(3, 5) + "/" + date.slice(0, 2) + "/" + date.slice(6, 20);
												return sFormat;
											} else {
												return date;
											}
										}
									}
								}
							}

						}, {
							// name: "Check-Out Timestamp",
							name: this.getOwnerComponent().getModel("i18n").getProperty("checkOutStamp"),
							// template: {
							// 	content: "{CheckoutTime}"
							// }

							// content: "{DeliveryType}"
							template: {
								content: {
									parts: ["CheckoutTime", "Region"],
									formatter: function(date, Region) {
										if (date !== null) {
											var matchPattern = date.match(/\d+/g);
											if (matchPattern != null) {
												if (Region === "EU" || Region === "LATAM" || Region === "ZA") {
													var sFormat = date.slice(3, 5) + "/" + date.slice(0, 2) + "/" + date.slice(6, 20);
													return sFormat;
												} else {
													return date;
												}

											} else {
												return date;
											}

										}
									}
								}
							}

						}, {
							// name: "IB Delivery",
							name: this.getOwnerComponent().getModel("i18n").getProperty("ibDelv"),
							template: {
								content: "{Ib_Delivery}"
							}
						}, {
							// name: "Driver Name",
							name: this.getOwnerComponent().getModel("i18n").getProperty("driverName"),
							template: {
								content: "{Driver_Name}"
							}
						}, {
							// name: "OB Delivery",
							name: this.getOwnerComponent().getModel("i18n").getProperty("obDelv"),
							template: {
								content: "{Ob_Delivery}"
							}
						}, {
							// name: "Driver Name",
							name: this.getOwnerComponent().getModel("i18n").getProperty("driverName"),
							template: {
								content: "{Namef}"
							}
						}, {
							// name: "Appointment Time",
							name: this.getOwnerComponent().getModel("i18n").getProperty("appTime"),
							template: {
								// content: "{Apptime}"
								// parts: ["Apptime"],
								// formatter: function(apptime) {
								// 	if (apptime === "0") {
								// 		return "";
								// 	} else {
								// 		return apptime;
								// 	}
								// }

								content: {
									parts: ["Apptime", "Region"],
									formatter: function(appTime, Region) {
										if (Region === "EU" || Region === "LATAM" || Region === "ZA") {
											if ((appTime === "0") || (appTime === 0)) {
												return 0;
											} else if (appTime !== null && appTime !== "0" && appTime !== undefined) {
												var newAppointmentTime = appTime.slice(6, 8) + "/" + appTime.slice(4, 6) + "/" + appTime.slice(0, 4) + " " +
													appTime.slice(
														8, 10) + ":" + appTime.slice(10, 12) + ":" + appTime.slice(12, 14);
												return newAppointmentTime;
											}
										} else {
											if ((appTime === "0") || (appTime === 0)) {
												return 0;
											} else if (appTime !== null && appTime !== "0" && appTime !== undefined) {
												var newAppointmentTime = appTime.slice(4, 6) + "/" + appTime.slice(6, 8) + "/" + appTime.slice(0, 4) + " " +
													appTime.slice(
														8, 10) + ":" + appTime.slice(10, 12) + ":" + appTime.slice(12, 14);
												return newAppointmentTime;
											}
										}
									}
								}
							}
						}, {
							// name: "Planned GI Date",
							name: this.getOwnerComponent().getModel("i18n").getProperty("planGIdate"),
							template: {
								// content: "{PlannedGI_date}"
								content: {
									parts: ["PlannedGI_date", "Region"],
									formatter: function(PlanDate, Region) {
										if (Region === "EU" || Region === "LATAM" || Region === "ZA") {
											if (PlanDate !== null && PlanDate !== "0" && PlanDate !== "" && PlanDate !== undefined) {
												var newPlannedGIDate = PlanDate.slice(6, 8) + "/" + PlanDate.slice(4, 6) + "/" + PlanDate.slice(0, 4);
												return newPlannedGIDate;
											}
										} else {
											if (PlanDate !== null && PlanDate !== "0" && PlanDate !== "" && PlanDate !== undefined) {
												var newPlannedGIDate = PlanDate.slice(4, 6) + "/" + PlanDate.slice(6, 8) + "/" + PlanDate.slice(0, 4);
												return newPlannedGIDate;
											}
										}
									}
								}
							}
						}, {
							// name: "Door Arrival Time",
							name: this.getOwnerComponent().getModel("i18n").getProperty("doorArrivTime"),
							template: {
								// content: "{DoorArrival}"
								content: {
									parts: ["DoorArrival", "Region"],
									formatter: function(DoorArrival, Region) {
										if (Region === "EU" || Region === "LATAM" || Region === "ZA") {
											if (DoorArrival === "0") {
												return 0;
											} else if (DoorArrival !== null && DoorArrival !== "0" && DoorArrival !== undefined) {
												var newDoorArrival = DoorArrival.slice(6, 8) + "/" + DoorArrival.slice(4, 6) + "/" + DoorArrival.slice(0, 4) + " " +
													DoorArrival.slice(8, 10) + ":" + DoorArrival.slice(10, 12) + ":" + DoorArrival.slice(12, 14);
												return newDoorArrival;
											}
										}
										if (DoorArrival === "0") {
											return 0;
										} else if (DoorArrival !== null && DoorArrival !== "0" && DoorArrival !== undefined) {
											var newDoorArrival = DoorArrival.slice(4, 6) + "/" + DoorArrival.slice(6, 8) + "/" + DoorArrival.slice(0, 4) + " " +
												DoorArrival.slice(
													8, 10) + ":" + DoorArrival.slice(10, 12) + ":" + DoorArrival.slice(12, 14);
											return newDoorArrival;
										}
									}
								}
							}
						}, {
							// name: "Park Time",
							name: this.getOwnerComponent().getModel("i18n").getProperty("parkTime"),
							template: {
								// content: "{ParkTime}"
								content: {
									parts: ["ParkTime", "Region"],
									formatter: function(Parktime, Region) {
										if (Region === "EU" || Region === "LATAM" || Region === "ZA") {
											if (Parktime === "0") {
												return 0;
											} else if (Parktime !== null && Parktime !== "0" && Parktime !== undefined) {
												var newParkTime = Parktime.slice(6, 8) + "/" + Parktime.slice(4, 6) + "/" + Parktime.slice(0, 4) + " " + Parktime.slice(
													8, 10) + ":" + Parktime.slice(10, 12) + ":" + Parktime.slice(12, 14);
												return newParkTime;
											}
										} else {

											if (Parktime === "0") {
												return 0;
											} else if (Parktime !== null && Parktime !== "0" && Parktime !== undefined) {
												var newParkTime = Parktime.slice(4, 6) + "/" + Parktime.slice(6, 8) + "/" + Parktime.slice(0, 4) + " " + Parktime.slice(
													8, 10) + ":" + Parktime.slice(10, 12) + ":" + Parktime.slice(12, 14);
												return newParkTime;
											}
										}
									}
								}
							}
						}, {
							// name: "Reg Num",
							name: this.getOwnerComponent().getModel("i18n").getProperty("regNum"),
							template: {
								content: "{RegNo}"
							}
						}, {
							// name: "Trailer Type",
							name: this.getOwnerComponent().getModel("i18n").getProperty("trailtype"),
							template: {
								content: "{Trailer_type}"
							}
						}, {
							// name: "Check In System",
							name: this.getOwnerComponent().getModel("i18n").getProperty("checkInSys"),
							template: {
								content: "{CheckInSystem}"
							}
						}, {
							// name: "Check Out System",
							name: this.getOwnerComponent().getModel("i18n").getProperty("checkOutSys"),
							template: {
								content: "{CheckOutSystem}"
							}
						}

					]
				});
				/*** add this column only when parentplant is active ***/
				var parentplant = this.getView().getModel("ViewModel").getProperty("/ParentPlant");
				var sGetRegion = this.getView().getModel("regionModel").getProperty("/region");
				
				if (parentplant !== "") {
					oExport.insertColumn(new sap.ui.core.util.ExportColumn({
						name: this.getOwnerComponent().getModel("i18n").getProperty("Plant"),
						template: {
							content: "{Werks}"
						}
					}), 0);
				if (sGetRegion === "US") {
						oExport.insertColumn(new sap.ui.core.util.ExportColumn({
							name: this.getOwnerComponent().getModel("i18n").getProperty("checkInTyp"),
							template: {
								content: "{CheckInType}"
							}
						}), 18);
					}
				} else {
					if (sGetRegion === "US") {
						oExport.insertColumn(new sap.ui.core.util.ExportColumn({
							name: this.getOwnerComponent().getModel("i18n").getProperty("checkInTyp"),
							template: {
								content: "{CheckInType}"
							}
						}), 17);
					}
				}

				var sdwellReport = this.getOwnerComponent().getModel("i18n").getProperty("dwellReport");
				oExport.saveFile(sdwellReport).catch(function(oError) {
					// MessageBox.error("Error when downloading data. Browser might not be supported!\n\n" + oError);
				}).then(function() {
					oExport.destroy();
				});
			}

		});
	});