var sInsLoggedUser;
var sUserFullName;
var sInsPlantId;
var sInsUrl;
var sInsUserId;
var sInsHeadPlantId;
var sPlantReport;
var sInsCdateId;
var sInsResult;
var oInsCreateDailog;
var sPanel;
var aPlantitems;
var plantids = [];
var sInsDateFormat;

sap.ui.define([
	"sap/ui/core/mvc/Controller",
	"sap/ui/model/json/JSONModel",
	"sap/m/MessageBox",
	"sap/m/MessageToast"
], function(Controller,
	JSONModel,
	MessageBox,
	MessageToast) {
	"use strict";
	return Controller.extend("com.report.controller.ReportInter", {
		onInit: function() {

			jQuery.sap.require("jquery.sap.storage");
			//-----------------------------------------------------------------------------------------------------------------------------------------------	
			// Get user information by calling the below service.
			//-----------------------------------------------------------------------------------------------------------------------------------------------
			var that = this;
			// BusyIndicator for navigation between pages.
			var busyTitle = that.getOwnerComponent().getModel("i18n").getProperty('pleaseWait');

			that.getOwnerComponent().BusyDialogGlobal = new sap.m.BusyDialog({
				title: busyTitle,
				showCancelButton: true
			}).addStyleClass("sapUiSizeCompact");
			that.fnCreateBusyDialog("pallet.svg");
			var sStartup = "/sap/bc/ui2/start_up";
			var xmlHttp = null;
			xmlHttp = new XMLHttpRequest();
			xmlHttp.onreadystatechange = function() {
				if (xmlHttp.readyState === 4 && xmlHttp.status === 200) {
					var oUserData = JSON.parse(xmlHttp.responseText);
					sInsLoggedUser = oUserData.id;
					sUserFullName = oUserData.fullName;

					sInsDateFormat = oUserData.dateFormat;
					// if (sInsDateFormat !== "" || sInsDateFormat !== " ") {
					// 	// that.pullTimeDateFormat();
					// 	// that.fnSetUserDateFormat(sInsDateFormat);
					// }
					jQuery.sap.storage(jQuery.sap.storage.Type.local).put("collectDate", sInsDateFormat);

					that.fnGetHeaderDetails(sInsLoggedUser);
				}
			};
			xmlHttp.open("GET", sStartup, false);
			xmlHttp.send(null);
			//----------------------------------------------------------------------------------
			//To get Header Bar for Desktop and Tablet
			//----------------------------------------------------------------------------------
			var oDesktopDevice = sap.ui.Device.system.desktop;
			if (oDesktopDevice === true) {
				//Desktop Title Bar
				var oTitleBar = sap.ui.xmlfragment(this.createId("Header_Desktop_Bar_ID"), "com.report.fragments.DesktopHeader", this);
				this.getView().addDependent(oTitleBar);
				that.byId("Header_Desktop_Bar_ID--Settings").setVisible(false);
				this.getView().byId("mainPage").addContent(oTitleBar);
				sInsUserId = "Header_Desktop_Bar_ID--userName";
				sInsHeadPlantId = "Header_Desktop_Bar_ID--plantName";
				sInsCdateId = "Header_Desktop_Bar_ID--cDate";

			} else {
				//Mobile Title Bar
				var oTitleMobBar = sap.ui.xmlfragment(this.createId("Header_Mobile_Bar_ID"), "com.report.fragments.MobileHeader", this);
				this.getView().addDependent(oTitleMobBar);
				that.byId("Header_Mobile_Bar_ID--Settings").setVisible(false);
				this.getView().byId("mainPage").addContent(oTitleMobBar);
				sInsUserId = "Header_Mobile_Bar_ID--userName1";
				sInsHeadPlantId = "Header_Mobile_Bar_ID--plantName1";
				sInsCdateId = "Header_Mobile_Bar_ID--cDate1";
			}
			//----------------------------------------------------------------------------------
			//Report selection screen
			//----------------------------------------------------------------------------------
			var ReportView = new sap.m.HBox({
				items: [
					new sap.m.VBox({
						items: [
							new sap.m.Label(this.createId("ReportName"), {
								text: "{i18n>report}",
								design: "Bold"
							}).addStyleClass("sapUiTinyMarginBegin sapUiTinyMarginBottom sapUiTinyMarginTop"),
							new sap.m.Label(this.createId("plant"), {
								text: "{i18n>plant}",
								design: "Bold",
								visible: false
							}).addStyleClass("sapUiTinyMarginBegin sapUiTinyMarginBottom labelMargin"),
							new sap.m.Label(this.createId("Date"), {
								text: "{i18n>startDate}",
								design: "Bold",
								visible: false
							}).addStyleClass("sapUiTinyMarginBegin sapUiTinyMarginBottom labelMargin"),
							new sap.m.Label(this.createId("startTime"), {
								text: "{i18n>starTime}",
								design: "Bold",
								visible: false
							}).addStyleClass("sapUiTinyMarginBegin sapUiTinyMarginBottom labelMargin"),

							new sap.m.Label(this.createId("DelvFRom"), {
								text: "{i18n>DelvFRom}",
								design: "Bold",
								visible: false
							}).addStyleClass("sapUiTinyMarginBegin sapUiTinyMarginBottom labelMargin"),
							new sap.m.Label(this.createId("DelvNumber"), {
								text: "{i18n>delNum}",
								design: "Bold",
								visible: false
							}).addStyleClass("sapUiTinyMarginBegin sapUiTinyMarginBottom labelMargin"),
							new sap.m.Label(this.createId("cust"), {
								text: "Customer Number",
								design: "Bold",
								visible: false
							}).addStyleClass("sapUiTinyMarginBegin sapUiTinyMarginBottom labelMargin")
						]
					}).addStyleClass("sapUiTinyMarginTop"),

					new sap.m.VBox({
						items: [
							new sap.m.Select(this.createId("onRepSelect"), {
								change: function() {
									that.onSelectionChange();
								}
							}).addStyleClass("sapUiTinyMarginBegin"),
							new sap.m.HBox({
								items: [
									new sap.m.Input(this.createId("mPlant"), {
										showValueHelp: true,
										visible: false,
										valueHelpRequest: function() {
											that.onPlant();
										}
									}).addStyleClass("sapUiTinyMarginBegin")
								]
							}),
							new sap.m.HBox({
								items: [
									new sap.m.DatePicker(this.createId("DataFrom"), {
										visible: false,
										dateValue: "{InputsModel>/FromDate}",
										displayFormat: "long",
										valueFormat: "yyyy-MM-dd",
										placeholder: "{i18n>startDate}",
										change: function() {
											that.onDateFrom();
										}
										//           width: "8rem"
									}).addStyleClass("sapUiTinyMarginBegin"),
									new sap.m.Label(this.createId("toLabel"), {
										visible: false,
										text: "{i18n>endDate}",
										design: "Bold"
									}).addStyleClass("sapUiTinyMarginTop sapUiSmallMarginBegin"),
									new sap.m.DatePicker(this.createId("DataTo"), {
										visible: false,
										dateValue: "{InputsModel>/ToDate}",
										displayFormat: "long",
										placeholder: "{i18n>endDate}",
										valueFormat: "yyyy-MM-dd",
										change: function() {
											that.onDateTo();
										}
										//		width: "8rem"
									}).addStyleClass("sapUiTinyMarginBegin")
								]
							}),
							// new sap.m.Label(this.createId("SETime"), {
							// 	visible: false
							// }).addStyleClass("sapUiTinyMarginBegin"),

							new sap.m.HBox({
								items: [
									// new sap.m.Input(this.createId("sTime"), {
									// 	visible: false
									// }).addStyleClass("sapUiTinyMarginBegin"),

									new sap.m.TimePicker(this.createId("sTime"), {
										visible: false,
										value: "{InputsModel>/StartTime}",
										valueFormat: "HH:mm:ss",
										displayFormat: "HH:mm:ss",
										support2400: true
									}).addStyleClass("sapUiTinyMarginBegin"),

									new sap.m.Label(this.createId("EndTime"), {
										visible: false,
										text: "{i18n>compTime}",
										design: "Bold"
									}).addStyleClass("sapUiSmallMarginBegin sapUiTinyMarginTop"),
									new sap.m.TimePicker(this.createId("eTime"), {
										visible: false,
										value: "{InputsModel>/EndTime}",
										valueFormat: "HH:mm:ss",
										displayFormat: "HH:mm:ss",
										support2400: true
									}).addStyleClass("sapUiTinyMarginBegin")
									// new sap.m.Input(this.createId("eTime"), {
									// 	visible: false
									// }).addStyleClass("sapUiTinyMarginBegin")
								]
							}),
							new sap.m.HBox({
								items: [
									// new sap.m.Input(this.createId("sTime"), {
									// 	visible: false
									// }).addStyleClass("sapUiTinyMarginBegin"),

									new sap.m.Input(this.createId("DeliveryFrom"), {
										visible: false,
										value: "",
										width: "13.5rem",
										enabled: true,
										liveChange: function() {
											that.onDeleveryFrom();
										}
									}).addStyleClass("sapUiTinyMarginBegin"),

									new sap.m.Label(this.createId("delvTo"), {
										visible: false,
										text: "{i18n>delvTo}",
										design: "Bold",
										width: "3.4rem"
									}).addStyleClass("sapUiTinyMarginTop sapUiSmallMarginBegin"),
									new sap.m.Input(this.createId("DeliveryTo"), {
										visible: false,
										value: "",
										width: "13.5rem",
										enabled: true,
										liveChange: function() {
											that.onDeleveryFrom();
										}
									}).addStyleClass("sapUiTinyMarginBegin")
									// new sap.m.Input(this.createId("eTime"), {
									// 	visible: false
									// }).addStyleClass("sapUiTinyMarginBegin")
								]
							}),
							new sap.m.Input(this.createId("DeliveryNum"), {
								visible: false,
								maxLength: 10,
								width: "13.5rem",
								type: "Number",
								enabled: true,
								liveChange: function(oEvent) {
									that.ondelnumberEntered(oEvent);
								}
							}).addStyleClass("sapUiTinyMarginBegin"),
							new sap.m.Input(this.createId("CustNum"), {
								visible: false,
								maxLength: 10,
								width: "13.5rem",
								type: "Number"
							}).addStyleClass("sapUiTinyMarginBegin")
						]
					}).addStyleClass("sapUiTinyMarginTop")
				]
			}).addStyleClass("sapUiTinyMarginTop borderStyle");
			this.byId("mainPage").addContent(ReportView);
			//----------------------------------------------------------------------------------
			//To get select data
			//----------------------------------------------------------------------------------

			var sSelRep = that.getOwnerComponent().getModel("i18n").getProperty('selRep');
			var sFdeUsage = that.getOwnerComponent().getModel("i18n").getProperty('fdeUsage');
			var sFdeReport = that.getOwnerComponent().getModel("i18n").getProperty('fdeReport');
			var sDwelTime = that.getOwnerComponent().getModel("i18n").getProperty('dwelTime');
			var sYardHos = that.getOwnerComponent().getModel("i18n").getProperty('yardHos');
			var sDelStatRep = that.getOwnerComponent().getModel("i18n").getProperty('delStatRep');
			var sRejecRep = that.getOwnerComponent().getModel("i18n").getProperty('rejecRep');
			var sIdocStatusTitle = that.getOwnerComponent().getModel("i18n").getProperty('IdocStatusTitle');
			var sProPlaDis = that.getOwnerComponent().getModel("i18n").getProperty('proPlcDes');
			var sEwtReport = that.getOwnerComponent().getModel("i18n").getProperty('EwtReport');
			var sYardStopReport = that.getOwnerComponent().getModel("i18n").getProperty('yardStopReport');
			var sDHDwellTymReport = that.getOwnerComponent().getModel("i18n").getProperty('DHDwellTymReport');

			var reportNames = [{
				"report": sSelRep,
				"key": "Select a report"
			}, {
				"report": sFdeUsage,
				"key": "FDE Usage"
			}, {
				"report": sFdeReport,
				"key": "FDE REPORT"
			}, {
				"report": sDwelTime,
				"key": "DWELL TIME"
			}, {
				"report": sYardHos,
				"key": "YARD HOSTLER"
			}, {
				"report": sDelStatRep,
				"key": "DELIVERY STATUS REPORT"
			}, {
				"report": sRejecRep,
				"key": "REJECTION REPORT"
			}, {
				"report": sIdocStatusTitle,
				"key": "IDOC STATUS LOG"
			}, {
				"report": sProPlaDis,
				"key": "PRODUCT PLACEMENT DISCREPANCIES"
			}, {
				"report": sEwtReport,
				"key": "EWT Report"
			}, {
				"report": sYardStopReport,
				"key": "YARD STOP REPORT"
			}, {
				"report": sDHDwellTymReport,
				"key": "DH Dwell Time Report"
			}];

			var oTemplate11 = new sap.ui.core.ListItem({
				text: "{reportno>report}",
				key: "{reportno>key}"
			});
			// var dataForm = $.sap.getModulePath("com.report", "/model/");
			// var json = new sap.ui.model.json.JSONModel((dataForm + "report.json"));
			var selecRepJsonMdoel = new sap.ui.model.json.JSONModel();
			selecRepJsonMdoel.setData(reportNames);
			// that.getView().setModel(selecRepJsonMdoel, "selRepMdoel");
			var oSelectReport = this.byId("onRepSelect");
			oSelectReport.setModel(selecRepJsonMdoel, "reportno");
			oSelectReport.bindItems("reportno>/", oTemplate11);

			//----------------------------------------------------------------------------------
			//To get the clock
			//----------------------------------------------------------------------------------
			/*setInterval(function() {
				// sInsResult = sap.ui.controller("com.report.controller.ReportInter").fnGetClock();
				var realClock = that.realDateTimeClock();
				if (that.byId(sInsCdateId) !== undefined) {
					that.byId(sInsCdateId).setText(realClock);
				}
			}, 1000);*/
			//----------------------------------------------------------------------------------
			//To disable manual inputs for datepickers.
			//----------------------------------------------------------------------------------
			that.byId("DataFrom").attachBrowserEvent("keydown",
				function(event) {
					event.preventDefault();
					//					if(event.keyCode === 8){
					that.byId("DataFrom").setValue("");
					//					}
					return false;
				});
			that.byId("DataTo").attachBrowserEvent("keydown",
				function(event) {
					event.preventDefault();
					//					if(event.keyCode === 8){
					that.byId("DataTo").setValue("");
					//					}
					return false;
				});

			that.byId("mPlant").attachBrowserEvent("keydown",
				function(event) {
					event.preventDefault();
					that.byId("mPlant").setValue("");
					aPlantitems = [];
					return false;
				});
			//----------------------------------------------------------------------------------
			//To set default dates in datepickers.
			//----------------------------------------------------------------------------------
			// that.byId("DataTo").setDateValue(new Date());
			// var date = new Date();
			// var firstDay = new Date(date.getFullYear(), date.getMonth(), 1);
			// that.byId("DataFrom").setDateValue(new Date(firstDay));

			var sInputObj = {
				"FromDate ": "",
				"StartTime ": "",
				"ToDate ": "",
				"EndTime ": ""
			};
			var oModel = new sap.ui.model.json.JSONModel();
			oModel.setData(sInputObj);
			that.getView().setModel(oModel, "InputsModel");
			// that.getView().getModel("InputsModel").setProperty("/Plant");
			// that.getView().getModel("InputsModel").setProperty("/StartTime", "000000");
			var date = new Date();
			var firstDay = new Date(date.getFullYear(), date.getMonth(), 1);
			that.getView().getModel("InputsModel").setProperty("/FromDate", new Date(firstDay));
			that.getView().getModel("InputsModel").setProperty("/ToDate", new Date());
			// that.byId("DataTo").setDateValue(new Date());
			// that.byId("DataFrom").setDateValue(new Date(firstDay));

			that.getView().getModel("InputsModel").setProperty("/StartTime", "00:00:00");
			that.getView().getModel("InputsModel").setProperty("/EndTime", "23:59:59");
		},

		realDateTimeClockBrowser: function() {
			var dateObject = new Date();
			var dateFormat = sap.ui.core.format.DateFormat.getDateInstance({
				style: 'full',
				pattern: "EEEE, MMMM dd, YYYY hh:mm:ss a"
			});
			// Format the date
			var dateFormatted = dateFormat.format(dateObject);
			return dateFormatted;
		},

		realDateTimeClock: function(TimeZone, DayLightSaving) {
			var that = this;

			/*	var sData = that.getView().getModel("HeaderDetailsPlant").getData();
			var TimeZone = sData.UTC_DIFF;
			var DayLightSaving = sData.DST_DIFF;*/

			var timeZoneOutput = [TimeZone.slice(0, 3), ":", TimeZone.slice(3, 5)].join('');

			if (DayLightSaving === "") {
				DayLightSaving = "0";
			}

			// var DayLightSavingOutput = [DayLightSaving.slice(0, 2), ":", DayLightSaving.slice(2, 4)].join('');

			if (timeZoneOutput.startsWith("-")) {
				var concatTimeZoneDayLight = parseInt(TimeZone.slice(1, 3)) - parseInt(DayLightSaving.slice(0, 2));
			} else if (timeZoneOutput.startsWith("+")) {
				var concatTimeZoneDayLight = parseInt(TimeZone.slice(1, 3)) + parseInt(DayLightSaving.slice(0, 2));
			}

			var finalOffset = [TimeZone.slice(0, 1), concatTimeZoneDayLight, ":", TimeZone.slice(3, 5)].join('');

			var _now = new Date();

			//var timeZoneOutput = "+11:00";
			var date = that.timezoneShifter(_now, finalOffset);

			var resultDate = that.formatTimeClock(date);
			return resultDate;
		},

		timezoneShifter: function(date, timezone) {

			var isBehindGTM = false;
			if (timezone.startsWith("-")) {
				timezone = timezone.substr(1);
				isBehindGTM = true;
			}

			var hDiff = timezone.split(":").map(myFunction);

			function myFunction(t) {
				return parseInt(t);
			}

			var value = isBehindGTM ? 1 : -1;
			var diff = (hDiff[0] * 60 + hDiff[1]) * value;
			var currentDiff = new Date().getTimezoneOffset();

			return new Date(date.valueOf() + (currentDiff - diff) * 60 * 1000);
		},

		formatTimeClock: function(_now) {
			var dateObject = _now;
			var dateFormat = sap.ui.core.format.DateFormat.getDateInstance({
				style: 'full',
				pattern: "EEEE, MMMM dd, YYYY hh:mm:ss a"
			});
			// Format the date
			var dateFormatted = dateFormat.format(dateObject);
			return dateFormatted;
		},

		//----------------------------------------------------------------------------------
		//Function to get Header details
		//----------------------------------------------------------------------------------
		fnGetHeaderDetails: function(sInsLoggedUser) {
			var that = this;
			//	that.fnCreateBusyDialog("pallet.svg");
			sInsUrl = "/sap/opu/odata/sap/ZGW_ACTIVITY_SRV";
			var oHeaderModel = new sap.ui.model.odata.ODataModel(sInsUrl);
			oHeaderModel.read("/HeaderDetailsSet('" + sInsLoggedUser + "') ", null, null,
				true,
				function(oData, oResponse) {
					if (oResponse.statusCode === 200) {
						var oODataJSONModel2 = new sap.ui.model.json.JSONModel();
						oODataJSONModel2.setData(oData);
						oODataJSONModel2.setSizeLimit(oData.length);
						// if (that.byId(sInsUserId) !== undefined) {
						// 	that.byId(sInsUserId).setText(oData.Firstname + " " + oData.Lastname); // Binding the user name
						// }
						if (that.byId(sInsUserId) !== undefined) {
							that.byId(sInsUserId).setText(sUserFullName); // Binding the user name
						}
						if (that.byId(sInsHeadPlantId) !== undefined) {
							if (oData.ParentPlant) {
								that.byId(sInsHeadPlantId).setText(oData.Name1); // Binding the multi-plant name/city	
							} else {
								that.byId(sInsHeadPlantId).setText(oData.Plant + "-" + oData.Name1); // Binding the plant name
							}
						}
						/*** passing parent plant -- to display time and date ***/
						if (oData.ParentPlant) {
							sInsPlantId = oData.ParentPlant;
						} else {
							sInsPlantId = oData.Plant;
						}
						jQuery.sap.storage(jQuery.sap.storage.Type.local).put("ParentPlant", oData.ParentPlant);

						jQuery.sap.storage(jQuery.sap.storage.Type.local).put("region", oData.Region);
						/*Serivce Call for getting Timezone From Plant*/

						var oGlobalBusyDialog = new sap.m.BusyDialog();
						oGlobalBusyDialog.open();

						var headerPlantModel = that.getOwnerComponent().getModel("TimeZoneModel");
						headerPlantModel.read("/HeaderDetailsSet(Plant='" + sInsPlantId + "')", {
							success: function(oDataTime, responseTime) {
								if (responseTime.statusCode === 200) {

									var TimeZone = oDataTime.UTC_DIFF;
									var DayLightSaving = oDataTime.DST_DIFF;
									var PullTimeFalg = oDataTime.Pull_time_active;

									jQuery.sap.storage(jQuery.sap.storage.Type.local).put("sTimeZone", TimeZone);
									jQuery.sap.storage(jQuery.sap.storage.Type.local).put("sDayLightSaving", DayLightSaving);
									jQuery.sap.storage(jQuery.sap.storage.Type.local).put("sFlag", PullTimeFalg);

									//----------------Setting the clock and date-----------------------//

									setInterval(function() {
										var oTimeZone = jQuery.sap.storage(jQuery.sap.storage.Type.local).get("sTimeZone");
										var oDayLightSaving = jQuery.sap.storage(jQuery.sap.storage.Type.local).get("sDayLightSaving");
										var oFlag = jQuery.sap.storage(jQuery.sap.storage.Type.local).get("sFlag");
										// var oFlag = true;

										if (oFlag === false || oFlag === "false" || oFlag === null || oFlag === undefined) {
											var resultBrowser = that.realDateTimeClockBrowser();

											if (that.byId(sInsCdateId) !== undefined) {
												that.byId(sInsCdateId).setText(resultBrowser);
											}

										} else if (oFlag === true || oFlag === "true") {

											var realClock = that.realDateTimeClock(oTimeZone, oDayLightSaving);
											if (that.byId(sInsCdateId) !== undefined) {
												that.byId(sInsCdateId).setText(realClock);
											}
										}

									}, 1000);

								}
								oGlobalBusyDialog.close();
							},
							error: function() {
								oGlobalBusyDialog.close();
							}
						});

					}
					oInsCreateDailog.close();
				},
				function() {
					oInsCreateDailog.close();
				});
		},
		//--------------------------------------------------------------------
		//Function for Date validations
		//--------------------------------------------------------------------
		onDateTo: function() {
			var oReportSelcted = this.byId("onRepSelect").getSelectedKey();
			var dateFrom = this.byId("DataFrom").getValue();
			var dateTo = this.byId("DataTo").getValue();
			var date1 = new Date(dateFrom);
			var date2 = new Date(dateTo);
			if (oReportSelcted === "EWT Report") {
				var sDate = new Date();
				if (date2 > sDate) {
					this.byId("DataTo").setValue("");
					var oMessageEwt = this.getOwnerComponent().getModel("i18n").getProperty('futureDate');
					var dateToErrorTitleEwt = this.getOwnerComponent().getModel("i18n").getProperty('errorDuringSubmit');
					MessageBox.show(
						oMessageEwt, {
							icon: sap.m.MessageBox.Icon.ERROR,
							title: dateToErrorTitleEwt
						});
				}
			} else if (date1 > date2) {
				// var oMessage = "Please select appropriate date";
				var oMessage = this.getOwnerComponent().getModel("i18n").getProperty('slctApprtDate');
				var dateToErrorTitle = this.getOwnerComponent().getModel("i18n").getProperty('errorDuringSubmit');
				MessageBox.show(
					oMessage, {
						icon: sap.m.MessageBox.Icon.ERROR,
						title: dateToErrorTitle
					});
				this.byId("DataTo").setValue("");
			}

		},
		//--------------------------------------------------------------------
		//Function for Date validations
		//--------------------------------------------------------------------
		onDateFrom: function() {
			var dateFrom = this.byId("DataFrom").getValue();
			var dateTo = this.byId("DataTo").getValue();
			var date1 = new Date(dateFrom);
			var date2 = new Date(dateTo);
			if (date2 < date1) {
				var oMessage = this.getOwnerComponent().getModel("i18n").getProperty('slctApprtDate');
				var dateFromErrorTitle = this.getOwnerComponent().getModel("i18n").getProperty('errorDuringSubmit');
				MessageBox.show(
					oMessage, {
						icon: sap.m.MessageBox.Icon.ERROR,
						title: dateFromErrorTitle
					});
				this.byId("DataFrom").setValue("");
			}
		},

		//--------------------------------------------------------------------
		//Function for selecting the plant
		//--------------------------------------------------------------------
		onPlant: function() {
			var that = this;
			that.fnCreateBusyDialog("pallet.svg");
			this._getDialog().open();
			var oTable = sap.ui.getCore().byId("plantName");
			var oRepSelect = this.byId("onRepSelect").getSelectedKey();
			if (oRepSelect === "FDE Usage") {
				oTable.setMode("MultiSelect");
			} else if (oRepSelect === "FDE REPORT" || oRepSelect === "DWELL TIME" || oRepSelect === "YARD HOSTLER" || oRepSelect ===
				"DELIVERY STATUS REPORT" || oRepSelect === "REJECTION REPORT" || oRepSelect === "IDOC STATUS LOG" || oRepSelect ===
				"PRODUCT PLACEMENT DISCREPANCIES" || oRepSelect === "YARD STOP REPORT" || oRepSelect === "DH Dwell Time Report") {
				oTable.setMode("SingleSelectLeft");
			} else {
				oTable.setMode("MultiSelect");
			}

			var sRepUrl = "/sap/opu/odata/sap/ZGW_CHANGE_PLANT_SRV";
			var oPlantsModel = new sap.ui.model.odata.ODataModel(sRepUrl);
			oPlantsModel.read("/PlantsSet?$filter=User eq '" + sInsLoggedUser + "'", null, null, false,
				function(oData, oResponse) {
					if (oResponse.statusCode === 200) {
						oInsCreateDailog.close();
						var json = new sap.ui.model.json.JSONModel(oData.results);
						json.setSizeLimit(oData.results.length);
						//	sap.ui.getCore().setModel(json, "plantName");
						oTable.setModel(json, "plantn");
					} else {
						oInsCreateDailog.close();
					}
				},
				function() {
					oInsCreateDailog.close();
				});
		},
		//--------------------------------------------------------------------
		//Function to display selected plant(s) in plants dialog
		//--------------------------------------------------------------------
		onFinished: function(oEvent) {
			var oList = oEvent.getSource();
			var oItem = oList.getItems();
			var oRepSelect = this.byId("onRepSelect").getSelectedKey();
			for (var i = 0; i < oItem.length; i++) {
				var defaultXObj = oItem[i].getAggregation("cells")[0].getProperty("text");
				if ((aPlantitems !== undefined) && (aPlantitems.length > 0)) {
					for (var j = 0; j < aPlantitems.length; j++) {
						if (aPlantitems[j] === defaultXObj) {
							oList.setSelectedItem(oItem[i]);
						}
					}
				}
			}
		},

		//-----------------------------------------------------------------------
		// Function to display selected plants in the dropdown
		//-----------------------------------------------------------------------
		onAccept: function() {
			var oTable = sap.ui.getCore().byId("plantName");
			aPlantitems = [];
			jQuery.each(oTable.getSelectedContextPaths(), function(id, value) {
				var modelData = oTable.getModel("plantn");
				var data = modelData.getProperty(value);
				//	aPlantitems.push(data.plant);
				aPlantitems.push(data.Plant);
			});
			var iValue = this.byId("mPlant");
			iValue.setValue(aPlantitems);
			sap.ui.getCore().byId("searchFiledId").setValue(null);
			this._getDialog().close();
		},

		onCancel: function(oEvent) {
			sap.ui.getCore().byId("searchFiledId").setValue(null);
			this._getDialog().close();
		},

		//----------------------------------------------------------------------
		// Function for opening or closing the plant fragment
		//----------------------------------------------------------------------
		_getDialog: function() {
			var oView = this.getView();
			if (!this.dialog) {
				this.dialog = sap.ui.xmlfragment("com.report.fragments.popup", this);
				oView.addDependent(this.dialog);
			}
			return this.dialog;
		},

		//---------------------------------------------------------------------------
		//Function for Submitting the selected data
		//---------------------------------------------------------------------------
		onPressSubmit: function(oEvent) {
			var that = this;
			var aSelectedReport = this.byId("onRepSelect").getSelectedKey();
			var aPlantInput = this.byId("mPlant").getValue();
			var aFromDate = this.byId("DataFrom").getValue();
			var aToDate = this.byId("DataTo").getValue();
			var aStartTime = this.byId("sTime").getValue();
			var aEndTime = this.byId("eTime").getValue();

			var aDates = [];
			var dateRange;
			if (aToDate !== "") {
				aDates = [aFromDate, aToDate];
				dateRange = aDates.join(",");
			} else {
				aDates = [aFromDate, aFromDate];
				dateRange = aDates.join(",");
			}

			if (aSelectedReport === "FDE Usage") {
				if (aPlantInput !== "") {
					if (((aFromDate !== "") && (aToDate !== "")) || ((aFromDate !== "") && (aToDate === ""))) {
						that.fnCreateBusyDialog("pallet.svg");
						// var dDateForm = aFromDate.slice(6, 10) + aFromDate.slice(0, 2) + aFromDate.slice(3, 5);
						// var dDateTo = aToDate.slice(6, 10) + aToDate.slice(0, 2) + aToDate.slice(3, 5);
						// MM-dd-yyyy   20181204   yyyy-MM-dd
						var dDateForm = aFromDate.slice(0, 4) + aFromDate.slice(5, 7) + aFromDate.slice(8, 10);
						var dDateTo = aToDate.slice(0, 4) + aToDate.slice(5, 7) + aToDate.slice(8, 10);
						var sInpDates;
						if (dDateTo !== "") {
							sInpDates = dDateForm + "," + dDateTo;
						} else {
							sInpDates = dDateForm + "," + dDateForm;
						}

						var sService = "/sap/opu/odata/sap/ZGW_REPORTS_SRV/";
						var oModel = new sap.ui.model.odata.ODataModel(sService);
						oModel.read("/UsageReportSet?$filter=Plants eq '" + aPlantInput + "' and Dates eq '" + sInpDates + "'", null, null,
							false,
							function(oData, oResponse) {
								if (oResponse.statusCode === 200) {
									if (oData.results.length > 0) {
										oInsCreateDailog.close();
										var oRouter = sap.ui.core.UIComponent.getRouterFor(that);
										oRouter.navTo("PlantDetails", {
											reportname: aSelectedReport,
											Plants: aPlantInput,
											DateRange: dateRange //sInpDates
										});
									} else {
										oInsCreateDailog.close();
										var oMessage = that.getOwnerComponent().getModel("i18n").getProperty('noInputDataError');
										var fdeUsageError = that.getOwnerComponent().getModel("i18n").getProperty('errorDuringFetch');
										MessageBox.show(
											oMessage, {
												icon: sap.m.MessageBox.Icon.ERROR,
												title: fdeUsageError
											});
									}
								} else {
									oInsCreateDailog.close();
									var oMessage = that.getOwnerComponent().getModel("i18n").getProperty('noInputDataError');
									var fdeUsageError = that.getOwnerComponent().getModel("i18n").getProperty('errorDuringFetch');
									MessageBox.show(
										oMessage, {
											icon: sap.m.MessageBox.Icon.ERROR,
											title: fdeUsageError
										});
								}
							},
							function() {
								oInsCreateDailog.close();
							});
					} else {
						var aMessage = that.getOwnerComponent().getModel("i18n").getProperty('startEndDateRange');
						var fdeUsageSubmitError = that.getOwnerComponent().getModel("i18n").getProperty('errorDuringSubmit');
						MessageBox.show(
							aMessage, {
								icon: sap.m.MessageBox.Icon.ERROR,
								title: fdeUsageSubmitError
							});
					}
				} else {
					var oMessage = that.getOwnerComponent().getModel("i18n").getProperty('slctPlant');
					var fdeUsageSubmitError = that.getOwnerComponent().getModel("i18n").getProperty('errorDuringSubmit');
					MessageBox.show(
						oMessage, {
							icon: sap.m.MessageBox.Icon.ERROR,
							title: fdeUsageSubmitError
						});
				}
			} else if (aSelectedReport === "FDE REPORT" || aSelectedReport === "DWELL TIME" || aSelectedReport === "YARD HOSTLER" ||
				aSelectedReport === "DELIVERY STATUS REPORT" || aSelectedReport === "REJECTION REPORT" || aSelectedReport === "IDOC STATUS LOG" ||
				aSelectedReport === "PRODUCT PLACEMENT DISCREPANCIES" || aSelectedReport === "EWT Report" || aSelectedReport ===
				"YARD STOP REPORT" || aSelectedReport === "DH Dwell Time Report") {
				if (aPlantInput === "" && aSelectedReport !== "EWT Report") {
					var oMessage = that.getOwnerComponent().getModel("i18n").getProperty('slctPlant');
					var fdeUsageSubmitError = that.getOwnerComponent().getModel("i18n").getProperty('errorDuringSubmit');
					MessageBox.show(
						oMessage, {
							icon: sap.m.MessageBox.Icon.ERROR,
							title: fdeUsageSubmitError
						});
				} else if ((((aFromDate === "") && (aToDate === "")) || ((aFromDate === "") && (aToDate !== ""))) && aSelectedReport !==
					"EWT Report") {
					var aMessage = that.getOwnerComponent().getModel("i18n").getProperty('startEndDateRange');
					var submitError = that.getOwnerComponent().getModel("i18n").getProperty('errorDuringSubmit');
					MessageBox.show(
						aMessage, {
							icon: sap.m.MessageBox.Icon.ERROR,
							title: submitError
						});
				} else if (aStartTime === "" && aSelectedReport !== "EWT Report") {
					var oMessage = that.getOwnerComponent().getModel("i18n").getProperty('startTime');
					var startTimeError = that.getOwnerComponent().getModel("i18n").getProperty('errorDuringSubmit');
					MessageBox.show(
						oMessage, {
							icon: sap.m.MessageBox.Icon.ERROR,
							title: startTimeError
						});
				} else if (aEndTime === "" && aSelectedReport !== "EWT Report") {
					var oMessage = that.getOwnerComponent().getModel("i18n").getProperty('endTime');
					var endTimeError = that.getOwnerComponent().getModel("i18n").getProperty('errorDuringSubmit');
					MessageBox.show(
						oMessage, {
							icon: sap.m.MessageBox.Icon.ERROR,
							title: endTimeError
						});
				} else if (aSelectedReport === "FDE REPORT") {
					that.getOwnerComponent().BusyDialogGlobal.open();
					var oRouter = sap.ui.core.UIComponent.getRouterFor(that);
					oRouter.navTo("ReportUsage", {
						reportname: aSelectedReport,
						Plants: aPlantInput,
						DateRange: dateRange, //sInpDates
						StartTime: aStartTime,
						EndTime: aEndTime
					});
				} else if (aSelectedReport === "DWELL TIME") {
					var oRouter = sap.ui.core.UIComponent.getRouterFor(that);
					oRouter.navTo("DwellTime", {
						reportname: aSelectedReport,
						Plants: aPlantInput,
						DateRange: dateRange, //sInpDates
						StartTime: aStartTime,
						EndTime: aEndTime
					});
				} else if (aSelectedReport === "YARD HOSTLER") {
					var oRouter = sap.ui.core.UIComponent.getRouterFor(that);
					oRouter.navTo("YardHostler", {
						reportname: aSelectedReport,
						Plants: aPlantInput,
						DateRange: dateRange, //sInpDates
						StartTime: aStartTime,
						EndTime: aEndTime
					});
				} else if (aSelectedReport === "DELIVERY STATUS REPORT") {
					var oRouter = sap.ui.core.UIComponent.getRouterFor(that);
					oRouter.navTo("DelStatusReport", {
						reportname: aSelectedReport,
						Plants: aPlantInput,
						DateRange: dateRange, //sInpDates
						StartTime: aStartTime,
						EndTime: aEndTime
					});
				} else if (aSelectedReport === "REJECTION REPORT") {
					var oRouter = sap.ui.core.UIComponent.getRouterFor(that);
					oRouter.navTo("RejectionReport", {
						reportname: aSelectedReport,
						Plants: aPlantInput,
						DateRange: dateRange, //sInpDates
						StartTime: aStartTime,
						EndTime: aEndTime
					});
				} else if (aSelectedReport === "IDOC STATUS LOG") {
					var oRouter = sap.ui.core.UIComponent.getRouterFor(that);
					var delivery_num = that.byId("DeliveryNum").getValue();
					var oDelNum;
					if (isNaN(parseInt(delivery_num))) {
						oDelNum = 12345;
					} else {
						oDelNum = parseInt(delivery_num);
					}
					oRouter.navTo("IDocStatus", {
						reportname: aSelectedReport,
						Plants: aPlantInput,
						DateRange: dateRange, //sInpDates
						StartTime: aStartTime,
						EndTime: aEndTime,
						DeliveryNumber: oDelNum
					});
				} else if (aSelectedReport === "PRODUCT PLACEMENT DISCREPANCIES") {
					var oRouter = sap.ui.core.UIComponent.getRouterFor(that);
					var delivery_num = that.byId("DeliveryNum").getValue();
					var oDelNum;
					if (isNaN(parseInt(delivery_num))) {
						oDelNum = 0;
					} else {
						oDelNum = parseInt(delivery_num);
					}
					oRouter.navTo("ProPlacementDescrepancies", {
						reportname: aSelectedReport,
						Plants: aPlantInput,
						DateRange: dateRange, //sInpDates
						DeliveryNumber: oDelNum
					});
				} else if (aSelectedReport === "EWT Report") {
					var Delivery = that.byId("DeliveryNum").getValue();
					var Customer = that.byId("CustNum").getValue();
					var FromDelivery = that.byId("DeliveryFrom").getValue();
					var ToDelivery = that.byId("DeliveryTo").getValue();
					if (aFromDate !== "" || aToDate !== "" || aPlantInput !== "" || Customer !== "" || FromDelivery !== "" || ToDelivery !== "" ||
						Delivery !== "") {
						if (((aFromDate !== "") || (aToDate !== "")) && aPlantInput === "") {
							var aMessagePlant = that.getOwnerComponent().getModel("i18n").getProperty('plantValdation');
							var submitErrorEWT = that.getOwnerComponent().getModel("i18n").getProperty('errorDuringSubmit');
							MessageBox.show(
								aMessagePlant, {
									icon: sap.m.MessageBox.Icon.ERROR,
									title: submitErrorEWT
								});
							return;
						} else if (((aFromDate === "") || (aToDate === "")) && aPlantInput !== "") {
							var aMessagePlantVal = that.getOwnerComponent().getModel("i18n").getProperty('dateValEwt');
							var submitErrorEWT1 = that.getOwnerComponent().getModel("i18n").getProperty('errorDuringSubmit');
							MessageBox.show(
								aMessagePlantVal, {
									icon: sap.m.MessageBox.Icon.ERROR,
									title: submitErrorEWT1
								});
							return;
						}
						// var Delivery = that.byId("DeliveryNum").getValue();
						// var Customer = that.byId("CustNum").getValue();
						// var FromDelivery = that.byId("DeliveryFrom").getValue();
						// var ToDelivery = that.byId("DeliveryTo").getValue();
						var sRegion = jQuery.sap.storage(jQuery.sap.storage.Type.local).get("region");
						var sDateRange = aFromDate.split(",");
						var oStartDate = sDateRange[0];
						var newStrDate = oStartDate.replace(/-/g, "");
						// var oEndDate = sDateRange[1];
						var aToNewDate = aToDate.replace(/-/g, "");

						var oDelNum;
						if (isNaN(parseInt(Delivery))) {
							oDelNum = 0;
						} else {
							oDelNum = parseInt(Delivery);
						}
						var eModel = that.getOwnerComponent().getModel("ewtReportModel");
						var sEwtFilter = [];
						sEwtFilter.push(new sap.ui.model.Filter("Plant", sap.ui.model.FilterOperator.EQ, aPlantInput));
						sEwtFilter.push(new sap.ui.model.Filter("Delivery", sap.ui.model.FilterOperator.EQ, Delivery));
						sEwtFilter.push(new sap.ui.model.Filter("Customer", sap.ui.model.FilterOperator.EQ, Customer));
						sEwtFilter.push(new sap.ui.model.Filter("FromDelivery", sap.ui.model.FilterOperator.EQ, FromDelivery));
						sEwtFilter.push(new sap.ui.model.Filter("ToDelivery", sap.ui.model.FilterOperator.EQ, ToDelivery));
						sEwtFilter.push(new sap.ui.model.Filter("FromDate", sap.ui.model.FilterOperator.EQ, newStrDate));
						sEwtFilter.push(new sap.ui.model.Filter("ToDate", sap.ui.model.FilterOperator.EQ, aToNewDate));
						eModel.read("/EwtSet", {
							filters: sEwtFilter,
							success: function(oData, oResponse) {
								if (oResponse.statusCode === 200 || oResponse.statusCode === "200") {
									var oEwtTableModel = new JSONModel();
									oEwtTableModel.setData(oData.results);

									for (var i = 0; i < oData.results.length; i++) {
										var newdate = oData.results[i].Date;
										var newdate1;
										if (sRegion === "EU") {
											newdate1 = newdate.slice(6, 8) + "/" + newdate.slice(4, 6) + "/" + newdate.slice(0, 4);
											oData.results[i].Date = newdate1;
										} else {

											newdate1 = newdate.slice(0, 4) + "/" + newdate.slice(4, 6) + "/" + newdate.slice(6, 8);
											oData.results[i].Date = newdate1;
										}

										// var dateFormat = sap.ui.core.format.DateFormat.getDateInstance({
										// 	style: 'full',
										// 	pattern: "yyyy/MM/dd"
										// });
										// // Format the date
										// var dateFormatted = dateFormat.format(newdate);
										// oData.results[i].Date=dateFormatted;
									}
									oEwtTableModel.setSizeLimit(oData.results.length);
									that.getOwnerComponent().setModel(oEwtTableModel, "EwtModelData");
									that.getView().getModel("EwtModelData").updateBindings(true);
									var oRouterEWT = sap.ui.core.UIComponent.getRouterFor(that);
									oRouterEWT.navTo("Ewtreport", {
										reportname: aSelectedReport
									});
									// 	oRouterEWT.navTo("Ewtreport", {
									// 	reportname: aSelectedReport,
									//   	Plant: aPlantInput,
									// 	Delivery: Delivery,
									// 	Customer: Customer,
									// 	FromDelivery: FromDelivery,
									// 	ToDelivery: ToDelivery,
									// 	FromDate: newStrDate,
									// 	ToDate: aToNewDate
									// });
								}
								that.fnCreateBusyDialog("pallet.svg", "false");
								oInsCreateDailog.close();
							},
							error: function(oError) {
								that.fnCreateBusyDialog("pallet.svg", "false");
								oInsCreateDailog.close();
								var submitErrorEwt = that.getOwnerComponent().getModel("i18n").getProperty('errorDuringFetch');
								var oMesg = JSON.parse(oError.responseText).error.message.value;
								MessageBox.show(
									oMesg, {
										icon: sap.m.MessageBox.Icon.ERROR,
										title: submitErrorEwt
									});
							}
						});
					} else {
						that.fnCreateBusyDialog("pallet.svg", "false");
						oInsCreateDailog.close();
						var submitErrorEwt = that.getOwnerComponent().getModel("i18n").getProperty('errorDuringFetch');
						var oMesg = that.getOwnerComponent().getModel("i18n").getProperty('inputValidatns');
						MessageBox.show(
							oMesg, {
								icon: sap.m.MessageBox.Icon.ERROR,
								title: submitErrorEwt
							});
					}
				} else if (aSelectedReport === "YARD STOP REPORT") {
					var oRouter = sap.ui.core.UIComponent.getRouterFor(that);
					oRouter.navTo("ParkingReport", {
						reportname: aSelectedReport,
						Plants: aPlantInput,
						DateRange: dateRange, //sInpDates
						StartTime: aStartTime,
						EndTime: aEndTime
					});
				} else if (aSelectedReport === "DH Dwell Time Report") {
					// that.getOwnerComponent().BusyDialogGlobal.open();
					var oRouter = sap.ui.core.UIComponent.getRouterFor(that);
					oRouter.navTo("DHDwellTimeReport", {
						reportname: aSelectedReport,
						Plants: aPlantInput,
						DateRange: dateRange, //sInpDates
						StartTime: aStartTime,
						EndTime: aEndTime
					});
				}
			} else {
				var oMessage = that.getOwnerComponent().getModel("i18n").getProperty('slctReport');
				var submitError = that.getOwnerComponent().getModel("i18n").getProperty('errorDuringSubmit');
				MessageBox.show(
					oMessage, {
						icon: sap.m.MessageBox.Icon.ERROR,
						title: submitError
					});
			}
		},

		//-----------------------------------------------------------------------
		//Function for clearing the Selected values
		//-----------------------------------------------------------------------
		onPressCancel: function() {
			var aSelectedReport = this.byId("onRepSelect").getSelectedKey();
			if (aSelectedReport === "EWT Report") {
				this.byId("DeliveryFrom").setValue("");
				this.byId("DeliveryTo").setValue("");
				var oDataFrom1 = this.byId("DataFrom");
				oDataFrom1.setValue("");
				var oDataTo1 = this.byId("DataTo");
				oDataTo1.setValue("");
				this.byId("DeliveryNum").setValue("");
				this.byId("DeliveryNum").setEnabled(true);
				this.byId("CustNum").setValue("");
				this.byId("mPlant").setValue("");
				this.byId("DeliveryFrom").setEnabled(true);
				this.byId("DeliveryTo").setEnabled(true);
			} else {
				var oRepSelect = this.byId("onRepSelect");
				oRepSelect.setSelectedKey(" ");
				var oPlant = this.byId("mPlant");
				oPlant.setValue("");
				var oDataFrom = this.byId("DataFrom");
				oDataFrom.setValue("");
				var oDataTo = this.byId("DataTo");
				oDataTo.setValue("");
				this.byId("plant").setVisible(false);
				this.byId("Date").setVisible(false);
				this.byId("mPlant").setVisible(false);
				this.byId("DataFrom").setVisible(false);
				this.byId("toLabel").setVisible(false);
				this.byId("DataTo").setVisible(false);
				this.byId("startTime").setVisible(false);
				this.byId("sTime").setVisible(false);
				this.byId("EndTime").setVisible(false);
				this.byId("eTime").setVisible(false);
				this.byId("DelvNumber").setVisible(false);
				this.byId("DeliveryNum").setVisible(false);
				this.byId("DelvFRom").setVisible(false);
				this.byId("DeliveryFrom").setVisible(false);
				this.byId("delvTo").setVisible(false);
				this.byId("DeliveryTo").setVisible(false);
				this.byId("cust").setVisible(false);
				this.byId("CustNum").setVisible(false);
				this.byId("DeliveryNum").setVisible(false);
				this.byId("DeliveryNum").setEnabled(true);
				this.byId("DeliveryNum").setValue("");
				this.byId("CustNum").setValue("");
				this.byId("DeliveryFrom").setValue("");
				this.byId("DeliveryTo").setValue("");
				this.byId("DeliveryFrom").setEnabled(true);
				this.byId("DeliveryTo").setEnabled(true);
				aPlantitems = [];
			}
		},
		//-----------------------------------------------------------------------
		//Function to handle selection screen 
		//-----------------------------------------------------------------------
		onSelectionChange: function() {
			var oRepSelect = this.byId("onRepSelect").getSelectedKey();
			var date = new Date();
			var firstDay = new Date(date.getFullYear(), date.getMonth(), 1);
			if (oRepSelect === "FDE Usage" || oRepSelect === "DH Dwell Time Report") {
				this.byId("plant").setVisible(true);
				this.byId("Date").setVisible(true);
				this.byId("mPlant").setVisible(true);
				this.byId("DataFrom").setVisible(true);
				this.byId("toLabel").setVisible(true);
				this.byId("DataTo").setVisible(true);
				// this.byId("Time").setVisible(false);
				this.byId("startTime").setVisible(false);
				this.byId("sTime").setVisible(false);
				this.byId("EndTime").setVisible(false);
				this.byId("eTime").setVisible(false);
				this.byId("DelvNumber").setVisible(false);
				this.byId("DeliveryNum").setVisible(false);
				this.byId("DelvFRom").setVisible(false);
				this.byId("DeliveryFrom").setVisible(false);
				this.byId("delvTo").setVisible(false);
				this.byId("DeliveryTo").setVisible(false);
				this.byId("cust").setVisible(false);
				this.byId("CustNum").setVisible(false);
				this.getView().getModel("InputsModel").setProperty("/FromDate", new Date(firstDay));
				this.getView().getModel("InputsModel").setProperty("/ToDate", new Date());
			} else if (oRepSelect === "FDE REPORT" || oRepSelect === "DWELL TIME" || oRepSelect === "YARD HOSTLER" || oRepSelect ===
				"DELIVERY STATUS REPORT" || oRepSelect === "REJECTION REPORT" || oRepSelect === "IDOC STATUS LOG" || oRepSelect ===
				"YARD STOP REPORT") {
				this.byId("plant").setVisible(true);
				this.byId("Date").setVisible(true);
				this.byId("mPlant").setVisible(true);
				this.byId("DataFrom").setVisible(true);
				this.byId("toLabel").setVisible(true);
				this.byId("DataTo").setVisible(true);
				// this.byId("Time").setVisible(true);
				this.byId("startTime").setVisible(true);
				this.byId("sTime").setVisible(true);
				this.byId("EndTime").setVisible(true);
				this.byId("eTime").setVisible(true);
				if (oRepSelect === "IDOC STATUS LOG") {
					this.byId("DelvNumber").setVisible(true);
					this.byId("DeliveryNum").setVisible(true);
				} else {
					this.byId("DelvNumber").setVisible(false);
					this.byId("DeliveryNum").setVisible(false);
				}
				this.byId("DelvFRom").setVisible(false);
				this.byId("DeliveryFrom").setVisible(false);
				this.byId("delvTo").setVisible(false);
				this.byId("DeliveryTo").setVisible(false);
				this.byId("cust").setVisible(false);
				this.byId("CustNum").setVisible(false);
				this.getView().getModel("InputsModel").setProperty("/FromDate", new Date(firstDay));
				this.getView().getModel("InputsModel").setProperty("/ToDate", new Date());
				// } else if (oRepSelect === "REJECTION REPORT") {
				// 	this.byId("plant").setVisible(true);
				// 	this.byId("Date").setVisible(false);
				// 	this.byId("mPlant").setVisible(true);
				// 	this.byId("DataFrom").setVisible(false);
				// 	this.byId("toLabel").setVisible(false);
				// 	this.byId("DataTo").setVisible(false);
				// 	// this.byId("Time").setVisible(true);
				// 	this.byId("startTime").setVisible(false);
				// 	this.byId("sTime").setVisible(false);
				// 	this.byId("EndTime").setVisible(false);
				// 	this.byId("eTime").setVisible(false);
			} else if (oRepSelect === "PRODUCT PLACEMENT DISCREPANCIES") {
				this.byId("plant").setVisible(true);
				this.byId("Date").setVisible(true);
				this.byId("mPlant").setVisible(true);
				this.byId("DataFrom").setVisible(true);
				this.byId("toLabel").setVisible(true);
				this.byId("DataTo").setVisible(true);
				this.byId("DelvNumber").setVisible(true);
				this.byId("DeliveryNum").setVisible(true);
				this.byId("startTime").setVisible(false);
				this.byId("sTime").setVisible(false);
				this.byId("EndTime").setVisible(false);
				this.byId("eTime").setVisible(false);
				this.byId("DelvFRom").setVisible(false);
				this.byId("DeliveryFrom").setVisible(false);
				this.byId("delvTo").setVisible(false);
				this.byId("DeliveryTo").setVisible(false);
				this.byId("cust").setVisible(false);
				this.byId("CustNum").setVisible(false);
				this.getView().getModel("InputsModel").setProperty("/FromDate", new Date(firstDay));
				this.getView().getModel("InputsModel").setProperty("/ToDate", new Date());
			} else if (oRepSelect === "EWT Report") {
				this.byId("plant").setVisible(true);
				this.byId("mPlant").setValue("");
				this.byId("Date").setVisible(true);
				this.byId("mPlant").setVisible(true);
				this.byId("DataFrom").setVisible(true);
				this.byId("toLabel").setVisible(true);
				this.byId("DataTo").setVisible(true);
				this.byId("DelvNumber").setVisible(true);
				this.byId("DeliveryNum").setVisible(true);
				this.byId("startTime").setVisible(false);
				this.byId("sTime").setVisible(false);
				this.byId("EndTime").setVisible(false);
				this.byId("eTime").setVisible(false);
				this.byId("DelvFRom").setVisible(true);
				this.byId("DeliveryFrom").setVisible(true);
				this.byId("delvTo").setVisible(true);
				this.byId("DeliveryTo").setVisible(true);
				this.byId("cust").setVisible(true);
				this.byId("CustNum").setVisible(true);
				this.byId("DataTo").setValue("");
				this.byId("DataFrom").setValue("");
			} else {
				this.byId("plant").setVisible(false);
				this.byId("Date").setVisible(false);
				this.byId("mPlant").setVisible(false);
				this.byId("DataFrom").setVisible(false);
				this.byId("toLabel").setVisible(false);
				this.byId("DataTo").setVisible(false);
				// this.byId("Time").setVisible(false);
				this.byId("startTime").setVisible(false);
				this.byId("sTime").setVisible(false);
				this.byId("EndTime").setVisible(false);
				this.byId("eTime").setVisible(false);
				this.byId("DelvNumber").setVisible(false);
				this.byId("DeliveryNum").setVisible(false);
			}
		},

		//----------------------------------------------------------------------------------
		//Function to create Busy Dialog
		//----------------------------------------------------------------------------------
		fnCreateBusyDialog: function(sImage) {
			var that = this;
			oInsCreateDailog = new sap.m.Dialog({
				showHeader: false
			}).addStyleClass("busyDialog sapUiTinyMargin");
			var sComponentName = that.getOwnerComponent().getMetadata().getComponentName();
			var imgUrl = $.sap.getModulePath(sComponentName, "/images/");
			var oImage = new sap.m.Image().addStyleClass("sapUiMediumMargin");
			oImage.setSrc(imgUrl + sImage);
			oInsCreateDailog.addContent(oImage);
			oInsCreateDailog.open();
		},
		//----------------------------------------------------------------------------------
		//Function for Exit
		//----------------------------------------------------------------------------------
		onExit: function() {
			aPlantitems = [];
			sInsLoggedUser = "";
			sInsPlantId = "";
			sInsUrl = "";
			sInsUserId = "";
			sInsHeadPlantId = "";
			sPlantReport = "";
			sInsCdateId = "";
			sInsResult = "";
			oInsCreateDailog = "";
			sPanel = "";
			plantids = [];
		},

		//---------------------------------------------------------------------------------- 
		//Function to get Clock
		//----------------------------------------------------------------------------------
		fnGetClock: function() {
			var tday = new Array("Sunday", "Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday");
			var tmonth = new Array("January", "February", "March", "April", "May", "June", "July", "August", "September", "October",
				"November",
				"December");
			var d = new Date();
			var nday = d.getDay(),
				nmonth = d.getMonth(),
				ndate = d.getDate(),
				nyear = d.getYear(),
				nhour = d.getHours(),
				nmin = d.getMinutes(),
				nsec = d.getSeconds(),
				ap;
			if (nhour === 0) {
				ap = " AM";
				nhour = 12;
			} else if (nhour < 12) {
				ap = " AM";
			} else if (nhour === 12) {
				ap = " PM";
			} else if (nhour > 12) {
				ap = " PM";
				nhour -= 12;
			}
			if (nyear < 1000) {
				nyear += 1900;
			}
			if (nmin <= 9) {
				nmin = "0" + nmin;
			}
			if (nsec <= 9) {
				nsec = "0" + nsec;
			}
			var resultC = "" + tday[nday] + ", " + tmonth[nmonth] + " " + ndate + ", " + nyear + " " + nhour + ":" + nmin + ":" + nsec + ap +
				"";
			return resultC;
		},

		onSearchPlants: function(oEvt) {
			var aFilters = [];
			var sQuery = oEvt.getSource().getValue();
			if (sQuery && sQuery.length > 0) {
				var filter = new sap.ui.model.Filter("Plant", sap.ui.model.FilterOperator.Contains, sQuery);
				aFilters.push(filter);
			}
			var oTable = sap.ui.getCore().byId("plantName");
			var binding = oTable.getBinding("items");
			binding.filter(aFilters, "Application");
		},
		onDeleveryFrom: function() {
			var that = this;
			var aSelectedReport = that.byId("onRepSelect").getSelectedKey();
			var FromDelivery = that.byId("DeliveryFrom").getValue();
			var ToDelivery = that.byId("DeliveryTo").getValue();
			if (aSelectedReport === "EWT Report" && (FromDelivery > 0 || ToDelivery > 0)) {
				that.byId("DeliveryNum").setEnabled(false);
			} else {
				that.byId("DeliveryNum").setEnabled(true);
			}
		},
		ondelnumberEntered: function(oEvent) {
			var that = this;
			var oDelNum = oEvent.getSource().getValue();
			var aSelectedReport = that.byId("onRepSelect").getSelectedKey();
			if (aSelectedReport === "EWT Report" && oDelNum !== "") {
				that.byId("DeliveryFrom").setEnabled(false);
				that.byId("DeliveryTo").setEnabled(false);
			} else {
				that.byId("DeliveryFrom").setEnabled(true);
				that.byId("DeliveryTo").setEnabled(true);
			}

		}
	});
});