var oInsCreateDailog;

sap.ui.define([
		"sap/ui/core/mvc/Controller",
		"sap/ui/layout/form/GridLayout",
		"sap/m/Panel",
		"sap/ui/model/json/JSONModel",
		"com/report/model/HostlerPersoService",
		"sap/m/TablePersoController",
		"sap/ui/core/util/Export",
		"sap/ui/core/util/ExportTypeCSV",
		"sap/ui/model/Filter",
		"sap/ui/model/Sorter",
		"com/report/model/formatter"
	],
	function(Controller, GridLayout, Panel, JSONModel, HostlerPersoService, TablePersoController, Export, ExportTypeCSV, Filter, Sorter,
		formatter) {
		"use strict";
		return Controller.extend("com.report.controller.Ewtreport", {

			onInit: function() {
				var that = this;
				var oGridLayout = new sap.ui.layout.Grid({
					defaultSpan: "L12 M12 S12",
					content: [
						new sap.m.Panel("", {
							expandable: false,
							expanded: false,
							content: [
								new sap.m.ScrollContainer("", {
									horizontal: true,
									vertical: true,
									height: '430px',

									content: [
										new sap.m.Table("ewtReport", {
											mode: "SingleSelectMaster",
											width: "1480px",
											growing: "true",
											growingThreshold: 20,

											// items: "{path: 'EwtModel'}",

											columns: [new sap.m.Column("", {
													header: new sap.m.Text({
														text: "{i18n>delNum}",
														width: "100px"

													}).addStyleClass("columnLabelStyle bold ")

												}),
												new sap.m.Column("", {
													header: new sap.m.Text({
														text: "{i18n>EwtRefLabel}",
														width: "100px"
													}).addStyleClass("columnLabelStyle bold")
												}), new sap.m.Column("", {
													header: new sap.m.Text({
														text: "{i18n>custNum}",
														width: "100px"
													}).addStyleClass("columnLabelStyle bold")
												}),
												new sap.m.Column("", {
													header: new sap.m.Text({
														text: "{i18n>Plant}",
														width: "80px"
													}).addStyleClass("columnLabelStyle bold")
												}),
												new sap.m.Column("", {
													header: new sap.m.Text({
														text: "{i18n>ewtcode}",
														width: "100px"
													}).addStyleClass("columnLabelStyle bold"),
													demandPopin: true,
													minScreenWidth: "Desktop",
													popinDisplay: "Inline"
												}),
												new sap.m.Column("", {
													header: new sap.m.Text({
														text: "{i18n>ewtcodedes}",
														width: "100px"
													}).addStyleClass("columnLabelStyle bold"),
													demandPopin: true,
													minScreenWidth: "Desktop",
													popinDisplay: "Inline"
												}),
												new sap.m.Column("", {
													header: new sap.m.Text({
														text: "{i18n>prdCode}",
														width: "60px"
													}).addStyleClass("columnLabelStyle bold"),
													demandPopin: true,
													minScreenWidth: "Desktop",
													popinDisplay: "Inline"
												}),
												new sap.m.Column("", {
													header: new sap.m.Text({
														text: "{i18n>prodcodedes}",
														width: "80px"
													}).addStyleClass("columnLabelStyle bold"),
													demandPopin: true,
													minScreenWidth: "Desktop",
													popinDisplay: "Inline"
												}),

												new sap.m.Column("", {
													header: new sap.m.Text({
														text: "{i18n>Quanrec}",
														width: "100px"

													}).addStyleClass("columnLabelStyle bold"),
													demandPopin: true,
													minScreenWidth: "Desktop",
													popinDisplay: "Inline"
												}),
												new sap.m.Column("", {
													header: new sap.m.Text({
														text: "{i18n>Quanrej}",
														width: "100px"
													}).addStyleClass("columnLabelStyle bold"),
													demandPopin: true,
													minScreenWidth: "Desktop",
													popinDisplay: "Inline"
												}),

												new sap.m.Column("", {
													header: new sap.m.Text({
														text: "{i18n>usrName}",
														width: "100px"

													}).addStyleClass("columnLabelStyle bold")
												}),
												new sap.m.Column("", {
													header: new sap.m.Text({
														text: "{i18n>CntryLabel}",
														width: "100px"
													}).addStyleClass("columnLabelStyle bold")
												}),
												new sap.m.Column("", {
													header: new sap.m.Text({
														text: "{i18n>ewtDate}",
														width: "80px"
													}).addStyleClass("columnLabelStyle bold")
												}),
												new sap.m.Column("", {
													header: new sap.m.Text({
														text: "{i18n>imagescap}",

														width: "100px"
													}).addStyleClass("columnLabelStyle bold")
												}),
												new sap.m.Column("", {
													header: new sap.m.Text({
														text: "{i18n>noofimgcap}",

														width: "100px"
													}).addStyleClass("columnLabelStyle bold")
												})
											]
										}).addStyleClass("tableStyle TableClass stickyClass")
									]
								}).addStyleClass("tableClass TableClass")
							]
						}).addStyleClass("pHeading panelBackground")
					]
				});
				that.byId("ewtPageId").addContent(oGridLayout);
				var oRouter = sap.ui.core.UIComponent.getRouterFor(that);
				oRouter.getRoute("Ewtreport").attachMatched(that._onRouteMatched, that);
				that.getView().getModel("detailsModel");

			},

			fnCreateBusyDialog: function(sImage) {
				var that = this;
				oInsCreateDailog = new sap.m.Dialog({
					showHeader: false
				}).addStyleClass("busyDialog sapUiTinyMargin");
				var sComponentName = that.getOwnerComponent().getMetadata().getComponentName();
				var imgUrl = $.sap.getModulePath(sComponentName, "/images/");
				var oImage = new sap.m.Image().addStyleClass("sapUiMediumMargin");
				oImage.setSrc(imgUrl + sImage);
				oInsCreateDailog.addContent(oImage);
				oInsCreateDailog.open();
			},

			_onRouteMatched: function(oEvent) {
				var that = this;
				var oArgs = oEvent.getParameter("arguments");
				var oModelData = that.getOwnerComponent().getModel("EwtModelData").getData();
				// var oModel = new JSONModel(oModelData);
				// 	that.getView().setModel(oModel, "EwtModel");

				that.tableBinding();
				// var sDateRange = oArgs.aFromDate.split(",");
				// var oStartDate = sDateRange[0];
				// var newStrDate = oStartDate.replace(/-/g, "");
				// var oEndDate = sDateRange[1];
				// var aToNewDate = oArgs.aToDate.replace(/-/g, "");
				// // oArgs.DateStart = oStartDate;
				// // oArgs.DateEnd = oEndDate;
				// var odelNum,
				// 	oPlant,
				// 	ocntry, ologgedUser, FromDelivery, ToDelivery;
				// var oModel = new JSONModel({
				// 	odelNum: oArgs.DeliveryNumber,
				// 	oPlant: oArgs.Plants,
				// 	// ocntry: oArgs.Country,
				// 	FromDelivery: oArgs.FromDelivery,
				// 	ToDelivery: oArgs.ToDelivery,
				// 	FromDate:newStrDate,
				// 	ToDate: aToNewDate
				// });
				// var sEwtFilter = [];
				// sEwtFilter.push(new sap.ui.model.Filter("Plant", sap.ui.model.FilterOperator.EQ, oArgs.Plants));
				// sEwtFilter.push(new sap.ui.model.Filter("FromDelivery", sap.ui.model.FilterOperator.EQ, oArgs.FromDelivery));
				// sEwtFilter.push(new sap.ui.model.Filter("ToDelivery", sap.ui.model.FilterOperator.EQ, oArgs.ToDelivery));
				// sEwtFilter.push(new sap.ui.model.Filter("FromDate", sap.ui.model.FilterOperator.EQ, oArgs.aFromDate));
				// sEwtFilter.push(new sap.ui.model.Filter("ToDate", sap.ui.model.FilterOperator.EQ, oArgs.aToDate));
				// that.getOwnerComponent().getModel("ewtReportModel").read("/HeaderSet", {
				// 	filters: sEwtFilter,
				// 	success: function(oData, oResponse) {
				// 		if (oResponse.statusCode === 200 || oResponse.statusCode === "200") {
				// 			var oEwtTableModel = new JSONModel();
				// 			oEwtTableModel.setData(oData.results);
				// 			oEwtTableModel.setSizeLimit(oData.results.length);
				// 			that.getView().setModel(oEwtTableModel, "EwtModelData");
				// 			// that.bindAllPanelsandTables(oData.results);
				// 		}
				// 		that.fnCreateBusyDialog("pallet.svg", "false");
				// 	},
				// 	error: function() {
				// 		that.fnCreateBusyDialog("pallet.svg", "false");
				// 	}
				// });

			},

			tableBinding: function() {
				/*Pass Data to Tables*/

				var oTemplate = new sap.m.ColumnListItem({
					cells: [
						new sap.m.Text({
							text: "{EwtModel>Delivery}",
							width: "8rem"
						}),
						new sap.m.Text({
							text: "{EwtModel>EwtRef}",
							width: "8rem"
						}),

						new sap.m.Text({
							text: "{EwtModel>Customer}",
							width: "8rem"
						}),

						new sap.m.Text({
							text: "{EwtModel>Plant}"
						}),
						new sap.m.Text({
							text: "{EwtModel>Material}"
						}),
						new sap.m.Text({
							text: "{EwtModel>EwtDesc}"
						}),
						new sap.m.Text({
							text: "{EwtModel>Smaterial}"
						}),
						new sap.m.Text({
							text: "{EwtModel>Sdesc}",
							width: "100px"
						}),

						new sap.m.Text({
							text: "{EwtModel>QtyReceived}"

						}),
						new sap.m.Text({
							text: "{EwtModel>QtyRejected}"
						}),

						new sap.m.Text({
							text: "{EwtModel>UserId}",
							width: "8rem"
						}),
						new sap.m.Text({
							text: "{EwtModel>Country}"
						}),
						new sap.m.Text({
							text: "{EwtModel>Date}"
						}),
						new sap.m.Text({
							text: "{EwtModel>ImagesCaptured}"
						
						}),
						new sap.m.Text({
							text: "{EwtModel>NumberOfImages}"
						

						})

					]
				});
				/*Table Binding*/
				var oEwtReportTable = sap.ui.getCore().byId("ewtReport");
				var oModelData = this.getOwnerComponent().getModel("EwtModelData").getData();
				var oModel1 = new sap.ui.model.json.JSONModel(oModelData);
				oModel1.setSizeLimit(oModelData.length);
				oModel1.setData(oModelData);
				this.getView().setModel(oModel1, "EwtModel");
				if (oEwtReportTable !== undefined) {
					oEwtReportTable.setModel("EwtModel");
					oEwtReportTable.bindAggregation("items", {
						path: "EwtModel>/",
						template: oTemplate
					});
				}
				/*Table Grouping*/
				var oGroupingModel = new JSONModel({
					hasGrouping: false
				});
				this.getView().setModel(oGroupingModel, 'Grouping');

			},
			onNavButtonPress: function() {
				var that = this;
				var reportModel = that.getView().getModel("EwtModel");
				if (reportModel !== undefined) {
					reportModel.destroy();
					sap.ui.getCore().byId("ewtReport").removeAllDependents();
				}
				var oRouter = sap.ui.core.UIComponent.getRouterFor(this);
				oRouter.navTo("ReportInter");
			},

			onPressEWTExport: sap.m.Table.prototype.exportData || function() {
				var that = this;
				var oExport = new Export({
					exportType: new ExportTypeCSV({
						separatorChar: ",",
						fileExtension: "csv"
					}),
					models:that.getView().getModel("EwtModel"),
					rows: {
						path: "/"
					},

					columns: [{
							name: that.getOwnerComponent().getModel("i18n").getProperty("delNum"),
							template: {
								content: "{Delivery}"
							}
						}, {
							name: that.getOwnerComponent().getModel("i18n").getProperty("EwtRefLabel"),
							template: {
								content: "{EwtRef}"
							}
						}, {
							name: that.getOwnerComponent().getModel("i18n").getProperty("custNum"),
							template: {
								content: "{Customer}"
							}
						}, {
							name: that.getOwnerComponent().getModel("i18n").getProperty("plant"),
							template: {
								content: "{Plant}"
							}
						}, {
							name: that.getOwnerComponent().getModel("i18n").getProperty("ewtcode"),
							template: {
								content: "{Material}"
							}
						}, {
							name: that.getOwnerComponent().getModel("i18n").getProperty("ewtcodedes"),
							template: {
								content: "{EwtDesc}"
							}
						}, {
							name: that.getOwnerComponent().getModel("i18n").getProperty("prdCode"),
							template: {
								content: "{Smaterial}"
							}
						}, {
							name: that.getOwnerComponent().getModel("i18n").getProperty("prodcodedes"),
							template: {
								content: "{Sdesc}"
							}
						}, {
							name: that.getOwnerComponent().getModel("i18n").getProperty("Quanrec"),
							template: {
								content: "{QtyReceived}"
							}
						}, {
							name: that.getOwnerComponent().getModel("i18n").getProperty("Quanrej"),
							template: {
								content: "{QtyRejected}"
							}
						}, {
							name: that.getOwnerComponent().getModel("i18n").getProperty("usrName"),
							template: {
								content: "{UserId}"
							}
						}, {
							name: that.getOwnerComponent().getModel("i18n").getProperty("CntryLabel"),
							template: {
								content: "{Country}"
							}
						}, {
							name: that.getOwnerComponent().getModel("i18n").getProperty("ewtDate"),
							template: {
								content: "{Date}"
							}
						}, {
							name: that.getOwnerComponent().getModel("i18n").getProperty("imagescap"),
							template: {
								content: "{ImagesCaptured}"
							}
						}, {
							name: that.getOwnerComponent().getModel("i18n").getProperty("noofimgcap"),
							template: {
								content: "{NumberOfImages}"
							}
						}

					]
				});
				// /*** add this column only when parentplant is active ***/
				// oExport.insertColumn(new sap.ui.core.util.ExportColumn({
				// 	name: this.getOwnerComponent().getModel("i18n").getProperty("Plant"),
				// 	template: {
				// 		content: "{Plant}"
				// 	}
				// }), 0);
				var sewtReport = that.getOwnerComponent().getModel("i18n").getProperty("ewtReport");
				oExport.saveFile(sewtReport).catch(function(oError) {}).then(function() {
					oExport.destroy();
				});
			}
		});
	});