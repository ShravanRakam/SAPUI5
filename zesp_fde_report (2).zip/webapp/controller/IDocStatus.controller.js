var sInsPlantId;
var sInsUrl;
var sInsUserId;
var sInsHeadPlantId;
var sInsCdateId;
var sDateRange = [];
var vRegion;
sap.ui.define([
		"sap/ui/core/mvc/Controller",
		"sap/m/Panel",
		"sap/ui/model/json/JSONModel",
		"sap/ui/model/Filter",
		"sap/ui/model/Sorter",
		"sap/m/MessageBox",
		"sap/ui/layout/Grid",
		"sap/ui/core/util/Export",
		"sap/ui/core/util/ExportTypeCSV",
		"com/report/model/formatter"
	],
	function(Controller, Panel, JSONModel, Filter, Sorter, MessageBox, Grid, Export, ExportTypeCSV, formatter) {
		"use strict";
		return Controller.extend("com.report.controller.IDocStatus", {
			formatter: formatter,
			onInit: function() {
				jQuery.sap.require("jquery.sap.storage");
				// Keeps reference to any of the created sap.m.ViewSettingsDialog-s in this sample
				this._mViewSettingsDialogs = {};

				var oModel = {
					NumberofDelv: 0,
					Success: 0,
					Failed: 0
				};
				var oViewModel = new JSONModel(oModel);
				this.getView().setModel(oViewModel, "ViewModel");
				var oRouter = sap.ui.core.UIComponent.getRouterFor(this);
				oRouter.getRoute("IDocStatus").attachMatched(this._onRouteMatched, this);
				var that = this;
				/*var sStartup = "/sap/bc/ui2/start_up";
				var xmlHttp = null;
				xmlHttp = new XMLHttpRequest();
				xmlHttp.onreadystatechange = function() {
					if (xmlHttp.readyState === 4 && xmlHttp.status === 200) {
						var oUserData = JSON.parse(xmlHttp.responseText);
						var sInsLoggedUser = oUserData.id;
						that.fnGetHeaderDetails(sInsLoggedUser);
					}
				};
				xmlHttp.open("GET", sStartup, false);
				xmlHttp.send(null);*/

				var oDesktopDevice = sap.ui.Device.system.desktop;
				if (oDesktopDevice === true) {
					//Desktop Title Bar
					var oTitleBar = sap.ui.xmlfragment(this.createId("Plant_Detail_Bar_ID"), "com.report.fragments.PlantDetails", this);
					this.getView().addDependent(oTitleBar);
					this.getView().byId("IDocStatusPage").addContent(oTitleBar);
					sInsUserId = "Header_Desktop_Bar_ID--userName";
					sInsHeadPlantId = "Header_Desktop_Bar_ID--plantName";
					sInsCdateId = "Header_Desktop_Bar_ID--cDate";
					/*_______________ making visible false for settings icon in the fragment ______________*/
					// this.getView().byId("Header_Desktop_Bar_ID--Settings").setVisible(false);
				} else {
					//Mobile Title Bar
					var oTitleMobBar = sap.ui.xmlfragment(this.createId("Header_PlantDetail_Mobile_Bar_ID"),
						"com.report.fragments.MobileHeaderPlantDetails", this);
					this.getView().addDependent(oTitleMobBar);
					this.getView().byId("IDocStatusPage").addContent(oTitleMobBar);
					sInsUserId = "Header_Mobile_Bar_ID--userName1";
					sInsHeadPlantId = "Header_Mobile_Bar_ID--plantName1";
					sInsCdateId = "Header_Mobile_Bar_ID--cDate1";
					/*_______________ making visible false for settings icon in the fragment ______________*/
					// this.getView().byId("Header_Mobile_Bar_ID--Settings").setVisible(false);
				}
				// ----------------------------------------------------------------------------------
				//                  		To get the clock
				// ----------------------------------------------------------------------------------

				/*	setInterval(function() {
					var realClock = that.realDateTimeClock();
					if (that.byId(sInsCdateId) !== undefined) {
						that.byId(sInsCdateId).setText(realClock);
					}
				}, 1000);*/

			},
			realDateTimeClock: function() {
				var dateObject = new Date();
				var dateFormat = sap.ui.core.format.DateFormat.getDateInstance({
					style: 'full',
					pattern: "EEEE, MMMM dd, YYYY hh:mm:ss a"
				});
				// Format the date
				var dateFormatted = dateFormat.format(dateObject);
				return dateFormatted;
			},
			fnGetHeaderDetails: function(sInsLoggedUser) {
				/*
				var that = this;
				that.fnCreateBusyDialog("pallet.svg", true);
				sInsUrl = "/sap/opu/odata/sap/ZGW_ACTIVITY_SRV";
				var oHeaderModel = new sap.ui.model.odata.ODataModel(sInsUrl);
				oHeaderModel.read("/HeaderDetailsSet('" + sInsLoggedUser + "') ", null, null,
					true, function(oData, oResponse) {
						if (oResponse.statusCode === 200) {
							var oODataJSONModel2 = new sap.ui.model.json.JSONModel();
							oODataJSONModel2.setData(oData);
							if (that.byId(sInsUserId) !== undefined) {
								that.byId(sInsUserId).setText(oData.Firstname + " " + oData.Lastname); // Binding the user name
							}
							if (that.byId(sInsHeadPlantId) !== undefined) {
								that.byId(sInsHeadPlantId).setText(oData.Plant + "-" + oData.Name1); // Binding the plant name
							}
							sInsPlantId = oData.Plant;
						}
						that.oCreateDailog.close();
					},
					function() {
						that.oCreateDailog.close();
					});
			*/
			},
			//----------------------------------------------------------------------------------
			//Function to create Busy Dialog
			//----------------------------------------------------------------------------------
			fnCreateBusyDialog: function(sImage) {
				this.oCreateDailog = new sap.m.Dialog({
					showHeader: false
				}).addStyleClass("busyDialog sapUiTinyMargin");
				var sComponentName = this.getOwnerComponent().getMetadata().getComponentName();
				var imgUrl = $.sap.getModulePath(sComponentName, "/images/");
				var oImage = new sap.m.Image().addStyleClass("sapUiMediumMargin");
				oImage.setSrc(imgUrl + sImage);
				this.oCreateDailog.addContent(oImage);
				this.oCreateDailog.open();

			},
			onNavButtonPress: function() {
				var IdocModel = this.getView().getModel("IdocModel");
				if (IdocModel !== undefined) {
					IdocModel.destroy();
				}
				var oModel = {
					NumberofDelv: 0,
					Success: 0,
					Failed: 0
				};

				this.getView().getModel("ViewModel").setData(oModel);
				var oRouter = sap.ui.core.UIComponent.getRouterFor(this);
				oRouter.navTo("ReportInter");
			},
			_onRouteMatched: function(oEvent) {
				var that = this;
				vRegion = jQuery.sap.storage(jQuery.sap.storage.Type.local).get("region");
				var oArgs = oEvent.getParameter("arguments"),
					StartTime = oArgs.StartTime,
					EndTime = oArgs.EndTime,
					delNum = oArgs.DeliveryNumber,
					delNumFilterStr;
				if (parseInt(delNum) !== 12345) {
					delNumFilterStr = " and DocId eq '" + delNum + "'";
				} else {
					delNumFilterStr = "";
				}
				// sPlantNames = oArgs.Plants.split(",");
				sDateRange = oArgs.DateRange.split(",");

				//Setting the selected report as page title 
				// this.byId("IDocStatusPage").setTitle(oArgs.reportname);

				var oPlantsVBox = that.byId("plantsVBox");
				if (oPlantsVBox !== undefined) {
					oPlantsVBox.destroy();
				}
				var oSummaryPanel = that.byId("SummaryPanel");
				if (oSummaryPanel !== undefined) {
					oSummaryPanel.destroy();
				}
				var IdocDetailsPanel = sap.ui.getCore().byId("IdocDetailsPanel");
				if (IdocDetailsPanel !== undefined) {
					IdocDetailsPanel.destroy();
				}
				var IdocTable = sap.ui.getCore().byId("IdocTable");
				if (IdocTable !== undefined) {
					IdocTable.destroy();
				}

				// var dDateForm = sDateRange[0].slice(6, 10) + sDateRange[0].slice(0, 2) + sDateRange[0].slice(3, 5);
				// var dDateTo = sDateRange[1].slice(6, 10) + sDateRange[1].slice(0, 2) + sDateRange[1].slice(3, 5);
				var dDateForm = sDateRange[0].slice(0, 4) + '-' + sDateRange[0].slice(5, 7) + '-' + sDateRange[0].slice(8, 10);
				var dDateTo = sDateRange[1].slice(0, 4) + '-' + sDateRange[1].slice(5, 7) + '-' + sDateRange[1].slice(8, 10);
				// var sInpDates = dDateForm + "," + dDateTo;

				sInsPlantId = oArgs.Plants;
				oArgs.DateStart = dDateForm;
				oArgs.DateEnd = dDateTo;
				var plantModel = new sap.ui.model.json.JSONModel();
				plantModel.setData(oArgs);
				that.getView().setModel(plantModel, "plantDetailModel");

				var oVBox = new sap.m.VBox(this.createId("plantsVBox"), {
					items: [
						new sap.m.Bar(this.createId("DateRange"), {
							contentMiddle: [
								new sap.m.Label(this.createId("onFrom"), {
									text: "{i18n>dateRange}",
									design: "Bold"
								}).addStyleClass("from"),
								new sap.m.Label(this.createId("onDateFrom"), {

								}).addStyleClass("fromData"),
								new sap.m.Label(this.createId("onTo"), {
									design: "Bold",
									text: "{i18n>to}"
								}).addStyleClass("to"),
								new sap.m.Label(this.createId("onDateTo"), {}).addStyleClass("toValue")
							]
						}),
						new sap.m.HBox({
							items: [
								new sap.m.Label({
									design: "Bold",
									text: "{i18n>LabelPlant}" //"Plants:"
								}).addStyleClass("sapUiTinyMarginTop sapUiSmallMargin"),
								new sap.m.Text({
									design: "Bold",
									text: sInsPlantId //"Plants:"
								}).addStyleClass("sapUiTinyMarginTop sapUiSmallMargin")
							]
						})

					]
				}).addStyleClass("sapUiSizeCompact printClass");

				var oPanel = new sap.m.Panel(this.createId("SummaryPanel"), {
					expandable: true,
					expanded: true,
					backgroundDesign: "Transparent",
					headerToolbar: new sap.m.Toolbar({
						content: [
							new sap.m.Label({
								text: "{i18n>summary}"
							}).addStyleClass("pHeaderText"),
							new sap.m.ToolbarSpacer({}),
							new sap.m.Button({
								icon: "sap-icon://expand-group",
								press: function(oEvent) {
									that.onPressExp(oEvent);
								}
							}).addStyleClass("headerButton")
						]
					}),
					content: [
						new sap.m.Bar({
							// defaultSpan: "L2 M2 S12",
							contentLeft: [
								new sap.m.HBox({
									items: [
										new sap.m.Label({
											text: "{i18n>NumberofDeliveries}",
											design: "Bold"
												// layoutData: new sap.ui.layout.GridData({
												// 	linebreakL: true,
												// 	linebreakM: true,
												// 	linebreakS: true

											// })
										}).addStyleClass("sapUiSmallMargin"),
										new sap.m.Label({
											text: "{ViewModel>/NumberofDelv}",
											design: "Standard"

										}).addStyleClass("sapUiSmallMarginBegin")
									]
								}).addStyleClass("sapUiTinyMarginBegin")
							],
							contentMiddle: [
								new sap.m.Label({
									text: "{i18n>Success}",
									design: "Bold"
										// layoutData: new sap.ui.layout.GridData({
										// 	linebreakL: true,
										// 	linebreakM: true,
										// 	linebreakS: true
										// })
								}).addStyleClass("sapUiSmallMargin"),
								new sap.m.Label({
									text: "{ViewModel>/Success}",
									design: "Standard"

								}).addStyleClass("sapUiSmallMarginBegin")
							],
							contentRight: [
								new sap.m.Label({
									text: "{i18n>Failed}",
									design: "Bold"
										// layoutData: new sap.ui.layout.GridData({
										// 	linebreakL: true,
										// 	linebreakM: true,
										// 	linebreakS: true
										// })
								}).addStyleClass("sapUiSmallMargin"),
								new sap.m.Label({
									text: "{ViewModel>/Failed}",
									design: "Standard"

								}).addStyleClass("sapUiLargeMarginEnd")
							]
						})
					]

				});

				//Adding the panels for the page
				var oBox = this.byId("IDocStatusPage");
				// oBox.addContent(oVBox);
				oBox.addContent(oPanel);

				this.byId("onDateFrom").setText(sDateRange[0]);
				this.byId("onDateTo").setText(sDateRange[1]);
				if (sDateRange[1] === "") {
					this.byId("onTo").setVisible(false);
				} else {
					this.byId("onTo").setVisible(true);
				}
				// this.fnCreateBusyDialog("pallet.svg");
				var busydialog = new sap.m.BusyDialog({
					text: "{i18n>pleaseWait}",
					showCancelButton: true
				});
				busydialog.open();
				var DelService = "/sap/opu/odata/sap/ZGW_IDOC_ERROR_CHECK_SRV/";
				var DeliveryReportModel = new sap.ui.model.odata.ODataModel(DelService);
				DeliveryReportModel.read("/Idoc_ErrorCheckSet?$filter=Erdat ge datetime'" + dDateForm + "T" + StartTime +
					"' and Erdat  le datetime'" +
					dDateTo + "T" + EndTime + "' and Werks eq'" + sInsPlantId + "'" + delNumFilterStr, {
						success: function(oData, oResponse) {
							if (oResponse.statusCode === 200 || oResponse.statusCode === "200") {
								var resLength = oData.results.length;
								if (resLength < 1) {
									var IdocstatusLogModel = new JSONModel(oData);
									that.getView().setModel(IdocstatusLogModel, "IdocModel");
									var bCompact = !!that.getView().$().closest(".sapUiSizeCompact").length;
									var noRecordFound = that.getOwnerComponent().getModel("i18n").getProperty('noRecordFound');
									MessageBox.error(
										noRecordFound, {
											styleClass: bCompact ? "sapUiSizeCompact" : ""
										});
									// that.oCreateDailog.close();
									busydialog.close();
								} else {
									for (var k = 0; k < resLength; k++) {
										oData.results[k].Region = vRegion;
									}
									var IdocstatusLogModel = new JSONModel(oData);
									IdocstatusLogModel.setSizeLimit(resLength);
									that.getView().setModel(IdocstatusLogModel, "IdocModel");
									// that.oCreateDailog.close();
									busydialog.close();
								}
							}
						},
						error: function(oError) {

							var oMessage;
							if (oMessage === undefined) {
								oMessage = $(oError.response.body).find('message').first().text();
							}
							var bCompact = !!that.getView().$().closest(".sapUiSizeCompact").length;
							var sError = that.getOwnerComponent().getModel("i18n").getProperty('error');
							MessageBox.show(
								oMessage, {
									icon: sap.m.MessageBox.Icon.ERROR,
									title: sError,
									styleClass: bCompact ? "sapUiSizeCompact" : ""

								});
							// that.oCreateDailog.close();
							busydialog.close();
						}
					});

				// sap.ui.getCore().byId("Settings").setVisible(false);

				that.onTabsPress();
			},
			//----------------------------------------------------------------------------------------
			// Function for viewing the plant details in Tab View
			//-----------------------------------------------------------------------------------------
			onTabsPress: function() {

				var aTabId = this.byId("TabLayout");
				if (aTabId !== undefined) {
					aTabId.destroy();
				}
				// var oGridLayout = new sap.ui.layout.Grid(this.getView().createId("panelGrid"),{content:[]});
				var sPlantReport = sap.ui.xmlfragment("com.report.fragments.IDocStatusLog", this);
				/*var oGridLayout = new sap.ui.layout.Grid(this.createId("TabLayout"), {
					defaultSpan: "L12 M12 S12",
					content: [sPlantReport]
				});*/
				this.getView().byId("IDocStatusPage").addContent(sPlantReport);
				// this.oCreateDailog.open();
			},
			onPersonalisation: function(oEvent) {
				var that = this;
				var popover = new sap.m.Popover(this.createId("popOver"), {
					showHeader: true,
					showFooter: true,
					placement: sap.m.PlacementType.Bottom,
					content: []
				}).addStyleClass("sapMOTAPopover sapTntToolHeaderPopover");

				//*----- Adding List to the PopOver -----*//
				var yardColumnList = new sap.m.List(this.createId("SelectedList"), {
					selectionChange: function() {
						that.onListSelection();
					}
				});
				if (that.byId("popOver") !== undefined) {
					this.byId("popOver").addContent(yardColumnList);
				}
				var yardTable = this.getView().byId("IdocTable"),
					columnHeader = yardTable.getColumns();
				var ColCountarray = [];
				for (var i = 0; i < columnHeader.length; i++) {
					var hText = columnHeader[i].mAggregations.header.mProperties.text;
					var columnObject = {};
					columnObject.column = hText;
					ColCountarray.push(columnObject);
				}

				var columnHeaderText = new sap.ui.model.json.JSONModel({
					list: ColCountarray
				});

				var itemTemplate = new sap.m.StandardListItem({
					title: "{yardHeaderText>column}"
				});

				yardColumnList.setMode("MultiSelect");
				yardColumnList.setModel(columnHeaderText);
				sap.ui.getCore().setModel(columnHeaderText, "yardHeaderText");
				yardColumnList.bindItems("yardHeaderText>/list", itemTemplate);
				var propFile = $.sap.getModulePath("com.yard", "/i18n/");
				var propData = propFile + "i18n.properties";
				var oBundle = jQuery.sap.resources({
					url: propData, //"i18n/i18n.properties",
					locale: sap.ui.getCore().getConfiguration().getLanguage()
				});

				var selectall = that.getModel("i18n").getProperty('selectall');
				var header = new sap.m.Bar({
					contentLeft: [
						new sap.m.CheckBox(this.createId("selectAll"), {
							text: selectall,
							select: function() {
								that.onSelectAll();
							}
						}).addStyleClass("sapUiTinyMargin sapUiLargeMarginBottom")
					]

				});

				if (this.byId("popOver") !== undefined) {
					this.byId("popOver").setCustomHeader(header);
				}

				var footer = new sap.m.Bar({
					contentLeft: [],
					contentMiddle: [

						new sap.m.Button({
							text: oBundle.getText("save"),

							press: function() {
								that.onSave();
							}

						}), new sap.m.Button({
							text: oBundle.getText("cancel"),

							press: function() {
								that.onCancel();
							}
						})
					],
					contentRight: []
				});
				if (this.byId("popOver") !== undefined) {
					this.byId("popOver").setFooter(footer);
				}
				var yardListPop = this.byId("SelectedList");
				var yardTableColumns = this.byId("yardtable").getColumns();

				yardListPop.attachEventOnce("updateFinished", function() {
					var popOverArray = [];
					for (var j = 0; j < yardTableColumns.length; j++) {
						var list = yardColumnList.oModels.undefined.oData.list[j].column;
						popOverArray.push(list);

					}
					var visible = [];
					for (var k = 0; k < popOverArray.length; k++) {
						var Text = yardTableColumns[k].getHeader().mProperties.text;
						var columnVisible = yardTableColumns[k].mProperties.visible;

						if (columnVisible === true) {
							visible.push(columnVisible);
							if (popOverArray.indexOf(Text) > -1) {
								var firstItem0 = yardColumnList.getItems()[k];
								yardColumnList.setSelectedItem(firstItem0, true);
							}
						} else {
							var Item = yardColumnList.getItems()[k];
							yardColumnList.setSelectedItem(Item, false);
						}
					}

				});
				popover.openBy(event.getSource());
			},
			handleSortButtonPressed: function() {
				this.createViewSettingsDialog("com.report.fragments.IDocSorter").open();

			},

			handleFilterButtonPressed: function() {
				this.createViewSettingsDialog("com.report.fragments.IDocFilter").open();
				this.loadFiltersData();
			},
			createViewSettingsDialog: function(sDialogFragmentName) {
				var oDialog = this._mViewSettingsDialogs[sDialogFragmentName];

				/*if (oDialog) {
					if (this._currentItemTab !== sKey) {
						oDialog.fireResetFilters(new sap.ui.base.Event());
					}
				}*/
				if (!oDialog) {
					oDialog = sap.ui.xmlfragment(sDialogFragmentName, this);
					this._mViewSettingsDialogs[sDialogFragmentName] = oDialog;
					var i18nModel = this.getOwnerComponent().getModel("i18n");
					oDialog.setModel(i18nModel, "i18n");
				}
				return oDialog;
			},
			handleSortDialogConfirm: function(oEvent) {
				var oTable = sap.ui.getCore().byId("IdocTable"),
					mParams = oEvent.getParameters(),
					oBinding = oTable.getBinding("items"),
					sPath,
					bDescending,
					aSorters = [];

				sPath = mParams.sortItem.getKey();
				bDescending = mParams.sortDescending;
				aSorters.push(new Sorter(sPath, bDescending));
				if (sPath === "Erdat" || sPath === "Logdat") {
					sPath === "Erdat" ? aSorters.push(new Sorter("Erzet", bDescending)) : aSorters.push(new Sorter("Logdat", bDescending));
				}

				// apply the selected sort and group settings
				if (oBinding !== undefined) {
					oBinding.sort(aSorters);
				}
			},
			handleFilterDialogConfirm: function(oEvent) {
				var mParams = oEvent.getParameters(),
					oBinding = sap.ui.getCore().byId("IdocTable").getBinding("items"),
					aFilters = [];
				mParams.filterItems.forEach(function(oItem) {
					var aSplit = oItem.getKey().split("___"),
						sPath = aSplit[0],
						sOperator = aSplit[1],
						sValue1 = aSplit[2],
						sValue2 = aSplit[3],
						oFilter = new Filter(sPath, sOperator, sValue1, sValue2);
					aFilters.push(oFilter);
				});

				// apply filter settings
				if (oBinding !== undefined) {
					oBinding.filter(aFilters, sap.ui.model.FilterType.Control);

					// update filter bar
					// sap.ui.getCore().byId( "InfoToolBar").setVisible(aFilters.length > 0);
					// sap.ui.getCore().byId(sKey + "InfoLabel").setText(mParams.filterString);

				}
			},
			loadFiltersData: function() {
				var Model = sap.ui.getCore().byId("IdocTable").getModel("IdocModel");
				if (Model !== undefined) {
					var filterResults = Model.getData();

					//----Binded unique data of Plant  to filter fragment----//
					/*	var PlantFilter = [];
					for (var i = 0; i < filterResults.results.length; i++) {
						if (PlantFilter.indexOf(filterResults.results[i].Werks) === -1) {
							PlantFilter.push(filterResults.results[i].Werks);
						}
					}
					if (sap.ui.getCore().byId("PlantFilter") !== undefined) {
						sap.ui.getCore().byId("PlantFilter").setModel(new JSONModel(PlantFilter), "PlantsModel");
					}*/

					//----Binded unique Delivery's  to filter fragment----//
					var DeliveryFilter = [];
					for (var i = 0; i < filterResults.results.length; i++) {
						if (DeliveryFilter.indexOf(filterResults.results[i].DocId) === -1) {
							DeliveryFilter.push(filterResults.results[i].DocId);
						}
					}

					if (sap.ui.getCore().byId("DeliveryFilter") !== undefined) {
						var DeliveryModel = new JSONModel(DeliveryFilter);
						DeliveryModel.setSizeLimit(DeliveryFilter.length);
						sap.ui.getCore().byId("DeliveryFilter").setModel(DeliveryModel, "DeliveryModel");
					}
					//----Binded unique Create On to filter fragment----//
					/*	var CreateOnFilter = [];
					for (var i = 0; i < filterResults.results.length; i++) {
						if (CreateOnFilter.indexOf(filterResults.results[i].Erdat) === -1) {
							CreateOnFilter.push(filterResults.results[i].Erdat);
						}
					}

					if (sap.ui.getCore().byId("CreatedOnFilter") !== undefined) {
						sap.ui.getCore().byId("CreatedOnFilter").setModel(new JSONModel(CreateOnFilter), "CreatedonModel");
					}
					//----Binded unique Time  to filter fragment----//
					var TimeFilter = [];
					for (var i = 0; i < filterResults.results.length; i++) {
						if (TimeFilter.indexOf(filterResults.results[i].Erzet) === -1) {
							TimeFilter.push(filterResults.results[i].Erzet);
						}
					}

					if (sap.ui.getCore().byId("CreatedTimeFilter") !== undefined) {
						sap.ui.getCore().byId("CreatedTimeFilter").setModel(new JSONModel(TimeFilter), "CreatedTimeModel");
					}*/
					//----Binded unique Status  to filter fragment----//
					var StatusFilter = [];
					for (var i = 0; i < filterResults.results.length; i++) {
						if (StatusFilter.indexOf(filterResults.results[i].StatusText) === -1) {
							StatusFilter.push(filterResults.results[i].StatusText);
						}
					}

					if (sap.ui.getCore().byId("StatusFilter") !== undefined) {
						sap.ui.getCore().byId("StatusFilter").setModel(new JSONModel(StatusFilter), "StatusModel");
					}
					//----Binded unique IdocStatus to filter fragment----//
					var IdocStatusFilter = [];
					for (var i = 0; i < filterResults.results.length; i++) {
						if (IdocStatusFilter.indexOf(filterResults.results[i].IdocStatus) === -1) {
							IdocStatusFilter.push(filterResults.results[i].IdocStatus);
						}
					}

					if (sap.ui.getCore().byId("IDocFilter") !== undefined) {
						sap.ui.getCore().byId("IDocFilter").setModel(new JSONModel(IdocStatusFilter), "IDocStatusModel");
					}
					//----Binded unique IDoc parentplant to filter fragment ----//
					var IdocParentFilter = [];
					for (var i = 0; i < filterResults.results.length; i++) {
						if (IdocParentFilter.indexOf(filterResults.results[i].Werks) === -1) {
							IdocParentFilter.push(filterResults.results[i].Werks);
						}
					}

					if (sap.ui.getCore().byId("IDocPlantFilter") !== undefined) {
						sap.ui.getCore().byId("IDocPlantFilter").setModel(new JSONModel(IdocParentFilter), "IDocPlantModel");
					}
					//----Binded unique IDoc Status Text to filter fragment----//
					/*	var IDocTextFilter = [];
					for (var i = 0; i < filterResults.results.length; i++) {
						if (IDocTextFilter.indexOf(filterResults.results[i].IdocStatxt) === -1) {
							IDocTextFilter.push(filterResults.results[i].IdocStatxt);
						}
					}

					if (sap.ui.getCore().byId("IDocTextFilter") !== undefined) {
						sap.ui.getCore().byId("IDocTextFilter").setModel(new JSONModel(IDocTextFilter), "IDocTextModel");
					}*/
					//----Binded unique Date Status Error to filter fragment----//
					/*	var ErrorDateFilter = [];
					for (var i = 0; i < filterResults.results.length; i++) {
						if (ErrorDateFilter.indexOf(filterResults.results[i].Logdat) === -1) {
							ErrorDateFilter.push(filterResults.results[i].Logdat);
						}
					}

					if (sap.ui.getCore().byId("ErrorDateFilter") !== undefined) {
						sap.ui.getCore().byId("ErrorDateFilter").setModel(new JSONModel(ErrorDateFilter), "ErrorDateModel");
					}
					//----Binded unique  time status error to filter fragment----//
					var ErrorTimeFitler = [];
					for (var i = 0; i < filterResults.results.length; i++) {
						if (ErrorTimeFitler.indexOf(filterResults.results[i].Logtim) === -1) {
							ErrorTimeFitler.push(filterResults.results[i].Logtim);
						}
					}

					if (sap.ui.getCore().byId("ErrorTimeFitler") !== undefined) {
						sap.ui.getCore().byId("ErrorTimeFitler").setModel(new JSONModel(ErrorTimeFitler), "ErrorTimeModel");
					}*/
				}

			},
			onPressExp: function(oEvent) {
				var oPanelId = oEvent.getSource().getParent().getParent().getId();
				var oButtonId = oEvent.getSource().getId();
				if (sap.ui.getCore().byId(oPanelId).getExpanded()) {
					sap.ui.getCore().byId(oPanelId).setExpanded(false);
					sap.ui.getCore().byId(oButtonId).setIcon("sap-icon://expand-group");
				} else {
					sap.ui.getCore().byId(oPanelId).setExpanded(true);
					sap.ui.getCore().byId(oButtonId).setIcon("sap-icon://collapse-group");
				}
			},
			onUpdateFinished: function(oEvent) {
				// var oModel = sap.ui.getCore().byId("IdocTable").getModel("IdocModel");
				// var data = oModel.getData().results;
				var oContext = sap.ui.getCore().byId("IdocTable").getItems();
				var data = oContext.map(function(ele) {
					return ele.getBindingContext("IdocModel").getObject();
				});
				if (data.length > 0) {
					/*	var delv = data.map(function(item) {
						return item.DocId;
					});

					var uniqueDelv = delv.filter(function(item, index) {
						return delv.indexOf(item) >= index;
					});
					console.log(uniqueDelv);*/
					var UniqueDeliveries = [];
					var successfilter = [];
					data.filter(function(item, i) {
						if (UniqueDeliveries.indexOf(data[i].DocId) === -1) {
							UniqueDeliveries.push(item.DocId);
						}
						if (item.DocId && item.ActualGiTime === "X") {
							successfilter.push(item.DocId);
						}

						return item.DocId && item.ActualGiTime === "X";
					});
					var sData = this.getView().getModel("ViewModel").getData();
					sData.NumberofDelv = UniqueDeliveries.length;
					sData.Success = successfilter.length;
					sData.Failed = UniqueDeliveries.length - successfilter.length;
					this.getView().getModel("ViewModel").refresh();

				}
			},
			handleRefreshButtonPressed: function(oEvent) {
				if (sap.ui.getCore().byId("IdocTable") !== undefined) {
					var oTable = sap.ui.getCore().byId("IdocTable");
					var oModel = oTable.getModel("IdocModel");
					var oTableBinding = oTable.getBinding("items");
					oTableBinding.aSorters = null;
					oTableBinding.aFilters = null;
					oModel.refresh(true);
				}
			}

		});
	});