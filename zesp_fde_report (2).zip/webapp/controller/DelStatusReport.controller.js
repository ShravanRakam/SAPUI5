var sInsPlantId;
var sInsUrl;
var sInsUserId;
var sInsHeadPlantId;
var sInsCdateId;
var sInsResult;
var sDateRange = [];
var sSourcePanelIds = [];
var sExpandIds = [];
var sButtonIds = [];
var sPlantNames = [];
var vRegion;
sap.ui.define([
		"sap/ui/core/mvc/Controller",
		"sap/m/Panel",
		"sap/ui/model/json/JSONModel",
		"sap/ui/model/Filter",
		"sap/ui/model/Sorter",
		"sap/m/MessageBox",
		"sap/ui/layout/Grid",
		'sap/ui/Device',
		"sap/ui/core/util/Export",
		"sap/ui/core/util/ExportTypeCSV",
		"com/report/model/formatter",
		"sap/ui/model/FilterOperator"
	],
	function(Controller, Panel, JSONModel, Filter, Sorter, MessageBox, Grid, Device, Export, ExportTypeCSV, formatter, FilterOperator) {
		"use strict";
		return Controller.extend("com.report.controller.DelStatusReport", {
			formatter: formatter,
			onInit: function() {

				jQuery.sap.require("jquery.sap.storage");
				// Keeps reference to any of the created sap.m.ViewSettingsDialog-s in this sample
				this._mViewSettingsDialogs = {};

				var oModel = {
					PlannedCount: this.getResourceBundle().getProperty("sPlannedCount"),
					ActiveCount: this.getResourceBundle().getProperty("sActiveCount"),
					ArrivedCount: this.getResourceBundle().getProperty("sArrivedCount"),
					PreloadedCount: this.getResourceBundle().getProperty("sPreloadedCount"),
					PreloadedFlag: this.getResourceBundle().getProperty("sPreloadedFlag"),
					CompletedCount: this.getResourceBundle().getProperty("sCompletedCount"),
					tableBusyDelay: 0,
					ParentPlant: jQuery.sap.storage(jQuery.sap.storage.Type.local).get("ParentPlant")
				};
				var oViewModel = new JSONModel(oModel);
				this.getView().setModel(oViewModel, "ViewModel");
				var oRouter = sap.ui.core.UIComponent.getRouterFor(this);
				oRouter.getRoute("DelStatusReport").attachMatched(this._onRouteMatched, this);
				var that = this;
				var sStartup = "/sap/bc/ui2/start_up";
				var xmlHttp = null;
				xmlHttp = new XMLHttpRequest();
				xmlHttp.onreadystatechange = function() {
					if (xmlHttp.readyState === 4 && xmlHttp.status === 200) {
						var oUserData = JSON.parse(xmlHttp.responseText);
						var sInsLoggedUser = oUserData.id;
						that.fnGetHeaderDetails(sInsLoggedUser);
					}
				};
				xmlHttp.open("GET", sStartup, false);
				xmlHttp.send(null);

				var oDesktopDevice = sap.ui.Device.system.desktop;
				if (oDesktopDevice === true) {
					//Desktop Title Bar
					var oTitleBar = sap.ui.xmlfragment(this.createId("Header_Desktop_Bar_ID"), "com.report.fragments.DesktopHeader", this);
					this.getView().addDependent(oTitleBar);
					this.getView().byId("StatusReportPage").addContent(oTitleBar);
					sInsUserId = "Header_Desktop_Bar_ID--userName";
					sInsHeadPlantId = "Header_Desktop_Bar_ID--plantName";
					sInsCdateId = "Header_Desktop_Bar_ID--cDate";
					/*_______________ making visible false for settings icon in the fragment ______________*/
					this.getView().byId("Header_Desktop_Bar_ID--Settings").setVisible(false);
				} else {
					//Mobile Title Bar
					var oTitleMobBar = sap.ui.xmlfragment(this.createId("Header_Mobile_Bar_ID"), "com.report.fragments.MobileHeader", this);
					this.getView().addDependent(oTitleMobBar);
					this.getView().byId("StatusReportPage").addContent(oTitleMobBar);
					sInsUserId = "Header_Mobile_Bar_ID--userName1";
					sInsHeadPlantId = "Header_Mobile_Bar_ID--plantName1";
					sInsCdateId = "Header_Mobile_Bar_ID--cDate1";
					/*_______________ making visible false for settings icon in the fragment ______________*/
					this.getView().byId("Header_Mobile_Bar_ID--Settings").setVisible(false);
				}
				// ----------------------------------------------------------------------------------
				//                  		To get the clock
				// ----------------------------------------------------------------------------------

				setInterval(function() {
					var oTimeZone = jQuery.sap.storage(jQuery.sap.storage.Type.local).get("sTimeZone");
					var oDayLightSaving = jQuery.sap.storage(jQuery.sap.storage.Type.local).get("sDayLightSaving");
					var oFlag = jQuery.sap.storage(jQuery.sap.storage.Type.local).get("sFlag");
					// var oFlag = true;

					if (oFlag === false || oFlag === "false" || oFlag === null || oFlag === undefined) {
						var resultBrowser = that.realDateTimeClockBrowser();

						if (that.byId(sInsCdateId) !== undefined) {
							that.byId(sInsCdateId).setText(resultBrowser);
						}

					} else if (oFlag === true || oFlag === "true") {

						var realClock = that.realDateTimeClock(oTimeZone, oDayLightSaving);
						if (that.byId(sInsCdateId) !== undefined) {
							that.byId(sInsCdateId).setText(realClock);
						}
					}

				}, 1000);

				/*	setInterval(function() {
						var realClock = that.realDateTimeClock();
						if (that.byId(sInsCdateId) !== undefined) {
							that.byId(sInsCdateId).setText(realClock);
						}
					}, 1000);*/

			},

			realDateTimeClockBrowser: function() {
				var dateObject = new Date();
				var dateFormat = sap.ui.core.format.DateFormat.getDateInstance({
					style: 'full',
					pattern: "EEEE, MMMM dd, YYYY hh:mm:ss a"
				});
				// Format the date
				var dateFormatted = dateFormat.format(dateObject);
				return dateFormatted;
			},

			realDateTimeClock: function(TimeZone, DayLightSaving) {
				var that = this;

				/*	var sData = that.getView().getModel("HeaderDetailsPlant").getData();
				var TimeZone = sData.UTC_DIFF;
				var DayLightSaving = sData.DST_DIFF;*/

				var timeZoneOutput = [TimeZone.slice(0, 3), ":", TimeZone.slice(3, 5)].join('');

				if (DayLightSaving === "") {
					DayLightSaving = "0";
				}

				// var DayLightSavingOutput = [DayLightSaving.slice(0, 2), ":", DayLightSaving.slice(2, 4)].join('');

				if (timeZoneOutput.startsWith("-")) {
					var concatTimeZoneDayLight = parseInt(TimeZone.slice(1, 3)) - parseInt(DayLightSaving.slice(0, 2));
				} else if (timeZoneOutput.startsWith("+")) {
					var concatTimeZoneDayLight = parseInt(TimeZone.slice(1, 3)) + parseInt(DayLightSaving.slice(0, 2));
				}

				var finalOffset = [TimeZone.slice(0, 1), concatTimeZoneDayLight, ":", TimeZone.slice(3, 5)].join('');

				var _now = new Date();

				//var timeZoneOutput = "+11:00";
				var date = that.timezoneShifter(_now, finalOffset);

				var resultDate = that.formatTimeClock(date);
				return resultDate;
			},

			timezoneShifter: function(date, timezone) {

				var isBehindGTM = false;
				if (timezone.startsWith("-")) {
					timezone = timezone.substr(1);
					isBehindGTM = true;
				}

				var hDiff = timezone.split(":").map(myFunction);

				function myFunction(t) {
					return parseInt(t);
				}

				var value = isBehindGTM ? 1 : -1;
				var diff = (hDiff[0] * 60 + hDiff[1]) * value;
				var currentDiff = new Date().getTimezoneOffset();

				return new Date(date.valueOf() + (currentDiff - diff) * 60 * 1000);
			},

			formatTimeClock: function(_now) {
				var dateObject = _now;
				var dateFormat = sap.ui.core.format.DateFormat.getDateInstance({
					style: 'full',
					pattern: "EEEE, MMMM dd, YYYY hh:mm:ss a"
				});
				// Format the date
				var dateFormatted = dateFormat.format(dateObject);
				return dateFormatted;
			},

			//----------------------------------------------------------------------------------
			//Function to get Header details
			//----------------------------------------------------------------------------------
			fnGetHeaderDetails: function(sInsLoggedUser) {
				var that = this;
				that.fnCreateBusyDialog("pallet.svg", true);
				sInsUrl = "/sap/opu/odata/sap/ZGW_ACTIVITY_SRV";
				var oHeaderModel = new sap.ui.model.odata.ODataModel(sInsUrl);
				oHeaderModel.read("/HeaderDetailsSet('" + sInsLoggedUser + "') ", null, null,
					true,
					function(oData, oResponse) {
						if (oResponse.statusCode === 200) {
							var oODataJSONModel2 = new sap.ui.model.json.JSONModel();
							oODataJSONModel2.setData(oData);
							if (that.byId(sInsUserId) !== undefined) {
								that.byId(sInsUserId).setText(oData.Firstname + " " + oData.Lastname); // Binding the user name
							}
							if (that.byId(sInsHeadPlantId) !== undefined) {
								that.byId(sInsHeadPlantId).setText(oData.Plant + "-" + oData.Name1); // Binding the plant name
							}
							sInsPlantId = oData.Plant;
						}
						that.oCreateDailog.close();
					},
					function() {
						that.oCreateDailog.close();
					});
			},

			//----------------------------------------------------------------------------------
			//Function to create Busy Dialog
			//----------------------------------------------------------------------------------
			fnCreateBusyDialog: function(sImage) {
				this.oCreateDailog = new sap.m.Dialog({
					showHeader: false
				}).addStyleClass("busyDialog sapUiTinyMargin");
				var sComponentName = this.getOwnerComponent().getMetadata().getComponentName();
				var imgUrl = $.sap.getModulePath(sComponentName, "/images/");
				var oImage = new sap.m.Image().addStyleClass("sapUiMediumMargin");
				oImage.setSrc(imgUrl + sImage);
				this.oCreateDailog.addContent(oImage);
				this.oCreateDailog.open();

			},

			onNavButtonPress: function() {
				var reportModel = this.getView().getModel("StatusReportModel");
				if (reportModel !== undefined) {
					reportModel.destroy();
				}
				var oRouter = sap.ui.core.UIComponent.getRouterFor(this);
				oRouter.navTo("ReportInter");
			},
			//---
			_onRouteMatched: function(oEvent) {
				var that = this;
				SVGElement.prototype.getTransformToElement = SVGElement.prototype.getTransformToElement || function(elem) {
					return elem.getScreenCTM().inverse().multiply(this.getScreenCTM());
				};

				var oArgs = oEvent.getParameter("arguments");
				sPlantNames = oArgs.Plants.split(",");
				sDateRange = oArgs.DateRange.split(",");

				//Setting the selected report as page title 
				// this.byId("StatusReportPage").setTitle(oArgs.reportname);

				var oPlantsVBox = that.byId("plantsVBox");
				if (oPlantsVBox !== undefined) {
					oPlantsVBox.destroy();
				}

				// var dDateForm = sDateRange[0].slice(6, 10) + sDateRange[0].slice(0, 2) + sDateRange[0].slice(3, 5);
				// var dDateTo = sDateRange[1].slice(6, 10) + sDateRange[1].slice(0, 2) + sDateRange[1].slice(3, 5);
				var dDateForm = sDateRange[0].slice(0, 4) + sDateRange[0].slice(5, 7) + sDateRange[0].slice(8, 10);
				var dDateTo = sDateRange[1].slice(0, 4) + sDateRange[1].slice(5, 7) + sDateRange[1].slice(8, 10);
				// var sInpDates = dDateForm + "," + dDateTo;

				sInsPlantId = oArgs.Plants;

				var oVBox = new sap.m.VBox(this.createId("plantsVBox"), {
					items: [
						new sap.m.Bar(this.createId("DateRange"), {
							contentMiddle: [
								new sap.m.Label(this.createId("onFrom"), {
									text: "{i18n>dateRange}",
									design: "Bold"
								}).addStyleClass("from"),
								new sap.m.Label(this.createId("onDateFrom"), {

								}).addStyleClass("fromData"),
								new sap.m.Label(this.createId("onTo"), {
									design: "Bold",
									text: "{i18n>to}"
								}).addStyleClass("to"),
								new sap.m.Label(this.createId("onDateTo"), {}).addStyleClass("toValue")
							]
						}),
						new sap.m.HBox({
							items: [
								new sap.m.Label({
									design: "Bold",
									text: "{i18n>LabelPlant}" //"Plants:"
								}).addStyleClass("sapUiTinyMarginTop sapUiSmallMargin"),
								new sap.m.Text({
									design: "Bold",
									text: sInsPlantId //"Plants:"
								}).addStyleClass("sapUiTinyMarginTop sapUiSmallMargin")
							]
						})

					]
				}).addStyleClass("sapUiSizeCompact printClass");

				//Adding the panels for the page
				var oBox = this.byId("StatusReportPage");
				oBox.addContent(oVBox);

				this.byId("onDateFrom").setText(sDateRange[0]);
				this.byId("onDateTo").setText(sDateRange[1]);
				if (sDateRange[1] === "") {
					this.byId("onTo").setVisible(false);
				} else {
					this.byId("onTo").setVisible(true);
				}
				// this.fnCreateBusyDialog("pallet.svg");
				var busydialog = new sap.m.BusyDialog({
					text: "{i18n>pleaseWait}",
					showCancelButton: true
				});
				busydialog.open();
				vRegion = jQuery.sap.storage(jQuery.sap.storage.Type.local).get("region");
				var DelService = "/sap/opu/odata/sap/ZGW_DELIVERY_STATUS_RPT_SRV/";
				var DeliveryReportModel = new sap.ui.model.odata.ODataModel(DelService);
				DeliveryReportModel.read("/StatusSet?$filter=Plant eq '" + sInsPlantId + "' and Fdate eq '" + dDateForm + "' and Tdate  eq '" +
					dDateTo + "'", {
						success: function(oData, oResponse) {
							if (oResponse.statusCode === 200 || oResponse.statusCode === "200") {
								var resLength = oData.results.length;
								if (resLength < 1) {
									var oStatusReportModel = new JSONModel(oData);
									that.getView().setModel(oStatusReportModel, "StatusReportModel");
									var bCompact = !!that.getView().$().closest(".sapUiSizeCompact").length;
									var noRecordFound = that.getOwnerComponent().getModel("i18n").getProperty('noRecordFound');
									MessageBox.error(
										noRecordFound, {
											styleClass: bCompact ? "sapUiSizeCompact" : ""
										});
									// that.oCreateDailog.close();
									busydialog.close();
								} else {

									for (var k = 0; k < resLength; k++) {
										oData.results[k].Region = vRegion;
									}

									var oStatusReportModel = new JSONModel(oData);
									oStatusReportModel.setSizeLimit(resLength);
									that.getView().setModel(oStatusReportModel, "StatusReportModel");
									// that.oCreateDailog.close();
									busydialog.close();
								}
							}
						},
						error: function(oError) {

							var oMessage;
							if (oMessage === undefined) {
								oMessage = $(oError.response.body).find('message').first().text();
							}
							var bCompact = !!that.getView().$().closest(".sapUiSizeCompact").length;
							MessageBox.show(
								oMessage, {
									icon: sap.m.MessageBox.Icon.ERROR,
									title: "{i18n>error}",
									styleClass: bCompact ? "sapUiSizeCompact" : ""

								});
							// that.oCreateDailog.close();
							busydialog.close();
						}
					});

				// sap.ui.getCore().byId("Settings").setVisible(false);

				that.onTabsPress();
			},

			getResourceBundle: function() {
				return this.getOwnerComponent().getModel("i18n");
			},

			//----------------------------------------------------------------------------------------
			// Function for viewing the plant details in Tab View
			//-----------------------------------------------------------------------------------------
			onTabsPress: function() {
				var that = this;
				// that.fnCreateBusyDialog("pallet.svg");

				var aTabId = this.byId("TabLayout");
				if (aTabId !== undefined) {
					aTabId.destroy();
				}
				// var oGridLayout = new sap.ui.layout.Grid(this.getView().createId("panelGrid"),{content:[]});
				var sPlantReport = sap.ui.xmlfragment("com.report.fragments.DeliveryReportTab", this);
				var oGridLayout = new sap.ui.layout.Grid(this.createId("TabLayout"), {
					defaultSpan: "L12 M12 S12",
					content: [sPlantReport]
				});
				this.getView().byId("StatusReportPage").addContent(oGridLayout);
				// this.oCreateDailog.open();
			},
			//-----------------------------------------------------------------------------------------
			// Function for expanding the pnales inside the plant panels
			//-----------------------------------------------------------------------------------------
			onPressExpandOrCollapse: function(oEvent) {
				var oPanelId = oEvent.getSource().getParent().getParent().getId();
				var oButtonId = oEvent.getSource().getId();
				if (sap.ui.getCore().byId(oPanelId).getExpanded()) {
					sap.ui.getCore().byId(oPanelId).setExpanded(false);
					sap.ui.getCore().byId(oButtonId).setIcon("sap-icon://expand-group");
				} else {
					sap.ui.getCore().byId(oPanelId).setExpanded(true);
					sap.ui.getCore().byId(oButtonId).setIcon("sap-icon://collapse-group");
				}
			},
			onPlannedTableUpdateFinsihed: function(oEvent) {
				var CountPlanned = 0;
				var ViewModel = this.getView().getModel("ViewModel");
				var plannedItemsCount = oEvent.getParameter("total");
				if (plannedItemsCount > 0) {
					ViewModel.setProperty("/PlannedCount", plannedItemsCount);
				} else {
					ViewModel.setProperty("/PlannedCount", CountPlanned);
				}

				var myFilters = new Filter({
					filters: [
						new Filter({
							path: 'Delstatus',
							operator: FilterOperator.Contains,
							value1: 'Planned'
						}),
						new Filter({
							path: 'Delstatus',
							operator: FilterOperator.Contains,
							value1: 'Cancelled'
						})

					]

				});
				var table = sap.ui.getCore().byId("PlannedTable");
				var binding = table.getBinding("items");
				binding.filter(myFilters, sap.ui.model.FilterType.Application);

			},
			onActiveTableUpdateFinsihed: function(oEvent) {

				var CountActive = 0;
				var ViewModel = this.getView().getModel("ViewModel");
				var ActiveItemsCount = oEvent.getParameter("total");
				if (ActiveItemsCount > 0) {
					ViewModel.setProperty("/ActiveCount", ActiveItemsCount);
				} else {
					ViewModel.setProperty("/ActiveCount", CountActive);
				}
			},
			onPreloadTableUpdateFinsihed: function(oEvent) {

				var CountPreload = 0;
				var ViewModel = this.getView().getModel("ViewModel");
				var PreloadItemsCount = oEvent.getParameter("total");
				if (PreloadItemsCount > 0) {
					// getting preloaded flag value ---to make  visibility of Preloaded Icontabbar
					var PreloadFlag = oEvent.getSource().getModel("StatusReportModel").getProperty("/results/0/Preloaded");
					ViewModel.setProperty("/PreloadedCount", PreloadItemsCount);
					ViewModel.setProperty("/PreloadedFlag", PreloadFlag);
				} else {
					ViewModel.setProperty("/PreloadedCount", CountPreload);
					ViewModel.setProperty("/PreloadedFlag", "");
				}
			},
			onArrivedTableUpdateFinsihed: function(oEvent) {

				var CountArrived = 0;
				var ViewModel = this.getView().getModel("ViewModel");
				var ArrivedItemsCount = oEvent.getParameter("total");
				if (ArrivedItemsCount > 0) {
					ViewModel.setProperty("/ArrivedCount", ArrivedItemsCount);
				} else {
					ViewModel.setProperty("/ArrivedCount", CountArrived);
				}
			},
			onCompletedTableUpdateFinsihed: function(oEvent) {

				var CountCompleted = 0;
				var ViewModel = this.getView().getModel("ViewModel");
				var CompletedItemsCount = oEvent.getParameter("total");
				if (CompletedItemsCount > 0) {
					ViewModel.setProperty("/CompletedCount", CompletedItemsCount);
				} else {
					ViewModel.setProperty("/CompletedCount", CountCompleted);
				}
			},
			createViewSettingsDialog: function(sDialogFragmentName, sKey) {
				var oDialog = this._mViewSettingsDialogs[sDialogFragmentName];

				if (oDialog) {
					if (this._currentItemTab !== sKey) {
						oDialog.fireResetFilters(new sap.ui.base.Event());
					}
					// var oEvent = new sap.ui.base.Event();
					// oDialog.attachEventOnce("resetFilters",this.onResetFilters(oEvent));
				}
				if (!oDialog) {
					oDialog = sap.ui.xmlfragment(sDialogFragmentName, this);
					this._mViewSettingsDialogs[sDialogFragmentName] = oDialog;
					var i18nModel = this.getOwnerComponent().getModel("i18n");
					/*var i18nModel = new sap.ui.model.resource.ResourceModel({
						bundleUrl: "i18n/i18n.properties"
					});*/
					oDialog.setModel(i18nModel, "i18n");
					/*** adding filter items for the multiplant/parentplant scenario ***/
					var parentplant = this.getView().getModel("ViewModel").getProperty("/ParentPlant");
					if (parentplant !== "") {
						if (sap.ui.getCore().byId("DelStatusPlantFilter") === undefined) {
							var ParentPlantFilter = new sap.m.ViewSettingsFilterItem("DelStatusPlantFilter", {
								multiSelect: true,
								text: "{i18n>Plant}"

							});
							var Template = new sap.m.ViewSettingsItem({
								key: "Plant___EQ___{sParentPlant>}",
								text: "{sParentPlant>}"
							});
							ParentPlantFilter.bindAggregation("items", "sParentPlant>/", Template);
							oDialog.addFilterItem(ParentPlantFilter);
						}
					}
					// if (Device.system.desktop) {
					// 	oDialog.addStyleClass("sapUiSizeCompact");
					// }
				}
				return oDialog;
			},
			handleSortButtonPressed: function() {
				this.createViewSettingsDialog("com.report.fragments.DeliverySorterDialog").open();

			},

			handleFilterButtonPressed: function() {
				var sKey = sap.ui.getCore().byId("IconTabBarID").getSelectedKey();
				this.createViewSettingsDialog("com.report.fragments.DeliveryFilterDialog", sKey).open();
				this.loadFiltersData(sKey);
			},
			handleSortDialogConfirm: function(oEvent) {
				var oTable = sap.ui.getCore().byId("PlannedTable"),
					mParams = oEvent.getParameters(),
					oBinding = oTable.getBinding("items"),
					sPath,
					bDescending,
					aSorters = [];

				sPath = mParams.sortItem.getKey();
				bDescending = mParams.sortDescending;
				aSorters.push(new Sorter(sPath, bDescending));

				// apply the selected sort and group settings
				if (oBinding !== undefined) {
					oBinding.sort(aSorters);
				}
			},
			handleFilterDialogConfirm: function(oEvent) {
				var sKey = sap.ui.getCore().byId("IconTabBarID").getSelectedKey(),
					mParams = oEvent.getParameters(),
					oBinding = sap.ui.getCore().byId(sKey).getBinding("items"),
					aFilters = [];
				this._currentItemTab = sKey;
				mParams.filterItems.forEach(function(oItem) {
					var aSplit = oItem.getKey().split("___"),
						sPath = aSplit[0],
						sOperator = aSplit[1],
						sValue1 = aSplit[2],
						sValue2 = aSplit[3],
						oFilter = new Filter(sPath, sOperator, sValue1, sValue2);
					aFilters.push(oFilter);
				});

				// apply filter settings
				if (oBinding !== undefined) {
					oBinding.filter(aFilters, sap.ui.model.FilterType.Control);

					// update filter bar
					sap.ui.getCore().byId(sKey + "InfoToolBar").setVisible(aFilters.length > 0);
					sap.ui.getCore().byId(sKey + "InfoLabel").setText(mParams.filterString);

				}
			},
			loadFiltersData: function(sKey) {
				var Model = sap.ui.getCore().byId(sKey).getModel("StatusReportModel");
				if (Model !== undefined) {
					var filterResults = Model.getData();

					//----Binded unique data of Order Types to filter fragment----//
					var sOrderTypeFilter = [];
					for (var k = 0; k < filterResults.results.length; k++) {
						if (sOrderTypeFilter.indexOf(filterResults.results[k].Ordtype) === -1) {
							sOrderTypeFilter.push(filterResults.results[k].Ordtype);
						}
					}
					if (sap.ui.getCore().byId("orderTypeModel") !== undefined) {
						sap.ui.getCore().byId("orderTypeModel").setModel(new JSONModel(sOrderTypeFilter), "orderTypeModel");
					}

					//----Binded unique data of Product Codes to filter fragment----//
					var ProdCodeFilter = [];
					for (var i = 0; i < filterResults.results.length; i++) {
						if (ProdCodeFilter.indexOf(filterResults.results[i].Prodcode) === -1) {
							ProdCodeFilter.push(filterResults.results[i].Prodcode);
						}
					}
					if (sap.ui.getCore().byId("ProdCodeFilter") !== undefined) {
						sap.ui.getCore().byId("ProdCodeFilter").setModel(new JSONModel(ProdCodeFilter), "ProdCodeModel");
					}

					//----Binded unique Batch Id's  to filter fragment----//
					var BatchCodes = [];
					for (var i = 0; i < filterResults.results.length; i++) {
						if (BatchCodes.indexOf(filterResults.results[i].Charg) === -1) {
							BatchCodes.push(filterResults.results[i].Charg);
						}
					}

					if (sap.ui.getCore().byId("BatchIDFilter") !== undefined) {
						sap.ui.getCore().byId("BatchIDFilter").setModel(new JSONModel(BatchCodes), "BatchNamesModel");
					}
					//----Binded unique Delivery Numbers to filter fragment----//
					var DeliveryNum = [];
					for (var i = 0; i < filterResults.results.length; i++) {
						if (DeliveryNum.indexOf(filterResults.results[i].Vbeln) === -1) {
							DeliveryNum.push(filterResults.results[i].Vbeln);
						}
					}

					if (sap.ui.getCore().byId("DeliveryNumFilter") !== undefined) {

						var sNewModel = new JSONModel(DeliveryNum);
						sNewModel.setSizeLimit(DeliveryNum.length);
						sap.ui.getCore().byId("DeliveryNumFilter").setModel(sNewModel, "DeliveryNumbersModel");
					}
					//----Binded unique Customer Id's  to filter fragment----//
					var CustomerNames = [];
					for (var i = 0; i < filterResults.results.length; i++) {
						if (CustomerNames.indexOf(filterResults.results[i].Lifnr) === -1) {
							CustomerNames.push(filterResults.results[i].Lifnr);
						}
					}

					if (sap.ui.getCore().byId("CustIDFilter") !== undefined) {
						sap.ui.getCore().byId("CustIDFilter").setModel(new JSONModel(CustomerNames), "CustNamesModel");
					}
					//----Binded unique Carrier Names  to filter fragment----//
					var CarrierNames = [];
					for (var i = 0; i < filterResults.results.length; i++) {
						if (CarrierNames.indexOf(filterResults.results[i].Carrier) === -1) {
							CarrierNames.push(filterResults.results[i].Carrier);
						}
					}

					if (sap.ui.getCore().byId("CarrNameFilter") !== undefined) {
						sap.ui.getCore().byId("CarrNameFilter").setModel(new JSONModel(CarrierNames), "CarrierNamesModel");
					}
					//----Binded unique Planned GI dates to filter fragment----//
					var PlannedGIdt = [];
					for (var i = 0; i < filterResults.results.length; i++) {

						if (PlannedGIdt.indexOf(filterResults.results[i].Wadat) === -1) {
							PlannedGIdt.push(filterResults.results[i].Wadat);
						}
					}

					if (sap.ui.getCore().byId("PlannedGIFilter") !== undefined) {
						sap.ui.getCore().byId("PlannedGIFilter").setModel(new JSONModel(PlannedGIdt), "GoodsIssueDateModel");
					}
					//----Binded unique Appointment times to filter fragment----//
					var ApptmntTime = [];
					for (var i = 0; i < filterResults.results.length; i++) {
						if (ApptmntTime.indexOf(filterResults.results[i].Apptime) === -1) {
							ApptmntTime.push(filterResults.results[i].Apptime);
						}
					}

					if (sap.ui.getCore().byId("AppTimeFilter") !== undefined) {
						sap.ui.getCore().byId("AppTimeFilter").setModel(new JSONModel(ApptmntTime), "AppTimeModel");
					}
					//----Binded unique data of parent plant to filter fragment----//
					var ParentPlant = [];
					for (var i = 0; i < filterResults.results.length; i++) {
						if (ParentPlant.indexOf(filterResults.results[i].Plant) === -1) {
							ParentPlant.push(filterResults.results[i].Plant);
						}
					}
					if (sap.ui.getCore().byId("DelStatusPlantFilter") !== undefined) {
						sap.ui.getCore().byId("DelStatusPlantFilter").setModel(new JSONModel(ParentPlant), "sParentPlant");
					}

				}
			},
			onResetFilters: function(oEvent) {
				console.log(oEvent);
				var source = oEvent.getSource(),
					filters = source.getSelectedFilterItems(),
					// aFilterItems = source.getFilterItems(),
					customControl,
					customFilter,
					i = 0;
				// this functionality only needed because custom control is cloned for this test page
				// if you don't have cloned controls you can directly access them by id and set/reset the values
				/*	for(; i < filters.length; i++) {
				if(filters[i] instanceof sap.m.ViewSettingsCustomItem && filters[i].getKey() === "myPriceFilter") {
					customFilter = filters[i];
					customControl = customFilter.getCustomControl();
					break;
				}
			}*/
				/*	aFilterItems.forEach(function(item) {
						var aItems = item.getItems();
						aItems.forEach(function(item) {
							item.setSelected(false);
						});
					});*/
				// if(customFilter) {
				for (; i < filters.length; i++) {
					customFilter = filters[i];
					customFilter.setSelected(false);

				}
			},
			handleRefreshButtonPressed: function() {

				var sKey = sap.ui.getCore().byId("IconTabBarID").getSelectedKey();
				var oBinding = sap.ui.getCore().byId(sKey).getBinding("items"),
					aFilters = [];
				// apply filter settings
				if (oBinding !== undefined) {
					oBinding.filter(aFilters, sap.ui.model.FilterType.Control);
					sap.ui.getCore().byId(sKey + "InfoToolBar").setVisible(aFilters.length > 0);
					sap.ui.getCore().byId(sKey + "InfoLabel").setText(null);

					var FilterDilaog = sap.ui.getCore().byId("filterDialogId");
					var filters = FilterDilaog.getSelectedFilterItems();
					for (var i = 0; i < filters.length; i++) {
						filters[i].setSelected(false);
					}
				}
			},

			onPressExcelSheetExport: sap.m.Table.prototype.exportData || function() {
				var getTableData = sap.ui.getCore().byId("PlannedTable").getModel("StatusReportModel");
				var getHeaderText = this.getOwnerComponent().getModel("i18n");
				var oExport = new Export({
					exportType: new ExportTypeCSV({
						separatorChar: ",",
						fileExtension: "csv"
						// mimeType: "application/vnd.ms-excel",
						// charset: "utf-8"
					}),
					models: getTableData,
					rows: {
						path: "/results"
					},
					columns: [{
						name: getHeaderText.getProperty("table.header.label.OrderType"),
						template: {
							content: {
								parts: ["Ordtype", "DelvType"],
								//ctrm 1297
								formatter: function(orderType, DelvType) {
									if (DelvType === "" || DelvType === undefined) {
											if ((orderType === "SAPI")) {
												return "Issue";
											} else if (orderType === "STOI") {
												return "STO-Issue";
											} else if (orderType === "SAPR") {
												return "Return";
											} else if (orderType === "STOR") {
												return "STO-Return";
											} else if (orderType === "PORAW") {
												return "Raw Material PO";
											}
										} else {
											return DelvType;
										}
								}
							}
						}
					}, {
						name: getHeaderText.getProperty("table.header.label.DeliveryNumber"),
						template: {
							content: "{Vbeln}"
						}
					}, {
						name: getHeaderText.getProperty("table.header.label.ProdCode"),
						template: {
							content: "{Prodcode}"
						}
					}, {
						name: getHeaderText.getProperty("table.header.label.BatchId"),
						template: {
							content: "{Charg}"
						}
					}, {
						name: getHeaderText.getProperty("table.header.label.CustomerName"),
						template: {
							content: "{Lifnr}"
						}
					}, {
						name: getHeaderText.getProperty("table.header.label.CarrierName"),
						template: {
							content: "{Carrier}"
						}
					}, {
						name: getHeaderText.getProperty("table.header.label.GI_Date"),

						template: {
							content: {
								parts: ["Wadat", "Region"],
								formatter: function(dt, region) {
									if (dt !== null) {
										if (region === "EU" || region === "LATAM" || region === "ZA") {
											if (dt !== "00000000") {
												var sDate = dt.slice(6, 8) + "/" + dt.slice(4, 6) + "/" + dt.slice(0, 4);
												return sDate;
											} else {
												return "";
											}
										} else {
											var date = dt.slice(0, 4) + "," + dt.slice(4, 6) + "," + dt.slice(6, 8);
											var localtime = new Date(date);
											var dateFormat = sap.ui.core.format.DateFormat.getDateInstance({
												pattern: "dd MMM YYYY"
											});
											var dateFormatted = dateFormat.format(new Date(localtime));
											return dateFormatted;
										}
									}
								}

							}
						}
					}, {
						name: getHeaderText.getProperty("table.header.label.AppointmentTime"),
						template: {
							// content: "{Apptime}"
							content: {
								parts: ["Apptime", "Region"],
								formatter: function(appTime, region) {
									if (appTime !== null) {
										appTime = appTime.trim();
										if (region === "EU" || region === "LATAM" || region === "ZA") {
											if ((appTime === "0") || (appTime === 0)) {
												return 0;
											} else if (appTime !== null && appTime !== "0" && appTime !== undefined) {
												var newAppointmentTime = appTime.slice(6, 8) + "/" + appTime.slice(4, 6) + "/" + appTime.slice(0, 4) + " " +
													appTime.slice(
														8, 10) + ":" + appTime.slice(10, 12) + ":" + appTime.slice(12, 14);
												return newAppointmentTime;
											}
										} else {
											if ((appTime === "0") || (appTime === 0)) {
												return 0;
											} else if (appTime !== null && appTime !== "0" && appTime !== undefined) {
												var newAppointmentTime = appTime.slice(4, 6) + "/" + appTime.slice(6, 8) + "/" + appTime.slice(0, 4) + " " +
													appTime.slice(
														8, 10) + ":" + appTime.slice(10, 12) + ":" + appTime.slice(12, 14);
												return newAppointmentTime;
											}
										}
									}
								}
							}
						}
					}, {
						name: getHeaderText.getProperty("table.header.label.totalQty"),
						template: {
							content: {
								parts: ["Zmeng"],
								type: sap.ui.model.type.Integer
							}
						}
					}, {
						name: getHeaderText.getProperty("table.header.label.Status"),
						template: {
							content: "{Delstatus}"
						}
					}, {
						name: getHeaderText.getProperty("checkInSys"),
						template: {
							content: "{CheckInSystem}"
						}
					}, {
						name: getHeaderText.getProperty("checkOutSys"),
						template: {
							content: "{CheckOutSystem}"
						}
					}, {
						name: getHeaderText.getProperty("CustRej"),
						template: {
							content: {
								parts: ["CustomerRejection"],
								//ctrm 1392
								formatter: function(CR) {
									if (CR === "X") {
										return "Y";
									} else if (CR === undefined || CR === "") {
										return "";
									} else {
										return "";
									}
								}
							}
						}
					}]
				});
				/*var today = new Date();
				var dd = today.getDate();
				var mm = today.getMonth() + 1; //January is 0!
				var yyyy = today.getFullYear();

				if (dd < 10) {
					dd = '0' + dd;
				}

				if (mm < 10) {
					mm = '0' + mm;
				}

				today = yyyy + '-' + mm + '-' + dd;*/

				/*** add this column only when parentplant is active ***/
				var parentplant = this.getView().getModel("ViewModel").getProperty("/ParentPlant");
				if (parentplant !== "") {
					oExport.insertColumn(new sap.ui.core.util.ExportColumn({
						name: this.getOwnerComponent().getModel("i18n").getProperty("Plant"),
						template: {
							content: "{Plant}"
						}
					}), 0);
				}

				var sdelStatRep = this.getOwnerComponent().getModel("i18n").getProperty("delStatRep");
				oExport.saveFile(sdelStatRep).catch(function(
					oError) {
					MessageBox.error("Error while exporting data. Browser might not be supported!\n\n" + oError);
				}).then(function() {
					oExport.destroy();
				});
			},

			onPressExcelSheetExportXLS: sap.m.Table.prototype.exportData || function() {
				var getTableData = sap.ui.getCore().byId("PlannedTable").getModel("StatusReportModel");
				var getHeaderText = this.getOwnerComponent().getModel("i18n");
				var oExport = new Export({
					exportType: new ExportTypeCSV({
						separatorChar: "\t",
						fileExtension: "xls"
						// mimeType: "application/vnd.ms-excel",
						// charset: "utf-8"
					}),
					models: getTableData,
					rows: {
						path: "/results"
					},
					columns: [{
							name: getHeaderText.getProperty("table.header.label.OrderType"),
							template: {
								content: {
									parts: ["Ordtype", "DelvType"],
									formatter: function(orderType, DelvType) {
										if (DelvType === "") {
											if ((orderType === "SAPI") || (orderType === "STOI")) {
												return "Issue";
											} else {
												return "Return";
											}

										} else {
											return DelvType;
										}
									
									}
								}
							}
						}, {
							name: getHeaderText.getProperty("table.header.label.DeliveryNumber"),
							template: {
								content: "{Vbeln}"
							}
						}, {
							name: getHeaderText.getProperty("table.header.label.ProdCode"),
							template: {
								content: "{Prodcode}"
							}
						}, {
							name: getHeaderText.getProperty("table.header.label.BatchId"),
							template: {
								content: "{Charg}"
							}
						}, {
							name: getHeaderText.getProperty("table.header.label.CustomerName"),
							template: {
								content: "{Lifnr}"
							}
						}, {
							name: getHeaderText.getProperty("table.header.label.CarrierName"),
							template: {
								content: "{Carrier}"
							}
						}, {
							name: getHeaderText.getProperty("table.header.label.GI_Date"),

							template: {
								content: {
									parts: ["Wadat", "Region"],
									formatter: function(dt, region) {
										if (dt !== null) {
											if (region === "EU" || region === "LATAM" || region === "ZA") {
												if (dt !== "00000000") {
													var sDate = dt.slice(6, 8) + "/" + dt.slice(4, 6) + "/" + dt.slice(0, 4);
													return sDate;
												} else {
													return "";
												}
											} else {
												var date = dt.slice(0, 4) + "," + dt.slice(4, 6) + "," + dt.slice(6, 8);
												var localtime = new Date(date);
												var dateFormat = sap.ui.core.format.DateFormat.getDateInstance({
													pattern: "dd MMM YYYY"
												});

												var dateFormatted = dateFormat.format(new Date(localtime));
												return dateFormatted;
											}
										}
									}

								}
							}
						}, {
							name: getHeaderText.getProperty("table.header.label.AppointmentTime"),
							template: {
								// content: "{Apptime}"
								content: {
									parts: ["Apptime", "Region"],
									formatter: function(appTime, region) {
										if (appTime !== null) {
											appTime = appTime.trim();
											if (region === "EU" || region === "LATAM" || region === "ZA") {
												if ((appTime === "0") || (appTime === 0)) {
													return 0;
												} else if (appTime !== null && appTime !== "0" && appTime !== undefined) {
													var newAppointmentTime = appTime.slice(6, 8) + "/" + appTime.slice(4, 6) + "/" + appTime.slice(0, 4) + " " +
														appTime.slice(
															8, 10) + ":" + appTime.slice(10, 12) + ":" + appTime.slice(12, 14);
													return newAppointmentTime;
												}
											}
											if ((appTime === "0") || (appTime === 0)) {
												return 0;
											} else if (appTime !== null && appTime !== "0" && appTime !== undefined) {
												var newAppointmentTime = appTime.slice(4, 6) + "/" + appTime.slice(6, 8) + "/" + appTime.slice(0, 4) + " " +
													appTime.slice(
														8, 10) + ":" + appTime.slice(10, 12) + ":" + appTime.slice(12, 14);
												return newAppointmentTime;
											}
										}
									}
								}
							}
						}, {
							name: getHeaderText.getProperty("table.header.label.totalQty"),
							template: {
								content: {
									parts: ["Zmeng"],
									type: sap.ui.model.type.Integer
								}
							}
						}, {
							name: getHeaderText.getProperty("table.header.label.Status"),
							template: {
								content: "{Delstatus}"
							}
						}, {
							name: getHeaderText.getProperty("checkInSys"),
							template: {
								content: "{CheckInSystem}"
							}
						}, {
							name: getHeaderText.getProperty("checkOutSys"),
							template: {
								content: "{CheckOutSystem}"
							}
						}, {
							name: getHeaderText.getProperty("CustRej"),
							template: {
								content: {
									parts: ["CustomerRejection"],
									//ctrm 1392
									formatter: function(CR) {
										if (CR === "X") {
											return "Y";
										} else if (CR === undefined || CR === "") {
											return "";
										} else {
											return "";
										}
									}
								}
							}
						}

					]
				});
				/*var today = new Date();
				var dd = today.getDate();
				var mm = today.getMonth() + 1; //January is 0!
				var yyyy = today.getFullYear();

				if (dd < 10) {
					dd = '0' + dd;
				}

				if (mm < 10) {
					mm = '0' + mm;
				}

				today = yyyy + '-' + mm + '-' + dd;*/

				/*** add this column only when parentplant is active ***/
				var parentplant = this.getView().getModel("ViewModel").getProperty("/ParentPlant");
				if (parentplant !== "") {
					oExport.insertColumn(new sap.ui.core.util.ExportColumn({
						name: this.getOwnerComponent().getModel("i18n").getProperty("Plant"),
						template: {
							content: "{Plant}"
						}
					}), 0);
				}
				var sdelStatRep = this.getOwnerComponent().getModel("i18n").getProperty("delStatRep");
				oExport.saveFile(sdelStatRep).catch(function(
					oError) {
					MessageBox.error("Error while exporting data. Browser might not be supported!\n\n" + oError);
				}).then(function() {
					oExport.destroy();
				});
			}
		});
	});