sap.ui.define([
		"sap/ui/core/mvc/Controller",
		"sap/ui/layout/form/GridLayout",
		"sap/m/Panel",
		"sap/ui/model/json/JSONModel",
		"com/report/model/HostlerPersoService",
		"sap/m/TablePersoController",
		"sap/ui/core/util/Export",
		"sap/ui/core/util/ExportTypeCSV",
		"sap/ui/model/Filter",
		"sap/ui/model/Sorter",
		"com/report/model/formatter"
	],
	function(Controller, GridLayout, Panel, JSONModel, HostlerPersoService, TablePersoController, Export, ExportTypeCSV, Filter, Sorter,
		formatter) {
		"use strict";
		return Controller.extend("com.report.controller.YardHostler", {

			onInit: function() {
				jQuery.sap.require("jquery.sap.storage");
				var that = this;
				var oRouter = sap.ui.core.UIComponent.getRouterFor(this);
				oRouter.getRoute("YardHostler").attachMatched(this._onRouteMatched, this);

				var oDesktopDevice = sap.ui.Device.system.desktop;
				if (oDesktopDevice === true) {
					var oTitleBar = sap.ui.xmlfragment(this.createId("Plant_Detail_Bar_ID"), "com.report.fragments.PlantDetails", this);
					this.getView().addDependent(oTitleBar);
					this.getView().byId("HostlerPage").addContent(oTitleBar);
				} else {
					var oTitleBarMobile = sap.ui.xmlfragment(this.createId("Header_PlantDetail_Mobile_Bar_ID"),
						"com.report.fragments.MobileHeaderPlantDetails", this);
					this.getView().addDependent(oTitleBarMobile);
					this.getView().byId("HostlerPage").addContent(oTitleBarMobile);
				}

				var oGridLayout = new sap.ui.layout.Grid({
					defaultSpan: "L12 M12 S12",
					content: [
						new sap.m.Panel("HostlerSummarypanel", {
							expandable: true,
							expanded: true,
							// headerText: "{i18n>summary}",
							headerToolbar: new sap.m.Toolbar({
								content: [
									new sap.m.Title({
										text: "{i18n>summary}"
									}).addStyleClass("pHeaderText"),
									new sap.m.ToolbarSpacer({}),
									new sap.m.Button({
										icon: "sap-icon://expand-group",
										press: function(oEvent) {
											that.onPressExp(oEvent);
										}
									}).addStyleClass("headerButton")
								]
							}),
							content: [
								new sap.ui.layout.Grid({
									hSpacing: 0,
									vSpacing: 0,
									defaultSpan: "L6 M6 S12",
									content: [

										new sap.m.Label({
											text: "{i18n>totalTrailMove}",
											design: "Bold",
											layoutData: new sap.ui.layout.GridData({
												linebreakL: true,
												linebreakM: true,
												linebreakS: true,
												span: "L3 M6 S12"
											})
										}),
										new sap.m.Label({
											text: "{averageHostModel>/TrailersCount}",
											design: "Bold",
											width: "100%"
										}),
										new sap.m.Label({
											text: "{i18n>avgTimeMove}",
											design: "Bold",
											layoutData: new sap.ui.layout.GridData({
												linebreakL: true,
												linebreakM: true,
												linebreakS: true,
												span: "L3 M6 S12"
											})
										}),
										new sap.m.Label({
											// text: "{averageHostModel>/AvgTime}",
											text: {
												parts: [{
													path: 'averageHostModel>/AvgTime'
												}],
												formatter: function(Ztimetaken) {
													return formatter.calTimeTaken(Ztimetaken);
												}
											},
											design: "Bold",
											width: "100%"
										})
									]
								})

							]
						}).addStyleClass("pHeading panelBackground"),
						new sap.m.Panel("HostlerTablepanel", {
							expandable: true,
							expanded: true,
							// headerText: "Table Data",
							headerToolbar: new sap.m.Toolbar({
								content: [
									new sap.m.Title({
										text: "{i18n>hostlerDetails}"
									}).addStyleClass("pHeaderText"),
									new sap.m.ToolbarSpacer({}),
									// new sap.m.Button({
									// 	icon: "sap-icon://action-settings",
									// 	press: function() {
									// 		that.onPersoButtonPressed();
									// 	}
									// }).addStyleClass("headerButton"),
									new sap.m.Button({
										icon: "sap-icon://filter",
										press: function() {
											that.onFilterPressed();
										}
									}).addStyleClass("headerButton"),
									new sap.m.Button({
										icon: "sap-icon://sort",
										press: function() {
											that.onSorterPressed();
										}
									}).addStyleClass("headerButton"),
									new sap.m.Button({
										icon: "sap-icon://expand-group",
										press: function(oEvent) {
											that.onPressExp(oEvent);
										}
									}).addStyleClass("headerButton"),
									new sap.m.Button({
										icon: "sap-icon://refresh",
										press: function() {
											that.onTableRefresh();
										}
									}).addStyleClass("headerButton")
								]
							}),
							content: [
								new sap.m.Toolbar({
									content: [
										new sap.m.Label("hostlerheaderData", {
											text: "",
											design: "Bold"
										}),
										new sap.m.ToolbarSpacer({}),
										new sap.m.CheckBox("hostlergroupCheck", {
											text: "{i18n>enablePerso}",
											select: function() {
												that.onTableGrouping();
											}
										}),
										new sap.m.Button({
											icon: "sap-icon://action-settings",
											press: function() {
												that.onPersoButtonPressed();
											}
										})
									]
								}),
								new sap.m.ScrollContainer("hostlerscroll", {
									// focusable: true,
									horizontal: true,
									vertical: true,
									height: '18rem',
									content: [
										new sap.m.Table("YardHostlerTab", {
											width: "1180px",
											mode: "SingleSelectMaster",
											columns: [new sap.m.Column("trailId", {
													header: new sap.m.Label({
														text: "{i18n>trailerId}",
														design: "Bold"
													}).addStyleClass("columnLabelStyle"),
													width: "10%"
												}),
												new sap.m.Column("locFrom", {
													header: new sap.m.Label({
														text: "{i18n>loctnFrom}",
														design: "Bold"
													}).addStyleClass("columnLabelStyle"),
													width: "8%"
												}),
												new sap.m.Column("locTo", {
													header: new sap.m.Label({
														text: "{i18n>loctnTo}",
														design: "Bold"
													}).addStyleClass("columnLabelStyle"),
													width: "8%"
												}),
												new sap.m.Column("startTmp", {
													header: new sap.m.Label({
														text: "{i18n>startTimeStamp}",
														design: "Bold"
													}).addStyleClass("columnLabelStyle"),
													width: "11%",
													demandPopin: true,
													minScreenWidth: "Desktop",
													popinDisplay: "Inline"
												}),
												new sap.m.Column("compTmp", {
													header: new sap.m.Label({
														text: "{i18n>compTimeStamp}",
														design: "Bold"
													}).addStyleClass("columnLabelStyle"),
													width: "11%",
													demandPopin: true,
													minScreenWidth: "Desktop",
													popinDisplay: "Inline"
												}),
												new sap.m.Column("timeTaken", {
													header: new sap.m.Label({
														text: "{i18n>timeTaken}",
														design: "Bold"
													}).addStyleClass("columnLabelStyle"),
													width: "10%",
													demandPopin: true,
													minScreenWidth: "Desktop",
													popinDisplay: "Inline"
												}),
												new sap.m.Column("personId", {
													header: new sap.m.Label({
														text: "{i18n>personnalId}",
														design: "Bold"
													}).addStyleClass("columnLabelStyle"),
													width: "10%",
													demandPopin: true,
													minScreenWidth: "Desktop",
													popinDisplay: "Inline"
												})
											]
										}).addStyleClass("tableStyle")
									]
								}).addStyleClass("tableClass")
							]
						}).addStyleClass("pHeading panelBackground")
					]
				}).addStyleClass("sapUiTinyMarginTop");
				that.byId("HostlerPage").addContent(oGridLayout);

				// init and activate controller
				this._oTPC = new TablePersoController({
					table: sap.ui.getCore().byId("YardHostlerTab"),
					//specify the first part of persistence ids e.g. 'demoApp-productsTable-dimensionsCol'
					componentName: "hostlerApp",
					persoService: HostlerPersoService
				}).activate();

			},
			getCurrentLanguage: function() {

				var sCurrentLang = sap.ui.getCore().getConfiguration().getLanguage();
				if (sCurrentLang.indexOf("ES") !== -1 || sCurrentLang.indexOf("es") !== -1) {
					sCurrentLang = "S";
				} else if (sCurrentLang.indexOf("EN") !== -1 || sCurrentLang.indexOf("en") !== -1) {
					sCurrentLang = "E";
				} else if (sCurrentLang.indexOf("NL") !== -1 || sCurrentLang.indexOf("nl") !== -1) {
					sCurrentLang = "N";
				} else if (sCurrentLang.indexOf("FR") !== -1 || sCurrentLang.indexOf("fr") !== -1) {
					sCurrentLang = "F";
				} else if (sCurrentLang.indexOf("PT") !== -1 || sCurrentLang.indexOf("pt") !== -1) {
					sCurrentLang = "P";
				} else if (sCurrentLang.indexOf("IT") !== -1 || sCurrentLang.indexOf("it") !== -1) {
					sCurrentLang = "I";
				} else if (sCurrentLang.indexOf("RO") !== -1 || sCurrentLang.indexOf("ro") !== -1) {
					sCurrentLang = "4";
				} else if (sCurrentLang.indexOf("DE") !== -1 || sCurrentLang.indexOf("de") !== -1) {
					sCurrentLang = "D";
				} else if (sCurrentLang.indexOf("PL") !== -1 || sCurrentLang.indexOf("pl") !== -1) {
					sCurrentLang = "L";
				} else if (sCurrentLang.indexOf("ZH") !== -1 || sCurrentLang.indexOf("zh") !== -1) {
					sCurrentLang = "1";
				} else if (sCurrentLang.indexOf("CS") !== -1 || sCurrentLang.indexOf("cs") !== -1) {
					sCurrentLang = "C";
				} else if (sCurrentLang.indexOf("HU") !== -1 || sCurrentLang.indexOf("hu") !== -1) {
					sCurrentLang = "H";
				} else if (sCurrentLang.indexOf("EL") !== -1 || sCurrentLang.indexOf("el") !== -1) {
					sCurrentLang = "G";
				} else if (sCurrentLang.indexOf("LT") !== -1 || sCurrentLang.indexOf("lt") !== -1) {
					sCurrentLang = "X";
				} else if (sCurrentLang.indexOf("SK") !== -1 || sCurrentLang.indexOf("sk") !== -1) {
					sCurrentLang = "Q";
				} else if (sCurrentLang.indexOf("TR") !== -1 || sCurrentLang.indexOf("tr") !== -1) {
					sCurrentLang = "T";
				} else if (sCurrentLang.indexOf("BG") !== -1 || sCurrentLang.indexOf("bg") !== -1) {
					sCurrentLang = "W";
				} else if (sCurrentLang.indexOf("DA") !== -1 || sCurrentLang.indexOf("da") !== -1) {
					sCurrentLang = "K";
				} else if (sCurrentLang.indexOf("FI") !== -1 || sCurrentLang.indexOf("fi") !== -1) {
					sCurrentLang = "U";
				} else if (sCurrentLang.indexOf("SV") !== -1 || sCurrentLang.indexOf("sv") !== -1) {
					sCurrentLang = "V";
				} else {
					sCurrentLang = "E";
				}
				return sCurrentLang;
			},

			_onRouteMatched: function(oEvent) {
				var that = this;
				//pulling language information
				var sCurrentLang = that.getCurrentLanguage();
				that.fnCreateBusyDialog("pallet.svg", "true");
				var oArgs = oEvent.getParameter("arguments");
				var sDateRange = oArgs.DateRange.split(",");
				var oStartDate = sDateRange[0];
				var newStrDate = oStartDate.replace(/-/g, "");
				var oEndDate = sDateRange[1];
				var newEndDate = oEndDate.replace(/-/g, "");
				oArgs.DateStart = oStartDate;
				oArgs.DateEnd = oEndDate;
				var startTime = oArgs.StartTime;
				var newStrTime = startTime.replace(/:/g, "");
				var endTime = oArgs.EndTime;
				var newEndTime = endTime.replace(/:/g, "");
				var plantModel = new sap.ui.model.json.JSONModel();
				plantModel.setData(oArgs);
				that.getView().setModel(plantModel, "plantDetailModel");

				that.getOwnerComponent().getModel("fdeRepModel").read("/YARD_HOSTLER_SUMMERYSet(Werks='" + oArgs.Plants + "',StartDate='" +
					newStrDate +
					"',EndDate='" + newEndDate + "',StartTime='" + newStrTime + "',EndTime='" + newEndTime + "',Langu='" + sCurrentLang + "')", {
						urlParameters: {
							"$expand": "YardNavig"
						},
						success: function(oData, oResponse) {
							if (oResponse.statusCode === 200 || oResponse.statusCode === "200") {
								var hostlerModel = new JSONModel();
								hostlerModel.setData(oData.YardNavig.results);
								hostlerModel.setSizeLimit(oData.YardNavig.results.length);
								that.getView().setModel(hostlerModel, "hostlertabModel");
								that.bindAllPanelsandTables(oData.YardNavig.results);

								var sHostAvgModel = new JSONModel();
								var objAvg = {};
								objAvg.TrailersCount = oData.TrailersCount;
								objAvg.AvgTime = oData.AvgTime;

								sHostAvgModel.setData(objAvg);
								that.getView().setModel(sHostAvgModel, "averageHostModel");

							}
							that.fnCreateBusyDialog("pallet.svg", "false");
						},
						error: function() {
							that.fnCreateBusyDialog("pallet.svg", "false");
						}
					});
			},

			//----------------------------------------------------------------------------------
			//Function to create Busy Dialog
			//----------------------------------------------------------------------------------
			fnCreateBusyDialog: function(sImage, sBusy) {
				var that = this;
				//	that.oInsCreateDailog;
				if (sBusy === "true") {
					that.oInsCreateDailog = new sap.m.Dialog({
						showHeader: false
					}).addStyleClass("busyDialog sapUiTinyMargin");
					var sComponentName = that.getOwnerComponent().getMetadata().getComponentName();
					var imgUrl = $.sap.getModulePath(sComponentName, "/images/");
					var oImage = new sap.m.Image().addStyleClass("sapUiMediumMargin");
					oImage.setSrc(imgUrl + sImage);
					that.oInsCreateDailog.addContent(oImage);
					that.oInsCreateDailog.open();
				} else {
					that.oInsCreateDailog.close();
				}
			},

			bindAllPanelsandTables: function(tableData) {
				var that = this;
				that.hostlertableBinding(tableData);
			},

			hostlertableBinding: function(tableData) {
				/*Pass Data to Tables*/
				var oTemplate = new sap.m.ColumnListItem({
					type: "Navigation",
					cells: [
						new sap.m.Text({
							text: "{Signi}"
						}).addStyleClass("bold"),
						new sap.m.Text({
							text: "{FromLocation}"
						}),
						new sap.m.Text({
							text: "{ToLocation}"
						}),
						new sap.m.Text({
							text: "{AssignTime}"
						}),
						new sap.m.Text({
							text: "{CompletionTime}"
						}),
						new sap.m.ObjectStatus({
							text: {
								parts: [{
									path: 'TimeTaken'
								}],
								formatter: function(Ztimetaken) {
									return formatter.calTimeTaken(Ztimetaken);
								}
							}
						}).addStyleClass("bold"),
						new sap.m.Text({
							text: "{PersonelId}"
						})
					]
				});

				/*Table Binding*/
				var oYardHostlerTable = sap.ui.getCore().byId("YardHostlerTab");
				var oModel1 = new sap.ui.model.json.JSONModel();
				oModel1.setSizeLimit(tableData.length);
				oModel1.setData(tableData);
				if (oYardHostlerTable !== undefined) {
					oYardHostlerTable.setModel(oModel1);
					oYardHostlerTable.bindAggregation("items", {
						path: "/",
						template: oTemplate
					});
				}
			},

			onTableRefresh: function() {
				//Remove Filters
				if (sap.ui.getCore().byId("YardHostlerTab") !== undefined) {
					var oTable = sap.ui.getCore().byId("YardHostlerTab");
					var oModel = oTable.getModel();
					var oTableBinding = oTable.getBinding("items");
					oTableBinding.aSorters = null;
					oTableBinding.aFilters = null;
					oModel.refresh(true);
				}
				if (sap.ui.getCore().byId("hostlerheaderData") !== undefined) {
					sap.ui.getCore().byId("hostlerheaderData").setText("");
				}
				this.resetFilterItems();
			},

			resetFilterItems: function() {
				var that = this;
				that.oInsCreateDailog.open();
				if (this._filterDialog !== undefined) {
					var aFilterItems = this._filterDialog.getFilterItems();

					aFilterItems.forEach(function(item) {
						var aItems = item.getItems();
						aItems.forEach(function(item) {
							item.setSelected(false);
						});
					});
				}
				that.oInsCreateDailog.close();
			},

			onPersoButtonPressed: function(oEvent) {
				this._oTPC.openDialog();
			},

			onTablePersoRefresh: function() {
				HostlerPersoService.resetPersData();
				this._oTPC.refresh();
			},

			onTableGrouping: function(oEvent) {
				// alert("msg")
				// this._oTPC.setHasGrouping(oEvent.getSource().getSelected());
				this._oTPC.setHasGrouping(sap.ui.getCore().byId("hostlergroupCheck").getSelected());

			},

			loadFiltersData: function() {
				var filterResults = sap.ui.getCore().byId("YardHostlerTab").getModel().getData();

				/*		//----Binded unique data of scac/carrier to filter fragment----//
				var carrierarray = [];
				for (var i = 0; i < filterResults.length; i++) {
					if (carrierarray.indexOf(filterResults[i].Scac) === -1) {
						carrierarray.push(filterResults[i].Scac);
					}
				}
				if (sap.ui.getCore().byId("CarrierFilter") !== undefined) {
					sap.ui.getCore().byId("CarrierFilter").setModel(new JSONModel(carrierarray), "sCarrier");
				}

				//----Binded unique data of type to filter fragment----//
				var Typearray = [];
				for (var i = 0; i < filterResults.length; i++) {
					if (Typearray.indexOf(filterResults[i].ZcheckinTy) === -1) {
						Typearray.push(filterResults[i].ZcheckinTy);
					}
				}
				if (sap.ui.getCore().byId("TypeFilter") !== undefined) {
					sap.ui.getCore().byId("TypeFilter").setModel(new JSONModel(Typearray), "sCheckInType");
				}*/

				//----Binded unique data of personnelID to filter fragment----//
				var personelIDarray = [];
				for (var i = 0; i < filterResults.length; i++) {
					if (personelIDarray.indexOf(filterResults[i].PersonelId) === -1) {
						personelIDarray.push(filterResults[i].PersonelId);
					}
				}
				if (sap.ui.getCore().byId("personIDFilter") !== undefined) {
					sap.ui.getCore().byId("personIDFilter").setModel(new JSONModel(personelIDarray), "sPersonelID");
				}

			},

			onFilterPressed: function() {
				var that = this;
				that.oInsCreateDailog.open();

				if (!this._filterDialog) {
					this._filterDialog = sap.ui.xmlfragment("com.report.fragments.HostlerFilter", this);
					this.getView().addDependent(this._filterDialog);
				}
				this.loadFiltersData();
				// toggle compact style
				jQuery.sap.syncStyleClass("sapUiSizeCompact", this.getView(), this._filterDialog);
				this._filterDialog.open();

				that.oInsCreateDailog.close();
			},

			//---------------------Code for filtering----------------------//

			onFilterConfirm: function(oEvent) {
				var that = this;
				that.oInsCreateDailog.open();
				var oView = sap.ui.getCore();
				if (oView.byId("YardHostlerTab") !== undefined) {
					var yTableFilter = oView.byId("YardHostlerTab");
					var mParams = oEvent.getParameters();
					var oBinding = yTableFilter.getBinding("items");
					var aFilters = [];
					for (var i = 0, l = mParams.filterItems.length; i < l; i++) {
						var oItem = mParams.filterItems[i];
						/*if (oItem.getKey() === "CarrierType") {
							var oFilter1 = new sap.ui.model.Filter("Scac", "EQ", oItem.getText());
							aFilters.push(oFilter1);
						} else if (oItem.getKey() === "CheckInType") {
							var oFilter2 = new sap.ui.model.Filter("ZcheckinTy", "EQ", oItem.getText());
							aFilters.push(oFilter2);
						} else*/
						if (oItem.getKey() === "PersonnelId") {
							var oFilter1 = new sap.ui.model.Filter("PersonelId", "EQ", oItem.getText());
							aFilters.push(oFilter1);
						}
					}
					oBinding.filter(aFilters);
				}

				that.oInsCreateDailog.close();

				if (oEvent.getParameters().filterString) {
					var filteredData = oEvent.getParameters().filterString;
				}
				sap.ui.getCore().byId("hostlerheaderData").setText(filteredData);
			},

			//----------------Code for opening Sorter Dailog when sorter icon pressed---------------------//

			onSorterPressed: function() {
				var that = this;
				that.oInsCreateDailog.open();
				if (!this._sorterDialog) {
					this._sorterDialog = sap.ui.xmlfragment("com.report.fragments.HostlerSorter", this);
					this.getView().addDependent(this._sorterDialog);
				}
				// toggle compact style
				jQuery.sap.syncStyleClass("sapUiSizeCompact", this.getView(), this._sorterDialog);
				this._sorterDialog.open();
				that.oInsCreateDailog.close();
			},

			//-----------------------Code for Sorting---------------------------//

			onSortConfirm: function(oEvent) {
				var that = this;
				that.oInsCreateDailog.open();
				var oView = sap.ui.getCore();
				if (oView.byId("YardHostlerTab") !== undefined) {
					var hostlerRepTable = oView.byId("YardHostlerTab");
					var mParams = oEvent.getParameters();
					var oBinding = hostlerRepTable.getBinding("items");

					var aSorters = [];
					if (mParams.sortItem !== undefined) {
						var sPath = mParams.sortItem.getKey();
						var bDescending = mParams.sortDescending;
						aSorters.push(new sap.ui.model.Sorter(sPath, bDescending));
						oBinding.sort(aSorters);
					}
				}
				that.oInsCreateDailog.close();
			},

			//-----------------------------------------------------------------------------------------
			// Function for expanding the pnales inside the plant panels
			//-----------------------------------------------------------------------------------------
			onPressExp: function(oEvent) {
				var oPanelId = oEvent.getSource().getParent().getParent().getId();
				var oButtonId = oEvent.getSource().getId();
				if (sap.ui.getCore().byId(oPanelId).getExpanded()) {
					sap.ui.getCore().byId(oPanelId).setExpanded(false);
					sap.ui.getCore().byId(oButtonId).setIcon("sap-icon://expand-group");
				} else {
					sap.ui.getCore().byId(oPanelId).setExpanded(true);
					sap.ui.getCore().byId(oButtonId).setIcon("sap-icon://collapse-group");
				}
			},

			onNavButtonPress: function() {
				var oRouter = sap.ui.core.UIComponent.getRouterFor(this);
				oRouter.navTo("ReportInter");
			},

			onPressExport: sap.m.Table.prototype.exportData || function(oEvent) {
				var oExport = new Export({
					exportType: new ExportTypeCSV({
						separatorChar: ",",
						fileExtension: "csv"
					}),
					models: sap.ui.getCore().byId("YardHostlerTab").getModel(),
					rows: {
						path: "/"
					},

					columns: [{
							// name: "Trailer Id",
							name: this.getOwnerComponent().getModel("i18n").getProperty("trailerId"),
							template: {
								content: "{Signi}"
							}
						}, {
							// name: "Location From",
							name: this.getOwnerComponent().getModel("i18n").getProperty("loctnFrom"),
							template: {
								content: "{FromLocation}"
							}
						}, {
							// name: "Location To",
							name: this.getOwnerComponent().getModel("i18n").getProperty("loctnTo"),
							template: {
								content: "{ToLocation}"
							}
						}, {
							// name: "Start Timestamp",
							name: this.getOwnerComponent().getModel("i18n").getProperty("startTimeStamp"),
							template: {
								content: "{AssignTime}"
							}
						}, {
							// name: "Complete Timestamp",
							name: this.getOwnerComponent().getModel("i18n").getProperty("compTimeStamp"),
							template: {
								content: "{CompletionTime}"
							}
						}, {
							// name: "Time Taken",
							name: this.getOwnerComponent().getModel("i18n").getProperty("timeTaken"),
							template: {
								// content: "{TimeTaken}"
								content: {
									parts: ["TimeTaken"],
									formatter: function(timeTaken) {
										if (timeTaken === "ONGOING") {
											return "ONGOING";
										} else if (timeTaken === "PLANNED") {
											return "PLANNED";
										} else {
											var day = parseInt(timeTaken / (24 * 3600));

											timeTaken = timeTaken % (24 * 3600);
											var hour = parseInt(timeTaken / 3600);

											timeTaken %= 3600;
											var minutes = parseInt(timeTaken / 60);

											var stimeTakenFormat = day + " days " + hour + " hrs " + minutes + " min ";
											return stimeTakenFormat;
										}
										// if (timeTaken !== "ONGOING") {
										// 	var day = parseInt(timeTaken / (24 * 3600));

										// 	timeTaken = timeTaken % (24 * 3600);
										// 	var hour = parseInt(timeTaken / 3600);

										// 	timeTaken %= 3600;
										// 	var minutes = parseInt(timeTaken / 60);

										// 	var stimeTakenFormat = day + " days " + hour + " hrs " + minutes + " min ";
										// 	return stimeTakenFormat;
										// } else {
										// 	return "ONGOING";
										// }
									}
								}
							}
						}, {
							// name: "Personnel ID",
							name: this.getOwnerComponent().getModel("i18n").getProperty("personnalId"),
							template: {
								content: "{PersonelId}"
							}
						}

					]
				});
				var yardHostRep = this.getOwnerComponent().getModel("i18n").getProperty("hostlerDetails");
				oExport.saveFile(yardHostRep).catch(function(oError) {
					// MessageBox.error("Error when downloading data. Browser might not be supported!\n\n" + oError);
				}).then(function() {
					oExport.destroy();
				});
			},

			onPressExportXLS: sap.m.Table.prototype.exportData || function(oEvent) {
				var oExport = new Export({
					exportType: new ExportTypeCSV({
						separatorChar: "\t",
						fileExtension: "xls"
					}),
					models: sap.ui.getCore().byId("YardHostlerTab").getModel(),
					rows: {
						path: "/"
					},

					columns: [{
							// name: "Trailer Id",
							name: this.getOwnerComponent().getModel("i18n").getProperty("trailerId"),
							template: {
								content: "{Signi}"
							}
						}, {
							// name: "Location From",
							name: this.getOwnerComponent().getModel("i18n").getProperty("loctnFrom"),
							template: {
								content: "{FromLocation}"
							}
						}, {
							// name: "Location To",
							name: this.getOwnerComponent().getModel("i18n").getProperty("loctnTo"),
							template: {
								content: "{ToLocation}"
							}
						}, {
							// name: "Start Timestamp",
							name: this.getOwnerComponent().getModel("i18n").getProperty("startTimeStamp"),
							template: {
								content: "{AssignTime}"
							}
						}, {
							// name: "Complete Timestamp",
							name: this.getOwnerComponent().getModel("i18n").getProperty("compTimeStamp"),
							template: {
								content: "{CompletionTime}"
							}
						}, {
							// name: "Time Taken",
							name: this.getOwnerComponent().getModel("i18n").getProperty("timeTaken"),
							template: {
								// content: "{TimeTaken}"
								content: {
									parts: ["TimeTaken"],
									formatter: function(timeTaken) {
										if (timeTaken === "ONGOING") {
											return "ONGOING";
										} else if (timeTaken === "PLANNED") {
											return "PLANNED";
										} else {
											var day = parseInt(timeTaken / (24 * 3600));

											timeTaken = timeTaken % (24 * 3600);
											var hour = parseInt(timeTaken / 3600);

											timeTaken %= 3600;
											var minutes = parseInt(timeTaken / 60);

											var stimeTakenFormat = day + " days " + hour + " hrs " + minutes + " min ";
											return stimeTakenFormat;
										}
										// if (timeTaken !== "ONGOING") {
										// 	var day = parseInt(timeTaken / (24 * 3600));

										// 	timeTaken = timeTaken % (24 * 3600);
										// 	var hour = parseInt(timeTaken / 3600);

										// 	timeTaken %= 3600;
										// 	var minutes = parseInt(timeTaken / 60);

										// 	var stimeTakenFormat = day + " days " + hour + " hrs " + minutes + " min ";
										// 	return stimeTakenFormat;
										// } else {
										// 	return "ONGOING";
										// }
									}
								}
							}
						}, {
							// name: "Personnel ID",
							name: this.getOwnerComponent().getModel("i18n").getProperty("personnalId"),
							template: {
								content: "{PersonelId}"
							}
						}

					]
				});
				var yardHostRep = this.getOwnerComponent().getModel("i18n").getProperty("hostlerDetails");
				oExport.saveFile(yardHostRep).catch(function(oError) {
					// MessageBox.error("Error when downloading data. Browser might not be supported!\n\n" + oError);
				}).then(function() {
					oExport.destroy();
				});
			}

		});
	});