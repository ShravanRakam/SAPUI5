var vPlant;
var vRegion;
sap.ui.define([
		"sap/ui/core/mvc/Controller",
		"sap/ui/layout/form/GridLayout",
		"sap/m/Panel",
		"sap/ui/model/json/JSONModel",
		"com/report/model/RejectionPersoService",
		"sap/m/TablePersoController",
		"sap/ui/core/util/Export",
		"sap/ui/core/util/ExportTypeCSV",
		"sap/ui/model/Filter",
		"sap/ui/model/Sorter",
		"com/report/model/formatter",
		"sap/m/MessageBox"
	],
	function(Controller, GridLayout, Panel, JSONModel, RejectionPersoService, TablePersoController, Export, ExportTypeCSV, Filter, Sorter,
		formatter, MessageBox) {
		"use strict";
		return Controller.extend("com.report.controller.RejectionReport", {

			onInit: function() {
				jQuery.sap.require("jquery.sap.storage");
				var that = this;

				var oRouter = sap.ui.core.UIComponent.getRouterFor(this);
				oRouter.getRoute("RejectionReport").attachMatched(this._onRouteMatched, this);

				// var sObj = {
				// 	"fromDate": false,
				// 	"toDate": false,
				// 	"startTime": false,
				// 	"endTime": false
				// };

				// var sModel = new sap.ui.model.json.JSONModel(sObj);

				// that.getView().setModel(sModel, "visibleModel");
				var oViewObj = {
					ParentPlant: jQuery.sap.storage(jQuery.sap.storage.Type.local).get("ParentPlant")
				};
				var oViewModel = new JSONModel(oViewObj);
				that.getView().setModel(oViewModel, "ViewModel");

				var oDesktopDevice = sap.ui.Device.system.desktop;
				if (oDesktopDevice === true) {
					var oTitleBar = sap.ui.xmlfragment(this.createId("Plant_Detail_Bar_ID"), "com.report.fragments.PlantDetails", this);
					this.getView().addDependent(oTitleBar);
					this.getView().byId("RejReportPage").addContent(oTitleBar);

				} else {
					var oTitleBarMobile = sap.ui.xmlfragment(this.createId("Header_PlantDetail_Mobile_Bar_ID"),
						"com.report.fragments.MobileHeaderPlantDetails", this);
					this.getView().addDependent(oTitleBarMobile);
					this.getView().byId("RejReportPage").addContent(oTitleBarMobile);
				}

				var oGridLayout = new sap.ui.layout.Grid({
					defaultSpan: "L12 M12 S12",
					content: [
						new sap.m.Panel("RejectTablepanel", {
							expandable: true,
							expanded: true,
							// headerText: "Table Data",
							headerToolbar: new sap.m.Toolbar({
								content: [
									new sap.m.Title({
										text: "{i18n>rejectDetails}"
									}).addStyleClass("pHeaderText"),
									new sap.m.ToolbarSpacer({}),
									new sap.m.Button({
										icon: "sap-icon://filter",
										press: function() {
											that.onFilterPressed();
										}
									}).addStyleClass("headerButton"),
									// new sap.m.Button({
									// 	icon: "sap-icon://action-settings",
									// 	press: function() {
									// 		that.onPersoButtonPressed();
									// 	}
									// }).addStyleClass("headerButton"),
									new sap.m.Button({
										icon: "sap-icon://sort",
										press: function() {
											that.onSorterPressed();
										}
									}).addStyleClass("headerButton"),
									new sap.m.Button({
										icon: "sap-icon://expand-group",
										press: function(oEvent) {
											that.onPressExp(oEvent);
										}
									}).addStyleClass("headerButton"),
									new sap.m.Button({
										icon: "sap-icon://refresh",
										press: function() {
											that.onTableRefresh();
										}
									}).addStyleClass("headerButton")
								]
							}),
							content: [
								new sap.m.Toolbar({
									content: [
										new sap.m.Label("rejectheaderData", {
											text: "",
											design: "Bold"
										}),
										new sap.m.ToolbarSpacer({}),
										new sap.m.CheckBox("rejectgroupCheck", {
											text: "{i18n>enablePerso}",
											select: function() {
												that.onTableGrouping();
											}
										}),
										new sap.m.Button({
											icon: "sap-icon://action-settings",
											press: function() {
												that.onPersoButtonPressed();
											}
										})
									]
								}),
								new sap.m.ScrollContainer("rejectscroll", {
									// focusable: true,
									horizontal: true,
									vertical: true,
									height: '25rem',
									content: [
										new sap.m.Table("RejReportTab", {
											width: "1500px",
											mode: "SingleSelectMaster",
											updateFinished: function(eve) {
												that.onRejectionTableUpdateFinished(eve);
											},
											selectionChange: function(oEvent) {
												// that.onSelectionChange(oEvent);
											},
											columns: [new sap.m.Column("location", {
													header: new sap.m.Label({
														text: "{i18n>location}",
														design: "Bold"
													}).addStyleClass("columnLabelStyle"),
													width: "10%"
												}),
												new sap.m.Column("LocationDesc", {
													header: new sap.m.Label({
														text: "{i18n>LocationDesc}",
														design: "Bold"
													}).addStyleClass("columnLabelStyle"),
													width: "15%"
												}),
												new sap.m.Column("rejtrailId", {
													header: new sap.m.Label({
														text: "{i18n>trailId}",
														design: "Bold"
													}).addStyleClass("columnLabelStyle"),
													width: "10%"
												}),
												new sap.m.Column("delivery", {
													header: new sap.m.Label({
														text: "{i18n>delivery}",
														design: "Bold"
													}).addStyleClass("columnLabelStyle"),
													width: "10%"
												}),
												new sap.m.Column("RejectionRepPlant",{
													header: new sap.m.Label({
														text: "{i18n>Plant}",
														design: "Bold"
													}).addStyleClass("columnLabelStyle"),
													width: "8%",
													visible: "{= ${ViewModel>/ParentPlant} !==''}"
												}),
												/*	new sap.m.Column("blockDate", {
													header: new sap.m.Label({
														text: "{i18n>blockDate}",
														design: "Bold"
													}).addStyleClass("columnLabelStyle"),
													width: "13%"
												}),
												new sap.m.Column("unblockDate", {
													header: new sap.m.Label({
														text: "{i18n>unblockDate}",
														design: "Bold"
													}).addStyleClass("columnLabelStyle"),
													width: "13%"
												}),
												new sap.m.Column("rejectDate", {
													header: new sap.m.Label({
														text: "{i18n>rejectDate}",
														design: "Bold"
													}).addStyleClass("columnLabelStyle"),
													width: "13%"
												}),*/
												/*** Action new field ****/
												new sap.m.Column("Action", {
													header: new sap.m.Label({
														text: "{i18n>Action}",
														design: "Bold"
													}).addStyleClass("columnLabelStyle"),
													width: "10%"
												}),
												/*** update time new field ****/
												new sap.m.Column("updateTime", {
													header: new sap.m.Label({
														text: "{i18n>UpdateTime}",
														design: "Bold"
													}).addStyleClass("columnLabelStyle"),
													width: "13%",
													visible: true,
													demandPopin: true,
													minScreenWidth: "Desktop",
													popinDisplay: "Inline"
												}),
												new sap.m.Column("userID", {
													header: new sap.m.Label({
														text: "{i18n>userID}",
														design: "Bold"
													}).addStyleClass("columnLabelStyle"),
													width: "9%",
													demandPopin: true,
													minScreenWidth: "Desktop",
													popinDisplay: "Inline"
												}),
												// new sap.m.Column("failCheckQues", {
												// 	header: new sap.m.Label({
												// 		text: "{i18n>failCheckQues}",
												// 		design: "Bold"
												// 	}).addStyleClass("columnLabelStyle"),
												// 	width: "19%",
												// 	demandPopin: true,
												// 	minScreenWidth: "Desktop",
												// 	popinDisplay: "Inline"
												// }),
												new sap.m.Column("reasonChecklist", {
													header: new sap.m.Label({
														text: "{i18n>reasonChecklist}",
														design: "Bold"
													}).addStyleClass("columnLabelStyle"),
													width: "20%",
													demandPopin: true,
													minScreenWidth: "Desktop",
													popinDisplay: "Inline"
												}),
												new sap.m.Column("comments", {
													header: new sap.m.Label({
														text: "{i18n>comments}",
														design: "Bold"
													}).addStyleClass("columnLabelStyle"),
													width: "14%",
													demandPopin: true,
													minScreenWidth: "Desktop",
													popinDisplay: "Inline"
												})
											]
										}).addStyleClass("tableStyle")
									]
								}).addStyleClass("tableClass")
							]
						}).addStyleClass("pHeading panelBackground")
					]
				}).addStyleClass("sapUiSmallMarginTop");
				that.byId("RejReportPage").addContent(oGridLayout);

				// init and activate controller
				this._oTPC = new TablePersoController({
					table: sap.ui.getCore().byId("RejReportTab"),
					//specify the first part of persistence ids e.g. 'demoApp-productsTable-dimensionsCol'
					componentName: "rejectApp",
					persoService: RejectionPersoService
				}).activate();

			},

			_onRouteMatched: function(oEvent) {
				var that = this;
				// that.fnCreateBusyDialog("pallet.svg", "true");
				var oArgs = oEvent.getParameter("arguments");
				vPlant = oArgs.Plants;
				var sDateRange = oArgs.DateRange.split(",");
				var oStartDate = sDateRange[0];
				var newStrDate = oStartDate.replace(/-/g, "");
				var oEndDate = sDateRange[1];
				var newEndDate = oEndDate.replace(/-/g, "");
				oArgs.DateStart = oStartDate;
				oArgs.DateEnd = oEndDate;
				var startTime = oArgs.StartTime;
				var newStrTime = startTime.replace(/:/g, "");
				var endTime = oArgs.EndTime;
				var newEndTime = endTime.replace(/:/g, "");
				var plantModel = new sap.ui.model.json.JSONModel();
				plantModel.setData(oArgs);
				that.getView().setModel(plantModel, "plantDetailModel");
				vRegion = jQuery.sap.storage(jQuery.sap.storage.Type.local).get("region");
				that.fnCreateBusyDialog("pallet.svg", "true");
				var sLanguage = that.getCurrentLanguage();
				var sRejecFilter = [];
				sRejecFilter.push(new sap.ui.model.Filter("Plant", sap.ui.model.FilterOperator.EQ, oArgs.Plants));
				sRejecFilter.push(new sap.ui.model.Filter("StartDate", sap.ui.model.FilterOperator.EQ, newStrDate));
				sRejecFilter.push(new sap.ui.model.Filter("EndDate", sap.ui.model.FilterOperator.EQ, newEndDate));
				sRejecFilter.push(new sap.ui.model.Filter("StartTime", sap.ui.model.FilterOperator.EQ, newStrTime));
				sRejecFilter.push(new sap.ui.model.Filter("EndTime", sap.ui.model.FilterOperator.EQ, newEndTime));
				sRejecFilter.push(new sap.ui.model.Filter("Zlangu", sap.ui.model.FilterOperator.EQ, sLanguage));

				that.getOwnerComponent().getModel("fdeRepModel").read("/YARD_REJECTIONS_REPORTSet", {
					filters: sRejecFilter,
					success: function(oData, oResponse) {
						if (oResponse.statusCode === 200 || oResponse.statusCode === "200") {
							var rejectTableModel = new JSONModel();

							for (var k = 0; k < oData.results.length; k++) {
								oData.results[k].Region = vRegion;
							}

							rejectTableModel.setData(oData.results);
							rejectTableModel.setSizeLimit(oData.results.length);
							that.getView().setModel(rejectTableModel, "rejecTabModel");
							that.bindAllPanelsandTables(oData.results);
						}
						that.fnCreateBusyDialog("pallet.svg", "false");
					},
					error: function() {
						that.fnCreateBusyDialog("pallet.svg", "false");
					}
				});
			},

			bindAllPanelsandTables: function(tableData) {
				var that = this;
				// that.onIssuesReturnsBind(tableData);
				that.tableBinding(tableData);
			},
			getCurrentLanguage: function() {

				var sCurrentLang = sap.ui.getCore().getConfiguration().getLanguage();
				if (sCurrentLang.indexOf("ES") !== -1 || sCurrentLang.indexOf("es") !== -1) {
					sCurrentLang = "S";
				} else if (sCurrentLang.indexOf("EN") !== -1 || sCurrentLang.indexOf("en") !== -1) {
					sCurrentLang = "E";
				} else if (sCurrentLang.indexOf("NL") !== -1 || sCurrentLang.indexOf("nl") !== -1) {
					sCurrentLang = "N";
				} else if (sCurrentLang.indexOf("FR") !== -1 || sCurrentLang.indexOf("fr") !== -1) {
					sCurrentLang = "F";
				} else if (sCurrentLang.indexOf("PT") !== -1 || sCurrentLang.indexOf("pt") !== -1) {
					sCurrentLang = "P";
				} else if (sCurrentLang.indexOf("IT") !== -1 || sCurrentLang.indexOf("it") !== -1) {
					sCurrentLang = "I";
				} else if (sCurrentLang.indexOf("RO") !== -1 || sCurrentLang.indexOf("ro") !== -1) {
					sCurrentLang = "4";
				} else if (sCurrentLang.indexOf("DE") !== -1 || sCurrentLang.indexOf("de") !== -1) {
					sCurrentLang = "D";
				} else if (sCurrentLang.indexOf("PL") !== -1 || sCurrentLang.indexOf("pl") !== -1) {
					sCurrentLang = "L";
				} else if (sCurrentLang.indexOf("ZH") !== -1 || sCurrentLang.indexOf("zh") !== -1) {
					sCurrentLang = "1";
				} else if (sCurrentLang.indexOf("CS") !== -1 || sCurrentLang.indexOf("cs") !== -1) {
					sCurrentLang = "C";
				} else if (sCurrentLang.indexOf("HU") !== -1 || sCurrentLang.indexOf("hu") !== -1) {
					sCurrentLang = "H";
				} else if (sCurrentLang.indexOf("EL") !== -1 || sCurrentLang.indexOf("el") !== -1) {
					sCurrentLang = "G";
				} else if (sCurrentLang.indexOf("LT") !== -1 || sCurrentLang.indexOf("lt") !== -1) {
					sCurrentLang = "X";
				} else if (sCurrentLang.indexOf("SK") !== -1 || sCurrentLang.indexOf("sk") !== -1) {
					sCurrentLang = "Q";
				} else if (sCurrentLang.indexOf("TR") !== -1 || sCurrentLang.indexOf("tr") !== -1) {
					sCurrentLang = "T";
				} else if (sCurrentLang.indexOf("BG") !== -1 || sCurrentLang.indexOf("bg") !== -1) {
					sCurrentLang = "W";
				} else if (sCurrentLang.indexOf("DA") !== -1 || sCurrentLang.indexOf("da") !== -1) {
					sCurrentLang = "K";
				} else if (sCurrentLang.indexOf("FI") !== -1 || sCurrentLang.indexOf("fi") !== -1) {
					sCurrentLang = "U";
				} else if (sCurrentLang.indexOf("SV") !== -1 || sCurrentLang.indexOf("sv") !== -1) {
					sCurrentLang = "V";
				} else {
					sCurrentLang = "E";
				}
				return sCurrentLang;
			},

			tableBinding: function(tableData) {
				/*Pass Data to Tables*/
				var that = this;
				var oTemplate = new sap.m.ColumnListItem({
					type: "Navigation",
					cells: [
						new sap.m.Text({
							text: "{Location}"
						}).addStyleClass("bold"),
						new sap.m.Text({
							text: "{LocDesc}"
						}),
						new sap.m.Text({
							text: "{TrailerId}"
						}),
						new sap.m.Text({
							text: "{Delivery}"
						}),
						new sap.m.Text({
							text: "{Plant}" // visible only for parent plant scenario.
						}),
						new sap.m.Text({
							text: "{Action}"
						}),
						/*	new sap.m.ObjectStatus({
							text: {
								parts: [{
									path: "BlockDate"
								}],
								formatter: function(blckdate) {
									return formatter.BlockDate(blckdate);
								}
							}
						}),
						new sap.m.ObjectStatus({
							text: {
								parts: [{
									path: "UnblockDate"
								}],
								formatter: function(unblckdate) {
									return formatter.UnBlockDate(unblckdate);
								}
							}
						}),
						new sap.m.ObjectStatus({
							text: {
								parts: [{
									path: "RejectionDate"
								}],
								formatter: function(rejectdate) {
									return formatter.RejectionDate(rejectdate);
								}
							}
						}),*/
						new sap.m.ObjectStatus({
							text: {
								parts: [{
									path: "Updatetime"
								}, {
									path: "Region"
								}],
								formatter: function(updttime, Region) {
									return formatter.UpdateTime(updttime, Region);
								}
							}
						}),
						new sap.m.Text({
							text: "{UserId}"
								// design: "Bold"
						}).addStyleClass("bold"),
						/*new sap.m.Text({
							text: "{FailedCheck}"
						}),*/
						/*	new sap.m.HBox({
							items: [
								new sap.ui.core.Icon({
									src: "sap-icon://action"
								}).addStyleClass("sapUiLargeMarginBegin"),
								new sap.m.Link({
									text: "Reasons",
									press: "onReasonPress"
								}).addStyleClass("sapUiTinyMarginBegin")
							]
						}),*/
						// new sap.m.Button({
						// 	icon: "sap-icon://manager-insight",
						// 	text: "{i18n>reasons}",
						// 	type: "Emphasized",
						// 	visible: "{= ${Flag} === 'X' ? true : false }",
						// 	press: function(oEvent) {
						// 		that.onReasonPress(oEvent);
						// 	}
						// }).addStyleClass("sapUiMediumMarginBegin"),
						new sap.m.Text({
							text: "{Reason_comment}"
						}),
						new sap.m.Button({
							icon: "sap-icon://discussion",
							text: "{i18n>comments}",
							type: "Reject",
							visible: "{= ${Flag} === 'X' ? true : false }",
							press: function(oEvent) {
								that.onCommentPress(oEvent);
							}
						}).addStyleClass("")
						// new sap.m.Text({
						// 	text: "{Reason}"
						// }),
						// new sap.m.Text({
						// 	text: "{Comments}"
						// })
					]
				});

				/*Table Binding*/
				var oRejReportTable = sap.ui.getCore().byId("RejReportTab");
				var oModel1 = new sap.ui.model.json.JSONModel();
				oModel1.setSizeLimit(tableData.length);
				oModel1.setData(tableData);
				if (oRejReportTable !== undefined) {
					oRejReportTable.setModel(oModel1);
					oRejReportTable.bindAggregation("items", {
						path: "/",
						template: oTemplate
					});
				}
				/*Table Grouping*/
				var oGroupingModel = new JSONModel({
					hasGrouping: false
				});
				this.getView().setModel(oGroupingModel, 'Grouping');

			},
			onRejectionTableUpdateFinished: function(oEvent) {
				// var oData = sap.ui.getCore().byId("RejReportTab").getModel().getData();
				var aItems = sap.ui.getCore().byId("RejReportTab").getItems();
				// var data =oData.results;
				/*	for (var i = 0; i < oData.length; i++) {
					if (oData[i].Zymstatus === "DELE") {
						aItems[i].addStyleClass("redBack");
					}
				}*/
				for (var i = 0; i < aItems.length; i++) {
					var sObj = aItems[i].getBindingContext().getObject();
					if (sObj.Zymstatus === "DELE") {
						aItems[i].addStyleClass("redBack");
					} else {
						aItems[i].removeStyleClass("redBack");
					}
				}
			},
			onReasonPress: function(oEvent) {
				var that = this;
				if (!that.oReasonPopover) {
					that.oReasonPopover = sap.ui.xmlfragment("com.report.fragments.ReasonPop", that);
					that.getView().addDependent(that.oReasonPopover);
				}
				that.oReasonPopover.openBy(oEvent.getSource());

				var path = oEvent.getSource().getBindingContext().getPath();
				var sPath = path.substr(1);
				var docID = oEvent.getSource().getBindingContext().getModel().getData()[sPath].Delivery;

				var statFilter = [];
				statFilter.push(new sap.ui.model.Filter("Werks", sap.ui.model.FilterOperator.EQ, vPlant));
				statFilter.push(new sap.ui.model.Filter("DocId", sap.ui.model.FilterOperator.EQ, docID));

				var statusModel = that.getOwnerComponent().getModel("statusModel");
				statusModel.read("/GetRejectInfoSet", {
					filters: statFilter,
					success: function(oData, oResponse) {

						if (oResponse.statusCode === 200) {
							var zymstatModel = new sap.ui.model.json.JSONModel();
							zymstatModel.setData(oData.results);
							// zymstatModel.setSizeLimit(oData.results.length);
							that.getView().setModel(zymstatModel, "rejectStatusModel");
						}
					},
					error: function() {
						MessageBox.show("Error");
					}
				});
			},

			onCommentPress: function(oEvent) {
				var that = this;
				if (!that.oCommentPopover) {
					that.oCommentPopover = sap.ui.xmlfragment("com.report.fragments.CommentsPop", that);
					that.getView().addDependent(that.oCommentPopover);
				}
				that.oCommentPopover.openBy(oEvent.getSource());

				var sCurrentLang = that.getCurrentLanguage();

				var path = oEvent.getSource().getBindingContext().getPath();
				var sPath = path.substr(1);
				var docID = oEvent.getSource().getBindingContext().getModel().getData()[sPath].Delivery;

				// var commentFilter = [];
				// commentFilter.push(new sap.ui.model.Filter("Werks", sap.ui.model.FilterOperator.EQ, vPlant));
				// commentFilter.push(new sap.ui.model.Filter("DocId", sap.ui.model.FilterOperator.EQ, docID));
				// commentFilter.push(new sap.ui.model.Filter("Spras", sap.ui.model.FilterOperator.EQ, sCurrentLang));

				var commentModel = that.getOwnerComponent().getModel("commentModel");
				commentModel.read("/CommentsSet(DocId='" + docID + "',Werks='" + vPlant + "',Spras='" + sCurrentLang + "')", {
					// filters: commentFilter,
					success: function(oData, oResponse) {

						if (oResponse.statusCode === 200) {
							var commModel = new JSONModel();
							commModel.setData(oData);
							that.getView().setModel(commModel, "commentsModel");
							console.log(oData);
							// console.log(	that.getView().getModel("commentsModel"));
						}
					},
					error: function() {
						MessageBox.show("Error");
					}
				});

			},

			//----------------------------------------------------------------------------------
			//Function to create Busy Dialog
			//----------------------------------------------------------------------------------
			fnCreateBusyDialog: function(sImage, sBusy) {
				var that = this;
				//	that.oInsCreateDailog;
				if (sBusy === "true") {
					that.oInsCreateDailog = new sap.m.Dialog({
						showHeader: false
					}).addStyleClass("busyDialog sapUiTinyMargin");
					var sComponentName = that.getOwnerComponent().getMetadata().getComponentName();
					var imgUrl = $.sap.getModulePath(sComponentName, "/images/");
					var oImage = new sap.m.Image().addStyleClass("sapUiMediumMargin");
					oImage.setSrc(imgUrl + sImage);
					that.oInsCreateDailog.addContent(oImage);
					that.oInsCreateDailog.open();
				} else {
					that.oInsCreateDailog.close();
				}
			},

			loadFiltersData: function() {
				var filterResults = sap.ui.getCore().byId("RejReportTab").getModel().getData();

				//----Binded unique data of Location to filter fragment----//
				var Locationarray = [];
				for (var i = 0; i < filterResults.length; i++) {
					if (Locationarray.indexOf(filterResults[i].Location) === -1) {
						Locationarray.push(filterResults[i].Location);
					}
				}
				if (sap.ui.getCore().byId("LocationFilter") !== undefined) {
					sap.ui.getCore().byId("LocationFilter").setModel(new JSONModel(Locationarray), "sLocation");
				}

				//----Binded unique data of Users to filter fragment----//
				var Userarray = [];
				for (var i = 0; i < filterResults.length; i++) {
					if (Userarray.indexOf(filterResults[i].UserId) === -1) {
						Userarray.push(filterResults[i].UserId);
					}
				}
				if (sap.ui.getCore().byId("UserFilter") !== undefined) {
					sap.ui.getCore().byId("UserFilter").setModel(new JSONModel(Userarray), "sUser");
				}
				
					//----CTRM-1424 Binded unique data of Action to filter fragment----//
				var Actionarray = [];
				for (var i = 0; i < filterResults.length; i++) {
					if (Actionarray.indexOf(filterResults[i].Action) === -1) {
						Actionarray.push(filterResults[i].Action);
					}
				}
				if (sap.ui.getCore().byId("actionFilter") !== undefined) {
					sap.ui.getCore().byId("actionFilter").setModel(new JSONModel(Actionarray), "sAction");
				}
				
				//----Binded unique data of parentplants to filter fragment----//
				var parentplant = [];
				for (var i = 0; i < filterResults.length; i++) {
					if (parentplant.indexOf(filterResults[i].Plant) === -1) {
						parentplant.push(filterResults[i].Plant);
					}
				}
				if (sap.ui.getCore().byId("RejPlantFilter") !== undefined) {
					sap.ui.getCore().byId("RejPlantFilter").setModel(new JSONModel(parentplant), "sParentPlant");
				}
			},

			onFilterPressed: function() {
				var that = this;
				that.oInsCreateDailog.open();

				if (!this._filterDialog) {
					this._filterDialog = sap.ui.xmlfragment("com.report.fragments.RejectFilter", this);
					this.getView().addDependent(this._filterDialog);
				}
				/*** adding filter items for the multiplant/ parentplant scenario ***/
				var parentplant = this.getView().getModel("ViewModel").getProperty("/ParentPlant");
				if (parentplant !== "") {
					if (sap.ui.getCore().byId("RejPlantFilter") === undefined) {
						var ParentPlantFilter = new sap.m.ViewSettingsFilterItem("RejPlantFilter", {
							multiSelect: true,
							text: "{i18n>Plant}"

						});
						var Template = new sap.m.ViewSettingsItem({
							key: "Plant",
							text: "{sParentPlant>}"
						});
						ParentPlantFilter.bindAggregation("items", "sParentPlant>/", Template);
						this._filterDialog.addFilterItem(ParentPlantFilter);
					}
				}
				this.loadFiltersData();
				// toggle compact style
				jQuery.sap.syncStyleClass("sapUiSizeCompact", this.getView(), this._filterDialog);
				this._filterDialog.open();

				that.oInsCreateDailog.close();
			},

			//---------------------Code for filtering----------------------//

			onFilterConfirm: function(oEvent) {
				var that = this;
				that.oInsCreateDailog.open();
				var oView = sap.ui.getCore();
				if (oView.byId("RejReportTab") !== undefined) {
					var rejTableFilter = oView.byId("RejReportTab");
					var mParams = oEvent.getParameters();
					var oBinding = rejTableFilter.getBinding("items");
					var aFilters = [];
					for (var i = 0, l = mParams.filterItems.length; i < l; i++) {
						var oItem = mParams.filterItems[i];
						if (oItem.getKey() === "Location") {
							var oFilter1 = new sap.ui.model.Filter("Location", "EQ", oItem.getText());
							aFilters.push(oFilter1);
						} else if (oItem.getKey() === "User") {
							var oFilter2 = new sap.ui.model.Filter("UserId", "EQ", oItem.getText());
							aFilters.push(oFilter2);
						} else if (oItem.getKey() === "Plant") {
							var oFilter3 = new sap.ui.model.Filter("Plant", "EQ", oItem.getText());
							aFilters.push(oFilter3);
						}else if (oItem.getKey() === "Action") {
						 var oFilter4 = new sap.ui.model.Filter("Action", "EQ", oItem.getText()); 	//CTRM-1424
							aFilters.push(oFilter4);
						}
					}
					oBinding.filter(aFilters);
				}

				that.oInsCreateDailog.close();

				if (oEvent.getParameters().filterString) {
					var filteredData = oEvent.getParameters().filterString;
				}
				sap.ui.getCore().byId("rejectheaderData").setText(filteredData);
			},

			onTableRefresh: function() {
				//Remove Filters
				if (sap.ui.getCore().byId("RejReportTab") !== undefined) {
					var oTable = sap.ui.getCore().byId("RejReportTab");
					var oModel = oTable.getModel();
					var oTableBinding = oTable.getBinding("items");
					oTableBinding.aSorters = null;
					oTableBinding.aFilters = null;
					oModel.refresh(true);
				}
				if (sap.ui.getCore().byId("rejectheaderData") !== undefined) {
					sap.ui.getCore().byId("rejectheaderData").setText("");
				}
				this.resetFilterItems();
			},

			resetFilterItems: function() {
				var that = this;
				that.oInsCreateDailog.open();
				if (this._filterDialog !== undefined) {
					var aFilterItems = this._filterDialog.getFilterItems();

					aFilterItems.forEach(function(item) {
						var aItems = item.getItems();
						aItems.forEach(function(item) {
							item.setSelected(false);
						});
					});
				}
				that.oInsCreateDailog.close();
			},

			//----------------Code for opening Sorter Dailog when sorter icon pressed---------------------//

			onSorterPressed: function() {
				var that = this;
				that.oInsCreateDailog.open();
				if (!this._sorterDialog) {
					this._sorterDialog = sap.ui.xmlfragment("com.report.fragments.RejectSorter", this);
					this.getView().addDependent(this._sorterDialog);
				}
				/*** adding sort items for the multiplant scenario ***/
				var parentplant = this.getView().getModel("ViewModel").getProperty("/ParentPlant");
				if (parentplant !== "") {
					if (sap.ui.getCore().byId("RejPlantSorter") === undefined) {
						var ParentPlantSort = new sap.m.ViewSettingsItem("RejPlantSorter", {
							text: "{i18n>Plant}",
							key: "Plant"

						});
						this._sorterDialog.addSortItem(ParentPlantSort);
					}
				}
				// toggle compact style
				jQuery.sap.syncStyleClass("sapUiSizeCompact", this.getView(), this._sorterDialog);
				this._sorterDialog.open();
				that.oInsCreateDailog.close();
			},

			//-----------------------Code for Sorting---------------------------//

			onSortConfirm: function(oEvent) {

				var that = this;
				that.oInsCreateDailog.open();
				var oView = sap.ui.getCore();
				if (oView.byId("RejReportTab") !== undefined) {
					var rejecRepTable = oView.byId("RejReportTab");
					var mParams = oEvent.getParameters();
					var oBinding = rejecRepTable.getBinding("items");
					var aSorters = [];
					if (mParams.sortItem !== undefined) {
						var sPath = mParams.sortItem.getKey();
						var bDescending = mParams.sortDescending;
						aSorters.push(new sap.ui.model.Sorter(sPath, bDescending));
						oBinding.sort(aSorters);
					}
				}

				that.oInsCreateDailog.close();
			},

			//-----------------------------------------------------------------------------------------
			// Function for expanding the pnales inside the plant panels
			//-----------------------------------------------------------------------------------------
			onPressExp: function(oEvent) {
				var oPanelId = oEvent.getSource().getParent().getParent().getId();
				var oButtonId = oEvent.getSource().getId();
				if (sap.ui.getCore().byId(oPanelId).getExpanded()) {
					sap.ui.getCore().byId(oPanelId).setExpanded(false);
					sap.ui.getCore().byId(oButtonId).setIcon("sap-icon://expand-group");
				} else {
					sap.ui.getCore().byId(oPanelId).setExpanded(true);
					sap.ui.getCore().byId(oButtonId).setIcon("sap-icon://collapse-group");
				}
			},

			//-----------------------------------------------------------------------------------------
			// Function for table export
			//-----------------------------------------------------------------------------------------

			onPressExport: sap.m.Table.prototype.exportData || function(oEvent) {
				var oExport = new Export({
					exportType: new ExportTypeCSV({
						separatorChar: ",",
						fileExtension: "csv"
					}),
					models: sap.ui.getCore().byId("RejReportTab").getModel(),
					rows: {
						path: "/"
					},

					columns: [{
							// name: "Location",
							name: this.getOwnerComponent().getModel("i18n").getProperty("location"),
							template: {
								content: "{Location}"
							}
						}, {
							// name: "Location Description",
							name: this.getOwnerComponent().getModel("i18n").getProperty("LocationDesc"),
							template: {
								content: "{LocDesc}"
							}
						}, {
							// name: "Trailer ID",
							name: this.getOwnerComponent().getModel("i18n").getProperty("trailId"),
							template: {
								content: "{TrailerId}"
							}
						}, {
							// name: "Delivery",
							name: this.getOwnerComponent().getModel("i18n").getProperty("delivery"),
							template: {
								content: "{Delivery}"
							}
						}, {
							// name: "Action",
							name: this.getOwnerComponent().getModel("i18n").getProperty("Action"),
							template: {
								content: "{Action}"
							}
						},
						/* {
							// name: "Block Date",
							name: this.getOwnerComponent().getModel("i18n").getProperty("blockDate"),
							template: {
								// content: "{BlockDate}"
								content: {
									parts: ["BlockDate"],
									formatter: function(blckdate) {
										if (blckdate !== null && blckdate !== "0") {
											var newBlockDate = blckdate.slice(4, 6) + "/" + blckdate.slice(6, 8) + "/" + blckdate.slice(0, 4) + " " + blckdate.slice(8,
													10) + ":" +
												blckdate.slice(10, 12) + ":" + blckdate.slice(12, 14);
											return newBlockDate;
										}
									}
								}
							}
						}, {
							// name: "Unblock Date",
							name: this.getOwnerComponent().getModel("i18n").getProperty("unblockDate"),
							template: {
								// content: "{UnblockDate}"
								content: {
									parts: ["UnblockDate"],
									formatter: function(unblckdate) {
										if (unblckdate !== null && unblckdate !== "0") {
											var newUnBlockDate = unblckdate.slice(4, 6) + "/" + unblckdate.slice(6, 8) + "/" + unblckdate.slice(0, 4) + " " + unblckdate
												.slice(8, 10) + ":" +
												unblckdate.slice(10, 12) + ":" + unblckdate.slice(12, 14);
											return newUnBlockDate;
										}
									}
								}
							}
						},*/
						{
							// name: "Updated time",
							name: this.getOwnerComponent().getModel("i18n").getProperty("UpdateTime"),
							template: {
								content: {
									parts: ["Updatetime", "Region"],
									formatter: function(UpdateTime, Region) {
										if (Region === "EU" || Region === "LATAM" || Region === "ZA") {
											if (UpdateTime !== null && UpdateTime !== "0") {
												var newUpdateTime = UpdateTime.slice(6,8) + "/" + UpdateTime.slice(4,6) + "/" + UpdateTime.slice(0, 4) + " " +
													UpdateTime.slice(8, 10) + ":" +
													UpdateTime.slice(10, 12) + ":" + UpdateTime.slice(12, 14);
												return newUpdateTime;
											}
										} else {
											if (UpdateTime !== null && UpdateTime !== "0") {
												var newUpdateTime = UpdateTime.slice(4, 6) + "/" + UpdateTime.slice(6, 8) + "/" + UpdateTime.slice(0, 4) + " " +
													UpdateTime.slice(8, 10) + ":" +
													UpdateTime.slice(10, 12) + ":" + UpdateTime.slice(12, 14);
												return newUpdateTime;
											}
										}
									}
								}
							}
						}, {
							// name: "User ID",
							name: this.getOwnerComponent().getModel("i18n").getProperty("userID"),
							template: {
								content: "{UserId}"
							}
							// }, {
							// 	name: "Failed Checklist Questions",
							// 	template: {
							// 		content: "{FailedCheck}"
							// 	}
							/*	}, {
							name: "Reason entered on checklist",
							template: {
								content: "{Reason}"
							}
						}, {
							name: "Comments",
							template: {
								content: "{Comments}"
							}*/
						}, {
							// name: "Action",
							name: this.getOwnerComponent().getModel("i18n").getProperty("reasonChecklist"),
							template: {
								content: "{Reason_comment}"
							}
						}

					]
				});

				/*** add this column only when parentplant is active ***/
				var parentplant = this.getView().getModel("ViewModel").getProperty("/ParentPlant");
				if (parentplant !== "") {
					oExport.insertColumn(new sap.ui.core.util.ExportColumn({
						name: this.getOwnerComponent().getModel("i18n").getProperty("Plant"),
						template: {
							content: "{Plant}"
						}
					}), 0);
				}

				var srejectDetails = this.getOwnerComponent().getModel("i18n").getProperty("rejectDetails");
				oExport.saveFile(srejectDetails).catch(function(oError) {
					// MessageBox.error("Error when downloading data. Browser might not be supported!\n\n" + oError);
				}).then(function() {
					oExport.destroy();
				});
			},

			onPressExportXLS: sap.m.Table.prototype.exportData || function(oEvent) {
				var oExport = new Export({
					exportType: new ExportTypeCSV({
						separatorChar: "\t",
						fileExtension: "xls"
					}),
					models: sap.ui.getCore().byId("RejReportTab").getModel(),
					rows: {
						path: "/"
					},

					columns: [{
							// name: "Location",
							name: this.getOwnerComponent().getModel("i18n").getProperty("location"),
							template: {
								content: "{Location}"
							}
						}, {
							// name: "Location Description",
							name: this.getOwnerComponent().getModel("i18n").getProperty("LocationDesc"),
							template: {
								content: "{LocDesc}"
							}
						}, {
							// name: "Trailer ID",
							name: this.getOwnerComponent().getModel("i18n").getProperty("trailId"),
							template: {
								content: "{TrailerId}"
							}
						}, {
							// name: "Delivery",
							name: this.getOwnerComponent().getModel("i18n").getProperty("delivery"),
							template: {
								content: "{Delivery}"
							}
						}, {
							// name: "Action",
							name: this.getOwnerComponent().getModel("i18n").getProperty("Action"),
							template: {
								content: "{Action}"
							}
						},
						/* {
							// name: "Block Date",
							name: this.getOwnerComponent().getModel("i18n").getProperty("blockDate"),
							template: {
								// content: "{BlockDate}"
								content: {
									parts: ["BlockDate"],
									formatter: function(blckdate) {
										if (blckdate !== null && blckdate !== "0") {
											var newBlockDate = blckdate.slice(4, 6) + "/" + blckdate.slice(6, 8) + "/" + blckdate.slice(0, 4) + " " + blckdate.slice(8,
													10) + ":" +
												blckdate.slice(10, 12) + ":" + blckdate.slice(12, 14);
											return newBlockDate;
										}
									}
								}
							}
						}, {
							// name: "Unblock Date",
							name: this.getOwnerComponent().getModel("i18n").getProperty("unblockDate"),
							template: {
								// content: "{UnblockDate}"
								content: {
									parts: ["UnblockDate"],
									formatter: function(unblckdate) {
										if (unblckdate !== null && unblckdate !== "0") {
											var newUnBlockDate = unblckdate.slice(4, 6) + "/" + unblckdate.slice(6, 8) + "/" + unblckdate.slice(0, 4) + " " + unblckdate
												.slice(8, 10) + ":" +
												unblckdate.slice(10, 12) + ":" + unblckdate.slice(12, 14);
											return newUnBlockDate;
										}
									}
								}
							}
						},*/
						{
							// name: "Updated time",
							name: this.getOwnerComponent().getModel("i18n").getProperty("UpdateTime"),
							template: {
								content: {
									parts: ["Updatetime","Region"],
									formatter: function(UpdateTime,Region) {
										if(Region === "EU" || Region === "LATAM" || Region === "ZA"){
											if (UpdateTime !== null && UpdateTime !== "0") {
											var newUpdateTime = UpdateTime.slice(6,8) + "/" + UpdateTime.slice(4,6) + "/" + UpdateTime.slice(0, 4) + " " +
												UpdateTime.slice(8, 10) + ":" +
												UpdateTime.slice(10, 12) + ":" + UpdateTime.slice(12, 14);
											return newUpdateTime;
										}	
										}
										if (UpdateTime !== null && UpdateTime !== "0") {
											var newUpdateTime = UpdateTime.slice(4, 6) + "/" + UpdateTime.slice(6, 8) + "/" + UpdateTime.slice(0, 4) + " " +
												UpdateTime.slice(8, 10) + ":" +
												UpdateTime.slice(10, 12) + ":" + UpdateTime.slice(12, 14);
											return newUpdateTime;
										}
									}
								}
							}
						}, {
							// name: "User ID",
							name: this.getOwnerComponent().getModel("i18n").getProperty("userID"),
							template: {
								content: "{UserId}"
							}
							// }, {
							// 	name: "Failed Checklist Questions",
							// 	template: {
							// 		content: "{FailedCheck}"
							// 	}
							/*	}, {
							name: "Reason entered on checklist",
							template: {
								content: "{Reason}"
							}
						}, {
							name: "Comments",
							template: {
								content: "{Comments}"
							}*/
						}, {
							// name: "Action",
							name: this.getOwnerComponent().getModel("i18n").getProperty("reasonChecklist"),
							template: {
								content: "{Reason_comment}"
							}
						}

					]
				});

				/*** add this column only when parentplant is active ***/
				var parentplant = this.getView().getModel("ViewModel").getProperty("/ParentPlant");
				if (parentplant !== "") {
					oExport.insertColumn(new sap.ui.core.util.ExportColumn({
						name: this.getOwnerComponent().getModel("i18n").getProperty("Plant"),
						template: {
							content: "{Plant}"
						}
					}), 0);
				}

				var srejectDetails = this.getOwnerComponent().getModel("i18n").getProperty("rejectDetails");
				oExport.saveFile(srejectDetails).catch(function(oError) {
					// MessageBox.error("Error when downloading data. Browser might not be supported!\n\n" + oError);
				}).then(function() {
					oExport.destroy();
				});
			},

			onNavButtonPress: function() {
				sap.ui.getCore().byId("RejReportTab").destroyItems();
				var oRouter = sap.ui.core.UIComponent.getRouterFor(this);
				oRouter.navTo("ReportInter");
			},

			onPersoButtonPressed: function(oEvent) {
				this._oTPC.openDialog();
			},

			onTablePersoRefresh: function() {
				RejectionPersoService.resetPersData();
				this._oTPC.refresh();
			},

			onTableGrouping: function(oEvent) {
				// alert("msg")
				// this._oTPC.setHasGrouping(oEvent.getSource().getSelected());
				this._oTPC.setHasGrouping(sap.ui.getCore().byId("rejectgroupCheck").getSelected());

			}

		});
	});