var oRegion1;
var vRegion;
sap.ui.define([
		"sap/ui/core/mvc/Controller",
		"sap/ui/layout/form/GridLayout",
		"sap/m/Panel",
		"sap/ui/model/json/JSONModel",
		"com/report/model/DemoPersoService",
		"sap/m/TablePersoController",
		"sap/ui/core/util/Export",
		"sap/ui/core/util/ExportTypeCSV",
		"sap/ui/model/Filter",
		"sap/ui/model/Sorter",
		"com/report/model/formatter"
	],
	function(Controller, GridLayout, Panel, JSONModel, DemoPersoService, TablePersoController, Export, ExportTypeCSV, Filter, Sorter,
		formatter) {
		"use strict";
		return Controller.extend("com.report.controller.ReportUsage", {
			formatter: formatter,

			onInit: function() {
				jQuery.sap.require("jquery.sap.storage");
				var that = this;
				var oViewObj = {
					PreloadedFlag: false,
					ParentPlant: jQuery.sap.storage(jQuery.sap.storage.Type.local).get("ParentPlant"),
					region: jQuery.sap.storage(jQuery.sap.storage.Type.local).get("region")
				};
				var oViewModel = new JSONModel(oViewObj);
				that.getView().setModel(oViewModel, "ViewModel");
				var oRouter = sap.ui.core.UIComponent.getRouterFor(this);
				oRouter.getRoute("ReportUsage").attachMatched(this._onRouteMatched, this);

				var oDesktopDevice = sap.ui.Device.system.desktop;
				if (oDesktopDevice === true) {
					var oTitleBar = sap.ui.xmlfragment(this.createId("Plant_Detail_Bar_ID"), "com.report.fragments.PlantDetails", this);
					this.getView().addDependent(oTitleBar);
					this.getView().byId("RUsagePage").addContent(oTitleBar);
				} else {
					var oTitleBarMobile = sap.ui.xmlfragment(this.createId("Header_PlantDetail_Mobile_Bar_ID"),
						"com.report.fragments.MobileHeaderPlantDetails", this);
					this.getView().addDependent(oTitleBarMobile);
					this.getView().byId("RUsagePage").addContent(oTitleBarMobile);
				}

				var oGridLayout = new sap.ui.layout.Grid({
					defaultSpan: "L12 M12 S12",
					content: [
						// new sap.m.Panel("Usagepanel", {
						// 	expandable: false,
						// 	expanded: false,
						// 	headerText: "Plant Details",
						// 	content: [
						// 		//////////////////////////////
						// 		new sap.ui.layout.Grid({
						// 			hSpacing: 0,
						// 			vSpacing: 0,
						// 			defaultSpan: "L6 M6 S12",
						// 			content: [

						// 				new sap.ui.layout.Grid({
						// 					hSpacing: 0,
						// 					vSpacing: 0,
						// 					defaultSpan: "L6 M6 S12",
						// 					content: [

						// 						new sap.m.Label({
						// 							text: "Plant:",
						// 							design: "Bold",
						// 							layoutData: new sap.ui.layout.GridData({
						// 								linebreakL: true,
						// 								linebreakM: true,
						// 								linebreakS: true,
						// 								span: "L4 M6 S12"
						// 							})
						// 						}),
						// 						new sap.m.Text({
						// 							text: "GB03",
						// 							width: "100%"
						// 						}),
						// 						new sap.m.Label({
						// 							text: "Date:",
						// 							design: "Bold",
						// 							layoutData: new sap.ui.layout.GridData({
						// 								linebreakL: true,
						// 								linebreakM: true,
						// 								linebreakS: true,
						// 								span: "L4 M6 S12"
						// 							})
						// 						}),
						// 						new sap.m.Text({
						// 							text: "21/12/2018",
						// 							width: "100%"
						// 						}),

						// 						new sap.m.Label({
						// 							text: "Start Time:",
						// 							design: "Bold",
						// 							layoutData: new sap.ui.layout.GridData({
						// 								linebreakL: true,
						// 								linebreakM: true,
						// 								linebreakS: true,
						// 								span: "L4 M6 S12"
						// 							})
						// 						}),
						// 						new sap.m.Text({
						// 							text: "15:05",
						// 							width: "100%"
						// 						}),

						// 						new sap.m.Label({
						// 							text: "End Time:",
						// 							design: "Bold",
						// 							layoutData: new sap.ui.layout.GridData({
						// 								linebreakL: true,
						// 								linebreakM: true,
						// 								linebreakS: true,
						// 								span: "L4 M6 S12"
						// 							})
						// 						}),
						// 						new sap.m.Text({
						// 							text: "15:30",
						// 							width: "100%"
						// 						})

						// 					]
						// 				})

						// 			]
						// 		})

						// 	]
						// }).addStyleClass("pHeading panelBackground"),

						//-------start: code for summary(both issues and returns) panel--------------//			
						new sap.m.Panel("Summarypanel", {
							expandable: false,
							expanded: false,
							// headerText: "{i18n>summary}",
							headerToolbar: new sap.m.Toolbar({
								content: [
									new sap.m.Title({
										text: "{i18n>summary}"
									}).addStyleClass("pHeaderText")
								]
							}),
							content: [
								new sap.m.Panel("SummaryIssuepanel", {
									expandable: true,
									expanded: false,
									headerToolbar: new sap.m.Toolbar({
										content: [
											new sap.m.Title({
												text: "{= ${ViewModel>/PreloadedFlag} === true ? ${i18n>IssuesCompleteTitle} : ${i18n>issues} }"
											}).addStyleClass("pHeaderText"),

											new sap.m.ToolbarSpacer({}),
											new sap.m.Button({
												icon: "sap-icon://expand-group",
												press: function(oEvent) {
													that.onPressExp(oEvent);
												}
											}).addStyleClass("headerButton")
										],
										active: true,
										press: function(oEvent) {
											// console.log("pressed");
											that.panelHeaderClick(oEvent);
										}
									}),
									content: [
										new sap.m.Table("issueTable", {
											columns: [new sap.m.Column({
													header: [new sap.m.Label({
														text: "{= ${ViewModel>/PreloadedFlag} === true ? ${i18n>CompletedDel} : ${i18n>totalDel} }",
														design: "Bold"
													})]
												}),
												new sap.m.Column({
													header: [new sap.m.Label({
														text: "{i18n>material}",
														design: "Bold"
													})]
												}),
												new sap.m.Column({
													header: [new sap.m.Label({
														text: "{i18n>batch}",
														design: "Bold"
													})]
												}),
												new sap.m.Column({
													header: [new sap.m.Label({
														text: "{i18n>total}",
														design: "Bold"
													})]
												})
											]
										})
									]
								}).addStyleClass("sumHeading"),
								new sap.m.Panel("SummaryIssuePreloadedpanel", {
									expandable: true,
									expanded: false,
									visible: "{ViewModel>/PreloadedFlag}",
									headerToolbar: new sap.m.Toolbar({
										content: [
											new sap.m.Title({
												text: "{i18n>IssuesPreloadTitle}"
											}).addStyleClass("pHeaderText"),
											new sap.m.ToolbarSpacer({}),
											new sap.m.Button({
												icon: "sap-icon://expand-group",
												press: function(oEvent) {
													that.onPressExp(oEvent);
												}
											}).addStyleClass("headerButton")
										],
										active: true,
										press: function(oEvent) {
											// console.log("pressed");
											that.panelHeaderClick(oEvent);
										}
									}),
									content: [
										new sap.m.Table("issuePreloadTable", {
											columns: [new sap.m.Column({
													header: [new sap.m.Label({
														text: "{i18n>PreloadedDel}",
														design: "Bold"
													})]
												}),
												new sap.m.Column({
													header: [new sap.m.Label({
														text: "{i18n>material}",
														design: "Bold"
													})]
												}),
												new sap.m.Column({
													header: [new sap.m.Label({
														text: "{i18n>batch}",
														design: "Bold"
													})]
												}),
												new sap.m.Column({
													header: [new sap.m.Label({
														text: "{i18n>total}",
														design: "Bold"
													})]
												})
											]
										})
									]
								}).addStyleClass("sumHeading"),
								new sap.m.Panel("SummaryReturnpanel", {
									expandable: true,
									expanded: false,
									// headerText: "Summary",

									headerToolbar: new sap.m.Toolbar({
										content: [
											new sap.m.Title({
												text: "{i18n>returns}"
											}).addStyleClass("pHeaderText"),
											new sap.m.ToolbarSpacer({}),
											new sap.m.Button({
												icon: "sap-icon://expand-group",
												press: function(oEvent) {
													that.onPressExp(oEvent);
												}
											}).addStyleClass("headerButton")
										],
										active: true,
										press: function(oEvent) {
											// console.log("pressed");
											that.panelHeaderClick(oEvent);
										}
									}),
									content: [
										new sap.m.Table("returnTable", {
											columns: [new sap.m.Column({
													header: [new sap.m.Label({
														text: "{i18n>totalDel}",
														design: "Bold"
													})]
												}),
												new sap.m.Column({
													header: [new sap.m.Label({
														text: "{i18n>material}",
														design: "Bold"
													})]
												}),
												new sap.m.Column({
													header: [new sap.m.Label({
														text: "{i18n>batch}",
														design: "Bold"
													})]
												}),
												new sap.m.Column({
													header: [new sap.m.Label({
														text: "{i18n>total}",
														design: "Bold"
													})]
												})
											]
										})
									]
								}).addStyleClass("sumHeading"),
								new sap.m.Panel("SummaryStoIssuepanel", {
									expandable: true,
									expanded: false,
									// headerText: "Summary",

									headerToolbar: new sap.m.Toolbar({
										content: [
											new sap.m.Title({
												text: "{i18n>stoIssue}"
											}).addStyleClass("pHeaderText"),
											new sap.m.ToolbarSpacer({}),
											new sap.m.Button({
												icon: "sap-icon://expand-group",
												press: function(oEvent) {
													that.onPressExp(oEvent);
												}
											}).addStyleClass("headerButton")
										],
										active: true,
										press: function(oEvent) {
											// console.log("pressed");
											that.panelHeaderClick(oEvent);
										}
									}),
									content: [
										new sap.m.Table("StoIssueTable", {
											columns: [new sap.m.Column({
													header: [new sap.m.Label({
														text: "{i18n>totalDel}",
														design: "Bold"
													})]
												}),
												new sap.m.Column({
													header: [new sap.m.Label({
														text: "{i18n>material}",
														design: "Bold"
													})]
												}),
												new sap.m.Column({
													header: [new sap.m.Label({
														text: "{i18n>batch}",
														design: "Bold"
													})]
												}),
												new sap.m.Column({
													header: [new sap.m.Label({
														text: "{i18n>total}",
														design: "Bold"
													})]
												})
											]
										})
									]
								}).addStyleClass("sumHeading"),

								new sap.m.Panel("SummaryStoReturnpanel", {
									expandable: true,
									expanded: false,
									// headerText: "Summary",

									headerToolbar: new sap.m.Toolbar({
										content: [
											new sap.m.Title({
												text: "{i18n>stoReturn}"
											}).addStyleClass("pHeaderText"),
											new sap.m.ToolbarSpacer({}),
											new sap.m.Button({
												icon: "sap-icon://expand-group",
												press: function(oEvent) {
													that.onPressExp(oEvent);
												}
											}).addStyleClass("headerButton")
										],
										active: true,
										press: function(oEvent) {
											// console.log("pressed");
											that.panelHeaderClick(oEvent);
										}
									}),
									content: [
										new sap.m.Table("StoReturnTable", {
											columns: [new sap.m.Column({
													header: [new sap.m.Label({
														text: "{i18n>totalDel}",
														design: "Bold"
													})]
												}),
												new sap.m.Column({
													header: [new sap.m.Label({
														text: "{i18n>material}",
														design: "Bold"
													})]
												}),
												new sap.m.Column({
													header: [new sap.m.Label({
														text: "{i18n>batch}",
														design: "Bold"
													})]
												}),
												new sap.m.Column({
													header: [new sap.m.Label({
														text: "{i18n>total}",
														design: "Bold"
													})]
												})
											]
										})
									]
								}).addStyleClass("sumHeading"),
								new sap.m.Panel("SummaryStoRMPOpanel", {
									expandable: true,
									expanded: false,
									// headerText: "Summary",

									headerToolbar: new sap.m.Toolbar({
										content: [
											new sap.m.Title({
												text: "{i18n>RawMtrlPO}"
											}).addStyleClass("pHeaderText"),
											new sap.m.ToolbarSpacer({}),
											new sap.m.Button({
												icon: "sap-icon://expand-group",
												press: function(oEvent) {
													that.onPressExp(oEvent);
												}
											}).addStyleClass("headerButton")
										],
										active: true,
										press: function(oEvent) {
											// console.log("pressed");
											that.panelHeaderClick(oEvent);
										}
									}),
									content: [
										new sap.m.Table("StoRMPOTable", {
											columns: [new sap.m.Column({
													header: [new sap.m.Label({
														text: "{i18n>totalDel}",
														design: "Bold"
													})]
												}),
												new sap.m.Column({
													header: [new sap.m.Label({
														text: "{i18n>material}",
														design: "Bold"
													})]
												}),
												new sap.m.Column({
													header: [new sap.m.Label({
														text: "{i18n>batch}",
														design: "Bold"
													})]
												}),
												new sap.m.Column({
													header: [new sap.m.Label({
														text: "{i18n>total}",
														design: "Bold"
													})]
												})
											]
										})
									]
								}).addStyleClass("sumHeading")
							]
						}).addStyleClass("pHeading panelBackground"),

						// new sap.m.Panel("Totalpanel", {
						// 	expandable: false,
						// 	expanded: false,
						// 	// headerText: "Total",
						// 	content: [
						// 		new sap.ui.layout.Grid({
						// 			hSpacing: 0,
						// 			vSpacing: 0,
						// 			defaultSpan: "L6 M6 S12",
						// 			content: [

						// 				new sap.m.Label({
						// 					text: "Total Distinct Delivery Number:",
						// 					design: "Bold",
						// 					layoutData: new sap.ui.layout.GridData({
						// 						linebreakL: true,
						// 						linebreakM: true,
						// 						linebreakS: true,
						// 						span: "L4 M6 S12"
						// 					})
						// 				}),
						// 				new sap.m.Text({
						// 					text: "",
						// 					width: "100%"
						// 				}),
						// 				new sap.m.Label({
						// 					text: "Total Sum:",
						// 					design: "Bold",
						// 					layoutData: new sap.ui.layout.GridData({
						// 						linebreakL: true,
						// 						linebreakM: true,
						// 						linebreakS: true,
						// 						span: "L4 M6 S12"
						// 					})
						// 				}),
						// 				new sap.m.Text({
						// 					text: "",
						// 					width: "100%"
						// 				})
						// 			]
						// 		}).addStyleClass()
						// 	]
						// }).addStyleClass("panelBackground"),
						new sap.m.Panel("Tablepanel", {
							expandable: true,
							expanded: true,
							// headerText: "Table Data",
							headerToolbar: new sap.m.Toolbar({
								content: [
									new sap.m.Title({
										text: "{i18n>issueReturn}"
									}).addStyleClass("pHeaderText"),
									new sap.m.ToolbarSpacer({}),
									new sap.m.Button({
										icon: "sap-icon://filter",
										press: function() {
											that.onFilterPressed();
										}
									}).addStyleClass("headerButton"),
									new sap.m.Button({
										icon: "sap-icon://sort",
										press: function() {
											that.onSorterPressed();
										}
									}).addStyleClass("headerButton"),
									new sap.m.Button({
										icon: "sap-icon://expand-group",
										press: function(oEvent) {
											that.onPressExp(oEvent);
										}
									}).addStyleClass("headerButton"),
									new sap.m.Button({
										icon: "sap-icon://refresh",
										press: function() {
											that.onTableRefresh();
										}
									}).addStyleClass("headerButton")
								]
							}),
							content: [
								new sap.m.Toolbar({
									content: [
										new sap.m.Label("headerData", {
											text: "",
											design: "Bold"
										}),
										new sap.m.ToolbarSpacer({}),
										new sap.m.CheckBox("groupCheck", {
											text: "{i18n>enablePerso}",
											select: function() {
												that.onTableGrouping();
											}
										}),
										new sap.m.Button({
											icon: "sap-icon://action-settings",
											press: function() {
												that.onPersoButtonPressed();
											}
										})
									]
								}),
								new sap.m.ScrollContainer("fdescroll", {
									// focusable: true,
									horizontal: true,
									vertical: true,
									height: '15rem',
									content: [
										new sap.m.Table("fdeReportTab", {
											width: "2900px",
											mode: "SingleSelectMaster",
											// select: function(oEvent){
											// 	that.onItemSelected(oEvent);                       
											// },
											// headerText: "Table",
											updateFinished: function(oEvent) {
												that.onTableUpdateFinish(oEvent);
											},
											columns: [new sap.m.Column("parentplant", {
													header: new sap.m.Text({
														text: "{i18n>Plant}"
													}).addStyleClass("columnLabelStyle bold"),
													width: "8%",
													visible: "{= ${ViewModel>/ParentPlant} !==''}"
												}),
												new sap.m.Column("delNum", {
													header: new sap.m.Text({
														text: "{i18n>delNo}"
													}).addStyleClass("columnLabelStyle bold"),
													width: "10%"
													// demandPopin: true,
													// minScreenWidth: "Desktop",
													// popinDisplay: "Inline"
												}),
												new sap.m.Column("carrierName", {
													header: new sap.m.Text({
														text: "{i18n>carrierName}"
													}).addStyleClass("columnLabelStyle bold"),
													width: "10%"
												}),

												new sap.m.Column("delType", {
													header: new sap.m.Text({
														text: "{i18n>delivType}"
													}).addStyleClass("columnLabelStyle bold"),
													width: "6%"
												}),
												new sap.m.Column("transType", {
													header: new sap.m.Text({
														text: "{i18n>transportType}"
													}).addStyleClass("columnLabelStyle bold"),
													width: "6%"
												}),
												new sap.m.Column("userId", {
													header: new sap.m.Text({
														text: "{i18n>userId}"
													}).addStyleClass("columnLabelStyle bold"),
													width: "9%",
													demandPopin: true,
													minScreenWidth: "Desktop",
													popinDisplay: "Inline"
												}),
												/*	new sap.m.Column("ldAcptTime", {
													header: new sap.m.Label({
														text: "Load Accept Time"
													}).addStyleClass("columnLabelStyle"),
													width: "11%",
													demandPopin: true,
													minScreenWidth: "Desktop",
													popinDisplay: "Inline"
												}),*/
												new sap.m.Column("ldStartTime", {
													header: new sap.m.Text({
														text: "{i18n>startTimeFdeRep}"
													}).addStyleClass("columnLabelStyle bold"),
													width: "12%",
													demandPopin: true,
													minScreenWidth: "Desktop",
													popinDisplay: "Inline"
												}),
												new sap.m.Column("ldCompTime", {
													header: new sap.m.Text({
														text: "{i18n>compTime}"
													}).addStyleClass("columnLabelStyle bold"),
													width: "12%",
													demandPopin: true,
													minScreenWidth: "Desktop",
													popinDisplay: "Inline"
												}),
												new sap.m.Column("checkoutTime", {
													header: new sap.m.Text({
														text: "{i18n>checkoutTime}"
													}).addStyleClass("columnLabelStyle bold"),
													width: "12%",
													demandPopin: true,
													minScreenWidth: "Desktop",
													popinDisplay: "Inline",
													visible: "{chkoutVisModel>/checkoutVisibility}"
												}),
												new sap.m.Column("prdCode", {
													header: new sap.m.Text({
														text: "{i18n>prdCode}"
													}).addStyleClass("columnLabelStyle bold"),
													width: "10%"
												}),
												new sap.m.Column("batch", {
													header: new sap.m.Text({
														text: "{i18n>batch}"
													}).addStyleClass("columnLabelStyle bold"),
													width: "10%"
												}),
												new sap.m.Column("qty", {
													header: new sap.m.Text({
														text: "{i18n>qty}"
													}).addStyleClass("columnLabelStyle bold"),
													width: "6%",
													demandPopin: true,
													minScreenWidth: "Desktop",
													popinDisplay: "Inline"
												}),
												new sap.m.Column("plannedQty", {
													header: new sap.m.Text({
														text: "{i18n>plannedQty}"
													}).addStyleClass("columnLabelStyle bold"),
													width: "8%",
													demandPopin: true,
													minScreenWidth: "Desktop",
													popinDisplay: "Inline"
												}),
												new sap.m.Column("variance", {
													header: new sap.m.Text({
														text: "{i18n>variance}"
													}).addStyleClass("columnLabelStyle bold"),
													width: "9%",
													demandPopin: true,
													minScreenWidth: "Desktop",
													popinDisplay: "Inline"
												}),
												new sap.m.Column("custName", {
													header: new sap.m.Text({
														text: "{i18n>custName}"
													}).addStyleClass("columnLabelStyle bold"),
													width: "12%",
													demandPopin: true,
													minScreenWidth: "Desktop",
													popinDisplay: "Inline"
												}),
												new sap.m.Column("glidGlobId", {
													header: new sap.m.Text({
														text: "{i18n>glidGlobalId}"
													}).addStyleClass("columnLabelStyle bold"),
													width: "12%",
													demandPopin: true,
													minScreenWidth: "Desktop",
													popinDisplay: "Inline"
												}),
												new sap.m.Column("scac", {
													header: new sap.m.Text({
														text: "{i18n>Scac}"
													}).addStyleClass("columnLabelStyle bold"),
													width: "6%"
												}),
												new sap.m.Column("storageLoc", {
													header: new sap.m.Text({
														text: "{i18n>storageLoc}"
													}).addStyleClass("columnLabelStyle bold"),
													width: "8%",
													demandPopin: true,
													minScreenWidth: "Desktop",
													popinDisplay: "Inline"
												}),
												new sap.m.Column("typOfTruck", {
													header: new sap.m.Text({
														text: "{i18n>typOfTruck}"
													}).addStyleClass("columnLabelStyle bold"),
													width: "9%",
													demandPopin: true,
													minScreenWidth: "Desktop",
													popinDisplay: "Inline"
												}),
												new sap.m.Column("dock", {
													header: new sap.m.Text({
														text: "{i18n>dock}"
													}).addStyleClass("columnLabelStyle bold"),
													width: "12%",
													demandPopin: true,
													minScreenWidth: "Desktop",
													popinDisplay: "Inline"
												}),
												new sap.m.Column("trailerId", {
													header: new sap.m.Text({
														text: "{i18n>trailerId}"
													}).addStyleClass("columnLabelStyle bold"),
													width: "10%",
													demandPopin: true,
													minScreenWidth: "Desktop",
													popinDisplay: "Inline"
												}),
												new sap.m.Column("regNum", {
													header: new sap.m.Text({
														text: "{i18n>regNum}"
													}).addStyleClass("columnLabelStyle bold"),
													width: "8%",
													demandPopin: true,
													minScreenWidth: "Desktop",
													popinDisplay: "Inline"
												}),
												new sap.m.Column("delStatus", {
													header: new sap.m.Text({
														text: "{i18n>delStatus}"
													}).addStyleClass("columnLabelStyle bold"),
													width: "8%",
													demandPopin: true,
													minScreenWidth: "Desktop",
													popinDisplay: "Inline"
												}),
												new sap.m.Column("proSys", {
													header: new sap.m.Text({
														text: "{i18n>processSystem}"
													}).addStyleClass("columnLabelStyle bold"),
													width: "8%",
													demandPopin: true,
													minScreenWidth: "Desktop",
													popinDisplay: "Inline"
												}),
												new sap.m.Column("termSaftyAcpt", {
													header: new sap.m.Text({
														text: "{i18n>termSaftyAggAcpt}"
													}).addStyleClass("columnLabelStyle bold"),
													width: "12%",
													demandPopin: true,
													minScreenWidth: "Desktop",
													popinDisplay: "Inline"
												}),
												new sap.m.Column("checkinSys", {
													header: new sap.m.Text({
														text: "{i18n>checkInSys}"
													}).addStyleClass("columnLabelStyle bold"),
													width: "10%",
													demandPopin: true,
													minScreenWidth: "Desktop",
													popinDisplay: "Inline"
												}),
												new sap.m.Column("checkoutSys", {
													header: new sap.m.Text({
														text: "{i18n>checkOutSys}"
													}).addStyleClass("columnLabelStyle bold"),
													width: "10%",
													demandPopin: true,
													minScreenWidth: "Desktop",
													popinDisplay: "Inline"
												}),
												new sap.m.Column("checkinTyp", {
													header: new sap.m.Text({
														text: "{i18n>checkInTyp}"
													}).addStyleClass("columnLabelStyle bold"),
													width: "12%",
													visible: "{= ${regionModel>/region} === 'US'? true : false}",
													demandPopin: true,
													minScreenWidth: "Desktop",
													popinDisplay: "Inline"
												})
											]
										}).addStyleClass("tableStyle")
									]
								}).addStyleClass("tableClass")
							]
						}).addStyleClass("pHeading panelBackground")
					]
				});

				that.byId("RUsagePage").addContent(oGridLayout);

				var sRegionMod = that.getView().getModel("ViewModel").getProperty("/region");

				if (sRegionMod !== "US") {
					sap.ui.getCore().byId("fdeReportTab").removeColumn("checkinTyp");
				}

				// init and activate controller
				this._oTPC = new TablePersoController({
					table: sap.ui.getCore().byId("fdeReportTab"),
					//specify the first part of persistence ids e.g. 'demoApp-productsTable-dimensionsCol'
					componentName: "demoApp",
					persoService: DemoPersoService
				}).activate();

				//---------------------Column filter code-----------------------//
				/*	var columnModel = new JSONModel("model/Objects.json");
				sap.ui.getCore().setModel(columnModel);
				if (!this._oResponsivePopover) {
					this._oResponsivePopover = sap.ui.xmlfragment("com.report.fragments.ColumnFilter", this);
					this._oResponsivePopover.setModel(sap.ui.getCore().getModel());
				}
				var colTable = sap.ui.getCore().byId("table");
				colTable.addEventDelegate({
					onAfterRendering: function() {
						var oHeader = this.$().find('.sapMListTblHeaderCell'); //Get hold of table header elements
						for (var i = 0; i < oHeader.length; i++) {
							var oID = oHeader[i].id;
							that.onClick(oID);
						}
					}
				}, colTable);*/
			},

			//----------------------Code for getting Selected Row in table--------------------------//

			// onItemSelected: function(oEvent) {
			// 	var that = this;
			// 	if (oEvent.getSource().getBindingContext("/") !== undefined) {
			// 		var selectedRow = oEvent.getSource().getBindingContext().getPath(); //Selected row
			// 		var index = parseInt(selectedRow.substring(selectedRow.lastIndexOf('/') + 1)); //Selected row index
			// 		var tableItems = that.byId("fdeReportTab").getItems()[index]; //Selected item
			// 		that.byId("fdeReportTab").setSelectedItem(tableItems, true); //Enabling selected item
			// 	}
			// },

			//----------------------------------------------------------------------------------
			//Function to create Busy Dialog
			//----------------------------------------------------------------------------------
			fnCreateBusyDialog: function(sImage, sBusy) {
				var that = this;
				//	that.oInsCreateDailog;
				if (sBusy === "true") {
					that.oInsCreateDailog = new sap.m.Dialog({
						showHeader: false
					}).addStyleClass("busyDialog sapUiTinyMargin");
					var sComponentName = that.getOwnerComponent().getMetadata().getComponentName();
					var imgUrl = $.sap.getModulePath(sComponentName, "/images/");
					var oImage = new sap.m.Image().addStyleClass("sapUiMediumMargin");
					oImage.setSrc(imgUrl + sImage);
					that.oInsCreateDailog.addContent(oImage);
					that.oInsCreateDailog.open();
				} else {
					that.oInsCreateDailog.close();
				}
			},

			_onRouteMatched: function(oEvent) {
				var that = this;
				that.fnCreateBusyDialog("pallet.svg", "true");
				var oArgs = oEvent.getParameter("arguments");
				var sDateRange = oArgs.DateRange.split(",");
				var oStartDate = sDateRange[0];
				var newStrDate = oStartDate.replace(/-/g, "");
				var oEndDate = sDateRange[1];
				var newEndDate = oEndDate.replace(/-/g, "");
				oArgs.DateStart = oStartDate;
				oArgs.DateEnd = oEndDate;
				var startTime = oArgs.StartTime;
				var newStrTime = startTime.replace(/:/g, "");
				var endTime = oArgs.EndTime;
				var newEndTime = endTime.replace(/:/g, "");
				var plantModel = new sap.ui.model.json.JSONModel();
				plantModel.setData(oArgs);
				that.getView().setModel(plantModel, "plantDetailModel");
				var sLoggedLanguage = sap.ui.getCore().getConfiguration().getLocale().getSAPLogonLanguage();

				oRegion1 = that.getView().getModel("plantDetailModel").getProperty("/Plants");
				vRegion = jQuery.sap.storage(jQuery.sap.storage.Type.local).get("region");
				var sObj = {
					region: vRegion
				};
				var oViewModel = new JSONModel(sObj);
				that.getView().setModel(oViewModel, "regionModel");

				var sRepFilter = [];
				sRepFilter.push(new sap.ui.model.Filter("Werks", sap.ui.model.FilterOperator.EQ, oArgs.Plants));
				sRepFilter.push(new sap.ui.model.Filter("StartDate", sap.ui.model.FilterOperator.EQ, newStrDate));
				sRepFilter.push(new sap.ui.model.Filter("EndDate", sap.ui.model.FilterOperator.EQ, newEndDate));
				sRepFilter.push(new sap.ui.model.Filter("StartTime", sap.ui.model.FilterOperator.EQ, newStrTime));
				sRepFilter.push(new sap.ui.model.Filter("EndTime", sap.ui.model.FilterOperator.EQ, newEndTime));
				sRepFilter.push(new sap.ui.model.Filter("Zlangu", sap.ui.model.FilterOperator.EQ, sLoggedLanguage));

				that.getOwnerComponent().getModel("fdeRepModel").read("/FDE_USAGE_DETAILSSet", {
					filters: sRepFilter,
					success: function(oData, oResponse) {
						if (oResponse.statusCode === 200 || oResponse.statusCode === "200") {
							var tableModel = new JSONModel();
							tableModel.setData(oData.results);

							for (var i = 0; i < oData.results.length; i++) {
								oData.results[i].Region = vRegion;
								// var loadStarttime = tableModel.getProperty("/" + i + "/LoadStartTime");
								// if (loadStarttime !== "") {
								// 	var newStartDate1 = loadStarttime.slice(3, 5) + "/" + loadStarttime.slice(0, 2) + "/" + loadStarttime.slice(6, 20);
								// } else {
								// 	newStartDate1 = "";
								// }
								// tableModel.setProperty("/" + i + "/LoadStartTime", newStartDate1);
								// var loadEndtime = tableModel.getProperty("/" + i + "/LoadEndTime");
								// if (loadEndtime !== "") {
								// 	var newEndDate1 = loadEndtime.slice(3, 5) + "/" + loadEndtime.slice(0, 2) + "/" + loadEndtime.slice(6, 20);
								// } else {
								// 	newEndDate1 = "";
								// }
								// tableModel.setProperty("/" + i + "/LoadEndTime", newEndDate1);
							}

							// if (oRegion1.startsWith("AU")) {
							// if (vRegion === "EU" || vRegion ==="AP") {
							// 	for (var i = 0; i < oData.results.length; i++) {
							// 		var loadStarttime = tableModel.getProperty("/" + i + "/LoadStartTime");
							// 		if (loadStarttime !== "") {
							// 			var newStartDate1 = loadStarttime.slice(3, 5) + "/" + loadStarttime.slice(0, 2) + "/" + loadStarttime.slice(6, 20);
							// 		} else {
							// 			newStartDate1 = "";
							// 		}
							// 		tableModel.setProperty("/" + i + "/LoadStartTime", newStartDate1);
							// 		var loadEndtime = tableModel.getProperty("/" + i + "/LoadEndTime");
							// 		if (loadEndtime !== "") {
							// 			var newEndDate1 = loadEndtime.slice(3, 5) + "/" + loadEndtime.slice(0, 2) + "/" + loadEndtime.slice(6, 20);
							// 		} else {
							// 			newEndDate1 = "";
							// 		}
							// 		tableModel.setProperty("/" + i + "/LoadEndTime", newEndDate1);
							// 	}
							// }

							tableModel.setSizeLimit(oData.results.length);
							that.getView().setModel(tableModel, "tabModel");
							that.bindAllPanelsandTables(oData.results);
							that.distinctData();

						}
						that.fnCreateBusyDialog("pallet.svg", "false");
						that.getOwnerComponent().BusyDialogGlobal.close();
					},
					error: function() {
						that.fnCreateBusyDialog("pallet.svg", "false");
						that.getOwnerComponent().BusyDialogGlobal.close();
					}
				});

			},

			onTableUpdateFinish: function(oEvent) {
				var tabelModel = oEvent.getSource().getModel().getData();
				var oTableItems = oEvent.getSource().getItems();
				for (var n = 0; n < oTableItems.length; n++) {
					if (tabelModel[n].StatusFlag === "E") {
						oTableItems[n].addStyleClass("redBack");
					} else {
						oTableItems[n].removeStyleClass("redBack");
					}
				}
			},

			distinctData: function(oEvent) {
				var sModel = this.getView().getModel("tabModel").getData();
				var aUniqueDelNum = [];

				for (var i = 0; i < sModel.length; i++) {
					if (aUniqueDelNum.indexOf(sModel[i].DocId) === -1) {
						aUniqueDelNum.push(sModel[i].DocId);
					}
				}

				var tot_Quantity = 0;
				for (var k = 0; k < sModel.length; k++) {
					var sDelvQty = sModel[k].Lfimg;
					tot_Quantity = tot_Quantity + Number(sDelvQty);
				}

				var sCountModel = new JSONModel();
				var modelobject = {
					"Count": aUniqueDelNum.length,
					"Sum": tot_Quantity
				};
				sCountModel.setData(modelobject);
				this.getView().setModel(sCountModel, "distinctCountModel");
			},

			bindAllPanelsandTables: function(tableData) {
				var that = this;
				that.onIssuesReturnsBind(tableData);
				that.tableBinding(tableData);
			},

			tableBinding: function(tableData) {
				/*Pass Data to Tables*/
				var oTemplate = new sap.m.ColumnListItem({
					type: "Navigation",
					cells: [
						new sap.m.Text({
							text: "{Werks}"
						}).addStyleClass("bold"),

						new sap.m.Text({
							text: "{DocId}"
						}).addStyleClass("bold"),

						new sap.m.Text({
							text: "{Zcarrier}"
						}).addStyleClass("bold"),

						new sap.m.ObjectStatus({
							text: {
								parts: [{
									path: "DeliveryType"
								}, {
									path: "DelvType"
								}],
								formatter: function(date, DelvType) {
									return formatter.IssueReturn(date, DelvType);
								}
							}
						}).addStyleClass("bold"),

						new sap.m.Text({
							text: "{TranspType}"
						}),
						new sap.m.Text({
							text: "{UserId}"
						}),
						// new sap.m.Text({
						// 	text: "{LoadStartTime}"
						// }),
						new sap.m.Text({
							text: {
								parts: [{
									path: "LoadStartTime"
								}, {
									path: "Region"
								}],
								formatter: function(date, Region) {
									return formatter.FDERepDateFormat(date, Region);
								}
							}
						}),

						// new sap.m.Text({
						// 	text: "{LoadEndTime}"
						// }),
						new sap.m.Text({
							text: {
								parts: [{
									path: "LoadEndTime"
								}, {
									path: "Region"
								}],
								formatter: function(date, Region) {
									return formatter.FDERepDateFormat(date, Region);
								}
							}
						}),
						// new sap.m.Text({
						// 	text: "{PreloadedTime}"
						// }),

						new sap.m.Text({
							text: {
								parts: [{
									path: "PreloadedTime"
								}, {
									path: "Region"
								}],
								formatter: function(date, Region) {
									return formatter.FDERepDateFormat(date, Region);
								}
							}
						}),

						new sap.m.Label({
							text: "{Prodcode}",
							design: "Bold"
						}),
						new sap.m.Text({
							text: "{Charg}"
							// design: "Bold"
						}).addStyleClass("bold"),
						// new sap.m.Label({
						// 	text: "{Lfimg}",
						// 	design: "Bold"
						// }),
						new sap.m.ObjectStatus({
							text: {
								parts: [{
									path: "Lfimg"
								}],
								formatter: function(qty) {
									return formatter.Quantity(qty);
								}
							}
						}).addStyleClass("bold"),
						new sap.m.Text({
							// text: "{Plannedqty}"
							text: {
								parts: [{
									path: "Plannedqty"
								}],
								formatter: function(planqty) {
									return formatter.PlannedQuantity(planqty);
								}
							}
						}),
						new sap.m.Text({
							// text: "{Variance}"
							text: {
								parts: [{
									path: "Variance"
								}],
								formatter: function(variance) {
									return formatter.Variance(variance);
								}
							}
						}),
						new sap.m.Text({
							text: "{CustomerName}"
						}),
						new sap.m.Text({
							text: "{GlobalID}"
						}),
						new sap.m.Text({
							text: "{Scac}"
						}),
						new sap.m.Text({
							text: "{Storageloc}"
						}),
						new sap.m.Text({
							text: "{Trucktyp}"
						}),
						new sap.m.Text({
							text: "{Dock}"
						}),
						new sap.m.Text({
							text: "{Trailerid}"
						}),
						new sap.m.Text({
							text: "{Regno}"
						}),
						new sap.m.Text({
							text: "{DeliveryStatus}"
						}),
						new sap.m.Text({
							text: "{Prosys}"
						}),
						new sap.m.Text({
							text: "{TermsSafetyAgreement}"
						}).addStyleClass("bold sapUiSmallMarginBegin"),
						new sap.m.Text({
							text: "{CheckInSystem}"
						}),
						new sap.m.Text({
							text: "{CheckOutSystem}"
						}),
						new sap.m.Text({
							text: "{CheckInType}"
						})
					]
				});

				/*Table Binding*/
				var oReportTable = sap.ui.getCore().byId("fdeReportTab");
				var oModel1 = new sap.ui.model.json.JSONModel();
				oModel1.setSizeLimit(tableData.length);
				oModel1.setData(tableData);
				if (oReportTable !== undefined) {
					oReportTable.setModel(oModel1);
					oReportTable.bindAggregation("items", {
						path: "/",
						template: oTemplate
					});
				}
				/*Table Grouping*/
				var oGroupingModel = new JSONModel({
					hasGrouping: false
				});
				this.getView().setModel(oGroupingModel, 'Grouping');

			},

			onIssuesReturnsBind: function(tableData) {
				// var that = this;
				// that.oInsCreateDailog.open();

				//checking preload flag --- to make visibility of preloaded issues panel

				var checkoutVisObj = {
					checkoutVisibility: false
				};
				var oCheckoutVisModel = new JSONModel(checkoutVisObj);
				this.getView().setModel(oCheckoutVisModel, "chkoutVisModel");

				if (tableData.length > 0) {
					var VisibleFlag = tableData[0].PreloadedFlag === "X" ? true : false;
					this.getView().getModel("ViewModel").setProperty("/PreloadedFlag", VisibleFlag);
					this.getView().getModel("chkoutVisModel").setProperty("/checkoutVisibility", VisibleFlag);

				} else {
					var sVisibleFlag = false;
					this.getView().getModel("ViewModel").setProperty("/PreloadedFlag", sVisibleFlag);
				}

				//--------------Table binding for Issues Table in summary panel--------------//

				//To get all the records with unique unit Load
				var issuesTableData = $.grep(tableData, function(n, m) {
					return n.DeliveryType === "01";
				});
				var issuesalterdData = [];
				var PreloadedalterdData = [];
				issuesTableData.filter(function(a) {
					var key = a.Prodcode + '|' + a.Charg;
					if (!this[key]) {
						//To get all the records with unique unit Load
						var issuesMainData = $.grep(issuesTableData, function(n, m) {
							return n.Prodcode === a.Prodcode && n.Charg === a.Charg;
						});
						var issuesTotal = 0;
						var issueCount = 0;
						var PreloadCount = 0;
						var PreloadTotal = 0;
						issuesMainData.forEach(function(entry) {
							//segregate records both completed and preloaded
							if (entry.PreloadedFlag === "X") {
								if (entry.Status === "Completed") {
									issuesTotal = issuesTotal + parseFloat(entry.Lfimg);
									issueCount++;
								} else if (entry.Status === "Preloaded") {
									PreloadTotal = PreloadTotal + parseFloat(entry.Lfimg);
									PreloadCount++;
								}
							} else {
								issuesTotal = issuesTotal + parseFloat(entry.Lfimg);
								issueCount++;
							}
							// issuesTotal = issuesTotal + parseFloat(entry.Lfimg);
						});
						var obj = {
							"TotalDel": issueCount === 0 ? issuesMainData.length : issueCount,
							"Material": a.Prodcode,
							"Batch": a.Charg,
							"Total": issuesTotal
						};
						if (issueCount !== 0) {
							issuesalterdData.push(obj);
						}

						var Preloadobj = {
							"TotalDel": PreloadCount,
							"Material": a.Prodcode,
							"Batch": a.Charg,
							"Total": PreloadTotal
						};
						if (PreloadCount !== 0) {
							PreloadedalterdData.push(Preloadobj);
						}
						this[key] = true;
						return true;
					}
				}, Object.create(null));

				var returnsTableData = $.grep(tableData, function(n, m) {
					return n.DeliveryType === "02";
				});

				var returnsalterdData = [];
				returnsTableData.filter(function(a) {
					var key = a.Prodcode + '|' + a.Charg;
					if (!this[key]) {

						//To get all the records with unique unit Load
						var returnsMainData = $.grep(returnsTableData, function(n, m) {
							return n.Prodcode === a.Prodcode && n.Charg === a.Charg;
						});

						var returnsTotal = 0;
						returnsMainData.forEach(function(entry) {
							returnsTotal = returnsTotal + parseFloat(entry.Lfimg);
						});

						var obj = {
							"TotalDel": returnsMainData.length,
							"Material": a.Prodcode,
							"Batch": a.Charg,
							"Total": returnsTotal
						};
						returnsalterdData.push(obj);
						this[key] = true;
						return true;
					}
				}, Object.create(null));

				var issueTemplate = new sap.m.ColumnListItem({
					cells: [
						new sap.m.Text({
							text: "{TotalDel}"
						}),
						new sap.m.Text({
							text: "{Material}"
						}),
						new sap.m.Text({
							text: "{Batch}"
						}),
						new sap.m.Text({
							text: "{Total}"
						})
					]
				});

				//---------Start Table Bnding for STO Returns Table in Summary Panel-----------//

				var storeturnsTableData = $.grep(tableData, function(n, m) {
					return n.DeliveryType === "05";
				});

				var storeturnsalterdData = [];
				storeturnsTableData.filter(function(a) {
					var key = a.Prodcode + '|' + a.Charg;
					if (!this[key]) {

						//To get all the records with unique unit Load
						var returnsMainData = $.grep(storeturnsTableData, function(n, m) {
							return n.Prodcode === a.Prodcode && n.Charg === a.Charg;
						});

						var returnsTotal = 0;
						returnsMainData.forEach(function(entry) {
							returnsTotal = returnsTotal + parseFloat(entry.Lfimg);
						});

						var obj = {
							"TotalDel": returnsMainData.length,
							"Material": a.Prodcode,
							"Batch": a.Charg,
							"Total": returnsTotal
						};
						storeturnsalterdData.push(obj);
						this[key] = true;
						return true;
					}
				}, Object.create(null));

				var StoRetTemplate = new sap.m.ColumnListItem({
					cells: [
						new sap.m.Text({
							text: "{TotalDel}"
						}),
						new sap.m.Text({
							text: "{Material}"
						}),
						new sap.m.Text({
							text: "{Batch}"
						}),
						new sap.m.Text({
							text: "{Total}"
						})
					]
				});

				var StoRetTable = sap.ui.getCore().byId("StoReturnTable");
				var StoRetModel = new sap.ui.model.json.JSONModel();
				StoRetModel.setSizeLimit(storeturnsalterdData.length);
				StoRetModel.setData(storeturnsalterdData);
				StoRetTable.setModel(StoRetModel);
				StoRetTable.bindAggregation("items", {
					path: "/",
					template: StoRetTemplate
				});

				//---------End Table Bnding for STO Returns Table in Summary Panel-----------//

				//---------Start Table Bnding for STO Issue Table in Summary Panel-----------//

				var stoIssueTableData = $.grep(tableData, function(n, m) {
					return n.DeliveryType === "04";
				});

				var stoIssuealterdData = [];
				stoIssueTableData.filter(function(a) {
					var skey = a.Prodcode + '|' + a.Charg;
					if (!this[skey]) {

						//To get all the records with unique unit Load
						var returnsMainData = $.grep(stoIssueTableData, function(n, m) {
							return n.Prodcode === a.Prodcode && n.Charg === a.Charg;
						});

						var returnsTotal = 0;
						returnsMainData.forEach(function(entry) {
							returnsTotal = returnsTotal + parseFloat(entry.Lfimg);
						});

						var obj = {
							"TotalDel": returnsMainData.length,
							"Material": a.Prodcode,
							"Batch": a.Charg,
							"Total": returnsTotal
						};
						stoIssuealterdData.push(obj);
						this[skey] = true;
						return true;
					}
				}, Object.create(null));

				var StoIssueTemplate = new sap.m.ColumnListItem({
					cells: [
						new sap.m.Text({
							text: "{TotalDel}"
						}),
						new sap.m.Text({
							text: "{Material}"
						}),
						new sap.m.Text({
							text: "{Batch}"
						}),
						new sap.m.Text({
							text: "{Total}"
						})
					]
				});

				var StoIssueTable = sap.ui.getCore().byId("StoIssueTable");
				var StoIssueModel = new sap.ui.model.json.JSONModel();
				StoIssueModel.setSizeLimit(stoIssuealterdData.length);
				StoIssueModel.setData(stoIssuealterdData);
				StoIssueTable.setModel(StoIssueModel);
				StoIssueTable.bindAggregation("items", {
					path: "/",
					template: StoIssueTemplate
				});

				//---------End Table Bnding for STO Issue Table in Summary Panel-----------//

				//---------Start Table Bnding for Raw Material PO Table in Summary Panel-----------//

				var RmpoTableData = $.grep(tableData, function(n, m) {
					return n.DeliveryType === "03";
				});

				var RmpoalterdData = [];
				RmpoTableData.filter(function(a) {
					var fKey = a.Prodcode + '|' + a.Charg;
					if (!this[fKey]) {

						//To get all the records with unique unit Load
						var RMPOreturnsMainData = $.grep(RmpoTableData, function(n, m) {
							return n.Prodcode === a.Prodcode && n.Charg === a.Charg;
						});

						var returnsTotal = 0;
						RMPOreturnsMainData.forEach(function(entry) {
							returnsTotal = returnsTotal + parseFloat(entry.Lfimg);
						});

						var obj = {
							"TotalDel": RMPOreturnsMainData.length,
							"Material": a.Prodcode,
							"Batch": a.Charg,
							"Total": returnsTotal
						};
						RmpoalterdData.push(obj);
						this[fKey] = true;
						return true;
					}
				}, Object.create(null));

				var RmpoTemplate = new sap.m.ColumnListItem({
					cells: [
						new sap.m.Text({
							text: "{TotalDel}"
						}),
						new sap.m.Text({
							text: "{Material}"
						}),
						new sap.m.Text({
							text: "{Batch}"
						}),
						new sap.m.Text({
							text: "{Total}"
						})
					]
				});

				var RmpoTable = sap.ui.getCore().byId("StoRMPOTable");
				var RmpoModel = new sap.ui.model.json.JSONModel();
				RmpoModel.setSizeLimit(RmpoalterdData.length);
				RmpoModel.setData(RmpoalterdData);
				RmpoTable.setModel(RmpoModel);
				RmpoTable.bindAggregation("items", {
					path: "/",
					template: RmpoTemplate
				});

				//---------End Table Bnding for Raw Material PO Table in Summary Panel-----------//

				var issTable = sap.ui.getCore().byId("issueTable");
				var issModel = new sap.ui.model.json.JSONModel();
				issModel.setSizeLimit(issuesalterdData.length);
				issModel.setData(issuesalterdData);
				issTable.setModel(issModel);
				issTable.bindAggregation("items", {
					path: "/",
					template: issueTemplate
				});
				//---------Table Bnding for Returns Table in Summary Panel-----------//	
				var retTable = sap.ui.getCore().byId("returnTable");
				var retModel = new sap.ui.model.json.JSONModel();
				retModel.setSizeLimit(returnsalterdData.length);
				retModel.setData(returnsalterdData);
				retTable.setModel(retModel);
				retTable.bindAggregation("items", {
					path: "/",
					template: issueTemplate
				});
				//---------Table Bnding for Preloaded deliveries  in Summary Panel of issues-----------//
				var issuePrelaodTemplate = new sap.m.ColumnListItem({
					cells: [
						new sap.m.Text({
							text: "{TotalDel}"
						}),
						new sap.m.Text({
							text: "{Material}"
						}),
						new sap.m.Text({
							text: "{Batch}"
						}),
						new sap.m.Text({
							text: "{Total}"
						})
					]
				});
				var PreloadTable = sap.ui.getCore().byId("issuePreloadTable");
				var PreloadModel = new sap.ui.model.json.JSONModel();
				PreloadModel.setSizeLimit(PreloadedalterdData.length);
				PreloadModel.setData(PreloadedalterdData);
				PreloadTable.setModel(PreloadModel);
				PreloadTable.bindAggregation("items", {
					path: "/",
					template: issuePrelaodTemplate
				});

				// that.oInsCreateDailog.close();
			},

			onTableRefresh: function() {
				//Remove Filters
				if (sap.ui.getCore().byId("fdeReportTab") !== undefined) {
					var oTable = sap.ui.getCore().byId("fdeReportTab");
					var oModel = oTable.getModel();
					var oTableBinding = oTable.getBinding("items");
					oTableBinding.aSorters = null;
					oTableBinding.aFilters = null;
					oModel.refresh(true);
				}
				if (sap.ui.getCore().byId("headerData") !== undefined) {
					sap.ui.getCore().byId("headerData").setText("");
				}
				this.resetFilterItems();
				this.distinctData();
			},

			// onClick: function(oID) {
			// 	var that = this;
			// 	$('#' + oID).click(function(oEvent) { //Attach Table Header Element Event
			// 		var oTarget = oEvent.currentTarget; //Get hold of Header Element
			// 		var oLabelText = oTarget.childNodes[0].textContent; //Get Column Header text
			// 		var oIndex = oTarget.id.slice(-1); //Get the column Index
			// 		var oView = sap.ui.getCore();
			// 		var colTable = oView.byId("fdeReportTab");
			// 		var columnModel = colTable.getModel().getProperty("/Data"); //Get Hold of Table Model Values
			// 		var oKeys = Object.keys(columnModel[0]); //Get Hold of Model Keys to filter the value
			// 		oView.getModel().setProperty("/bindingValue", oKeys[oIndex]); //Save the key value to property
			// 		that._oResponsivePopover.openBy(oTarget);
			// 	});
			// },

			// onChange: function(oEvent) {
			// 	var oValue = oEvent.getParameter("value");
			// 	var oMultipleValues = oValue.split(",");
			// 	var colTable = sap.ui.getCore().byId("fdeReportTab");
			// 	var oBindingPath = sap.ui.getCore().getModel().getProperty("/bindingValue"); //Get Hold of Model Key value that was saved
			// 	var aFilters = [];
			// 	for (var i = 0; i < oMultipleValues.length; i++) {
			// 		var oFilter = new Filter(oBindingPath, "Contains", oMultipleValues[i]);
			// 		aFilters.push(oFilter);
			// 	}
			// 	var oItems = colTable.getBinding("items");
			// 	oItems.filter(aFilters, "Application");
			// 	this._oResponsivePopover.close();
			// },

			// onAscending: function() {
			// 	var colTable = sap.ui.getCore().byId("fdeReportTab");
			// 	var oItems = colTable.getBinding("items");
			// 	var oBindingPath = sap.ui.getCore().getModel().getProperty("/bindingValue");
			// 	var oSorter = new Sorter(oBindingPath);
			// 	oItems.sort(oSorter);
			// 	this._oResponsivePopover.close();
			// },

			// onDescending: function() {
			// 	var colTable = sap.ui.getCore().byId("fdeReportTab");
			// 	var oItems = colTable.getBinding("items");
			// 	var oBindingPath = sap.ui.getCore().getModel().getProperty("/bindingValue");
			// 	var oSorter = new Sorter(oBindingPath, true);
			// 	oItems.sort(oSorter);
			// 	this._oResponsivePopover.close();
			// },

			// onOpen: function(oEvent) {
			// 	//On Popover open focus on Input control
			// 	var oPopover = sap.ui.getCore().byId(oEvent.getParameter("id"));
			// 	var oPopoverContent = oPopover.getContent()[0];
			// 	var oCustomListItem = oPopoverContent.getItems()[2];
			// 	var oCustomContent = oCustomListItem.getContent()[0];
			// 	var oInput = oCustomContent.getItems()[1];
			// 	oInput.focus();
			// 	oInput.$().find('.sapMInputBaseInner')[0].select();
			// },

			onPersoButtonPressed: function(oEvent) {
				this._oTPC.openDialog();
			},

			onTablePersoRefresh: function() {
				DemoPersoService.resetPersData();
				this._oTPC.refresh();
			},

			onTableGrouping: function(oEvent) {
				// alert("msg")
				// this._oTPC.setHasGrouping(oEvent.getSource().getSelected());
				this._oTPC.setHasGrouping(sap.ui.getCore().byId("groupCheck").getSelected());

			},

			onPressExport: sap.m.Table.prototype.exportData || function(oEvent) {
				var oExport = new Export({
					exportType: new ExportTypeCSV({
						separatorChar: ",",
						fileExtension: "csv"
					}),
					models: sap.ui.getCore().byId("fdeReportTab").getModel(),
					rows: {
						path: "/"
					},

					columns: [{
						
							// name: "Plant",
							name: this.getOwnerComponent().getModel("i18n").getProperty("plant"),
							template: {
								content: "{Werks}"
							}
						}, {
							// name: "Del Num",
							name: this.getOwnerComponent().getModel("i18n").getProperty("delNo"),
							template: {
								content: "{DocId}"
							}
						}, {
							// name: "Carrier Name",
							name: this.getOwnerComponent().getModel("i18n").getProperty("carrierName"),
							template: {
								content: "{Zcarrier}"
							}
						}, {
							// name: "Del Type",
							name: this.getOwnerComponent().getModel("i18n").getProperty("delivType"),
							template: {
								// content: "{DeliveryType}"
								content: {
									parts: ["DeliveryType", "DelvType"],
									formatter: function(sStatus, DelvType) {
										if (DelvType === "" || DelvType === undefined) {
											if (sStatus === "01") {
												return "Issue";
											} else if (sStatus === "02") {
												return "Return";
											} else if (sStatus === "03") {
												return "Raw Material PO";
											} else if (sStatus === "04") {
												return "STO-Issue";
											} else if (sStatus === "05") {
												return "STO-Return";
											}
										} else {
											return DelvType;
										}
									}
								}
							}
						}, {
							// name: "Type",
							name: this.getOwnerComponent().getModel("i18n").getProperty("transportType"),
							template: {
								content: "{TranspType}"
							}
						}, {
							// name: "User ID",
							name: this.getOwnerComponent().getModel("i18n").getProperty("userID"),
							template: {
								content: "{UserId}"
							}
							// }, {
							// 	name: "Load Accept Time",
							// 	template: {
							// 		content: "{loadAcptTime}"
							// 	}
						}, {
							// name: "Start Time",
							// name: this.getOwnerComponent().getModel("i18n").getProperty("startTimeFdeRep"),
							// template: {
							// 	content: "{LoadStartTime}"
							// }

							name: this.getOwnerComponent().getModel("i18n").getProperty("startTimeFdeRep"),
							template: {
								// content: "{DeliveryType}"
								content: {
									parts: ["LoadStartTime", "Region"],
									formatter: function(LoadStartTime, Region) {
										if (LoadStartTime !== null) {
											if (Region === "EU" || Region === "LATAM" || Region === "ZA" || Region === "AP") {
												var newStartDate1 = LoadStartTime.slice(3, 5) + "/" + LoadStartTime.slice(0, 2) + "/" + LoadStartTime.slice(6, 20);
												return newStartDate1;
											} else {
												return LoadStartTime;
											}
										}
									}
								}
							}
						}, {
							// name: "Complete Time",
							name: this.getOwnerComponent().getModel("i18n").getProperty("completionTime"),
							template: {
								// content: "{LoadEndTime}"
								content: {
									parts: ["LoadEndTime", "Region"],
									formatter: function(LoadEndTime, Region) {
										if (LoadEndTime !== null) {
											if (Region === "EU" || Region === "LATAM" || Region === "ZA" || Region === "AP") {
												var newStartDate1 = LoadEndTime.slice(3, 5) + "/" + LoadEndTime.slice(0, 2) + "/" + LoadEndTime.slice(6, 20);
												return newStartDate1;
											} else {
												return LoadEndTime;
											}
										}
									}
								}
							}
						}, {
							// name: "Checkout Time",
							name: this.getOwnerComponent().getModel("i18n").getProperty("checkoutTime"),
							template: {
								// content: "{PreloadedTime}"
								content: {
									parts: ["PreloadedTime", "Region"],
									formatter: function(PreloadedTime, Region) {
										if (PreloadedTime !== null) {
											if (PreloadedTime !== "") {
												if (Region === "EU" || Region === "LATAM" || Region === "ZA" || Region === "AP") {
													var newStartDate1 = PreloadedTime.slice(3, 5) + "/" + PreloadedTime.slice(0, 2) + "/" + PreloadedTime.slice(6, 20);
													return newStartDate1;
												} else {
													return PreloadedTime;
												}
											}
										}
									}
								}
							}
						}, {
							// name: "ProductCode",
							name: this.getOwnerComponent().getModel("i18n").getProperty("prdCode"),
							template: {
								content: "{Prodcode}"
							}
						}, {
							// name: "Batch",
							name: this.getOwnerComponent().getModel("i18n").getProperty("batch"),
							template: {
								content: "{Charg}"
							}
						}, {
							// name: "Qty",
							name: this.getOwnerComponent().getModel("i18n").getProperty("qty"),
							template: {
								content: "{Lfimg}"
							}
						}, {
							// name: "Planned Qty",
							name: this.getOwnerComponent().getModel("i18n").getProperty("plannedQty"),
							template: {
								content: "{Plannedqty}"
							}
						}, {
							// name: "Variance",
							name: this.getOwnerComponent().getModel("i18n").getProperty("variance"),
							template: {
								// content: "{Variance}"
								content: {
									parts: ["Variance"],
									formatter: function(variance) {
										if (variance !== "" && variance !== null) {
											if (variance.includes("-")) {
												if (variance.charAt(0) !== "-") {
													var sVariance = variance.trim().split("-");
													var newVariance = "-" + sVariance[0];
												}
												return newVariance;
											} else {
												return variance;
											}
										}
									}
								}
							}
						}, {
							// name: "Customer Name",
							name: this.getOwnerComponent().getModel("i18n").getProperty("custName"),
							template: {
								content: "{CustomerName}"
							}
						}, {
							// name: "GLID/Global ID",
							name: this.getOwnerComponent().getModel("i18n").getProperty("glidGlobalId"),
							template: {
								content: "{GlobalID}"
							}
						}, {
							// name: "Carrier",
							name: this.getOwnerComponent().getModel("i18n").getProperty("carrier"),
							template: {
								content: "{Scac}"
							}
						}, {
							// name: "Storage Loc",
							name: this.getOwnerComponent().getModel("i18n").getProperty("storageLoc"),
							template: {
								content: "{Storageloc}"
							}
						}, {
							// name: "Type of Trucks",
							name: this.getOwnerComponent().getModel("i18n").getProperty("typOfTruck"),
							template: {
								content: "{Trucktyp}"
							}
						}, {
							// name: "Dock/Service Bay",
							name: this.getOwnerComponent().getModel("i18n").getProperty("dock"),
							template: {
								content: "{Dock}"
							}
						}, {
							// name: "Trailer Id",
							name: this.getOwnerComponent().getModel("i18n").getProperty("trailerId"),
							template: {
								content: "{Trailerid}"
							}
						}, {
							// name: "Reg Num",
							name: this.getOwnerComponent().getModel("i18n").getProperty("regNum"),
							template: {
								content: "{Regno}"
							}
						}, {
							// name: "Delivery Status",
							name: this.getOwnerComponent().getModel("i18n").getProperty("delStatus"),
							template: {
								content: "{DeliveryStatus}"
							}
						}, {
							// name: "Delivery Processed System",
							name: this.getOwnerComponent().getModel("i18n").getProperty("processSystem"),
							template: {
								content: "{Prosys}"
							}
						}, {
							// name: "Terms & Safety Agreement Accepted",
							name: this.getOwnerComponent().getModel("i18n").getProperty("termSaftyAggAcpt"),
							template: {
								content: "{TermsSafetyAgreement}"
							}
						}, {
							// name: "Check In System",
							name: this.getOwnerComponent().getModel("i18n").getProperty("checkInSys"),
							template: {
								content: "{CheckInSystem}"
							}
						}, {
							// name: "Check Out System",
							name: this.getOwnerComponent().getModel("i18n").getProperty("checkOutSys"),
							template: {
								content: "{CheckOutSystem}"
							}
						}

					]
				});
				/*** add this column only when parentplant is active ***/
				var parentplant = this.getView().getModel("ViewModel").getProperty("/ParentPlant");
				var sGetRegion = this.getView().getModel("regionModel").getProperty("/region");

				if (parentplant !== "") {
					// The below code is commented as part of ESP-5230
					// oExport.insertColumn(new sap.ui.core.util.ExportColumn({
					// 	name: this.getOwnerComponent().getModel("i18n").getProperty("Plant"),
					// 	template: {
					// 		content: "{Werks}"
					// 	}
					// }), 0);

					if (sGetRegion === "US") {
						oExport.insertColumn(new sap.ui.core.util.ExportColumn({
							name: this.getOwnerComponent().getModel("i18n").getProperty("checkInTyp"),
							template: {
								content: "{CheckInType}"
							}
						}), 28);
					}
				} else {
					if (sGetRegion === "US") {
						oExport.insertColumn(new sap.ui.core.util.ExportColumn({
							name: this.getOwnerComponent().getModel("i18n").getProperty("checkInTyp"),
							template: {
								content: "{CheckInType}"
							}
						}), 27);
					}
				}

				var sfdeReport = this.getOwnerComponent().getModel("i18n").getProperty("fdeReport");
				oExport.saveFile(sfdeReport).catch(function(oError) {
					// MessageBox.error("Error when downloading data. Browser might not be supported!\n\n" + oError);
				}).then(function() {
					oExport.destroy();
				});
			},

			onPressExportXLS: sap.m.Table.prototype.exportData || function(oEvent) {
				var oExport = new Export({
					exportType: new ExportTypeCSV({
						separatorChar: "\t",
						fileExtension: "xls"
					}),
					models: sap.ui.getCore().byId("fdeReportTab").getModel(),
					rows: {
						path: "/"
					},

					columns: [{
                            // name: "Plant",
                            name: this.getOwnerComponent().getModel("i18n").getProperty("plant"),
                            template: {
                                content: "{Werks}"
                            }
                        },{
						// name: "Del Num",
						name: this.getOwnerComponent().getModel("i18n").getProperty("delNo"),
						template: {
							content: "{DocId}"
						}
					}, {
						// name: "Carrier Name",
						name: this.getOwnerComponent().getModel("i18n").getProperty("carrierName"),
						template: {
							content: "{Zcarrier}"
						}
					}, {
						// name: "Del Type",
						name: this.getOwnerComponent().getModel("i18n").getProperty("delivType"),
						template: {
							// content: "{DeliveryType}"
							content: {
								parts: ["DeliveryType", "DelvType"],
								formatter: function(sStatus, DelvType) {
									if (DelvType === "" || DelvType === undefined) {
										if (sStatus === "01") {
											return "Issue";
										} else if (sStatus === "02") {
											return "Return";
										} else if (sStatus === "03") {
											return "Raw Material PO";
										} else if (sStatus === "04") {
											return "STO-Issue";
										} else if (sStatus === "05") {
											return "STO-Return";
										}
									} else {
										return DelvType;
									}
								}
							}
						}
					}, {
						// name: "Type",
						name: this.getOwnerComponent().getModel("i18n").getProperty("transportType"),
						template: {
							content: "{TranspType}"
						}
					}, {
						// name: "User ID",
						name: this.getOwnerComponent().getModel("i18n").getProperty("userID"),
						template: {
							content: "{UserId}"
						}
						// }, {
						// 	name: "Load Accept Time",
						// 	template: {
						// 		content: "{loadAcptTime}"
						// 	}
					}, {
						// name: "Start Time",
						// name: this.getOwnerComponent().getModel("i18n").getProperty("startTimeFdeRep"),
						// template: {
						// 	content: "{LoadStartTime}"
						// }

						name: this.getOwnerComponent().getModel("i18n").getProperty("startTimeFdeRep"),
						template: {
							// content: "{DeliveryType}"
							content: {
								parts: ["LoadStartTime", "Region"],
								formatter: function(LoadStartTime, Region) {
									if (LoadStartTime !== null) {
										if (Region === "EU" || Region === "LATAM" || Region === "ZA" || Region === "AP") {
											var newStartDate1 = LoadStartTime.slice(3, 5) + "/" + LoadStartTime.slice(0, 2) + "/" + LoadStartTime.slice(6, 20);
											return newStartDate1;
										} else {
											return LoadStartTime;
										}

									}

								}
							}
						}

					}, {
						// name: "Complete Time",
						name: this.getOwnerComponent().getModel("i18n").getProperty("completionTime"),
						template: {
							// content: "{LoadEndTime}"
							content: {
								parts: ["LoadEndTime", "Region"],
								formatter: function(LoadEndTime, Region) {
									if (LoadEndTime !== null) {
										if (Region === "EU" || Region === "LATAM" || Region === "ZA" || Region === "AP") {
											var newStartDate1 = LoadEndTime.slice(3, 5) + "/" + LoadEndTime.slice(0, 2) + "/" + LoadEndTime.slice(6, 20);
											return newStartDate1;
										} else {
											return LoadEndTime;
										}

									}

								}
							}
						}
					}, {
						// name: "Checkout Time",
						name: this.getOwnerComponent().getModel("i18n").getProperty("checkoutTime"),
						template: {
							// content: "{PreloadedTime}"
							content: {
								parts: ["PreloadedTime", "Region"],
								formatter: function(PreloadedTime, Region) {
									if (PreloadedTime !== null) {
										if (PreloadedTime !== "") {
											if (Region === "EU" || Region === "LATAM" || Region === "ZA" || Region === "AP") {
												var newStartDate1 = PreloadedTime.slice(3, 5) + "/" + PreloadedTime.slice(0, 2) + "/" + PreloadedTime.slice(6, 20);
												return newStartDate1;
											} else {
												return PreloadedTime;
											}

										}
									}

								}
							}
						}
					}, {
						// name: "ProductCode",
						name: this.getOwnerComponent().getModel("i18n").getProperty("prdCode"),
						template: {
							content: "{Prodcode}"
						}
					}, {
						// name: "Batch",
						name: this.getOwnerComponent().getModel("i18n").getProperty("batch"),
						template: {
							content: "{Charg}"
						}
					}, {
						// name: "Qty",
						name: this.getOwnerComponent().getModel("i18n").getProperty("qty"),
						template: {
							content: "{Lfimg}"
						}
					}, {
						// name: "Planned Qty",
						name: this.getOwnerComponent().getModel("i18n").getProperty("plannedQty"),
						template: {
							content: "{Plannedqty}"
						}
					}, {
						// name: "Variance",
						name: this.getOwnerComponent().getModel("i18n").getProperty("variance"),
						template: {
							// content: "{Variance}"
							content: {
								parts: ["Variance"],
								formatter: function(variance) {
									if (variance !== "" && variance !== null) {
										if (variance.includes("-")) {
											if (variance.charAt(0) !== "-") {
												var sVariance = variance.trim().split("-");
												var newVariance = "-" + sVariance[0];
											}
											return newVariance;
										} else {
											return variance;
										}
									}
								}
							}
						}
					}, {
						// name: "Customer Name",
						name: this.getOwnerComponent().getModel("i18n").getProperty("custName"),
						template: {
							content: "{CustomerName}"
						}
					}, {
						// name: "GLID/Global ID",
						name: this.getOwnerComponent().getModel("i18n").getProperty("glidGlobalId"),
						template: {
							content: "{GlobalID}"
						}
					}, {
						// name: "Carrier",
						name: this.getOwnerComponent().getModel("i18n").getProperty("carrier"),
						template: {
							content: "{Scac}"
						}
					}, {
						// name: "Storage Loc",
						name: this.getOwnerComponent().getModel("i18n").getProperty("storageLoc"),
						template: {
							content: "{Storageloc}"
						}
					}, {
						// name: "Type of Trucks",
						name: this.getOwnerComponent().getModel("i18n").getProperty("typOfTruck"),
						template: {
							content: "{Trucktyp}"
						}
					}, {
						// name: "Dock/Service Bay",
						name: this.getOwnerComponent().getModel("i18n").getProperty("dock"),
						template: {
							content: "{Dock}"
						}
					}, {
						// name: "Trailer Id",
						name: this.getOwnerComponent().getModel("i18n").getProperty("trailerId"),
						template: {
							content: "{Trailerid}"
						}
					}, {
						// name: "Reg Num",
						name: this.getOwnerComponent().getModel("i18n").getProperty("regNum"),
						template: {
							content: "{Regno}"
						}
					}, {
						// name: "Delivery Status",
						name: this.getOwnerComponent().getModel("i18n").getProperty("delStatus"),
						template: {
							content: "{DeliveryStatus}"
						}
					}, {
						// name: "Delivery Processed System",
						name: this.getOwnerComponent().getModel("i18n").getProperty("processSystem"),
						template: {
							content: "{Prosys}"
						}
					}, {
						// name: "Terms & Safety Agreement Accepted",
						name: this.getOwnerComponent().getModel("i18n").getProperty("termSaftyAggAcpt"),
						template: {
							content: "{TermsSafetyAgreement}"
						}
					}, {
						// name: "Check In System",
						name: this.getOwnerComponent().getModel("i18n").getProperty("checkInSys"),
						template: {
							content: "{CheckInSystem}"
						}
					}, {
						// name: "Check Out System",
						name: this.getOwnerComponent().getModel("i18n").getProperty("checkOutSys"),
						template: {
							content: "{CheckOutSystem}"
						}
					}]
				});
				/*** add this column only when parentplant is active ***/
				var parentplant = this.getView().getModel("ViewModel").getProperty("/ParentPlant");
				var sGetRegion = this.getView().getModel("regionModel").getProperty("/region");
				if (parentplant !== "") {
					// The below code is commented as part of ESP-5230
					// oExport.insertColumn(new sap.ui.core.util.ExportColumn({
					// 	name: this.getOwnerComponent().getModel("i18n").getProperty("Plant"),
					// 	template: {
					// 		content: "{Werks}"
					// 	}
					// }), 0);

					if (sGetRegion === "US") {
						oExport.insertColumn(new sap.ui.core.util.ExportColumn({
							name: this.getOwnerComponent().getModel("i18n").getProperty("checkInTyp"),
							template: {
								content: "{CheckInType}"
							}
						}), 28);
					}
				} else {
					if (sGetRegion === "US") {
						oExport.insertColumn(new sap.ui.core.util.ExportColumn({
							name: this.getOwnerComponent().getModel("i18n").getProperty("checkInTyp"),
							template: {
								content: "{CheckInType}"
							}
						}), 27);
					}
				}

				var sfdeReport = this.getOwnerComponent().getModel("i18n").getProperty("fdeReport");
				oExport.saveFile(sfdeReport).catch(function(oError) {
					// MessageBox.error("Error when downloading data. Browser might not be supported!\n\n" + oError);
				}).then(function() {
					oExport.destroy();
				});
			},

			// onPressExport: function() {
			// 	//Logic to export data in the page to xls format
			// 	//Read the HTML content Dynamically 
			// 	var hContent = '<html><head></head><body class="sapUiSizeCompact displayCSS">';
			// 	var bodyContent = "";
			// 	bodyContent = $(".tableClass").html();
			// 	var closeContent = "</body></html>";
			// 	var htmlpage = hContent + bodyContent + closeContent;
			// 	var htmls = "";
			// 	var uri = 'data:application/vnd.ms-excel;base64,';
			// 	var base64 = function(s) {
			// 		return window.btoa(unescape(encodeURIComponent(s)));
			// 	};

			// 	var format = function(s, c) {
			// 		return s.replace(/{(\w+)}/g, function(m, p) {
			// 			return c[p];
			// 		});
			// 	};

			// 	htmls = "Page Export";
			// 	var ctx = {
			// 		worksheet: 'Page_Export',
			// 		table: htmls
			// 	};

			// 	var link = document.createElement("a");
			// 	link.download = "Page_Export.xls";
			// 	link.href = uri + base64(format(htmlpage, ctx));
			// 	link.click();
			// },

			loadFiltersData: function() {
				var filterResults = sap.ui.getCore().byId("fdeReportTab").getModel().getData();

				//----Binded unique data of DelType to filter fragment----//
				var Delarray = [];
				var newdelarray = [];
				for (var i = 0; i < filterResults.length; i++) {
					if (Delarray.indexOf(filterResults[i].DeliveryType) === -1) {
						Delarray.push(filterResults[i].DeliveryType);
					}
					if (filterResults[i].DelvType !== "") {
						if (newdelarray.indexOf(filterResults[i].DelvType) === -1) {
							newdelarray.push(filterResults[i].DelvType);
						}
					}
				}
				var sDelType = [];
				for (var j = 0; j < Delarray.length; j++) {
					var stemp = {};
					stemp.delType = formatter.IssueReturn(Delarray[j]);
					sDelType.push(stemp);
				}
				for (var k = 0; k < newdelarray.length; k++) {
					sDelType.push({
						delType: newdelarray[k]
					});
				}
				sap.ui.getCore().byId("DelTypeFilter").setModel(new JSONModel(sDelType), "sDeliveryType");

				//----Binded unique data of TransType to filter fragment----//
				var Transarray = [];
				for (var i = 0; i < filterResults.length; i++) {
					if (Transarray.indexOf(filterResults[i].TranspType) === -1) {
						Transarray.push(filterResults[i].TranspType);
					}
				}
				if (sap.ui.getCore().byId("TransTypeFilter") !== undefined) {
					sap.ui.getCore().byId("TransTypeFilter").setModel(new JSONModel(Transarray), "sTransportType");
				}

				//----Binded unique data of UserId to filter fragment----//
				var userIdarray = [];
				for (var i = 0; i < filterResults.length; i++) {
					if (userIdarray.indexOf(filterResults[i].UserId) === -1) {
						userIdarray.push(filterResults[i].UserId);
					}
				}
				if (sap.ui.getCore().byId("UserIdFilter") !== undefined) {
					sap.ui.getCore().byId("UserIdFilter").setModel(new JSONModel(userIdarray), "sUserId");
				}

				//----Binded unique data of PrdCode to filter fragment----//
				var PCodearray = [];
				for (var i = 0; i < filterResults.length; i++) {
					if (PCodearray.indexOf(filterResults[i].Prodcode) === -1) {
						PCodearray.push(filterResults[i].Prodcode);
					}
				}
				if (sap.ui.getCore().byId("PrdCodeFilter") !== undefined) {
					sap.ui.getCore().byId("PrdCodeFilter").setModel(new JSONModel(PCodearray), "sProductCode");
				}

				//----Binded unique data of Batch to filter fragment----//
				var batcharray = [];
				for (var i = 0; i < filterResults.length; i++) {
					if (batcharray.indexOf(filterResults[i].Charg) === -1) {
						batcharray.push(filterResults[i].Charg);
					}
				}
				if (sap.ui.getCore().byId("BatchFilter")) {
					sap.ui.getCore().byId("BatchFilter").setModel(new JSONModel(batcharray), "sBatch");
				}

				//----Binded unique data of scac to filter fragment----//
				var scacarray = [];
				for (var i = 0; i < filterResults.length; i++) {
					if (scacarray.indexOf(filterResults[i].Scac) === -1) {
						scacarray.push(filterResults[i].Scac);
					}
				}
				if (sap.ui.getCore().byId("ScacFilter") !== undefined) {
					sap.ui.getCore().byId("ScacFilter").setModel(new JSONModel(scacarray), "sSCAC");
				}

				//----Binded unique data of Storage Location to filter fragment----//
				/*	var storLocarray = [];
				for (var i = 0; i < filterResults.length; i++) {
					if (storLocarray.indexOf(filterResults[i].Storageloc) === -1) {
						storLocarray.push(filterResults[i].Storageloc);
					}
				}
				if (sap.ui.getCore().byId("StorLocFilter") !== undefined) {
					sap.ui.getCore().byId("StorLocFilter").setModel(new JSONModel(storLocarray), "sStorLoc");
				}*/

				//----Binded unique data of Type of Truck to filter fragment----//
				var typTruckarray = [];
				for (var i = 0; i < filterResults.length; i++) {
					if (typTruckarray.indexOf(filterResults[i].Trucktyp) === -1) {
						typTruckarray.push(filterResults[i].Trucktyp);
					}
				}
				if (sap.ui.getCore().byId("typTruckFilter") !== undefined) {
					sap.ui.getCore().byId("typTruckFilter").setModel(new JSONModel(typTruckarray), "stypeTruck");
				}

				//----Binded unique data of dock/service bay to filter fragment----//
				var dockarray = [];
				for (var i = 0; i < filterResults.length; i++) {
					if (dockarray.indexOf(filterResults[i].Dock) === -1) {
						dockarray.push(filterResults[i].Dock);
					}
				}
				if (sap.ui.getCore().byId("DockFilter") !== undefined) {
					sap.ui.getCore().byId("DockFilter").setModel(new JSONModel(dockarray), "sDock");
				}

				var delStatusArray = [];
				for (var i = 0; i < filterResults.length; i++) {
					if (delStatusArray.indexOf(filterResults[i].DeliveryStatus) === -1) {
						delStatusArray.push(filterResults[i].DeliveryStatus);
					}
				}
				if (sap.ui.getCore().byId("delStat") !== undefined) {
					sap.ui.getCore().byId("delStat").setModel(new JSONModel(delStatusArray), "dStat");
				}

				var delProSys = [];
				for (var i = 0; i < filterResults.length; i++) {
					if (delProSys.indexOf(filterResults[i].Prosys) === -1) {
						delProSys.push(filterResults[i].Prosys);
					}
				}
				if (sap.ui.getCore().byId("processSys") !== undefined) {
					sap.ui.getCore().byId("processSys").setModel(new JSONModel(delProSys), "pSyst");
				}
				//----Binded unique data of parent plant to filter fragment----//
				var ParentPlant = [];
				for (var i = 0; i < filterResults.length; i++) {
					if (ParentPlant.indexOf(filterResults[i].Werks) === -1) {
						ParentPlant.push(filterResults[i].Werks);
					}
				}
				if (sap.ui.getCore().byId("ParentPlantFilter") !== undefined) {
					sap.ui.getCore().byId("ParentPlantFilter").setModel(new JSONModel(ParentPlant), "sParentPlant");
				}

			},

			onFilterPressed: function() {
				var that = this;
				that.oInsCreateDailog.open();

				if (!this._filterDialog) {
					this._filterDialog = sap.ui.xmlfragment("com.report.fragments.Filter", this);
					this.getView().addDependent(this._filterDialog);
				}
				/*** adding filter items for the multiplant scenario ***/
				var parentplant = this.getView().getModel("ViewModel").getProperty("/ParentPlant");
				if (parentplant !== "") {
					if (sap.ui.getCore().byId("ParentPlantFilter") === undefined) {
						var ParentPlantFilter = new sap.m.ViewSettingsFilterItem("ParentPlantFilter", {
							multiSelect: true,
							text: "{i18n>Plant}"

						});
						var Template = new sap.m.ViewSettingsItem({
							key: "Werks",
							text: "{sParentPlant>}"
						});
						ParentPlantFilter.bindAggregation("items", "sParentPlant>/", Template);
						this._filterDialog.addFilterItem(ParentPlantFilter);
					}
				}
				this.loadFiltersData();
				// toggle compact style
				jQuery.sap.syncStyleClass("sapUiSizeCompact", this.getView(), this._filterDialog);
				this._filterDialog.open();

				that.oInsCreateDailog.close();

				// var timeModel = new JSONModel("model/Time.json");
				// timeModel.attachRequestCompleted(function(oEvent) {
				// 	console.log(timeModel.getData());
				// 	this.getView().setModel(timeModel, "timeRangeModel");

				// }, this);

			},

			resetFilterItems: function() {
				var that = this;
				that.oInsCreateDailog.open();
				if (this._filterDialog !== undefined) {
					var aFilterItems = this._filterDialog.getFilterItems();

					aFilterItems.forEach(function(item) {
						var aItems = item.getItems();
						aItems.forEach(function(item) {
							item.setSelected(false);
						});
					});
				}
				that.oInsCreateDailog.close();
			},

			//---------------------Code for filtering----------------------//

			onFilterConfirm: function(oEvent) {
				var that = this;
				that.oInsCreateDailog.open();
				var oView = sap.ui.getCore();
				if (oView.byId("fdeReportTab") !== undefined) {
					var yTableFilter = oView.byId("fdeReportTab");
					var mParams = oEvent.getParameters();
					var oBinding = yTableFilter.getBinding("items");
					var aFilters = [];
					for (var i = 0, l = mParams.filterItems.length; i < l; i++) {
						var oItem = mParams.filterItems[i];
						if (oItem.getKey() === "DeliveryType") {
							var filterIssueReturn;
							var filterIssueReturn1;
							if (oItem.getText() === "Return") {
								filterIssueReturn = "02";
							} else if (oItem.getText() === "Issue") {
								filterIssueReturn = "01";
							} else if (oItem.getText() === "Raw Material PO") {
								filterIssueReturn = "03";
							} else if (oItem.getText() === "STO-Issue") {
								filterIssueReturn = "04";
							} else if (oItem.getText() === "STO-Return") {
								filterIssueReturn = "05";
							} else if (oItem.getText() === "Multi Issue") {
								filterIssueReturn1 = "Multi Issue";
							} else if (oItem.getText() === "Tip Reload") {
								filterIssueReturn1 = "Tip Reload";
							} else if (oItem.getText() === "Multi Return") {
								filterIssueReturn1 = "Multi Return";
							}
							if (filterIssueReturn !== "" && filterIssueReturn !== undefined) {
								var oFilter1 = new sap.ui.model.Filter("DeliveryType", "EQ", filterIssueReturn);
								var oFilterdelv = new sap.ui.model.Filter("DelvType", "EQ", "", undefined);
								aFilters.push(oFilter1, oFilterdelv);
								// aFilters.push(oFilter1);
							} else if (filterIssueReturn1 !== "" && filterIssueReturn1 !== undefined) {
								var oFilter2 = new sap.ui.model.Filter("DelvType", "EQ", filterIssueReturn1);
								aFilters.push(oFilter2);
								// var oFilter = new sap.ui.model.Filter("DeliveryType", "EQ", filterIssueReturn);
								// aFilters.push(oFilter);
							}
						} else if (oItem.getKey() === "TransportType") {
							var oFilter1 = new sap.ui.model.Filter("TranspType", "EQ", oItem.getText());
							aFilters.push(oFilter1);
						} else if (oItem.getKey() === "UserId") {
							var oFilter2 = new sap.ui.model.Filter("UserId", "EQ", oItem.getText());
							aFilters.push(oFilter2);
						} else if (oItem.getKey() === "ProductCode") {
							var oFilter3 = new sap.ui.model.Filter("Prodcode", "EQ", oItem.getText());
							aFilters.push(oFilter3);
						} else if (oItem.getKey() === "Batch") {
							var oFilter4 = new sap.ui.model.Filter("Charg", "EQ", oItem.getText());
							aFilters.push(oFilter4);
						} else if (oItem.getKey() === "SCAC") {
							var oFilter5 = new sap.ui.model.Filter("Scac", "EQ", oItem.getText());
							aFilters.push(oFilter5);
							/*	} else if (oItem.getKey() === "StorageLoc") {
								var oFilter5 = new sap.ui.model.Filter("Storageloc", "EQ", oItem.getText());
								aFilters.push(oFilter5);*/
						} else if (oItem.getKey() === "TypeTruck") {
							var oFilter6 = new sap.ui.model.Filter("Trucktyp", "EQ", oItem.getText());
							aFilters.push(oFilter6);
						} else if (oItem.getKey() === "Dock") {
							var oFilter7 = new sap.ui.model.Filter("Dock", "EQ", oItem.getText());
							aFilters.push(oFilter7);
						} else if (oItem.getKey() === "DeliveryStatus") {
							var oFilter8 = new sap.ui.model.Filter("DeliveryStatus", "EQ", oItem.getText());
							aFilters.push(oFilter8);
						} else if (oItem.getKey() === "Prosys") {
							var oFilter9 = new sap.ui.model.Filter("Prosys", "EQ", oItem.getText());
							aFilters.push(oFilter9);
						} else if (oItem.getKey() === "Werks") {
							var oFilter10 = new sap.ui.model.Filter("Werks", "EQ", oItem.getText());
							aFilters.push(oFilter10);
						}
					}
					oBinding.filter(aFilters);
				}

				that.oInsCreateDailog.close();
				var filteredIndices = oBinding.getContexts();
				var filteredUniqueDelNum = [];

				for (var k = 0; k < filteredIndices.length; k++) {
					var docPath = oBinding.getContexts()[k].getPath();
					var filDoc = this.getView().getModel("tabModel").getProperty(docPath).DocId;
					if (filteredUniqueDelNum.indexOf(filDoc) === -1) {
						filteredUniqueDelNum.push(filDoc);
					}
				}

				var sTotalQty = 0;
				for (var j = 0; j < filteredIndices.length; j++) {
					var sPath = oBinding.getContexts()[j].getPath();
					sTotalQty = sTotalQty + parseInt(this.getView().getModel("tabModel").getProperty(sPath).Lfimg);
				}
				that.getView().getModel("distinctCountModel").setProperty("/Sum", sTotalQty);
				that.getView().getModel("distinctCountModel").setProperty("/Count", filteredUniqueDelNum.length);
				that.getView().getModel("distinctCountModel").updateBindings();
				if (oEvent.getParameters().filterString) {
					var filteredData = oEvent.getParameters().filterString;
				}
				sap.ui.getCore().byId("headerData").setText(filteredData);
			},

			//----------------Code for opening Sorter Dailog when sorter icon pressed---------------------//

			onSorterPressed: function() {
				var that = this;
				that.oInsCreateDailog.open();
				if (!this._sorterDialog) {
					this._sorterDialog = sap.ui.xmlfragment("com.report.fragments.Sorter", this);
					this.getView().addDependent(this._sorterDialog);
				}
				/*** adding sort items for the multiplant scenario ***/
				var parentplant = this.getView().getModel("ViewModel").getProperty("/ParentPlant");
				if (parentplant !== "") {
					if (sap.ui.getCore().byId("ParentPlantSorter") === undefined) {
						var ParentPlantSort = new sap.m.ViewSettingsItem("ParentPlantSorter", {
							text: "{i18n>Plant}",
							key: "Werks"

						});
						this._sorterDialog.addSortItem(ParentPlantSort);
					}
				}
				// toggle compact style
				jQuery.sap.syncStyleClass("sapUiSizeCompact", this.getView(), this._sorterDialog);
				this._sorterDialog.open();
				that.oInsCreateDailog.close();
			},

			//-----------------------Code for Sorting---------------------------//

			onSortConfirm: function(oEvent) {
				var that = this;
				that.oInsCreateDailog.open();
				var oView = sap.ui.getCore();
				if (oView.byId("fdeReportTab") !== undefined) {
					var yardTable = oView.byId("fdeReportTab");
					var mParams = oEvent.getParameters();
					var oBinding = yardTable.getBinding("items");

					var aSorters = [];
					if (mParams.sortItem !== undefined) {
						var sPath = mParams.sortItem.getKey();
						var bDescending = mParams.sortDescending;
						if (sPath === "CompletionTime") {
							var sPath1 = "StartDate";
							aSorters.push(new sap.ui.model.Sorter(sPath1, bDescending));
						}
						aSorters.push(new sap.ui.model.Sorter(sPath, bDescending));
						oBinding.sort(aSorters);
					}
				}
				that.oInsCreateDailog.close();
			},

			//-----------------------------------------------------------------------------------------
			// Function for expanding the pnales inside the plant panels
			//-----------------------------------------------------------------------------------------
			onPressExp: function(oEvent) {
				var oPanelId = oEvent.getSource().getParent().getParent().getId();
				var oButtonId = oEvent.getSource().getId();
				if (sap.ui.getCore().byId(oPanelId).getExpanded()) {
					sap.ui.getCore().byId(oPanelId).setExpanded(false);
					sap.ui.getCore().byId(oButtonId).setIcon("sap-icon://expand-group");
				} else {
					sap.ui.getCore().byId(oPanelId).setExpanded(true);
					sap.ui.getCore().byId(oButtonId).setIcon("sap-icon://collapse-group");
				}
			},

			onNavButtonPress: function() {
				var oTabModel = this.getView().getModel("tabModel");
				if (oTabModel !== undefined) {
					oTabModel.destroy();
				}
				var oRouter = sap.ui.core.UIComponent.getRouterFor(this);
				oRouter.navTo("ReportInter");
			},
			panelHeaderClick: function(oEvent) {
				var sPanel = oEvent.getSource().getParent();
				if (sPanel.getExpanded()) {
					sPanel.setExpanded(false);
				} else {
					sPanel.setExpanded(true);
				}
			}
		});
	});