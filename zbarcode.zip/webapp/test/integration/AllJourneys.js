/*global QUnit*/

jQuery.sap.require("sap.ui.qunit.qunit-css");
jQuery.sap.require("sap.ui.thirdparty.qunit");
jQuery.sap.require("sap.ui.qunit.qunit-junit");
QUnit.config.autostart = false;

sap.ui.require([
	"sap/ui/test/Opa5",
	"com/zbarcode/test/integration/pages/Common",
	"sap/ui/test/opaQunit",
	"com/zbarcode/test/integration/pages/Worklist",
	"com/zbarcode/test/integration/pages/Object",
	"com/zbarcode/test/integration/pages/NotFound",
	"com/zbarcode/test/integration/pages/Browser",
	"com/zbarcode/test/integration/pages/App"
], function (Opa5, Common) {
	"use strict";
	Opa5.extendConfig({
		arrangements: new Common(),
		viewNamespace: "com.zbarcode.view."
	});

	sap.ui.require([
		"com/zbarcode/test/integration/WorklistJourney",
		"com/zbarcode/test/integration/ObjectJourney",
		"com/zbarcode/test/integration/NavigationJourney",
		"com/zbarcode/test/integration/NotFoundJourney"
	], function () {
		QUnit.start();
	});
});