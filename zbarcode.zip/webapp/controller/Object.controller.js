/*global location*/
sap.ui.define([
	"com/zbarcode/controller/BaseController",
	"sap/ui/model/json/JSONModel",
	"sap/ui/core/routing/History",
	"com/zbarcode/model/formatter",
	"sap/ui/model/Filter",
	"sap/ui/model/FilterOperator",
	"sap/m/MessageBox"
], function(
	BaseController,
	JSONModel,
	History,
	formatter,
	Filter,
	FilterOperator,
	MessageBox
) {
	"use strict";

	return BaseController.extend("com.zbarcode.controller.Object", {

		formatter: formatter,

		/* =========================================================== */
		/* lifecycle methods                                           */
		/* =========================================================== */

		/**
		 * Called when the worklist controller is instantiated.
		 * @public
		 */
		onInit: function() {
			this.getRouter().getRoute("object").attachPatternMatched(this._onObjectMatched, this);
		},

		/* =========================================================== */
		/* event handlers                                              */
		/* =========================================================== */

		/**
		 * Event handler  for navigating back.
		 * It there is a history entry we go one step back in the browser history
		 * If not, it will replace the current entry of the browser history with the worklist route.
		 * @public
		 */
		onBackPress: function() {
			var that = this;
			var sPreviousHash = History.getInstance().getPreviousHash();

			if (sPreviousHash !== undefined) {
				history.go(-1);
				var PODetails = new JSONModel({
					results: []
				});
				that.onAfterShow();
				that.getView().setModel(PODetails, "objectData");
			} else {
				this.getRouter().navTo("worklist", {}, true);
				var PODetails1 = new JSONModel({
					results: []
				});
				that.getView().setModel(PODetails1, "objectData");
			}
		},

		/* =========================================================== */
		/* internal methods                                            */
		/* =========================================================== */

		/**
		 * Binds the view to the object path.
		 * @function
		 * @param {sap.ui.base.Event} oEvent pattern match event in route 'object'
		 * @private
		 */
		_onObjectMatched: function(oEvent) {
			var that = this;
			var oModel1 = new JSONModel({
				qtyEnableFlag: false,
				postButton: false
			});
			that.getView().setModel(oModel1, "viewModel");
			that.sObjectId = oEvent.getParameter("arguments").PoNumber;
			that.getPODetails(that.sObjectId);
		},
		getPODetails: function(poNumber) {
			var that = this;
			var mFilters = [];
			var oModel = that.getOwnerComponent().getModel();
			var busyDialog = new sap.m.BusyDialog({
				text: "Data loading please wait..."
			});
			busyDialog.open();
			oModel.setUseBatch(false);
			mFilters.push(new Filter("PoNumber", FilterOperator.EQ, poNumber));
			oModel.read("/Get_DetailsSet", {
				filters: mFilters,
				success: function(OData) {
					busyDialog.close();
					var PODetails = new JSONModel(OData.results);
					if (OData.results.length > 0) {
						for (var i = 0; i < OData.results.length; i++) {
							OData.results[i].qtyEnableFlag = false;
						}
						that.getView().setModel(PODetails, "objectData");

					} else {
						PODetails.setData({
							results: []
						});
					}
				},
				error: function(err) {
					busyDialog.close();
					var error = JSON.parse(err.responseText).error.innererror.errordetails[0].message;
					sap.m.MessageBox.error(error);
				}
			});
		},

		/* Event handler for Post Button */

		onPostPress: function(oEvent) {
			var that = this,
				oArray = [],
				data = oEvent.getSource().getParent().getParent().getSelectedContexts("objectData"),
				oItems = oEvent.getSource().getParent().getParent().getSelectedItems();
			var busyDialog = new sap.m.BusyDialog({
				text: "GR is posting please wait..."
			});
			busyDialog.open();
			if (oItems.length > 0) {
				var oModel = that.getOwnerComponent().getModel();
				data.forEach(function(item) {
					var obj = item.getObject();
					delete obj.qtyEnableFlag;
					delete obj.__metadata;
					oArray.push(obj);
				});
				var oEntry = {
					"PoNumber": that.sObjectId,
					"Get_Detailsset": oArray
				};
				var msg = "Are you sure you want to update the Quantity(s)?";
				MessageBox.show(msg, {
					icon: MessageBox.Icon.INFORMATION,
					title: "Confirmation",
					actions: [MessageBox.Action.OK, MessageBox.Action.CANCEL],
					onClose: function(oAction) {
						if (oAction === MessageBox.Action.OK) {
							oModel.create("/PO_ITEM_DETAILSSet", oEntry, {
								success: function(OData) {
									var sMsg = "PO Number " + that.sObjectId + " Quantity(s)  updated Successfully";
									MessageBox.success(sMsg, {
										icon: "Success",
										action: [MessageBox.Action.OK],
										onClose: function(Action) {
											busyDialog.close();
											if (Action === MessageBox.Action.OK) {
												that.getPODetails(that.sObjectId);
											} else {
												busyDialog.close();
											}
										}
									});

								},
								error: function(err) {
									busyDialog.close();
									var error = JSON.parse(err.responseText).error.message.value;
									MessageBox.error(error);
								}
							});
						}
					}
				});
				busyDialog.close();
			} else {
				sap.m.MessageBox.error("Please select atleast one record");
			}
		},

		/* This method is making the Input Enable on the condition base */

		QuantityChng: function(oEvent) {
			var that = this;
			if (oEvent.getParameters().selected === true) {
				oEvent.getParameters().listItems.forEach(function(item) {
					var oContext = item.getBindingContext("objectData");
					var path = oContext.getPath();
					var obj = oContext.getObject();
					obj.qtyEnableFlag = true;
					that.getView().getModel("objectData").setProperty(path, obj, oContext, true);
				});
			} else {
				oEvent.getParameters().listItems.forEach(function(item) {
					var oContext = item.getBindingContext("objectData");
					var path = oContext.getPath();
					var obj = oContext.getObject();
					obj.qtyEnableFlag = false;
					that.getView().getModel("objectData").setProperty(path, obj, oContext, true);
					that.getView().getModel("viewModel").setProperty("/postButton", false);
				});
			}
			var sRecords = oEvent.getSource().getSelectedItems();
			var oRecords = that.getView().getModel("objectData").getData().length;
			if (oRecords > 0 && sRecords.length > 0) {
				that.getView().getModel("viewModel").setProperty("/postButton", true);
			} else {
				that.getView().getModel("viewModel").setProperty("/postButton", false);
			}

		},
		onSearchTableData: function(oEvent) {
			var that = this,
				sQuery = oEvent.getSource().getValue();

			if (sQuery === "") {
				that.onPressSearchRefresh();
			} else {
				if (!sQuery) {
					sQuery = oEvent.getParameter("newValue");
				}

				var filter1 = new Filter("ItemNo", FilterOperator.EQ, sQuery);
				var filter2 = new Filter("PoNumber", FilterOperator.Contains, sQuery);
				var filter3 = new Filter("Material", FilterOperator.Contains, sQuery);
				var filter4 = new Filter("MaterialDescription", FilterOperator.Contains, sQuery);
				var filter5 = new Filter("Unit", FilterOperator.Contains, sQuery);
				var filter6 = new Filter("UnitPrice", FilterOperator.Contains, sQuery);
				var filter7 = new Filter("Amount", FilterOperator.Contains, sQuery);
				var filter8 = new Filter("Quantity", FilterOperator.Contains, sQuery);
				var filterData = [filter1, filter2, filter3, filter4, filter5, filter6, filter7, filter8];
				var oNewFilter = new Filter({
					filters: filterData,
					and: false
				});
				// filter binding
				var oTab = that.getView().byId("itemsId");
				var oBinding = oTab.getBinding("items");
				oBinding.filter(oNewFilter);
			}

		},
		onPressSearchRefresh: function() {
			var that = this;
			var oTable = that.getView().byId("itemsId");
			var oBindings = oTable.getBinding("items");
			oBindings.filter(null);

		}

	});

});