sap.ui.define([
	"com/zbarcode/controller/BaseController",
	"sap/ui/model/json/JSONModel",
	"sap/ui/core/routing/History",
	"com/zbarcode/model/formatter",
	"sap/ui/model/Filter",
	"sap/ui/model/FilterOperator"
], function(
	BaseController,
	JSONModel,
	History,
	formatter,
	Filter,
	FilterOperator
) {
	"use strict";
	var data = [];
	return BaseController.extend("com.zbarcode.controller.PODetails", {

		onInit: function() {
			var that = this;
			var viewModel = new JSONModel({
				PoNumber: "",
				vendorNo: "",
				userName: "",
				poTable: false,
				editPoNum: true,
				editVendNo: true,
				editUserName: true
			});
			that.getView().setModel(viewModel, "viewModel");
			var serviceData = new JSONModel();
			that.getView().setModel(serviceData, "serviceData");
			this.getRouter().getRoute("object").attachPatternMatched(this._onObjectMatched, this);

		},
		/* =========================================================== */
		/* event handlers                                              */
		/* =========================================================== */
		
		/* Event handlers for Navigating back */
		
		onNavBack: function() {
			var that = this;
			var route = sap.ui.core.UIComponent.getRouterFor(this);
			route.navTo("worklist");
			that.onPressClear();
		},
		_onObjectMatched: function(){
			var that = this;
			that.onPressClear();
		},
		/* Event handlers for Navigating on press of ListItem */
		
		onItempress: function(oEvent) {
			var that = this;
			var route = sap.ui.core.UIComponent.getRouterFor(this);
			var obj = oEvent.getSource().getBindingContext("serviceData").getObject();
			route.navTo("object", {
				PoNumber: obj.PoNumber
			});
		},
		
		/* Event handler for Input of PO Number */
		
		onTypePOs: function() {
			var that = this;
			that.getView().getModel("viewModel").setProperty("/editUserName", false);
			that.getView().getModel("viewModel").setProperty("/editVendNo", false);
		},
		
		/* Event handler for Input of Vendor No && UserName */
		
		onTypeVendNOUname: function() {
			var that = this;
			that.getView().getModel("viewModel").setProperty("/editPoNum", false);

		},
		
		/* Event handler for Filterbar Go button */
		
		onPressGo: function() {
			var that = this;
			var PONumber = that.getView().getModel("viewModel").getProperty("/PoNumber");
			var vendNo = that.getView().getModel("viewModel").getProperty("/vendorNo");
			var username = that.getView().getModel("viewModel").getProperty("/userName");
			if (PONumber !== "") {
				var route = sap.ui.core.UIComponent.getRouterFor(this);
				route.navTo("object", {
					PoNumber: PONumber
				});
			}else if(PONumber === "" && vendNo === "" && username === "") {
				sap.m.MessageBox.warning("Please enter any of the above filters");
			}
			else	{
				that.getDetails();
			}
			
		},
		/* =========================================================== */
		/* internal methods                                            */
		/* =========================================================== */
		
		/* This method is for making service call and get Data */
		
		getDetails: function() {
			var that = this,
				mFilters = [],
				uName = that.getView().getModel("viewModel").getProperty("/userName"),
				vendNoInput = that.getView().getModel("viewModel").getProperty("/vendorNo"),
				PONumber = that.getView().getModel("viewModel").getProperty("/PoNumber"),
				oModel = that.getOwnerComponent().getModel();
				if(vendNoInput !== ""){
				var vendorNumber = "00"+vendNoInput;
				}else{
					vendorNumber = "";
				}
			oModel.setUseBatch(false);
			mFilters.push(new Filter("PersonCreated", FilterOperator.EQ, uName));
			mFilters.push(new Filter("Vendor", FilterOperator.EQ, vendorNumber));
			mFilters.push(new Filter("PoNumber", FilterOperator.EQ, PONumber));
			var busyDialog = new sap.m.BusyDialog({
				text: "Data loading please wait..."
			});
			busyDialog.open();
			oModel.read("/Get_DetailsSet", {
				filters: mFilters,
				success: function(OData) {
					busyDialog.close();
					var PODetails = new JSONModel(OData.results);
					if(OData.results.length>0){
					that.getView().setModel(PODetails, "serviceData");
					that.getView().getModel("viewModel").setProperty("/poTable", true);
					}else{
						PODetails.setData({
							results: []
						});
						that.getView().getModel("viewModel").setProperty("/poTable", false);
					}
				},
				error: function(err) {
					busyDialog.close();
					var error = JSON.parse(err.responseText).error.innererror.errordetails[0].message;
					sap.m.MessageBox.error(error);
				}
			});
		},
		
		/* This method is for clearing the value in the input */
		
		onPressClear: function() {
			var that = this;
			that.getView().getModel("viewModel").setProperty("/userName", "");
			that.getView().getModel("viewModel").setProperty("/vendorNo", "");
			that.getView().getModel("viewModel").setProperty("/PoNumber", "");
			that.getView().getModel("viewModel").setProperty("/poTable", false);
			that.getView().getModel("viewModel").setProperty("/editPoNum", true);
			that.getView().getModel("viewModel").setProperty("/editVendNo", true);
			that.getView().getModel("viewModel").setProperty("/editUserName", true);

		}
	});

});