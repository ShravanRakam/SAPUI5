/*global location history */
sap.ui.define([
	"com/zbarcode/controller/BaseController",
	"sap/ui/model/json/JSONModel",
	"com/zbarcode/model/formatter",
	"sap/ui/model/Filter",
	"sap/ui/model/FilterOperator"
], function(BaseController, JSONModel, formatter, Filter, FilterOperator) {
	"use strict";
	var newArray = [];
	return BaseController.extend("com.zbarcode.controller.Worklist", {

		formatter: formatter,

		/* =========================================================== */
		/* lifecycle methods                                           */
		/* =========================================================== */

		/**
		 * Called when the worklist controller is instantiated.
		 * @public
		 */
		onInit: function() {
			
			
		},

		/* =========================================================== */
		/* event handlers                                              */
		/* =========================================================== */
		/**
		
			/* Event handler when a table item gets pressed */
			
			onItempress: function(oEvent) {
			var that = this;
			var route = sap.ui.core.UIComponent.getRouterFor(this);
			var obj = oEvent.getSource().getBindingContext("barcodes").getObject();
			route.navTo("object", {
				PoNumber: obj.code
			});
		},
		
		/* Event handler when pressed button Manual Purchase Order Entry */
		
		onManualPO: function() {
			var oRouter = sap.ui.core.UIComponent.getRouterFor(this);
			oRouter.navTo("PODetails");
		},

		/* =========================================================== */
		/* internal methods                                            */
		/* =========================================================== */
		
		
		/*This method is for scanning the PO Number*/
		
		onScanPress: function() {
			var that = this;
			//	that._getBusyDialog.open();
			jQuery.sap.require("sap.ndc.BarcodeScanner");
			sap.ndc.BarcodeScanner.scan(
				function(mResult) {
					var oTable = that.byId("table");
					var serialNumber = oTable.getItems().length + 1;
					var sObject = {};

					sObject.code = mResult.text;
					//alert(sObject.code);
					sObject.format = mResult.format;
					sObject.number = serialNumber;
					var i18nModel = that.getOwnerComponent();
					var error = i18nModel.getModel("i18n").getProperty('submiterror');
					var inputMsg = i18nModel.getModel("i18n").getProperty('code');
					if (sObject.code === "") {
						sap.m.MessageBox.show(
							inputMsg, {
								icon: sap.m.MessageBox.Icon.ERROR,
								title: error //"Error during submitting!"
							});

					} else if (sObject.format === "") {
						sap.m.MessageBox.show(
							inputMsg, {
								icon: sap.m.MessageBox.Icon.ERROR,
								title: error //"Error during submitting!"
							});

					} else {
						newArray.push(sObject);
						var oModel = new sap.ui.model.json.JSONModel(newArray);
						oTable.setModel(oModel, "barcodes");
					}

				},
				function(Error) {
					var i18nModel = that.getOwnerComponent();
					var error = i18nModel.getModel("i18n").getProperty('submiterror');
					var inputMsg = i18nModel.getModel("i18n").getProperty('code');
					sap.m.MessageBox.show(
						inputMsg, {
							icon: sap.m.MessageBox.Icon.ERROR,
							title: error //"Error during submitting!"
						});
				}

			);

		}

	});
});