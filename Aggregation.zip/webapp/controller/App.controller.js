sap.ui.define([
	"sap/ui/core/mvc/Controller",
	"sap/ui/core/ValueState",
	"sap/ui/model/Sorter",
	"sap/ui/model/Filter",
	"sap/ui/model/FilterOperator",
	"sap/ui/table/library",
	"sap/ui/model/json/JSONModel"

], function(Controller, ValueState, Sorter, Filter, FilterOperator, library, JSONModel) {
	"use strict";
	// var SortOrder = library.SortOrder;
	
	return Controller.extend("com.AggregationAggregation.controller.App", {
		onInit: function() {
			var that = this;
			// for M table
		
			var Products1Model = new JSONModel(jQuery.sap.getModulePath("com.AggregationAggregation", "/model/Products.json"));
			that.getView().setModel(Products1Model, "Products1Model");

			// for UI table
			
			
			var oModel2 = new JSONModel(jQuery.sap.getModulePath("com.AggregationAggregation", "/model/Products2.json"));
			that.getView().setModel(oModel2, "Products2Model");

			//for registration form

			var formData = new sap.ui.model.json.JSONModel();
			formData.loadData("model/form.json");
			this.getView().setModel(formData);

		},
		// formatter for Price state based on the price
		formatPriceState: function(iState) {
			if (iState <= 30000) {
				return ValueState.Success;
			} else if (iState > 30000 && iState <= 50000) {
				return ValueState.Warning;
			} else
				return ValueState.Error;

		},
		// function for filtering the products
		onFilterProducts: function(oEvent) {
			//build filter array
			var filterProducts = [];
			var sQuery = oEvent.getParameter("query");

			if (sQuery) {
				filterProducts.push(new Filter("Prod_Name", FilterOperator.Contains, sQuery));
			}
			// filter binding
			var oTable1 = this.getView();

			var oBinding1 = oTable1.getBinding("items");

			oBinding1.filter(filterProducts);

		},
		// for sorting of products
		onSort: function() {
			var that = this;
			var oView = that.getView(),
				aStates = [undefined, "asc", "desc"];
			// aStateTextIds = ["sortNone", "sortAscending", "sortDescending"],

			var iPrice = that.getView().getModel("Products1Model").getProperty("Prod_Price");
			iPrice = (iPrice + 1) % aStates.length;
			var sPrice = aStates[iPrice];
			oView.getModel("Products1Model").setProperty("Prod_Price", iPrice);
			oView.byId("Tab1").getBinding("items").sort(sPrice && new Sorter("Prod_Price", sPrice === "desc"));

		},
		// for navigating the screen
		
		onPress: function(){
			var oRouter = sap.ui.core.UIComponent.getRouterFor(this);
			oRouter.navTo("view2");
		},
		addRow: function() {
			var that = this;
			that.getView().getModel("Products1Model").getData().Details.push({
				Prod_Id: "",
				Prod_Name: "",
				Category: "",
				Brand: "",
				Price: ""
			});
			that.getView().getModel("Products1Model").refresh(); //which will add the new record
		},
		onBeforeRendering: function() {

			var that = this;

			that.getView().getModel("Products1Model");
			// that.byId("login").setModel(that.sTableModel);
		},
			deleteRow: function(oEvent) {
			var that = this;
			var oContext = oEvent.getSource().getBindingContext("Products1Model");
			var oPath = oContext.getPath();
			var oModel = that.getView().getModel("Products1Model");
			var oData = that.getView().getModel("Products1Model").getData();
			var l = parseInt(oPath.split("/")[2]);
			oData.Details.splice(l, 1);
			oData.Details.forEach(function(item, index) {
				item.SNo = index + 1;
			});
			oModel.setData(oData);
			oModel.refresh(true);
		},
		
		// for navigating Northwind service
		
		onPressButton: function(){
			var oRouter = sap.ui.core.UIComponent.getRouterFor(this);
			oRouter.navTo("northwind");
		}


	});
});