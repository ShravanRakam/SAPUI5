sap.ui.define([
	"sap/ui/core/mvc/Controller",
	"sap/ui/model/json/JSONModel"
], function(Controller, JSONModel) {
	"use strict";

	return Controller.extend("com.AggregationAggregation.controller.Northwind", {
		onInit: function() {
			var that = this;
			
            // that.getView().setModel(viewModel, "NorthwindData");
			var sUrl = "/Northwind/V2/Northwind/Northwind.svc/";
			var oModel = new sap.ui.model.odata.ODataModel(sUrl, true);
			that.getView().setModel(oModel, "nortWindModel"); // local to the View
		

			var eData = that.getView().getModel("nortWindModel");
			eData.read("/Products", {
			success: function(oData, res) {
                    if (res.statusCode === "200" || res.statusCode === 200) {
                    
                        // that.getView().getModel("NorthwindData").setData(oData.results);
                        var viewModel = new JSONModel(oData.results);
                         //console.log(oData.results);
                        that.getView().setModel(viewModel, "dataModel");
                        var data = that.getView().getModel("dataModel").getData(oData.results);
                       
                        console.log(data);
                    }
                },
                error: function(err) {
                    // console.log(err);
                }
			

			});
		}

		// onInit: function() {
		// 	var sUrl = "/Northwind/V2/Northwind/Northwind.svc/";
		// 	var oModel = new sap.ui.model.odata.ODataModel(sUrl, true);
		// 	sap.ui.getCore().setModel(oModel);
		// }

	
	});
});