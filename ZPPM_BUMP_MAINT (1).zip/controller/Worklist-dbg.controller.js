/*global location history */
sap.ui.define([
	"bumpmaint/zbump_maintenance/controller/BaseController",
	"sap/ui/model/json/JSONModel",
	"bumpmaint/zbump_maintenance/model/formatter",
	"sap/ui/model/Filter",
	"sap/ui/model/FilterOperator"
], function (BaseController, JSONModel, formatter, Filter, FilterOperator) {
	"use strict";

	return BaseController.extend("bumpmaint.zbump_maintenance.controller.Worklist", {
		formatter: formatter,
		/* =========================================================== */
		/* lifecycle methods                                           */
		/* =========================================================== */

		/**
		 * Called when the worklist controller is instantiated.
		 * @public
		 */
		onInit: function () {
			var that = this;
			var mModel = that.getOwnerComponent().getModel("oDataSrv");
			that.oLoggedinUser = "";
			that.craftUnion = "";
			var y = "/sap/bc/ui2/start_up";
			var xmlHttp = null;
			xmlHttp = new XMLHttpRequest();
			xmlHttp.onreadystatechange = function () {
				if (xmlHttp.readyState === 4 && xmlHttp.status === 200) {
					var oUserData = JSON.parse(xmlHttp.responseText);
					that.oLoggedinUser = oUserData.id;
					var firstName = oUserData.firstName;
					var lastName = oUserData.lastName;
					that.name = firstName + " " + lastName;
					//------ Calling the oData service for Craft ------
					mModel.read("/UserDetailsSet?$filter=Uname eq '" + that.oLoggedinUser + "'", null, null, false,
						function (oData) {
							that.userDetailsSetData = oData; //settting the odata to global variable access the User details 
							that.craftUnion = oData.results[0].Unions;
							//setting the view model for visibility control
							var oViewModel = new sap.ui.model.json.JSONModel({
								Unions: oData.results[0].Unions
							});
							that.getView().setModel(oViewModel, "viewModel");
							var resul = oData.results;
							var rolesArray = resul.slice();
							var roleVals = [];
							for (var i = 0; i < rolesArray.length; i++) {
								var oVal1 = rolesArray[i].Role;
								roleVals.push(oVal1);
							}
							var finalArray = that.uniqueValuesFunc(roleVals, "Role");
							var oDataRole = {
								results: finalArray
							};
							var selectedKey1 = oDataRole.results[0].Role;
							var oJModelRole = new sap.ui.model.json.JSONModel(oDataRole);
							that.byId("roleIdSelect").setModel(oJModelRole);
							that.byId("roleIdSelect").setSelectedKey(selectedKey1);
							//fire the change event of the roles dropdown to get the departments values
							that.byId("roleIdSelect").fireChange(that.byId("roleIdSelect").getSelectedItem());

							// var resul2 = oData.results;
							// var DepArray2 = resul2.slice();
							// var depVals = [];
							// for (var i = 0; i < DepArray2.length; i++) {
							// 	var oVal = DepArray2[i].Department;
							// 	depVals.push(oVal);
							// }
							// var finalArray2 = that.uniqueValuesFunc(depVals, "Department");
							// var oDataRole2 = {
							// 	results: finalArray2
							// };
							// var oJModel = new sap.ui.model.json.JSONModel(oDataRole2);
							// // oJModel.setDefaultBindingMode("OneWay");
							// var selectedKey2 = oDataRole2.results[0].Department;

							// var oJModelRole = new sap.ui.model.json.JSONModel(oDataRole);
							// // oJModelRole.setDefaultBindingMode("OneWay");
							// var selectedKey1 = oDataRole.results[0].Role;
							// that.byId("roleIdSelect").setModel(oJModelRole);
							// that.byId("depIdSelect").setModel(oJModel);
							// that.byId("roleIdSelect").setSelectedKey(selectedKey1);
							// that.byId("depIdSelect").setSelectedKey(selectedKey2);
							// that.byId("oBumpMaintPageId").setShowFooter(true);
							// var roleSelection = that.byId("roleIdSelect").getSelectedKey();
							// that.onRoleSelectionChange();

							// that.byId("roleIdSelect").clearSelection(true);
							// that.byId("depIdSelect").clearSelection(true);
						});

				}
			};
			xmlHttp.open("GET", y, false);
			xmlHttp.send(null);

			that.byId("effDateId").setMinDate(new Date());
			if (!that._oResponsivePopover) {
				that._oResponsivePopover = sap.ui.xmlfragment("bumpmaint.zbump_maintenance.fragments.FilterPopover",
					that);
				that.getView().addDependent(that._oResponsivePopover, that);
				// that._oResponsivePopover.setModel(sap.ui.getCore().getModel("tabhdr"));
			}

			var oTable = that.byId("bumpHeadTabId");
			oTable.addEventDelegate({
				onAfterRendering: function () {
					var oHeader = oTable.$().find('.sapMListTblHeaderCell'); //Get hold of table header elements
					for (var i = 0; i < oHeader.length; i++) {
						var oID = oHeader[i].id;
						that.onClick(oID);
					}
				}
			}, oTable);
			that.aFilters = [];
			that.activeEligTableBindFunc(this.craftUnion);

		},

		activeEligTableBindFunc: function (craft) {
			var that = this;
			var oTable = that.byId("bumpTableId");
			var oFilter = new sap.ui.model.Filter("Craft", "EQ", craft);
			oTable.setBusy(true);
			oTable.setBusyIndicatorDelay(0);
			var oEligModel = new sap.ui.model.json.JSONModel();
			oEligModel.setDefaultBindingMode("OneWay");
			var oModel = that.getOwnerComponent().getModel("oDataSrv");
			oModel.setUseBatch(false);
			that.aFilters = [];
			oModel.read("/BumpDataSet", {
				async: true,
				filters: [oFilter],
				success: function (oData) {
					oEligModel.setData(oData);
					oTable.setBusy(false);
					oTable.setModel(oEligModel);
					var sItems = oTable.getBinding("items");
					var sSorter = new sap.ui.model.Sorter("BumpId", true);
					sItems.sort(sSorter);
					oTable.getModel().refresh();
				}
			});

		},

		onEffDateChange: function (oEvent) {
			var bValid = oEvent.getParameter("valid");

			if (bValid) {
				oEvent.getSource().setValueState("None");
			} else {
				oEvent.getSource().setValueState("Error");
				oEvent.getSource().setValue();
			}
		},

		onEndDateChange: function (oEvent) {
			var oEffDate = this.getView().byId("effDateId").getValue();
			var bValid = oEvent.getParameter("valid");
			if (bValid) {
				oEvent.getSource().setValueState("None");
				if (oEffDate > oEvent.getSource().getValue()) {
					oEvent.getSource().setValue();
					oEvent.getSource().setValueState("Error");
					sap.m.MessageToast.show("Bump End date should be greater than Bump Start Date");
				} else {
					oEvent.getSource().setValueState("None");
				}
			} else {
				oEvent.getSource().setValueState("Error");
				oEvent.getSource().setValue();
			}

		},

		onEndTimeChange: function (oEvent) {
			var oEffDate = this.byId("effDateId").getValue();
			var oEndDate = this.byId("endDateId").getValue();
			var oStartTime = this.byId("effTimeId").getValue();
			if (oEffDate === oEndDate) {
				if (oStartTime > oEvent.getSource().getValue()) {
					oEvent.getSource().setValue("000000");
					oEvent.getSource().setValueState("Error");
					sap.m.MessageToast.show("Bump End Time should be greater than Bump Start Time");
				} else {
					oEvent.getSource().setValueState("None");
				}
			}
		},

		onRoleSelectionChange: function (oEvent) {
			var that = this;
			var oSelectedRole = oEvent.getSource().getSelectedKey();
			var selectedRows = [];
			//get the same roles data based on the role selection
			for (var i = 0; i < that.userDetailsSetData.results.length; i++) {
				if (that.userDetailsSetData.results[i].Role === oSelectedRole) {
					selectedRows.push(that.userDetailsSetData.results[i]);
				}
			}
			//create the array of object of unique departments to bind it to the group dropdown
			var newObj = {};
			var newDepAndUnionsArray = selectedRows.filter(function (obj) {
				if (newObj[obj.Department]) {
					return false;
				}
				newObj[obj.Department] = true;
				return true;
			});

			var oDataRole2 = {
				results: newDepAndUnionsArray
			};
			var oJModel = new sap.ui.model.json.JSONModel(oDataRole2);
			oJModel.setDefaultBindingMode("OneWay");
			that.byId("depIdSelect").setModel(oJModel, "DepModel");

			that.byId("depIdSelect").setSelectedKey(newDepAndUnionsArray[0].Unions);
			//fire the change event of the roles dropdown to get the departments values
			that.byId("depIdSelect").fireChange(that.byId("depIdSelect").getSelectedItem());
			//to set the enable of the group dropdown based on the data
			if (newDepAndUnionsArray.length === 1 || newDepAndUnionsArray.length === 0) {
				that.byId("depIdSelect").setEnabled(false);
			} else {
				that.byId("depIdSelect").setEnabled(true);
			}
			// var oSelectedRole = this.byId("roleIdSelect").getSelectedKey();
			// this.byId("depIdSelect").setSelectedKey(oSelectedRole);
			// var oSelctedIndex;
			/*if (oSelectedRole === "LR Admin") {
				// this.byId("depIdSelect").setEnabled(true);
				this.byId("createBumpEligTabId").setVisible(false);
				this.byId("oBumpMaintPageId").setShowFooter(false);
			} else {
				// this.byId("depIdSelect").setEnabled(false);
				this.byId("createBumpEligTabId").setVisible(true);
				this.byId("oBumpMaintPageId").setShowFooter(true);
			}*/

			// if (oSelectedRole === "ATDA") {

			// } else if (oSelectedRole === "Mechanical") {

			// } else if (oSelectedRole === "TCU") {

			// } else if (
			// 	oSelectedRole !== "LR Admin") {

			// }
			// this.craftUnion = oSelectedRole;
		},

		onDepSelectionChange: function (oEvent) {
			// var oSelectedKey = this.byId("depIdSelect").getSelectedKey();
			var sPath = oEvent.getSource().getSelectedItem().getBindingContext("DepModel").getPath();
			var data = oEvent.getSource().getModel("DepModel").getProperty(sPath);
			// var Department = data.Department;
			var union = data.Unions;
			this.getView().getModel("viewModel").setProperty("/Unions", union);
			// this.byId("depIdSelect").setSelectedKey(oSelectedKey);
			var mCraft;
			//set the craft union based on the model path
			this.craftUnion = data.Unions;
			// this.craftUnion = mCraft;
			// var oSelectedKey = "E";
			var oTable = this.byId("bumpList");
			oTable.setVisible(true);
			var empId = ""; //initiallily emp id will be empty
			if (union === "SM" || union === "M") {
				mCraft = "M";
				this.onGetCallFunc(mCraft, oTable, empId);
			} else if (union === "SE" || union === "E") {
				mCraft = "E";
				this.onGetCallFunc(mCraft, oTable, empId);
			} else if (union === "ST" || union === "T") {
				mCraft = "T";
				this.onGetCallFunc(mCraft, oTable, empId);
			} else if (union === "SA" || union === "A" || union === "D" || union === "SD") {
				mCraft = "D";
				this.onGetCallFunc(mCraft, oTable, empId);
			} else {
				var oJModel = new sap.ui.model.json.JSONModel([{
					"results": ""
				}]);
				oTable.setVisible(false);
				oTable.setModel(oJModel, "bumpListModel");

			}
			// if (Department === "Mechanical") {
			// 	mCraft = "M";

			// 	oTable = this.byId("mechTableId");
			// 	oTable.setVisible(true);
			// 	this.byId("EngTableId").setVisible(false);
			// 	this.byId("tcuTableId").setVisible(false);
			// 	this.byId("atdaTableId").setVisible(false);
			// 	this.onGetCallFunc(mCraft, oTable);
			// } else if (Department === "Engineering") {
			// 	mCraft = "E";

			// 	// this.byId("endDateId").setValue("11:59");
			// 	this.byId("mechTableId").setVisible(false);
			// 	oTable = this.byId("EngTableId");
			// 	oTable.setVisible(true);
			// 	this.byId("tcuTableId").setVisible(false);
			// 	this.byId("atdaTableId").setVisible(false);
			// 	this.onGetCallFunc(mCraft, oTable);
			// } else if (Department === "TCU") {
			// 	mCraft = "T";

			// 	this.byId("mechTableId").setVisible(false);
			// 	this.byId("EngTableId").setVisible(false);
			// 	oTable = this.byId("tcuTableId");
			// 	oTable.setVisible(true);
			// 	this.byId("atdaTableId").setVisible(false);
			// 	this.onGetCallFunc(mCraft, oTable);
			// } else if (Department === "ATDA" || Department === "Dispatchers") {
			// 	mCraft = "A";

			// 	this.byId("mechTableId").setVisible(false);
			// 	this.byId("EngTableId").setVisible(false);
			// 	this.byId("tcuTableId").setVisible(false);
			// 	oTable = this.byId("atdaTableId");
			// 	oTable.setVisible(true);
			// 	this.onGetCallFunc(mCraft, oTable);
			// } else {
			// 	// var results=[];

			// 	var oJModel = new sap.ui.model.json.JSONModel([{
			// 		"results": ""
			// 	}]);
			// 	this.byId("mechTableId").setModel(oJModel);
			// 	this.byId("EngTableId").setModel(oJModel);
			// 	this.byId("tcuTableId").setModel(oJModel);
			// 	this.byId("atdaTableId").setModel(oJModel);

			// }

		},

		onGetCallFunc: function (craft, oTable, empNo) {
			var oModel = this.getOwnerComponent().getModel();
			var sFilter = [];
			var oCraft = new sap.ui.model.Filter("Craft", "EQ", craft);
			sFilter.push(oCraft);
			if (empNo.trim() !== "") {
				var oEmpId = new sap.ui.model.Filter("EmpId", "EQ", empNo);
				sFilter.push(oEmpId);
			}
			var oJModel = new sap.ui.model.json.JSONModel();
			oModel.setUseBatch(false);
			var oPage = this.byId("oBumpMaintPageId");
			oPage.setBusy(true);
			oPage.setBusyIndicatorDelay(0);
			oModel.read("/BumpListSet", {
				filters: sFilter,
				success: function (oData) {
					oPage.setBusy(false);
					oJModel.setData(oData);
					oTable.setModel(oJModel, "bumpListModel");
					oTable.getModel("bumpListModel").refresh();
				},
				error: function () {
					oPage.setBusy(false);
				}
			});
		},

		uniqueValuesFunc: function (array, field) {
			// var names = ["Mike", "Matt", "Nancy", "Adam", "Jenny", "Nancy", "Carl"];
			var uniqueValues = [];
			var finalArray = [];
			$.each(array, function (i, el) {
				if ($.inArray(el, uniqueValues) === -1) {
					uniqueValues.push(el);
				}
			});

			$.each(uniqueValues, function (j, val) {
				var sObj = {};
				sObj["" + field + ""] = val;
				finalArray.push(sObj);
			});

			return finalArray;
		},

		onIconTabBarSelect: function (oEvent) {
			var that = this;
			var oSelectedKey = oEvent.getSource().getSelectedKey();
			if (oSelectedKey === "activeBumpEmployeeList") {
				// this.byId("saveBtn").setVisible(true);
				that.byId("submitBtn").setVisible(true);
				that.byId("cancelBtn").setVisible(true);

				this.onRefresh();
			} else if (oSelectedKey === "createBump") {
				// this.byId("saveBtn").setVisible(false);
				if (this.craftUnion === "E" || this.craftUnion === "SE") {
					this.getView().byId("endTimeId").setValue("11:59");
				}
				that.byId("submitBtn").setVisible(true);
				that.byId("cancelBtn").setVisible(true);
			} else if (oSelectedKey === "bumpList") {
				that.byId("depIdSelect").fireChange(that.byId("depIdSelect").getSelectedItem());
				that.byId("submitBtn").setVisible(false);
				that.byId("cancelBtn").setVisible(false);

			}

		},

		onSubmit: function () {
			var that = this;
			var oSelectedKey = that.byId("bumpMaintIconTabId").getSelectedKey();
			if (oSelectedKey === "createBump") {
				var formErrorFlag = false;
				var formContent = that.byId("createBumpEligFormId").getContent();
				for (var f = 0; f < formContent.length; f++) {
					var oElement = formContent[f].getMetadata().getElementName();
					if ((oElement === "sap.m.Input") || (oElement === "sap.m.ComboBox") || (oElement === "sap.m.DatePicker") || (oElement ===
							"sap.m.TimePicker")) {

						if ((formContent[f].getRequired() === true) && (formContent[f]
								.getValue().trim().length < 1)) {
							formErrorFlag = true;
							formContent[f].setValueState("Error");
						}
					}
				}

				if (formErrorFlag) {
					sap.m.MessageToast.show("Please fill all the mandatory fields");
				} else {
					var oEntry = {};
					oEntry.EmpId = that.byId("empId").getValue();
					oEntry.EmpName = that.byId("empTextId").getText();
					oEntry.BumpSdate = that.byId("effDateId").getValue();
					oEntry.BumpEdate = that.byId("endDateId").getValue();
					oEntry.BumpStime = that.byId("effTimeId").getValue().split(":").join("");
					oEntry.BumpEtime = that.byId("endTimeId").getValue().split(":").join("");
					oEntry.ReasonCode = that.byId("reasonCodeId").getValue();
					oEntry.ReasonDesc = that.byId("splScnId").getValue();

					var oModel = that.getOwnerComponent().getModel();

					var oPage = this.byId("oBumpMaintPageId");
					oPage.setBusy(true);
					oPage.setBusyIndicatorDelay(0);
					oModel.create("/BumpDataSet", oEntry, {
						success: function (oData, oResponse) {
							oPage.setBusy(false);
							var message = oResponse.headers;
							if (message !== undefined) {
								var xml = message["sap-message"];
								$($.parseXML(xml)).find("message").each(function (a, b) {
									if (b.innerHTML !== "") {
										var text = $(b).text();

										sap.m.MessageBox.show(text, {
											icon: sap.m.MessageBox.Icon.INFORMATION,
											title: "Information",
											actions: [sap.m.MessageBox.Action.OK],
											onClose: function (sAction) {}
										});
										that.onClearCreateForm();

									}
								});
							}
						},
						error: function (error) {
							oPage.setBusy(false);
							var rrorDetails = JSON.parse(error.responseText).error.innererror.errordetails;
							var oMessage = false;
							var errmsg;
							for (var x = 0; x < rrorDetails.length; x++) {
								var msg = rrorDetails[x].message;
								if (!(msg.includes("without specific error"))) {
									oMessage = true;
									errmsg = msg;
								}

							}

							if (oMessage) {
								sap.m.MessageBox.show(errmsg, {
									icon: sap.m.MessageBox.Icon.SUCCESS,
									title: "Information",
									actions: [sap.m.MessageBox.Action.OK],
									onClose: function (sAction) {}
								});
								that.onClearCreateForm();
							}

						}
					});
				}
			} else if (oSelectedKey === "activeBumpEmployeeList") {

				sap.m.MessageBox.confirm("Are you sure you want to proceed with the update?", {
					title: "Confirm",
					actions: [sap.m.MessageBox.Action.YES, sap.m.MessageBox.Action.NO],
					onClose: function (oAction) {
						if (oAction === "YES") {
							that.stopBumpEligibleFunc();
						} else {
							that.onRefresh();
						}
					}
				});

			}

		},

		stopBumpEligibleFunc: function (oEvent) {
			var that = this;
			var oTable = that.byId("bumpTableId");
			var oItems = oTable.getItems();
			// var bumpFlagSelect = false;
			that.stopBumpArray = [];
			for (var i = 0; i < oItems.length; i++) {
				var oPath = oItems[i].getBindingContextPath();
				var oContext = oTable.getModel().getProperty(oPath);
				// if (oItems[i].getCells()[0].getSelected() === true) {
				// 	that.stopBumpArray.push(oContext);
				// }
				if (oItems[i].getCells()[0].getItems()[0].getSelected() === true) {
					that.stopBumpArray.push(oContext);
				}
			}

			if (that.stopBumpArray.length < 1) {
				sap.m.MessageToast.show("Please select atleast one record from the table");
			} else {
				sap.m.MessageToast.show("You have selected " + that.stopBumpArray.length + " records");
				that.submitManualStopFunc(that.stopBumpArray);
			}
		},

		submitManualStopFunc: function (bumpStopArray) {
			var that = this;
			var oEntry = {
				BumpId: "1"
			};

			// for (var i = 0; i < bumpStopArray.length; i++) {
			// 	var oContext = bumpStopArray[i];
			// 	oContext.BumpTrigger = "";
			// 	oContext.BumpStop = "X";
			// }
			oEntry.BumpDataNav = bumpStopArray;

			var oModel = that.getOwnerComponent().getModel("oDataSrv");
			var oPage = that.byId("oBumpMaintPageId");
			oPage.setBusy(true);
			oPage.setBusyIndicatorDelay(0);

			oModel.create("/BumpHeaderSet()", oEntry, {
				async: true,
				success: function (res) {
					sap.m.MessageToast.show("success");
					oPage.setBusy(false);
					that.onRefresh();
				},
				error: function (err, response) {
					oPage.setBusy(false);
					that.onRefresh();
					var rrorDetails = JSON.parse(err.response.body).error.innererror.errordetails;
					// var oMessage = false;
					var errmsg;
					for (var x = 0; x < rrorDetails.length; x++) {
						var msg = rrorDetails[x].message;
						if (!(msg.includes("without specific error"))) {
							// oMessage = true;
							errmsg = msg;
						}

					}
					sap.m.MessageBox.information(errmsg);

				}
			});

		},

		onEmpF4Help: function (oEvent) {
			var that = this;
			that.id = oEvent.getSource().getId();
			if (!that._empNoValueDialog) {
				that._empNoValueDialog = sap.ui.xmlfragment("bumpmaint.zbump_maintenance.fragments.EmpId", that.getView()
					.getController());
				that.getView().addDependent(that._empNoValueDialog);
			}
			that._empNoValueDialog.open();
			sap.ui.getCore().byId("empIdSearch").setValue(oEvent.getSource().getValue());
			sap.ui.getCore().byId("empIdSearch").fireSearch();

		},

		onEmpNoSearch: function (oEvent) {
			var oVal = oEvent.getSource().getValue().trim();
			if (oVal.length > 0) {
				this.onEmpData();
			} else {
				var jsonModel = new sap.ui.model.json.JSONModel({});
				var empNoTable = sap.ui.getCore().byId("empIdTable");
				empNoTable.setModel(jsonModel, "empNoModel");
			}
		},

		onEmpData: function () {
			var that = this;
			var oModel = that.getOwnerComponent().getModel();
			var dialog = new sap.m.BusyDialog({});
			dialog.open();
			// var craftVal = that.byId("craftId").getValue();
			var craftVal = that.byId("depIdSelect").getSelectedKey();
			var union;
			if (craftVal === "SM" || craftVal === "M") {
				union = "M";
			} else if (craftVal === "SE" || craftVal === "E") {
				union = "E";
			} else if (craftVal === "ST" || craftVal === "T") {
				union = "T";
			} else if (craftVal === "SA" || craftVal === "A" || craftVal === "D" || craftVal === "SD") {
				union = "D";
			} else {
				union = "A";
			}
			var empVal = sap.ui.getCore().byId("empIdSearch").getValue();
			var craftQueryFil = [];
			var empNo = new sap.ui.model.Filter("EmpId", "EQ", empVal);
			// var craft = new sap.ui.model.Filter("Craft", "EQ", "T");
			var craft = new sap.ui.model.Filter("Craft", "EQ", union);
			craftQueryFil.push(empNo);
			craftQueryFil.push(craft);
			oModel.read("/EmpSearchHelpSet", {
				filters: craftQueryFil,
				success: function (oData, oResponse) {
					dialog.close();
					that.empDataFlag = true;
					var jsonModel = new sap.ui.model.json.JSONModel(oData);
					var empNoTable = sap.ui.getCore().byId("empIdTable");
					empNoTable.setModel(jsonModel, "empNoModel");
				},
				error: function (oErr) {
					dialog.close();
					that.empDataFlag = false;
					var msg = JSON.parse(oErr.response.body).error.message.value;
					sap.m.MessageBox.show(
						msg, {
							icon: sap.m.MessageBox.Icon.INFORMATION,
							title: "Log",
							actions: [sap.m.MessageBox.Action.OK],
							onClose: function (oAction) {
								if (oAction === sap.m.MessageBox.Action.OK) {

								}
							}
						});

				}
			});
		},

		onEmpNoSubmit: function (oEvent) {
			var that = this;
			var pPath = oEvent.getSource().getBindingContextPath();
			var empNoContexts = sap.ui.getCore().byId("empIdTable").getModel("empNoModel").getProperty(pPath);
			var empNo = empNoContexts.EmpId;
			var empDesc = empNoContexts.EmpName;
			this.posId = empNoContexts.PosId;
			this.PosDesc = empNoContexts.PosDesc;
			var oSelectedKey = that.byId("bumpMaintIconTabId").getSelectedKey();
			var craftVal = that.byId("depIdSelect").getSelectedKey();
			var union;
			if (craftVal === "SM" || craftVal === "M") {
				union = "M";
			} else if (craftVal === "SE" || craftVal === "E") {
				union = "E";
			} else if (craftVal === "ST" || craftVal === "T") {
				union = "T";
			} else if (craftVal === "SA" || craftVal === "A" || craftVal === "D" || craftVal === "SD") {
				union = "D";
			} else {
				union = "E";
			}
			if (oSelectedKey === "createBump") {
				that.byId(that.id).setValue(empNo);
				that.byId("posId").setValue(this.posId);
				that.byId("empTextId").setText(empDesc);
				that.byId("posTextId").setText(this.PosDesc);
				that._empNoValueDialog.close();
			} else if (oSelectedKey === "bumpList") {
				that.byId(that.id).setValue(empNo);
				that._empNoValueDialog.close();
				var oTable = this.byId("bumpList");
				this.onGetCallFunc(union, oTable, empNo);
			} else {
				that.byId(that.id).setValue(empNo);
				that._empNoValueDialog.close();
			}
		},

		onEmpNoCancel: function () {
			var that = this;
			var oSelectedKey = that.byId("bumpMaintIconTabId").getSelectedKey();
			if (oSelectedKey === "createBump") {
				that._empNoValueDialog.close();
				that.byId(that.id).setValue();
				that.byId("posId").setValue();
				that.byId("empTextId").setText();
				that.byId("posTextId").setText();
			} else {
				that.byId(that.id).setValue();
				that._empNoValueDialog.close();
			}
		},

		onCancel: function () {
			var that = this;
			var oSelectedKey = that.byId("bumpMaintIconTabId").getSelectedKey();

			if (oSelectedKey === "createBump") {
				sap.m.MessageBox.confirm("Do you want to cancel the data?", {
					title: "Confirm",
					actions: [sap.m.MessageBox.Action.YES, sap.m.MessageBox.Action.NO],
					onClose: function (oAction) {
						if (oAction === sap.m.MessageBox.Action.YES) {
							var formContent = that.byId("createBumpEligFormId").getContent();
							for (var f = 0; f < formContent.length; f++) {
								var oElement = formContent[f].getMetadata().getElementName();
								if ((oElement === "sap.m.Input") || (oElement === "sap.m.ComboBox") || (oElement === "sap.m.DatePicker") || (oElement ===
										"sap.m.TimePicker")) {
									formContent[f].setValue();
									formContent[f].setValueState("None");

								}
							}
							that.byId("empTextId").setText();
							that.byId("posTextId").setText();
							that.byId("splScnId").setValue();
							that.byId("splScnId").setEnabled(false);
							that.byId("splScnId").setRequired(false);
							that.byId("reasonCodeId").setValue();
							that.byId("reasonCodeId").clearSelection();

						}
					}
				});
			} else {
				// if (that.stopBumpArray.length > 0) {
				sap.m.MessageBox.warning("Selection will be lost! \n Are you sure you want to cancel?", {
					title: "Warning",
					actions: [sap.m.MessageBox.Action.YES, sap.m.MessageBox.Action.NO],
					onClose: function (oAction) {
						if (oAction === sap.m.MessageBox.Action.YES) {
							that.onRefresh();
						}
					}
				});
			}
			// }

		},

		onClearCreateForm: function () {
			var that = this;
			var formContent = that.byId("createBumpEligFormId").getContent();
			for (var f = 0; f < formContent.length; f++) {
				var oElement = formContent[f].getMetadata().getElementName();
				if ((oElement === "sap.m.Input") || (oElement === "sap.m.ComboBox") || (oElement === "sap.m.DatePicker") || (oElement ===
						"sap.m.TimePicker")) {
					formContent[f].setValue();
					formContent[f].setValueState("None");

				}
			}
			that.byId("empTextId").setText();
			that.byId("posTextId").setText();
			that.byId("splScnId").setValue();
			that.byId("splScnId").setEnabled(false);
			that.byId("splScnId").setRequired(false);
			that.byId("reasonCodeId").setValue();
			that.byId("reasonCodeId").clearSelection();
		},

		onReasonChange: function (oEvent) {
			var oReason = oEvent.getSource().getValue();
			if (oReason === "Special Scenarios") {
				this.byId("splScnId").setRequired(true);
				this.byId("splScnId").setEnabled(true);
			} else {
				this.byId("splScnId").setRequired(false);
				this.byId("splScnId").setEnabled(false);
				this.byId("splScnId").setValueState("None");
				this.byId("splScnId").setValue();
			}
		},

		splScnChange: function (oEvent) {
			var oSplVal = oEvent.getSource().getValue().trim();
			if (oSplVal.length > 0) {
				oEvent.getSource().setValueState("None");
			}
		},

		onLoadItemsFinished: function (oEvent) {
			var that = this;
			var oTable = that.byId("bumpTableId");
			var oItems = oTable.getItems();
			for (var i = 0; i < oItems.length; i++) {
				var oPath = oItems[i].getBindingContextPath();
				var oContext = oTable.getModel().getProperty(oPath);
				var bumpStop = oContext.BumpStop;
				var bumpTrigger = oContext.BumpTrigger;
				if ((bumpStop === "Yes") || (bumpTrigger === "Yes")) {
					oItems[i].getCells()[0].getItems()[0].setEditable(false);
					oItems[i].getCells()[0].getItems()[0].setSelected(false);
					oItems[i].getCells()[0].getItems()[0].addStyleClass("cbCustom");
					// oItems[i].getCells()[0].setEditable(false);
					// oItems[i].getCells()[0].setSelected(false);
					// oItems[i].getCells()[0].addStyleClass("cbCustom");
				} else {
					oItems[i].getCells()[0].getItems()[0].setEditable(true);
					oItems[i].getCells()[0].getItems()[0].setSelected(false);
					oItems[i].getCells()[0].getItems()[0].removeStyleClass("cbCustom");
					// oItems[i].getCells()[0].setEditable(true);
					// oItems[i].getCells()[0].setSelected(false);
					// oItems[i].getCells()[0].removeStyleClass("cbCustom");
				}
			}
		},

		onClick: function (oID) {
			var that = this;
			$('#' + oID).click(function (oEvent) {
				// var columnName = sap.ui.getCore().byId(oID).mAggregations.header.mProperties.text;
				var columnName = sap.ui.getCore().byId(oID).getAggregation("header").getProperty("text");
				sap.ui.getCore().byId("oFilterInputId").setType("Text");
				switch (columnName) {
				case "Bump ID":
					that.filColumn = "BumpId";
					sap.ui.getCore().byId("oFilterInputId");
					sap.ui.getCore().byId("oFilterInputId").setPlaceholder("Enter Bump ID");
					var oTarget = oEvent.currentTarget; //Get hold of Header Element
					var oLabelText = oTarget.childNodes[0].textContent; //Get Column Header text
					var oIndex = oTarget.id.slice(-1); //Get the column Index
					var oView = that.getView();
					var oTable = oView.byId("bumpTableId");
					that._oResponsivePopover.srcColumn = columnName;
					that._oResponsivePopover.openBy(oTarget);
					break;
				case "Employee ID":
					that.filColumn = "EmpId";
					sap.ui.getCore().byId("oFilterInputId");
					sap.ui.getCore().byId("oFilterInputId").setPlaceholder("Enter Employee ID");
					var oTarget1 = oEvent.currentTarget; //Get hold of Header Element
					var oLabelText1 = oTarget1.childNodes[0].textContent; //Get Column Header text
					oTarget1.id.slice(-1); //Get the column Index
					that._oResponsivePopover.srcColumn = columnName;
					that._oResponsivePopover.openBy(oTarget1);
					break;
				case "Employee Name":
					that.filColumn = "EmpName";
					sap.ui.getCore().byId("oFilterInputId");
					sap.ui.getCore().byId("oFilterInputId").setPlaceholder("Enter Employee Name");
					var oTarget2 = oEvent.currentTarget; //Get hold of Header Element
					var oLabelText2 = oTarget2.childNodes[0].textContent; //Get Column Header text
					oTarget2.id.slice(-1); //Get the column Index
					that._oResponsivePopover.srcColumn = columnName;
					that._oResponsivePopover.openBy(oTarget2);
					break;
				case "Reason Code":
					that.filColumn = "ReasonCode";
					sap.ui.getCore().byId("oFilterInputId");
					sap.ui.getCore().byId("oFilterInputId").setPlaceholder("Enter Reason Code");
					var oTarget3 = oEvent.currentTarget; //Get hold of Header Element
					var oLabelText3 = oTarget3.childNodes[0].textContent; //Get Column Header text
					oTarget3.id.slice(-1); //Get the column Index
					that._oResponsivePopover.srcColumn = columnName;
					that._oResponsivePopover.openBy(oTarget3);
					break;
				case "RR Hired":
					that.filColumn = "RRHired";
					sap.ui.getCore().byId("oFilterInputId");
					sap.ui.getCore().byId("oFilterInputId").setPlaceholder("Enter RR Hired ");
					var oTarget4 = oEvent.currentTarget; //Get hold of Header Element
					oTarget4.id.slice(-1); //Get the column Index
					that._oResponsivePopover.srcColumn = columnName;
					that._oResponsivePopover.openBy(oTarget4);
					break;
				case "Rest Days":
					that.filColumn = "RestDays";
					sap.ui.getCore().byId("oFilterInputId");
					sap.ui.getCore().byId("oFilterInputId").setPlaceholder("Enter Rest Days");
					var oTarget5 = oEvent.currentTarget; //Get hold of Header Element
					oTarget5.id.slice(-1); //Get the column Index
					that._oResponsivePopover.srcColumn = columnName;
					that._oResponsivePopover.openBy(oTarget5);
					break;
				case "Department":
					that.filColumn = "Department";
					sap.ui.getCore().byId("oFilterInputId");
					sap.ui.getCore().byId("oFilterInputId").setPlaceholder("Enter Department ");
					var oTarget6 = oEvent.currentTarget; //Get hold of Header Element
					oTarget6.id.slice(-1); //Get the column Index
					that._oResponsivePopover.srcColumn = columnName;
					that._oResponsivePopover.openBy(oTarget6);
					break;
				case "Desk":
					that.filColumn = "Desk";
					sap.ui.getCore().byId("oFilterInputId");
					sap.ui.getCore().byId("oFilterInputId").setPlaceholder("Enter Department ");
					var oTarget7 = oEvent.currentTarget; //Get hold of Header Element
					oTarget7.id.slice(-1); //Get the column Index
					that._oResponsivePopover.srcColumn = columnName;
					that._oResponsivePopover.openBy(oTarget7);
					break;
				default:
					sap.ui.getCore().byId("oFilterInputId").setPlaceholder("Enter Text");
				}
			});
		},

		onChange: function (oEvent) {
			var that = this;
			var oValue = oEvent.getParameter("value");
			if (oValue.length < 1) {
				that._oResponsivePopover.close();
				oEvent.getSource().setValueState("None");
				return;
			}
			var oMultipleValues = oValue.split(",");
			var columnName = that.filColumn;
			switch (columnName) {
			case "BumpId":
				var aFil = [];
				if (oValue.length > 0) {
					for (var i = 0; i < oMultipleValues.length; i++) {
						var oVal = Number(oMultipleValues[i]);
						var oFilter = new sap.ui.model.Filter("BumpId", "EQ", oVal);
						aFil.push(oFilter);
						var Fin = new sap.ui.model.Filter({
							filters: aFil,
							and: false
						});
						that.aFilters.push(Fin);
					}
					oEvent.getSource().setValueState("None");
				} else {
					oEvent.getSource().setValueState("Error");
				}
				break;
			case "EmpId":

				if (oValue.length > 0) {
					for (var j = 0; j < oMultipleValues.length; j++) {
						var oVal1 = oMultipleValues[j];

						var oFilter1 = new sap.ui.model.Filter("EmpId", "Contains", oVal1);
						that.aFilters.push(oFilter1);
					}
					oEvent.getSource().setValueState("None");
				} else {
					oEvent.getSource().setValueState("Error");
				}
				break;
			case "EmpName":

				if (oValue.length > 0) {
					for (var k = 0; k < oMultipleValues.length; k++) {
						var oVal2 = oMultipleValues[k];

						var oFilter2 = new sap.ui.model.Filter("EmpName", "Contains", oVal2);
						that.aFilters.push(oFilter2);
					}
					oEvent.getSource().setValueState("None");
				} else {
					oEvent.getSource().setValueState("Error");
				}
				break;
			case "ReasonCode":

				if (oValue.length > 0) {
					for (var l = 0; l < oMultipleValues.length; l++) {
						var oVal3 = oMultipleValues[l];

						var oFilter3 = new sap.ui.model.Filter("ReasonCode", "Contains", oVal3);
						that.aFilters.push(oFilter3);
					}
					oEvent.getSource().setValueState("None");
				} else {
					oEvent.getSource().setValueState("Error");
				}
				break;
			case "RRHired":
				if (oValue.length > 0) {
					for (var m = 0; m < oMultipleValues.length; m++) {
						var oVal4 = oMultipleValues[m];
						var oFilter4 = new sap.ui.model.Filter("RRHired", "Contains", oVal4);
						that.aFilters.push(oFilter4);
					}
					oEvent.getSource().setValueState("None");
				} else {
					oEvent.getSource().setValueState("Error");
				}
				break;
			case "RestDays":
				if (oValue.length > 0) {
					for (var n = 0; n < oMultipleValues.length; n++) {
						var oVal5 = oMultipleValues[n];
						var oFilter5 = new sap.ui.model.Filter("Restdays", "Contains", oVal5);
						that.aFilters.pushn(oFilter5);
					}
					oEvent.getSource().setValueState("None");
				} else {
					oEvent.getSource().setValueState("Error");
				}
				break;
			case "Department":
				if (oValue.length > 0) {
					for (var o = 0; o < oMultipleValues.length; o++) {
						var oVal6 = oMultipleValues[o];
						var oFilter6 = new sap.ui.model.Filter("Department", "Contains", oVal6);
						that.aFilters.pushn(oFilter6);
					}
					oEvent.getSource().setValueState("None");
				} else {
					oEvent.getSource().setValueState("Error");
				}
				break;
			case "Desk":
				if (oValue.length > 0) {
					for (var p = 0; p < oMultipleValues.length; p++) {
						var oVal7 = oMultipleValues[p];
						var oFilter7 = new sap.ui.model.Filter("DeskNumber", "Contains", oVal7);
						that.aFilters.pushn(oFilter7);
					}
					oEvent.getSource().setValueState("None");
				} else {
					oEvent.getSource().setValueState("Error");
				}
				break;
			default:
			}
			if (oEvent.getSource().getValueState() !== "Error") {
				var oFilters = new sap.ui.model.Filter({
					filters: that.aFilters,
					and: true
				});
				var oItems = that.getView().byId("bumpTableId").getBinding("items");
				oItems.filter(oFilters);
				sap.ui.getCore().byId("oFilterInputId").setValue();
				this._oResponsivePopover.close();
			}

		},

		onAscending: function () {
			var that = this;
			var oTable = that.byId("bumpTableId");
			var sItems = oTable.getBinding("items");
			var sSorter = new sap.ui.model.Sorter("" + that.filColumn + "", false);
			sItems.sort(sSorter);
			oTable.getModel().refresh();
			that._oResponsivePopover.close();
			// that.onLoadItemsFinished();

		},

		onDescending: function () {
			var that = this;
			var oTable = that.byId("bumpTableId");
			var sItems = oTable.getBinding("items");
			var sSorter = new sap.ui.model.Sorter("" + that.filColumn + "", true);
			sItems.sort(sSorter);
			oTable.getModel().refresh();
			that._oResponsivePopover.close();
			// that.onLoadItemsFinished();
		},

		onRefresh: function (oEvent) {
			var that = this;
			// that.byId("bumpTableId").unbindItems();
			that.activeEligTableBindFunc(this.craftUnion);
			that.byId("bumpTableId").getModel().refresh();
			that.onLoadItemsFinished();
			var oSelectedKey = that.byId("bumpMaintIconTabId").getSelectedKey();
			if (oSelectedKey === "bumpList") {
				/*var oTable = this.byId("atdaTableId");
				that.onGetCallFunc("A", oTable);*/

			}
		},

		dateTimeFormatFunc: function (date) {
			if (date !== null) {
				var oDate = date.slice("0", "8");
				var oTime;
				if (date.slice("8").includes(":")) {
					oTime = date.slice("8").split(":").join("").trim();
				} else {
					oTime = date.slice("8");
				}
				var mTime;
				if (oTime.length === 6) {
					mTime = oTime.slice("0", "2") + ":" + oTime.slice("2", "4") + ":" + oTime.slice("4");
				} else if (oTime.length === 4) {
					mTime = oTime.slice("0", "2") + ":" + oTime.slice("2", "4") + ":" + "00";
				} else if (oTime.length === 2) {
					mTime = oTime.slice("2", "0") + ":" + "00" + ":" + "00";
				} else if (oTime.length === 0) {
					mTime = "00" + ":" + "00" + ":" + "00";
				}

				var mDate = oDate.slice("4", "6") + "-" + oDate.slice("6") + "-" + oDate.slice("0", "4");
				// var mTime = oTime.slice("0", "2") + ":" + oTime.slice("2", "2") + ":" + oTime.slice("4");
				var mDateTime = mDate + ", " + mTime;

				return mDateTime;
			}
		},

		onDateFormat: function (oVal) {
			if (oVal) {
				var year = oVal.slice("0", "4");
				var month = oVal.slice("4").slice("0", "2");
				var day = oVal.slice("6");
				var date = month + "/" + day + "/" + year;
				return date;
			}
		},

		onTCU_ATDA_BumpPress: function () {
			this.getRouter().navTo("TCUATDAForm");
		},
		/*onMechBumpPress: function () {
			this.getRouter().navTo("MechForm");
		}*/
		onMechBumpPress: function (oEvent) {
			/*this.getRouter().navTo("MechForm");*/
			var oPath = oEvent.getSource().getParent().getBindingContextPath();
			// var oContext = oEvent.getSource().getParent().getParent().getModel().getProperty(oPath);
			var oContext = oEvent.getSource().getModel("bumpListModel").getProperty(oPath);
			var userEmpId = oContext.UserEmpId;
			var empId = oContext.EmpId;
			var empName = oContext.EmpName;
			var posId = oContext.PosId;
			var senDate = oContext.SenDate;
			var posDesc = oContext.PosDesc;

			// var ebtFlag = oContext.EbtFlag;
			// var ebtDate = oContext.EbtDate;
			var shiftTimings = oContext.ShiftTiming;
			var splitTimings = shiftTimings.split("-");
			var stTimings = splitTimings[0].slice("0", "2") + ":" + splitTimings[0].slice("2").slice("0", "2") + ":" + splitTimings[0].slice(
				"4");
			var endTimings = splitTimings[1].slice("0", "2") + ":" + splitTimings[1].slice("2").slice("0", "2") + ":" + splitTimings[1].slice(
				"4");
			var sTimings = stTimings + " " + "-" + " " + endTimings;
			var rDays = oContext.RestDays;
			var dept = oContext.DeptName;
			var union = oContext.Union;
			var roster = oContext.RosterNo;

			var oSelectedKey = this.byId("depIdSelect").getSelectedKey();
			var mModel = this.getOwnerComponent().getModel("oDataSrv");
			var aMes = "Please find \n Hello";
			var oPos;
			var oStartDate;
			var bData = "";
			mModel.read("/BumpTransDataSet(EmployeeID='" + empId + "',Craft='" + oSelectedKey + "')", {
				async: false,
				success: function (oData) {
					oPos = oData.PositionID;
					oStartDate = oData.StartDate;
					bData = oData;
				},
				error: function () {

				}
			});
			this.sData = bData;
			var sDate = oStartDate.slice("4").slice("0", "2") + "/" + oStartDate.slice("6") + "/" + oStartDate.slice("0", "4");
			senDate = senDate.slice("4").slice("0", "2") + "/" + senDate.slice("6") + "/" + senDate.slice("0", "4");
			var a = new Date();
			var thDate = new Date((a.getTime() + 129600000));
			var effDate = thDate.toLocaleDateString();
			if (effDate.split("/")[0].length < 2) {
				effDate = "0" + effDate;
			}
			if (effDate.split("/")[1].length < 2) {
				effDate = "0" + effDate;
			}
			var efftime = thDate.toLocaleTimeString();

			if (oSelectedKey === "M" || oSelectedKey === "SM") {
				if (!this._oPopover) {
					this._oPopover = sap.ui.xmlfragment("bumpmaint.zbump_maintenance.fragments.MechBump", this);
					this.getView().addDependent(this._oPopover);

					// this._oPopover.bindElement("/ProductCollection/0");
				}
				// this.sData.EmpName = empName;
				this.sData.PositionID = posId;
				this.sData.EmployeeID = empId;
				this.sData.Department = dept;
				this.sData.Shift = shiftTimings;
				this.sData.Rdays = rDays;
				this.sData.Union = union;
				// this.sData.RosterNo = roster;
				// var oMechFormData = {
				// 	results: [this.sData]
				// };
				// var oMechFormModel = new sap.ui.model.json.JSONModel(oMechFormData);
				// this._oPopover.setModel(oMechFormModel);
				// this._oPopover.bindElement("/results/0");
				// this._oPopover.getModel().refresh();
				sap.ui.getCore().byId("mechMsgId").setText("Union Affiliation  " + union + "   Seniority District" +
					this.sData.SenDist + ". \n\n Employee  " + empName + "  Roster No.   " + roster + "   EIN# " + userEmpId + "." +
					"\n\n You are hereby notified that effective with the close of your tour duty on  " + effDate + "\n\n  that your position  " +
					this.posId + " - " + this.PosDesc + "  in department  " + dept + "   /  " + empName + "\n\n  on  " + sTimings +
					"  with  " +
					rDays + "  rest days has been claimed by senior employee  " + empName + ". \n\n  Roster#  " + "  " + roster +
					"  EIN#  " + empId + ".");

				this._oPopover.open();
			} else if (oSelectedKey === "T" || oSelectedKey === "ST" || oSelectedKey === "D" || oSelectedKey === "SD") {
				if (!this._oPopover1) {
					this._oPopover1 = sap.ui.xmlfragment("bumpmaint.zbump_maintenance.fragments.TCUATDA", this);
					this.getView().addDependent(this._oPopover1);

					// this._oPopover.bindElement("/ProductCollection/0");
				}
				sap.ui.getCore().byId("mesgId").setText("I " + this.name + ",\n\nDue to the change to my cuurent Position ID: " +
					//this.byId("posId").getValue() + " - " + this.byId("posTextId").getText() +
					this.posId + " - " + this.PosDesc + " " +
					"effective " + effDate + " at " + efftime + ".\n" +
					"\nDue to the above reason I am displacing " + empName +
					" from positon ID: " + posId + "-" + posDesc + " Central division effective from " + sDate + "." +
					"           " + "     \n\n My Seniority Date is " + senDate + ".");
				this._oPopover1.open();
			}

		},

		oncCancel: function () {
			var oSelectedKey = this.byId("depIdSelect").getSelectedKey();
			if (oSelectedKey === "M" || oSelectedKey === "SM") {
				this._oPopover.close();
			} else if (oSelectedKey === "T" || oSelectedKey === "ST" || oSelectedKey === "D" || oSelectedKey === "SD") {
				this._oPopover1.close();
			}
		},

		/*onBumpListLive: function (oEvent) {
			var oVal = oEvent.getSource().getValue();
			var oTable = this.byId("atdaTableId");
			if (oVal.trim().length > 0) {
				var oFilter = new sap.ui.model.Filter("EmpId", "Contains",
					oVal);
				var oTableBindings = oTable.getBinding("items");
				oTableBindings.filter([oFilter]);
			} else {
				this.onGetCallFunc("A", oTable);
			}
		},*/

		onConfirm: function () {
			var that = this;
			var oSelectedKey = that.byId("depIdSelect").getSelectedKey();
			// sap.m.MessageToast.show("Success");
			var oData = that.sData;
			oData.Bumptriggger = "X";
			oData.Craft = oSelectedKey;
			var mModel = that.getOwnerComponent().getModel("oDataSrv");
			mModel.create("/BumpTransDataSet", oData, {
				async: false,
				success: function (succ) {
					if (oSelectedKey === "M" || oSelectedKey === "SM") {
						that._oPopover.close();
					} else if (oSelectedKey === "T" || oSelectedKey === "ST" || oSelectedKey === "D" || oSelectedKey === "SD") {
						that._oPopover1.close();
					}
				},
				error: function (err) {
					var messageLen = JSON.parse(err.response.body).error.innererror.errordetails;
					var msg = "";
					for (var i = 0; i < messageLen.length; i++) {
						if (!messageLen[i].message.includes("without specific error")) {
							msg = messageLen[i].message;
						}
					}
					if (messageLen.length === 0) {
						msg = JSON.parse(err.response.body).error.message.value;
					}
					sap.m.MessageBox.success(msg);
					if (oSelectedKey === "M" || oSelectedKey === "SM") {
						that._oPopover.close();
					} else if (oSelectedKey === "T" || oSelectedKey === "ST" || oSelectedKey === "D" || oSelectedKey === "SD") {
						that._oPopover1.close();
					}
				}
			});
		},

		onShiftFormat: function (oVal) {
			if ((oVal !== "000000") && (oVal !== null)) {
				var oValSplit = oVal.split("-");

				var hh = oValSplit[0].slice("0", "2");
				var mm = oValSplit[0].slice("4").slice("0", "2");
				var ss = oValSplit[0].slice("4");
				var date = hh + ":" + mm;

				var hh1 = oValSplit[1].slice("0", "2");
				var mm1 = oValSplit[1].slice("4").slice("0", "2");
				var ss1 = oValSplit[1].slice("4");
				var date1 = hh1 + ":" + mm1;

				var sTimings = date + " " + "-" + " " + date1;

				return sTimings;
			} else {
				return "00:00:00 - 00:00";
			}
		},
		onBumpedStoppedConfirm: function () {
			var oModel = this.getView().byId("bumpTableId").getModel();
			var comments = sap.ui.getCore().byId("bumpStoppedComments").getValue();
			if (comments.trim() === "") {
				sap.ui.getCore().byId("bumpStoppedComments").setValueState("Error");
				sap.m.MessageToast.show("Please add some comments");
			} else {
				sap.ui.getCore().byId("bumpStoppedComments").setValueState("None");
				oModel.setProperty(this.path + "/BumpStop", "X");
				oModel.setProperty(this.path + "/Comments", comments);
				sap.m.MessageToast.show("Comments Saved Successfully");
				this.bumpStoppedDialog.close();
				// oModel.refresh();
			}

		},
		onBumpStoppedCancel: function () {
			this.bumpStoppedDialog.close();
			sap.ui.getCore().byId("bumpStoppedComments").setValueState("None");
			sap.ui.getCore().byId("bumpStoppedComments").setValue("");
		},
		onCheckSelect: function (oEvent) {
			if (oEvent.getSource().getSelected()) {
				this.openBumpCommentsDialog(oEvent);
			} else {
				var oModel = this.getView().byId("bumpTableId").getModel();
				oModel.setProperty(this.path + "/BumpStop", "");
				oModel.setProperty(this.path + "/Comments", "");
			}
		},
		onBumpCommentsPress: function (oEvent) {
			this.openBumpCommentsDialog(oEvent);
		},
		openBumpCommentsDialog: function (oEvent) {
			var that = this;
			var sPath = oEvent.getSource().getBindingContext().getPath();
			this.path = sPath;
			var oModel = oEvent.getSource().getModel();
			var comments = oModel.getProperty(sPath).Comments;
			if (!that.bumpStoppedDialog) {
				that.bumpStoppedDialog = sap.ui.xmlfragment("bumpmaint.zbump_maintenance.fragments.BumpStoppedComments", that.getView()
					.getController());
				that.getView().addDependent(that.bumpStoppedDialog);
			}
			that.bumpStoppedDialog.open();
			sap.ui.getCore().byId("bumpStoppedComments").setValue(comments);
		}
	});
});