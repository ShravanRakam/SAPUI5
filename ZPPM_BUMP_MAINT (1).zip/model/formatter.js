sap.ui.define([], function () {
	"use strict";
	return {
		numberUnit: function (n) {
			if (!n) {
				return ""
			}
			return parseFloat(n).toFixed(2)
		},
		dateTimeFormat: function (date) {
			if (date !== null && date !== "00000000000000" && date !== "" && date !== " " && date !== undefined) {
				var oDate = date.slice("0", "8");
				var oTime;
				if (date.slice("8").includes(":")) {
					oTime = date.slice("8").split(":").join("").trim();
				} else {
					oTime = date.slice("8");
				}
				var mTime;
				if (oTime.length === 6) {
					mTime = oTime.slice("0", "2") + ":" + oTime.slice("2", "4");
				} else if (oTime.length === 4) {
					mTime = oTime.slice("0", "2") + ":" + oTime.slice("2", "4");
				} else if (oTime.length === 2) {
					mTime = oTime.slice("2", "0") + ":" + "00";
				} else if (oTime.length === 0) {
					mTime = "00" + ":" + "00";
				}

				var mDate = oDate.slice("4", "6") + "/" + oDate.slice("6") + "/" + oDate.slice("0", "4");
				// var mTime = oTime.slice("0", "2") + ":" + oTime.slice("2", "2") + ":" + oTime.slice("4");
				var mDateTime = mDate + ", " + mTime;

				return mDateTime;
			} else {
				return "";
			}
		}
	}
});