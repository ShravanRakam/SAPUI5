/*global QUnit*/

jQuery.sap.require("sap.ui.qunit.qunit-css");
jQuery.sap.require("sap.ui.thirdparty.qunit");
jQuery.sap.require("sap.ui.qunit.qunit-junit");
QUnit.config.autostart = false;

sap.ui.require([
	"sap/ui/test/Opa5",
	"bumpmaint/zbump_maintenance/test/integration/pages/Common",
	"sap/ui/test/opaQunit",
	"bumpmaint/zbump_maintenance/test/integration/pages/Worklist",
	"bumpmaint/zbump_maintenance/test/integration/pages/Object",
	"bumpmaint/zbump_maintenance/test/integration/pages/NotFound",
	"bumpmaint/zbump_maintenance/test/integration/pages/Browser",
	"bumpmaint/zbump_maintenance/test/integration/pages/App"
], function (Opa5, Common) {
	"use strict";
	Opa5.extendConfig({
		arrangements: new Common(),
		viewNamespace: "bumpmaint.zbump_maintenance.view."
	});

	sap.ui.require([
		"bumpmaint/zbump_maintenance/test/integration/WorklistJourney",
		"bumpmaint/zbump_maintenance/test/integration/ObjectJourney",
		"bumpmaint/zbump_maintenance/test/integration/NavigationJourney",
		"bumpmaint/zbump_maintenance/test/integration/NotFoundJourney"
	], function () {
		QUnit.start();
	});
});