sap.ui.define(["sap/ui/core/UIComponent", "sap/ui/Device", "bumpmaint/zbump_maintenance/model/models",
	"bumpmaint/zbump_maintenance/controller/ErrorHandler"
], function (e, t, s, n) {
	"use strict";
	return e.extend("bumpmaint.zbump_maintenance.Component", {
		metadata: {
			manifest: "json",
			includes: ["css/style.css"]
		},
		init: function () {
			e.prototype.init.apply(this, arguments);
			this._oErrorHandler = new n(this);
			this.setModel(s.createDeviceModel(), "device");
			this.getRouter().initialize()
		},
		destroy: function () {
			this._oErrorHandler.destroy();
			e.prototype.destroy.apply(this, arguments)
		},
		getContentDensityClass: function () {
			if (this._sContentDensityClass === undefined) {
				if (jQuery(document.body).hasClass("sapUiSizeCozy") || jQuery(document.body).hasClass("sapUiSizeCompact")) {
					this._sContentDensityClass = ""
				} else if (!t.support.touch) {
					this._sContentDensityClass = "sapUiSizeCompact"
				} else {
					this._sContentDensityClass = "sapUiSizeCozy"
				}
			}
			return this._sContentDensityClass
		}
	})
});