sap.ui.define([
    "sap/ui/core/mvc/Controller",
    "sap/ui/model/json/JSONModel"
],
    /**
     * @param {typeof sap.ui.core.mvc.Controller} Controller
     */
    function (Controller, JSONModel) {
        "use strict";

        return Controller.extend("com.double.doubleclick1.controller.View1", {
            onInit: function () {
                var that = this;
                // that.fnCreateBusyDialog("275.gif"); 
                var sTableModel = new JSONModel(jQuery.sap.getModulePath("com.double.doubleclick1", "/model/Table.json"));
                that.getView().setModel(sTableModel, "STableModel");
                // this.obj = this.getView().getBindingContext("STableModel").getObject(); 
                var oTable = this.getView().byId("Table");
                oTable.attachBrowserEvent("dblclick", this.onDblClick.bind(this));
                // oTable.attachEvent("cellClick", function(event) { //oTable.attachBrowserEvent("dblclick", function(oEvent) { 
                // Check if the click event is a double-click 
                // if (oEvent.getParameter("clickCount") === 2) {
                // // Double-click logic goes here 
                // console.log("Double-click event"); 
                // } 
                // }); 
            }, onDblClick: function (oEvent) {
                var that = this; 
                var oID = oEvent.toElement.id;
                var oParent = $('#' + oID).parent();
                // var oParentID = oParent[0].id;
                var oParentID = oParent.prevObject.context.activeElement.id; 
                var oItem = sap.ui.getCore().byId(oParentID); 
                // var viewData = this.getView().getModel("table").getData(); 
                // var oContext = oItem.getBindingContext(); 
                var obj = oItem.getBindingContext("STableModel").getObject();
                // var path = oItem.getBindingContext("STableModel").getObject(); 
                var data = new JSONModel(obj); 
                that.byId("Table").setModel(data, "rowData"); 
                // sap.ui.getCore().setModel(data, "rowData"); 
                if (!this.Fragment) { this.Fragment = sap.ui.xmlfragment("com.double.doubleclick1.view.Fragment", this); 
                // this.Fragment.byId("idsimpleForm", "controlId"); 
                // sap.ui.getCore().addDependent(this.Fragment); 
                this.getView().addDependent(this.Fragment); 
            } this.Fragment.open(); 
            //if (!this.Fragment) { 
                //  This fragment can be instantiated from a controller as follows: 
                // this.Fragment = sap.ui.xmlfragment("idFragment","com.task.view.Fragment", this); 
                // //debugger; 
                } 
                //debugger; this.Fragment.open();
            });
    });
