sap.ui.define([
	"comdouble/doubleclick1/test/unit/controller/View1.controller"
], function () {
	"use strict";
});
