sap.ui.define([
	"com/projectk/test/unit/controller/View1.controller"
], function () {
	"use strict";
});