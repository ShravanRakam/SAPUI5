sap.ui.define([], function () {
	"use strict";

	return {

		/**
		 * Rounds the number unit value to 2 digits
		 * @public
		 * @param {string} sValue the number string to be rounded
		 * @returns {string} sValue with 2 digits rounded
		 */
		numberUnit: function (sValue) {
			if (!sValue) {
				return "";
			}
			return parseFloat(sValue).toFixed(2);
		},
		checkBoxFormatter: function (Zone) {
			var zone = Zone;
			var value = false;
			if (zone === "X") {
				value = true;
			} else if (zone === "") {
				value = false;
			}
			return value;
		},
		// restDays: function (enabled, RestDay) {
		// 	var returnVal = enabled;
		// 	if (RestDay !== undefined && RestDay !== null) {
		// 		var rd = RestDay.split("/");
		// 		for (var i = 0; i < rd.length; i++) {
		// 			if (rd[i] === "MONDAY") {
		// 				returnVal = false;
		// 				break;
		// 			} else if (rd[i] === "TUESDAY") {
		// 				returnVal = false;
		// 				break;
		// 			} else if (rd[i] === "WEDNESDAY") {
		// 				returnVal = false;
		// 				break;
		// 			} else if (rd[i] === "THURSDAY") {
		// 				returnVal = false;
		// 				break;
		// 			} else if (rd[i] === "FRIDAY") {
		// 				returnVal = false;
		// 				break;
		// 			} else if (rd[i] === "SATURDAY") {
		// 				returnVal = false;
		// 				break;
		// 			} else if (rd[i] === "SUNDAY") {
		// 				returnVal = false;
		// 				break;
		// 			}
		// 		}
		// 	}
		// 	return returnVal;
		// },
		restDaysMon: function (enabled, RestDay) {
			var returnVal = enabled;
			if (RestDay !== undefined && RestDay !== null) {
				if (RestDay.includes("MONDAY")) {
					returnVal = false;
				}
			}
			return returnVal;

		},
		restDaysTues: function (enabled, RestDay) {
			var returnVal = enabled;
			if (RestDay !== undefined && RestDay !== null) {
				// var rd = RestDay.incldes("TUESDAY");
				if (RestDay.includes("TUESDAY")) {
					returnVal = false;
				}
			}
			return returnVal;
		},
		restDaysWedn: function (enabled, RestDay) {
			var returnVal = enabled;
			if (RestDay !== undefined && RestDay !== null) {
				if (RestDay.includes("WEDNESDAY")) {
					returnVal = false;
				}
			}
			return returnVal;
		},
		restDaysThurs: function (enabled, RestDay) {
			var returnVal = enabled;
			if (RestDay !== undefined && RestDay !== null) {
				if (RestDay.includes("THURSDAY")) {
					returnVal = false;
				}
			}
			return returnVal;
		},
		restDaysFriday: function (enabled, RestDay) {
			var returnVal = enabled;
			if (RestDay !== undefined && RestDay !== null) {
				if (RestDay.includes("FRIDAY")) {
					returnVal = false;
				}
			}
			return returnVal;
		},
		restDaysSatrday: function (enabled, RestDay) {
			var returnVal = enabled;
			if (RestDay !== undefined && RestDay !== null) {
				if (RestDay.includes("SATURDAY")) {
					returnVal = false;
				}
			}
			return returnVal;
		},
		restDaysSundy: function (enabled, RestDay) {
			var returnVal = enabled;
			if (RestDay !== undefined && RestDay !== null) {
				if (RestDay.includes("SUNDAY")) {
					returnVal = false;
				}
			}
			return returnVal;
		}

	};

});