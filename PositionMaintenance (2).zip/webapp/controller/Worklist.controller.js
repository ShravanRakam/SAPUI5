sap.ui.define([
	"./BaseController",
	"sap/ui/model/json/JSONModel",
	"../model/formatter",
	"sap/ui/model/Filter",
	"sap/ui/model/FilterOperator",
	"sap/m/MessageBox"
], function (BaseController, JSONModel, formatter, Filter, FilterOperator, MessageBox) {
	"use strict";

	return BaseController.extend("com.position.controller.Worklist", {

		formatter: formatter,

		/* =========================================================== */
		/* lifecycle methods                                           */
		/* =========================================================== */

		/**
		 * Called when the worklist controller is instantiated.
		 * @public
		 */
		onInit: function () {
			jQuery(".sapUShellFullHeight").addClass("cTracsApps");
			var that = this,
				oViewModel, visibleModel;
			var dateFormat = sap.ui.core.format.DateFormat.getDateInstance({
				pattern: "yyyyMMdd"
			});
			var todayDate = dateFormat.format(new Date());
			oViewModel = new JSONModel({
				busyInd: false,
				Role: "",
				Group: "",
				craftTxt: "",
				positonIdVal: "",
				posDesc: "",
				posIdSearchValue: "",
				contectIconTabKey: "POSITION",
				dateRange: todayDate,
				qulEffectDate: todayDate,
				qulEndDate: "12319999",
				qualTitieIdVal: "",
				qualifIdInpDesc: "",
				QualNameId: "",
				QualNameIdDesc: "",
				QualNameIdName: "",
				posStartDateValState: "None",
				roleEnabled: true,
				groupEnabled: true,
				posIdEnabled: true,
				asDateEnabled: true,
				qualStartDateEnable: false,
				qualifIdInpEnable: false,
				qualEndDateEnable: false,
				qualAddBtnEnable: false,
				editable: false,
				enabled: false
			});
			that.getView().setModel(oViewModel, "viewModel");
			visibleModel = new JSONModel({
				iconTabContent: false,
				positionPayrolCont: false,
				editBtn: false,
				cancelBtn: false,
				saveBtn: false,
				submitBtn: false,
				editBtnEnable: false,
				cancelBtnEnable: false,
				saveBtnEnable: false,
				submitBtnEnable: false,
				posGlobalTable: false
			});
			that.getView().setModel(visibleModel, "visibleModel");
			var mModel = that.getOwnerComponent().getModel("oDataSrv");
			mModel.setDefaultBindingMode(sap.ui.model.BindingMode.OneWay);
			var oRatedModel = new JSONModel();
			mModel.read("/RatedetSet", null, null, false, function (oRatedData) {
				var oRateData = oRatedData.results;
				oRatedModel.setData(oRateData);
				that.getView().setModel(oRatedModel, "oRatedModel");
			});

			//********************Startup Parameters*****************//
			var oLoggedinUser;
			var y = "/sap/bc/ui2/start_up";
			var xmlHttp = null;
			xmlHttp = new XMLHttpRequest();
			xmlHttp.onreadystatechange = function () {
				if (xmlHttp.readyState === 4 && xmlHttp.status === 200) {
					var oUserData = JSON.parse(xmlHttp.responseText);
					oLoggedinUser = oUserData.id;
					jQuery.sap.require("jquery.sap.storage");
					jQuery.sap.storage(jQuery.sap.storage.Type.local).put("UserName", oLoggedinUser);
					that.userDetailsSet(oLoggedinUser);
				}
			};
			xmlHttp.open("GET", y, false);
			xmlHttp.send(null);

		},
		getDropdownData: function (entity, modelName, filters) {
			var that = this,
				sModel = that.getOwnerComponent().getModel();
			sModel.read(entity, {
				filters: filters,
				success: function (oData, res) {
					if (res.statusCode === '200' || res.statusCode === 200) {
						var oModel = new JSONModel();
						if (oData.results.length > 0) {
							oModel.setData(oData);
							oModel.setSizeLimit(100000);
						} else {
							oModel.setData({
								results: []
							});
						}
						that.getView().setModel(oModel, modelName);
					}
				},
				error: function (err) {
					that.errorHandler(err);
				}
			});
		},
		userDetailsSet: function (userId) {
			var that = this;
			//-----------------------------------------------------------------------	
			// Calling the oData service. 
			//-----------------------------------------------------------------------
			var craftTypeModel = that.getOwnerComponent().getModel();
			var Intdialog = new sap.m.BusyDialog({
				text: "Data loading please wait..."
			});
			Intdialog.open();
			craftTypeModel.read("/UserDetailsSet?$filter=Uname eq '" + userId + "'", {
				success: function (oData) {
					Intdialog.close();
					that.userDetailsSetData = oData; //settting the odata to global variable access the User details 
					var resul = oData.results;
					var rolesArray = resul.slice();
					var roleVals = [];
					for (var i = 0; i < rolesArray.length; i++) {
						var oVal1 = rolesArray[i].Role;
						roleVals.push(oVal1);
						if (oVal1 === "LR Admin") {
							that.getModel("visibleModel").setProperty("/editBtn", false);
							that.getModel("visibleModel").setProperty("/cancelBtn", false);
						}
					}
					var finalArray = that.uniqueValuesFunc(roleVals, "Role");
					var oDataRole = {
						results: finalArray
					};
					var selectedKey1 = oDataRole.results[0].Role;
					var oJModelRole = new JSONModel(oDataRole);
					that.setModel(oJModelRole, "RoleModel");
					that.getModel("viewModel").setProperty("/Role", selectedKey1);
					if (selectedKey1 === "Payroll Admin") {
						that.getModel("viewModel").setProperty("/groupEnabled", true);
					}
					//fire the change event of the roles dropdown to get the departments values
					that.byId("roleIdSelect").fireChange(that.byId("roleIdSelect").getSelectedItem());
					that.byId("positonIdInp").setValueState("None");
					that.byId("positonIdInp").setValue();
					that.byId("positonIdInp").setTokens([]);
					that.byId("posMaintId").setShowFooter(true);

				},
				error: function (oResponse) {
					Intdialog.close();
					var oMessage = [];
					var msg_len = $(oResponse.response.body).find('message').first().prevObject.length;
					for (var j = 0; j < msg_len; j++) {
						var exception = $(oResponse.response.body).find('message').first().prevObject[j].innerText;
						if (exception !== "Exception raised without specific error") {
							var Message = $(oResponse.response.body).find('message').first().prevObject[j].innerText;
							oMessage.push(Message);
						}
					}
					var uniqueMsgs = [];
					$.each(oMessage, function (i, el) {
						if ($.inArray(el, uniqueMsgs) === -1) uniqueMsgs.push(el);
					});
					var msg = uniqueMsgs.toLocaleString().split(",").join("\r\n");

					if (oMessage === undefined) {
						msg = $(oResponse.response.body).find('message').first().prevObject[0].innerText;
					}
					MessageBox.show(
						msg, {
							icon: MessageBox.Icon.INFORMATION,
							title: "Log",
							actions: [MessageBox.Action.OK],
							onClose: function (sAction) {
								if (sAction === "OK") {
									var oCrossAppNavigator = sap.ushell.Container.getService("CrossApplicationNavigation");
									oCrossAppNavigator.toExternal({
										target: {
											semanticObject: "#"
										}
									});
								}
							}
						});

				}
			});
		},
		onRoleSelectionChange: function (oEvent) {
			var that = this;
			var oSelectedRole = oEvent.getSource().getSelectedKey();
			var selectedRows = [];
			//get the same roles data based on the role selection
			var oRole = that.byId("roleIdSelect").getSelectedKey();
			if (oRole === "LR Admin") {
				that.getModel("visibleModel").setProperty("/editBtn", false);
				that.getModel("visibleModel").setProperty("/cancelBtn", false);
				that.byId("qualificationIconTab").setVisible(false);
			} else {
				that.getModel("visibleModel").setProperty("/editBtn", false);
				that.getModel("visibleModel").setProperty("/cancelBtn", false);
				that.byId("qualificationIconTab").setVisible(true);
			}
			for (var i = 0; i < that.userDetailsSetData.results.length; i++) {
				if (that.userDetailsSetData.results[i].Role === oSelectedRole) {
					selectedRows.push(that.userDetailsSetData.results[i]);
				}
			}
			//create the array of object of unique departments to bind it to the group dropdown
			var newObj = {};
			var newDepAndUnionsArray = selectedRows.filter(function (obj) {
				if (newObj[obj.Department]) {
					return false;
				}
				newObj[obj.Department] = true;
				return true;
			});

			var oJModel = new JSONModel(newDepAndUnionsArray);
			oJModel.setDefaultBindingMode("OneWay");
			that.setModel(oJModel, "DepModel");
			that.getModel("viewModel").setProperty("/Group", newDepAndUnionsArray[0].Unions);

			that.craftUnion = newDepAndUnionsArray[0].Department;
			that.Unions = newDepAndUnionsArray[0].Unions;
			that.getModel("viewModel").setProperty("/craftTxt", that.craftUnion);
			that.byId("depIdSelect").fireChange({
				selectedItem: that.byId("depIdSelect").getItems()[0]
			});
			that.byId("positonIdInp").setValueState("None");
			that.posChangeFlag = undefined;
		},
		onChangeEngStDateSelection: function (oEvt) {
			var that = this;
			if (oEvt) {
				var oDP = oEvt.getSource();
				var bValid = oEvt.getParameter("valid");
				if (!bValid) {
					oEvt.getSource().setValue("");
					oDP.setValueState(sap.ui.core.ValueState.Error);
					sap.m.MessageToast.show("Please enter valid date");
					return;
				}
				oDP.setValueState(sap.ui.core.ValueState.None);
			}
			// var engOldSDate = sap.ui.getCore().getModel("oDataModel").getProperty("/StartDate");
			var engCurrentSDate = oEvt.getSource().getValue();
			// var engCurrStYear = engCurrentSDate.slice("0", "4");
			// var engCurrStMonth = engCurrentSDate.slice("4").slice("0", "2");
			// var engCurrStDay = engCurrentSDate.slice("6");
			// var engCurrentStDate = engCurrStMonth + "/" + engCurrStDay + "/" + engCurrStYear;
			var engOld = sap.ui.getCore().getModel("oDataModel").getProperty("/EndDate");

			// if (engCurrentStDate < that.oEfectVal) {
			// 	sap.m.MessageBox.show("Start date should not be less than Position Start date", {
			// 		icon: sap.m.MessageBox.Icon.ERROR,
			// 		title: "Error",
			// 		actions: [sap.m.MessageBox.Action.OK],
			// 	});
			// 	oEvt.getSource().setValueState("Error");
			// } else 
			if (engCurrentSDate > engOld) {
				sap.m.MessageBox.show("Start date should be less than End date", {
					icon: sap.m.MessageBox.Icon.ERROR,
					title: "Error",
					actions: [sap.m.MessageBox.Action.OK],
				});
				oEvt.getSource().setValueState("Error");
			} else {
				oEvt.getSource().setValueState("None");
			}
		},
		onDepSelectionChange: function (oEvent) {
			var that = this;
			var dialog = new sap.m.BusyDialog({
				text: "Please wait..."
			});
			dialog.open();
			var sPath = oEvent.getSource().getSelectedItem().getBindingContext("DepModel").getPath();
			var data = oEvent.getSource().getModel("DepModel").getProperty(sPath);
			that.craftUnion = data.Unions;
			if (data.Department === "TCU") {
				that.craftDept = data.Department;
			}
			that.byId("positonIdInp").setTokens([]);
			that.getModel("visibleModel").setProperty("/iconTabContent", false);
			that.getModel("viewModel").setProperty("/positonIdVal", "");
			that.getModel("viewModel").setProperty("/posDesc", "");
			that.getModel("visibleModel").setProperty("/editBtn", false);
			that.getModel("visibleModel").setProperty("/cancelBtn", false);
			that.getModel("visibleModel").setProperty("/saveBtn", false);
			that.getModel("visibleModel").setProperty("/submitBtn", false);
			that.getModel("visibleModel").setProperty("/iconTabContent", false);
			that.getModel("visibleModel").setProperty("/positionPayrolCont", false);
			that.getModel("visibleModel").setProperty("/editBtnEnable", false);
			that.getModel("visibleModel").setProperty("/cancelBtnEnable", true);
			that.getModel("visibleModel").setProperty("/saveBtnEnable", false);
			that.getModel("visibleModel").setProperty("/submitBtnEnable", false);
			that.posChangeFlag = undefined;
			if (that.craftUnion === "SE" || that.craftUnion === "SD" || that.craftUnion === "SM" || that.craftUnion === "ST" || that.craftUnion ===
				"SL") {
				that.getValueHelpData("/workschsearchhelpSet", "WorkSchModel");
				that.getValueHelpData("/PosTypeSearchHelpSet", "PosTypeModel");
				that.getValueHelpData("/HosStatusSearchHelpSet", "HosStatusModel");
				dialog.close();
				if (that.craftUnion === "SD" || that.craftUnion === "ST" || that.craftUnion === "SL") {
					that.getValueHelpData("/PFSearchHelpSet", "PadFenceModel");
					dialog.close();
				}
			}
			if (that.craftUnion === "ATDA" || that.payCraft === "A" || that.craftUnion === "Dispatchers" || that.craftUnion === "SD") {
				that.getValueHelpData("/DeskNumberSet", "DeskNumberJSModel");
				that.getValueHelpData("/TCUDepartmentDropdownSet", "TCUDepartmentSuggDropdown");
				dialog.close();
			} else if (that.craftUnion === "ILA" || that.craftUnion === "SL" || that.payCraft === "L" || that.craftUnion === "L") {
				// code
				dialog.close();
			} else if (that.craftUnion === "IHB" || that.craftUnion === "NAHR" || that.craftUnion === "Conrail" || that.craftUnion ===
				"SI" ||
				that.craftUnion === "SN" || that.craftUnion === "SC" || that.payCraft === "N" || that.payCraft === "C" || that.payCraft ===
				"I") {
				// code
				dialog.close();
			} else if (that.craftUnion === "Mechanical" || that.craftUnion === "SM" || that.payCraft === "M" || that.craftUnion === "M") {
				that.getValueHelpData("/CraftSearchHelpSet", "CraftModel");
				that.getValueHelpData("/AreaSearchHelpSet", "AreaData");
				that.getValueHelpData("/SkillDifferentialSet", "SkillDiffSuggModel");
				dialog.close();
			} else if (that.craftUnion === "Engineering" || that.craftUnion === "SE" ||
				that.payCraft === "E" ||
				that.craftUnion === "E") {
				that.getValueHelpData("/StateSearchhelpSet", "StateData");
				that.getValueHelpData("/DistrictSearchHelpSet", "DistData");
				that.getValueHelpData("/RRCodeSearchHelpSet", "RrCodeJsModel");
				that.getValueHelpData("/RegionSearchHelpSet", "RegionJsModel");
				that.getValueHelpData("/PosDropDownsSet?$filter=Key eq 'H' and Value eq ''", "holdDropDown");
				dialog.close();
			} else if (that.craftUnion === "TCU" || that.craftUnion === "ST" || that.payCraft === "T" || that.craftUnion === "T") {
				that.getValueHelpData("/TCUDepartmentDropdownSet", "TCUDepartmentSuggDropdown");
				dialog.close();
			} else if (that.craftUnion === "Payroll" || that.craftUnion === "P" || that.craftUnion === "SP") {
				that.getValueHelpData("/AggrSearchHelpSet", "AggrModelData");
				that.getValueHelpData("/JobClsSearchHelpSet", "jobModelData");
				that.getValueHelpData("/SkillDifferentialSet", "skillDiffModel");
				that.getValueHelpData("/SenPlanSearchHelpSet", "senirModeldata");
				that.getValueHelpData("/ExtbrdSeachHelpSet", "extbrdModel");
				that.getValueHelpData("/StepRateSearchHelpSet", "stepRateModel");
				that.getValueHelpData("/vacqualsearchhelpSet", "vacQualModel");
				that.getValueHelpData("/PayTypeSearchHelpSet", "oPSTypeModel");
				dialog.close();
			}
		},
		//-----------------------------------------------------------------------	
		// Position ID token update.
		//-----------------------------------------------------------------------
		onPosLiveChange: function (oEvent) {
			var that = this;
			that.oEditAll = false;
			var posId = "";
			if (that.byId("positonIdInp").getTokens().length !== 0) {
				posId = that.byId("positonIdInp").getTokens()[0].getKey();
			}
			if (posId.trim().length === 0) {
				that.byId("positonIdInp").setValueState("None");
				that.getModel("viewModel").setProperty("/positonIdVal", "");
				that.getModel("viewModel").setProperty("/posDesc", "");
				that.emptyData();
			} else if (posId.trim().length < 8) {
				that.emptyData();
			} else {
				that.byId("positonIdInp").setValueState("None");
			}
			if (oEvent.getParameter("type") === "removed") {
				that.getModel("visibleModel").setProperty("/iconTabContent", false);
				that.getModel("viewModel").setProperty("/positonIdVal", "");
				that.getModel("viewModel").setProperty("/posDesc", "");
				that.getModel("visibleModel").setProperty("/editBtn", false);
				that.getModel("visibleModel").setProperty("/cancelBtn", false);
				that.getModel("visibleModel").setProperty("/saveBtn", false);
				that.getModel("visibleModel").setProperty("/submitBtn", false);
				that.getModel("visibleModel").setProperty("/iconTabContent", false);
				that.getModel("visibleModel").setProperty("/positionPayrolCont", false);
				that.getModel("visibleModel").setProperty("/editBtnEnable", false);
				that.getModel("visibleModel").setProperty("/cancelBtnEnable", false);
				that.getModel("visibleModel").setProperty("/saveBtnEnable", false);
				that.getModel("visibleModel").setProperty("/submitBtnEnable", false);
			} else {
				that.getModel("visibleModel").setProperty("/iconTabContent", true);
				that.getModel("visibleModel").setProperty("/editBtn", true);
				that.getModel("visibleModel").setProperty("/cancelBtn", true);
				that.getModel("visibleModel").setProperty("/editBtnEnable", false);
				that.getModel("visibleModel").setProperty("/cancelBtnEnable", true);
			}
		},
		//-----------------------------------------------------------------------	
		// Position ID Dialogue.
		//-----------------------------------------------------------------------
		onPosIdRequest: function (oEvent) {
			var that = this;
			var PositionId;
			var key;
			var dialog = new sap.m.BusyDialog({
				text: "Please wait..."
			});
			dialog.open();
			if (that.getView().byId("positonIdInp").getTokens().length !== 0) {
				PositionId = that.byId("positonIdInp").getTokens()[0].getKey();
				key = "";
			} else {
				PositionId = oEvent.getSource().getValue().trim();
				key = "";
			}
			that.craftUnion = that.getView().getModel("viewModel").getProperty("/Group");

			that.onSelectIconTabBar();
			if (that.craftUnion === "M" || that.craftUnion === "E" || that.craftUnion === "A" || that.craftUnion === "T" || that.craftUnion ===
				"D" || that.craftUnion ===
				"SE" || that.craftUnion === "SM" || that.craftUnion ===
				"SL" || that.craftUnion ===
				"SD" || that.craftUnion === "CH" || that.craftUnion === "CG" || that.craftUnion === "SN" || that.craftUnion === "N" || that.craftUnion ===
				"SI" || that.craftUnion ===
				"I" || that.craftUnion ===
				"SC" || that.craftUnion ===
				"C" || that.craftUnion ===
				"ST" || that.craftUnion ===
				"P" || that.craftUnion ===
				"SP" || that.craftUnion ===
				"LR" || that.craftUnion ===
				"Payroll") {
				if (!that.oDialog) {
					dialog.close();
					that.oDialog = sap.ui.xmlfragment("com.position.fragment.PositionId", that.getView()
						.getController());
					that.getView().addDependent(that.oDialog);
				}
				// that.getView().getModel("viewModel").setProperty("/posIdSearchValue", PositionId);
				if (that.craftUnion === "Engineering" || that.craftUnion === "SE" || that.craftUnion === "E") {
					key = "E";
					// if (!that.popOver) {
					// 	that.popOver = sap.ui.xmlfragment("com.position.fragment.FilterPopover",
					// 		that);
					// 	that.oDialog.addDependent(that.popOver, that.oDialog);
					// }
					// var oTable = sap.ui.getCore().byId("PositionIdTable");
					// oTable.addEventDelegate({
					// 	onAfterRendering: function () {
					// 		var oHeader = oTable.$().find(".sapMListTblHeaderCell"); //Get hold of table header elements
					// 		for (var i = 0; i < oHeader.length; i++) {
					// 			var oID = oHeader[i].id;
					// 			that.onClick(oID);
					// 		}
					// 	}
					// }, oTable);
				} else if (that.craftUnion === "Mechanical" || that.craftUnion === "SM" || that.craftUnion === "M") {
					key = "M";
				} else if (that.craftUnion === "TCU" || that.craftUnion === "ST" || that.craftUnion === "T") {
					key = "T";
				} else if ((that.craftUnion === "ATDA" || that.craftUnion === "SD") || (that.craftUnion === "Dispatchers" || that.craftUnion ===
						"D")) {
					key = "D";
				} else if (that.craftUnion === "ILA" || that.craftUnion === "SL" || that.craftUnion === "L") {
					key = "L";
				} else if (that.craftUnion === "Conrail" || that.craftUnion === "SC" || that.craftUnion === "C") {
					key = "C";
				} else if (that.craftUnion === "IHB" || that.craftUnion === "SI" || that.craftUnion === "I") {
					key = "I";
				} else if (that.craftUnion === "NAHR" || that.craftUnion === "SN" || that.craftUnion === "N") {
					key = "N";
				} else if (that.craftUnion === "Payroll" || that.craftUnion === "P" || that.craftUnion === "SP") {
					key = "P";
				}
				if (oEvent.getSource().getValue().trim() !== "") {
					that.oDialog.setBusy(true);
					that.oDialog.setBusyIndicatorDelay(0);
					that.posIdService(PositionId, key);
					that.oDialog.open();
					sap.ui.getCore().byId("idEngIconTabBar").setSelectedKey("Position ID or Title");
					that.posIdDialog = "X";
				} else {
					that.oDialog.open();
					that.oDialog.setEscapeHandler(function (o) {
						o.reject();
					});
					that.posIdDialog = "X";
				}
			}
			// if (that.getView().byId("positonIdInp").getTokens().length !== 0) {
			// 	sap.ui.getCore().byId("positionSearch").fireSearch();
			// }
		},
		posIdService: function (PositionId, key) {
			var that = this;
			var oTable = sap.ui.getCore().byId("PositionIdTable");
			var titleInfo = that.getView().getModel("i18n").getProperty("titleInfo");
			var oModel = new JSONModel();
			var srvModel = that.getOwnerComponent().getModel("oDataSrv");
			srvModel.read("/PositionSearchHelpSet?$filter=PositionId eq '" + PositionId + "' and Key eq '" + key + "'", null, null,
				true,
				function (oData) {
					if (oData.results.length > 0) {
						oModel.setData(oData);
						that.oDialog.setBusy(false);
						oTable.setModel(oModel, "positionModelData");
						that.getView().getModel("visibleModel").setProperty("/posGlobalTable", true);
						if (key === "P") {
							that.payCraft = oData.results[0].Craft;
						}
					} else {
						that.oDialog.setBusy(false);
						that.getView().getModel("visibleModel").setProperty("/posGlobalTable", false);
					}
				},
				function (oResponse) {
					oModel.setData({});
					oTable.setModel(oModel, "positionModelData");
					that.getView().getModel("visibleModel").setProperty("/posGlobalTable", false);
					//-----------------------------------------------------------------------	
					// Displaying response body message.
					//-----------------------------------------------------------------------
					that.oDialog.setBusy(false);
					that.errorMessageforHelp(oResponse, titleInfo);
				});
		},
		onPayrollPositionSubmit: function (oEvent) {
			var context = oEvent.getSource().getBindingContext("payRollPosDetails");
			var data = context.getModel().getProperty(context.getPath());
			this.getView().byId("positonIdInp").setValue(data.PositionId);
			if (data.PositionDesc !== "") {
				this.getView().byId("positonIdInp").setDescription(data.PositionDesc).setWidth("25%");
			}
			this.payCraft = data.Craft;
			this.onPositionSubmitInput();
			this.onPayDialogCancel();
		},
		onDialogClose: function () {
			var that = this;
			that.oDialog.close();
			that.oDialog.destroy();
			that.oDialog = null;
			that.popOver = null;
		},
		onPosIdDropDown: function (oEvent) {
			var that = this;
			var name = oEvent.getSource().getName();
			var GrpValue = that.craftUnionfun();
			var filters = [],
				modelName = "",
				key = "";
			if (name === "Union") {
				modelName = "UninonModel";
				key = "U";
			} else if (name === "State") {
				modelName = "stateModelData";
				key = "S";
			} else if (name === "Division") {
				modelName = "DivisnModelData";
				key = "D";
			} else if (name === "Gang") {
				modelName = "GangModelDropModel";
				key = "G";
			} else if (name === "AgreementCode") {
				modelName = "payrollAggDropDownModelData";
				key = "AGR_CODE";
			} else if (name === "craftName") {
				modelName = "craftModelData";
				key = "C";
			} else if (name === "Area") {
				modelName = "mechAreaDropDownModelData";
				key = "A";
			} else if (name === "Territory") {
				modelName = "mechTerritoryModelData";
				key = "T";
			} else if (name === "deprtmet") {
				modelName = "deptModel";
				key = "DEPT_CODE";
			} else if (name === "desk") {
				modelName = "deskModel";
				key = "K";
			}
			filters.push(new sap.ui.model.Filter("Key", sap.ui.model.FilterOperator.EQ, key));
			if (name !== "desk") {
				filters.push(new sap.ui.model.Filter("Value", sap.ui.model.FilterOperator.EQ, GrpValue));
			}
			that.posIdDropDownSrv(filters, modelName, name);
		},
		posIdDropDownSrv: function (filters, modelName, name) {
			var that = this;
			var unionModel = that.getOwnerComponent().getModel();
			var titleInfo = that.getView().getModel("i18n").getProperty("titleInfo");
			unionModel.read("/PosDropDownsSet", {
				filters: filters,
				success: function (oData) {
					if (oData.results.length > 0) {
						if (name === "Gang") {
							var uniqDivArr = that.uniqueDropDownValFun(oData.results, "Value");
							oData = {
								results: uniqDivArr
							};
						}
						var oUninonModel = new JSONModel(oData);
						that.getView().setModel(oUninonModel, modelName);
					} else {
						var oDropDownModel = new JSONModel(oData);
						that.getView().setModel(oDropDownModel, modelName);
					}
				},
				error: function (oResponse) {
					if (name === "Division") {
						//-----------------------------------------------------------------------	
						// Displaying response body message.
						//-----------------------------------------------------------------------
						var oMessage;
						var mesLen = $(oResponse.response.body).find("message").first().prevObject.length;
						for (var i = 1; i < mesLen; i++) {
							var exception = $(oResponse.response.body).find("message").first().prevObject[i].innerText;
							if (exception !== "Exception raised without specific error") {
								var Message = $(oResponse.response.body).find("message").first().prevObject[i].innerText;
							} else {
								Message = "";
							}
							if (i === 1) {
								oMessage = Message;
							}
							if (i > 1) {
								oMessage = oMessage + "\r\n" + Message;
							}
						}
						if (oMessage === undefined) {
							oMessage = $(oResponse.response.body).find("message").first().prevObject[0].innerText;
						}
						sap.m.MessageBox.show(oMessage, {
							icon: sap.m.MessageBox.Icon.INFORMATION,
							title: titleInfo,
							actions: [sap.m.MessageBox.Action.OK],
							onClose: function (oAction) {}
						});
					} else {
						that.errorMessageforHelp(oResponse);
					}
				}
			});
		},
		onDropDownSelectionChange: function (oEvent) {
			var that = this,
				filterKey,
				GrpValue, sFilters = [],
				name = oEvent.getSource().getName(),
				titleInfo = that.getView().getModel("i18n").getProperty("titleInfo"),
				selectText = oEvent.getParameter("selectedItem").getProperty("text"),
				srvModel = that.getOwnerComponent().getModel();
			GrpValue = that.craftUnionfun();
			if (name === "Union") {
				filterKey = "Union";
			} else if (name === "State") {
				filterKey = "State";
			} else if (name === "Division") {
				filterKey = "Divison";
				selectText = selectText.replace(/&/g, "%26");
			} else if (name === "Gang") {
				filterKey = "GangId";
			} else if (name === "AgreementCode") {
				filterKey = "AgreementCode";
			} else if (name === "craftName") {
				filterKey = "Craft";
			} else if (name === "Area") {
				filterKey = "Area";
			} else if (name === "Territory") {
				filterKey = "Territory";
			} else if (name === "deprtmet") {
				filterKey = "Department";
			} else if (name === "desk") {
				filterKey = "Desk";
			}
			sFilters.push(new sap.ui.model.Filter(filterKey, sap.ui.model.FilterOperator.EQ, selectText));
			sFilters.push(new sap.ui.model.Filter("Key", sap.ui.model.FilterOperator.EQ, GrpValue));
			srvModel.read("/PositionSearchHelpSet", {
				filters: sFilters,
				success: function (oData) {
					if (oData.results.length > 0) {
						var oUninonModel = new JSONModel(oData.results);
						that.getView().setModel(oUninonModel, "positionModelData");
						that.getView().getModel("visibleModel").setProperty("/posGlobalTable", true);
					} else {
						that.getView().getModel("visibleModel").setProperty("/posGlobalTable", false);
					}
				},
				error: function (oResponse) {
					that.errorMessageforHelp(oResponse, titleInfo);
					that.getView().getModel("visibleModel").setProperty("/posGlobalTable", false);
				}
			});
		},
		positionTitleSearch: function (oEvent) {
			var that = this,
				GrpValue, sFilters = [];
			var searchValue = oEvent.getSource().getValue();
			var SeltedKeyTabbar = oEvent.getSource().getParent().getParent().getKey();
			/*var posValue = that.getView().getModel("ValueModel").getProperty("/positionTitle");
			var DeptVal = that.getView().getModel("ValueModel").getProperty("/DeptVal");
			var DeskVal = that.getView().getModel("ValueModel").getProperty("/DeskVal");
			var AssignedVal = that.getView().getModel("ValueModel").getProperty("/AssignedSuperVisrVal");
			var Cityval = that.getView().getModel("ValueModel").getProperty("/cityValue");
			var Currentcupant = that.getView().getModel("ValueModel").getProperty("/CurrOcupntvalue");*/
			var oModel = that.getOwnerComponent().getModel();
			if (SeltedKeyTabbar === "Position ID or Title") {
				sFilters.push(new sap.ui.model.Filter("PositionId", sap.ui.model.FilterOperator.EQ, searchValue));
			} else if (SeltedKeyTabbar === "Assigned Supervisor") {
				sFilters.push(new sap.ui.model.Filter("AssignSup", sap.ui.model.FilterOperator.EQ, searchValue));
			} else if (SeltedKeyTabbar === "City") {
				sFilters.push(new sap.ui.model.Filter("City", sap.ui.model.FilterOperator.EQ, searchValue));
			} else if (SeltedKeyTabbar === "Current Occupant") {
				sFilters.push(new sap.ui.model.Filter("CurntOcupnt", sap.ui.model.FilterOperator.EQ, searchValue));
			} else if (SeltedKeyTabbar === "Department") {
				sFilters.push(new sap.ui.model.Filter("Department", sap.ui.model.FilterOperator.EQ, searchValue));
			} else if (SeltedKeyTabbar === "Desk") {
				sFilters.push(new sap.ui.model.Filter("Desk", sap.ui.model.FilterOperator.EQ, searchValue));
			} else if (SeltedKeyTabbar === "CostCenter") {
				sFilters.push(new sap.ui.model.Filter("CostCenter", sap.ui.model.FilterOperator.EQ, searchValue));
			}
			GrpValue = that.craftUnionfun();
			var dialog = new sap.m.BusyDialog({
				text: "Data loading please wait..."
			});
			dialog.open();
			sFilters.push(new sap.ui.model.Filter("Key", sap.ui.model.FilterOperator.EQ, GrpValue));
			oModel.read("/PositionSearchHelpSet", {
				filters: sFilters,
				success: function (oData) {
					dialog.close();
					if (oData.results.length > 0) {
						var oUninonModel = new JSONModel(oData.results);
						that.getView().setModel(oUninonModel, "positionModelData");
						that.getView().getModel("visibleModel").setProperty("/posGlobalTable", true);
					} else {
						var oModel1 = new JSONModel([]);
						that.getView().setModel(oModel1, "positionModelData");
						that.getView().getModel("visibleModel").setProperty("/posGlobalTable", false);
						dialog.close();
					}
				},
				error: function (oResponse) {
					dialog.close();
					that.getView().getModel("visibleModel").setProperty("/posGlobalTable", false);
					that.errorMessageforHelp(oResponse);
				}
			});
		},
		onAssSupValueHelp: function (oEvent) {
			var that = this;
			var oValue = oEvent.getSource().getValue().trim();
			var oAssSupVal = "";
			if (oValue.includes("-")) {
				oAssSupVal = oValue.split("-")[0].trim();
			} else {
				oAssSupVal = oValue.trim();
			}
			if (!that._AssSupDialog) {
				that._AssSupDialog = sap.ui.xmlfragment("com.position.fragment.SupervisorNo", that);
				that.getView().addDependent(that._AssSupDialog);
			}
			that._AssSupDialog.open();
			that._AssSupDialog.setEscapeHandler(function (o) {
				o.reject();
			});
			if (oAssSupVal.length > 0) {
				sap.ui.getCore().byId("SupervisorNoSearch").setValue(oAssSupVal);
				sap.ui.getCore().byId("SupervisorNoSearch").fireSearch();
			}
		},
		onSupervisorNumberSearch: function (oEvent) {
			var AssSupchId = oEvent.getSource().getValue();
			var AssSupTable = sap.ui.getCore().byId("SupervisorNoTable");
			AssSupTable.setVisible(true);
			AssSupTable.getBinding("items").filter([new sap.ui.model.Filter("Pernr", "EQ", AssSupchId), new sap.ui.model.Filter("PernrName",
				"EQ", AssSupchId)]);
		},
		onAssignSupLiveChange: function (oEvent) {
			var that = this;
			var oAssVal = oEvent.getSource().getValue();
			if (oAssVal.trim().length < 1) {
				if (that.craftUnion === "Engineering") {
					this.posChangeFlag = "X";
				} else if (that.craftUnion === "Mechanical") {
					this.posChangeFlag = "X";
				} else if (that.craftUnion === "TCU") {
					this.posChangeFlag = "X";
				} else if (that.craftUnion === "ATDA" || that.craftUnion === "Dispatchers") {
					this.posChangeFlag = "X";
				} else if (that.craftUnion === "ILA") {
					this.posChangeFlag = "X";
				}
				that.getView().getModel("oDataModel").setProperty("/ADE", "");
				that.getView().getModel("oDataModel").setProperty("/ADEName", "");
				that.getView().getModel("oDataModel").setProperty("/DE", "");
				that.getView().getModel("oDataModel").setProperty("/DEName", "");
				that.getView().getModel("oDataModel").setProperty("/CE", "");
				that.getView().getModel("oDataModel").setProperty("/CEName", "");
			}
			this.posChangeFlag = "X";
		},
		onSupervisorNumberSave: function (oEvent) {
			var that = this;
			that.engBullFlag = true;
			var supNo = oEvent.getSource().getAggregation("cells")[0].getText();
			var supName = oEvent.getSource().getAggregation("cells")[1].getText();
			if (that.craftUnion === "Engineering") {
				that.engBullFlag = true;
				sap.ui.getCore().byId("changeEngAssSup").setWidth("200%");
			} else if (that.craftUnion === "Mechanical") {
				that.bullFlag = true;
				sap.ui.getCore().byId("changeMechAssSup").setWidth("200%");
			} else if (that.craftUnion === "TCU") {
				that.tcuDepChangeFlag = true;
				sap.ui.getCore().byId("changeTcuAssSup").setWidth("200%");
			} else if (that.craftUnion === "ATDA" || that.craftUnion === "Dispatchers") {
				that.tcuDepChangeFlag = true;
				sap.ui.getCore().byId("changeTcuAssSup").setWidth("200%");
			} else if (that.craftUnion === "ILA") {
				that.tcuDepChangeFlag = true;
				sap.ui.getCore().byId("changeTcuAssSup").setWidth("200%");
			}
			that.getView().getModel("oDataModel").setProperty("/AssignSupEmp", supNo);
			that.getView().getModel("oDataModel").setProperty("/AssignSupEmpName", supName);
			var supModel = that.getOwnerComponent().getModel("oDataSrv");
			supModel.read("/AssignSupSearchHelpSet(Pernr='" + supNo + "',PernrName='')", null, null, function (oData) {},
				function (oResponse) {
					that.getView().getModel("oDataModel").setProperty("/ADE", oResponse.ADE);
					that.getView().getModel("oDataModel").setProperty("/ADEName", oResponse.ADEName);
					that.getView().getModel("oDataModel").setProperty("/DE", oResponse.DE);
					that.getView().getModel("oDataModel").setProperty("/DEName", oResponse.DEName);
					that.getView().getModel("oDataModel").setProperty("/CE", oResponse.CE);
					that.getView().getModel("oDataModel").setProperty("/CEName", oResponse.CEName);
				});
			that._AssSupDialog.close();
			that._AssSupDialog.destroy(true);
			that._AssSupDialog = null;
		},
		/* Roaster Value Helps start */
		onRosterNumberValueHelp: function (oEvent) {
			var that = this;
			that.craftUnion = that.getView().getModel("viewModel").getProperty("/Group");
			that.selInpValHelp = oEvent.getSource();
			that.selInpName = that.selInpValHelp.getName();
			var oRosterValue = oEvent.getSource().getValue().trim();
			var deptModel = that.getOwnerComponent().getModel("oDataSrv");
			deptModel.read("/UserDetailsSet(Uname='')", null, null, false,
				function (oData) {
					that.byId("positonIdInp").setValueState("None");
					if (oData.Unions === "SE") {
						that.dept = "Engineering";
					}
					if (oData.Unions === "SM") {
						that.dept = "Mechanical";
					}
					if (oData.Unions === "ST") {
						that.dept = "TCU";
					}
				}
			);
			//stores department value
			that.dept = that.craftUnion;
			if (!that.oDialog) {
				that.oDialog = sap.ui.xmlfragment("com.position.fragment.RoasterValueHelp", that.getView()
					.getController());
				that.getView().addDependent(that.oDialog);
			}
			that.oDialog.open();
			that.oDialog.setEscapeHandler(function (o) {
				o.reject();
			});
			if (oRosterValue !== "") {
				sap.ui.getCore().byId("RosterNoDescSearch").setValue(oRosterValue);
				sap.ui.getCore().byId("RosterNoDescSearch").fireSearch();
			} else {
				var engJsonPos = new sap.ui.model.json.JSONModel({});
				that.getView().setModel(engJsonPos, "RosterNoDescModelData");
			}
		},

		onRosterDropDown: function (oEvent) {
			var that = this;
			var name = oEvent.getSource().getName();
			var GrpValue = that.craftUnionfun();
			var CraftType = that.getView().getModel("oDataModel").getProperty("/Craft");
			var Territory = that.getView().getModel("oDataModel").getProperty("/Territory");
			var filters = [],
				modelName = "",
				key = "";
			if (name === "Union") {
				modelName = "UnionModelData";
				key = "U";
			} else if (name === "RR Code") {
				modelName = "rrModelData";
				key = "RR";
			} else if (name === "Region") {
				modelName = "RegionModelData";
				key = "RE";
			} else if (name === "Division") {
				modelName = "DivisionModelData";
				key = "D";
			} else if (name === "Craft") {
				modelName = "CraftModelData";
				key = "C";
			} else if (name === "Territory") {
				modelName = "TerritoryModelData";
				key = "T";
			} else if (name === "State") {
				modelName = "StateModelData";
				key = "S";
			}
			if (that.craftUnion === "Mechanical" || that.craftUnion === "SM" || that.craftUnion === "M") {
				filters.push(new sap.ui.model.Filter("CraftType", sap.ui.model.FilterOperator.EQ, CraftType));
				filters.push(new sap.ui.model.Filter("Territory", sap.ui.model.FilterOperator.EQ, Territory));
			}
			filters.push(new sap.ui.model.Filter("Key", sap.ui.model.FilterOperator.EQ, key));
			filters.push(new sap.ui.model.Filter("Value", sap.ui.model.FilterOperator.EQ, GrpValue));
			that.posIdDropDownSrv(filters, modelName, name);
		},
		RosterDropDownSrv: function (filters, modelName, name) {
			var that = this;
			var unionModel = that.getOwnerComponent().getModel();
			var titleInfo = that.getView().getModel("i18n").getProperty("titleInfo");
			unionModel.read("/RostDropDownsSet", {
				filters: filters,
				success: function (oData) {
					if (oData.results.length > 0) {
						if (name === "Gang") {
							var uniqDivArr = that.uniqueDropDownValFun(oData.results, "Value");
							oData = {
								results: uniqDivArr
							};
						}
						var oUninonModel = new JSONModel(oData);
						oUninonModel.setSizeLimit(oData.results.length);
						that.getView().setModel(oUninonModel, modelName);
					} else {
						var oDropDownModel = new JSONModel(oData);
						that.getView().setModel(oDropDownModel, modelName);
					}
				},
				error: function (oResponse) {
					if (name === "Division") {
						//-----------------------------------------------------------------------	
						// Displaying response body message.
						//-----------------------------------------------------------------------
						var oMessage;
						var mesLen = $(oResponse.response.body).find("message").first().prevObject.length;
						for (var i = 1; i < mesLen; i++) {
							var exception = $(oResponse.response.body).find("message").first().prevObject[i].innerText;
							if (exception !== "Exception raised without specific error") {
								var Message = $(oResponse.response.body).find("message").first().prevObject[i].innerText;
							} else {
								Message = "";
							}
							if (i === 1) {
								oMessage = Message;
							}
							if (i > 1) {
								oMessage = oMessage + "\r\n" + Message;
							}
						}
						if (oMessage === undefined) {
							oMessage = $(oResponse.response.body).find("message").first().prevObject[0].innerText;
						}
						sap.m.MessageBox.show(oMessage, {
							icon: sap.m.MessageBox.Icon.INFORMATION,
							title: titleInfo,
							actions: [sap.m.MessageBox.Action.OK],
							onClose: function (oAction) {}
						});
					} else {
						that.errorMessageforHelp(oResponse);
					}
				}
			});
		},
		onRosterDropDownSelChange: function (oEvent) {
			var that = this,
				filterKey,
				GrpValue, sFilters = [],
				name = oEvent.getSource().getName(),
				titleInfo = that.getView().getModel("i18n").getProperty("titleInfo"),
				selectText = oEvent.getParameter("selectedItem").getProperty("text"),
				srvModel = that.getOwnerComponent().getModel();
			GrpValue = that.craftUnionfun();
			if (name === "Union") {
				filterKey = "Union";
			} else if (name === "State") {
				filterKey = "State";
			} else if (name === "Division") {
				filterKey = "Divison";
				selectText = selectText.replace(/&/g, "%26");
			} else if (name === "Gang") {
				filterKey = "GangId";
			} else if (name === "AgreementCode") {
				filterKey = "AgreementCode";
			}
			sFilters.push(new sap.ui.model.Filter(filterKey, sap.ui.model.FilterOperator.EQ, selectText));
			sFilters.push(new sap.ui.model.Filter("Key", sap.ui.model.FilterOperator.EQ, GrpValue));
			srvModel.read("/PositionSearchHelpSet", {
				filters: sFilters,
				success: function (oData) {
					if (oData.results.length > 0) {
						var oUninonModel = new JSONModel(oData.results);
						that.getView().setModel(oUninonModel, "positionModelData");
						// that.getView().getModel("visibleModel").setProperty("/posGlobalTable", true);
					} else {
						// that.getView().getModel("visibleModel").setProperty("/posGlobalTable", false);
					}
				},
				error: function (oResponse) {
					that.errorMessageforHelp(oResponse, titleInfo);
					that.getView().getModel("visibleModel").setProperty("/posGlobalTable", false);
				}
			});
		},
		HandleRoasterTabSelect: function (oEvent) {
			var that = this,
				selKey = oEvent.getSource().getSelectedKey();
			that.getView().getModel("viewModel").setProperty("/RoasterTabSelKey", selKey);
		},
		onRosterSearch: function (oEvent) {
			var that = this,
				GrpValue, sFilters = [];
			var searchValue = oEvent.getSource().getValue();
			var SeltedKeyTabbar = oEvent.getSource().getParent().getParent().getKey();
			var oModel = that.getOwnerComponent().getModel();
			var CraftType = that.getView().getModel("oDataModel").getProperty("/Craft");
			var Territory = that.getView().getModel("oDataModel").getProperty("/Territory");
			if (SeltedKeyTabbar === "Roster Number or Desc") {
				sFilters.push(new sap.ui.model.Filter("RosterNo", sap.ui.model.FilterOperator.EQ, searchValue));
			} else if (SeltedKeyTabbar === "District") {
				sFilters.push(new sap.ui.model.Filter("District", sap.ui.model.FilterOperator.EQ, searchValue));
			} else if (SeltedKeyTabbar === "City") {
				sFilters.push(new sap.ui.model.Filter("City", sap.ui.model.FilterOperator.EQ, searchValue));
			} else if (SeltedKeyTabbar === "Department") {
				sFilters.push(new sap.ui.model.Filter("Department", sap.ui.model.FilterOperator.EQ, searchValue));
			}
			GrpValue = that.craftUnionfun();
			if (that.craftUnion === "SD") {
				GrpValue = "A";
			}
			sFilters.push(new sap.ui.model.Filter("Key", sap.ui.model.FilterOperator.EQ, GrpValue));
			if (that.craftUnion === "Mechanical" || that.craftUnion === "SM" || that.craftUnion === "M") {
				sFilters.push(new sap.ui.model.Filter("CraftType", sap.ui.model.FilterOperator.EQ, CraftType));
				sFilters.push(new sap.ui.model.Filter("Territory", sap.ui.model.FilterOperator.EQ, Territory));
			}
			oModel.read("/RostSearchHelpSet", {
				filters: sFilters,
				success: function (oData) {
					if (oData.results.length > 0) {
						var oUninonModel = new JSONModel(oData);
						that.getView().setModel(oUninonModel, "RosterNoDescModelData");
						that.getView().getModel("visibleModel").setProperty("/posGlobalTable", true);
					} else {
						var oModel1 = new JSONModel([]);
						that.getView().setModel(oModel1, "-+2qa	Z");
						that.getView().getModel("visibleModel").setProperty("/posGlobalTable", false);
					}
				},
				error: function (oResponse) {
					that.getView().getModel("visibleModel").setProperty("/posGlobalTable", false);
					that.errorMessageforHelp(oResponse);
				}
			});
		},
		onRosterSubmit: function (oEvent) {
			var that = this,
				selTabKey = that.getView().getModel("viewModel").getProperty("/RoasterTabSelKey"),
				Group = that.getView().getModel("viewModel").getProperty("/Group"),
				context = oEvent.getSource().getBindingContext("RosterNoDescModelData"),
				data = context.getModel().getProperty(context.getPath());
			if (that.selInpName === "roster") {
				that.selInpValHelp.setValue(data.RosterNo);
				that.getView().getModel("oDataModel").setProperty("/RosterNo", data.RosterNo);
				that.getView().getModel("oDataModel").setProperty("/RostDesc", data.RostDesc);
			} else if (that.selInpName === "priorRightsRoster") {
				that.selInpValHelp.setValue(data.RosterNo);
				that.getView().getModel("oDataModel").setProperty("/PriorRightsRosterNo", data.RosterNo);
				that.getView().getModel("oDataModel").setProperty("/PriorRightsRostDesc", data.RostDesc);
			} else if (that.selInpName === "RosterNo") {
				that.selInpValHelp.setValue(data.RosterNo);
				that.getView().getModel("oDataModel").setProperty("/RosterNo", data.RosterNo);
				that.getView().getModel("oDataModel").setProperty("/RostDesc", data.RostDesc);
			}
			that.posChangeFlag = "X";
			that.oDialog.close();
			that.oDialog.destroy();
			that.oDialog = null;
		},
		/* Roaster Value Hepls end */
		/* Work Schedule Value Hepls start */
		onWorkSchValueHelp: function (oEvent) {
			var that = this;
			if (!that.oDialog) {
				that.oDialog = sap.ui.xmlfragment("com.position.fragment.WorkSch", this.getView()
					.getController());
				that.getView().addDependent(that.oDialog);
			}
			that.oDialog.open();
			that.oDialog.setEscapeHandler(function (o) {
				o.reject();
			});
		},
		onWSSearch: function (oEvent) {
			var serchValue = oEvent.getSource().getValue();
			var SeltedKeyTabbar = sap.ui.getCore().byId("posSearchTabBar").getSelectedKey();
			var oBinding = sap.ui.getCore().byId("workSchSearchHelpTable").getBinding("items");
			var oFilters = [new sap.ui.model.Filter(SeltedKeyTabbar, sap.ui.model.FilterOperator.EQ, serchValue)];
			var filterObj = new sap.ui.model.Filter(oFilters, true);
			oBinding.filter(filterObj);
			sap.ui.getCore().byId("workSchSearchHelpTable").setVisible(true);

		},
		onStChange: function () {
			var starttime = sap.ui.getCore().byId("wrkStartTime").getValue();
			var endtime = sap.ui.getCore().byId("wrkEndTime").getValue();
			var oBinding = sap.ui.getCore().byId("workSchSearchHelpTable").getBinding("items");
			if (starttime !== "000000" && endtime !== "000000" && starttime !== "" && endtime !== "") {
				var oFilters = [new sap.ui.model.Filter("ShiftStatTime", sap.ui.model.FilterOperator.EQ, starttime),
					new sap.ui.model.Filter("ShiftEndTime", sap.ui.model.FilterOperator.EQ, endtime)
				];
				var filterObj = new sap.ui.model.Filter(oFilters, true);
				oBinding.filter(filterObj);
				sap.ui.getCore().byId("workSchSearchHelpTable").setVisible(true);
			}

		},
		_OnWorkSchFunc: function (oShiftTime, oRestDays) {
			var that = this;
			var shTIme1 = oShiftTime;
			var restDays = oRestDays;
			var shTimePreVal = that.ShiftTimeValues;
			if (shTimePreVal !== undefined) {
				shTimePreVal = shTimePreVal.split("-")[0];
			} else {
				shTimePreVal = "00:00:00";
			}
			var sht1 = Number(shTIme1.split(":")[0]);
			var shp = Number(shTimePreVal.split(":")[0]);
			var shDiff = sht1 - shp;
			var shStr = shDiff.toString();
			if (this.CurrentOcup !== "Vacant") {
				if ((Math.abs(shDiff) >= 2) || (restDays !== that.RestDayValues)) {
					// sap.m.MessageBox.warning(
					// 	"Position is currently occupied.  The edit entered may require this position to be abolished and a bump created for the employee(s) holding this position."
					// );
				}
			}
		},
		onWorkSchIdSubmit: function (oEvent) {
			var that = this;
			if (that.craftUnion === "E" || that.craftUnion === "SE") {
				this.engBullFlag = "X";
				that.getView().getModel("oDataModel").setProperty("/ShiftStatTime", oEvent.getSource().getCells()[2].getText().split("-")[0]);
				that.getView().getModel("oDataModel").setProperty("/ShiftEndTime", oEvent.getSource().getCells()[2].getText().split("-")[1]);
				that.getView().getModel("oDataModel").setProperty("/RestDays", oEvent.getSource().getCells()[3].getText());
				that.getView().getModel("oDataModel").setProperty("/BreakDuration", oEvent.getSource().getCells()[4].getText());
				var shTime1 = oEvent.getSource().getCells()[2].getText();
				var restDay1 = oEvent.getSource().getCells()[3].getText();
				that._OnWorkSchFunc(shTime1, restDay1);
			} else if (that.craftUnion === "M" || that.craftUnion === "SM") {
				that.getView().getModel("oDataModel").setProperty("/WorkSch", oEvent.getSource().getCells()[0].getText());
				that.getView().getModel("oDataModel").setProperty("/ShiftStatTime", oEvent.getSource().getCells()[2].getText().split("-")[0]);
				that.getView().getModel("oDataModel").setProperty("/ShiftEndTime", oEvent.getSource().getCells()[2].getText().split("-")[1]);
				that.getView().getModel("oDataModel").setProperty("/RestDays", oEvent.getSource().getCells()[3].getText());
				that.getView().getModel("oDataModel").setProperty("/BreakDuration", oEvent.getSource().getCells()[4].getText());
				var shTime2 = oEvent.getSource().getCells()[2].getText();
				var restDay2 = oEvent.getSource().getCells()[3].getText();
				that._OnWorkSchFunc(shTime2, restDay2);
				that.bullFlag = "X";
				if (oEvent.getSource().getCells()[3].getText().length > 0) {
					that.getView().getModel("oDataModel").setProperty("/Monday", "");
					that.getView().getModel("oDataModel").setProperty("/Tuesday", "");
					that.getView().getModel("oDataModel").setProperty("/Wednesday", "");
					that.getView().getModel("oDataModel").setProperty("/Thursday", "");
					that.getView().getModel("oDataModel").setProperty("/Friday", "");
					that.getView().getModel("oDataModel").setProperty("/Saturday", "");
					that.getView().getModel("oDataModel").setProperty("/Sunday", "");
					var restDays = oEvent.getSource().getCells()[3].getText().split("/");
					for (var i = 0; i < restDays.length; i++) {
						if (restDays[i] === "MONDAY") {
							that.getView().getModel("oDataModel").setProperty("/Monday", "RD");
						} else if (restDays[i] === "TUESDAY") {
							that.getView().getModel("oDataModel").setProperty("/Tuesday", "RD");
						} else if (restDays[i] === "WEDNESDAY") {
							that.getView().getModel("oDataModel").setProperty("/Wednesday", "RD");
						} else if (restDays[i] === "THURSDAY") {
							that.getView().getModel("oDataModel").setProperty("/Thursday", "RD");
						} else if (restDays[i] === "FRIDAY") {
							that.getView().getModel("oDataModel").setProperty("/Friday", "RD");
						} else if (restDays[i] === "SATURDAY") {
							that.getView().getModel("oDataModel").setProperty("/Saturday", "RD");
						} else if (restDays[i] === "SUNDAY") {
							that.getView().getModel("oDataModel").setProperty("/Sunday", "RD");
						}
					}
					that.getView().getModel("oDataModel").updateBindings(true);
				}

			} else if (that.craftUnion === "L" || that.craftUnion === "A" || that.craftUnion === "D" || that.craftUnion === "SD" || that.craftUnion ===
				"T" ||
				that.craftUnion === "ST" || that.craftUnion === "SL") {
				that.getView().getModel("oDataModel").setProperty("/WorkSch", oEvent.getSource().getCells()[0].getText());
				that.getView().getModel("oDataModel").setProperty("/ShiftStatTime", oEvent.getSource().getCells()[2].getText().split("-")[0]);
				that.getView().getModel("oDataModel").setProperty("/ShiftEndTime", oEvent.getSource().getCells()[2].getText().split("-")[1]);
				that.getView().getModel("oDataModel").setProperty("/RestDays", oEvent.getSource().getCells()[3].getText());
				that.getView().getModel("oDataModel").setProperty("/BreakDuration", oEvent.getSource().getCells()[4].getText());
				var shTime3 = oEvent.getSource().getCells()[2].getText();
				var restDay3 = oEvent.getSource().getCells()[3].getText();
				that._OnWorkSchFunc(shTime3, restDay3);
				that.tcuDepChangeFlag = "X";
				// this.onTcuWrkSchChange();
				if (this.getView().getModel("oDataModel").getProperty("/WorkSch") === "FLEXIBLE") {
					this.getView().byId("tcnote").setVisible(true);
				} else {
					this.getView().byId("tcnote").setVisible(false);
				}
			} else if (that.craftUnion === "I" || that.craftUnion === "SI" || that.craftUnion === "N" || that.craftUnion === "SN" || that.craftUnion ===
				"C" ||
				that.craftUnion === "SC") {
				that.getView().getModel("oDataModel").setProperty("/WorkSchd", oEvent.getSource().getCells()[0].getText());
				that.getView().getModel("oDataModel").setProperty("/ShiftStartTime", oEvent.getSource().getCells()[2].getText().split("-")[0]);
				that.getView().getModel("oDataModel").setProperty("/ShiftEndTime", oEvent.getSource().getCells()[2].getText().split("-")[1]);
				that.getView().getModel("oDataModel").setProperty("/RestDays", oEvent.getSource().getCells()[3].getText());
				that.getView().getModel("oDataModel").setProperty("/BreakDuration", oEvent.getSource().getCells()[4].getText());
				var shTime4 = oEvent.getSource().getCells()[2].getText();
				var restDay4 = oEvent.getSource().getCells()[3].getText();
				that._OnWorkSchFunc(shTime4, restDay4);
				that.posChangeFlag = "X";
				// this.onTcuWrkSchChange();
			}
			that.oDialog.close();
			that.oDialog.destroy();
			that.oDialog = null;
			that.bullComment = true;
			that.sChange = true;
			this.posChangeFlag = "X";
		},
		/* Work schedule Value Hepls end */
		onSelectionChange: function (oEvent) {
			var that = this;
			if (oEvent.getSource().getValue() !== "" || oEvent.getSource().getSelectedKey() !== "") {
				that.posChangeFlag = "X";
			}
			if (oEvent.getSource().getName() === "Craft") {
				that.getView().getModel("oDataModel").setProperty("/Territory", "");
				that.getView().getModel("oDataModel").setProperty("/RosterNo", "");
				that.getView().getModel("oDataModel").setProperty("/RostDesc", "");
			} else if (oEvent.getSource().getName() === "Territory") {
				that.getView().getModel("oDataModel").setProperty("/RosterNo", "");
				that.getView().getModel("oDataModel").setProperty("/RostDesc", "");
				that.onTerrtiryChange();
			} else if (oEvent.getSource().getName() === "rosterM") {
				that.getView().getModel("oDataModel").setProperty("/RosterNo", oEvent.getSource().getValue());
				that.getView().getModel("oDataModel").setProperty("/RostDesc", oEvent.getSource().getValue());
			}
			that.posChangeFlag = "X";
		},
		onInpChange: function (oEvent) {
			if (oEvent.getSource().getValue() !== "") {
				this.posChangeFlag = "X";
			}
		},
		onValueChange: function (oEvent) {
			var that = this,
				craftId, oSearchParam;
			that.bullFlag = false;
			if (oEvent.getSource().getValue() === "") {
				oEvent.getSource().setValueState("None");
				if (oEvent.getSource().getName() === "Craft") {
					that.byId("changeMechTerriId").setEnabled(false);
				}
			}
			oSearchParam = oEvent.getSource().getValue();

			if (oEvent.getSource().getName() === "Craft") {
				craftId = oEvent.getSource().getSelectedKey();
				that.craftKey = oEvent.getSource().getSelectedKey();
				that.onCraftChange(oSearchParam, craftId, oEvent);
			}
			this.posChangeFlag = "X";
		},
		onPRdateChange: function (oEvt) {
			if (oEvt) {
				var oDP = oEvt.getSource();
				var bValid = oEvt.getParameter("valid");
				if (!bValid) {
					oEvt.getSource().setValue("");
					oDP.setValueState(sap.ui.core.ValueState.Error);
					sap.m.MessageToast.show("Please enter valid date");
					return;
				}
				oDP.setValueState(sap.ui.core.ValueState.None);
			}
			this.posChangeFlag = "X";
		},
		onTCUATDARosterClear: function (oEvent) {
			if (oEvent.getSource().getValue().trim().length < 1) {
				this.getView().getModel("oDataModel").setProperty("/RostDesc", "");
			}
		},
		onTerrtiryChange: function () {
			var that = this,
				sFilters = [];
			var mechTerritory = that.getView().byId("rosterId");
			var CraftType = that.getView().getModel("oDataModel").getProperty("/Craft");
			var Territory = that.getView().getModel("oDataModel").getProperty("/Territory");
			var GrpValue = that.craftUnionfun();
			var rosterModel = that.getOwnerComponent().getModel("oDataSrv");
			sFilters.push(new sap.ui.model.Filter("Key", sap.ui.model.FilterOperator.EQ, GrpValue));
			sFilters.push(new sap.ui.model.Filter("CraftType", sap.ui.model.FilterOperator.EQ, CraftType));
			sFilters.push(new sap.ui.model.Filter("Territory", sap.ui.model.FilterOperator.EQ, Territory));
			rosterModel.read("/RostSearchHelpSet", {
				filters: sFilters,
				success: function (oData) {
					if (oData.results.length > 0) {
						var rostrArr = [];
						for (var d = 0; d < oData.results.length; d++) {
							var rosterObj = {};
							rosterObj.RosterNo = oData.results[d].RosterNo;
							rosterObj.RostDesc = oData.results[d].RostDesc;
							rostrArr.push(rosterObj);
						}
						var rosterModelData = new sap.ui.model.json.JSONModel({
							results: rostrArr
						});
						sap.ui.getCore().setModel(rosterModelData, "RosterNoDescModelData");
						mechTerritory.setModel(rosterModelData, "RosterNoDescModelData");
						var oTerritoryTemp = new sap.ui.core.ListItem({
							key: "{RosterNoDescModelData>RostDesc}",
							text: "{RosterNoDescModelData>RosterNo}",
							additionalText: "{RosterNoDescModelData>RosterNo}"
						});
						mechTerritory.bindItems({
							path: 'RosterNoDescModelData>/results',
							template: oTerritoryTemp
						});
					} else {
						var rosterModelData = new sap.ui.model.json.JSONModel({
							results: []
						});
						sap.ui.getCore().setModel(rosterModelData, "RosterNoDescModelData");
						mechTerritory.setModel(rosterModelData, "RosterNoDescModelData");
					}
				},
				error: function (oResponse) {
					var rosterModelData = new sap.ui.model.json.JSONModel({
						results: []
					});
					sap.ui.getCore().setModel(rosterModelData, "RosterNoDescModelData");
					mechTerritory.setModel(rosterModelData, "RosterNoDescModelData");
					that.getView().getModel("visibleModel").setProperty("/posGlobalTable", false);
					that.errorMessageforHelp(oResponse);
				}
			});
		},
		onCraftChange: function (oSearchParam, craftId, oEvent) {
			var that = this;
			var craftSuggModel = that.getView().getModel("CraftModel");
			var CraftData = craftSuggModel.getData();
			var validationATrue = [];
			var validationAFalse = [];
			var validation = "X";
			for (var k = 0; k < CraftData.results.length; k++) {
				if (CraftData.results[k].Craft !== oSearchParam && CraftData.results[k].CraftId !== oSearchParam) {
					validationATrue.push(validation);
				} else {
					validationAFalse.push(validation);
				}
			}
			if (validationAFalse.length > 0) {
				oEvent.getSource().setValueState("None");
				var TerritoryModel = that.getOwnerComponent().getModel("oDataSrv");
				TerritoryModel.read("/TerritorySearchHelpSet?$filter=CraftId eq '" + craftId + "'", null, null, false,
					function (oData, oResponse) {
						if (oData.results.length > 0) {
							oEvent.getSource().setEnabled(true);
							var mechTerritory = that.getView().byId("changeMechTerriId");
							var mechTerritoryArray = [];
							for (var d = 0; d < oData.results.length; d++) {
								var mechTerritoryObj = {};
								mechTerritoryObj.CraftId = oData.results[d].CraftId;
								mechTerritoryObj.Territory = oData.results[d].Territory;
								mechTerritoryArray.push(mechTerritoryObj);
							}
							var mechTerritoryModel = new sap.ui.model.json.JSONModel({
								results: mechTerritoryArray
							});
							sap.ui.getCore().setModel(mechTerritoryModel, "TerritoryModel");
							mechTerritory.setModel(mechTerritoryModel, "TerritoryModel");
							var oTerritoryTemp = new sap.ui.core.ListItem({
								key: "{TerritoryModel>Territory}",
								text: "{TerritoryModel>Territory}",
								additionalText: "{TerritoryModel>CraftId}"
							});
							mechTerritory.bindItems({
								path: 'TerritoryModel>/results',
								template: oTerritoryTemp
							});
						}
					},
					function (oResponse) {
						that.errorMessageforHelp(oResponse, "Error");
					}
				);
			} else {
				if (sap.ui.getCore().byId("changeMechraftId").getValue() !== "") {
					sap.ui.getCore().byId("changeMechraftId").setValueState("Error");
					sap.m.MessageBox.show("No records found", {
						icon: sap.m.MessageBox.Icon.ERROR,
						title: "Error",
						actions: [sap.m.MessageBox.Action.OK],
						onClose: function (oAction) {
							if (oAction === sap.m.MessageBox.Action.OK) {}
						}
					});
				}
			}
		},
		onSelectIconTabBar: function () {
			var that = this;
			if (that.getView().getModel("positionModelData") !== undefined) {
				that.getView().getModel("positionModelData").setData([]);
			}
			that.getView().getModel("visibleModel").setProperty("/posGlobalTable", false);
			that.getView().getModel("viewModel").setProperty("/posIdSearchValue", "");
		},
		onQualValueHelpReq: function () {
			var that = this;
			var craft = "";
			if (!that._qualIdValueDialog) {
				that._qualIdValueDialog = sap.ui.xmlfragment("com.position.fragment.Qualification", that.getView()
					.getController());
				that.getView().addDependent(that._qualIdValueDialog);
			}
			that._qualIdValueDialog.open();
			that._qualIdValueDialog.setEscapeHandler(function (o) {
				o.reject();
			});
			if (this.byId("qualifIdInp").getTokens().length !== 0) {
				this.onQualSChange();
			}
			var oPage = sap.ui.getCore().byId("qualDialogue");
			oPage.setBusy(true);
			oPage.setBusyIndicatorDelay(0);
			var qualModel = that.getOwnerComponent().getModel("oDataSrv");
			qualModel.read("/QualSearchhelpSet?$filter=Craft eq '" + that.craftUnion + "'and EffectiveDate eq '" + that.byId("dateRangeId").getValue() +
				"'", null, null, false,
				function (oData, oResponse) {
					oPage.setBusy(false);
					var qualJsonModel = new JSONModel(oData);
					that.getView().setModel(qualJsonModel, "qualIdModel");
				},
				function () {
					oPage.setBusy(false);
				}
			);
		},

		onQualIdSubmit: function (oEvent) {
			var oSelectedQualId = oEvent.getParameter("selectedItem").getProperty("title");
			var oSelectedQualDesc = oEvent.getParameter("selectedItem").getProperty("description");
			this.byId("qualifIdInp").setTokens([new sap.m.Token({
				text: oSelectedQualId,
				key: oSelectedQualId
			})]);
			this.getView().getModel("viewModel").setProperty("/qualTitieIdVal", oSelectedQualDesc);
			this.sChange = true;
			this.getView().getModel("visibleModel").setProperty("/submitBtnEnable", false);
		},
		onQualAdd: function () {
			var that = this;
			var qualModel = that.getOwnerComponent().getModel("oDataSrv");
			var viewModel = that.getView().getModel("viewModel").getData();
			var craftType = viewModel.craftTxt;
			if (craftType === "Engineering") {
				craftType = "ENG";
			} else if (craftType === "Mechanical") {
				craftType = "MECH";
			} else if (craftType === "TCU") {
				craftType = "TCU";
			}
			var cDate = new Date();
			var dateFormat = sap.ui.core.format.DateFormat.getDateInstance({
				pattern: "MM/dd/yyyy"
			});
			var sStartDte = dateFormat.format(cDate);
			var qual = viewModel.QualNameId;
			var startDate = viewModel.qulEffectDate;
			var endDate = viewModel.qulEndDate;
			var positionId = "",
				stDate = "",
				quSdate = "",
				fdate = "",
				quEnddate = "",
				enDate = "";
			if (that.byId("positonIdInp").getTokens().length !== 0) {
				positionId = that.byId("positonIdInp").getTokens()[0].getKey();
			}
			var positionIdValueState = that.byId("positonIdInp").getValueState();
			if (startDate !== "") {
				stDate = startDate;
				fdate = startDate.split("/");
				quSdate = fdate[2] + fdate[0] + fdate[1];
			}
			if (endDate !== "") {
				enDate = endDate;
				var qfdate = endDate.split("/");
				quEnddate = qfdate[2] + qfdate[0] + qfdate[1];
			}
			var oResults = that.getView().byId("selectedQualTable").getModel("oModelData");
			if (oResults !== undefined) {
				if (positionId === "") {
					//sap.m.MessageToast.show("Please enter Position ID");
					sap.m.MessageBox.show("Please enter Position ID", {
						icon: sap.m.MessageBox.Icon.ERROR,
						title: "Warning",
						actions: [sap.m.MessageBox.Action.OK]
					});
					that.byId("positonIdInp").setValueState("Error");
				} else if (positionIdValueState === "Error") {
					sap.m.MessageBox.show("Please enter valid Position", {
						icon: sap.m.MessageBox.Icon.ERROR,
						title: "Warning",
						actions: [sap.m.MessageBox.Action.OK]
					});
				} else if (that.byId("qualifIdInp").getTokens().length === 0) {
					sap.m.MessageBox.show("Please enter Qualification", {
						icon: sap.m.MessageBox.Icon.ERROR,
						title: "Warning",
						actions: [sap.m.MessageBox.Action.OK]
					});
				} else if (viewModel.QualNameId === "" || that.byId("qualifIdInp").getValueState() === "Error") {
					sap.m.MessageBox.show("Please enter valid Qualification", {
						icon: sap.m.MessageBox.Icon.ERROR,
						title: "Warning",
						actions: [sap.m.MessageBox.Action.OK]
					});
				} else if (viewModel.qulEffectDate === "") {
					sap.m.MessageBox.show("Please enter Start Date", {
						icon: sap.m.MessageBox.Icon.ERROR,
						title: "Warning",
						actions: [sap.m.MessageBox.Action.OK]
					});
				} else if (viewModel.qulEndDate === "") {
					sap.m.MessageBox.show("Please enter End Date", {
						icon: sap.m.MessageBox.Icon.ERROR,
						title: "Warning",
						actions: [sap.m.MessageBox.Action.OK]
					});
				} else if (that.byId("qualStartDateId").getValueState() === "Error") {
					sap.m.MessageBox.show("Please enter Valid Start Date", {
						icon: sap.m.MessageBox.Icon.ERROR,
						title: "Error",
						actions: [sap.m.MessageBox.Action.OK]
					});
				} else if (that.byId("qualEndDateId").getValueState() === "") {
					sap.m.MessageBox.show("Please enter Valid Start Date", {
						icon: sap.m.MessageBox.Icon.ERROR,
						title: "Error",
						actions: [sap.m.MessageBox.Action.OK]
					});
				} else if (new Date(viewModel.qulEndDate) < new Date(viewModel.qulEffectDate)) {
					sap.m.MessageBox.show("End Date cannot be less than Start/Effective Date!", {
						icon: sap.m.MessageBox.Icon.ERROR,
						title: "Error",
						actions: [sap.m.MessageBox.Action.OK]
					});
				} else {
					that.byId("positonIdInp").setValueState("None");
					qualModel.read("/QualdetUpdateSet?$filter=CraftType eq '" + craftType + "' and Qualification eq '" + qual +
						"' and QualSdate eq '" + quSdate + "' and PosId eq ' " + positionId + "'and EffectiveDate eq '' and QualEdate eq '" +
						quEnddate +
						"'", null, null,
						false,
						function (oData, oResponse) {
							that.byId("qualStartDateId").setValueState("None");
							that.byId("qualEndDateId").setValueState("None");
							var betweenDatesArray = [],
								createTableObj = {},
								extendDatesArray = [],
								newDatesArray = [],
								existQualArray = [],
								check = "X",
								cdlCheck = false,
								resultsData = oResults.getData(),
								qualTable = that.getView().byId("selectedQualTable");
							for (var h = 0; h < resultsData.results.length; h++) {
								var existStDate = resultsData.results[h].QualSdate,
									existEnDate = resultsData.results[h].QualEdate,
									existQual = resultsData.results[h].QualId;
								if (that.byId("qualifIdInp").getTokens()[0].getKey().substring(0, 3) === "CDL") {
									if (resultsData.results[h].Qualification.substring(0, 3) === "CDL") {
										cdlCheck = true;
									}
								}
								if (qual === existQual) {
									if (new Date(stDate) >= new Date(existStDate) && new Date(enDate) <= new Date(existEnDate)) {
										betweenDatesArray.push(check);
									} else if (new Date(stDate) >= new Date(existStDate) && new Date(enDate) > new Date(existEnDate) && new Date(stDate) <=
										new Date(
											existEnDate)) {
										extendDatesArray.push(check);
									} else if (new Date(stDate) > new Date(existEnDate) && new Date(enDate) > new Date(stDate)) {
										newDatesArray.push(check);
									}
								} else {
									existQualArray.push();
								}
							}
							if (betweenDatesArray.length > 0) {
								sap.m.MessageBox.show("Qualification is already assigned to this position", {
									icon: sap.m.MessageBox.Icon.ERROR,
									title: "Error",
									actions: [sap.m.MessageBox.Action.OK]
								});
							} else if (cdlCheck) {
								sap.m.MessageBox.show("Position Should have only 1 active CDL Qualification", {
									icon: sap.m.MessageBox.Icon.ERROR,
									title: "Error",
									actions: [sap.m.MessageBox.Action.OK]
								});
							} else if (extendDatesArray.length > 0) {
								sap.m.MessageBox.show("The qualification has been assigned already, please adjust end date accordingly", {
									icon: sap.m.MessageBox.Icon.ERROR,
									title: "Error",
									actions: [sap.m.MessageBox.Action.OK]
								});
							} else if (newDatesArray.length > 0) {
								createTableObj.Qualification = that.byId("qualifIdInp").getTokens()[0].getKey();
								createTableObj.QualId = that.getView().getModel("viewModel").getProperty("/QualNameId");
								createTableObj.QualDesc = that.getView().getModel("viewModel").setProperty("/QualNameIdDesc");
								createTableObj.QualSdate = stDate;
								createTableObj.QualEdate = enDate;
								createTableObj.QualProflevel = "Yes";
								createTableObj.ChangedOn = "";
								createTableObj.ChangedBy = "";
								createTableObj.rowKey = "F";
								resultsData.results.push(createTableObj);
								oResults.setData(resultsData);
								qualTable.setModel(oResults, "oModelData");
								that.byId("selectedQualTable").getModel("oModelData").refresh();
								that.getModel("visibleModel").setProperty("/submitBtnEnable", true);
								that.byId("qualifIdInp").setWidth("70%");
								that.byId("qualifIdInp").setTokens([]);
								that.getView().getModel("viewModel").setProperty("/qualTitieIdVal", "");
								that.getView().getModel("viewModel").setProperty("/qulEffectDate", sStartDte);
								that.getView().getModel("viewModel").setProperty("/qulEndDate", "99991231");
							} else if (existQualArray.length === 0) {
								createTableObj.Qualification = that.byId("qualifIdInp").getTokens()[0].getKey();
								createTableObj.QualId = that.getView().getModel("viewModel").getProperty("/QualNameId");
								createTableObj.QualDesc = that.getView().getModel("viewModel").setProperty("/QualNameIdDesc");
								createTableObj.QualSdate = stDate;
								createTableObj.QualEdate = enDate;
								createTableObj.QualProflevel = "Yes";
								createTableObj.ChangedOn = "";
								createTableObj.ChangedBy = "";
								createTableObj.rowKey = "F";
								resultsData.results.push(createTableObj);
								oResults.setData(resultsData);
								qualTable.setModel(oResults, "oModelData");
								that.byId("selectedQualTable").getModel("oModelData").refresh();
								that.getModel("visibleModel").setProperty("/submitBtnEnable", true);
								that.byId("qualifIdInp").setTokens([]);
								that.byId("qualifIdInp").setWidth("70%");
								that.getView().getModel("viewModel").setProperty("/qualTitieIdVal", "");
								that.getView().getModel("viewModel").setProperty("/QualNameIdName", "");
								that.getView().getModel("viewModel").setProperty("/QualNameId", "");
								that.getView().getModel("viewModel").setProperty("/QualNameIdDesc", "");
								that.getView().getModel("viewModel").setProperty("/qulEffectDate", sStartDte);
								that.getView().getModel("viewModel").setProperty("/qulEndDate", "99991231");
							}
						},
						function (oResponse) {
							//-----------------------------------------------------------------------	
							// Displaying response body message.
							//-----------------------------------------------------------------------
							var oMessage = JSON.parse(oResponse.response.body).error.innererror.errordetails[0].message;
							var msg = oMessage;
							var splitMsg = msg.split(":");
							var msgCode = splitMsg[0];
							var message = splitMsg[1];

							var errmsg;
							if (oMessage === "") {

								errmsg = oResponse.response.body;
							} else {
								// errmsg = oMessage;
								errmsg = message;
							}

							sap.m.MessageBox.show(errmsg, {
								icon: sap.m.MessageBox.Icon.ERROR,
								title: "Error",
								actions: [sap.m.MessageBox.Action.OK],
								onClose: function (oAction) {
									if (oAction === sap.m.MessageBox.Action.OK) {
										if (msgCode === "S") {
											that.byId("qualStartDateId").setValueState("Error");
											that.getView().getModel("viewModel").setProperty("/qulEffectDate", "");
										} else if (msgCode === "E") {
											that.byId("qualEndDateId").setValueState("Error");
											that.getView().getModel("viewModel").setProperty("/qulEndDate", "");
										}
										that.getView().getModel("viewModel").setProperty("/qulEffectDate", sStartDte);
										that.getView().getModel("viewModel").setProperty("/qulEndDate", "99991231");
									}
								}
							});
						}
					);
				}
			} else {
				if (positionId === "") {
					//sap.m.MessageToast.show("Please enter Position ID");
					sap.m.MessageBox.show("Please enter Position ID", {
						icon: sap.m.MessageBox.Icon.ERROR,
						title: "Error",
						actions: [sap.m.MessageBox.Action.OK]
					});
					that.byId("positonIdInp").setValueState("Error");
				} else if (positionIdValueState === "Error") {
					//sap.m.MessageToast.show("Please enter valid Position");
					sap.m.MessageBox.show("Please enter valid Position", {
						icon: sap.m.MessageBox.Icon.ERROR,
						title: "Error",
						actions: [sap.m.MessageBox.Action.OK]
					});
				} else if (that.byId("qualifIdInp").getTokens().length === 0) {
					//	sap.m.MessageToast.show("Please enter Qualification");
					sap.m.MessageBox.show("Please enter Qualification", {
						icon: sap.m.MessageBox.Icon.ERROR,
						title: "Error",
						actions: [sap.m.MessageBox.Action.OK]
					});
				} else if (viewModel.qulEffectDate === "") {
					//sap.m.MessageToast.show("Please enter Start Date");
					sap.m.MessageBox.show("Please enter Start Date", {
						icon: sap.m.MessageBox.Icon.ERROR,
						title: "Error",
						actions: [sap.m.MessageBox.Action.OK]
					});
				} else if (viewModel.qulEndDate === "") {
					//	sap.m.MessageToast.show("Please enter End Date");
					sap.m.MessageBox.show("Please enter End Date", {
						icon: sap.m.MessageBox.Icon.ERROR,
						title: "Error",
						actions: [sap.m.MessageBox.Action.OK]
					});
				} else {
					that.byId("positonIdInp").setValueState("None");
					qualModel.read("/QualdetUpdateSet?$filter=CraftType eq '" + craftType + "' and Qualification eq '" + qual +
						"' and QualSdate eq '" +
						startDate + "' and PosId eq '" + positionId + "'and EffectiveDate eq '" + that.byId("dateRangeId").getValue() +
						"' and QualEdate eq '" + endDate + "'", null,
						null,
						false,
						function (oData, oResponse) {
							that.byId("qualStartDateId").setValueState("None");
							that.byId("qualEndDateId").setValueState("None");
							var createTableArray = [];
							var createTableObj = {};
							createTableObj.Qualification = that.byId("qualifIdInp").getTokens()[0].getKey();
							createTableObj.QualId = that.getView().getModel("viewModel").getProperty("/QualNameId");
							createTableObj.QualDesc = that.getView().getModel("viewModel").getProperty("/QualNameIdDesc");
							createTableObj.QualSdate = stDate;
							createTableObj.QualEdate = enDate;
							createTableObj.QualProflevel = "Yes";
							createTableObj.ChangedOn = "";
							createTableObj.ChangedBy = "";
							createTableObj.rowKey = "F";
							createTableArray.push(createTableObj);
							var addRowUniqQualArr1 = that.addRownique(createTableArray);
							var oQualTableModel = new sap.ui.model.json.JSONModel({
								"results": addRowUniqQualArr1
							});
							var oQalTable = that.getView().byId("selectedQualTable");
							oQalTable.setModel(oQualTableModel, "oModelData");
							that.byId("selectedQualTable").getModel("oModelData").refresh();
							that.getModel("visibleModel").setProperty("/submitBtnEnable", true);
							that.byId("qualifIdInp").setTokens([]);
							that.getView().getModel("viewModel").setProperty("/qualTitieIdVal", "");
							that.getView().getModel("viewModel").setProperty("/QualNameIdName", "");
							that.getView().getModel("viewModel").setProperty("/QualNameId", "");
							that.getView().getModel("viewModel").setProperty("/QualNameIdDesc", "");
							that.byId("qualifIdInp").setWidth("70%");
							that.getView().getModel("viewModel").setProperty("/qulEffectDate", sStartDte);
							that.getView().getModel("viewModel").setProperty("/qulEndDate", "99991231");
						},
						function (oResponse) {
							//-----------------------------------------------------------------------	
							// Displaying response body message.
							//-----------------------------------------------------------------------
							var oMessage = $(oResponse.response.body).find('message').first().text();
							var msg = oMessage;
							var splitMsg = msg.split(":");
							var msgCode = splitMsg[0];
							var message = splitMsg[1];

							var errmsg;
							if (oMessage === "") {
								errmsg = oResponse.response.body;
							} else {
								// errmsg = oMessage;
								errmsg = message;
							}
							sap.m.MessageBox.show(errmsg, {
								icon: sap.m.MessageBox.Icon.ERROR,
								title: "Error",
								actions: [sap.m.MessageBox.Action.OK],
								onClose: function (oAction) {
									if (oAction === sap.m.MessageBox.Action.OK) {
										if (msgCode === "S") {
											that.byId("qualStartDateId").setValueState("Error");
											that.getView().getModel("viewModel").setProperty("/qulEffectDate", "");
										} else if (msgCode === "E") {
											that.byId("qualEndDateId").setValueState("Error");
											that.getView().getModel("viewModel").setProperty("/qulEndDate", "");
										}
										that.getView().getModel("viewModel").setProperty("/qulEffectDate", sStartDte);
										that.getView().getModel("viewModel").setProperty("/qulEndDate", "99991231");
									}
								}
							});
						}
					);
				}
			}
		},
		addRownique: function (createTableArray) {
			for (var i = 1; i < createTableArray.length;) {
				if (createTableArray[i - 1].QualId === createTableArray[i].QualId) {
					createTableArray.splice(i, 1);
				} else {
					i++;
				}
			}
			return createTableArray;
		},
		onUpdateFinished: function () {
			var data = this.byId("selectedQualTable").getItems();
			for (var i = 0; i < data.length; i++) {
				if (data[i].getAggregation("cells")[7].getText() === "B") {
					data[i].getAggregation("cells")[9].getItems()[0].setVisible(false);
					data[i].getAggregation("cells")[9].getItems()[1].setVisible(true);
				} else if (data[i].getAggregation("cells")[7].getText() === "F") {
					data[i].getAggregation("cells")[9].getItems()[0].setVisible(true);
					data[i].getAggregation("cells")[9].getItems()[1].setVisible(true);
				}
			}
		},
		onRelDelete: function (oEvent) {
			var that = this,
				index = parseInt(oEvent.getSource().getId().split("selectedQualTable-")[1], 10),
				tableId = that.getView().byId("selectedQualTable").getId(),
				tabledItems = this.byId("selectedQualTable").getItems(),
				rowKey = oEvent.getSource().getParent().getParent().getCells()[7].getText();
			if (rowKey === "F") {
				var oModelres = this.byId("selectedQualTable").getModel("oModelData").getData().results;
				var path = oEvent.getSource().getParent().getParent().getBindingContextPath().split("/")[2];
				oModelres.splice(path, "1");
				this.byId("selectedQualTable").getModel("oModelData").refresh();
				this.byId("selectedQualTable").removeSelections(true);
			} else if (rowKey === "B") {
				var oPath = oEvent.getSource().getBindingContext("oModelData").getPath();
				var oContext = that.getView().byId("selectedQualTable").getModel("oModelData").getProperty(oPath);
				var valueString = oEvent.getSource().getBindingContext("oModelData").sPath;
				that.getView().byId("selectedQualTable").getModel("oModelData").setProperty(valueString + "/key", "D");
				that.getModel("visibleModel").setProperty("/submitBtnEnable", true);
			}
			if (tabledItems.length === 0) {
				that.getModel("visibleModel").setProperty("/submitBtnEnable", false);
			} else {
				that.getModel("visibleModel").setProperty("/submitBtnEnable", true);
			}
			var changeArr = [];
			var oChange = "X";
			tabledItems = this.byId("selectedQualTable").getItems();
			for (var i = 0; i < tabledItems.length; i++) {
				if (tabledItems[i].getAggregation("cells")[8].getText() === "E" || tabledItems[i].getAggregation("cells")[7].getText() === "F") {
					changeArr.push(oChange);
				} else {
					changeArr.push();
				}
			}
			if (changeArr.length > 0) {
				that.getModel("visibleModel").setProperty("/submitBtnEnable", true);
			} else {
				that.getModel("visibleModel").setProperty("/submitBtnEnable", false);
			}
		},
		//-----------------------------------------------------------------------	
		// Editing table row based on index.
		//-----------------------------------------------------------------------
		onInlineEdit: function (oEvent) {
			var that = this;
			that.oldEndDate = oEvent.getSource().getParent().getParent().getCells()[3].getValue();
			// oEvent.getSource().getParent().getParent().getCells()[3].setEnabled(true);
			var endDateCellId = oEvent.getSource().getParent().getParent().getCells()[3].getId();
			that.byId(endDateCellId).setEnabled(true);
			that.oldQualDate = oEvent.getSource().getParent().getParent().getCells()[3].getValue();
			oEvent.getSource().getParent().getParent().getCells()[8].setText("E");
			that.getModel("visibleModel").setProperty("/submitBtnEnable", true);
		},
		onEndDateCellChange: function (oEvent) {
			var that = this;
			that.id = oEvent.getSource().getId();
			var startDate = oEvent.getSource().getParent().getCells()[2].getText();
			var endDate = oEvent.getSource().getParent().getCells()[3].getValue();
			var endDateCellId = oEvent.getSource().getParent().getCells()[3].getId();
			var oDP = oEvent.getSource();
			var bValid = oEvent.getParameter("valid");
			if (bValid) {
				oDP.setValueState(sap.ui.core.ValueState.None);
			} else {
				oDP.setValueState(sap.ui.core.ValueState.Error);
				oDP.setValue("");
				sap.m.MessageBox.show("Please enter a date in the format MM/DD/YYYY", {
					icon: sap.m.MessageBox.Icon.ERROR,
					title: "Error",
					actions: [sap.m.MessageBox.Action.OK]
				});
			}
			if (new Date(endDate) < new Date(startDate)) {
				this.byId(endDateCellId).setValueState("Error");
				sap.m.MessageBox.show("End date should be greater than Effective Date", {
					icon: sap.m.MessageBox.Icon.ERROR,
					title: "Error",
					actions: [sap.m.MessageBox.Action.OK]
				});
			} else {
				if (bValid) {
					oDP.setValueState(sap.ui.core.ValueState.None);
					this.byId(endDateCellId).setValueState("None");
				} else {
					oDP.setValueState(sap.ui.core.ValueState.Error);
					this.byId(endDateCellId).setValueState("Error");
					that.getModel("visibleModel").setProperty("/submitBtnEnable", false);
				}
			}
			var data = this.byId("selectedQualTable").getItems();
			var valueStateArray = [];
			var visible = "X";
			for (var i = 0; i < data.length; i++) {
				if (data[i].getAggregation("cells")[3].getValueState() === "Error") {
					valueStateArray.push(visible);
				} else {
					valueStateArray.push();
				}
			}
			if (valueStateArray.length > 0) {
				that.getModel("visibleModel").setProperty("/submitBtnEnable", false);
			} else {
				that.getModel("visibleModel").setProperty("/submitBtnEnable", true);
			}
		},
		onSubmit: function () {
			var that = this;
			var tableItemData = that.byId("selectedQualTable").getItems();
			var itemData = [];
			var valdate = true;
			for (var i = 0; i < tableItemData.length; i++) {
				var key = tableItemData[i].getAggregation("cells")[8].getText();
				var rowKey = tableItemData[i].getAggregation("cells")[7].getText();
				if (tableItemData[i].getAggregation("cells")[7].getText() === "F" || tableItemData[i].getAggregation("cells")[8].getText() ===
					"E") {
					var sDate = tableItemData[i].getAggregation("cells")[2].getText();
					if (sDate !== "") {
						var oSDate = sDate.split("/");
						var startDate = oSDate[2] + oSDate[0] + oSDate[1];
					} else {
						startDate = "";
					}
					// var eDate = tableItemData[i].getAggregation("cells")[3].getText();
					var eDate = tableItemData[i].getAggregation("cells")[3].getValue();
					if (eDate !== "") {
						var oEDate = eDate.split("/");
						var endDate = oEDate[2] + oEDate[0] + oEDate[1];
						tableItemData[i].getAggregation("cells")[3].setValueState("None");
					} else {
						endDate = "";
						valdate = false;
						tableItemData[i].getAggregation("cells")[3].setValueState("Error");
					}
					var itemObj = {};
					// itemObj.PosId = that.byId("positonIdInp").getValue();
					itemObj.QualId = tableItemData[i].getAggregation("cells")[10].getText();
					itemObj.QualSdate = startDate;
					itemObj.QualEdate = endDate;
					itemObj.QualProflevel = tableItemData[i].getAggregation("cells")[4].getText();
					if ((tableItemData[i].getAggregation("cells")[8].getText() === "E" && tableItemData[i].getAggregation("cells")[7].getText() ===
							"F") || (tableItemData[i].getAggregation("cells")[8].getText() === "" && tableItemData[i].getAggregation("cells")[7].getText() ===
							"F")) {
						itemObj.Key = "I";
					} else {
						itemObj.Key = "E";
					}
					itemData.push(itemObj);
				}
			}
			if (valdate === false) {
				sap.m.MessageBox.show("End Date can't be empty", {
					icon: sap.m.MessageBox.Icon.ERROR,
					title: "Error",
					actions: [sap.m.MessageBox.Action.OK],
				});
				return;
			}
			var oEntry = {};
			oEntry.PosId = that.byId("positonIdInp").getTokens()[0].getKey();
			oEntry.QualdetUpdateSet = itemData;
			var sUrl = "/sap/opu/odata/SAP/ZPPM_POS_MAIT_SRV";
			var oModel = new sap.ui.model.odata.ODataModel(sUrl, false);
			oModel.create("/QualdetHeaderSet()", oEntry, null, function (oData, oResponse) {},
				function (oResponse) {
					var oMessage = [];
					var msg_len = $(oResponse.response.body).find('message').first().prevObject.length;
					for (var j = 0; j < msg_len; j++) {
						var exception = $(oResponse.response.body).find('message').first().prevObject[j].innerText;
						if (exception !== "Exception raised without specific error") {
							var Message = $(oResponse.response.body).find('message').first().prevObject[j].innerText;
							oMessage.push(Message);
						}
					}
					var uniqueMsgs = [];
					$.each(oMessage, function (i, el) {
						if ($.inArray(el, uniqueMsgs) === -1) uniqueMsgs.push(el);
					});
					var msg = uniqueMsgs.toLocaleString().split(",").join("\r\n");
					if (oMessage === undefined) {
						msg = $(oResponse.response.body).find('message').first().prevObject[0].innerText;
					}
					MessageBox.show(
						msg, {
							icon: MessageBox.Icon.INFORMATION,
							title: "Log",
							actions: [MessageBox.Action.OK],
							onClose: function (oAction) {
								if (oAction === MessageBox.Action.OK) {
									// window.parent.parent.close();
									// that.byId("selectedQualTable").unbindItems();
									// that.byId("selectedQualTable").removeAllItems();
									// -------Clear table data------- 
									var itemTableData = that.byId("selectedQualTable").getItems();
									var itemsArray = [];
									var qualCModel = new sap.ui.model.json.JSONModel({
										"results": itemsArray
									});
									var itemsTable = that.byId("selectedQualTable");
									itemsTable.setModel(qualCModel, "oModelData");
									// var posId = that.byId("positonIdInp").getValue();
									var posId = "";
									if (that.byId("positonIdInp").getTokens().length !== 0) {
										posId = that.byId("positonIdInp").getTokens()[0].getKey();
									}
									var craftType = that.byId("craftId").getText();
									var contectIconTabKey = that.getModel("viewModel").getProperty("/contectIconTabKey");
									if (craftType === "Engineering") {
										craftType = "ENG";
									} else if (craftType === "Mechanical") {
										craftType = "MECH";
									} else if (craftType === "TCU") {
										craftType = "TCU";
									}
									//-----------------------------------------------------------------------	
									//Busy Indicator.
									//-----------------------------------------------------------------------
									var dialog = new sap.m.BusyDialog({});
									dialog.open();
									var sUrl = "/sap/opu/odata/SAP/ZPPM_POS_MAIT_SRV";
									var pernrModel = new sap.ui.model.odata.ODataModel(sUrl, false);
									pernrModel.read("/QualdetUpdateSet?$filter=CraftType eq '" + craftType + "'and EffectiveDate eq '" + that.byId(
											"dateRangeId").getValue() + "' and PosId eq '" + posId + "'", null, null,
										false,
										function (oData, oResponse) {
											setTimeout(function () {
												dialog.close();
											}, 2000);
											that.byId("positonIdInp").setValueState("None");
											if (oData.results.length > 0) {
												that.oPosDesc = oData.results[0].PosDesc;
												if (that.oPosDesc !== "") {
													if (contectIconTabKey === "QUALIFICATION") {
														that.getModel("visibleModel").setProperty("/posDesc", oData.results[0].PosDesc);
													}
												} else {
													if (contectIconTabKey === "QUALIFICATION") {
														that.getModel("visibleModel").setProperty("/posDesc", "");
													}
												}
												var oResults = that.getView().byId("selectedQualTable").getModel("oModelData");
												var qualTableArray1 = [];
												var qualTableArray2 = [];
												for (var i = 0; i < oData.results.length; i++) {
													var Qualification = oData.results[i].Qualification;
													var QualId = oData.results[i].QualId;
													var QualDesc = oData.results[i].QualDesc;
													var QualSdate = oData.results[i].QualSdate;
													var QualEdate = oData.results[i].QualEdate;
													var QualProflevel = oData.results[i].QualProflevel;
													var ChangedBy = oData.results[i].ChangedBy;
													if (QualSdate === "00000000" || QualSdate === "") {
														var stDate = "";
													} else {
														QualSdate = QualSdate;
														var stYear = QualSdate.slice("0", "4");
														var stMonth = QualSdate.slice("4").slice("0", "2");
														var stDay = QualSdate.slice("6");
														stDate = stMonth + "/" + stDay + "/" + stYear;
													}
													if (QualEdate === "00000000" || QualEdate === "") {
														var enDate = "";
													} else {
														QualEdate = QualEdate;
														var endYear = QualEdate.slice("0", "4");
														var endMonth = QualEdate.slice("4").slice("0", "2");
														var endDay = QualEdate.slice("6");
														enDate = endMonth + "/" + endDay + "/" + endYear;
													}
													if (Qualification === "00000000" || Qualification === "") {
														Qualification = "";
													} else {
														Qualification = Qualification;
													}
													if (QualId === "00000000" || QualId === "") {
														QualId = "";
													} else {
														QualId = QualId;
													}
													if (QualProflevel === "") {
														QualProflevel = "";
													} else {
														QualProflevel = QualProflevel;
													}
													if (oData.results[i].ChangedOn !== "") {
														var changedOn;
														var changedDate = oData.results[i].ChangedOn;
														var changedYear = changedDate.slice("0", "4");
														var changedMonth = changedDate.slice("4").slice("0", "2");
														var changedDay = changedDate.slice("6");
														changedOn = changedMonth + "/" + changedDay + "/" + changedYear;
													} else {
														changedOn = "";
													}
													if (oResults !== undefined) {
														if (oResults.oData.results.length > 0) {
															var qualTableObj = {};
															if (stDate !== "" || enDate !== "" || Qualification !== "" || QualId !== "" || QualProflevel !== "") {
																qualTableObj.Qualification = Qualification;
																qualTableObj.QualId = QualId;
																qualTableObj.QualDesc = QualDesc;
																qualTableObj.QualSdate = stDate;
																qualTableObj.QualEdate = enDate;
																qualTableObj.QualProflevel = QualProflevel;
																qualTableObj.ChangedOn = changedOn;
																qualTableObj.ChangedBy = oData.results[i].ChangedBy;
																qualTableObj.rowKey = "B";
																oResults.oData.results.push(qualTableObj);
															}
														} else {
															var qualTableObj1 = {};
															if (stDate !== "" || enDate !== "" || Qualification !== "" || QualId !== "" || QualProflevel !== "") {
																qualTableObj1.Qualification = Qualification;
																qualTableObj1.QualId = QualId;
																qualTableObj1.QualDesc = QualDesc;
																qualTableObj1.QualSdate = stDate;
																qualTableObj1.QualEdate = enDate;
																qualTableObj1.QualProflevel = QualProflevel;
																qualTableObj1.ChangedOn = changedOn;
																qualTableObj1.ChangedBy = oData.results[i].ChangedBy;
																qualTableObj1.rowKey = "B";
																qualTableArray1.push(qualTableObj1);
															}
														}
													} else {
														var qualTableObj2 = {};
														if (stDate !== "" || enDate !== "" || Qualification !== "" || QualId !== "" || QualProflevel !== "") {
															qualTableObj2.Qualification = Qualification;
															qualTableObj2.QualId = QualId;
															qualTableObj2.QualSdate = stDate;
															qualTableObj2.QualDesc = QualDesc;
															qualTableObj2.QualEdate = enDate;
															qualTableObj2.QualProflevel = QualProflevel;
															qualTableObj2.ChangedOn = changedOn;
															qualTableObj2.ChangedBy = oData.results[i].ChangedBy;
															qualTableObj2.rowKey = "B";
															qualTableArray2.push(qualTableObj2);
														}
													}
												}
												var uniqQualArr = that.dupArr1(qualTableArray1);
												var oQualTableModel = new sap.ui.model.json.JSONModel({
													"results": uniqQualArr
												});
												var uniqQualArr1 = that.dupArr2(qualTableArray2);
												var oQualTableModel1 = new sap.ui.model.json.JSONModel({
													"results": uniqQualArr1
												});
												if (oQualTableModel.oData.results.length > 0) {
													var oQalTable = that.getView().byId("selectedQualTable");
													oQalTable.setModel(oQualTableModel, "oModelData");
												} else if (oQualTableModel1.oData.results.length > 0) {
													var oQalTable = that.getView().byId("selectedQualTable");
													oQalTable.setModel(oQualTableModel1, "oModelData");
												} else {
													var uniqEffDateQualArr = that.effDateUnique(oResults);
													var oQualTable = that.byId("selectedQualTable");
													oQualTable.setModel(uniqEffDateQualArr, "oModelData");
													that.byId("selectedQualTable").getModel("oModelData").refresh();
													that.getModel("visibleModel").setProperty("/submitBtnEnable", false);
												}
											}
											that.getModel("visibleModel").setProperty("/submitBtn", false);
											that.getModel("visibleModel").setProperty("/submitBtnEnable", false);
											that.getView().getModel("viewModel").setProperty("/qualStartDateEnable", false);
											that.getView().getModel("viewModel").setProperty("/qualifIdInpEnable", false);
											that.byId("posAssignId").setEnabled(false);
											that.getView().getModel("viewModel").setProperty("/qualEndDateEnable", false);
											if (posId !== "" && posId.length === 8) {
												that.getModel("visibleModel").setProperty("/editBtn", true);
												that.getModel("visibleModel").setProperty("/editBtnEnable", true);
											} else {
												that.getModel("visibleModel").setProperty("/editBtn", true);
												that.getModel("visibleModel").setProperty("/editBtnEnable", false);
											}
											if (that.byId("roleIdSelect").getSelectedKey() === "Certification Group") {
												that.getModel("visibleModel").setProperty("/editBtn", false);
												that.getModel("visibleModel").setProperty("/cancelBtn", false);
											}
											that.oEditAll = false;
											that.posEditBtnPress = false;
											that.oPosEditFlag = false;
											var data = that.byId("selectedQualTable").getItems();
											for (var i = 0; i < data.length; i++) {
												data[i].getAggregation("cells")[9].getItems()[1].setEnabled(false);
											}
											that.byId("positonIdInp").setEnabled(true);
											that.byId("dateRangeId").setEnabled(true);
											that.byId("roleIdSelect").setEnabled(true);
										},
										function (oResponse) {
											dialog.close();
											//-----------------------------------------------------------------------	
											// Displaying response body message.
											//-----------------------------------------------------------------------
											// var oMessage = $(oResponse.response.body).find('message').first().text();
											var errmsg = JSON.parse(oResponse.response.body).error.innererror.errordetails[0].message;
											sap.m.MessageBox.show(errmsg, {
												icon: sap.m.MessageBox.Icon.ERROR,
												title: "Error",
												actions: [sap.m.MessageBox.Action.OK],
												onClose: function (oAction) {
													if (oAction === sap.m.MessageBox.Action.OK) {
														that.byId("positonIdInp").setValueState("Error");
														that.byId("positonIdInp").setTokens([]);
														that.byId("positonIdInp").fireTokenUpdate({
															type: "removed",
															addedTokens: [],
															removedTokens: that.byId("positonIdInp").getTokens()
														});
													}
												}
											});
										}
									);
									that.getModel("visibleModel").setProperty("/submitBtnEnable", false);
								}
							}
						});
				});
			// }
		},
		dupArr1: function (qualTableArray1) {
			for (var i = 1; i < qualTableArray1.length;) {
				if (qualTableArray1[i - 1].QualId === qualTableArray1[i].QualId) {
					qualTableArray1.splice(i, 1);
				} else {
					i++;
				}
			}
			return qualTableArray1;
		},
		dupArr2: function (qualTableArray2) {
			for (var i = 1; i < qualTableArray2.length;) {
				if (qualTableArray2[i - 1].QualId === qualTableArray2[i].QualId) {
					qualTableArray2.splice(i, 1);
				} else {
					i++;
				}
			}
			return qualTableArray2;
		},
		onQualDateChange: function (oEvent) {
			var startDate = this.byId("qualStartDateId").getValue();
			var endDate = this.byId("qualEndDateId").getValue();
			var oDP = oEvent.getSource();
			var sValue = oEvent.getParameter("value");
			var bValid = oEvent.getParameter("valid");
			if (bValid) {
				oDP.setValueState(sap.ui.core.ValueState.None);
			} else {
				oDP.setValueState(sap.ui.core.ValueState.Error);
				sap.m.MessageBox.show("Please enter a date in the format MM/DD/YYYY", {
					icon: sap.m.MessageBox.Icon.ERROR,
					title: "Error",
					actions: [sap.m.MessageBox.Action.OK],
					onClose: function (oAction) {
						if (oAction === sap.m.MessageBox.Action.OK) {}
					}
				});
			}
			if (startDate !== "") {
				if (startDate.includes("/")) {
					var sDate = startDate;
				} else {
					var sDate = startDate.substring(0, 4) + "/" + startDate.substring(4, 6) + "/" + startDate.substring(6, 8);
				}
			}
			if (endDate !== "") {
				if (endDate.includes("/")) {
					var eDate = endDate;
				} else {
					var eDate = endDate.substring(0, 4) + "/" + endDate.substring(4, 6) + "/" + endDate.substring(6, 8);
				}
			}
			if (new Date(eDate) < new Date(sDate)) {
				this.byId("qualEndDateId").setValueState("Error");
				sap.m.MessageBox.show("End date should be greater than Effective Date", {
					icon: sap.m.MessageBox.Icon.ERROR,
					title: "Error",
					actions: [sap.m.MessageBox.Action.OK],
					onClose: function (oAction) {
						if (oAction === sap.m.MessageBox.Action.OK) {}
					}
				});
			} else {
				if (bValid) {
					oDP.setValueState(sap.ui.core.ValueState.None);
					this.byId("qualEndDateId").setValueState("None");
				} else {
					oDP.setValueState(sap.ui.core.ValueState.Error);
				}
			}
		},
		onQualTableFilter: function () {
			var aFilters = [];
			var sQuery = sap.ui.getCore().byId("qualSearch").getValue();
			aFilters = [
				new sap.ui.model.Filter([
					new sap.ui.model.Filter("QualName", sap.ui.model.FilterOperator.Contains, sQuery),
					new sap.ui.model.Filter("QualDesc", sap.ui.model.FilterOperator.Contains, sQuery),
					new sap.ui.model.Filter("QualId", sap.ui.model.FilterOperator.Contains, sQuery)
				], false)
			];
			// update list binding
			var list = sap.ui.getCore().byId("qualMaintenanceTable");
			var binding = list.getBinding("items");
			binding.filter(aFilters);
		},
		onQualCancel: function () {
			this._qualIdValueDialog.close();
		},
		onQualSubmit: function (oEvent) {
			var that = this;
			var qualName = that.getView().getModel("qualIdModel").getProperty(oEvent.getSource().getBindingContextPath()).QualName; // qualSItems[0].QualName;
			var qualDesc = that.getView().getModel("qualIdModel").getProperty(oEvent.getSource().getBindingContextPath()).QualDesc;
			var QualId = that.getView().getModel("qualIdModel").getProperty(oEvent.getSource().getBindingContextPath()).QualId;
			var Endda = that.getView().getModel("qualIdModel").getProperty(oEvent.getSource().getBindingContextPath()).Endda;
			that.byId("qualifIdInp").setTokens([new sap.m.Token({
				text: qualName,
				key: qualName
			})]);
			that.byId("QualNameIdName").setText(QualId + " - " + qualDesc);
			that.byId("QualNameId").setText(QualId);
			that.byId("QualNameIdDesc").setText(qualDesc);
			var oRangeDate = "";
			if (Endda !== "") {
				oRangeDate = Endda.substring(4, 6) + "/" + Endda.substring(6, 8) + "/" + Endda.substring(0, 4);
			}
			that.getView().getModel("viewModel").setProperty("/qulEndDate", oRangeDate);
			that.byId("posAssignId").setEnabled(true);
			that.getModel("visibleModel").setProperty("/submitBtnEnable", false);
			that.onEdit();
			this._qualIdValueDialog.close();
		},
		onQualSChange: function () {
			this.onQualValueHelpReq();
			sap.ui.getCore().byId("qualSearch").setValue(this.byId("qualifIdInp").getTokens()[0].getKey());
		},
		onQualSuggChage: function () {
			var that = this;
			that.byId("qualifIdInp").setValueState("None");
			that.getModel("viewModel").setProperty("/qualTitieIdVal", "");
			that.getModel("viewModel").setProperty("/qualifIdInpDesc", "");
			that.getModel("viewModel").setProperty("/QualNameId", "");
			that.getModel("viewModel").setProperty("/QualNameIdDesc", "");
			that.getModel("viewModel").setProperty("/QualNameIdName", "");
			this.byId("qualifIdInp").setWidth("70%");
		},
		onPositionSubmit: function (oEvent) {
			var that = this;
			var sObj = oEvent.getParameter("rowBindingContext").getObject();
			that.getModel("viewModel").setProperty("/positonIdVal", sObj.PositionId);
			that.getModel("viewModel").setProperty("/posDesc", sObj.PositionDesc);
			that.getModel("visibleModel").setProperty("/iconTabContent", true);
			that.byId("positonIdInp").setTokens([new sap.m.Token({
				text: sObj.PositionId,
				key: sObj.PositionId
			})]);
			that.CurrentOcup = sObj.CurntOcupnt;
			that.onPositionSubmitInput();
			that.onDialogClose();
		},
		payrollPositiontableData: function (property, type) {
			var that = this;
			var titleInfo = that.getView().getModel("i18n").getProperty("titleInfo");
			var posIdTitleJsonPos = new sap.ui.model.json.JSONModel();
			var posIdTitleModel = that.getOwnerComponent().getModel("oDataSrv");
			posIdTitleModel.read("/PositionSearchHelpSet?$filter=" + property + " and Key eq 'P'", null, null,
				true,
				function (oData) {
					if (type === "Search") {
						that._payRollPosIdValueDialog.setBusy(false);
						if (oData.results.length > 0) {
							posIdTitleJsonPos.setData(oData);
							var posIdTitleTable = sap.ui.getCore().byId("payRollPosIdTabTable");
							posIdTitleTable.setModel(posIdTitleJsonPos, "payRollPosDetails");
							sap.ui.getCore().byId("payRollPosIdTabTable").setVisible(true);
						} else {
							sap.ui.getCore().byId("payRollPosIdTabTable").setVisible(false);
						}
					} else {
						that.payCraft = oData.results[0].Craft;
					}
				},
				function (oResponse) {
					//-----------------------------------------------------------------------	
					// Displaying response body message.
					//-----------------------------------------------------------------------
					that._payRollPosIdValueDialog.setBusy(false);
					var oMessage;
					var mesLen = $(oResponse.response.body).find("message").first().prevObject.length;
					for (var i = 1; i < mesLen; i++) {
						var exception = $(oResponse.response.body).find("message").first().prevObject[i].innerText;
						if (exception !== "Exception raised without specific error") {
							var Message = $(oResponse.response.body).find("message").first().prevObject[i].innerText;
						} else {
							Message = "";
						}
						if (i === 1) {
							oMessage = Message;
						}
						if (i > 1) {
							oMessage = oMessage + "\r\n" + Message;
						}
					}
					if (oMessage === undefined) {
						oMessage = $(oResponse.response.body).find("message").first().prevObject[0].innerText;
					}
					sap.m.MessageBox.show(oMessage, {
						icon: sap.m.MessageBox.Icon.INFORMATION,
						title: titleInfo,
						actions: [sap.m.MessageBox.Action.OK],
						onClose: function (oAction) {
							if (oAction === "OK") {
								if (sap.ui.getCore().byId("payRollPosIdTabTable") !== undefined) {
									sap.ui.getCore().byId("payRollPosIdTabTable").setVisible(false);
								}
							}
						}
					});
				});
		},
		onPositionSubmitInput: function (oEvt) {
			var that = this;
			if (oEvt) {
				var oDP = oEvt.getSource();
				var bValid = oEvt.getParameter("valid");
				if (!bValid) {
					oEvt.getSource().setValue("");
					oDP.setValueState(sap.ui.core.ValueState.Error);
					sap.m.MessageToast.show("Please enter valid date");
					// that.onPosLiveChange();
					that.byId("positonIdInp").setTokens([]);
					that.byId("positonIdInp").fireTokenUpdate({
						type: "removed",
						addedTokens: [],
						removedTokens: that.byId("positonIdInp").getTokens()
					});
					return;
				}
				if (oDP.getValue() === "") {
					sap.m.MessageToast.show("As Of date can't be empty");
					return;
				}
				oDP.setValueState(sap.ui.core.ValueState.None);
			}
			var posId = "";
			if (that.byId("positonIdInp").getTokens().length !== 0) {
				posId = that.byId("positonIdInp").getTokens()[0].getKey();
			}
			that.valChangeFlag = true;
			if (posId.trim().length > 0) {
				var craftType = that.getModel("viewModel").getProperty("/Group");
				var contectIconTabKey = that.getModel("viewModel").getProperty("/contectIconTabKey");
				var property = "PositionId eq '" + posId + "'";
				var type = "Data";
				if (craftType === "Payroll" || craftType === "P" || craftType === "SP") {
					this.payrollPositiontableData(property, type);
				}
				if (contectIconTabKey === "POSITION") {
					var craftId = that.craftUnionfun();
					if (that.craftUnion === "ATDA" || that.craftUnion === "Dispatchers" || that.craftUnion === "SD" || that.craftUnion === "D") {
						craftId = "ATDA";
					}
					var oPosVal = "";
					if (that.byId("positonIdInp").getTokens().length !== 0) {
						oPosVal = that.byId("positonIdInp").getTokens()[0].getKey();
					}
					var EffectiveDate = that.getView().getModel("viewModel").getProperty("/dateRange");
					if (EffectiveDate.includes("/") === "true") {
						var oSplitdate = EffectiveDate.split("/");
						EffectiveDate = oSplitdate[2] + "" + oSplitdate[0] + "" + oSplitdate[1];
					} else {
						EffectiveDate = EffectiveDate;
					}
					var oKey = contectIconTabKey;
					if ((oKey === "POSITION") || (oKey === "PAYROLL") || (oKey === "QUALIFICATION")) {
						that.getModel("visibleModel").setProperty("/iconTabContent", true);
						// Mechanical get data from service
						if (that.craftUnion === "Mechanical" || that.craftUnion === "SM" || that.craftUnion === "M" || that.payCraft === "M") {
							that.getPositionData(oPosVal, "(PosId='" + oPosVal + "',EffectiveDate='" + EffectiveDate + "')");
						}
						// Payroll get data from service
						if (that.craftUnion === "Payroll" || that.craftUnion === "P" || that.craftUnion === "SP") {
							that.getPositionData(oPosVal, "(PosId='" + oPosVal + "',EffectiveDate='" + EffectiveDate + "')");
						}
						// TCU get data from service
						if (that.craftUnion === "TCU" || that.craftUnion === "ST" || that.payCraft === "T" || that.craftUnion === "T") {
							that.getPositionData(oPosVal, "(PosId='" + oPosVal + "',EffectiveDate='" + EffectiveDate + "')");
						}
						// Eng get data from service
						if (that.craftUnion === "Engineering" || that.craftUnion === "SE" || that.payCraft === "E" || that.craftUnion === "E") {
							that.getPositionData(oPosVal, "(PosId='" + oPosVal + "',EffectiveDate='" + EffectiveDate + "')");
						}
						if (that.craftUnion === "ATDA" || that.craftUnion === "SD" || that.craftUnion === "D" || that.payCraft === "A" || that.craftUnion ===
							"Dispatchers") {
							that.getPositionData(oPosVal, "(PosId='" + oPosVal + "',EffectiveDate='" + EffectiveDate + "')");
						}
						if (that.craftUnion === "ILA" || that.craftUnion === "SL" || that.craftUnion === "L" || that.payCraft === "L") {
							that.getPositionData(oPosVal, "(PosId='" + oPosVal + "',EffectiveDate='" + EffectiveDate + "')");
						}
						if (that.craftUnion === "CH") {
							that.getPositionData(oPosVal, "(PosId='" + oPosVal + "',EffectiveDate='" + EffectiveDate + "')");
						}
						if (that.craftUnion === "IHB" || that.craftUnion === "NAHR" || that.craftUnion === "Conrail" || that.craftUnion === "SI" || that
							.craftUnion === "I" ||
							that.craftUnion === "SN" || that.craftUnion === "N" || that.craftUnion === "SC" || that.craftUnion === "C" || that.payCraft ===
							"CH" || that.payCraft ===
							"N" ||
							that.payCraft === "C" || that.payCraft === "I") {
							var subtype = "";
							that.getModel("visibleModel").setProperty("/iconTabContent", true);
							that.getModel("visibleModel").setProperty("/positionPayrolCont", false);
							if (that.craftUnion === "IHB" || that.craftUnion === "SI" || that.craftUnion === "I") {
								subtype = "I";
							} else if (that.craftUnion === "NAHR" || that.craftUnion === "SN" || that.craftUnion === "N") {
								subtype = "N";
							} else if (that.craftUnion === "Conrail" || that.craftUnion === "SC" || that.craftUnion === "C") {
								subtype = "C";
							}
							if (posId !== "") {
								that.getPositionData(oPosVal, "(PosId='" + oPosVal + "',EffectiveDate='" + EffectiveDate + "',Subtype='" + subtype + "')");
							}
							if (craftType !== "Payroll") {
								that.getModel("visibleModel").setProperty("/editBtnEnable", true);
							}
						}
					}
					if (craftType === "Payroll" || craftType === "P" || craftType === "SP") {
						that.getModel("visibleModel").setProperty("/editBtnEnable", false);
						that.getModel("visibleModel").setProperty("/cancelBtnEnable", false);
					}
				} else if (contectIconTabKey === "PAYROLL") {
					// this.payrollformData();
					if (craftType === "Payroll") {
						that.getModel("visibleModel").setProperty("/editBtnEnable", true);
						that.getModel("visibleModel").setProperty("/cancelBtnEnable", true);
					}
					that.byId("posMaintIconTabBar").setSelectedKey("POSITION");
					that.byId("posMaintIconTabBar").fireSelect();
				} else if (contectIconTabKey === "QUALIFICATION") {
					if (that.byId("positonIdInp").getTokens().length !== "" && that.byId("positonIdInp").getValueState() !== "Error") {
						that.qualificationTab();
					}
					if (craftType === "Payroll") {
						that.getModel("visibleModel").setProperty("/editBtnEnable", false);
						that.getModel("visibleModel").setProperty("/cancelBtnEnable", false);
					} else {
						that.getModel("visibleModel").setProperty("/editBtnEnable", true);
						that.getModel("visibleModel").setProperty("/cancelBtnEnable", true);
					}
					this.byId("qualStartDateId").setEnabled(false);
					this.byId("qualifIdInp").setEnabled(false);
					this.byId("posAssignId").setEnabled(false);
					this.byId("qualEndDateId").setEnabled(false);
					that.getModel("viewModel").setProperty("/contectIconTabKey", "POSITION");
					that.byId("posMaintIconTabBar").fireSelect();
				}
				if (that.byId("positonIdInp").getMetadata().getElementName() === "sap.m.DatePicker") {
					var newDate = new Date();
					var currDay = newDate.getDate();
					var currMonth = newDate.getMonth() + 1;
					var currYear = newDate.getFullYear();
					if (currDay < 10) {
						currDay = "0" + currDay;
					} else {
						currDay = currDay;
					}
					if (currMonth < 10) {
						currMonth = "0" + currMonth;
					} else {
						currMonth = currMonth;
					}
					var currentDate = currMonth + "/" + currDay + "/" + currYear;
					var rangeDate = that.byId("dateRangeId").getValue();
					if (rangeDate !== "") {
						var oRangeDate = rangeDate.substring(4, 6) + "/" + rangeDate.substring(6, 8) + "/" + rangeDate.substring(0, 4);
					}
					if (new Date(oRangeDate) < new Date(currentDate)) {
						that.getModel("visibleModel").setProperty("/editBtn", true);
						that.getModel("visibleModel").setProperty("/saveBtn", false);
						that.getModel("visibleModel").setProperty("/editBtnEnable", false);
					} else {
						that.getModel("visibleModel").setProperty("/editBtn", true);
						that.getModel("visibleModel").setProperty("/saveBtn", false);
						that.getModel("visibleModel").setProperty("/editBtnEnable", true);
					}
					if (that.byId("roleIdSelect").getSelectedKey() === "Certification Group") {
						that.getModel("visibleModel").setProperty("/editBtn", false);
						that.getModel("visibleModel").setProperty("/cancelBtn", false);
					}
				}
			} else {
				sap.m.MessageBox.show("Please enter the Position ID.", {
					icon: sap.m.MessageBox.Icon.ERROR,
					title: "Error",
					actions: [sap.m.MessageBox.Action.OK]
				});
			}
		},
		getPositionData: function (oPosVal, url) {
			var that = this;
			if (oPosVal.length > 0) {
				var entitySet;
				if (that.craftUnion === "TCU" || that.craftUnion === "ST" || that.payCraft === "T") {
					entitySet = "/PosTcuSet";
				} else if (that.craftUnion === "ILA" || that.craftUnion === "SL" || that.payCraft === "L") {
					entitySet = "/POSILASet";
				} else if (that.craftUnion === "ATDA" || that.craftUnion === "SD" || that.craftUnion === "D" || that.payCraft === "A" || that.craftUnion ===
					"Dispatchers") {
					entitySet = "/POSATDASet";
				} else if (that.craftUnion === "Mechanical" || that.craftUnion === "SM" || that.craftUnion === "M" || that.payCraft === "M") {
					entitySet = "/PosMechSet";
				} else if (that.craftUnion === "Engineering" || that.craftUnion === "SE" || that.payCraft === "E" || that.craftUnion === "E") {
					entitySet = "/PosEngSet";
					that.valChangeFlag = true;
				} else if (that.craftUnion === "IHB" || that.craftUnion === "NAHR" || that.craftUnion === "Conrail" || that.craftUnion === "SI" ||
					that.craftUnion === "SN" || that.craftUnion ===
					"SC" || that.payCraft === "N" || that.payCraft === "C" || that.payCraft === "I") {
					entitySet = "/POS_CR_IHB_NAHRSet";
				} else if (that.craftUnion === "payroll" || that.craftUnion === "P" || that.craftUnion === "SP") {
					entitySet = "/PosMechSet";
				}
				var srvModel = that.getOwnerComponent().getModel("oDataSrv");
				srvModel.read(entitySet + url, null, null, false,
					function (oData) {
						that.getView().getModel("viewModel").setProperty("/enabled", false);
						var EffectiveDate = that.getView().getModel("viewModel").getProperty("/dateRange");
						if (EffectiveDate.includes("/") === "true") {
							var oSplitdate = EffectiveDate.split("/");
							EffectiveDate = oSplitdate[2] + "" + oSplitdate[0] + "" + oSplitdate[1];
						} else {
							EffectiveDate = EffectiveDate;
						}
						that.oPosDesc = oData.PosDesc;
						that.getView().getModel("viewModel").setProperty("/posDesc", oData.PosDesc);
						that.byId("positonIdInp").setValueState("None");
						that.getModel("visibleModel").setProperty("/editBtnEnable", true);
						that.getValueHelpData("/PosDropDownsSet?$filter=Key eq 'PG' and PosId eq '" + oPosVal + "' and Effdate eq '" + EffectiveDate +
							"'", "PaySuggModel");
						if (that.craftUnion === "ATDA" || that.payCraft === "A" || that.craftUnion === "Dispatchers" || that.craftUnion === "SD" ||
							that.craftUnion === "D") {
							that.getModel("visibleModel").setProperty("/editBtn", true);
							that.getModel("visibleModel").setProperty("/cancelBtn", true);
							that.getModel("visibleModel").setProperty("/editBtnEnable", true);
							that.getModel("visibleModel").setProperty("/cancelBtnEnable", true);
						} else if (that.craftUnion === "ILA" || that.craftUnion === "SL" || that.payCraft === "L" || that.craftUnion === "L") {
							that.getModel("visibleModel").setProperty("/editBtn", true);
							that.getModel("visibleModel").setProperty("/cancelBtn", true);
							that.getModel("visibleModel").setProperty("/saveBtn", false);
							that.getModel("visibleModel").setProperty("/saveBtnEnable", false);
							that.getModel("visibleModel").setProperty("/editBtnEnable", true);
							that.getModel("visibleModel").setProperty("/cancelBtnEnable", true);
						} else if (that.craftUnion === "IHB" || that.craftUnion === "NAHR" || that.craftUnion === "Conrail" || that.craftUnion ===
							"SI" || that.craftUnion ===
							"I" ||
							that.craftUnion === "SN" || that.craftUnion === "SC" || that.payCraft === "N" || that.payCraft === "C" || that.payCraft ===
							"I") {
							that.tcuOldSDate = oData.StartDate;
							var tcuOldStYear = that.tcuOldSDate.slice("0", "4");
							var tcuOldStMonth = that.tcuOldSDate.slice("4").slice("0", "2");
							var tcuOldStDay = that.tcuOldSDate.slice("6");
							that.tcuOldStDate = tcuOldStMonth + "/" + tcuOldStDay + "/" + tcuOldStYear;
							that.getModel("visibleModel").setProperty("/editBtn", true);
							that.getModel("visibleModel").setProperty("/cancelBtn", true);
							that.getModel("visibleModel").setProperty("/saveBtn", false);
							that.getModel("visibleModel").setProperty("/saveBtnEnable", false);
							that.getModel("visibleModel").setProperty("/editBtnEnable", true);
							that.getModel("visibleModel").setProperty("/cancelBtnEnable", true);
						} else if (that.craftUnion === "Mechanical" || that.craftUnion === "SM" || that.craftUnion === "M" || that.payCraft === "M") {
							that.getModel("visibleModel").setProperty("/editBtn", true);
							that.getModel("visibleModel").setProperty("/cancelBtn", true);
							that.getModel("visibleModel").setProperty("/saveBtn", false);
							that.getModel("visibleModel").setProperty("/saveBtnEnable", false);
							that.getModel("visibleModel").setProperty("/editBtnEnable", true);
							that.getModel("visibleModel").setProperty("/cancelBtnEnable", true);
						} else if (that.craftUnion ===
							"Engineering" || that.craftUnion === "SE" ||
							that.payCraft === "E" || that.craftUnion === "E") {
							that.getValueHelpData("/DivisionSearchhelpSet?$filter=RRCode eq '" + oData.RRCode + "'", "DiviData");
							if (oData.RRCode === "" && oData.Region === "" && oData.MilePost === "" && oData.RosterNo === "" && oData.AggCode === "" &&
								oData.PosTypeDesc === "" && oData.WorkSch === "") {
								that.getModel("visibleModel").setProperty("/editBtn", true);
							} else {
								if (that.getModel("viewModel").getProperty("/Role") !== "LR Admin") {
									that.getModel("visibleModel").setProperty("/editBtn", true);
									that.getModel("visibleModel").setProperty("/cancelBtn", true);
									that.getModel("visibleModel").setProperty("/saveBtn", false);
									that.getModel("visibleModel").setProperty("/saveBtnEnable", false);
									that.getModel("visibleModel").setProperty("/editBtnEnable", true);
									that.getModel("visibleModel").setProperty("/cancelBtnEnable", true);
								} else {
									that.getModel("visibleModel").setProperty("/editBtn", true);
									that.getModel("visibleModel").setProperty("/cancelBtn", true);
									that.getModel("visibleModel").setProperty("/saveBtn", false);
									that.getModel("visibleModel").setProperty("/saveBtnEnable", false);
									that.getModel("visibleModel").setProperty("/editBtnEnable", false);
									that.getModel("visibleModel").setProperty("/cancelBtnEnable", false);
									if (that.getModel("viewModel").getProperty("/Role") === "Certification Group") {
										that.getModel("visibleModel").setProperty("/editBtn", false);
										that.getModel("visibleModel").setProperty("/cancelBtn", false);
									}
								}
							}
						} else if (that.craftUnion === "TCU" || that.craftUnion === "ST" || that.craftUnion === "T" || that.payCraft === "T") {
							that.getModel("visibleModel").setProperty("/cancelBtn", true);
							that.getModel("visibleModel").setProperty("/saveBtn", false);
							that.getModel("visibleModel").setProperty("/editBtn", true);
							that.getModel("visibleModel").setProperty("/editBtnEnable", true);
							that.getModel("visibleModel").setProperty("/cancelBtnEnable", true);
						}
						that.existingSavedData = JSON.stringify(oData);
						var oEngChangeJSModel = new JSONModel(oData);
						sap.ui.getCore().setModel(oEngChangeJSModel, "oDataModel");
						that.getView().setModel(oEngChangeJSModel, "oDataModel");
						that.oEfectVal = that.getView().getModel("oDataModel").getData().StartDate;
					},
					function (error) {
						var msg = JSON.parse(error.response.body).error.innererror.errordetails[0].message;
						MessageBox.show(
							msg, {
								icon: MessageBox.Icon.INFORMATION,
								title: "Log",
								actions: [MessageBox.Action.OK],
								onClose: function (oAction) {
									if (oAction === MessageBox.Action.OK) {
										that.byId("positonIdInp").setValueState("Error");
										that.byId("positonIdInp").setTokens([]);
										// that.onPosLiveChange();
										that.byId("positonIdInp").fireTokenUpdate({
											type: "removed",
											addedTokens: [],
											removedTokens: that.byId("positonIdInp").getTokens()
										});
									}
								}
							});
					}
				);
			}
		},
		unique: function (oPSTypeArr, key) {
			for (var i = 1; i < oPSTypeArr.length;) {
				if (oPSTypeArr[i - 1]["" + key + ""] === oPSTypeArr[i]["" + key + ""]) {
					oPSTypeArr.splice(i, 1);
				} else {
					i++;
				}
			}
			return oPSTypeArr;
		},
		getValueHelpData: function (url, modelName) {
			var that = this;
			if (modelName !== "PaySuggModel" && that.getView().getModel(modelName) !== undefined) {
				return;
			}
			var sModel = that.getOwnerComponent().getModel("oDataSrv");
			sModel.read(url, null, null, false,
				function (oData, oResponse) {
					if (oData.results.length > 0) {
						var oModel;
						if (modelName === "payScaleAreaModel" || modelName === "payScaleGrpModel") {
							var oPSAreaArr = oData.results,
								field = "",
								newPsAreaArr;
							if (modelName === "payScaleAreaModel") {
								newPsAreaArr = that.unique(oPSAreaArr, "PayArea");
							} else if (modelName === "payScaleGrpModel") {
								newPsAreaArr = that.unique(oPSAreaArr, "PayGroup");
							}
							var oPSAreaData = {
								results: newPsAreaArr
							};
							oModel = new JSONModel(oPSAreaData);
							oModel.setSizeLimit(oPSAreaData.results.length);
						} else {
							oModel = new JSONModel(oData);
							oModel.setSizeLimit(oData.results.length);
						}
						that.getView().setModel(oModel, modelName);
					}
				},
				function (oResponse) {
					//-----------------------------------------------------------------------	
					// Displaying response body message.
					//-----------------------------------------------------------------------
					that.errorResponse(oResponse);
				}
			);
		},
		handleIconTabBarSelect: function (oEvent) {
			var that = this,
				selectedTabKey = oEvent.getSource().getSelectedKey(),
				posIdVal = that.getModel("viewModel").getProperty("/positonIdVal").trim(),
				Group = that.getModel("viewModel").getProperty("/Group"),
				Role = that.getModel("viewModel").getProperty("/Role");
			var EffectiveDate = that.getView().getModel("viewModel").getProperty("/dateRange");
			var sModel = that.getOwnerComponent().getModel("oDataSrv");
			if (EffectiveDate.includes("/") === "true") {
				var oSplitdate = EffectiveDate.split("/");
				EffectiveDate = oSplitdate[2] + "" + oSplitdate[0] + "" + oSplitdate[1];
			} else {
				EffectiveDate = EffectiveDate;
			}
			if (Role === "LR Admin") {
				that.getModel("visibleModel").setProperty("/editBtn", false);
				that.getModel("visibleModel").setProperty("/cancelBtn", false);
			}
			that.getModel("viewModel").setProperty("/contectIconTabKey", selectedTabKey);
			if (that.oEditAll) {
				sap.m.MessageBox.show("Please Save/Cancel the unsaved changes", {
					icon: sap.m.MessageBox.Icon.ERROR,
					title: "Error",
					actions: [sap.m.MessageBox.Action.OK]
				});
				that.getModel("viewModel").setProperty("/contectIconTabKey", that.aSelected);
			} else if (this.getView().byId("submitId").getEnabled() === true) {
				sap.m.MessageBox.show("Please Submit/Cancel the unsaved changes", {
					icon: sap.m.MessageBox.Icon.ERROR,
					title: "Error",
					actions: [sap.m.MessageBox.Action.OK]
				});
				that.getModel("viewModel").setProperty("/contectIconTabKey", "QUALIFICATION");
				that.byId("posMaintIconTabBar").setSelectedKey("QUALIFICATION"); // ""
			} else {
				if (selectedTabKey !== "QUALIFICATION" && posIdVal.length > 0 && posIdVal !== "") {
					var StartDate = JSON.parse(that.existingSavedData).StartDate;
					var EndDate = JSON.parse(that.existingSavedData).EndDate;
					that.getModel("oDataModel").setProperty("/StartDate", StartDate);
					that.getModel("oDataModel").setProperty("/EndDate", EndDate);
					if (selectedTabKey === "PAYROLL") {
						if (that.craftUnion === "SP" || that.craftUnion === "P" || that.craftUnion === "Payroll") {
							that.getModel("visibleModel").setProperty("/editBtn", true);
							that.getModel("visibleModel").setProperty("/editBtnEnable", true);
							that.getModel("visibleModel").setProperty("/cancelBtn", true);
							that.getModel("visibleModel").setProperty("/cancelBtnEnable", true);
						} else {
							that.getModel("visibleModel").setProperty("/editBtn", false);
							that.getModel("visibleModel").setProperty("/editBtnEnable", false);
							that.getModel("visibleModel").setProperty("/cancelBtn", false);
							that.getModel("visibleModel").setProperty("/cancelBtnEnable", false);
						}
						that.getValueHelpData("/TimeCodesSet?$filter=PosId eq '" + posIdVal + "'", "DiffTimeCodeJSModel");
						sModel.read("/PosPayrollSet(PosId='" + posIdVal + "',UnionType='" + that.craftUnion + "',EffectiveDate='" + EffectiveDate +
							"')",
							null,
							null,
							false,
							function (oData) {
								// that.oDialog.close();
								var oPayrollForm = that.byId("PositionPayrollFormId");
								// that.byId("editId").setEnabled(true);
								that.getValueHelpData("/PayscaleSearchHelpSet?$filter=PayType eq '" + oData.PayType + "'", "payScaleAreaModel");
								that.getValueHelpData("/PayscaleSearchHelpSet?$filter=PayType eq '" + oData.PayType + "'and PayArea eq '" + oData.PayArea +
									"'", "payScaleGrpModel");
								that.getValueHelpData("/payLevelSearchHelpSet?$filter=PayType eq '" + oData.PayType + "'and PayArea eq '" + oData.PayArea +
									"'and PayGroup eq '" + oData.PayGroup +
									"'", "payscaleLevelModel");
								var oPayJSModel = new sap.ui.model.json.JSONModel(oData);
								that.getView().setModel(oPayJSModel, "oPayJSModel");
								that.getModel("oDataModel").setProperty("/StartDate", oData.StartDate);
								that.getModel("oDataModel").setProperty("/EndDate", oData.EndDate);
								var eModel = sap.ui.getCore().getModel("gModel");
								oPayrollForm.setModel(eModel, "mModel");
								oPayrollForm.setModel(oPayJSModel);
								oPayrollForm.bindElement("/");
								that.byId("DifferentialTimecodesId").setValue(oData.DiffTimeCodes);
								var keys = oData.DiffTimeCodes.split(",");
								that.byId("DifferentialTimecodesId").setSelectedKeys(keys);
								that.byId("payprotectedId").setEditable(false);
								that.byId("payscaleTypeId").setEnabled(false);
								that.byId("payscaleAreaId").setEnabled(false);
								that.byId("payscaleLevelId").setEnabled(false);
								that.byId("payAggCode").setEditable(false);
								that.byId("payJobClsId").setEnabled(false);
								that.byId("paytwicId").setEditable(false);
								that.byId("paySeniorityPlanId").setEnabled(false);
								that.byId("payskillDiffId").setEnabled(false);
								that.byId("payExtraBoardId").setEnabled(false);
								that.byId("payEntryId").setEditable(false);
								that.byId("payStepRateId").setEnabled(false);
								that.byId("DifferentialTimecodesId").setEditable(false);
								that.byId("vacationQualId").setEnabled(false);
								that.byId("qualTrainingId").setEditable(false);
								that.byId("payRollPsGroup").setEnabled(false);

								if (that.byId("payprotectedId").getValue() === "" && that.byId("payscaleTypeId").getValue() === "" &&
									that.byId("payscaleAreaId").getValue() === "" && that.byId("payscaleLevelId").getValue() === ""

									&& that.byId("payJobClsId").getValue() === "" &&
									that.byId("paytwicId").getValue() === "" && that.byId("paySeniorityPlanId").getValue() === "" &&
									that.byId("payExtraBoardId").getValue() === "" && that.byId("payEntryId").getValue() === "" &&
									that.byId("payStepRateId").getValue() === "" && that.byId("vacationQualId").getValue() === "") {
									that.getModel("visibleModel").setProperty("/editBtn", false);
								} else {
									// if (that.craftUnion === "SP" || that.craftUnion === "P" || that.craftUnion === "Payroll") {
									// 	that.getModel("visibleModel").setProperty("/editBtn", true);
									// 	that.getModel("visibleModel").setProperty("/editBtnEnable", true);
									// 	that.getModel("visibleModel").setProperty("/cancelBtn", true);
									// 	that.getModel("visibleModel").setProperty("/cancelBtnEnable", true);
									// }
									// that.getModel("visibleModel").setProperty("/editBtn", true);
								}
							},
							function (oResponse) {
								var msg = JSON.parse(oResponse.response.body).error.innererror.errordetails[0].message;
								MessageBox.show(
									msg, {
										icon: MessageBox.Icon.INFORMATION,
										title: "Log",
										actions: [MessageBox.Action.OK],
										onClose: function (oAction) {
											if (oAction === MessageBox.Action.OK) {
												that.byId("positonIdInp").setTokens([]);
												that.byId("positonIdInp").fireTokenUpdate({
													type: "removed",
													addedTokens: [],
													removedTokens: that.byId("positonIdInp").getTokens()
												});
											}
										}
									});

							});
					} else if (selectedTabKey === "POSITION") {
						if (that.craftUnion === "SP" || that.craftUnion === "P" || that.craftUnion === "Payroll") {
							that.getModel("visibleModel").setProperty("/editBtn", false);
							that.getModel("visibleModel").setProperty("/editBtnEnable", false);
							that.getModel("visibleModel").setProperty("/cancelBtn", false);
							that.getModel("visibleModel").setProperty("/cancelBtnEnable", false);
						} else {
							that.getView().getModel("viewModel").setProperty("/enabled", false);
							that.getModel("visibleModel").setProperty("/editBtn", true);
							that.getModel("visibleModel").setProperty("/editBtnEnable", true);
							that.getModel("visibleModel").setProperty("/cancelBtn", true);
							that.getModel("visibleModel").setProperty("/cancelBtnEnable", true);
						}
					} else if (selectedTabKey === "PAYROLL") {
						if (that.craftUnion === "SP" || that.craftUnion === "P" || that.craftUnion === "Payroll") {
							that.getModel("visibleModel").setProperty("/editBtn", true);
							that.getModel("visibleModel").setProperty("/editBtnEnable", true);
							that.getModel("visibleModel").setProperty("/cancelBtn", true);
							that.getModel("visibleModel").setProperty("/cancelBtnEnable", true);
						} else {
							that.getModel("visibleModel").setProperty("/editBtn", false);
							that.getModel("visibleModel").setProperty("/editBtnEnable", false);
							that.getModel("visibleModel").setProperty("/cancelBtn", false);
							that.getModel("visibleModel").setProperty("/cancelBtnEnable", false);
						}
					}
				} else if (selectedTabKey === "QUALIFICATION" && posIdVal.length === 8 && posIdVal !== "") {
					if (that.craftUnion === "SP" || that.craftUnion === "P" || that.craftUnion === "Payroll") {
						that.getModel("visibleModel").setProperty("/editBtnEnable", false);
						that.getModel("visibleModel").setProperty("/cancelBtn", false);
						that.getModel("viewModel").setProperty("/qualStartDateEnable", false);
						that.getModel("viewModel").setProperty("/qualifIdInpEnable", false);
						that.getModel("viewModel").setProperty("/qualEndDateEnable", false);
						that.getModel("viewModel").setProperty("/qualAddBtnEnable", false);
					} else {
						that.getModel("visibleModel").setProperty("/editBtn", true);
						that.getModel("visibleModel").setProperty("/editBtnEnable", true);
						that.getModel("visibleModel").setProperty("/cancelBtn", true);
						that.getModel("visibleModel").setProperty("/cancelBtnEnable", true);
						that.getModel("visibleModel").setProperty("/saveBtn", false);
						that.getModel("visibleModel").setProperty("/submitBtn", false);
						that.getModel("viewModel").setProperty("/qualStartDateEnable", true);
						that.getModel("viewModel").setProperty("/qualifIdInpEnable", true);
						that.getModel("viewModel").setProperty("/qualEndDateEnable", true);
						that.getModel("viewModel").setProperty("/qualAddBtnEnable", false);
					}
					that.qualificationTab();
				}
			}
		},

		onEdit: function () {
			var that = this;
			that.oEditAll = true;
			var selectedTabKey = that.getModel("viewModel").getProperty("/contectIconTabKey"),
				posIdVal = that.getModel("viewModel").getProperty("/positonIdVal").trim(),
				Group = that.getModel("viewModel").getProperty("/Group"),
				Role = that.getModel("viewModel").getProperty("/Role");
			that.aSelected = selectedTabKey;
			that.getView().getModel("visibleModel").setProperty("/editBtn", false);
			that.getView().getModel("visibleModel").setProperty("/cancelBtn", true);
			that.getView().getModel("visibleModel").setProperty("/saveBtn", true);
			that.getView().getModel("visibleModel").setProperty("/saveBtnEnable", true);
			if (selectedTabKey === "POSITION" && posIdVal.length === 8 && posIdVal !== "") {
				if (that.craftUnion === "Payroll" || that.craftUnion === "SP" || that.craftUnion === "P") {
					that.getView().getModel("visibleModel").setProperty("/editBtn", false);
					that.getView().getModel("visibleModel").setProperty("/cancelBtn", false);
				}
				that.getView().getModel("viewModel").setProperty("/enabled", true);

			}
			if (selectedTabKey === "PAYROLL" && posIdVal.length === 8 && posIdVal !== "") {
				that.getView().getModel("viewModel").setProperty("/enabled", true);
			}
			if (selectedTabKey === "QUALIFICATION" && posIdVal.length === 8 && posIdVal !== "") {
				that.getView().getModel("viewModel").setProperty("/qualStartDateEnable", true);
				that.getView().getModel("viewModel").setProperty("/qualifIdInpEnable", true);
				that.getView().getModel("viewModel").setProperty("/qualEndDateEnable", true);
				that.getView().getModel("viewModel").setProperty("/qualAddBtnEnable", true);
				that.getModel("visibleModel").setProperty("/saveBtn", false);
				that.getModel("visibleModel").setProperty("/submitBtn", true);
				that.getModel("visibleModel").setProperty("/qualAddBtnEnable", true);
				that.getModel("visibleModel").setProperty("/submitBtnEnable", false);
				var data = this.byId("selectedQualTable").getItems();
				for (var i = 0; i < data.length; i++) {
					data[i].getAggregation("cells")[9].getItems()[1].setEnabled(true);
				}

			} else {
				if (that.craftUnion === "Mechanical" || that.craftUnion === "SM" || that.craftUnion === "M") {
					sap.m.MessageBox.warning(
						"The edit entered may require this position to be abolished and a bump created for the employee(s) holding this position."
					);
				}
			}
			that.getView().getModel("viewModel").setProperty("/roleEnabled", false);
			that.getView().getModel("viewModel").setProperty("/groupEnabled", false);
			that.getView().getModel("viewModel").setProperty("/posIdEnabled", false);
			that.getView().getModel("viewModel").setProperty("/asDateEnabled", false);
			that.getView().getModel("oDataModel").setProperty("/StartDate", "");
		},
		qualificationTab: function () {
			var that = this;
			var posVal = "";
			if (that.byId("positonIdInp").getTokens().length !== 0) {
				posVal = that.byId("positonIdInp").getTokens()[0].getKey();
			}
			var craftType = that.byId("craftId").getText();
			if (that.craftUnion !== "Payroll" || that.craftUnion !== "SP" || that.craftUnion !== "P") {
				that.byId("assignQualificationForm").setVisible(true);
				that.byId("qualTableCols").setVisible(true);
				that.byId("selectedQualTable").setVisible(true);
				this.byId("qualifIdInp").setEnabled(false);
				this.byId("qualStartDateId").setEnabled(true);
				this.byId("qualEndDateId").setEnabled(true);
			} else {
				that.byId("posAssignId").setEnabled(false);
			}

			if (that.craftUnion === "Engineering" || that.craftUnion === "SE" || that.craftUnion === "E") {
				craftType = "ENG";
			} else if (that.craftUnion === "Mechanical" || that.craftUnion === "SM" || that.craftUnion === "M") {
				craftType = "MECH";
			} else if (that.craftUnion === "TCU" || that.craftUnion === "ST" || that.craftUnion === "T") {
				craftType = "TCU";
			} else if (that.craftUnion === "ATDA" || that.craftUnion === "Dispatchers" || that.craftUnion === "SD" || that.craftUnion === "D") {
				craftType = "ATDA";
			} else if (that.craftUnion === "ILA" || that.craftUnion === "SI" || that.craftUnion === "I") {
				craftType = "ILA";
			}
			//-----------------------------------------------------------------------	
			//Busy Indicator.
			//-----------------------------------------------------------------------
			var pernrModel = that.getOwnerComponent().getModel("oDataSrv");
			pernrModel.read("/QualdetUpdateSet?$filter=CraftType eq '" + craftType + "'and EffectiveDate eq '" + that.byId("dateRangeId").getValue() +
				"' and PosId eq '" + posVal + "'", null, null, true,
				function (oData, oResponse) {
					var cDate = new Date();
					var dateFormat = sap.ui.core.format.DateFormat.getDateInstance({
						pattern: "MM/dd/yyyy"
					});
					var sStartDte = dateFormat.format(cDate);
					that.byId("posMaintId").setBusy(false);
					if (that.craftUnion !== "Payroll" || that.craftUnion !== "SP" || that.craftUnion !== "P") {
						that.getView().getModel("viewModel").setProperty("/qualifIdInpEnable", true);
						that.getView().getModel("viewModel").setProperty("/qualStartDateEnable", true);
						that.getView().getModel("viewModel").setProperty("/qualEndDateEnable", true);
					}
					that.byId("qualifIdInp").setTokens([]);
					that.byId("qualifIdInp").setWidth("70%");
					that.getView().getModel("viewModel").setProperty("/qualTitieIdVal", "");
					that.getView().getModel("viewModel").setProperty("/qulEffectDate", "");
					that.getView().getModel("viewModel").setProperty("/qulEndDate", "");
					that.byId("qualStartDateId").setValueState("None");
					that.byId("qualEndDateId").setValueState("None");

					that.getView().getModel("viewModel").setProperty("/qulEffectDate", sStartDte);
					that.getView().getModel("viewModel").setProperty("/qulEndDate", "99991231");

					that.byId("qualEndDateId").setWidth("70%");
					that.byId("positonIdInp").setValueState("None");
					if (oData.results.length > 0) {
						that.oPosDesc = oData.results[0].PosDesc;
						if (that.oPosDesc !== "") {
							that.getView().getModel("viewModel").setProperty("/posDesc", that.oPosDesc);
						} else {
							that.getView().getModel("viewModel").setProperty("/posDesc", "");
						}
						var qualTableArray = [];
						for (var i = 0; i < oData.results.length; i++) {
							var Qualification = oData.results[i].Qualification,
								QualId = oData.results[i].QualId,
								QualDesc = oData.results[i].QualDesc,
								QualSdate = oData.results[i].QualSdate,
								QualEdate = oData.results[i].QualEdate,
								QualProflevel = oData.results[i].QualProflevel,
								changedOn = oData.results[i].ChangedOn,
								stDate = "",
								enDate = "";
							if (QualSdate === "00000000" || QualSdate === "") {
								stDate = "";
							} else {
								QualSdate = QualSdate;
								var stYear = QualSdate.slice("0", "4");
								var stMonth = QualSdate.slice("4").slice("0", "2");
								var stDay = QualSdate.slice("6");
								stDate = stMonth + "/" + stDay + "/" + stYear;
							}
							if (QualEdate === "00000000" || QualEdate === "") {
								enDate = "";
							} else {
								QualEdate = QualEdate;
								var endYear = QualEdate.slice("0", "4");
								var endMonth = QualEdate.slice("4").slice("0", "2");
								var endDay = QualEdate.slice("6");
								enDate = endMonth + "/" + endDay + "/" + endYear;
							}

							if (Qualification === "00000000" || Qualification === "") {
								Qualification = "";
							} else {
								Qualification = Qualification;
							}
							if (QualId === "00000000" || QualId === "") {
								QualId = "";
							} else {
								QualId = QualId;
							}

							if (QualProflevel === "") {
								QualProflevel = "";
							} else {
								QualProflevel = QualProflevel;
							}

							if (changedOn !== "") {
								var changedDate = oData.results[i].ChangedOn;
								var changedYear = changedDate.slice("0", "4");
								var changedMonth = changedDate.slice("4").slice("0", "2");
								var changedDay = changedDate.slice("6");
								changedOn = changedMonth + "/" + changedDay + "/" + changedYear;
							} else {
								changedOn = "";
							}
							var qualTableObj = {};
							if (stDate !== "" || enDate !== "" || Qualification !== "" || QualId !== "" || QualProflevel !== "") {
								qualTableObj.Qualification = Qualification;
								qualTableObj.QualId = QualId;
								qualTableObj.QualDesc = QualDesc;
								qualTableObj.QualSdate = stDate;
								qualTableObj.QualEdate = enDate;
								qualTableObj.QualProflevel = QualProflevel;
								qualTableObj.ChangedOn = changedOn;
								qualTableObj.ChangedBy = oData.results[i].ChangedBy;
								qualTableObj.rowKey = "B";
								qualTableArray.push(qualTableObj);
							} else {
								qualTableArray.push();
							}
						}
					}

					that.getView().getModel("viewModel").setProperty("/qulEffectDate", sStartDte);
					that.getView().getModel("viewModel").setProperty("/qulEndDate", "99991231");

					var oQualTableModel = new JSONModel({
						"results": qualTableArray
					});
					var oQalTable = that.getView().byId("selectedQualTable");
					oQalTable.setModel(oQualTableModel, "oModelData");
					that.byId("selectedQualTable").getModel("oModelData").refresh(true);
					// initially disable change icons
					var dataInit = oQalTable.getItems();
					for (var p = 0; p < dataInit.length; p++) {
						dataInit[p].getAggregation("cells")[9].getItems()[1].setEnabled(false);
					}
				},
				function (oResponse) {
					//-----------------------------------------------------------------------	
					// Displaying response body message.
					//-----------------------------------------------------------------------
					var oMessage = JSON.parse(oResponse.response.body).find('message').first().text();
					var errmsg;
					if (oMessage === "") {
						errmsg = oResponse.response.body;
					} else {
						errmsg = oMessage;
					}
					sap.m.MessageBox.show(errmsg, {
						icon: sap.m.MessageBox.Icon.ERROR,
						title: "Error",
						actions: [sap.m.MessageBox.Action.OK],
						onClose: function (oAction) {
							if (oAction === sap.m.MessageBox.Action.OK) {

								that.byId("positonIdInp").setValueState("Error");
								that.byId("positonIdInp").setTokens([]);
								that.byId("positonIdInp").fireTokenUpdate({
									type: "removed",
									addedTokens: [],
									removedTokens: that.byId("positonIdInp").getTokens()
								});
							}
						}
					});
				}
			);
		},

		onCancel: function () {
			var that = this;
			that.oEditAll = false;
			that.posChangeFlag = undefined;
			var selectedTabKey = that.getModel("viewModel").getProperty("/contectIconTabKey"),
				posIdVal = that.getModel("viewModel").getProperty("/positonIdVal").trim(),
				Group = that.getModel("viewModel").getProperty("/Group"),
				Role = that.getModel("viewModel").getProperty("/Role");
			that.getView().getModel("viewModel").setProperty("/roleEnabled", true);
			that.getView().getModel("viewModel").setProperty("/groupEnabled", true);
			that.getView().getModel("viewModel").setProperty("/posIdEnabled", true);
			that.getView().getModel("viewModel").setProperty("/asDateEnabled", true);

			if (selectedTabKey === "QUALIFICATION" && posIdVal.length === 8 && posIdVal !== "") {
				sap.m.MessageBox.confirm("Do you want to clear the data?", {
					title: "Confirm",
					actions: [sap.m.MessageBox.Action.YES, sap.m.MessageBox.Action.NO],
					onClose: function (oAction) {
						if (oAction === sap.m.MessageBox.Action.YES) {
							that.oEditAll = false;
							that.getView().getModel("viewModel").setProperty("/roleEnabled", true);
							that.getView().getModel("viewModel").setProperty("/groupEnabled", true);
							that.getView().getModel("viewModel").setProperty("/posIdEnabled", true);
							that.getView().getModel("viewModel").setProperty("/asDateEnabled", true);
							that.posEditBtnPress = false;
							that.oPosEditFlag = false;
							that.byId("qualifIdInp").setTokens([]);
							that.byId("qualifIdInp").setValueState("None");
							that.byId("qualStartDateId").setValueState("None");
							that.byId("qualEndDateId").setValueState("None");
							that.getView().getModel("viewModel").setProperty("/qualifIdInpEnable", false);
							that.getView().getModel("viewModel").setProperty("/qualAddBtnEnable", false);
							that.getView().getModel("viewModel").setProperty("/qualifIdInpEnable", true);
							that.getView().getModel("viewModel").setProperty("/qualStartDateEnable", false);
							that.getView().getModel("viewModel").setProperty("/qualEndDateEnable", false);
							that.getView().getModel("viewModel").setProperty("/qualTitieIdVal", "");
							that.getView().getModel("viewModel").setProperty("/QualNameIdName", "");
							that.getView().getModel("viewModel").setProperty("/QualNameId", "");
							that.getView().getModel("viewModel").setProperty("/QualNameIdDesc", "");
							var cDate = new Date();
							var dateFormat = sap.ui.core.format.DateFormat.getDateInstance({
								pattern: "MM/dd/yyyy"
							});
							var sStartDte = dateFormat.format(cDate);
							that.getView().getModel("oDataModel").setProperty("/StartDate", sStartDte);
							that.getView().getModel("viewModel").setProperty("/qulEffectDate", sStartDte);
							that.getView().getModel("viewModel").setProperty("/qulEndDate", "99991231");
							var itemTableData = that.byId("selectedQualTable").getItems();
							var itemsArray = [];
							var qualCModel = new sap.ui.model.json.JSONModel({
								"results": itemsArray
							});
							var itemsTable = that.byId("selectedQualTable");
							itemsTable.setModel(qualCModel, "oModelData");
							that.getModel("visibleModel").setProperty("/editBtn", true);
							that.getModel("visibleModel").setProperty("/cancelBtn", true);
							that.getModel("visibleModel").setProperty("/saveBtn", false);
							that.getModel("visibleModel").setProperty("/submitBtn", false);
							that.getModel("visibleModel").setProperty("/submitBtnEnable", false);
							that.getModel("visibleModel").setProperty("/qualAddBtnEnable", false);
							if (that.byId("roleIdSelect").getSelectedKey() === "Certification Group") {
								that.getModel("visibleModel").setProperty("/editBtn", false);
								that.getModel("visibleModel").setProperty("/cancelBtn", false);
							}
							that.qualificationTab();
						}
					}
				});

			} else if (that.byId("posMaintIconTabBar").getSelectedKey() === "POSITION") {
				if (posIdVal !== "" && posIdVal.length !== 0) {
					sap.m.MessageBox.confirm("Do you want to cancel the data?", {
						title: "Confirm",
						actions: [sap.m.MessageBox.Action.YES, sap.m.MessageBox.Action.NO],
						onClose: function (oAction) {
							if (oAction === sap.m.MessageBox.Action.YES) {
								if (that.byId("editId").getVisible()) {
									that.getView().getModel("viewModel").setProperty("/enabled", false);
									that.getModel("visibleModel").setProperty("/editBtn", true);
									that.getModel("visibleModel").setProperty("/cancelBtn", true);
									that.getModel("visibleModel").setProperty("/saveBtn", false);
									that.getModel("visibleModel").setProperty("/saveBtnEnable", false);
									if (that.byId("roleIdSelect").getSelectedKey() === "Certification Group") {
										that.getModel("visibleModel").setProperty("/editBtn", false);
										that.getModel("visibleModel").setProperty("/cancelBtn", false);
									}
									that.getView().getModel("viewModel").setProperty("/groupEnabled", true);
									that.byId("positonIdInp").setTokens([]);
									that.byId("positonIdInp").fireTokenUpdate({
										type: "removed",
										addedTokens: [],
										removedTokens: that.byId("positonIdInp").getTokens()
									});
								} else {
									that.emptyData();
									that.oEditAll = false;
									that.posEditBtnPress = false;
									that.oPosEditFlag = false;
									that.getModel("visibleModel").setProperty("/editBtn", true);
									that.getModel("visibleModel").setProperty("/cancelBtn", true);
									that.getModel("visibleModel").setProperty("/saveBtn", false);
									that.getModel("visibleModel").setProperty("/saveBtnEnable", false);
									that.getView().getModel("viewModel").setProperty("/enabled", false);
									that.getView().getModel("viewModel").setProperty("/roleEnabled", true);
									that.getView().getModel("viewModel").setProperty("/groupEnabled", true);
									that.getView().getModel("viewModel").setProperty("/posIdEnabled", true);
									that.getView().getModel("viewModel").setProperty("/asDateEnabled", true);
									if (that.byId("roleIdSelect").getSelectedKey() === "Certification Group") {
										that.getModel("visibleModel").setProperty("/editBtn", false);
										that.getModel("visibleModel").setProperty("/cancelBtn", false);
									}
								}
								var oData = JSON.parse(that.existingSavedData);
								var oDataModel = new JSONModel(oData);
								that.getView().setModel(oDataModel, "oDataModel");
								var cDate = new Date();
								var dateFormat = sap.ui.core.format.DateFormat.getDateInstance({
									pattern: "MM/dd/yyyy"
								});
								var sStartDte = dateFormat.format(cDate);
								that.getView().getModel("oDataModel").setProperty("/StartDate", sStartDte);
							}
						}
					});
				}
			} else if (that.byId("posMaintIconTabBar").getSelectedKey() === "PAYROLL") {
				if (posIdVal !== "" && posIdVal.length !== 0) {
					sap.m.MessageBox.confirm("Do you want to cancel the data?", {
						title: "Confirm",
						actions: [sap.m.MessageBox.Action.YES, sap.m.MessageBox.Action.NO],
						onClose: function (oAction) {
							if (oAction === sap.m.MessageBox.Action.YES) {
								if (that.byId("editId").getVisible()) {
									that.oEditAll = false;
									that.payRollEditBtnPress = false;
									that.psEditFlag = false;
									that.otherEditFlag = false;
									that.getView().getModel("viewModel").setProperty("/roleEnabled", true);
									that.getView().getModel("viewModel").setProperty("/groupEnabled", true);
									that.getView().getModel("viewModel").setProperty("/posIdEnabled", true);
									that.getView().getModel("viewModel").setProperty("/asDateEnabled", true);
									that.getView().getModel("viewModel").setProperty("/enabled", false);
									that.getModel("visibleModel").setProperty("/editBtn", true);
									that.getModel("visibleModel").setProperty("/cancelBtn", true);
									that.getModel("visibleModel").setProperty("/saveBtn", false);
									that.getModel("visibleModel").setProperty("/saveBtnEnable", false);
									if (that.byId("roleIdSelect").getSelectedKey() === "Certification Group") {
										that.getModel("visibleModel").setProperty("/editBtn", false);
										that.getModel("visibleModel").setProperty("/cancelBtn", false);
										that.getModel("visibleModel").setProperty("/saveBtn", false);
										that.getModel("visibleModel").setProperty("/saveBtnEnable", false);
									}
									that.byId("positonIdInp").setTokens([]);
									that.byId("positonIdInp").fireTokenUpdate({
										type: "removed",
										addedTokens: [],
										removedTokens: that.byId("positonIdInp").getTokens()
									});
								} else {
									that.oEditAll = false;
									that.emptyData();
									that.payRollEditBtnPress = false;
									that.psEditFlag = false;
									that.otherEditFlag = false;
									that.getView().getModel("viewModel").setProperty("/roleEnabled", true);
									that.getView().getModel("viewModel").setProperty("/groupEnabled", true);
									that.getView().getModel("viewModel").setProperty("/posIdEnabled", true);
									that.getView().getModel("viewModel").setProperty("/asDateEnabled", true);
									that.getView().getModel("viewModel").setProperty("/enabled", false);
									that.getModel("visibleModel").setProperty("/editBtn", true);
									that.getModel("visibleModel").setProperty("/cancelBtn", true);
									that.getModel("visibleModel").setProperty("/saveBtn", false);
									that.getModel("visibleModel").setProperty("/saveBtnEnable", false);
									if (that.byId("roleIdSelect").getSelectedKey() === "Certification Group") {
										that.getModel("visibleModel").setProperty("/editBtn", false);
										that.getModel("visibleModel").setProperty("/cancelBtn", false);
										that.getModel("visibleModel").setProperty("/saveBtn", false);
										that.getModel("visibleModel").setProperty("/saveBtnEnable", false);
									}
									var oPosVal = that.byId("positonIdInp").getTokens()[0].getKey();
									var craftType = that.byId("craftId").getText();
									var craft;
									if (craftType === "Engineering") {
										craft = "ENG";
									} else if (craftType === "Mechanical") {
										craft = "MECH";
									} else if (craftType === "TCU") {
										craft = "TCU";
									}
									if (oPosVal.length > 0) {
										var oModelSup = that.getView().getModel("oDataSrv");
										oModelSup.read("/PosPayrollSet(PosId='" + oPosVal + "',UnionType='" + craft + "',EffectiveDate='" + that.byId(
												"dateRangeId").getValue() +
											"')", null, null,
											false,
											function (oData) {
												that.oPosDesc = oData.PosDesc;
												var oPayrollForm = that.byId("PositionPayrollFormId");
												that.byId("editId").setEnabled(true);
												var oPayJSModel = new sap.ui.model.json.JSONModel(oData);
												that.getView().setModel(oPayJSModel, "oPayJSModel");
												var eModel = sap.ui.getCore().getModel("gModel");
												oPayrollForm.setModel(eModel, "mModel");
												oPayrollForm.setModel(oPayJSModel);
												oPayrollForm.bindElement("/");
												that.byId("DifferentialTimecodesId").setValue(oData.DiffTimeCodes);
												var keys = oData.DiffTimeCodes.split(",");
												that.byId("DifferentialTimecodesId").setSelectedKeys(keys);
												// that.byId("paystartDate").setEditable(false);
												that.byId("payprotectedId").setEditable(false);
												that.byId("payscaleTypeId").setEnabled(false);
												that.byId("payscaleAreaId").setEnabled(false);
												that.byId("payscaleLevelId").setEnabled(false);
												that.byId("payRollPsGroup").setEnabled(false);
												that.byId("payAggCode").setEditable(false);
												that.byId("payJobClsId").setEnabled(false);
												that.byId("paytwicId").setEditable(false);
												that.byId("paySeniorityPlanId").setEnabled(false);
												that.byId("payskillDiffId").setEnabled(false);
												that.byId("payExtraBoardId").setEnabled(false);
												that.byId("payEntryId").setEditable(false);
												that.byId("payStepRateId").setEnabled(false);
												that.byId("DifferentialTimecodesId").setEditable(false);
												that.byId("vacationQualId").setEnabled(false);
												that.byId("qualTrainingId").setEditable(false);

												that.getModel("visibleModel").setProperty("/editBtn", false);
												that.getModel("visibleModel").setProperty("/cancelBtn", false);

											},
											function () {

											});
									}
								}
								var oData = sap.ui.getCore().getModel("oDataModel").getData();
								var oDataModel = new JSONModel(oData);
								that.getView().setModel(oDataModel, "oDataModel");
							}
						}
					});

				}

			}

		},
		emptyData: function () {
			var that = this;
			that.getView().getModel("viewModel").setProperty("/roleEnabled", true);
			that.getView().getModel("viewModel").setProperty("/groupEnabled", true);
			that.getView().getModel("viewModel").setProperty("/posIdEnabled", true);
			that.getView().getModel("viewModel").setProperty("/asDateEnabled", true);
			// that.getModel("visibleModel").setProperty("/editBtn", true);
			// that.getModel("visibleModel").setProperty("/cancelBtn", true);
			that.getModel("visibleModel").setProperty("/saveBtn", false);
			that.getModel("visibleModel").setProperty("/submitBtn", false);
			that.getModel("visibleModel").setProperty("/editBtnEnable", true);
			that.getModel("visibleModel").setProperty("/cancelBtnEnable", true);
			that.getModel("visibleModel").setProperty("/saveBtnEnable", false);
			that.getModel("visibleModel").setProperty("/submitBtnEnable", false);
			if (that.craftUnion === "Payroll" || that.craftUnion === "P" || that.craftUnion === "SP") {
				that.getModel("visibleModel").setProperty("/editBtn", false);
				that.getModel("visibleModel").setProperty("/cancelBtn", false);
				that.getModel("visibleModel").setProperty("/editBtnEnable", false);
				that.getModel("visibleModel").setProperty("/cancelBtnEnable", false);
			}
			that.getModel("viewModel").setProperty("/contectIconTabKey", "POSITION");
			var posFormContent = that.getView().byId("PositionFormId").getContent();
			// posFormContent.forEach(function (item, index) {
			for (var i = 0; i < posFormContent.length; i++) {
				var index = i,
					item = posFormContent[index],
					oElement = item.getMetadata().getElementName();
				if ((oElement === "sap.m.Input") || (oElement === "sap.m.TextArea") || (oElement === "sap.m.ComboBox") || (oElement ===
						"sap.m.DatePicker")) {
					item.setValueState("None");
				}
			}

			// ---------------- Qualification Tab -----------------------

			that.byId("positonIdInpDec").setText();
			that.byId("qualStartDateId").setValueState("None");
			that.byId("qualEndDateId").setValueState("None");
			that.byId("qualifIdInp").setTokens([]);
			that.byId("qualifIdInp").setValueState("None");
			that.byId("qualStartDateId").setValueState("None");
			that.byId("qualEndDateId").setValueState("None");
			that.getView().getModel("viewModel").setProperty("/qualifIdInpEnable", false);
			that.getView().getModel("viewModel").setProperty("/qualAddBtnEnable", false);
			that.getView().getModel("viewModel").setProperty("/qualifIdInpEnable", true);
			that.getView().getModel("viewModel").setProperty("/qualStartDateEnable", false);
			that.getView().getModel("viewModel").setProperty("/qualEndDateEnable", false);
			that.getView().getModel("viewModel").setProperty("/qualTitieIdVal", "");
			that.getView().getModel("viewModel").setProperty("/QualNameIdName", "");
			that.getView().getModel("viewModel").setProperty("/QualNameId", "");
			that.getView().getModel("viewModel").setProperty("/QualNameIdDesc", "");
			// that.byId("craftId").setText();
			var cDate = new Date();
			var dateFormat = sap.ui.core.format.DateFormat.getDateInstance({
				pattern: "MM/dd/yyyy"
			});
			var sStartDte = dateFormat.format(cDate);
			that.getView().getModel("oDataModel").setProperty("/StartDate", sStartDte);
			that.getView().getModel("viewModel").setProperty("/qulEffectDate", sStartDte);
			that.getView().getModel("viewModel").setProperty("/qulEndDate", "99991231");
			var itemsArray = [];
			var qualCModel = new sap.ui.model.json.JSONModel({
				"results": itemsArray
			});
			var itemsTable = that.byId("selectedQualTable");
			itemsTable.setModel(qualCModel, "oModelData");
			that.posChangeFlag = undefined;
		},

		onSave: function () {
			var that = this,
				entity, validationFlag = "",
				selectedTabKey = that.getModel("viewModel").getProperty("/contectIconTabKey");
			if (that.getView().getModel("oDataModel") !== undefined) {
				var oDataModel = that.getView().getModel("oDataModel").getData();
			}
			if (that.getView().getModel("oPayJSModel") !== undefined) {
				var oPayJSModel = that.getView().getModel("oPayJSModel").getData();
			}
			var posFormContent = that.getView().byId("PositionFormId").getContent();
			that.getView().getModel("viewModel").setProperty("/roleEnabled", true);
			that.getView().getModel("viewModel").setProperty("/groupEnabled", true);
			that.getView().getModel("viewModel").setProperty("/posIdEnabled", true);
			that.getView().getModel("viewModel").setProperty("/asDateEnabled", true);
			/*Validation for Simple form inputs/ combo box*/
			// for (var i = 0; i < posFormContent.length; i++) {
			// 	var index = i,
			// 		item = posFormContent[index],
			// 		oElement = item.getMetadata().getElementName();
			// 	if ((oElement === "sap.m.Input") || (oElement === "sap.m.ComboBox")) {
			// 		if (item.getVisible() === true && (item.getValue().length === 0) && item.getRequired() ===
			// 			true) {
			// 			item.setValueState("Error");
			// 			sap.m.MessageBox.show("Please Enter " + posFormContent[index - 1].getText(), {
			// 				icon: sap.m.MessageBox.Icon.ERROR,
			// 				title: "Error"
			// 			});
			// 			return;
			// 		} else {
			// 			item.setValueState("None");
			// 		}
			// 	}
			// }
			if (oDataModel.StartDate === "") {
				sap.m.MessageBox.show("Please select start date", {
					icon: sap.m.MessageBox.Icon.ERROR,
					title: "Error",
					actions: [sap.m.MessageBox.Action.OK]
				});
				that.getView().getModel("viewModel").setProperty("/posStartDateValState", "Error");
				validationFlag = "X";
				return;
			} else if (that.getView().getModel("viewModel").getProperty("/posStartDateValState") === "Error") {
				sap.m.MessageBox.show("Please select valid start date", {
					icon: sap.m.MessageBox.Icon.ERROR,
					title: "Error",
					actions: [sap.m.MessageBox.Action.OK]
				});
				validationFlag = "X";
				return;
			} else if (this.posChangeFlag === undefined && (that.craftUnion !== "Mechanical" || that.craftUnion !== "M" || that.craftUnion !==
					"SM")) {
				sap.m.MessageBox.show("Please change at least one field value", {
					icon: sap.m.MessageBox.Icon.ERROR,
					title: "Error",
					actions: [sap.m.MessageBox.Action.OK]
				});
				validationFlag = "X";
				return;
			}
			if ((that.craftUnion === "Engineering" || that.craftUnion === "SE" || that.craftUnion === "E") && selectedTabKey === "POSITION") {
				entity = "/PosEngSet";
				oDataModel.ChBegda = oDataModel.StartDate;
				oDataModel.AssignSup = oDataModel.AssignSupEmp;
				oDataModel.AssisDivEng = oDataModel.ADE;
				oDataModel.ChiefEng = oDataModel.CE;
				oDataModel.DivEng = oDataModel.DE;
				if (oDataModel.RostDesc === oDataModel.PriorRightsRostDesc) {
					sap.m.MessageBox.show("Roster No and Prior Rights Roster No should not be same", {
						icon: sap.m.MessageBox.Icon.ERROR,
						title: "Error",
						actions: [sap.m.MessageBox.Action.OK],
						onClose: function (oAction) {
							if (oAction === sap.m.MessageBox.Action.OK) {
								//
							}
						}
					});
				}
			} else if ((that.craftUnion === "Mechanical" || that.craftUnion === "SM" || that.craftUnion === "M") && selectedTabKey ===
				"POSITION") {
				oDataModel.ChBegda = oDataModel.StartDate;
				entity = "/PosMechSet";
			} else if ((that.craftUnion === "Payroll" || that.craftUnion === "P" || that.craftUnion === "SP") && selectedTabKey === "PAYROLL") {
				oPayJSModel.ChBegda = oDataModel.StartDate;
				entity = "/PosPayrollSet";
			} else if ((that.craftUnion === "IHB" || that.craftUnion === "NAHR" || that.craftUnion === "Conrail" || that.craftUnion === "SN" ||
					that.craftUnion === "SC" || that.craftUnion === "SI") && selectedTabKey === "POSITION") {
				oDataModel.ChBegda = oDataModel.StartDate;
				entity = "POS_CR_IHB_NAHRSet";
				if (oDataModel.WorkSchd === "") {
					sap.m.MessageBox.show("Please select Work Schedule", {
						icon: sap.m.MessageBox.Icon.ERROR,
						title: "Error",
						actions: [sap.m.MessageBox.Action.OK]
					});
					validationFlag = "X";
					return;
				}
			} else if ((that.craftUnion === "TCU" || that.craftUnion === "ILA" || that.craftUnion === "ATDA" || that.craftUnion ===
					"Dispatchers" || that.craftUnion === "T" || that.craftUnion === "ST" || that.craftUnion === "SL" || that.craftUnion === "L" ||
					that.craftUnion === "SD" || that.craftUnion === "D") &&
				selectedTabKey ===
				"POSITION") {
				if (that.craftUnion === "TCU" || that.craftUnion === "ST" || that.craftUnion === "T") {
					oDataModel.Department = oDataModel.DepartmentCode;
					entity = "/PosTcuSet";
				} else if (that.craftUnion === "ILA" || that.craftUnion === "SI" || that.craftUnion === "I") {
					entity = "/POSILASet";
				} else if (that.craftUnion === "ATDA" || that.craftUnion === "Dispatchers" || that.craftUnion === "SD" || that.craftUnion === "D") {
					entity = "/POSATDASet";
				}
				if (oDataModel.AssignSup === "00000000") {
					oDataModel.AssignSup = "";
				}
				if (oDataModel.BrkEndTime === "000000") {
					oDataModel.BrkEndTime = "";
				}
				if (oDataModel.BrkStatTime === "000000") {
					oDataModel.BrkStatTime = "";
				}
				oDataModel.ChBegda = oDataModel.StartDate;
				oDataModel.Craft = that.craftDept;
			}

			if (validationFlag !== "X") {
				if ((that.craftUnion === "Payroll" || that.craftUnion === "SP" || that.craftUnion === "P") && selectedTabKey === "PAYROLL") {
					delete oPayJSModel.__metadata;
					oPayJSModel.ChBegda = oDataModel.StartDate;
					that.onSaveService(oPayJSModel, entity);
				} else {
					delete oDataModel.__metadata;
					that.onSaveService(oDataModel, entity);
				}
			}
		},
		onSaveService: function (oEntry, entity) {
			var that = this,
				sModel = that.getOwnerComponent().getModel("oDataSrv");
			sModel.create(entity, oEntry, {
				async: false,
				success: function (succ, res) {
					var oMessage, specialChar;
					if (oMessage === undefined) {
						oMessage = JSON.parse(res.headers["sap-message"]).message;
					}
					specialChar = oMessage.includes("&amp;");
					if (specialChar === true) {
						var splitMsg = oMessage.split("&amp;");
						that.message = splitMsg[0] + "&" + splitMsg[1];
					} else {
						that.message = oMessage;
					}
					sap.m.MessageBox.show(
						that.message, {
							icon: sap.m.MessageBox.Icon.INFORMATION,
							title: "Information",
							onClose: function (sAction) {
								if (sAction === "OK") {
									if (that.message === "Please change at least one field value") {
										return;
									}
									that.oEditAll = false;
									that.posEditBtnPress = false;
									that.oPosEditFlag = false;
									that.bullFlag = "";
									that.posChangeFlag = undefined;
									that.emptyData();
									that.onPositionSubmitInput();
								}
							}
						});
				},
				error: function (oResponse) {
					sap.m.MessageToast.show("Error");
				}
			});
		},
		onPayrollChange: function (oEvent) {
			if (oEvent.getSource().getMetadata().getElementName() === "sap.m.Input") {
				this.sChange = true;
				var oContext = oEvent.getSource().getParent().getParent().getParent().getParent().getModel().getData();
				oContext.BullFlag = "";
			} else if (oEvent.getSource().getMetadata().getElementName() === "sap.m.ComboBox") {
				var len = oEvent.getSource().getItems().length;
				var enteredText = oEvent.getSource().getValue();
				var bExists = false;
				for (var i = 0; i < len; i++) {
					var itemText = oEvent.getSource().getItems()[i].getProperty("text");
					if (itemText === enteredText || itemText.startsWith(enteredText)) {
						bExists = true;
						break;
					}
				}
				if (bExists) {
					oEvent.getSource().setValueState(sap.ui.core.ValueState.None);
					this.sChange = true;
				} else {
					oEvent.getSource().setValueState(sap.ui.core.ValueState.Error);
					oEvent.getSource().setValue();
					sap.m.MessageBox.show("No records found", {
						icon: sap.m.MessageBox.Icon.ERROR,
						title: "Error",
						actions: [sap.m.MessageBox.Action.OK],
						onClose: function (oAction) {
							if (oAction === sap.m.MessageBox.Action.OK) {}
						}
					});
					oEvent.getSource().setValueStateText("Please enter valid " + oEvent.getSource().getParent().getAggregation("label").getText());
				}
			} else {
				this.sChange = true;
			}
			this.posChangeFlag = "X";
		},
		onSkillDiffChange: function () {
			if (this.byId("payskillDiffId").getSelectedKey() === "1") {
				this.byId("DifferentialTimecodesId").setEditable(true);
			} else if (this.byId("payskillDiffId").getSelectedKey() === "3") {
				this.byId("DifferentialTimecodesId").setEditable(true);
			} else {
				this.byId("DifferentialTimecodesId").setEditable(false);
				this.byId("DifferentialTimecodesId").clearSelection();
			}
			this.posChangeFlag = "X";
		},
		onPayrollEntryRateChange: function () {
			var that = this;
			if (that.byId("payEntryId").getValue() > 100) {
				sap.m.MessageBox.show(
					"Entry Rate should be less than or equal to 100", {
						icon: sap.m.MessageBox.Icon.ERROR,
						title: "Error",
						onClose: function (sAction) {
							if (sAction === "OK") {
								that.byId("payEntryId").setValueState("Error");
							}
						}
					});
			} else if (that.byId("payEntryId").getValue().length > 3) {
				sap.m.MessageBox.show(
					"Entry Rate length should be less than or equal to 3", {
						icon: sap.m.MessageBox.Icon.ERROR,
						title: "Error",
						onClose: function (sAction) {
							if (sAction === "OK") {
								that.byId("payEntryId").setValueState("Error");
							}
						}
					});
			} else {
				that.byId("payEntryId").setValueState("None");
				that.posChangeFlag = "X";
				that.otherEditFlag = true;
			}
			this.posChangeFlag = "X";
		},
		onPayProtectedDaysChange: function () {
			var that = this;
			if (that.byId("payprotectedId").getValue().length > 3) {
				sap.m.MessageBox.show(
					"Protected Days length should be less than or equal to 3", {
						icon: sap.m.MessageBox.Icon.ERROR,
						title: "Error",
						onClose: function (sAction) {
							if (sAction === "OK") {
								that.byId("payprotectedId").setValueState("Error");
							}
						}
					});
			} else {
				that.byId("payprotectedId").setValueState("None");
				that.posChangeFlag = "X";
				that.otherEditFlag = true;
			}
		},
		onPSLevelSelChange: function () {
			this.onPayRollComboBoxChange("payscaleLevelId", "payscaleLevelModel", "PayLevel");
			var that = this;
			that.psEditFlag = true;
			if (that.byId("payscaleLevelId").getValue() === "") {
				that.byId("payscaleLevelId").setValueState("None");
			}
			var oSearchParam = that.getView().getModel("oPayJSModel").getProperty("/payLevel");
			var payscaleLevelModel = that.getView().getModel("payscaleLevelModel").getData();
			var validationATrue = [];
			var validationAFalse = [];
			var validation = "X";
			for (var k = 0; k < payscaleLevelModel.results.length; k++) {
				if (payscaleLevelModel.results[k].PayLevel !== oSearchParam) {
					validationATrue.push(validation);
				} else {
					validationAFalse.push(validation);
				}
			}
			if (validationAFalse.length > 0) {
				that.byId("payscaleLevelId").setValueState("None");
			} else {
				if (that.byId("payscaleLevelId").getValue() !== "") {
					that.byId("payscaleLevelId").setValueState("Error");
					sap.m.MessageBox.show("No records found", {
						icon: sap.m.MessageBox.Icon.ERROR,
						title: "Error",
						actions: [sap.m.MessageBox.Action.OK],
						onClose: function (oAction) {
							if (oAction === sap.m.MessageBox.Action.OK) {}
						}
					});
				}
			}
			that.posChangeFlag = "X";
		},
		onPsLevelChange: function () {
			var that = this;
			that.payChangeFlag = "X";
			that.sTotalRateFunc();
		},
		onPayscaleChange: function (oEvent) {
			var that = this,
				osTypeKey;
			var payType = oEvent.getSource().getSelectedKey();
			if (oEvent.getParameter("selectedItem")) {
				osTypeKey = oEvent.getParameter("selectedItem").getKey();
			}
			that.getView().getModel("oPayJSModel").setProperty("/PayType", payType);

			var psAreaModel = that.getOwnerComponent().getModel("oDataSrv");
			if (payType !== "") {
				psAreaModel.read("/PayscaleSearchHelpSet?$filter=PayType eq '" + payType + "' ", null, null,
					false,
					function (oData, oResponse) {
						var oPSAreaArr = [];
						if (oData.results.length > 0) {
							that.byId("payscaleAreaId").setEnabled(true);
							that.getView().getModel("oPayJSModel").setProperty("/PayArea", "");
							that.getView().getModel("oPayJSModel").setProperty("/PayGroup", "");
							that.getView().getModel("oPayJSModel").setProperty("/payLevel", "");
							that.getView().getModel("oPayJSModel").setProperty("/RateUnit", "");
							that.getView().getModel("oPayJSModel").setProperty("/AreaDesc", "");
							that.getView().getModel("oPayJSModel").setProperty("/PayGroupDesc", "");
						} else {
							that.byId("payscaleAreaId").setEnabled(false);
						}
						var psArea = that.byId("payscaleAreaId");
						for (var i = 0; i < oData.results.length; i++) {
							var Object = oData.results[i];
							if (osTypeKey === oData.results[i].PayType) {
								oPSAreaArr.push(Object);
							}
						}
						var newPsAreaArr = that.unique(oPSAreaArr, "PayArea");

						var oPSAreaData = {
							results: newPsAreaArr
						};

						if (oPSAreaData.results.length > 0) {
							that.byId("payscaleAreaId").setEnabled(true);
							that.getView().getModel("oPayJSModel").setProperty("/PayArea", "");
							that.getView().getModel("oPayJSModel").setProperty("/PayGroup", "");
							that.getView().getModel("oPayJSModel").setProperty("/AreaDesc", "");
							that.getView().getModel("oPayJSModel").setProperty("/PayGroupDesc", "");
							that.getView().getModel("oPayJSModel").setProperty("/TotRate", "");
							that.getView().getModel("oPayJSModel").setProperty("/ProRate", "");
						} else {
							that.byId("payscaleAreaId").setEnabled(false);
							that.sTotalRateFunc();
						}

						var oPSAreaModel = new sap.ui.model.json.JSONModel(oPSAreaData);
						sap.ui.getCore().setModel(oPSAreaModel, "payScaleAreaModel");
						psArea.setModel(oPSAreaModel, "payScaleAreaModel");
						that.getView().byId("payRollPsGroup").setEnabled(false);
						that.getView().byId("payscaleLevelId").setEnabled(false);
						that.getView().getModel("oPayJSModel").setProperty("/TotRate", "0.0000");
						that.getView().getModel("oPayJSModel").setProperty("/ProRate", "0.00");

					},
					function () {

					});
			} else {
				var model = new JSONModel({
					results: []
				});
				that.getView().byId("payscaleAreaId").setEnabled(false).setModel(model, "payScaleAreaModel");
				that.getView().byId("payRollPsGroup").setEnabled(false).setModel(model, "payScaleGrpModel");
				that.getView().byId("payscaleLevelId").setEnabled(false).setModel(model, "payscaleLevelModel");
				that.getView().getModel("oPayJSModel").setProperty("/TotRate", "0.0000");
				that.getView().getModel("oPayJSModel").setProperty("/ProRate", "0.00");
			}
			that.posChangeFlag = "X";
		},
		sTotalRateFunc: function () {
			var that = this,
				oType = that.getView().getModel("oPayJSModel").getProperty("/PayType"),
				oArea = that.getView().getModel("oPayJSModel").getProperty("/PayArea"),
				oLevel = that.getView().getModel("oPayJSModel").getProperty("/payLevel"),
				oGroup = this.byId("payRollPsGroup").getSelectedKey();
			if (oType.length > 0) {
				var oData = that.getView().getModel("oRatedModel").getData();
				for (var i = 0; i < oData.length; i++) {
					var oObject = oData[i];
					var rateUnit = oObject.RateUnit;
					if (rateUnit === "H") {
						rateUnit = "Hourly";
					} else if (rateUnit === "D") {
						rateUnit = "Daily";
					} else if (rateUnit === "W") {
						rateUnit = "Weekly";
					} else if (rateUnit === "M") {
						rateUnit = "Monthly";
					} else if (rateUnit === "Y") {
						rateUnit = "Yearly";
					} else {
						rateUnit = "";
					}
					if (((oType === oObject.PayType) && (oArea === oObject.PayArea) && (oLevel === oObject.PayLevel) && oGroup === oObject.PayGroup)) {
						that.getView().getModel("oPayJSModel").setProperty("/RateUnit", rateUnit);
						that.getView().getModel("oPayJSModel").setProperty("/TotRate", oObject.TotRate);
						that.getView().getModel("oPayJSModel").setProperty("/ProRate", oObject.ProRate);
						i = oData.length;
					} else {
						that.getView().getModel("oPayJSModel").setProperty("/TotRate", "");
						that.getView().getModel("oPayJSModel").setProperty("/ProRate", "");
					}
				}
			}
		},

		onPsAreaChange1: function (oEvent) {
			var that = this,
				osAreaKey,
				payType = that.getView().getModel("oPayJSModel").getProperty("/PayType"),
				payArea = that.getView().getModel("oPayJSModel").getProperty("/PayArea");
			if (oEvent.getParameter("selectedItem")) {
				osAreaKey = oEvent.getParameter("selectedItem").getKey();
				that.getView().getModel("oPayJSModel").getProperty("/PayArea", osAreaKey);
			}
			that.psEditFlag = true;
			that.payChangeFlag = "X";
			var psAreaModel = that.getOwnerComponent().getModel("oDataSrv");
			if (payType !== "" && payArea !== "") {
				psAreaModel.read("/PayscaleSearchHelpSet?$filter=PayType eq '" + payType + "' and PayArea eq '" + payArea + "' ", null, null,
					false,
					function (oData, oResponse) {
						if (oData.results.length > 0) {
							that.byId("payRollPsGroup").setEnabled(true);
							that.getView().getModel("oPayJSModel").setProperty("/payLevel", "");
							that.getView().getModel("oPayJSModel").setProperty("/PayGroup", "");
							that.getView().getModel("oPayJSModel").setProperty("/PayGroupDesc", "");
							that.getView().getModel("oPayJSModel").setProperty("/RateUnit", "");
						} else {
							that.byId("payRollPsGroup").setEnabled(false);
						}
						var oPSAreaModel = new sap.ui.model.json.JSONModel(oData);
						sap.ui.getCore().setModel(oPSAreaModel, "payScaleGrpModel");
						that.getView().setModel(oPSAreaModel, "payScaleGrpModel");
						that.getView().byId("payscaleLevelId").setEnabled(false);
						that.getView().getModel("oPayJSModel").setProperty("/TotRate", "0.0000");
						that.getView().getModel("oPayJSModel").setProperty("/ProRate", "0.00");
					},
					function () {

					});
			} else {
				var model = new JSONModel({
					results: []
				});
				that.getView().byId("payRollPsGroup").setEnabled(false);
				that.getView().setModel(model, "payScaleGrpModel");
				that.getView().byId("payscaleLevelId").setEnabled(false);
				that.getView().setModel(model, "payscaleLevelModel");
				that.getView().getModel("oPayJSModel").setProperty("/TotRate", "0.0000");
				that.getView().getModel("oPayJSModel").setProperty("/ProRate", "0.00");
			}
		},
		onPsGrpChange: function () {
			var that = this,
				payType = that.getView().getModel("oPayJSModel").getProperty("/PayType"),
				payArea = that.getView().getModel("oPayJSModel").getProperty("/PayArea"),
				paygrp = that.getView().getModel("oPayJSModel").getProperty("/PayGroup");
			that.byId("payscaleLevelId").setValue();
			that.byId("payRateUnitId").setValue();
			that.psEditFlag = true;
			this.payscaledata(payType, payArea, paygrp);
		},
		payscaledata: function (payType, payArea, paygrp) {
			var that = this;
			var createSubmitModel = that.getView().getModel("oDataSrv");
			if (payType !== "" && payArea !== "" && paygrp !== "") {
				createSubmitModel.read("/payLevelSearchHelpSet?$filter=PayType eq '" + payType + "' and PayGroup eq '" + paygrp +
					"' and PayArea eq '" + payArea + "'", null, null,
					false,
					function (oData, oResponse) {
						if (oData.results.length > 1) {
							that.getView().getModel("oPayJSModel").setProperty("/TotRate", "");
							that.getView().getModel("oPayJSModel").setProperty("/ProRate", "");
						} else {
							that.getView().getModel("oPayJSModel").setProperty("/payLevel", "");
							that.sTotalRateFunc();
						}
						that.byId("payscaleLevelId").setEnabled(true);
						var payscaleLevelModel = new sap.ui.model.json.JSONModel(oData);
						payscaleLevelModel.setSizeLimit(oData.results.length);
						sap.ui.getCore().setModel(payscaleLevelModel, "payscaleLevelModel");
						that.getView().setModel(payscaleLevelModel, "payscaleLevelModel");
					},
					function () {

					});
			} else {
				var model = new JSONModel({
					results: []
				});
				that.getView().byId("payscaleLevelId").setEnabled(false);
				that.getView().setModel(model, "payscaleLevelModel");
				that.getView().getModel("oPayJSModel").setProperty("/TotRate", "0.0000");
				that.getView().getModel("oPayJSModel").setProperty("/ProRate", "0.00");
			}
			that.posChangeFlag = "X";
		},
		onVacQualChange: function (oEvent) {
			this.onPayRollComboBoxChange("vacationQualId", "vacQualModel", "VacationQual", "VacationCode");
		},
		onExtBoardChange: function (oEvent) {
			this.onPayRollComboBoxChange("payExtraBoardId", "extbrdModel", "Location", "ExtraBoardCode");
		},
		onJobClsChange: function (oEvent) {
			this.onPayRollComboBoxChange("payJobClsId", "jobModelData", "JobKey", "JobClass");
		},
		onTwicChange: function (oEvent) {
			this.onPayRollComboBoxChange("paytwicId", "twicSuggModel", "TWIC", "TWICCode");
		},
		onSrPlanChange: function (oEvent) {
			this.onPayRollComboBoxChange("paySeniorityPlanId", "senirModeldata", "PlanDesc", "SenPlan");
		},
		onStepRateIndChange: function (oEvent) {
			this.onPayRollComboBoxChange("payStepRateId", "stepRateModel", "StepRate");
		},

		onPayRollComboBoxChange: function (id, modelName, lField, rField) {
			var that = this;
			that.payChangeFlag = "X";
			that.otherEditFlag = true;
			if (that.byId(id).getValue() === "") {
				that.byId(id).setValueState("None");
			}
			var oSearchParam = that.byId(id).getValue();
			var oModel = that.getView().getModel(modelName).getData();
			var validationATrue = [];
			var validationAFalse = [];
			var validation = "X";
			for (var k = 0; k < oModel.results.length; k++) {
				if (rField !== undefined) {
					if (oModel.results[k][lField] !== oSearchParam && oModel.results[k][rField] !== oSearchParam) {
						validationATrue.push(validation);
					} else {
						validationAFalse.push(validation);
					}
				} else if (rField === undefined) {
					if (oModel.results[k][lField] !== oSearchParam) {
						validationATrue.push(validation);
					} else {
						validationAFalse.push(validation);
					}
				}
			}
			if (validationAFalse.length > 0) {
				that.byId(id).setValueState("None");
			} else {
				if (that.byId(id).getValue() !== "") {
					that.byId(id).setValueState("Error");
					//sap.m.MessageToast.show("No records found");
					sap.m.MessageBox.show("No records found", {
						icon: sap.m.MessageBox.Icon.ERROR,
						title: "Error",
						actions: [sap.m.MessageBox.Action.OK],
						onClose: function (oAction) {
							if (oAction === sap.m.MessageBox.Action.OK) {}
						}
					});
				}
			}
		},
		onDateSelection: function (oEvent) {
			var that = this;
			if (oEvent) {
				that.posChangeFlag = "X";
				var oDP = oEvent.getSource();
				var bValid = oEvent.getParameter("valid");
				if (!bValid) {
					oEvent.getSource().setValue("");
					oDP.setValueState(sap.ui.core.ValueState.Error);
					sap.m.MessageToast.show("Please enter valid date");
					return;
				}
				oDP.setValueState(sap.ui.core.ValueState.None);
			}
		},
		/*Bulletin Comments Pop-UP*/
		onBulltinComentsPress: function () {
			var that = this;
			if (!that.bullComntsDilog) {
				that.bullComntsDilog = sap.ui.xmlfragment("com.position.fragment.BullComment", that);
				that.getView().addDependent(that.bullComntsDilog);
			}
			that.bullComntsDilog.open();
		},
		onBullCommentCancel: function () {
			var that = this;
			that.bullComntsDilog.close();
			that.bullComntsDilog.destroy();
			that.bullComntsDilog = null;
		},
		/*Internal Comments Pop-UP*/
		onIntalComentsPress: function () {
			var that = this;
			if (!that.intComntsDilog) {
				that.intComntsDilog = sap.ui.xmlfragment("com.position.fragment.InternalComments", that);
				that.getView().addDependent(that.intComntsDilog);
			}
			that.intComntsDilog.open();
		},
		onIntCommentCancel: function () {
			var that = this;
			that.intComntsDilog.close();
			that.intComntsDilog.destroy();
			that.intComntsDilog = null;
		}
	});
});