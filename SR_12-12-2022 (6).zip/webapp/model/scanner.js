sap.ui.define(['jquery.sap.global'], function(q) {
	"use strict";
	var B = (function() {
		var D = "sap.ndc.BarcodeScanDialog";
		document.addEventListener("settingsDone", i);
		document.addEventListener("SettingCompleted", i);
		document.addEventListener("mockSettingsDone", i);
		var a = {},
			s, S = new sap.ui.model.json.JSONModel({
				available: false
			}),
			o = null,
			b = {},
			r = true,
			R = new sap.ui.model.resource.ResourceModel({
				bundleName: "sap.ndc.messagebundle"
			});

		function g() {
			try {
				s = cordova.plugins.barcodeScanner;
				if (s) {
					q.sap.log.debug("Cordova BarcodeScanner plugin is available!");
				} else {
					S.setProperty("/available", false);
					q.sap.log.error("BarcodeScanner: cordova.plugins.barcodeScanner is not available");
				}
			} catch (e) {
				q.sap.log.info("BarcodeScanner: cordova.plugins is not available");
				return;
			}
		}

		function i() {
			s = null;
			S.setProperty("/available", true);
			if (sap.Settings === undefined) {
				q.sap.log.debug("No sap.Settings. No feature vector available.");
				g();
			} else if (sap.Settings && typeof sap.Settings.isFeatureEnabled === "function") {
				sap.Settings.isFeatureEnabled("cordova.plugins.barcodeScanner", function(e) {
					if (e) {
						g();
					} else {
						S.setProperty("/available", false);
						q.sap.log.warning("BarcodeScanner: Feature disabled");
					}
				}, function() {
					q.sap.log.warning("BarcodeScanner: Feature check failed");
				});
			} else {
				q.sap.log.warning("BarcodeScanner: Feature vector (sap.Settings.isFeatureEnabled) is not available");
			}
		}

		function c(f, l) {
			var d;
			b.onSuccess = f;
			b.onLiveUpdate = l;
			if (!o) {
				d = new sap.ui.model.json.JSONModel();
				o = sap.ui.xmlfragment(D, {
					onOK: function(e) {
						a.closeScanDialog();
						if (typeof b.onSuccess === "function") {
							b.onSuccess({
								text: d.getProperty("/barcode"),
								cancelled: false
							});
						}
					},
					onCancel: function(e) {
						a.closeScanDialog();
						if (typeof b.onSuccess === "function") {
							b.onSuccess({
								text: d.getProperty("/barcode"),
								cancelled: true
							});
						}
					},
					onLiveChange: function(e) {
						if (typeof b.onLiveUpdate === "function") {
							b.onLiveUpdate({
								newValue: e.getParameter("newValue")
							});
						}
					},
					onAfterOpen: function(e) {
						e.getSource().getContent()[0].focus();
					}
				});
				o.setModel(d);
				o.setModel(R, "i18n");
			}
			return o;
		}
		a.scan = function(f, F, l) {
			var d;
			if (!r) {
				q.sap.log.error("Barcode scanning is already in progress.");
				return;
			}
			r = false;
			if (S.getProperty("/available") === true && s === null) {
				g();
			}
			if (s) {
				s.scan(function(e) {
					if (e.cancelled === "false" || !e.cancelled) {
						e.cancelled = false;
						if (typeof f === "function") {
							f(e);
						}
					} else {
						d = c(f, l);
						d.getModel().setProperty("/barcode", "");
						d.getModel().setProperty("/isNoScanner", false);
						d.open();
					}
					r = true;
				}, function(e) {
					q.sap.log.error("Barcode scanning failed.");
					if (typeof F === "function") {
						F(e);
					}
					r = true;
				});
			} else {
				d = c(f, l);
				d.getModel().setProperty("/barcode", "");
				d.getModel().setProperty("/isNoScanner", true);
				d.open();
			}
		};
		a.closeScanDialog = function() {
			if (o) {
				o.close();
				r = true;
			}
		};
		a.getStatusModel = function() {
			return S;
		};
		i();
		return a;
	}());
	return B;
}, true);