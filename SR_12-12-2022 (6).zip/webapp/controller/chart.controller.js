sap.ui.define([
	"sap/ui/core/mvc/Controller",
	"sap/ui/model/json/JSONModel",
	'sap/viz/ui5/format/ChartFormatter',
	"sap/ui/core/routing/History"

], function(Controller, JSONModel, ChartFormatter, History) {
	"use strict";

	return Controller.extend("com.SR_12-12-2022SR_12-12-2022.controller.chart", {
		onInit: function() {
			var that = this;
			var oRouter = that.getOwnerComponent().getRouter();
			oRouter.getRoute("chart").attachPatternMatched(that._onObjectMatched, that);
		},
		_onObjectMatched: function(oEvent) {
			var that = this;
			var selectedArguments = oEvent.getParameter("arguments").Details;
			var sData = that.getView().getModel("vizFrameModel").getData().results[selectedArguments];
			// jsondata of single row which was clicked
			var vizModel = new JSONModel(sData);
			var oVizFrame = that.getView().byId("idVizFrame");
			oVizFrame.setModel(vizModel, "vizModel");
			var oPopOverBar = this.getView().byId("idPopOver");
			oPopOverBar.connect(oVizFrame.getVizUid());
			oPopOverBar.setFormatString(ChartFormatter.DefaultPattern.STANDARDFLOAT);

			var oVizFrameForm = that.getView().byId("idAddForm");
			oVizFrameForm.setModel(vizModel, "formModel");

			var oVizFrame1 = that.getView().byId("idVizFrame1");
			oVizFrame1.setModel(vizModel, "vizModel");
			var oPopOverBar1 = this.getView().byId("idPopOver1");
			oPopOverBar1.connect(oVizFrame1.getVizUid());
			oPopOverBar1.setFormatString(ChartFormatter.DefaultPattern.STANDARDFLOAT);

			var oVizFrame2 = that.getView().byId("idVizFrame2");
			oVizFrame2.setModel(vizModel, "vizModel");
			var oPopOverBar2 = this.getView().byId("idPopOver2");
			oPopOverBar2.connect(oVizFrame2.getVizUid());
			oPopOverBar2.setFormatString(ChartFormatter.DefaultPattern.STANDARDFLOAT);

		},
		onBack: function() {

			var oHistory, sPreviousHash;

			oHistory = History.getInstance();
			sPreviousHash = oHistory.getPreviousHash();

			if (sPreviousHash !== undefined) {
				window.history.go(-1);
			} else {
				this.getRouter().navTo("InitialView", {}, true /*no history*/ );
			}
		}

	});
});