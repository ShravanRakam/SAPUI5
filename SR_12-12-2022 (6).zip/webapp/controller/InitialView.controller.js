var newArray = [];
sap.ui.define([
	"sap/ui/core/mvc/Controller",
	"sap/ui/model/json/JSONModel",
	"sap/ui/model/Filter",
	"sap/ui/model/FilterOperator",
	"sap/ui/export/Spreadsheet",
	"sap/ndc/BarcodeScanner",
	"sap/m/MessageBox",
	"sap/m/Dialog",
	"sap/m/MessageToast"
	// "com.SR_12-12-2022SR_12-12-2022/libs/Download"
], function(Controller, JSONModel, Filter, FilterOperator, Spreadsheet, BarcodeScanner, MessageBox, Dialog, MessageToast) {
	"use strict";

	return Controller.extend("com.SR_12-12-2022SR_12-12-2022.controller.InitialView", {
		onInit: function() {
			var that = this;
			// model data using from sampleData.json
			// var  orderDetails = new JSONModel(jQuery.sap.getModulePath("com.SR_12-12-2022SR_12-12-2022", "/model/sampleData.json"));
			// // setting the model with the view
			// that.getView().setModel( orderDetails, " orderDetails");

			// var dialogModel = new JSONModel(jQuery.sap.getModulePath("com.SR_12-12-2022SR_12-12-2022", "/model/sampleData.json"));
			// that.getView().setModel(dialogModel, "dialogModel");
			that.getSalesOrder();

			// var assetModel = new JSONModel(jQuery.sap.getModulePath("com.SR_12-12-2022SR_12-12-2022", "/model/standardListItem.json"));
			// that.getView().setModel(assetModel, "assetModel");
			// dummy model used to the user input from the filterbar
			var dummyModel = new JSONModel({
				"selectedSDNo": "",
				"selectedName": "",
				"selectedVkorg": "",
				"selectedSalesType": "",
				"selectedVbtyp": "",
				"selectedWaerk": "",
				"selectedNetwr": "",
				"mTableVisible": false,
				"standardListVisible": false,
				"uTableVisible": false,
				"fragTitle": "",
				"buttonVisible": false,
				"barcodeText": "",
				"barCodeFormat": ""

			});

			// setting up the data as dummy model which contains the user input to the view 
			that.getView().setModel(dummyModel, "dummyModel");

			var inputModel = new JSONModel({
				Vbeln: "",
				Ernam: "",
				Vkorg: "",
				Vbtyp: "",
				Auart: "",
				Netwr: "",
				Waerk: "",
				BarcodeText: "",
				barcodeFormat: "",
				createRow: false,
				updateRow: false
			});
			that.getView().setModel(inputModel, "inputVisible");

			var textModel = new JSONModel({
				Vbeln: "",
				Ernam: "",
				Vkorg: "",
				Vbtyp: "",
				Auart: "",
				Netwr: "",
				Waerk: "",
				BarcodeText: "",
				barcodeFormat: ""
			});
			that.getView().setModel(textModel, "textVisible");

			var buttonModel = new JSONModel({
				editButton: false,
				saveButton: false,
				deleteButton: false,
				cancelButton: false,
				updateButton: false
			});
			that.getView().setModel(buttonModel, "buttonVisible");

		},
		getSalesOrder: function() {
			var that = this;
			var dataModel = that.getOwnerComponent().getModel("salesOrderModel");

			dataModel.read("/sales_headerSet", {
				success: function(OData, res) {
					if (res.statusCode === "200" || res.statusCode === 200) {
						var orderDetails = new JSONModel(OData.results);
						that.getView().setModel(orderDetails, "orderDetails");
						var data = that.getView().getModel("orderDetails").getData();

						that.getView().getModel("buttonVisible").setProperty("/editButton", true);
						that.getView().getModel("buttonVisible").setProperty("/deleteButton", true);
						console.log(data);
					}
				},
				error: function(err) {
					console.log(err);
				}
			});
		},
		onCreate: function() {
			var that = this;
			var dataModelCreate = that.getOwnerComponent().getModel("salesOrderModel");

			var formData = that.getView().getModel("formModel").getData();

			dataModelCreate.create("/sales_headerSet", formData, {
				success: function(OData) {
					MessageToast.show("record Created Successfuly");
				}
			});
			that.onpressCancelM();
			that.getSalesOrder();
		},
		onPressButtons: function(oEvent) {
			var that = this;
			
			var getTexts = oEvent.getSource().getText();
			var oModel = that.getView().getModel("buttonVisible");
			var inputModel = that.getView().getModel("inptVisible");
			if (getTexts === "Edit" || getTexts === "Add") {
				if (getTexts === "Edit") {
					oModel.setProperty("/saveButton", false);
					oModel.setProperty("/updateButton", true);
					inputModel.setProperty("/updateRow", true);
					inputModel.setProperty("/createRow", false);
					
					var selecteditem = oEvent.getSource().getParent().getParent().getBindingContextPath();
					var sIndex = selecteditem.split("/")[selecteditem.split("/").length - 1];
					var object = 	that.getView().getModel("orderDetails").getData()[sIndex];
					var newModel = new JSONModel(object);
					that.getView().setModel(newModel, "objectData");
					if (!that.oDialog) {
						that.oDialog = sap.ui.xmlfragment("com.SR_12-12-2022SR_12-12-2022.fragments.createRecord", that);
						that.getView().addDependent(that.oDialog);
					}

					that.oDialog.open();

					

				} else {
					oModel.setProperty("/updateButton", false);
					oModel.setProperty("/saveButton", true);
					inputModel.setProperty("/createRow", true);
					inputModel.setProperty("/updateRow", false);
					if (!that.oDialog) {
						that.oDialog = sap.ui.xmlfragment("com.SR_12-12-2022SR_12-12-2022.fragments.createRecord", that);
						that.getView().addDependent(that.oDialog);
					}

					that.oDialog.open();

				}

			}

			// this.getView().setModel(newModel, "formModel");
			// this.getView().getModel("buttonVisible").setProperty("/saveButton", false);
			// this.getView().getModel("buttonVisible").setProperty("/updateButton", true);

		},
		onUpdate: function() {
			var that = this;

			var dataModel = that.getOwnerComponent().getModel("salesOrderModel");
			var formdata = this.getView().getModel("formModel").getData();
			dataModel.update("/zempSet('" + formdata.Vbeln + "')", formdata, {
				success: function(oData) {
					MessageToast.show("Updated successfully Successfully");
				}
			});
			this.onCancel();
			this.getSalesOrder();
		},

		onDelete: function() {

		},
		// onRecordPress: function(oEvent){
		// 	var that = this;
		// 	var bValue = that.getView().getModel("orderDetails").getBindingContext();
		// 	getSelectedItems()[0].getBindingContext("orderDetails").sPath;
		// 	var bInput = this.getView().byId("idSalesOrg");
		// 	bInput.setValue(bValue);
		// 	this.oDialog.close();
		// }

		// onValueHelpRequested: function(oEvent) {
		// 	var that = this;
		// 	var getName = oEvent.getSource().getName();
		// 	if(getName==="forAsset"){

		// 	if (!that.sLDialog) {
		// 		that.sLDialog = sap.ui.xmlfragment("com.SR_12-12-2022SR_12-12-2022.fragments.standardListVHD", that.getView()
		// 			.getController());
		// 		that.getView().addDependent(that.sLDialog);
		// 	}
		// 	that.sLDialog.open();
		// 	}else if(getName === "forRetireUnit"){
		// 		if (!that.mDialog) {
		// 		that.mDialog = sap.ui.xmlfragment("com.SR_12-12-2022SR_12-12-2022.fragments.mTable", that.getView()
		// 			.getController());
		// 		that.getView().addDependent(that.mDialog);
		// 	}
		// 	that.mDialog.open();
		// 	}
		// },
		onValueHelpRequested: function(oEvent) {
			var that = this;
			var getName = oEvent.getSource().getName();
			// this model variable is created for reduce the piece of code in every line below
			var model = that.getView().getModel("dummyModel");
			if (getName === "forSalesOrg" || getName === "forSalesType" || getName === "forPrice") {
				if (getName === "forSalesOrg") {
					model.setProperty("/standardListVisible", true);
					model.setProperty("/buttonVisible", false);
					model.setProperty("/uTableVisible", false);
					model.setProperty("/fragTitle", "Standard List");
					model.setProperty("/mTableVisible", false);

				} else if (getName === "forSalesType") {

					model.setProperty("/mTableVisible", true);
					model.setProperty("/buttonVisible", true);
					model.setProperty("/uTableVisible", false);
					model.setProperty("/standardListVisible", false);
					model.setProperty("/fragTitle", "Responsive Table");
				} else {
					model.setProperty("/uTableVisible", true);
					model.setProperty("/mTableVisible", false);
					model.setProperty("/buttonVisible", false);
					model.setProperty("/fragTitle", "Grid Table");
				}

				if (!that.oDialog) {
					that.oDialog = sap.ui.xmlfragment("com.SR_12-12-2022SR_12-12-2022.fragments.oDialog", that.getView()
						.getController());
					that.getView().addDependent(that.oDialog);
				}
				that.oDialog.open();

			}

			// else if(getName === "forRetireUnit"){

			// 	if (!that.mDialog) {
			// 	that.mDialog = sap.ui.xmlfragment("com.SR_12-12-2022SR_12-12-2022.fragments.mTable", that.getView()
			// 		.getController());
			// 	that.getView().addDependent(that.mDialog);
			// }
			// that.mDialog.open();
			// }
		},
		// _________________________________________________________________________________________________________________________________________________________________________________
		// onValueHelpRequestedMTable: function() {
		// 	var that = this;
		// 	if (!that.mDialog) {
		// 		that.mDialog = sap.ui.xmlfragment("com.SR_12-12-2022SR_12-12-2022.fragments.mTable", that.getView()
		// 			.getController());
		// 		that.getView().addDependent(that.mDialog);
		// 	}
		// 	that.mDialog.open();
		// },
		// onValueHelpRequestedUTable: function() {
		// 	var that = this;
		// 	if (!that.uDialog) {
		// 		that.uDialog = sap.ui.xmlfragment("com.SR_12-12-2022SR_12-12-2022.fragments.uTable", that.getView()
		// 			.getController());
		// 		that.getView().addDependent(that.uDialog);
		// 	}
		// 	that.uDialog.open();
		// },

		// onValueHelpRequestedList: function() {
		// 	var that = this;
		// 	if (!that.lDialog) {
		// 		that.lDialog = sap.ui.xmlfragment("com.SR_12-12-2022SR_12-12-2022.fragments.List", that.getView()
		// 			.getController());
		// 		that.getView().addDependent(that.lDialog);
		// 	}
		// 	that.lDialog.open();
		// },
		// onValueHelpRequestedsL: function() {
		// 	var that = this;
		// 	if (!that.oDialog) {
		// 		that.oDialog = sap.ui.xmlfragment("com.SR_12-12-2022SR_12-12-2022.fragments.List", that.getView()
		// 			.getController());
		// 		that.getView().addDependent(that.oDialog);
		// 	}
		// 	that.oDialog.open();
		// },
		// onpressCancel: function() {
		// 	this.sLDialog.close();

		// 	// this.mDialog.close();
		// 	// this.uDialog.close();
		// 	// this.lDialog.close();
		// },
		// onpressCancelU: function() {
		// 	this.uDialog.close();
		// },
		// onpressCancelL: function() {
		// 	this.lDialog.close();
		// },
		// ____________________________________________________________________________________________________________________________________________________________________________
		onpressCancelM: function() {
			var that = this;
			that.oDialog.close();
			that.oDialog.destroy();
			that.oDialog = null;

		},
		onPress: function(oEvent) {
			var that = this;
			// here I have selecting the Index of the selected row 
			var selectedRow = oEvent.getSource().getSelectedIndex();
			// here I am assigning sorting the array with the index number and getting the only property of  Vbtyp
			var getElement = that.getView().getModel(" orderDetails").getData().results[selectedRow].Vbtyp;
			// then i setted the property with the selected Vbtyp with the getElement
			that.getView().getModel("dummyModel").setProperty("/selectedVbtyp", getElement);
			// then i have opened the dialog
			that.oDialog.destroy();
			that.oDialog = null;
			that.oDialog.close();
		},
		onPressList: function(oEvent) {
			var that = this;
			var selectedRow = oEvent.getSource();
		},
		// onConfirm: function(oEvent){
		// 	var that = this;
		// 	var oSelectedItem = oEvent.getParameters("listItems").selectedContexts[0].getObject();
		// 	// var oSelectedItem = sap.ui.getCore().byId("tab1")._oSelectedItem.oBindingContexts.materialModel.sPath;
		// 	// that.getView().getModel("dummyModel").setProperty("/ selectedVbeln", oSelectedItem. Ernam);
		// 	// that.getView().getModel("dummyModel").setProperty("/selectedRetirement_Unit", oSelectedItem.retirement_Unit);
		// 	// that.getView().getModel("dummyModel").setProperty("/selected Vbtyp", oSelectedItem. Vbtyp);
		// 	that.getView().getModel("dummyModel").setProperty("/selectedAsset", oSelectedItem.Asset);
		// },

		onPressSave: function() {
			// var getIdOfElement = sap.ui.getCore().getElementById();
			// if (getIdOfElement === "list1" || getIdOfElement === "tab1") {
			// 	if (getIdOfElement === "list1") {
			// 		var aValue = sap.ui.getCore().byId("list1").getBindingContext("dialogModel").getObject().Asset;
			// 		var oInput = this.getView().byId("idInputAsset");
			// 		oInput.setValue(aValue);
			// 		this.oDialog.close();
			// 	}
			// 	else{
			// 		var bValue = sap.ui.getCore().byId("tab1").getBindingContext(" orderDetails").getObject().Asset;
			// 		var bInput = this.getView().byId("idInputRU");
			// 		bInput.setValue(bValue);
			// 		this.oDialog.close();
			// 	}
			// }
			// = sap.ui.getCore().byId("tab1").getSelectedItem().getBindingContext(" orderDetails").getObject().retirement_Unit;
			// // var bValue=oEvent.getSource().getParent().getContent()[0].getSelectedContexts()[0].getObject().retitrement_Unit;
			var bValue = sap.ui.getCore().byId("tab1").getSelectedItems()[0].getBindingContext("orderDetails").sPath;
			var bInput = this.getView().byId("idSalesOrg");
			bInput.setValue(bValue);
			this.oDialog.close();

			// var aValue = getBindingContext("dialogModel").getObject().Asset;
			// var oInput = this.getView().byId("idInputAsset");
			// oInput.setValue(aValue);
			// this.oDialog.close();

		},
		onPressGo: function(oEvent) {
			var that = this;
			// var getName = oEvent.getSource.getName();
			var filter = [];
			var selectedSalesDocNo = oEvent.getSource().getModel("dummyModel").getProperty("/selectedSDNo");
			if (selectedSalesDocNo) {
				filter.push(new Filter("Vbeln", FilterOperator.Contains, selectedSalesDocNo));
			}
			var selectedCreatedBy = oEvent.getSource().getModel("dummyModel").getProperty("/selectedName");
			if (selectedCreatedBy) {
				filter.push(new Filter("Ernam", FilterOperator.Contains, selectedCreatedBy));
			}
			var selectedSalesOrg = oEvent.getSource().getModel("dummyModel").getProperty("/selectedVkorg");
			if (selectedSalesOrg) {
				filter.push(new Filter("Vkorg", FilterOperator.Contains, selectedSalesOrg));
			}
			var selectedNetwr = oEvent.getSource().getModel("dummyModel").getProperty("/selectedNetwr");
			if (selectedNetwr) {
				filter.push(new Filter("Netwr", FilterOperator.Contains, selectedNetwr));
			}

			var oNewFilter = new Filter({
				filters: filter,
				and: false
			});
			var oTab = that.getView().byId("table");
			oTab.getBinding("items").filter(oNewFilter);

		},

		// onConfirm: function(oControlEvent) {

		// 	var that = this;
		// 	var oSelectedItem = oControlEvent.getParameters("listItems").selectedContexts[0].getObject();
		// 	// var oSelectedItem = sap.ui.getCore().byId("tab1")._oSelectedItem.oBindingContexts.materialModel.sPath;

		// 	that.getView().getModel("groupItems").setProperty("/selected Vbtyp", oSelectedItem. Vbtyp);

		// },
		onSearchData: function(oEvent) {
			var that = this;
			//build filter array

			var sQuery = oEvent.getParameter("query");

			if (!sQuery) {
				sQuery = oEvent.getParameter("newValue");
			}
			var filter1 = new Filter("Vbeln", FilterOperator.Contains, sQuery);
			var filter2 = new Filter("Ernam", FilterOperator.Contains, sQuery);
			var filter3 = new Filter("Vbtyp", FilterOperator.Contains, sQuery);
			var filter4 = new Filter("Auart", FilterOperator.Contains, sQuery);
			var filter5 = new Filter("Netwr", FilterOperator.Contains, sQuery);
			var filter6 = new Filter("Waerk", FilterOperator.Contains, sQuery);
			var filter7 = new Filter("Vkorg", FilterOperator.Contains, sQuery);
			// var filter8 = new Filter("Asset", FilterOperator.Contains, sQuery);
			// var filter9 = new Filter("Asset_Type", FilterOperator.Contains, sQuery);
			var filterData = [filter1, filter2, filter3, filter4, filter5, filter6, filter7];

			var oNewFilter = new Filter({
				filters: filterData,
				and: false
			});
			// filter binding
			var oTab = that.getView().byId("table");
			var oBinding = oTab.getBinding("items");
			oBinding.filter(oNewFilter);

			// var oTable = that.getView().byId("table");
			// var oBindings = oTable.getBinding("items");
			// oBindings.filter(null);

		},
		onCameraPress: function() {
			var that = this;
			that.cameraDialog = new Dialog({
				title: "Click on Capture to take a photo",
				beginButton: new Button({
					text: "Capture",
					press: function(oEvent) {
						that.imageValue = document.getElementById("player");
						var oButton = oEvent.getSource();
						that.imageText = oButton.getParent().getContent()[1].getValue();
						that.cameraDialog.close();
					}
				}),
				content: [
					new sap.ui.core.HTML({
						content: "<video id='player' autoplay></video>"
					}),
					new sap.m.Input({
						placeholder: "Please input image text here",
						required: true
					})
				],
				endButton: new Button({
					text: "Cancel",
					press: function() {
						that.cameraDialog.close();
					}
				})

			});
			this.getView().addDependent(this.cameraDialog);
			this.cameraDialog.open();
			this.cameraDialog.attachBeforeClose(this.setImage, this);
			if (navigator.mediaDevices) {
				navigator.mediaDevices.getUserMedia({
					video: true
				}).then(function(stream) {
					player.srcObject = stream;
					mediaStream = stream;
					//this.video.srcObject = stream;
					this.mediaStream.play();
					mediaStream.stop = function() {
						this.getVideoTracks().forEach(function(track) { //in case... :)
							track.stop();
						});
					};
				});
			}
		},
		setImage: function() {
			var oVBox = this.getView().byId("vBox1");
			var oItems = oVBox.getItems();
			var imageId = 'archie-' + oItems.length;
			var fileName = this.imageText;
			var imageValue = this.imageValue;
			if (imageValue == null) {
				MessageToast.show("No image captured");
			} else {

				var oCanvas = new sap.ui.core.HTML({
					content: "<canvas id='" + imageId + "' width='450px' height='320px' " +
						" style='2px solid red'></canvas> "
				});
				var snapShotCanvas;

				oVBox.addItem(oCanvas);
				oCanvas.addEventDelegate({
					onAfterRendering: function() {
						snapShotCanvas = document.getElementById(imageId);
						var oContext = snapShotCanvas.getContext('2d');
						oContext.drawImage(imageValue, 0, 0, snapShotCanvas.width, snapShotCanvas.height);
						var imageData = snapShotCanvas.toDataURL('image/png');
						var imageBase64 = imageData.substring(imageData.indexOf(",") + 1);
						//	mediaStream.stop();
						//window.open(imageData);  
						//download(imageData, fileName + ".png", "image/png");

					}
				});

			}
		},

		createColumnConfig: function() {
			var aColumns = [];
			aColumns.push({
				label: 'Retirement Unit',
				property: 'retirement_Unit'

			});
			aColumns.push({
				label: 'Company Code',
				property: ' Ernam'
			});
			aColumns.push({
				label: 'Asset Group',
				property: ' Vbtyp'
			});
			aColumns.push({
				label: 'Asset Location',
				property: ' Auart'
			});

			aColumns.push({
				label: ' Netwr',
				property: ' Netwr'
			});
			aColumns.push({
				label: 'Plant Account',
				property: ' Waerk'
			});
			aColumns.push({
				label: 'Asset Industry Code',
				property: ' Vkorg'
			});
			return aColumns;
		},
		onPressExport: function() {
			var that = this;
			var oTable, tableItems;
			oTable = that.getView().byId("table");
			tableItems = oTable.getItems();
			if (tableItems.length > 0) {
				//varibles related to spreedsheet
				var aColumns, oSettings, oSheet;
				aColumns = that.createColumnConfig();
				var collectionRecord = that.getView().getModel("orderDetails").getData().results;
				//calling columns event in order to get that colums
				// aCols = that.createColumnConfig();
				//geting whole data from model
				oSettings = {
					workbook: {
						columns: aColumns,
						context: {
							sheetName: "salesOrderDetails"
						}
					},
					dataSource: collectionRecord,
					fileName: "salesOrderDetails"
				};
				//created spreedsheet
				oSheet = new Spreadsheet(oSettings);
				oSheet.build()
					.then(function() {
						//	MessageToast.show("Spreadsheet export has finished);
					})
					.finally(function() {
						oSheet.destroy();
					});
			}
		},
		// addRow: function() {
		// 	var that = this;
		// 	var oCreateModel = new JSONModel({
		// 		Vbeln: "",
		// 		Ernam: "",
		// 		Vkorg: "",
		// 		Vbtyp: "",
		// 		Auart: "",
		// 		Netwr: "",
		// 		Waerk: ""
		// 	});
		// 	that.getView().setModel(oCreateModel, "formModel");

		// 	that.getView().getModel("buttonVisible").setProperty("/saveButton", true);
		// 	that.getView().getModel("buttonVisible").setProperty("/updateButton", false);

		// 	if (!that.oDialog) {
		// 		that.oDialog = sap.ui.xmlfragment("com.SR_12-12-2022SR_12-12-2022.fragments.createRecord", that);
		// 		that.getView().addDependent(that.oDialog);
		// 	}

		// 	that.oDialog.open();
		// },
		deleteRow: function(oEvent) {
			var oTable = this.getView().byId("table");
			oTable.removeItem(oEvent.getSource().getParent());
		},

		onPressColumn: function(oEvent) {
			var sPath = oEvent.getSource().getBindingContext(" orderDetails").getPath();
			var sIndex = sPath.split("/")[sPath.split("/").length - 1];
			var oRouter = sap.ui.core.UIComponent.getRouterFor(this);

			oRouter.navTo("chart", {
				"Details": sIndex
			});
		},
		_getBusyDialog: function() {
			var oView = this.getView();
			if (!this.dialog) {
				this.dialog = sap.ui.xmlfragment("com.SR_12-12-2022SR_12-12-2022.fragments.busyIndicator", this);
				oView.addDependent(this.dialog);
			}
			return this.dialog;
		},
		onScanSuccess: function() {
			var that = this;
			that._getBusyDialog();

			jQuery.sap.require("sap.ndc.BarcodeScanner");
			sap.ndc.BarcodeScanner.scan(
				function(mResult) {
					var oTable = that.byId("table");
					var serialNumber = oTable.getItems().length + 1;
					var sObject = {};

					sObject.code = mResult.text;
					//alert(sObject.code);
					sObject.format = mResult.format;
					sObject.number = serialNumber;

					var i18nModel = that.getOwnerComponent();
					var error = i18nModel.getModel("i18n").getProperty('submiterror');
					var inputMsg = i18nModel.getModel("i18n").getProperty('code');
					if (sObject.code === "") {
						sap.m.MessageBox.show(
							inputMsg, {
								icon: sap.m.MessageBox.Icon.ERROR,
								title: error //"Error during submitting!"
							});

					} else if (sObject.format === "") {
						sap.m.MessageBox.show(
							inputMsg, {
								icon: sap.m.MessageBox.Icon.ERROR,
								title: error //"Error during submitting!"
							});

					} else {
						newArray.push(sObject);
						// that.getView().getModel(" orderDetails").getData.push(sObject);
						// var oModel = new sap.ui.model.json.JSONModel(newArray);
						// oTable.setModel(oModel, "barcodes");

						var oModel = that.getView().getModel(" orderDetails");
						var aData = oModel.getProperty("/results");
						aData.push.apply(aData, newArray);
						oModel.setProperty("/results", aData);
					}

				},
				function(Error) {
					var i18nModel = that.getOwnerComponent();
					var error = i18nModel.getModel("i18n").getProperty('submiterror');
					var inputMsg = i18nModel.getModel("i18n").getProperty('code');
					sap.m.MessageBox.show(
						inputMsg, {
							icon: sap.m.MessageBox.Icon.ERROR,
							title: error //"Error during submitting!"
						});
				}

			);

		},
		onItemDelete: function(e) {
			if (e.getSource().getItems().length > 0) {
				var path = e.getParameter('listItem').getBindingContext("barcodes").getPath();
				var idx = parseInt(path.substring(path.lastIndexOf('/') + 1));
				var m = e.getSource().getModel("barcodes");

				var d = m.getData();
				d.splice(idx, 1);
				for (var i = 0; i < d.length; i++) {
					d[i].number = i + 1;
				}
				m.setData(d);

			}

		}

	});
});