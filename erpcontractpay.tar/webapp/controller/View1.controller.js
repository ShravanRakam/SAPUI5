sap.ui.define([
    "sap/ui/core/mvc/Controller",
    "sap/ui/model/json/JSONModel",
    "sap/ui/model/Filter",
    "sap/ui/model/FilterOperator",
    "sap/ui/model/Sorter",
    // "../model/formatter",
    "sap/m/MessageBox",
    "./persoCode",
    "sap/ui/table/TablePersoController",
    "sap/ui/export/Spreadsheet",
    "sap/ui/export/library",
    "../libs/xlsx"
],
    /**
     * @param {typeof sap.ui.core.mvc.Controller} Controller
     */
    function (Controller, JSONModel, Filter, FilterOperator, Sorter, MessageBox, persoCode, TablePersoController, Spreadsheet, exportLibrary, xlsx) {
        "use strict";

        return Controller.extend("erp.erpcontractpay.controller.View1", {
            onInit: function () {
                var oExcelModel = new JSONModel();
                this.getView().setModel(oExcelModel, "ExcelModel");
                var sPath = jQuery.sap.getModulePath("sowtracker", "/model/dropdownsData.json");
                var oDropdownModel = new JSONModel(sPath);
                this.getView().setModel(oDropdownModel, "dropDownModel");
                var oVisibleModel = new JSONModel({
                    Text: true,
                    Input: false,
                    formBusy: false,
                    TableBusy: false,
                    selectVisible: false,
                    fbEditable: true,
                    MultiEditButton: true,
                    MultiSaveButton: false,
                    MultiCancelButton: false,
                    createEndbleButton: true,
                    tableLenght: 0,
                    clientBusy: false

                });
                this.getView().setModel(oVisibleModel, "visibleModel");
                var oRefreshModel = new JSONModel({
                    Name: "",
                    DialogName:"",
                    year: ""
                });
                this.getView().setModel(oRefreshModel, "searchModel");
              this._oTPC = new TablePersoController({
                table: this.getView().byId("ContractTableId"),
                persoService: persoCode
            });
            this.getErpContract();
        },
        oData: function () {
            this.getErpContract();
        },
        openPersoDialog: function () {
            var that = this;
            that._oTPC.openDialog();
        },
        getErpContract: function () {
            var that = this,
                FinalTableData = [],
                oDataModel = that.getOwnerComponent().getModel();
                that.getView().getModel("visibleModel").setProperty("/TableBusy", true);
            oDataModel.read("/Contractor_paySet", {
                success: function (data) {
                    that.getView().getModel("visibleModel").setProperty("/TableBusy", false);
                   var oTableModel = new JSONModel(data.results);
                   that.totalYearlyRevenue(data);
                    that.getView().setModel(oTableModel, "tableModel");
                    that.getView().getModel("visibleModel").setProperty("/tableLenght", data.results.length);
                     
                     that.onGoPress();
                },
                error: function (error) {
                    that.getView().getModel("visibleModel").setProperty("/TableBusy", false);
                    MessageBox.error(JSON.parse(error.responseText).error.message.value);
                    
                }
            });
        },
        totalYearlyRevenue: function(oData){
            var that = this;
            oData.results.forEach(function(object){
                object.total = parseFloat(object.Zjan) + parseFloat(object.Zfeb) + parseFloat(object.Zmar) + parseFloat(object.Zapr) + parseFloat(object.Zmay) + parseFloat(object.Zjun) + parseFloat(object.Zjul) + parseFloat(object.Zaug) + parseFloat(object.Zsep) + parseFloat(object.Zoct) + parseFloat(object.Znov) + parseFloat(object.Zdec);
                object.total.toString();
            });
        },
        onMultiEditPress: function () {
            var dialog = new sap.m.Dialog({})
            dialog.open();
            this.getView().getModel("visibleModel").setProperty("/Text", false);
            this.getView().getModel("visibleModel").setProperty("/Input", true);
            this.getView().getModel("visibleModel").setProperty("/fbEditable", false);
            this.getView().getModel("visibleModel").setProperty("/selectVisible", true);
            this.getView().getModel("visibleModel").setProperty("/MultiEditButton", false);
            this.getView().getModel("visibleModel").setProperty("/MultiSaveButton", true);
            this.getView().getModel("visibleModel").setProperty("/MultiCancelButton", true);
            this.getView().getModel("visibleModel").setProperty("/createEndbleButton", false);
            dialog.close();
        },
        onMultiSavePress: function () {
            var aUpdateArray = [];
            var that = this;
            
            that.getView().getModel("visibleModel").setProperty("/Text", true);
            that.getView().getModel("visibleModel").setProperty("/Input", false);
            this.getView().getModel("visibleModel").setProperty("/fbEditable", true);
            that.getView().getModel("visibleModel").setProperty("/selectVisible", false);
            that.getView().getModel("visibleModel").setProperty("/MultiEditButton", true);
            that.getView().getModel("visibleModel").setProperty("/MultiSaveButton", false);
            that.getView().getModel("visibleModel").setProperty("/MultiCancelButton", false);
            that.getView().getModel("visibleModel").setProperty("/createEndbleButton", true);
            var data = that.getView().getModel("tableModel").getData();
            data.forEach(function (obj) {
                delete obj.__metadata;
                delete obj.total
                aUpdateArray.push(obj);
            });

            var UpdateData = {
                CntrId: "",
                Contractor_paySet: data
            };
            that.getView().getModel("visibleModel").setProperty("/TableBusy", true);
            var oDataModel = that.getOwnerComponent().getModel();
            oDataModel.create("/DH_contractor_paySet", UpdateData, {
                success: function (oData) {
                    that.getView().getModel("visibleModel").setProperty("/TableBusy", false);
                    MessageBox.success("Updated Successfully.");
                    
                    that.getErpContract();
                    that.onGoPress();
                },
                error: function () {
                    that.getErpContract();
                    that.getView().getModel("visibleModel").setProperty("/TableBusy", false);
                    MessageBox.error(JSON.parse(error.responseText).error.message.value);
                    
                }
            });
        },
        onMultiCancelPress: function () {
            this.getErpContract();
            this.getView().getModel("visibleModel").setProperty("/Text", true);
            this.getView().getModel("visibleModel").setProperty("/Input", false);
            this.getView().getModel("visibleModel").setProperty("/fbEditable", true);
            this.getView().getModel("visibleModel").setProperty("/selectVisible", false);
            this.getView().getModel("visibleModel").setProperty("/MultiEditButton", true);
            this.getView().getModel("visibleModel").setProperty("/MultiSaveButton", false);
            this.getView().getModel("visibleModel").setProperty("/MultiCancelButton", false);
            this.getView().getModel("visibleModel").setProperty("/createEndbleButton", true);
        },
        onCreatePress: function(oEvent){
            var that = this,
            object = {
                "CntrId": "",
                "Status": "",
                "Zjan": "",
                "Zfeb": "",
                "Zmar": "",
                "Zapr": "",
                "Zmay": "",
                "Zjun": "",
                "Zjul": "",
                "Zaug": "",
                "Zsep": "",
                "Zoct": "",
                "Znov": "",
                "Zdec": "",
                "Zyear": "",
            }
            var oModel = new JSONModel(object);
            that.getView().setModel(oModel, "formModel");
            if (!this.onCreateDialog) {
                this.onCreateDialog = new sap.ui.xmlfragment("erp.erpcontractpay.fragments.create", this);
                this.getView().addDependent(this.onCreateDialog);
            }
            this.onCreateDialog.open();
        },
        onSavePress: function(){
            var that = this,
           form =  that.getView().getModel("formModel").getData(),
            oDataModel = that.getOwnerComponent().getModel();
                that.getView().getModel("visibleModel").setProperty("/formBusy", true);
            oDataModel.create("/Contractor_paySet",form, {
                success: function (data) {
                    that.getView().getModel("visibleModel").setProperty("/formBusy", false);
                   MessageBox.success("Record created Successfully", {
                    actions: [MessageBox.Action.OK,],
                    emphasizedAction: MessageBox.Action.OK,
                    onClose: function (sAction) {
                        if(sAction === "OK"){
                            that.getErpContract();
                        }
                    }
                });
                   that.onCancelPress();
                },
                error: function (error) {
                    that.getView().getModel("visibleModel").setProperty("/formBusy", false);
                    MessageBox.error(JSON.parse(error.responseText).error.message.value);
                }
            });
        },
        onCancelPress: function(){
            var that = this;
            if(that.onCreateDialog){
                that.onCreateDialog.close();
                that.onCreateDialog.destroy();
                that.onCreateDialog = null;
            }
        },
        onHandleYearSearch: function(){
            var that = this,
            inputYear = new Date().getFullYear().toString(),
            standardYear = "2023",
            arrayYear = [];
            for(var year = standardYear; year <=inputYear; year++){
                arrayYear.push({"year": year});
            }
            var oModel = new JSONModel(arrayYear);
            that.getView().setModel(oModel, "yearModel");
            
        },
        onGoPress: function () {
            var that = this,
                ofilter = [];
                that.getView().getModel("visibleModel").setProperty("/TableBusy", true);
            var name = this.getView().getModel("searchModel").getProperty("/Name");
            var year = this.getView().getModel("searchModel").getProperty("/year");
            if (name.length > 0) {
                ofilter.push(new sap.ui.model.Filter("Name", sap.ui.model.FilterOperator.Contains, name)); 
            }
            if(year.length > 0){
                that.onHandleYearSearch();
                ofilter.push(new sap.ui.model.Filter("Zyear", sap.ui.model.FilterOperator.Contains, year));
            }
            var oTab = that.getView().byId("ContractTableId");
            var oBinding = oTab.getBinding("rows");
            oBinding.filter(ofilter);
            that.getView().getModel("visibleModel").setProperty("/TableBusy", false);
            // this.filterData();
        },
        onNameDilaog:function(){
            if (!this.onEmpNameDialog) {
                this.onEmpNameDialog = new sap.ui.xmlfragment("erp.erpcontractpay.fragments.EmpDetails", this);
                this.getView().addDependent(this.onEmpNameDialog);
            }
            this.onEmpNameDialog.open();
        },
        onEmpSelect: function (oEvent) {
            var Emp = oEvent.getSource().getBindingContext("tableModel").getObject();
            this.getView().getModel("searchModel").setProperty("/Name", Emp.Name);
            this.onEmpNameDialog.close();
            this.onGoPress();
            var oTab = sap.ui.getCore().byId("EmpTable");
            var oBinding = oTab.getBinding("items");
            oBinding.filter([]);
            this.getView().getModel("searchModel").setProperty("/DialogName","");
        },
        onEmpIdSearch:function(oEvent){
            var that = this,
            ofilter = [];      
        var name = oEvent.getSource().getValue();
        if (name.length > 0) {
            ofilter.push(new sap.ui.model.Filter("Name", sap.ui.model.FilterOperator.Contains, name)); 
        }
        var oTab = sap.ui.getCore().byId("EmpTable");
        var oBinding = oTab.getBinding("items");
        oBinding.filter(ofilter);
      
        },
        onEmpIdClose:function(){
            this.onEmpNameDialog.close();  
        },
        onRefresh: function () {
            var that = this;
            var refreshModel = that.getView().getModel("searchModel");
            refreshModel.setProperty("/Name", "");
            that.getView().byId("ContractTableId").getBinding("rows").filter([]);
        },
        createColumnConfig: function () {
            var aCols = [];

            aCols.push({
                label: 'Employee Id',
                property: 'CntrId'

            });

            aCols.push({
                label: 'Name',
                property: 'Name'

            });

            aCols.push({
                label: 'Status',
                property: 'Status'

            });

            aCols.push({
                label: 'Year',
                property: 'Zyear'

            });
            aCols.push({
                label: 'January',
                property: 'Zjan'

            });
            aCols.push({
                label: 'February',
                property: 'Zfeb'

            });
            aCols.push({
                label: 'March',
                property: 'Zmar'

            });
            aCols.push({
                label: 'April',
                property: 'Zapr'
            });
            aCols.push({
                label: 'May',
                property: 'Zmay'

            });
            aCols.push({
                label: 'June',
                property: 'Zjun'

            });
            aCols.push({
                label: 'July',
                property: 'Zjul'

            });
            aCols.push({
                label: 'August',
                property: 'Zaug'

            });
            aCols.push({
                label: 'September',
                property: 'Zsep'

            });
            aCols.push({
                label: 'October',
                property: 'Zoct'

            });
            aCols.push({
                label: 'November',
                property: 'Znov'

            });
           aCols.push({
                label: 'December',
                property: 'Zdec'

            });
          

            return aCols;
        },

        onExport: function () {
            var that = this;
            var TableData = that.getView().byId("ContractTableId");
            var TableItems = that.getView().getModel("tableModel").getData();
            if (TableItems.length > 0) {
                var aCols = that.createColumnConfig();
                var Collectionrecord = that.getView().getModel("tableModel").getData();

                var oSettings = {
                    workbook: {
                        columns: aCols,
                        context: {
                            sheetName: "ERP Contract Pay"
                        }
                    },
                    dataSource: Collectionrecord,
                    fileName: "ERP Contract Pay"
                };
                var oSheet = new Spreadsheet(oSettings);
                oSheet.build()
                    .then(function () {

                    })
                    .finally(function () {
                        oSheet.destory();
                    });

            }
        },
        onEmpIdValueHelpPress: function () {
            if (!this.EmpDialog) {
                this.EmpDialog = new sap.ui.xmlfragment("erp.erpcontractpay.fragments.EmpDetails", this);
                this.getView().addDependent(this.EmpDialog);
            }
            this.EmpDialog.open();
        },
        });
    });
