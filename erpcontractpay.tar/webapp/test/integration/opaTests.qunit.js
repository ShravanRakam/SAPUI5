/* global QUnit */

sap.ui.require(["erp/erpcontractpay/test/integration/AllJourneys"
], function () {
	QUnit.config.autostart = false;
	QUnit.start();
});
