sap.ui.define([
	"erp/erpcontractpay/test/unit/controller/View1.controller"
], function () {
	"use strict";
});
