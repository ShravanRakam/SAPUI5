var XLSX;
var maxRowsSelect = 25;
jQuery.sap.require("com.zarchivalsystems.Libs.jszip");
// jQuery.sap.require("com.zarchivalsystems.Libs.xlsx");
jQuery.sap.require("jquery.sap.resources");
jQuery.sap.require("jquery.sap.storage");
jQuery.sap.require("com.zarchivalsystems.Libs.pdf");
jQuery.sap.require("com.zarchivalsystems.Libs.FileSaver");

sap.ui.define([
    "sap/ui/core/mvc/Controller",
    "com/zarchivalsystems/controller/BaseController",
    "sap/ui/model/json/JSONModel",
    "sap/ui/model/Filter",
    "sap/ui/model/FilterOperator",
    "sap/m/MessageBox",
    "sap/ui/core/util/Export",
    "sap/ui/core/util/ExportTypeCSV",
    'sap/ui/core/Fragment',
    'sap/m/MessageToast'

],
    /**
     * @param {typeof sap.ui.core.mvc.Controller} Controller
     */
    function (Controller, BaseController, JSONModel, Filter, FilterOperator, MessageBox, Export, ExportTypeCSV, Fragment, MessageToast) {
        "use strict";


        return BaseController.extend("com.zarchivalsystems.controller.ArchivalSystems", {
            onInit: function () {

                var oFilterModel = new JSONModel({
                    payer: "",
                    soldTo: "",
                    country: "",
                    invoiceNumber: "",
                    invoiceType: "",
                    billingDate: "",
                    outputType: ""
                });
                this.setModel(oFilterModel, "FilterModel");

                // var oFilterModel = new JSONModel({
                //     payer: "",
                //     soldTo: "",
                //     country: [],
                //     invoiceNumber: "",
                //     invoiceType: [],
                //     billingDate: "",
                //     outputType: []
                // });
                // this.setModel(oFilterModel, "FilterModel");

                var oSelectModel = new JSONModel({
                    tableData: [],
                    originalData: [],
                    selectedRows: [],
                    noOfRows: 0,
                    startIndex: 0,
                    endIndex: 0,
                    noOfTableRows: 25,
                    isSelectDataLoading: false,
                    isPdfDataLoading: false
                });
                this.setModel(oSelectModel, "SelectModel");


                var oSearchModel = new JSONModel({
                    InvoiceTypeData: [],
                    CountryData: [],
                    OutputTypeData: [],
                    PayerData: [],
                    SoldToData: [],
                    IsDetailsLoading: true,
                    ApiData: []
                });

                this.setModel(oSearchModel, "SearchModel");


                this.fnGetSearchParametersData();
                this.fnGetAPIUrls();


                var that = this;

                var oModel = this.getOwnerComponent().getModel("searchDataModel");
                oModel.attachBatchRequestCompleted(function (oEvent) {
                    // if (oEvent.getParameters().requests[0].url.includes("") && oEvent.getParameters().success) {

                    //     // }
                    // }
                    that.getModel("SearchModel").setProperty("/IsDetailsLoading", false);
                    // debugger;
                });





            },

            fnGetAPIUrls: function () {
                var oModel = this.getOwnerComponent().getModel("searchDataModel");
                var that = this;


                oModel.read("/UrlDataSet", {
                    success: function (oData) {
                        // debugger;

                        that.getModel("SearchModel").setProperty("/ApiData", oData.results);
                    },
                    error: function (oError) {
                        // debugger;
                    }
                });
            },

            fnGetSearchParametersData: function () {
                var oModel = this.getOwnerComponent().getModel("searchDataModel");
                var that = this;

                oModel.read("/BillingTypeSet", {
                    success: function (oData) {
                        that.getModel("SearchModel").setProperty("/InvoiceTypeData", oData.results);
                    },
                    error: function (oError) {
                        that.getModel("SearchModel").setProperty("/IsDetailsLoading", false);
                    }
                });

                oModel.read("/CountrySet", {
                    success: function (oData) {
                        that.getModel("SearchModel").setProperty("/CountryData", oData.results);
                    },
                    error: function (oError) {
                        that.getModel("SearchModel").setProperty("/IsDetailsLoading", false);
                    }
                });

                oModel.read("/OutputTypeSet", {
                    success: function (oData) {
                        that.getModel("SearchModel").setProperty("/OutputTypeData", oData.results);
                    },
                    error: function (oError) {
                        that.getModel("SearchModel").setProperty("/IsDetailsLoading", false);
                    }
                });

                //commented due to performance issue. Have to uncomment again


                // oModel.read("/PayerSet", {
                //     success: function (oData) {
                //         that.getModel("SearchModel").setProperty("/PayerData", oData.results);
                //     },
                //     error: function (oError) {

                //     }
                // });

                // oModel.read("/SoldToSet", {
                //     success: function (oData) {
                //         that.getModel("SearchModel").setProperty("/SoldToData", oData.results);
                //     },
                //     error: function (oError) {

                //     }
                // });




            },

            onClear: function () {
                this.getModel("FilterModel").setProperty("/payer", "");
                this.getModel("FilterModel").setProperty("/country", "");
                this.getModel("FilterModel").setProperty("/invoiceNumber", "");
                this.getModel("FilterModel").setProperty("/invoiceType", "");
                this.getModel("FilterModel").setProperty("/soldTo", "");
                this.getModel("FilterModel").setProperty("/billingDate", "");
                this.getModel("FilterModel").setProperty("/outputType", "");

                //un comment this code when use value help functionality
                // this.byId("payerInput").setValue();
                // this.byId("soldToInput").setValue();
                this.byId("invoiceTypeMCBox").removeAllSelectedItems();
                this.byId("countryMCBox").removeAllSelectedItems();
                this.byId("outputTypeMCBox").removeAllSelectedItems();


                // this.getModel("FilterModel").setProperty("/fromDate", "");
                // this.getModel("FilterModel").setProperty("/toDate", "");
            },

            // onBillingDateChange: function (oEvent) {
            //     // debugger;
            //     var date = oEvent.getParameter("value").split(" - ");

            //     var dateFormat = sap.ui.core.format.DateFormat.getDateInstance({ pattern: "YYYYMMdd" });

            //     var fromDate = dateFormat.format(new Date(date[0]));
            //     var toDate = dateFormat.format(new Date(date[1]));

            //     this.getModel("FilterModel").setProperty("/fromDate", fromDate);
            //     this.getModel("FilterModel").setProperty("/toDate", toDate);

            // },

            onSearch: function () {
                var that = this;

                that.getModel("SelectModel").setProperty("/isSelectDataLoading", true);

                var payer = this.fnCheckData(this.getModel("FilterModel").getProperty("/payer"));
                var soldTo = this.fnCheckData(this.getModel("FilterModel").getProperty("/soldTo"));
                var country = this.fnCheckData(this.getModel("FilterModel").getProperty("/country"));
                var invoiceNumber = this.fnCheckData(this.getModel("FilterModel").getProperty("/invoiceNumber"));
                var invoiceType = this.fnCheckData(this.getModel("FilterModel").getProperty("/invoiceType"));
                var billingDate = this.fnCheckData(this.getModel("FilterModel").getProperty("/billingDate"));
                var outputType = this.fnCheckData(this.getModel("FilterModel").getProperty("/outputType"));

                var apiData = this.getModel("SearchModel").getProperty("/ApiData");
                // var fromDate = this.getModel("FilterModel").getProperty("/fromDate");
                // var toDate = this.getModel("FilterModel").getProperty("/toDate");

                var fromDate;
                var toDate

                var dateFormat = sap.ui.core.format.DateFormat.getDateInstance({ pattern: "YYYYMMdd" });
                if (billingDate !== "" && billingDate !== null) {
                    var date = billingDate.split(" - ");
                    fromDate = dateFormat.format(new Date(date[0]));
                    toDate = dateFormat.format(new Date(date[1]));
                } else {
                    fromDate = null;
                    toDate = null;
                }

                // var oFilter = [new Filter("payer", FilterOperator.EQ, payer),
                // new Filter("soldTo", FilterOperator.EQ, soldTo),
                // new Filter("country", FilterOperator.EQ, country),
                // new Filter("invoiceNumber", FilterOperator.EQ, invoiceNumber),
                // new Filter("invoiceType", FilterOperator.EQ, invoiceType),
                // new Filter("outputType", FilterOperator.EQ, outputType),
                // new Filter("fromDate", FilterOperator.EQ, fromDate),
                // new Filter("toDate", FilterOperator.EQ, toDate)];


                var requestBody = {
                    "payer": payer,
                    "soldTo": soldTo,
                    "invoiceNumber": invoiceNumber,
                    "invoiceType": invoiceType,
                    "billingDateFrom": fromDate,
                    "billingDateTo": toDate,
                    "country": country,
                    "outputType": outputType
                };





                // var b = [];


                // for (var i = 1; i < 11; i++) {
                //     var a = {
                //         payer1: "Venkat",
                //         billingdate: "10022023",
                //         invoicenumber: i,
                //         country1: "India",
                //         selected: false
                //     };

                //     b.push(a)
                // }

                // that.getModel("SelectModel").setProperty("/originalData", b);

                // that.getModel("SelectModel").setProperty("/noOfRows", b.length);
                // that.getModel("SelectModel").setProperty("/isSelectDataLoading", false);
                // that.onFirstPress();
                // that.fnSetButtonsVisible();





                var settings = {
                    "crossDomain": true,
                    "async": true,
                    // "url": "https://dev-mule-exp-api-sap.cloudhub.io:443/api/document/index",
                    "url": apiData[0].Url2 + "document/index",
                    "method": "POST",
                    "timeout": 0,
                    "headers": {
                        "Access-Control-Allow-Origin": "*",
                        "Access-Control-Allow-Methods": "GET, POST, PUT, DELETE, OPTIONS",
                        "cache-control": "no-cache",
                        "client_id": apiData[0].ClientId,
                        "client_secret": apiData[0].SecreteCode,
                        "Content-Type": "application/json",
                        "system": "sap"
                    },
                    "data": JSON.stringify(requestBody),

                    // "data": JSON.stringify({
                    //     "soldTo": "",
                    //     "payer": "000128",
                    //     "invoiceNumber": "R1121006",
                    //     "invoiceType": "ZF2",
                    //     "billingDateFrom": "20051029",
                    //     "billingDateTo": "20051029",
                    //     "country": "AU",
                    //     "outputType": "Z500"
                    // }),

                    // {
                    //     "soldTo": soldTo,
                    //     "payer": payer,
                    //     "invoiceNumber": invoiceNumber,
                    //     "invoiceType": invoiceType,
                    //     "billingDateFrom": fromDate,
                    //     "billingDateTo": toDate,
                    //     "country": country,
                    //     "outputType": outputType
                    // }
                };


                $.ajax(settings).success(function (response) {
                    // console.log(response);
                    response.resultSet.forEach(function (data) {
                        data.selected = false;
                    });
                    that.getModel("SelectModel").setProperty("/originalData", response.resultSet);

                    that.getModel("SelectModel").setProperty("/noOfRows", response.resultSet.length);
                    that.getModel("SelectModel").setProperty("/isSelectDataLoading", false);
                    that.onFirstPress();
                    that.fnSetButtonsVisible();
                    // debugger;
                }).error(function (error) {
                    // console.log(error);
                    // debugger;
                    if (error.responseJSON.errorMessage) {
                        MessageBox.error(error.responseJSON.errorMessage);
                    }else{
                        var msg = that.getResourceBundle().getText("dataError");
                        MessageBox.error(msg);
                    }
                    // error.responseJSON.errorMessage;
                    that.getModel("SelectModel").setProperty("/isSelectDataLoading", false);
                });


            },

            fnCheckData: function (data) {
                if (data.length > 0) {
                    return data;
                } else {
                    return null;
                }
            },

            onFirstPress: function (oEvent) {
                var data = this.getModel("SelectModel").getProperty("/originalData");
                var noOfTableRows = parseInt(this.getModel("SelectModel").getProperty("/noOfTableRows"));

                // var newData = JSON.parse(JSON.stringify(data)).slice(0, noOfTableRows);
                var newData = data.slice(0, noOfTableRows);

                this.getModel("SelectModel").setProperty("/tableData", newData);
                this.getModel("SelectModel").setProperty("/startIndex", 0);
                this.getModel("SelectModel").setProperty("/endIndex", noOfTableRows - 1);

                this.fnNavButtonsEnable();

            },

            onPreviousPress: function (oEvent) {
                var data = this.getModel("SelectModel").getProperty("/originalData");
                var noOfTableRows = parseInt(this.getModel("SelectModel").getProperty("/noOfTableRows"));
                var startIndex = this.getModel("SelectModel").getProperty("/startIndex");

                // var newData = JSON.parse(JSON.stringify(data)).slice(startIndex - noOfTableRows, startIndex);
                var newData = data.slice(startIndex - noOfTableRows, startIndex);

                this.getModel("SelectModel").setProperty("/tableData", newData);
                this.getModel("SelectModel").setProperty("/startIndex", startIndex - noOfTableRows);
                this.getModel("SelectModel").setProperty("/endIndex", startIndex - 1);

                this.fnNavButtonsEnable();

            },

            onNextPress: function (oEvent) {
                var data = this.getModel("SelectModel").getProperty("/originalData");
                var noOfTableRows = parseInt(this.getModel("SelectModel").getProperty("/noOfTableRows"));
                var startIndex = this.getModel("SelectModel").getProperty("/startIndex");
                var endIndex = this.getModel("SelectModel").getProperty("/endIndex");

                // var newData = JSON.parse(JSON.stringify(data)).slice(endIndex + 1, endIndex + 1 + noOfTableRows);
                var newData = data.slice(endIndex + 1, endIndex + 1 + noOfTableRows);

                this.getModel("SelectModel").setProperty("/tableData", newData);
                this.getModel("SelectModel").setProperty("/startIndex", endIndex + 1);
                this.getModel("SelectModel").setProperty("/endIndex", endIndex + noOfTableRows);

                this.fnNavButtonsEnable();
            },

            onLastPress: function (oEvent) {
                var data = this.getModel("SelectModel").getProperty("/originalData");
                var noOfTableRows = parseInt(this.getModel("SelectModel").getProperty("/noOfTableRows"));
                // var endIndex = this.getModel("SelectModel").getProperty("/endIndex");
                var startIndex;
                var oIndex = data.length % noOfTableRows;
                if (oIndex === 0) {
                    startIndex = data.length - noOfTableRows;
                } else {
                    startIndex = data.length - oIndex;
                }

                // var newData = JSON.parse(JSON.stringify(data)).slice(startIndex);
                var newData = data.slice(startIndex);

                this.getModel("SelectModel").setProperty("/tableData", newData);
                this.getModel("SelectModel").setProperty("/startIndex", startIndex);
                this.getModel("SelectModel").setProperty("/endIndex", data.length);

                this.fnNavButtonsEnable();
            },

            fnNavButtonsEnable: function () {
                var data = this.getModel("SelectModel").getProperty("/originalData");
                // var noOfTableRows = parseInt(this.getModel("SelectModel").getProperty("/noOfTableRows"));
                var startIndex = this.getModel("SelectModel").getProperty("/startIndex");
                var endIndex = this.getModel("SelectModel").getProperty("/endIndex");

                if (data.length > endIndex + 1) {
                    this.getView().byId("BtnNextPressId").setEnabled(true);
                    this.getView().byId("BtnLastPressId").setEnabled(true);
                } else {
                    this.getView().byId("BtnNextPressId").setEnabled(false);
                    this.getView().byId("BtnLastPressId").setEnabled(false);
                }

                if (startIndex === 0) {
                    this.getView().byId("BtnFirstPressId").setEnabled(false);
                    this.getView().byId("BtnPreviousPressId").setEnabled(false);
                } else {
                    this.getView().byId("BtnFirstPressId").setEnabled(true);
                    this.getView().byId("BtnPreviousPressId").setEnabled(true);
                }
            },

            fnSetButtonsVisible: function () {

                var noOfRows = this.getModel("SelectModel").getProperty("/noOfRows");

                if (noOfRows > 0) {
                    this.getView().byId("BtnFirstPressId").setVisible(true);
                    this.getView().byId("BtnPreviousPressId").setVisible(true);
                    this.getView().byId("BtnNextPressId").setVisible(true);
                    this.getView().byId("BtnLastPressId").setVisible(true);
                } else {
                    this.getView().byId("BtnFirstPressId").setVisible(false);
                    this.getView().byId("BtnPreviousPressId").setVisible(false);
                    this.getView().byId("BtnNextPressId").setVisible(false);
                    this.getView().byId("BtnLastPressId").setVisible(false);
                }

            },

            // handleChange: function(oEvent){
            //     debugger;
            // },


            fnGetPDFData: function (Data, flag) {
                var that = this;
                var apiData = this.getModel("SearchModel").getProperty("/ApiData");

                var body = [];

                Data.forEach(function (data) {
                    body.push({
                        "fileName": data.country + "/" + new Date(data.billingDate).getFullYear() + "/" + data.fileName,
                        "fileType": data.fileType
                    });
                });

                var settings = {
                    "crossDomain": true,
                    "async": true,
                    // "url": "https://dev-mule-exp-api-sap.cloudhub.io:443/api/document/fileRetrieve",
                    "url": apiData[0].Url2 + "document/fileRetrieve",
                    "method": "POST",
                    "headers": {
                        "Access-Control-Allow-Origin": "*",
                        "Access-Control-Allow-Methods": "GET, POST, PUT, DELETE, OPTIONS",
                        "cache-control": "no-cache",
                        "client_id": apiData[0].ClientId,
                        "client_secret": apiData[0].SecreteCode,
                        "Content-Type": "application/json",
                        "system": "sap"
                    },
                    // "data": JSON.stringify(body),
                    "data": JSON.stringify([{
                    "fileName": "2023/CHEPINInv_20230204_4000472128_5780605333.PDF",
                    "fileType": ".pdf"
                }]),
                };

                


                $.ajax(settings).success(function (response) {
                    // console.log(response);
                    // return response;
                    // debugger;
                    var oFileName = "";
                    var count = 0;

                    response.forEach(function (data) {
                        if (!data.fileBody) {
                            var fileName = data.fileName.split("/");
                            oFileName = oFileName + "\n" + fileName[fileName.length - 1];
                            count += 1;
                        }
                    });

                    if (count > 0) {
                        var msg = that.getResourceBundle().getText("fileRetrieveErrMsg");
                        MessageBox.error(msg.replace("{0}", oFileName));
                    }

                    if (count === response.length) {
                        that.getModel("SelectModel").setProperty("/isPdfDataLoading", false);
                    } else {

                        if (flag === "ViewPdf") {
                            that.openPDF(response);
                        } else if (flag === "DownloadZip") {
                            that.downloadZip(response);
                        } else {
                            that.downloadPDF(response);
                        }
                    }

                    // debugger;

                }).error(function (error) {
                    // console.log(error);
                    // debugger;
                    var msg = that.getResourceBundle().getText("dataError");
                    MessageBox.error(msg);
                    that.getModel("SelectModel").setProperty("/isPdfDataLoading", false);
                });

            },

            onViewBtnPress: function (oEvent) {
                var that = this;
                this.getModel("SelectModel").setProperty("/isPdfDataLoading", true);
                var index = oEvent.getSource().getBindingContext("SelectModel").sPath.split("/")[2];
                var oSelectedRow = this.getModel("SelectModel").getData().tableData[index];
                var data = this.getModel("SelectModel").getProperty("/originalData");


                // var oSelectedData = jQuery.grep(data, function (element, index) {
                //     return element.billingdate === oSelectedRow.billingdate && element.country1 === oSelectedRow.country1 && element.invoicenumber === oSelectedRow.invoicenumber && element.payer1 === oSelectedRow.payer1 && element.selected === oSelectedRow.selected;
                // });

                this.fnGetPDFData([oSelectedRow], "ViewPdf");

            },

            decodePdfData: function (data) {
                var base64EncodedPDF = data.fileBody; // the encoded string
                var decodedPdfContent = atob(base64EncodedPDF);
                var byteArray = new Uint8Array(decodedPdfContent.length)
                for (var i = 0; i < decodedPdfContent.length; i++) {
                    byteArray[i] = decodedPdfContent.charCodeAt(i);
                }
                return byteArray;
            },

            openPDF: function (response) {

                // var data = this.getView().getModel("PdfModel").getProperty("/PdfData");


                // var base64EncodedPDF = response[0].fileBody; // the encoded string
                // var decodedPdfContent = atob(base64EncodedPDF);
                // var byteArray = new Uint8Array(decodedPdfContent.length)
                // for (var i = 0; i < decodedPdfContent.length; i++) {
                //     byteArray[i] = decodedPdfContent.charCodeAt(i);
                // }

                var byteArray = this.decodePdfData(response[0]);


                //for show pdf data 

                var blob = new Blob([byteArray.buffer], { type: 'application/pdf' });
                var _pdfurl = URL.createObjectURL(blob);

                // solution for Internet Explorer
                // if(window.navigator.msSaveOrOpenBlob){
                //     window.navigator.msSaveOrOpenBlob(blob,"filename.pdf");
                //    }else{
                //     sap.m.URLHelper.redirect(_pdfurl);
                //    }

                var fileName = response[0].fileName.split("/");

                // var zip = new JSZip();
                // zip.file(fileName[fileName.length - 1], byteArray);
                // var content = zip.generate({ type: 'blob' });
                // sap.ui.core.util.File.save(content, "zipfile", "zip");
                // sap.ui.core.util.File.save(byteArray, fileName[fileName.length - 1], "pdf");


                if (!this._PDFViewer) {
                    this._PDFViewer = new sap.m.PDFViewer({
                        width: "auto",
                        source: _pdfurl, // my blob url
                        // title: "document"
                        // showDownloadButton: false
                    });
                    this._PDFViewer.setTitle(fileName[fileName.length - 1]);
                    // this._PDFViewer.setTitle(response[0].fileName.split("/")[2]);
                    jQuery.sap.addUrlWhitelist("blob"); // register blob url as whitelist
                }
                this._PDFViewer.downloadPDF = function () {
                    // File.save(
                    //     byteArray.buffer,
                    //     "Hello_UI5",
                    //     "pdf",
                    //     "application/pdf"
                    // );

                    var fileName = response[0].fileName.split("/");

                    const blobURL = window.URL.createObjectURL(new Blob([byteArray.buffer], { type: 'application/pdf' }));
                    var downloadLink = window.document.createElement('a');
                    var contentTypeHeader = "My Header";
                    downloadLink.href = blobURL;
                    downloadLink.download = fileName[fileName.length - 1];
                    // downloadLink.download = response[0].fileName.split("/")[2];
                    document.body.appendChild(downloadLink);
                    downloadLink.click();
                    document.body.removeChild(downloadLink);
                };
                this.getModel("SelectModel").setProperty("/isPdfDataLoading", false);
                this._PDFViewer.open();

                // For Direct Download
                // const blobURL = window.URL.createObjectURL(new Blob([byteArray.buffer], { type: 'application/pdf' }));
                // var downloadLink = window.document.createElement('a');
                // var contentTypeHeader = "My Header";
                // downloadLink.href = blobURL;
                // downloadLink.download = "file.pdf";
                // document.body.appendChild(downloadLink);
                // downloadLink.click();
                // document.body.removeChild(downloadLink);


                // this.getView().byId("pdfViewer").setSource(_pdfurl);
            },

            downloadPDF: function (response) {
                // var base64EncodedPDF = response[0].fileBody; // the encoded string
                // var decodedPdfContent = atob(base64EncodedPDF);
                // var byteArray = new Uint8Array(decodedPdfContent.length)
                // for (var i = 0; i < decodedPdfContent.length; i++) {
                //     byteArray[i] = decodedPdfContent.charCodeAt(i);
                // }

                var byteArray = this.decodePdfData(response[0]);

                var fileName = response[0].fileName.split("/");

                const blobURL = window.URL.createObjectURL(new Blob([byteArray.buffer], { type: 'application/pdf' }));
                var downloadLink = window.document.createElement('a');
                var contentTypeHeader = "My Header";
                downloadLink.href = blobURL;
                downloadLink.download = fileName[fileName.length - 1];
                // downloadLink.download = response[0].fileName.split("/")[2];
                document.body.appendChild(downloadLink);
                downloadLink.click();
                document.body.removeChild(downloadLink);

                this.getModel("SelectModel").setProperty("/isPdfDataLoading", false);

            },

            onDownloadBtnPress: function (oEvent) {
                var that = this;
                this.getModel("SelectModel").setProperty("/isPdfDataLoading", true);
                var index = oEvent.getSource().getBindingContext("SelectModel").sPath.split("/")[2];
                var oSelectedRow = this.getModel("SelectModel").getData().tableData[index];
                var data = this.getModel("SelectModel").getProperty("/originalData");


                // var oSelectedData = jQuery.grep(data, function (element, index) {
                //     return element.billingdate === oSelectedRow.billingdate && element.country1 === oSelectedRow.country1 && element.invoicenumber === oSelectedRow.invoicenumber && element.payer1 === oSelectedRow.payer1 && element.selected === oSelectedRow.selected;
                // });

                this.fnGetPDFData([oSelectedRow], "DownloadPdf");

            },

            onPressDownloadAll: function () {
                // debugger;


                var that = this;
                var data = this.getModel("SelectModel").getProperty("/originalData");

                var oSelectedData = jQuery.grep(data, function (element, index) {
                    return element.selected === true;
                });

                if (oSelectedData.length > maxRowsSelect) {
                    var msg = this.getResourceBundle().getText("maxRowSelect");
                    MessageBox.information(msg.replace("{0}", maxRowsSelect));
                    // MessageBox.information(msg);
                } else if (oSelectedData.length > 0) {
                    this.fnGetPDFData(oSelectedData, "DownloadZip");
                    this.getModel("SelectModel").setProperty("/isPdfDataLoading", true);
                } else {
                    var msg = this.getResourceBundle().getText("rowSelect");
                    MessageBox.warning(msg);

                }


                // var selectedRows = this.getModel("SelectModel").getProperty("/selectedRows");
                // this.getView().byId("idArcSysTable").getSelectedItems()[0].getBindingContext("SelectModel").sPath.split("/")[2];
                // var data = this.getModel("SelectModel").getProperty("/originalData");


                // var oSelectedData = jQuery.grep(data, function (element, index) {
                //     return element.billingdate === oSelectedRow.billingdate && element.country1 === oSelectedRow.country1 && element.invoicenumber === oSelectedRow.invoicenumber && element.payer1 === oSelectedRow.payer1 && element.selected === oSelectedRow.selected;
                // });

                // this.fnGetPDFData(oSelectedData, "DownloadZip");
            },

            downloadZip: function (response) {

                var that = this;
                var files = [];
                var fileName;

                var msg = this.getResourceBundle().getText("fileRetrieveErrMsg");
                // MessageBox.error(msg.replace("{0}", maxRowsSelect));



                response.forEach(function (data) {
                    // var base64EncodedPDF = data.fileBody; // the encoded string
                    // var decodedPdfContent = atob(base64EncodedPDF);
                    // var byteArray = new Uint8Array(decodedPdfContent.length)
                    // for (var i = 0; i < decodedPdfContent.length; i++) {
                    //     byteArray[i] = decodedPdfContent.charCodeAt(i);
                    // }
                    fileName = data.fileName.split("/");

                    var byteArray = that.decodePdfData(data);

                    // files.push({ name: data.fileName.split("/")[2], data: byteArray });
                    files.push({ name: fileName[fileName.length - 1], data: byteArray });
                });

                // var files = [
                //     { name: response[0].fileName, data: byteArray },
                //     { name: 'file2.pdf', data: byteArray },
                //     { name: 'file3.pdf', data: byteArray }
                // ];
                var zip = new JSZip();
                files.forEach(function (file) {
                    zip.file(file.name, file.data);
                });

                var content = zip.generate({ type: 'blob' });
                var link = document.createElement('a');
                link.href = URL.createObjectURL(content);
                link.download = 'Archival Systems files.zip';
                document.body.appendChild(link);
                link.click();
                document.body.removeChild(link);

                this.getModel("SelectModel").setProperty("/isPdfDataLoading", false);
            },

            fnResetData: function () {
                // this.getModel("FilterModel").setProperty("/payer", "");
                // this.getModel("FilterModel").setProperty("/country", "");
                // this.getModel("FilterModel").setProperty("/invoiceNumber", "");
                // this.getModel("FilterModel").setProperty("/invoiceType", "");
                // this.getModel("FilterModel").setProperty("/soldTo", "");
                // this.getModel("FilterModel").setProperty("/billingDate", "");
                // this.getModel("FilterModel").setProperty("/outputType", "");

                this.onClear();

                this.getModel("SelectModel").setProperty("/tableData", []);
                this.getModel("SelectModel").setProperty("/selectedRows", []);
                this.getModel("SelectModel").setProperty("/originalData", []);
                this.getModel("SelectModel").setProperty("/noOfRows", 0);
                this.getModel("SelectModel").setProperty("/startIndex", 0);
                this.getModel("SelectModel").setProperty("/endIndex", 0);

            },

            onPressSelectAll: function (oEvent) {
                // this.onPressDeSelectAll();
                var data = this.getModel("SelectModel").getProperty("/tableData");
                data.forEach(function (item, index) {
                    if (index < maxRowsSelect) {
                        item.selected = true;
                    } else {
                        return;
                    }

                });

                this.getModel("SelectModel").setProperty("/originalData", data);

            },

            onPressCheckBox: function (oEvent) {

                if (oEvent.getSource().getSelected()) {
                    var data = this.getModel("SelectModel").getProperty("/tableData");
                    data.forEach(function (item, index) {
                        if (index < maxRowsSelect) {
                            item.selected = true;
                        } else {
                            return;
                        }
                    });

                    this.getModel("SelectModel").setProperty("/tableData", data);
                }
                else {
                    var data = this.getModel("SelectModel").getProperty("/originalData");
                    data.forEach(function (item) {
                        item.selected = false;
                    });

                    this.getModel("SelectModel").setProperty("/originalData", data);
                }


            },

            onPressDeSelectAll: function (oEvent) {
                var data = this.getModel("SelectModel").getProperty("/originalData");
                data.forEach(function (item) {
                    item.selected = false;

                });

                this.getModel("SelectModel").setProperty("/originalData", data);

            },

            // onSelectionChange: function (oEvent) {
            //     // debugger;
            //     var selectedRows = this.getModel("SelectModel").getProperty("/selectedRows");

            //     this.getView().byId("idArcSysTable").getItems()[0].setSelected(true);
            //     oEvent.getParameters().listItems[0].getBindingContext("SelectModel").sPath.split("/")[2];
            //     this.getModel("SelectModel").getProperty("/tableData")[oEvent.getParameters().listItems[0].getBindingContext("SelectModel").sPath.split("/")[2]]

            // },


            FnPayerChange: function (oEvent) {
                var inputValue = oEvent.getParameters().value;
                this.getView().getModel("FilterModel").setProperty("/payer", inputValue);
            },

            onPayerValueRequest: function (oEvent) {
                var sInputValue = oEvent.getSource().getValue(),
                    oView = this.getView();

                if (!this._payerValueHelpDialog) {
                    this._payerValueHelpDialog = Fragment.load({
                        id: oView.getId(),
                        name: "com.zarchivalsystems.view.fragments.PayerValueHelp",
                        controller: this
                    }).then(function (oDialog) {
                        oView.addDependent(oDialog);
                        return oDialog;
                    });
                }
                this._payerValueHelpDialog.then(function (oDialog) {
                    // Create a filter for the binding
                    oDialog.getBinding("items").filter([new Filter("Kunnr", FilterOperator.Contains, sInputValue)]);
                    // Open ValueHelpDialog filtered by the input's value
                    oDialog.open(sInputValue);
                });
            },

            onPayerValueHelpSearch: function (oEvent) {
                var sValue = oEvent.getParameter("value");
                var oFilter = new Filter("Kunnr", FilterOperator.Contains, sValue);

                oEvent.getSource().getBinding("items").filter([oFilter]);
            },

            onPayerValueHelpClose: function (oEvent) {
                var oSelectedItem = oEvent.getParameter("selectedItem");


                if (!oSelectedItem) {
                    return;
                }

                this.byId("payerInput").setValue(oSelectedItem.getTitle());
                this.getModel("FilterModel").setProperty("/payer", oSelectedItem.getTitle());

                oEvent.getSource().getBinding("items").filter([]);
            },



            FnSoldToChange: function (oEvent) {
                var inputValue = oEvent.getParameters().value;
                this.getView().getModel("FilterModel").setProperty("/soldTo", inputValue);
            },

            onSoldToValueRequest: function (oEvent) {
                var sInputValue = oEvent.getSource().getValue(),
                    oView = this.getView();

                if (!this._soldToValueHelpDialog) {
                    this._soldToValueHelpDialog = Fragment.load({
                        id: oView.getId(),
                        name: "com.zarchivalsystems.view.fragments.SoldToValueHelp",
                        controller: this
                    }).then(function (oDialog) {
                        oView.addDependent(oDialog);
                        return oDialog;
                    });
                }
                this._soldToValueHelpDialog.then(function (oDialog) {
                    // Create a filter for the binding
                    oDialog.getBinding("items").filter([new Filter("Kunnr", FilterOperator.Contains, sInputValue)]);
                    // Open ValueHelpDialog filtered by the input's value
                    oDialog.open(sInputValue);
                });
            },

            onSoldToValueHelpSearch: function (oEvent) {
                var sValue = oEvent.getParameter("value");
                var oFilter = new Filter("Kunnr", FilterOperator.Contains, sValue);

                oEvent.getSource().getBinding("items").filter([oFilter]);
            },

            onSoldToValueHelpClose: function (oEvent) {
                var oSelectedItem = oEvent.getParameter("selectedItem");


                if (!oSelectedItem) {
                    return;
                }

                this.byId("soldToInput").setValue(oSelectedItem.getTitle());
                this.getView().getModel("FilterModel").setProperty("/soldTo", oSelectedItem.getTitle());

                oEvent.getSource().getBinding("items").filter([]);
            },


            handleInvoiceTypeSelectionChange: function (oEvent) {
                var changedItem = oEvent.getParameter("changedItem");
                var isSelected = oEvent.getParameter("selected");

                var state = "Selected";
                if (!isSelected) {
                    state = "Deselected";
                }


            },

            handleInvoiceTypeSelectionFinish: function (oEvent) {
                var selectedItems = oEvent.getParameter("selectedItems");

                var multiSelect = "";
                var oInvoiceNumber = [];

                for (var i = 0; i < selectedItems.length; i++) {
                    if (multiSelect === "") {
                        multiSelect = selectedItems[i].getKey();   //getText()
                    } else {
                        multiSelect = multiSelect + "," + selectedItems[i].getKey();
                    }

                    oInvoiceNumber.push(selectedItems[i].getKey());
                }

                this.getView().getModel("FilterModel").setProperty("/invoiceType", multiSelect);
                // this.getView().getModel("FilterModel").setProperty("/invoiceType", oInvoiceNumber);

            },




            handleCountrySelectionChange: function (oEvent) {
                var changedItem = oEvent.getParameter("changedItem");
                var isSelected = oEvent.getParameter("selected");

                var state = "Selected";
                if (!isSelected) {
                    state = "Deselected";
                }

            },

            handleCountrySelectionFinish: function (oEvent) {
                var selectedItems = oEvent.getParameter("selectedItems");

                var multiSelect = "";
                var oCountry = [];

                for (var i = 0; i < selectedItems.length; i++) {
                    if (multiSelect === "") {
                        multiSelect = selectedItems[i].getKey();
                    } else {
                        multiSelect = multiSelect + "," + selectedItems[i].getKey();
                    }

                    oCountry.push(selectedItems[i].getKey());

                }

                this.getView().getModel("FilterModel").setProperty("/country", multiSelect);
                // this.getView().getModel("FilterModel").setProperty("/country", oCountry);


            },



            handleOutputTypeSelectionChange: function (oEvent) {
                var changedItem = oEvent.getParameter("changedItem");
                var isSelected = oEvent.getParameter("selected");

                var state = "Selected";
                if (!isSelected) {
                    state = "Deselected";
                }


            },

            handleOutputTypeSelectionFinish: function (oEvent) {
                var selectedItems = oEvent.getParameter("selectedItems");

                var multiSelect = "";
                var oOutputType = [];

                for (var i = 0; i < selectedItems.length; i++) {
                    if (multiSelect === "") {
                        multiSelect = selectedItems[i].getKey();
                    } else {
                        multiSelect = multiSelect + "," + selectedItems[i].getKey();
                    }

                    oOutputType.push(selectedItems[i].getKey());

                }

                this.getView().getModel("FilterModel").setProperty("/outputType", multiSelect);
                // this.getView().getModel("FilterModel").setProperty("/outputType", oOutputType);

            },











        });
    });
