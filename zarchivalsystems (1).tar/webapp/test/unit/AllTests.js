sap.ui.define([
	"com/zarchivalsystems/test/unit/controller/ArchivalSystems.controller"
], function () {
	"use strict";
});
