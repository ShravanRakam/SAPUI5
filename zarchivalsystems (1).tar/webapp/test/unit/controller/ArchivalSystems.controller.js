/*global QUnit*/

sap.ui.define([
	"com/zarchivalsystems/controller/ArchivalSystems.controller"
], function (Controller) {
	"use strict";

	QUnit.module("ArchivalSystems Controller");

	QUnit.test("I should test the ArchivalSystems controller", function (assert) {
		var oAppController = new Controller();
		oAppController.onInit();
		assert.ok(oAppController);
	});

});
