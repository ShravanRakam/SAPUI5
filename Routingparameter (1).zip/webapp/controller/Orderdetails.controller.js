sap.ui.define([
	"sap/ui/core/mvc/Controller",
	"sap/ui/model/json/JSONModel",
	"sap/ui/model/Filter",
	"sap/ui/model/FilterOperator"
], function(Controller, JSONModel, Filter, FilterOperator) {
	"use strict";
	return Controller.extend("RoutingparameterRoutingparameter.controller.Orderdetails", {
		onInit: function() {
			var oRouter = sap.ui.core.UIComponent.getRouterFor(this);
			oRouter.getRoute("Orderdetails").attachPatternMatched(this._onObjectMatched, this);
		},
		_onObjectMatched: function(oEvent) {
			var oUrlArgs = oEvent.getParameter("arguments");
			this.getOrderdetails(oUrlArgs.Customers);
		},
		getOrderdetails: function(sCustomerId) {
			var oModel = this.getOwnerComponent().getModel("northwindModel");
			var that = this;
			// var orderModel = new JSONModel({
			// 	Orders: [],
			// 	IsOrderDetailsLoading: true,
			// 	Customers: sCustomerId
			// });
			// this.getView().setModel(orderModel, "NewModel");
			var oFilter = [new Filter("CustomerID", FilterOperator.EQ, sCustomerId)];
			oModel.read("/Orders", {
				filters: oFilter,
				success: function(oData) {
					// that.getView().getModel("NewModel").setProperty("/Orders", oData.results);
					// that.getView().getModel("NewModel").setProperty("/IsOrderDetailsLoading", false);
					var dataModel = new JSONModel(oData);
					that.getView().setModel(dataModel, "NewModel");
					
				},

				error: function(oError) {

				}

			});
		}
	});
});