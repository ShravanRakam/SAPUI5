sap.ui.define([
	"sap/ui/core/mvc/Controller",
	"sap/ui/model/json/JSONModel",
	"sap/m/MessageBox"
], function(Controller, JSONModel, MessageBox) {
	"use strict";

	return Controller.extend("com.dynamicChartsdynamicCharts.controller.View1", {
		onInit: function() {
			var that = this;
			var oModel = new JSONModel(jQuery.sap.getModulePath("com.dynamicChartsdynamicCharts", "/model/comboModel.json"));
			that.getView().setModel(oModel, "comboModel");

			var value = new JSONModel({
				input: "",
				comboBox: ""
			});
			that.getView().setModel(value, "valueModel");
			var visible = new JSONModel({
				visibleBar: false,
				visibleColumn: false,
				visiblePie: false,
				visibleDonut: false
			});
			that.getView().setModel(visible, "visibleModel");
		},
		onSubmitInput: function(oEvent) {
			var that = this;
			var url = that.getView().getModel("valueModel").getData().input;
			that.handlingInput(url);
		},
		handlingInput: function(url) {
			var that = this;
			var input = that.getView().getModel("valueModel").getData().input;
			var vizType = that.getView().getModel("valueModel").getData().comboBox;
			var array = input.split("/", "7");
			var entity = array.slice(-1).toString();
			var uri = input.replace(entity, "");
			that.getData(uri, entity, vizType);
		},
		getData: function(url, entity, vizType) {
			var that = this;
			var oModel1 = new sap.ui.model.odata.ODataModel(url, true);
			var busyDialog = new sap.m.BusyDialog({
				text: "Data loading please wait..."
			});
			busyDialog.open();
			oModel1.read("/" + entity, {
				success: function(oData) {
					busyDialog.close();
					var oModel = new JSONModel(oData);
					if (oData !== "") {
							that.handlingVizTypes(oData, vizType);
							that.getView().setModel(oModel, "employeeData");
					} else {
						oModel.setData({
							results: []
						});
					}
				},
				error: function(err) {
					busyDialog.close();
					sap.m.MessageBox.error(err.response.body);
				}
			});
		},
		handlingVizTypes: function(oData, vizType) {
			if (vizType === "pie") {
				oData.vizType = "pie";
				oData.measureUid = "size";
				oData.dimensionUid = "color";
			}
			else if(vizType === "donut"){
				oData.vizType = "donut";
				oData.measureUid = "size";
				oData.dimensionUid = "color";
			}
			else if(vizType === "bar"){
				oData.vizType = "bar";
				oData.measureUid = "valueAxis";
				oData.dimensionUid = "categoryAxis";
			}
			else if(vizType === "column"){
				oData.vizType = "column";
				oData.measureUid = "valueAxis";
				oData.dimensionUid = "categoryAxis";
			}
		}
	});
});