sap.ui.define([
	"comfiskerinc/zdlr_acctdet/test/unit/controller/DealerAccountDetails.controller"
], function () {
	"use strict";
});
