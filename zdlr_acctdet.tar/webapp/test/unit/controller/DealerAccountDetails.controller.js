/*global QUnit*/

sap.ui.define([
	"comfiskerinc/zdlr_acctdet/controller/DealerAccountDetails.controller"
], function (Controller) {
	"use strict";

	QUnit.module("DealerAccountDetails Controller");

	QUnit.test("I should test the DealerAccountDetails controller", function (assert) {
		var oAppController = new Controller();
		oAppController.onInit();
		assert.ok(oAppController);
	});

});
