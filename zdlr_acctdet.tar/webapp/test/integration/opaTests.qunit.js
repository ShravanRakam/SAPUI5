/* global QUnit */

sap.ui.require(["com/fiskerinc/zdlracctdet/test/integration/AllJourneys"
], function () {
	QUnit.config.autostart = false;
	QUnit.start();
});
