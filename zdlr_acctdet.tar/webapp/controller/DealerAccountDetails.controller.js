sap.ui.define([
    "sap/ui/core/mvc/Controller",
    "sap/ui/model/json/JSONModel"
],
    /**
     * @param {typeof sap.ui.core.mvc.Controller} Controller
     */
    function (Controller, JSONModel) {
        "use strict";

        return Controller.extend("com.fiskerinc.zdlracctdet.controller.DealerAccountDetails", {
            onInit: function () {
                var that = this,
                oModel = new JSONModel({
                    formBusy: false
                });
                that.getView().setModel(oModel, "visibleModel");
                that.onGetDealerDetails();
            },
            onGetDealerDetails: function(){
                var that = this,
                oModel = that.getOwnerComponent().getModel("serviceModel");
                that.getView().getModel("visibleModel").setProperty("/formBusy", true);
                oModel.read("/DlrAccDSet",{
                    success: function(oData){
                        that.getView().getModel("visibleModel").setProperty("/formBusy", false);
                        var data = new JSONModel(oData.results);
                        that.getView().setModel(data, "dealerModel");
                    },
                    error: function (error) {
                        that.getView().getModel("visibleModel").setProperty("/formBusy", false);
                        MessageBox.error(JSON.parse(error.responseText).error.message.value);

                    }
                });
            }
        });
    });
