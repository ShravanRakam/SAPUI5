sap.ui.define([
	"sap/ui/core/mvc/Controller",
	"sap/ui/model/json/JSONModel"
], function(Controller, JSONModel) {
	"use strict";

	return Controller.extend("com.PropertyPropertyBinding.controller.App", {
		onInit: function(){
		
			var formData = new JSONModel();
			formData.loadData("model/form.json");
			this.getView().setModel(formData);
		}
	});
});