var newArray = [];
//var sdialog;
sap.ui.define([
	"sap/ui/core/mvc/Controller",
	"sap/m/MessageBox",
	"sap/ndc/BarcodeScanner"
], function(Controller, MessageBox, BarcodeScanner) {
	"use strict";

	return Controller.extend("BarCode.controller.View1", {
		
			//----------------------------------------------------------------------------------
		//Function to Busy Dialog(Pallet)
		//----------------------------------------------------------------------------------
		_getBusyDialog: function() {
			var oView = this.getView();
			if (!this.dialog) {
				this.dialog = sap.ui.xmlfragment("BarCode.fragments.BusyIndicator", this);
				oView.addDependent(this.dialog);
			}
			return this.dialog;
		},
		onScanPress: function() {
			var that = this;
	//	that._getBusyDialog.open();
			jQuery.sap.require("sap.ndc.BarcodeScanner");
			sap.ndc.BarcodeScanner.scan(
				function(mResult) {
					var oTable = that.byId("itemsId");
					var serialNumber = oTable.getItems().length + 1;
					var sObject = {};

					sObject.code = mResult.text;
					//alert(sObject.code);
					sObject.format = mResult.format;
					sObject.number = serialNumber;
					var i18nModel = that.getOwnerComponent();
					var error = i18nModel.getModel("i18n").getProperty('submiterror');
					var inputMsg = i18nModel.getModel("i18n").getProperty('code');
					if (sObject.code === "") {
						sap.m.MessageBox.show(
							inputMsg, {
								icon: sap.m.MessageBox.Icon.ERROR,
								title: error //"Error during submitting!"
							});

					} else if (sObject.format === "") {
						sap.m.MessageBox.show(
							inputMsg, {
								icon: sap.m.MessageBox.Icon.ERROR,
								title: error //"Error during submitting!"
							});

					} else {
						newArray.push(sObject);
						var oModel = new sap.ui.model.json.JSONModel(newArray);
						oTable.setModel(oModel, "barcodes");
					}

				},
				function(Error) {
					var i18nModel = that.getOwnerComponent();
					var error = i18nModel.getModel("i18n").getProperty('submiterror');
					var inputMsg = i18nModel.getModel("i18n").getProperty('code');
					sap.m.MessageBox.show(
						inputMsg, {
							icon: sap.m.MessageBox.Icon.ERROR,
							title: error //"Error during submitting!"
						});
				}

			);

		},
		onItemDelete: function(e) {
			if (e.getSource().getItems().length > 0) {
				var path = e.getParameter('listItem').getBindingContext("barcodes").getPath();
				var idx = parseInt(path.substring(path.lastIndexOf('/') + 1));
				var m = e.getSource().getModel("barcodes");

				var d = m.getData();
				d.splice(idx, 1);
				for (var i = 0; i < d.length; i++) {
					d[i].number = i + 1;
				}
				m.setData(d);

			}
		}

	});
});